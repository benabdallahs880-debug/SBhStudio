package com.sbh.studio.mapeditor

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.sbh.studio.ui.AgwColors

/**
 * Éditeur de maps 3D intégré (Three.js via WebView).
 * Charge assets/mapstudio.html (Three.js embarqué localement, sans CDN)
 * et expose un bridge Android pour exporter la map vers SBh Studio.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MapEditorScreen(
    onBack: () -> Unit,
    onMapExported: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    val bridge = remember {
        object {
            @JavascriptInterface
            fun close() {
                mainHandler.post { onBack() }
            }

            @JavascriptInterface
            fun exportMap(json: String) {
                mainHandler.post {
                    onMapExported(json)
                    Toast.makeText(context, "Map importée dans SBh Studio ✓", Toast.LENGTH_SHORT).show()
                }
            }

            @JavascriptInterface
            fun toast(msg: String) {
                mainHandler.post {
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val assetLoader = remember {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
    }

    val webView = remember {
        WebView(context).apply {
            setBackgroundColor(Color.parseColor("#1A1612"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mediaPlaybackRequiresUserGesture = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
                // Les assets sont servis par WebViewAssetLoader sur une origine HTTPS locale.
                // Aucune autorisation file:// inter-origines n'est nécessaire.
                // Améliore les perfs WebGL
                setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    // Log utile en debug ; évite de spammer l'utilisateur
                    return true
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val url = request?.url ?: return null
                    return assetLoader.shouldInterceptRequest(url)
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val uri = request?.url ?: return true
                    return uri.scheme != "https" || uri.host != "appassets.androidplatform.net"
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    loading = false
                    // Injecter les régions fondation si disponibles
                    val regionsFile = java.io.File(context.filesDir, "map_studio_regions.json")
                    if (regionsFile.exists()) {
                        try {
                            val json = regionsFile.readText()
                            val encoded = Base64.encodeToString(json.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                            view?.evaluateJavascript(
                                """
                                (function(){
                                  try {
                                    const raw = atob('$encoded');
                                    const bytes = Uint8Array.from(raw, c => c.charCodeAt(0));
                                    const text = new TextDecoder('utf-8').decode(bytes);
                                    window.__SBH_REGIONS__ = JSON.parse(text);
                                    if (window.SBhBridge && window.SBhBridge.toast) {
                                      window.SBhBridge.toast('Régions AGW chargées');
                                    }
                                  } catch(e) { console.warn('regions inject', e); }
                                })();
                                """.trimIndent(),
                                null
                            )
                        } catch (_: Exception) { /* ignore */ }
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    // Ne signaler que l'erreur de la page principale
                    if (request?.isForMainFrame == true) {
                        loadError = error?.description?.toString() ?: "Erreur de chargement Map Studio"
                        loading = false
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        webView.addJavascriptInterface(bridge, "SBhBridge")
        webView.loadUrl("https://appassets.androidplatform.net/assets/mapstudio.html")
        onDispose {
            try {
                webView.removeJavascriptInterface("SBhBridge")
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            } catch (_: Exception) { /* ignore */ }
        }
    }

    BackHandler { onBack() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AgwColors.DeepNight)
    ) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )

        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = AgwColors.SacredGold
            )
        }

        if (loadError != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AgwColors.DeepNight.copy(alpha = 0.92f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.layout.Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Map Studio n'a pas pu se charger",
                        color = AgwColors.SacredGold
                    )
                    Text(
                        loadError ?: "",
                        color = AgwColors.Sand,
                        modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                    )
                    TextButton(onClick = onBack) {
                        Text("← Retour", color = AgwColors.GoldSoft)
                    }
                }
            }
        }
    }
}
