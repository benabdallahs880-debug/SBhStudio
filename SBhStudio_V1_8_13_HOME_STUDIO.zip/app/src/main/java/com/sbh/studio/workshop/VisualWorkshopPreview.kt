package com.sbh.studio.workshop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sbh.studio.character.CharacterPreview3D
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.ui.AgwColors

/**
 * Visual layer shared by the Workshop. It deliberately sits above the forms so the
 * user sees the thing being built before drowning in fields. The previews are local,
 * deterministic and work without an online service.
 */
@Composable
internal fun VisualWorkshopPreview(
    zone: WorkshopZoneId,
    items: List<SbhItem>,
    blocks: List<SbhBlock>,
    mobs: List<MobEntity>,
    entities: List<SceneEntity>,
    characters: List<com.sbh.studio.character.CharacterProject>,
    maps: List<MapBlueprint>,
    selectedId: String? = null,
    onSelect: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val title = when (zone) {
        WorkshopZoneId.BLOCKS -> "Aperçu du bloc"
        WorkshopZoneId.ITEMS -> "Aperçu de l'objet"
        WorkshopZoneId.MOBS -> "Aperçu de la créature"
        WorkshopZoneId.ENTITIES -> "Aperçu de la scène 3D"
        WorkshopZoneId.CHARACTER_STUDIO -> "Aperçu du personnage"
        WorkshopZoneId.MAPS -> "Aperçu de la carte"
        WorkshopZoneId.GAME_BUILDER -> "Aperçu du jeu"
        else -> "Aperçu visuel"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(AgwDecor.ViewportShape)
            .background(AgwDecor.ViewportFrameBrush)
            .border(AgwDecor.ViewportBorder, AgwDecor.ViewportShape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = AgwColors.PaleMarble, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    "Créer → sélectionner → voir → modifier",
                    color = AgwColors.SilverMuted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            LiveBadge()
        }

        val selectable = when (zone) {
            WorkshopZoneId.BLOCKS -> blocks.map { it.id to it.name }
            WorkshopZoneId.ITEMS -> items.map { it.id to it.name }
            WorkshopZoneId.MOBS -> mobs.map { it.id to it.nom }
            WorkshopZoneId.ENTITIES -> entities.map { it.id to it.name }
            WorkshopZoneId.CHARACTER_STUDIO -> characters.map { it.id to it.name }
            WorkshopZoneId.MAPS -> maps.map { it.id to it.name }
            else -> emptyList()
        }
        if (selectable.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                selectable.forEach { (id, name) ->
                    val selected = selectedId == id
                    FilterChip(
                        selected = selected,
                        onClick = { onSelect(id) },
                        label = {
                            Text(
                                name,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = AgwColors.DeepNight.copy(alpha = 0.55f),
                            labelColor = AgwColors.Sand,
                            selectedContainerColor = AgwColors.SacredGold.copy(alpha = 0.22f),
                            selectedLabelColor = AgwColors.GoldSoft
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = AgwColors.SilverMuted.copy(alpha = 0.28f),
                            selectedBorderColor = AgwColors.SacredGold.copy(alpha = 0.55f)
                        )
                    )
                }
            }
        }

        when (zone) {
            WorkshopZoneId.CHARACTER_STUDIO -> {
                val character = characters.firstOrNull { it.id == selectedId } ?: characters.firstOrNull()
                if (character != null) {
                    CharacterPreview3D(
                        modelUri = character.modelUri,
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                } else {
                    EmptyVisual("Crée un personnage pour le voir ici")
                }
            }
            WorkshopZoneId.ENTITIES -> {
                val entity = entities.firstOrNull { it.id == selectedId && !it.glbUri.isNullOrBlank() } ?: entities.firstOrNull { !it.glbUri.isNullOrBlank() }
                if (entity != null) {
                    CharacterPreview3D(
                        modelUri = entity.glbUri,
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                } else {
                    SceneCanvas(VisualKind.SCENE, "Aucun modèle 3D sélectionné")
                }
            }
            WorkshopZoneId.BLOCKS -> {
                val block = blocks.firstOrNull { it.id == selectedId } ?: blocks.firstOrNull()
                SceneCanvas(VisualKind.BLOCK, block?.name ?: "Nouveau bloc")
            }
            WorkshopZoneId.ITEMS -> {
                val item = items.firstOrNull { it.id == selectedId } ?: items.firstOrNull()
                SceneCanvas(VisualKind.ITEM, item?.name ?: "Nouvel objet")
            }
            WorkshopZoneId.MOBS -> {
                val mob = mobs.firstOrNull { it.id == selectedId } ?: mobs.firstOrNull()
                SceneCanvas(VisualKind.MOB, mob?.nom ?: "Nouvelle créature")
            }
            WorkshopZoneId.MAPS -> {
                val map = maps.firstOrNull { it.id == selectedId } ?: maps.firstOrNull()
                SceneCanvas(VisualKind.MAP, map?.name ?: "Nouvelle carte")
            }
            WorkshopZoneId.GAME_BUILDER -> {
                SceneCanvas(VisualKind.GAME, "Scène de jeu")
            }
            else -> {
                SceneCanvas(VisualKind.STUDIO, "Sélectionne un élément à construire")
            }
        }
    }
}

private enum class VisualKind { BLOCK, ITEM, MOB, MAP, GAME, SCENE, STUDIO }

@Composable
private fun EmptyVisual(message: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(AgwColors.DeepNight.copy(alpha = 0.55f))
            .border(1.dp, AgwColors.SilverMuted.copy(alpha = 0.18f), RoundedCornerShape(14.dp))
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("◇", color = AgwColors.SilverMuted, fontSize = 22.sp)
        Spacer(Modifier.height(8.dp))
        Text(message, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SceneCanvas(kind: VisualKind, label: String) {
    Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(14.dp)).background(AgwColors.DeepNight)) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f + 8f
            val s = minOf(size.width, size.height) * 0.27f
            val stroke = Stroke(width = 3f, cap = StrokeCap.Round)

            // Ground / perspective guides
            drawLine(AgwColors.SilverMuted.copy(alpha = .18f), Offset(cx - s * 1.6f, cy + s), Offset(cx + s * 1.6f, cy + s), 2f)
            drawLine(AgwColors.SilverMuted.copy(alpha = .12f), Offset(cx - s, cy - s * .9f), Offset(cx - s * .25f, cy + s), 2f)
            drawLine(AgwColors.SilverMuted.copy(alpha = .12f), Offset(cx + s, cy - s * .9f), Offset(cx + s * .25f, cy + s), 2f)

            when (kind) {
                VisualKind.BLOCK -> cube(this, cx, cy, s)
                VisualKind.ITEM -> sword(this, cx, cy, s)
                VisualKind.MOB -> humanoid(this, cx, cy, s)
                VisualKind.MAP -> map(this, cx, cy, s)
                VisualKind.GAME -> game(this, cx, cy, s)
                VisualKind.SCENE -> scene(this, cx, cy, s)
                VisualKind.STUDIO -> studio(this, cx, cy, s)
            }
        }
        Text(label, Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp), color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
    }
}

private fun cube(c: androidx.compose.ui.graphics.drawscope.DrawScope, x: Float, y: Float, s: Float) {
    val top = Path().apply { moveTo(x, y - s); lineTo(x + s, y - s * .5f); lineTo(x, y); lineTo(x - s, y - s * .5f); close() }
    val left = Path().apply { moveTo(x - s, y - s * .5f); lineTo(x, y); lineTo(x, y + s); lineTo(x - s, y + s * .5f); close() }
    val right = Path().apply { moveTo(x + s, y - s * .5f); lineTo(x, y); lineTo(x, y + s); lineTo(x + s, y + s * .5f); close() }
    c.drawPath(top, AgwColors.SacredGold.copy(alpha = .78f))
    c.drawPath(left, AgwColors.Sand.copy(alpha = .55f))
    c.drawPath(right, AgwColors.SilverMuted.copy(alpha = .55f))
}

private fun sword(c: androidx.compose.ui.graphics.drawscope.DrawScope, x: Float, y: Float, s: Float) {
    c.rotate(-32f, Offset(x, y)) {
        c.drawRect(AgwColors.SilverMuted, Offset(x - s * .12f, y - s * 1.15f), Size(s * .24f, s * 1.55f))
        c.drawLine(AgwColors.SacredGold, Offset(x - s * .45f, y + s * .42f), Offset(x + s * .45f, y + s * .42f), s * .12f)
        c.drawRect(AgwColors.SacredGold, Offset(x - s * .10f, y + s * .42f), Size(s * .20f, s * .55f))
    }
}

private fun humanoid(c: androidx.compose.ui.graphics.drawscope.DrawScope, x: Float, y: Float, s: Float) {
    c.drawCircle(Offset(x, y - s * .75f), s * .28f, AgwColors.SilverMuted)
    c.drawRoundRect(AgwColors.Sand.copy(alpha = .75f), Offset(x - s * .42f, y - s * .4f), Size(s * .84f, s * .95f), s * .18f, s * .18f)
    c.drawLine(AgwColors.SilverMuted, Offset(x - s * .25f, y + s * .5f), Offset(x - s * .42f, y + s * 1.05f), s * .14f)
    c.drawLine(AgwColors.SilverMuted, Offset(x + s * .25f, y + s * .5f), Offset(x + s * .42f, y + s * 1.05f), s * .14f)
}

private fun map(c: androidx.compose.ui.graphics.drawscope.DrawScope, x: Float, y: Float, s: Float) {
    c.drawRect(AgwColors.Sand.copy(alpha = .22f), Offset(x - s * 1.3f, y - s * .8f), Size(s * 2.6f, s * 1.6f))
    repeat(5) { i ->
        c.drawLine(AgwColors.SacredGold.copy(alpha = .55f), Offset(x - s * 1.1f, y - s * .55f + i * s * .27f), Offset(x + s * 1.0f, y - s * .55f + i * s * .27f), 3f)
    }
    c.drawCircle(Offset(x + s * .55f, y - s * .1f), s * .18f, AgwColors.SacredGold)
}

private fun game(c: androidx.compose.ui.graphics.drawscope.DrawScope, x: Float, y: Float, s: Float) {
    c.drawRoundRect(AgwColors.SilverMuted.copy(alpha = .35f), Offset(x - s * 1.25f, y - s * .65f), Size(s * 2.5f, s * 1.45f), s * .25f, s * .25f, style = Stroke(4f))
    c.drawCircle(Offset(x - s * .65f, y), s * .22f, AgwColors.SacredGold)
    c.drawCircle(Offset(x + s * .65f, y), s * .22f, AgwColors.Sand)
}

private fun scene(c: androidx.compose.ui.graphics.drawscope.DrawScope, x: Float, y: Float, s: Float) {
    cube(c, x, y + s * .1f, s * .8f)
    humanoid(c, x + s * .8f, y - s * .1f, s * .55f)
}

private fun studio(c: androidx.compose.ui.graphics.drawscope.DrawScope, x: Float, y: Float, s: Float) {
    cube(c, x, y, s * .75f)
    c.drawCircle(Offset(x, y - s * .95f), s * .12f, AgwColors.SacredGold)
}
