# SBh Studio V1.4.0

SBh Studio is the Android-first editor and project hub for the SBH ecosystem.

## V1.4.0

- AGW World Core (`sbh.agw.worldcore.v1`)
- SBh Studio ↔ SBH World integration
- Map Atelier / Map Studio integration
- AGW synchronization center
- Settings center
- SBH communication and validation core
- Godot SBH World runtime under `world/SBH_World`

## Repository layout

```text
.
├── app/                 # Android application
├── docs/                # Update/import documentation
├── tools/               # Static validation tools
├── world/               # SBH World Godot runtime
├── .github/workflows/   # CI / release workflow
├── version.json         # Release source of truth
├── build.gradle.kts
└── settings.gradle.kts
```

## Version source of truth

`version.json` is the release metadata source. CI synchronizes `versionCode`, `versionName`, and the Android assets copy before building.

## GitHub Actions

The release workflow builds a signed APK and publishes a GitHub Release. Configure these repository secrets before enabling signed releases:

- `SBH_KEYSTORE_B64`
- `SBH_KEYSTORE_PASSWORD`
- `SBH_KEY_ALIAS`
- `SBH_KEY_PASSWORD`

No signing key is stored in the repository.

## Local validation

```bash
python3 tools/validate_sbh.py
./gradlew assembleDebug
```
