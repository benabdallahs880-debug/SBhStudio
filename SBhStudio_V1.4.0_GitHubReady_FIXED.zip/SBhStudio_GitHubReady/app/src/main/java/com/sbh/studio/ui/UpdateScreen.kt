package com.sbh.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.BuildConfig
import com.sbh.studio.data.AppDiagnostic
import com.sbh.studio.data.DiagItem
import com.sbh.studio.data.DiagStatus
import com.sbh.studio.data.DiagnosticReport
import com.sbh.studio.data.DownloadState
import com.sbh.studio.data.UpdateCheckResult
import com.sbh.studio.data.UpdateInfo
import com.sbh.studio.data.UpdateManager
import com.sbh.studio.data.LocalApkInspection
import com.sbh.studio.data.ManualUpdateImporter
import com.sbh.studio.data.ManualImportResult
import com.sbh.studio.data.ManualUpdateMeta
import com.sbh.studio.data.AgwDataRepository
import com.sbh.studio.data.AgwWorldCoreRepository
import com.sbh.studio.workshop.WorkshopRepository
import com.sbh.studio.security.SbhKeyManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdateScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val updateManager = remember { UpdateManager(context) }
    val diagnostic = remember { AppDiagnostic(context) }
    val scope = rememberCoroutineScope()

    var checking by remember { mutableStateOf(false) }
    var checkResult by remember { mutableStateOf<UpdateCheckResult?>(null) }
    var downloadState by remember { mutableStateOf<DownloadState>(DownloadState.Idle) }

    var updateKey by remember { mutableStateOf("") }
    var updateKeyMessage by remember { mutableStateOf<String?>(null) }
    var updateUnlocked by remember { mutableStateOf(SbhKeyManager.isUnlocked(context)) }

    var diagRunning by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<DiagnosticReport?>(null) }

    val importer = remember { ManualUpdateImporter(context) }
    val agwRepository = remember { AgwDataRepository(context) }
    val worldCoreRepository = remember { AgwWorldCoreRepository(context) }
    val workshopRepository = remember { WorkshopRepository(context) }
    var worldCore by remember { mutableStateOf(worldCoreRepository.load()) }
    var worldSyncBusy by remember { mutableStateOf(false) }
    var worldSyncMessage by remember { mutableStateOf<String?>(null) }
    var worldSyncOk by remember { mutableStateOf(true) }
    var importBusy by remember { mutableStateOf(false) }
    var importPreview by remember { mutableStateOf<ManualImportResult.Preview?>(null) }
    var importMessage by remember { mutableStateOf<String?>(null) }
    var importReport by remember { mutableStateOf<List<String>?>(null) }
    var lastMeta by remember { mutableStateOf(importer.lastMeta()) }

    var apkBusy by remember { mutableStateOf(false) }
    var apkInspection by remember { mutableStateOf<LocalApkInspection?>(null) }
    var apkMessage by remember { mutableStateOf<String?>(null) }

    val pickLocalApk = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        apkBusy = true
        apkMessage = null
        apkInspection = null
        scope.launch {
            try {
                val inspection = withContext(Dispatchers.IO) {
                    val file = updateManager.copyApkFromUri(uri)
                    updateManager.inspectLocalApk(file)
                }
                apkInspection = inspection
            } catch (e: Exception) {
                apkMessage = e.message ?: "Lecture APK impossible"
            } finally {
                apkBusy = false
            }
        }
    }

    val pickUpdateDoc = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        importBusy = true
        importMessage = null
        importReport = null
        importPreview = null
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val text = importer.readUriText(uri)
                    importer.preview(text)
                } catch (e: Exception) {
                    ManualImportResult.Error(e.message ?: "Lecture impossible")
                }
            }
            importBusy = false
            when (result) {
                is ManualImportResult.Preview -> importPreview = result
                is ManualImportResult.Error -> importMessage = result.message
                is ManualImportResult.Success -> { /* not used in preview */ }
            }
        }
    }

    val assetInfo = remember { updateManager.localVersionFromAssets() }
    val currentCode = assetInfo?.versionCode ?: BuildConfig.VERSION_CODE
    val currentName = assetInfo?.versionName ?: BuildConfig.VERSION_NAME

    // État AGW World Core local à l'ouverture
    LaunchedEffect(Unit) {
        worldCore = worldCoreRepository.load()
    }

    fun synchronizeWorldCore() {
        if (worldSyncBusy) return
        worldSyncBusy = true
        worldSyncMessage = null
        scope.launch {
            try {
                val synced = withContext(Dispatchers.IO) {
                    val maps = workshopRepository.loadMaps()
                    val portals = workshopRepository.loadPortals()
                    worldCoreRepository.synchronize(
                        agwRepository,
                        maps,
                        portals,
                        projectId = "global"
                    ).also(worldCoreRepository::save)
                }
                worldCore = synced
                worldSyncOk = true
                worldSyncMessage = "World Core synchronisé : ${synced.nodes.size} nœud(s)."
            } catch (e: Exception) {
                worldSyncOk = false
                worldSyncMessage = e.message ?: "Synchronisation du World Core impossible."
            } finally {
                worldSyncBusy = false
            }
        }
    }

    // Diagnostic automatique à l'ouverture
    LaunchedEffect(Unit) {
        diagRunning = true
        report = diagnostic.runFull()
        diagRunning = false
    }

    fun relancerDiagnostic() {
        diagRunning = true
        report = null
        scope.launch {
            report = diagnostic.runFull()
            diagRunning = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Mises à jour", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                        Text("Diagnostic & version", style = MaterialTheme.typography.labelSmall, color = AgwColors.Sand)
                    }
                },
                navigationIcon = {
                    TextButton(onBack) { Text("←", color = AgwColors.GoldSoft, fontSize = 18.sp) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // —— Fiche identité ——
            IdentityCard(
                versionName = currentName,
                versionCode = currentCode,
                report = report
            )

            // —— AGW World Core V1.4 ——
            SectionTitle("AGW World Core")
            GoldDivider()
            WorldCoreCard(
                worldCore = worldCore,
                expectedFactions = agwRepository.loadFactions().size,
                syncBusy = worldSyncBusy,
                syncMessage = worldSyncMessage,
                syncOk = worldSyncOk,
                onSynchronize = { synchronizeWorldCore() }
            )

            // —— Résumé diagnostic ——
            SectionTitle("État de l'application")
            GoldDivider()
            when {
                diagRunning && report == null -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(22.dp), color = AgwColors.SacredGold, strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Diagnostic en cours…", color = AgwColors.Sand)
                    }
                }
                report != null -> {
                    SummaryRow(report!!)
                    GoldPrimaryButton(
                        if (diagRunning) "Analyse…" else "Relancer le diagnostic",
                        onClick = { if (!diagRunning) relancerDiagnostic() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !diagRunning
                    )
                }
            }

            // —— Connexions ——
            report?.let { r ->
                val connexions = r.items.filter { it.category == "connexion" }
                if (connexions.isNotEmpty()) {
                    SectionTitle("Connexions")
                    GoldDivider()
                    connexions.forEach { DiagRow(it) }
                }

                val modules = r.items.filter { it.category == "module" }
                if (modules.isNotEmpty()) {
                    SectionTitle("Modules (marche / ne marche pas)")
                    GoldDivider()
                    modules.forEach { DiagRow(it) }
                }

                val data = r.items.filter { it.category == "données" }
                if (data.isNotEmpty()) {
                    SectionTitle("Données locales")
                    GoldDivider()
                    data.forEach { DiagRow(it) }
                }

                val system = r.items.filter { it.category == "système" }
                if (system.isNotEmpty()) {
                    SectionTitle("Système")
                    GoldDivider()
                    system.forEach { DiagRow(it) }
                }
            }

            // —— Import manuel Phase 1 ——
            SectionTitle("Import manuel")
            GoldDivider()
            Text(
                "Fournis un document JSON de mise à jour (schéma sbh.studio.update.v1) pour assimiler version + données AGW / atelier.",
                color = AgwColors.Sand,
                style = MaterialTheme.typography.bodySmall
            )
            GoldOutlineButton(
                if (importBusy) "Lecture…" else "Choisir un document de mise à jour",
                onClick = {
                    if (!importBusy) pickUpdateDoc.launch(arrayOf("application/json", "text/plain", "*/*"))
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !importBusy
            )
            GoldOutlineButton(
                "Charger l'exemple intégré (test)",
                onClick = {
                    if (importBusy) return@GoldOutlineButton
                    importBusy = true
                    importMessage = null
                    importReport = null
                    importPreview = null
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            try {
                                importer.preview(importer.loadBundledExample())
                            } catch (e: Exception) {
                                ManualImportResult.Error(e.message ?: "Exemple introuvable")
                            }
                        }
                        importBusy = false
                        when (result) {
                            is ManualImportResult.Preview -> importPreview = result
                            is ManualImportResult.Error -> importMessage = result.message
                            else -> {}
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !importBusy
            )
            lastMeta?.let { meta ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("Dernier import appliqué", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelMedium)
                    val sdf = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE) }
                    Text(
                        "${meta.versionName ?: "?"} · code ${meta.versionCode ?: "?"} · ${sdf.format(Date(meta.appliedAt))}",
                        color = AgwColors.SacredGold,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (meta.sourceName.isNotBlank()) {
                        Text("Source : ${meta.sourceName}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    if (meta.notes.isNotBlank()) {
                        Text(meta.notes, color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            importMessage?.let { msg ->
                StatusBanner(msg, DiagStatus.FAIL)
            }
            importPreview?.let { prev ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("Aperçu — prêt à assimiler", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelMedium)
                    prev.summary.forEach { line ->
                        Text("· $line", color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    GoldPrimaryButton(
                        if (importBusy) "Assimilation…" else "Assimiler ce document",
                        onClick = {
                            if (importBusy) return@GoldPrimaryButton
                            importBusy = true
                            scope.launch {
                                val applied = withContext(Dispatchers.IO) {
                                    importer.apply(prev.raw, sourceName = "document_manuel.json")
                                }
                                importBusy = false
                                when (applied) {
                                    is ManualImportResult.Success -> {
                                        importPreview = null
                                        importReport = applied.report
                                        lastMeta = applied.meta
                                        importMessage = null
                                        // Relancer diagnostic
                                        diagRunning = true
                                        report = diagnostic.runFull()
                                        diagRunning = false
                                    }
                                    is ManualImportResult.Error -> {
                                        importMessage = applied.message
                                    }
                                    else -> {}
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !importBusy
                    )
                    GoldOutlineButton(
                        "Annuler l'aperçu",
                        onClick = { importPreview = null },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            importReport?.let { lines ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("Rapport d'assimilation", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                    lines.forEach { Text("✓ $it", color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall) }
                }
            }

            // —— Phase 2 : APK local ——
            SectionTitle("Installer un APK local")
            GoldDivider()
            Text(
                "Choisis un fichier .apk signé avec la même clé que l'app installée, et un versionCode supérieur.",
                color = AgwColors.Sand,
                style = MaterialTheme.typography.bodySmall
            )
            GoldOutlineButton(
                if (apkBusy) "Analyse de l'APK…" else "Choisir un fichier APK",
                onClick = {
                    if (!apkBusy) pickLocalApk.launch(arrayOf(
                        "application/vnd.android.package-archive",
                        "application/octet-stream",
                        "*/*"
                    ))
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !apkBusy
            )
            apkMessage?.let { StatusBanner(it, DiagStatus.FAIL) }
            apkInspection?.let { info ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("APK local analysé", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelMedium)
                    Text(
                        "${info.versionName ?: "?"}  ·  code ${info.versionCode}",
                        fontWeight = FontWeight.Bold,
                        color = AgwColors.SacredGold
                    )
                    Text("Package : ${info.packageName}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Signature : ${if (info.signatureMatches) "OK (identique)" else "DIFFÉRENTE"}",
                        color = if (info.signatureMatches) AgwColors.SacredGold else AgwColors.DriedBlood,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "Plus récent : ${if (info.isNewer) "oui" else "non"}",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(info.reason, color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    if (info.canInstall) {
                        GoldPrimaryButton(
                            "Installer cet APK",
                            onClick = {
                                try {
                                    updateManager.installLocalApk(info.file)
                                } catch (e: Exception) {
                                    apkMessage = e.message ?: "Installation refusée"
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        StatusBanner("Installation bloquée — ${info.reason}", DiagStatus.FAIL)
                    }
                    GoldOutlineButton(
                        "Annuler",
                        onClick = { apkInspection = null; apkMessage = null },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // —— Clé temporaire de mise à jour ——
            SectionTitle("Clé de mise à jour")
            GoldDivider()
            Text(
                if (updateUnlocked) "Accès aux mises à jour déverrouillé sur cet appareil."
                else "Entre la clé temporaire pour déverrouiller les fonctions de mise à jour.",
                color = AgwColors.Sand,
                style = MaterialTheme.typography.bodySmall
            )
            if (!updateUnlocked) {
                OutlinedTextField(
                    value = updateKey,
                    onValueChange = {
                        updateKey = it
                        updateKeyMessage = null
                    },
                    label = { Text("Code clé") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AgwColors.SacredGold,
                        unfocusedBorderColor = AgwColors.GoldSoft,
                        focusedLabelColor = AgwColors.SacredGold,
                        unfocusedLabelColor = AgwColors.Sand,
                        focusedTextColor = AgwColors.PaleMarble,
                        unfocusedTextColor = AgwColors.PaleMarble
                    )
                )
                Spacer(Modifier.height(6.dp))
                GoldPrimaryButton(
                    "Déverrouiller les mises à jour",
                    onClick = {
                        updateUnlocked = SbhKeyManager.unlock(context, updateKey)
                        updateKeyMessage = if (updateUnlocked)
                            "Clé acceptée. Les mises à jour sont déverrouillées."
                        else
                            "Clé incorrecte."
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                GoldOutlineButton(
                    "Verrouiller la clé sur cet appareil",
                    onClick = {
                        SbhKeyManager.lock(context)
                        updateUnlocked = false
                        updateKey = ""
                        updateKeyMessage = null
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            updateKeyMessage?.let { msg ->
                StatusBanner(msg, if (updateUnlocked) DiagStatus.OK else DiagStatus.FAIL)
            }

            // —— Mises à jour distantes ——
            SectionTitle("Mises à jour distantes")
            GoldDivider()
            GoldPrimaryButton(
                text = if (checking) "Vérification en cours…" else "Vérifier les mises à jour",
                onClick = {
                    checking = true
                    checkResult = null
                    downloadState = DownloadState.Idle
                    scope.launch {
                        checkResult = updateManager.checkForUpdate(currentCode)
                        checking = false
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = updateUnlocked && !checking && downloadState !is DownloadState.Downloading
            )

            when (val result = checkResult) {
                is UpdateCheckResult.UpToDate -> {
                    StatusBanner("Tu as déjà la dernière version.", DiagStatus.OK)
                }
                is UpdateCheckResult.Error -> {
                    StatusBanner("Impossible de vérifier : ${result.message}", DiagStatus.FAIL)
                    Text(
                        "Vérifie : réseau, repo public, release avec APK + body = version.json",
                        color = AgwColors.DesertOchre,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                is UpdateCheckResult.UpdateAvailable -> UpdateAvailableCard(
                    info = result.info,
                    localCode = currentCode,
                    downloadState = downloadState,
                    onDownload = {
                        downloadState = DownloadState.Downloading
                        scope.launch {
                            try {
                                val id = updateManager.startDownload(result.info.apkUrl)
                                downloadState = updateManager.awaitDownload(id, result.info.sha256)
                            } catch (e: Exception) {
                                downloadState = DownloadState.Failed(e.message ?: "Erreur téléchargement")
                            }
                        }
                    },
                    onInstall = { file ->
                        try {
                            updateManager.installApk(file)
                        } catch (e: Exception) {
                            downloadState = DownloadState.Failed(
                                e.message ?: "APK refusé : signature ou application incompatible."
                            )
                        }
                    }
                )
                null -> {
                    Text(
                        "Appuie sur « Vérifier » pour interroger GitHub Releases.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Text(
                "Le diagnostic détecte connexions, modules (Map Studio, Atelier…) et anomalies locales. " +
                    "Le versionCode de version.json doit être identique dans l'APK et dans le body de la release GitHub.",
                style = MaterialTheme.typography.bodySmall,
                color = AgwColors.Sand
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun WorldCoreCard(
    worldCore: com.sbh.studio.data.AgwWorldCoreState,
    expectedFactions: Int,
    syncBusy: Boolean,
    syncMessage: String?,
    syncOk: Boolean,
    onSynchronize: () -> Unit
) {
    val factionCount = worldCore.nodes.count { it.type == "faction" }
    val mapCount = worldCore.nodes.count { it.type == "map" }
    val portalCount = worldCore.nodes.count { it.type == "portal" }
    val npcCount = worldCore.nodes.count { it.type == "npc" }
    val schemaOk = worldCore.schema == "sbh.agw.worldcore.v1"
    val factionsOk = factionCount == expectedFactions
    val stateOk = schemaOk && factionsOk

    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(if (stateOk) DiagStatus.OK else DiagStatus.WARN)
            Column(Modifier.weight(1f)) {
                Text(
                    worldCore.worldName,
                    color = AgwColors.SacredGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    "${worldCore.worldId} · ${worldCore.schema}",
                    color = AgwColors.Sand,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Factions $factionCount/$expectedFactions · Maps $mapCount · Portails $portalCount · PNJ $npcCount · Total ${worldCore.nodes.size}",
            color = AgwColors.PaleMarble,
            style = MaterialTheme.typography.bodySmall
        )
        Text(
            if (stateOk) "✓ Contrat AGW valide et données locales cohérentes"
            else "⚠ Vérifier le schéma ou la synchronisation des factions",
            color = if (stateOk) AgwColors.SacredGold else AgwColors.DesertOchre,
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        GoldPrimaryButton(
            if (syncBusy) "Synchronisation…" else "Synchroniser AGW World Core",
            onClick = onSynchronize,
            modifier = Modifier.fillMaxWidth(),
            enabled = !syncBusy
        )
        syncMessage?.let {
            Spacer(Modifier.height(6.dp))
            StatusBanner(it, if (syncOk) DiagStatus.OK else DiagStatus.FAIL)
        }
    }
}

@Composable
private fun IdentityCard(versionName: String, versionCode: Int, report: DiagnosticReport?) {
    val id = report?.identity
    GlassCard(Modifier.fillMaxWidth()) {
        Text("Fiche application", color = AgwColors.DesertOchre, style = MaterialTheme.typography.labelMedium)
        Text(
            "$versionName  ·  code $versionCode",
            fontWeight = FontWeight.Bold,
            color = AgwColors.SacredGold,
            fontSize = 18.sp
        )
        if (id != null) {
            Spacer(Modifier.height(6.dp))
            InfoLine("Package", id.packageName)
            InfoLine("Build", id.buildType)
            InfoLine("Appareil", id.deviceModel)
            InfoLine("Android SDK", id.sdkInt.toString())
            InfoLine("Source d'install", id.installSource)
            id.assetVersionName?.let {
                InfoLine("Assets version.json", "$it (code ${id.assetVersionCode})")
            }
            val sdf = remember { SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE) }
            InfoLine("Diagnostic", sdf.format(Date(report.generatedAtMs)))
        } else {
            Text(
                "Source : version.json (même fichier que la release GitHub)",
                style = MaterialTheme.typography.bodySmall,
                color = AgwColors.Sand
            )
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Text(value, color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SummaryRow(report: DiagnosticReport) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SummaryChip("OK", report.okCount, AgwColors.SacredGold, Modifier.weight(1f))
        SummaryChip("Attention", report.warnCount, AgwColors.DesertOchre, Modifier.weight(1f))
        SummaryChip("Problème", report.failCount, AgwColors.DriedBlood, Modifier.weight(1f))
    }
}

@Composable
private fun SummaryChip(label: String, count: Int, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(AgwDecor.CardShape)
            .background(AgwColors.NightGlass)
            .border(1.dp, color.copy(alpha = 0.5f), AgwDecor.CardShape)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("$count", fontWeight = FontWeight.Bold, color = color, fontSize = 20.sp)
        Text(label, color = AgwColors.Sand, fontSize = 11.sp)
    }
}

@Composable
private fun DiagRow(item: DiagItem) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(AgwDecor.CardShape)
            .background(AgwColors.NightGlass)
            .border(1.dp, statusColor(item.status).copy(alpha = 0.35f), AgwDecor.CardShape)
            .padding(12.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatusDot(item.status)
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.title, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble, modifier = Modifier.weight(1f))
                Text(statusLabel(item.status), color = statusColor(item.status), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Text(item.detail, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun StatusDot(status: DiagStatus) {
    Box(
        Modifier
            .size(12.dp)
            .clip(CircleShape)
            .background(statusColor(status))
    )
}

@Composable
private fun StatusBanner(text: String, status: DiagStatus) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(AgwDecor.CardShape)
            .background(statusColor(status).copy(alpha = 0.15f))
            .border(1.dp, statusColor(status).copy(alpha = 0.4f), AgwDecor.CardShape)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatusDot(status)
        Text(text, color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodyMedium)
    }
}

private fun statusColor(s: DiagStatus): Color = when (s) {
    DiagStatus.OK -> Color(0xFFC9A227)
    DiagStatus.WARN -> Color(0xFF8C6A3F)
    DiagStatus.FAIL -> Color(0xFFB33A3A)
    DiagStatus.UNKNOWN -> Color(0xFF6B6560)
}

private fun statusLabel(s: DiagStatus): String = when (s) {
    DiagStatus.OK -> "OK · connecté / marche"
    DiagStatus.WARN -> "Attention"
    DiagStatus.FAIL -> "Problème · déconnecté"
    DiagStatus.UNKNOWN -> "Inconnu"
}

@Composable
private fun UpdateAvailableCard(
    info: UpdateInfo,
    localCode: Int,
    downloadState: DownloadState,
    onDownload: () -> Unit,
    onInstall: (java.io.File) -> Unit
) {
    GlassCard(Modifier.fillMaxWidth()) {
        Text("Nouvelle version disponible", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelMedium)
        Text(
            "${info.versionName}  ·  code ${info.versionCode}",
            style = MaterialTheme.typography.titleMedium,
            color = AgwColors.SacredGold
        )
        Text(
            "Installé : code $localCode → Distant : code ${info.versionCode}",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        if (info.notes.isNotBlank()) {
            Text(info.notes, style = MaterialTheme.typography.bodyMedium, color = AgwColors.PaleMarble)
        }

        when (val s = downloadState) {
            is DownloadState.Idle -> GoldPrimaryButton("Télécharger l'APK", onDownload, Modifier.fillMaxWidth())
            is DownloadState.Downloading -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = AgwColors.SacredGold, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Téléchargement…", color = AgwColors.Sand)
            }
            is DownloadState.ReadyToInstall -> GoldPrimaryButton(
                "Installer maintenant",
                { onInstall(s.apkFile) },
                Modifier.fillMaxWidth()
            )
            is DownloadState.Failed -> Text("Échec : ${s.message}", color = AgwColors.DriedBlood)
        }
    }
}
