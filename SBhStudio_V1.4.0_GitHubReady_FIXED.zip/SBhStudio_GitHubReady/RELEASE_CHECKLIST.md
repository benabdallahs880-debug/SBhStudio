# SBh Studio 1.4.0 — release checklist

## Version
- Vérifier `version.json` : `versionCode=29`, `versionName=1.4.0`.
- Vérifier que `app/build.gradle.kts` correspond après synchronisation CI.
- Vérifier `world/integration_manifest.json` : intégration `1.4.0`, Studio `SBh Studio V1.4`.

## GitHub Actions
Create these repository secrets before a Release build:

- `SBH_KEYSTORE_B64`: base64 du keystore de publication
- `SBH_KEYSTORE_PASSWORD`: mot de passe du keystore
- `SBH_KEY_ALIAS`: alias de la clé
- `SBH_KEY_PASSWORD`: mot de passe de la clé

La clé privée ne doit jamais être commitée dans Git.

## Build

1. Push sur `main`/`master` ou lancer `workflow_dispatch`.
2. Vérifier `assembleRelease`.
3. Vérifier l'artefact APK.
4. Vérifier que le SHA-256 publié correspond à l'APK.
5. Vérifier que la Release contient l'APK et `version-1.4.0.json`.

## Intégration AGW / SBH World

1. Vérifier le chargement du World Core.
2. Vérifier la présence des nœuds AGW attendus.
3. Vérifier la synchronisation Studio → World Core.
4. Vérifier la projection vers SBH World via `AGWWorldAdapter`.
5. Vérifier une opération voxel via `PlacementAdapter`.
6. Vérifier qu'une modification utilisateur du World Core est rechargée depuis `user://agw_world_core/`.

## Téléphone

1. Installer la première version signée.
2. Activer l'autorisation d'installation d'applications inconnues pour SBh Studio si Android la demande.
3. Vérifier une mise à jour vers un `versionCode` supérieur.
4. Vérifier qu'un APK signé avec une autre clé est refusé.
5. Vérifier qu'un APK dont le SHA-256 ne correspond pas au manifeste de release est refusé.
6. Tester import/export Minecraft Bedrock.
7. Tester Map Studio et l'intégration SBH World.
