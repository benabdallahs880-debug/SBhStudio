package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Detailed runtime error captured without replacing the original error. */
@Serializable
data class RuntimeErrorRecord(
    val errorId: String = "SBH-ERR-" + UUID.randomUUID().toString().take(8).uppercase(Locale.US),
    val timestampMs: Long = System.currentTimeMillis(),
    val module: String? = null,
    val action: String? = null,
    val state: String? = null,
    val name: String = "Error",
    val message: String = "",
    val filename: String? = null,
    val line: Int? = null,
    val column: Int? = null,
    val function: String? = null,
    val stack: String? = null,
    val lastEvent: String? = null,
    val recentActions: List<String> = emptyList(),
    val runtimeState: Map<String, String> = emptyMap(),
    val raw: String = "",
    val interpretation: String? = null
) {
    fun humanReport(): String = buildString {
        appendLine("🔴 ERREUR RUNTIME")
        appendLine()
        appendLine("ERROR_ID"); appendLine(errorId); appendLine()
        appendLine("Type"); appendLine(name); appendLine()
        appendLine("Message original"); appendLine(message); appendLine()
        appendLine("Fichier"); appendLine(filename ?: "Non déterminé")
        appendLine("Ligne / colonne"); appendLine(if (line != null) "$line / ${column ?: "?"}" else "Non déterminées")
        appendLine("Fonction"); appendLine(function ?: "Non déterminée"); appendLine()
        appendLine("Module"); appendLine(module ?: "Non déterminé")
        appendLine("Action"); appendLine(action ?: "Non déterminée")
        appendLine("État"); appendLine(state ?: "Non déterminé")
        appendLine("Dernière action"); appendLine(lastEvent ?: "Aucun événement"); appendLine()
        appendLine("Journal récent")
        recentActions.forEach { appendLine(it) }
        appendLine()
        appendLine("Interprétation"); appendLine(interpretation ?: "Analyse automatique non disponible."); appendLine()
        appendLine("Stack"); appendLine(stack ?: "Non disponible")
    }

    fun developerReport(): String = buildString {
        appendLine(humanReport())
        appendLine()
        appendLine("ÉTAT RUNTIME")
        runtimeState.forEach { (k, v) -> appendLine("$k=$v") }
        appendLine()
        appendLine("ERREUR BRUTE")
        appendLine(raw.ifBlank { message })
    }
}

class RuntimeDiagnosticStore(private val context: Context) {
    private val file = File(context.filesDir, "diagnostics/runtime_errors.json")
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    fun save(record: RuntimeErrorRecord) {
        runCatching {
            file.parentFile?.mkdirs()
            val list = load().toMutableList()
            list.add(0, record)
            file.writeText(json.encodeToString(list.take(50)))
        }
    }

    fun load(): List<RuntimeErrorRecord> = runCatching {
        if (!file.exists()) emptyList() else json.decodeFromString(file.readText())
    }.getOrDefault(emptyList())

    fun latest(): RuntimeErrorRecord? = load().firstOrNull()

    fun appendEvent(message: String) {
        val eventFile = File(context.filesDir, "diagnostics/runtime_events.log")
        runCatching {
            eventFile.parentFile?.mkdirs()
            val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
            eventFile.appendText("[$time] $message\n")
            val lines = eventFile.readLines()
            if (lines.size > 200) eventFile.writeText(lines.takeLast(200).joinToString("\n") + "\n")
        }
    }

    fun recentEvents(limit: Int = 12): List<String> = runCatching {
        val eventFile = File(context.filesDir, "diagnostics/runtime_events.log")
        if (!eventFile.exists()) emptyList() else eventFile.readLines().takeLast(limit)
    }.getOrDefault(emptyList())
}
