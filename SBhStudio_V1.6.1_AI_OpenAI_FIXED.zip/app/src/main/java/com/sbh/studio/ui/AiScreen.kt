package com.sbh.studio.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.ai.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiScreen(back: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val manager = remember { AiPermissionManager(context) }
    val dispatcher = remember { AiActionDispatcher(context) }
    val client = remember { AiOpenAiClient() }
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(manager.load()) }
    var history by remember { mutableStateOf(dispatcher.history()) }
    var connected by remember { mutableStateOf(settings.enabled) }
    var gatewayUrl by remember { mutableStateOf(settings.gatewayUrl) }
    var model by remember { mutableStateOf(settings.model) }
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var connectionState by remember { mutableStateOf("⚪ Passerelle non testée") }
    var busy by remember { mutableStateOf(false) }

    fun refresh() { settings = manager.load(); history = dispatcher.history(); connected = settings.enabled; gatewayUrl = settings.gatewayUrl; model = settings.model }
    fun saveConnection() {
        manager.save(settings.copy(provider = "OpenAI / passerelle", model = model.trim().ifBlank { "gpt-5-mini" }, gatewayUrl = gatewayUrl.trim()))
        refresh()
    }
    fun togglePermission(p: AiPermission) {
        val next = settings.permissions.toMutableSet().apply { if (!remove(p)) add(p) }
        manager.save(settings.copy(permissions = next)); refresh()
    }
    fun sendToOpenAI() {
        if (!settings.enabled || AiPermission.ANALYZE !in settings.permissions) {
            connectionState = "🔴 Action refusée : permission ANALYZE absente ou canal désactivé."
            return
        }
        saveConnection()
        if (gatewayUrl.isBlank()) { connectionState = "🟡 Configure d'abord la passerelle sécurisée."; return }
        busy = true
        connectionState = "🟡 Communication avec la passerelle..."
        scope.launch(Dispatchers.IO) {
            val session = settings.provider + ":" + gatewayUrl
            val result = client.send(gatewayUrl, model, prompt, session)
            launch(Dispatchers.Main) {
                busy = false
                if (result.ok) {
                    answer = result.text
                    connectionState = "🟢 OpenAI connecté via la passerelle"
                    dispatcher.dispatch("AI_CHAT", "OpenAI", AiPermission.ANALYZE)
                    refresh()
                } else connectionState = "🔴 ${result.detail}"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Column { Text("🧠 SBh AI", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold); Text("INTELLIGENCE & CONTRÔLE", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall) } },
                navigationIcon = { TextButton(onClick = back) { Text("‹", fontSize = 32.sp, color = AgwColors.PaleMarble) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        }, containerColor = AgwColors.DeepNight
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                ForgeSectionCard(title = "Connexion IA") {
                    Text(if (connected) "🟢 Canal IA activé" else "⚪ Canal IA désactivé", color = if (connected) AgwColors.Success else AgwColors.Sand)
                    Text("Fournisseur : ${settings.provider}", color = AgwColors.PaleMarble)
                    Text("Modèle : ${settings.model}", color = AgwColors.PaleMarble)
                    Text(connectionState, color = AgwColors.Sand)
                    Spacer(Modifier.height(8.dp))
                    GoldPrimaryButton(text = if (connected) "Déconnecter l'IA" else "Activer le canal IA", onClick = { manager.save(settings.copy(enabled = !connected)); refresh() }, modifier = Modifier.fillMaxWidth())
                }
            }
            item {
                ForgeSectionCard(title = "Connexion OpenAI") {
                    Text("Cette version se connecte à OpenAI via une passerelle HTTPS. La clé API reste côté serveur, jamais dans l'APK.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = gatewayUrl, onValueChange = { gatewayUrl = it }, label = { Text("URL de la passerelle HTTPS") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Modèle") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    GoldOutlineButton(text = "Enregistrer la connexion", onClick = { saveConnection(); connectionState = "🟡 Configuration enregistrée" }, modifier = Modifier.fillMaxWidth())
                }
            }
            item {
                ForgeSectionCard(title = "Niveau d'accès") {
                    listOf(AiAccessLevel.LOW to "🔵 Faible", AiAccessLevel.MEDIUM to "🟡 Moyen", AiAccessLevel.FULL to "🟢 Total").forEach { (level, label) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { RadioButton(settings.accessLevel == level, onClick = { manager.setAccessLevel(level); refresh() }); Text(label, color = AgwColors.PaleMarble) }
                    }
                    Text("Le niveau applique un jeu de permissions par défaut. Chaque permission peut ensuite être ajustée.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                }
            }
            item {
                ForgeSectionCard(title = "Permissions") {
                    AiPermission.values().forEach { p ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = p in settings.permissions, onCheckedChange = { togglePermission(p) })
                            Text(permissionLabel(p), color = AgwColors.PaleMarble, modifier = Modifier.weight(1f))
                            if (p == AiPermission.SENSITIVE_ACTIONS) Text("⚠", color = AgwColors.Warning)
                        }
                    }
                }
            }
            item {
                ForgeSectionCard(title = "💬 Communication avec OpenAI") {
                    Text("L'application peut envoyer une demande au modèle et recevoir sa réponse. Ce n'est pas une connexion directe à cette conversation ChatGPT : l'API OpenAI est un service séparé.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Message à l'IA") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    GoldPrimaryButton(text = if (busy) "Communication..." else "Envoyer à OpenAI", onClick = { sendToOpenAI() }, modifier = Modifier.fillMaxWidth())
                    if (answer.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text("Réponse", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                        Text(answer, color = AgwColors.PaleMarble)
                    }
                }
            }
            item {
                ForgeSectionCard(title = "Test du SBh AI Bridge") {
                    Text("Teste les permissions sans modifier aucun fichier.", color = AgwColors.Sand)
                    Spacer(Modifier.height(8.dp))
                    GoldOutlineButton(text = "Tester lecture", onClick = { dispatcher.dispatch("READ_PROJECT", "SBh Studio", AiPermission.READ); refresh() }, modifier = Modifier.fillMaxWidth())
                    GoldOutlineButton(text = "Tester modification", onClick = { dispatcher.dispatch("MODIFY_TEST", "Diagnostic", AiPermission.MODIFY); refresh() }, modifier = Modifier.fillMaxWidth())
                    GoldOutlineButton(text = "Tester suppression", onClick = { dispatcher.dispatch("DELETE_TEST", "Diagnostic", AiPermission.DELETE); refresh() }, modifier = Modifier.fillMaxWidth())
                }
            }
            item { Text("Journal des actions IA", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            items(history.take(20)) { action ->
                ForgeSectionCard(title = if (action.allowed) "🟢 ${action.action}" else "🔴 ${action.action}") {
                    Text("Module : ${action.module}", color = AgwColors.PaleMarble)
                    Text("Permission : ${permissionLabel(action.permission)}", color = AgwColors.Sand)
                    Text(action.detail, color = AgwColors.Sand)
                    Text(SimpleDateFormat("dd/MM HH:mm:ss", Locale.FRANCE).format(Date(action.timestampMs)), color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

private fun permissionLabel(p: AiPermission): String = when (p) {
    AiPermission.READ -> "Lire"
    AiPermission.ANALYZE -> "Analyser"
    AiPermission.CREATE -> "Créer"
    AiPermission.MODIFY -> "Modifier"
    AiPermission.EXPORT -> "Exporter"
    AiPermission.IMPORT -> "Importer"
    AiPermission.EXECUTE -> "Exécuter"
    AiPermission.DELETE -> "Supprimer"
    AiPermission.CONFIGURE -> "Configurer"
    AiPermission.SENSITIVE_ACTIONS -> "Actions sensibles sans confirmation"
}
