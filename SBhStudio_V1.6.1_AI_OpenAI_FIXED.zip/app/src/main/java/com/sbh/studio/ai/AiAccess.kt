package com.sbh.studio.ai

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

@Serializable
enum class AiAccessLevel { LOW, MEDIUM, FULL }

@Serializable
enum class AiPermission {
    READ,
    ANALYZE,
    CREATE,
    MODIFY,
    EXPORT,
    IMPORT,
    EXECUTE,
    DELETE,
    CONFIGURE,
    SENSITIVE_ACTIONS
}

@Serializable
data class AiSettings(
    val enabled: Boolean = false,
    val provider: String = "Non configuré",
    val model: String = "gpt-5-mini",
    val gatewayUrl: String = "",
    val accessLevel: AiAccessLevel = AiAccessLevel.LOW,
    val permissions: Set<AiPermission> = defaultPermissions(AiAccessLevel.LOW)
)

@Serializable
data class AiSession(
    val id: String = "AI-" + UUID.randomUUID().toString().take(8).uppercase(),
    val provider: String,
    val model: String,
    val accessLevel: AiAccessLevel,
    val startedAtMs: Long = System.currentTimeMillis()
)

@Serializable
data class AiAction(
    val id: String = "ACT-" + UUID.randomUUID().toString().take(8).uppercase(),
    val action: String,
    val module: String,
    val permission: AiPermission,
    val allowed: Boolean,
    val detail: String,
    val timestampMs: Long = System.currentTimeMillis()
)

fun defaultPermissions(level: AiAccessLevel): Set<AiPermission> = when (level) {
    AiAccessLevel.LOW -> setOf(AiPermission.READ, AiPermission.ANALYZE)
    AiAccessLevel.MEDIUM -> setOf(
        AiPermission.READ, AiPermission.ANALYZE, AiPermission.CREATE,
        AiPermission.MODIFY, AiPermission.EXPORT
    )
    AiAccessLevel.FULL -> AiPermission.values().toSet() - AiPermission.SENSITIVE_ACTIONS
}

class AiPermissionManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("sbh_ai", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun load(): AiSettings = runCatching {
        prefs.getString("settings", null)?.let { json.decodeFromString<AiSettings>(it) }
    }.getOrNull() ?: AiSettings()

    fun save(settings: AiSettings) {
        prefs.edit().putString("settings", json.encodeToString(settings)).apply()
    }

    fun setAccessLevel(level: AiAccessLevel) {
        save(load().copy(accessLevel = level, permissions = defaultPermissions(level)))
    }

    fun can(permission: AiPermission): Boolean = load().enabled && permission in load().permissions
}

class AiActionDispatcher(private val context: Context) {
    private val manager = AiPermissionManager(context)
    private val prefs = context.getSharedPreferences("sbh_ai", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun dispatch(action: String, module: String, permission: AiPermission): AiAction {
        val settings = manager.load()
        val allowed = settings.enabled && permission in settings.permissions
        val detail = if (allowed) "Action autorisée par SBh AI Bridge." else "Action refusée par le gestionnaire de permissions."
        val result = AiAction(action = action, module = module, permission = permission, allowed = allowed, detail = detail)
        val old = runCatching { prefs.getString("actions", null)?.let { json.decodeFromString<List<AiAction>>(it) } ?: emptyList() }.getOrDefault(emptyList())
        prefs.edit().putString("actions", json.encodeToString((listOf(result) + old).take(100))).apply()
        return result
    }

    fun history(): List<AiAction> = runCatching {
        prefs.getString("actions", null)?.let { json.decodeFromString<List<AiAction>>(it) } ?: emptyList()
    }.getOrDefault(emptyList())
}
