package com.sbh.studio.workshop

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sbh.studio.data.BlockRepository
import com.sbh.studio.data.ItemRepository
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.generator.AdvancedPackEngine
import com.sbh.studio.ui.AgwColors
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkshopScreen(
    project: SbhProject?,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val repo = remember { WorkshopRepository(context) }
    val mobRepo = remember { MobRepository(context) }
    val itemRepo = remember { ItemRepository(context) }
    val blockRepo = remember { BlockRepository(context) }
    val engine = remember { AdvancedPackEngine(context) }

    var zone by remember { mutableStateOf(WorkshopZoneId.HUB) }
    var portals by remember { mutableStateOf(repo.loadPortals()) }
    var maps by remember { mutableStateOf(repo.loadMaps()) }
    var mobs by remember { mutableStateOf(mobRepo.loadAll()) }
    var items by remember { mutableStateOf(itemRepo.loadAll()) }
    var blocks by remember { mutableStateOf(blockRepo.loadAll()) }
    var reportText by remember { mutableStateOf("") }
    var lastExport by remember { mutableStateOf<File?>(null) }

    val projectId = project?.id ?: "global"
    fun projectMobs() = mobs.filter { it.projectId == projectId }
    fun projectItems() = items.filter { it.projectId == projectId }
    fun projectBlocks() = blocks.filter { it.projectId == projectId }
    fun projectPortals() = portals.filter { it.projectId == projectId }
    fun projectMaps() = maps.filter { it.projectId == projectId }

    fun savePortals(v: List<PortalBlueprint>) { portals = v; repo.savePortals(v) }
    fun saveMaps(v: List<MapBlueprint>) { maps = v; repo.saveMaps(v) }
    fun saveMobs(v: List<MobEntity>) { mobs = v; mobRepo.saveAll(v) }
    fun saveItems(v: List<SbhItem>) { items = v; itemRepo.saveAll(v) }
    fun saveBlocks(v: List<SbhBlock>) { blocks = v; blockRepo.saveAll(v) }

    fun importAgwPresets() {
        if (project == null) {
            onMessage("Ouvrez un projet d'abord")
            return
        }
        val pid = project.id
        val newMobs = engine.presetMobs(pid)
        val newItems = listOf(
            SbhItem(projectId = pid, name = "Cimeterre de fer", identifier = "agw:iron_scimitar", damage = 7, durability = 250),
            SbhItem(projectId = pid, name = "Lanterne suspendue", identifier = "agw:hanging_lantern", damage = 0, durability = 100)
        )
        val newBlocks = listOf(
            SbhBlock(projectId = pid, name = "Grès sombre", identifier = "agw:dark_sandstone", hardness = 1.5),
            SbhBlock(projectId = pid, name = "Pierre arabesque", identifier = "agw:arabesque_stone", hardness = 2.0),
            SbhBlock(projectId = pid, name = "Briques de nuit", identifier = "agw:night_bricks", hardness = 1.8),
            SbhBlock(projectId = pid, name = "Mosaïque sacrée", identifier = "agw:sacred_mosaic", hardness = 1.2)
        )
        saveMobs((mobs + newMobs).distinctBy { it.identifiant })
        saveItems((items + newItems).distinctBy { it.identifier })
        saveBlocks((blocks + newBlocks).distinctBy { it.identifier })
        val portal = PortalBlueprint(projectId = pid, name = "Portail Al-Zahra", identifier = "agw:portal_al_zahra", destinationHint = "الزهراء")
        val map = MapBlueprint(projectId = pid, name = "Cité Al-Zahra", sizeX = 48, sizeZ = 48, hasVillage = true, hasDungeon = true, hasOasis = true)
        savePortals((portals + portal).distinctBy { it.identifier })
        saveMaps((maps + map).distinctBy { it.name })
        onMessage("Monde AGW importé dans le projet")
        reportText = "✅ Import AGW : ${newMobs.size} mobs, ${newItems.size} items, ${newBlocks.size} blocs, 1 portail, 1 map"
        zone = WorkshopZoneId.EXPORT
    }

    fun runValidate() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet (Accueil → projet) puis revenez à l'atelier."
            return
        }
        val r = engine.validateAll(project, projectMobs(), projectItems(), projectBlocks(), projectPortals(), projectMaps())
        reportText = buildString {
            append(if (r.ok) "✅ Validation OK\n" else "❌ Erreurs\n")
            append("Contenu : ${projectMobs().size} mobs · ${projectItems().size} items · ${projectBlocks().size} blocs · ${projectPortals().size} portails · ${projectMaps().size} maps\n")
            r.errors.forEach { append("· $it\n") }
            r.warnings.forEach { append("⚠ $it\n") }
        }
    }

    fun runExport() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet d'abord."
            return
        }
        val r = engine.exportAdvanced(project, projectMobs(), projectItems(), projectBlocks(), projectPortals(), projectMaps())
        lastExport = r.file
        reportText = buildString {
            append(if (r.ok) "✅ Export réussi\n" else "❌ Échec export\n")
            append("Fichier : ${r.file?.name ?: "—"}\n")
            append("Contenu : ${projectMobs().size} mobs · ${projectItems().size} items · ${projectBlocks().size} blocs · ${projectPortals().size} portails · ${projectMaps().size} maps\n")
            r.errors.forEach { append("· $it\n") }
            r.warnings.forEach { append("⚠ $it\n") }
        }
        if (r.ok && r.file != null) {
            onMessage("Pack généré : ${r.file.name}")
            try {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", r.file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/mcaddon"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Partager le pack"))
            } catch (_: Exception) { }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Atelier · الورشة", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text(project?.name ?: "Aucun projet ouvert", style = MaterialTheme.typography.labelSmall, color = AgwColors.Sand)
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(WorkshopZoneId.entries.toList()) { z ->
                    FilterChip(
                        selected = zone == z,
                        onClick = { zone = z },
                        label = { Text(zoneLabel(z)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AgwColors.SacredGold,
                            selectedLabelColor = AgwColors.DeepNight
                        )
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            when (zone) {
                WorkshopZoneId.HUB -> HubZone(
                    onSelect = { zone = it },
                    mobCount = projectMobs().size,
                    portalCount = projectPortals().size,
                    mapCount = projectMaps().size,
                    itemCount = projectItems().size,
                    blockCount = projectBlocks().size,
                    onImportAgw = { importAgwPresets() }
                )
                WorkshopZoneId.MOBS -> MobZone(
                    mobs = projectMobs(),
                    onAddPresets = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val presets = engine.presetMobs(projectId)
                            saveMobs((mobs + presets).distinctBy { it.identifiant })
                            onMessage("Presets monstres ajoutés")
                        }
                    },
                    onAddCustom = { name, id, vie, dmg, vit ->
                        if (project == null) return@MobZone
                        val m = MobEntity(
                            projectId = projectId,
                            nom = name,
                            identifiant = id,
                            vie = vie,
                            degats = dmg,
                            vitesse = vit,
                            hostile = true
                        )
                        saveMobs(mobs + m)
                    },
                    onDelete = { m -> saveMobs(mobs - m) }
                )
                WorkshopZoneId.PORTALS -> PortalZone(
                    projectId = projectId,
                    portals = projectPortals(),
                    onSave = { p ->
                        savePortals(portals.filter { it.id != p.id } + p)
                    },
                    onDelete = { p -> savePortals(portals - p) }
                )
                WorkshopZoneId.MAPS -> MapZone(
                    projectId = projectId,
                    maps = projectMaps(),
                    onSave = { m -> saveMaps(maps.filter { it.id != m.id } + m) },
                    onDelete = { m -> saveMaps(maps - m) }
                )
                WorkshopZoneId.BLOCKS -> ContentListZone(
                    title = "Blocs du projet",
                    lines = projectBlocks().map { "${it.name} (${it.identifier})" },
                    emptyHint = "Ajoutez des blocs dans le détail du projet, ou importez AGW."
                )
                WorkshopZoneId.ITEMS -> ContentListZone(
                    title = "Items du projet",
                    lines = projectItems().map { "${it.name} (${it.identifier})" },
                    emptyHint = "Ajoutez des items dans le détail du projet, ou importez AGW."
                )
                WorkshopZoneId.EXPORT -> ExportZone(
                    reportText = reportText,
                    hasProject = project != null,
                    counts = "${projectMobs().size}m ${projectItems().size}i ${projectBlocks().size}b ${projectPortals().size}p ${projectMaps().size}maps",
                    onValidate = { runValidate() },
                    onExport = { runExport() },
                    onImportAgw = { importAgwPresets() }
                )
            }
        }
    }
}

@Composable
private fun HubZone(
    onSelect: (WorkshopZoneId) -> Unit,
    mobCount: Int,
    portalCount: Int,
    mapCount: Int,
    itemCount: Int,
    blockCount: Int,
    onImportAgw: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Minimap de l'atelier", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        MinimapCanvas(
            pins = listOf(
                MinimapPin("hub", "Hub", 50f, 50f, WorkshopZoneId.HUB),
                MinimapPin("mobs", "Mobs ($mobCount)", 18f, 28f, WorkshopZoneId.MOBS),
                MinimapPin("portals", "Portails ($portalCount)", 82f, 22f, WorkshopZoneId.PORTALS),
                MinimapPin("maps", "Maps ($mapCount)", 78f, 72f, WorkshopZoneId.MAPS),
                MinimapPin("items", "Items ($itemCount)", 22f, 75f, WorkshopZoneId.ITEMS),
                MinimapPin("blocks", "Blocs ($blockCount)", 40f, 88f, WorkshopZoneId.BLOCKS),
                MinimapPin("export", "Export", 55f, 88f, WorkshopZoneId.EXPORT)
            ),
            onPin = onSelect
        )
        Button(
            onClick = onImportAgw,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Importer le monde AGW dans ce projet") }
        Text(
            "Parcours : Import AGW → ajuster zones → Export. Tout le contenu projet part dans le .mcaddon.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun MinimapCanvas(pins: List<MinimapPin>, onPin: (WorkshopZoneId) -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(AgwColors.NightStone)
            .border(1.dp, AgwColors.DesertOchre.copy(0.5f), RoundedCornerShape(12.dp))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val step = size.minDimension / 8f
            var x = 0f
            while (x < size.width) {
                drawLine(Color(0x22C9A227), Offset(x, 0f), Offset(x, size.height), 1f)
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(Color(0x22C9A227), Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }
            val cx = size.width * 0.5f
            val cy = size.height * 0.5f
            listOf(
                Offset(size.width * 0.18f, size.height * 0.28f),
                Offset(size.width * 0.82f, size.height * 0.22f),
                Offset(size.width * 0.78f, size.height * 0.72f),
                Offset(size.width * 0.55f, size.height * 0.88f)
            ).forEach { drawLine(Color(0x66C9A227), Offset(cx, cy), it, 3f) }
        }
        pins.forEach { pin ->
            Column(
                Modifier
                    .offset(x = (pin.x / 100f * 280).dp, y = (pin.y / 100f * 160).dp)
                    .clickable { onPin(pin.zone) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(14.dp)
                        .background(AgwColors.SacredGold, CircleShape)
                        .border(1.dp, AgwColors.GoldSoft, CircleShape)
                )
                Text(pin.label, color = AgwColors.PaleMarble, fontSize = 9.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun MobZone(
    mobs: List<MobEntity>,
    onAddPresets: () -> Unit,
    onAddCustom: (name: String, id: String, vie: Int, dmg: Int, vit: Double) -> Unit,
    onDelete: (MobEntity) -> Unit
) {
    var name by remember { mutableStateOf("Créature") }
    var id by remember { mutableStateOf("agw:creature") }
    var vie by remember { mutableStateOf("20") }
    var dmg by remember { mutableStateOf("4") }
    var vit by remember { mutableStateOf("0.25") }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Création de monstres", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Button(
            onClick = onAddPresets,
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Presets AGW (4 créatures)") }

        Text("Nouveau monstre", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(vie, { vie = it }, label = { Text("PV") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(vit, { vit = it }, label = { Text("Vitesse") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Button(onClick = {
            onAddCustom(name, id, vie.toIntOrNull() ?: 20, dmg.toIntOrNull() ?: 4, vit.toDoubleOrNull() ?: 0.25)
        }, modifier = Modifier.fillMaxWidth()) { Text("Ajouter") }

        mobs.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(m.nom, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.identifiant} · PV ${m.vie} · DMG ${m.degats}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(m) }) { Text("X") }
                }
            }
        }
        if (mobs.isEmpty()) Text("Aucun monstre pour ce projet.", color = AgwColors.Sand)
    }
}

@Composable
private fun PortalZone(
    projectId: String,
    portals: List<PortalBlueprint>,
    onSave: (PortalBlueprint) -> Unit,
    onDelete: (PortalBlueprint) -> Unit
) {
    var name by remember { mutableStateOf("Portail Al-Zahra") }
    var identifier by remember { mutableStateOf("agw:portal_custom") }
    var width by remember { mutableStateOf("4") }
    var height by remember { mutableStateOf("5") }
    var frame by remember { mutableStateOf("agw:night_bricks") }
    var dest by remember { mutableStateOf("الزهراء · Al-Zahra") }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Portails Minecraft", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(width, { width = it }, label = { Text("Largeur") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(height, { height = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedTextField(frame, { frame = it }, label = { Text("Bloc cadre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(dest, { dest = it }, label = { Text("Destination") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                onSave(
                    PortalBlueprint(
                        name = name,
                        identifier = identifier,
                        width = width.toIntOrNull() ?: 4,
                        height = height.toIntOrNull() ?: 5,
                        frameBlock = frame,
                        destinationHint = dest,
                        projectId = projectId
                    )
                )
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Enregistrer le portail") }

        portals.forEach { p ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${p.identifier} · ${p.width}×${p.height}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        Text("→ ${p.destinationHint}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(p) }) { Text("X") }
                }
            }
        }
    }
}

@Composable
private fun MapZone(
    projectId: String,
    maps: List<MapBlueprint>,
    onSave: (MapBlueprint) -> Unit,
    onDelete: (MapBlueprint) -> Unit
) {
    var name by remember { mutableStateOf("Plan cité") }
    var sizeX by remember { mutableStateOf("32") }
    var sizeZ by remember { mutableStateOf("32") }
    var village by remember { mutableStateOf(true) }
    var dungeon by remember { mutableStateOf(true) }
    var oasis by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Plans de map", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom du plan") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(sizeX, { sizeX = it }, label = { Text("Taille X") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(sizeZ, { sizeZ = it }, label = { Text("Taille Z") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(village, { village = it }); Text("Village", color = AgwColors.PaleMarble)
            Checkbox(dungeon, { dungeon = it }); Text("Donjon", color = AgwColors.PaleMarble)
            Checkbox(oasis, { oasis = it }); Text("Oasis", color = AgwColors.PaleMarble)
        }
        Button(
            onClick = {
                onSave(
                    MapBlueprint(
                        name = name,
                        sizeX = sizeX.toIntOrNull() ?: 32,
                        sizeZ = sizeZ.toIntOrNull() ?: 32,
                        hasVillage = village,
                        hasDungeon = dungeon,
                        hasOasis = oasis,
                        projectId = projectId,
                        theme = "desert_gothic"
                    )
                )
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Enregistrer le plan") }

        maps.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.sizeX}×${m.sizeZ} · ${m.theme}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(m) }) { Text("X") }
                }
            }
        }
    }
}

@Composable
private fun ContentListZone(title: String, lines: List<String>, emptyHint: String) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text(title, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        if (lines.isEmpty()) Text(emptyHint, color = AgwColors.Sand)
        lines.forEach { line ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Text(line, Modifier.padding(12.dp), color = AgwColors.PaleMarble)
            }
        }
    }
}

@Composable
private fun ExportZone(
    reportText: String,
    hasProject: Boolean,
    counts: String,
    onValidate: () -> Unit,
    onExport: () -> Unit,
    onImportAgw: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Validation & export complet", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Projet : ${if (hasProject) "ouvert" else "aucun"} · $counts", color = AgwColors.Sand)
        if (!hasProject) {
            Text("Astuce : Accueil → ouvrez un projet → Atelier.", color = AgwColors.DesertOchre)
        }
        Button(onClick = onImportAgw, modifier = Modifier.fillMaxWidth()) { Text("Importer AGW puis exporter") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onValidate, modifier = Modifier.weight(1f)) { Text("Valider") }
            Button(
                onClick = onExport,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
            ) { Text("Exporter") }
        }
        if (reportText.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Text(reportText, Modifier.padding(12.dp), color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun zoneLabel(z: WorkshopZoneId) = when (z) {
    WorkshopZoneId.HUB -> "Hub"
    WorkshopZoneId.MOBS -> "Monstres"
    WorkshopZoneId.PORTALS -> "Portails"
    WorkshopZoneId.MAPS -> "Maps"
    WorkshopZoneId.BLOCKS -> "Blocs"
    WorkshopZoneId.ITEMS -> "Items"
    WorkshopZoneId.EXPORT -> "Export"
}
