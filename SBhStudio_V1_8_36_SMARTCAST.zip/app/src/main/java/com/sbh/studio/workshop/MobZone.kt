package com.sbh.studio.workshop

import android.content.Intent
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobShapeCatalog
import com.sbh.studio.data.SkinLibrary
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GoldPrimaryButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Zone Mobs améliorée — Atelier libre.
 *
 * L'utilisateur sélectionne un MOB / créature via le menu (bibliothèque de skins),
 * voit l'image + le nom en grand, peut afficher / appliquer la forme,
 * puis crée librement (stats, comportement, pouvoirs) et ajoute à la liste.
 * Aucune génération automatique forcée.
 */
@Composable
internal fun MobZone(
    projectId: String,
    mobs: List<MobEntity>,
    hasProject: Boolean,
    textures: List<TextureProject> = emptyList(),
    onAddPresets: () -> Unit,
    onSave: (MobEntity) -> Unit,
    onDelete: (MobEntity) -> Unit
) {
    val context = LocalContext.current

    // Nul tant qu'on crée un nouveau monstre ; rempli avec l'id du monstre en cours d'édition.
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }

    var name by rememberSaveable { mutableStateOf("Créature") }
    var id by rememberSaveable { mutableStateOf("agw:creature") }
    var vie by rememberSaveable { mutableStateOf("20") }
    var dmg by rememberSaveable { mutableStateOf("4") }
    var vit by rememberSaveable { mutableStateOf("0.25") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    // Comportement réel : ces booléens pilotent le JSON de comportement exporté
    // (minecraft:attack, poursuite du joueur, riposte aux dégâts subis).
    var hostile by rememberSaveable { mutableStateOf(true) }
    var poursuite by rememberSaveable { mutableStateOf(true) }
    var attaque by rememberSaveable { mutableStateOf(true) }
    var reactionDegats by rememberSaveable { mutableStateOf(true) }
    // Pouvoirs (buffs appliqués à l'entité côté PackGenerator).
    var pouvoirVitesse by rememberSaveable { mutableStateOf(false) }
    var pouvoirResistance by rememberSaveable { mutableStateOf(false) }
    var pouvoirInvisibilite by rememberSaveable { mutableStateOf(false) }
    var profilIA by rememberSaveable { mutableStateOf("guerrier") }
    var faction by rememberSaveable { mutableStateOf("neutre") }
    var detectionDistance by rememberSaveable { mutableStateOf("24") }
    var vitesseAttaque by rememberSaveable { mutableStateOf("1.0") }
    var cooldownAttaque by rememberSaveable { mutableStateOf("0") }
    var collisionLargeur by rememberSaveable { mutableStateOf("0.6") }
    var collisionHauteur by rememberSaveable { mutableStateOf("1.8") }
    var formeBase by rememberSaveable { mutableStateOf("humanoid") }
    var showSkinLibrary by rememberSaveable { mutableStateOf(true) } // ouvert par défaut pour la sélection
    var showFormeDetails by rememberSaveable { mutableStateOf(false) }

    // Skin actuellement sélectionné (pour l'aperçu grand)
    val selectedSkin = remember(tex) {
        val currentTex = tex
        if (currentTex?.startsWith("asset://") == true) {
            val path = currentTex.removePrefix("asset://")
            SkinLibrary.all(context).firstOrNull { it.assetPath == path }
        } else null
    }

    val selectedBitmap by produceState<ImageBitmap?>(initialValue = null, selectedSkin) {
        val skin = selectedSkin
        if (skin == null) {
            value = null
        } else {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    context.assets.open(skin.assetPath).use { stream ->
                        BitmapFactory.decodeStream(stream)?.asImageBitmap()
                    }
                }.onFailure {
                    android.util.Log.w("MobZone", "Aperçu skin illisible: ${skin.assetPath}", it)
                }.getOrNull()
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }

    fun resetForm() {
        editingId = null
        name = "Créature"; id = "agw:creature"; vie = "20"; dmg = "4"; vit = "0.25"; tex = null
        hostile = true; poursuite = true; attaque = true; reactionDegats = true
        pouvoirVitesse = false; pouvoirResistance = false; pouvoirInvisibilite = false
        profilIA = "guerrier"; faction = "neutre"; detectionDistance = "24"; vitesseAttaque = "1.0"
        cooldownAttaque = "0"; collisionLargeur = "0.6"; collisionHauteur = "1.8"
        formeBase = "humanoid"
        showFormeDetails = false
    }

    fun loadForEdit(m: MobEntity) {
        editingId = m.id
        name = m.nom; id = m.identifiant
        vie = m.vie.toString(); dmg = m.degats.toString(); vit = m.vitesse.toString()
        tex = m.textureUri
        hostile = m.hostile; poursuite = m.poursuite; attaque = m.attaque; reactionDegats = m.reactionDegats
        pouvoirVitesse = m.pouvoirVitesse; pouvoirResistance = m.pouvoirResistance; pouvoirInvisibilite = m.pouvoirInvisibilite
        profilIA = m.profilIA; faction = m.faction; detectionDistance = m.detectionDistance.toString()
        vitesseAttaque = m.vitesseAttaque.toString(); cooldownAttaque = m.cooldownAttaque.toString()
        collisionLargeur = m.collisionLargeur.toString(); collisionHauteur = m.collisionHauteur.toString()
        formeBase = m.formeBase
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Atelier Mobs — Création libre", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text(
            "Sélectionne un MOB / une créature, vois son image et son nom, applique sa forme, puis crée librement ce que tu veux.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        // ========== 1. SÉLECTION MOB (menu + aperçu image/nom) ==========
        Card(
            colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("1. Sélectionner un MOB / créature", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)

                OutlinedButton(
                    onClick = { showSkinLibrary = !showSkinLibrary },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (showSkinLibrary) "Masquer le menu de sélection"
                        else "Ouvrir le menu de sélection (bibliothèque)"
                    )
                }

                if (showSkinLibrary) {
                    SkinLibraryPicker(
                        selectedAssetPath = tex?.removePrefix("asset://"),
                        onSelect = { assetPath, recommendedForme ->
                            tex = "asset://$assetPath"
                            // Propose la forme adaptée
                            formeBase = recommendedForme
                            // Pré-remplit le nom si encore par défaut
                            val skin = SkinLibrary.all(context).firstOrNull { it.assetPath == assetPath }
                            if (skin != null && (name == "Créature" || name.isBlank())) {
                                name = skin.name
                                id = "agw:${skin.id}"
                            }
                        },
                        maxHeight = 220
                    )
                }

                // Aperçu grand : image + nom du MOB sélectionné
                if (selectedSkin != null) {
                    HorizontalDivider(color = AgwColors.Sand.copy(alpha = 0.3f))
                    Text("MOB sélectionné", fontWeight = FontWeight.SemiBold, color = AgwColors.SacredGold)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Grande image
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .background(AgwColors.DeepNight, RoundedCornerShape(8.dp))
                                .border(2.dp, AgwColors.SacredGold, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            val previewBmp = selectedBitmap
                            if (previewBmp != null) {
                                Image(
                                    bitmap = previewBmp,
                                    contentDescription = selectedSkin.name,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize().padding(4.dp)
                                )
                            } else {
                                Text("?", color = AgwColors.Sand, fontSize = 28.sp)
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(selectedSkin.name, fontWeight = FontWeight.Bold, color = AgwColors.PaleMarble, fontSize = 18.sp)
                            Text("Catégorie : ${selectedSkin.category}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                            Text("Forme recommandée : ${selectedSkin.formeBase}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    // Boutons forme
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                formeBase = selectedSkin.formeBase
                                showFormeDetails = true
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Appliquer la forme")
                        }
                        OutlinedButton(
                            onClick = { showFormeDetails = !showFormeDetails },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (showFormeDetails) "Masquer forme" else "Afficher la forme")
                        }
                    }

                    if (showFormeDetails) {
                        val shapeInfo = MobShapeCatalog.shapes.firstOrNull { it.id == formeBase }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = AgwColors.DeepNight),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text("Forme active : ${shapeInfo?.label ?: formeBase}", fontWeight = FontWeight.SemiBold, color = AgwColors.SacredGold)
                                Text("Géométrie Minecraft : ${shapeInfo?.geometryId ?: "geometry.humanoid"}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    "Cette forme utilise un squelette vanilla (pas de fichier 3D à fournir). " +
                                    "Tu peux la changer manuellement ci-dessous si tu préfères.",
                                    color = AgwColors.Sand,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                } else if (tex != null) {
                    Text("Texture sélectionnée (externe ou studio)", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // ========== 2. CRÉATION LIBRE (stats, forme manuelle, comportement) ==========
        Text("2. Création libre (à ta guise)", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text(
            if (editingId == null) "Nouveau monstre" else "Modification : ${name.ifBlank { "monstre" }}",
            fontWeight = FontWeight.SemiBold,
            color = AgwColors.GoldSoft
        )
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Text("Forme de base (modifiable librement)", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text(
            "Squelettes déjà intégrés à Minecraft. Change-la comme tu veux.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            MobShapeCatalog.shapes.forEach { shape ->
                FilterChip(selected = formeBase == shape.id, onClick = { formeBase = shape.id }, label = { Text(shape.label) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(vie, { vie = it }, label = { Text("PV") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(vit, { vit = it }, label = { Text("Vitesse") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            val currentTex = tex
            Text(
                when {
                    currentTex == null -> "Fichier image externe"
                    currentTex.startsWith("sbhtex://") -> "Texture Studio liée ✓"
                    currentTex.startsWith("asset://") -> "Skin bibliothèque ✓"
                    else -> "Fichier externe ✓"
                }
            )
        }
        StudioTexturePicker(
            textures = textures,
            selectedUri = tex,
            onSelect = { tex = it },
            preferredFormats = listOf("ITEM_16", "BLOCK_16")
        )

        Text("Comportement", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text(
            "Coche ce que tu veux. Rien n'est forcé.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(hostile, { v -> hostile = v; if (v) { poursuite = true; attaque = true } })
            Text("Hostile", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(poursuite, { poursuite = it }); Text("Poursuit le joueur", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(attaque, { attaque = it }); Text("Attaque au contact", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(reactionDegats, { reactionDegats = it }); Text("Riposte quand on l'attaque", color = AgwColors.PaleMarble)
        }

        Text("IA avancée", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text("Profil", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("passif", "garde", "guerrier", "archer", "boss").forEach { option ->
                FilterChip(selected = profilIA == option, onClick = { profilIA = option }, label = { Text(option) })
            }
        }
        OutlinedTextField(faction, { faction = it.lowercase().replace(' ', '_') }, label = { Text("Faction") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(detectionDistance, { detectionDistance = it }, label = { Text("Détection") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(vitesseAttaque, { vitesseAttaque = it }, label = { Text("Vitesse attaque") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(cooldownAttaque, { cooldownAttaque = it }, label = { Text("Recharge (s)") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Text("Collision / taille", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(collisionLargeur, { collisionLargeur = it }, label = { Text("Largeur") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(collisionHauteur, { collisionHauteur = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
        }

        Text("Pouvoirs", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirVitesse, { pouvoirVitesse = it }); Text("Vitesse (+50%)", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirResistance, { pouvoirResistance = it }); Text("Résistance", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirInvisibilite, { pouvoirInvisibilite = it }); Text("Invisibilité", color = AgwColors.PaleMarble)
        }

        // ========== 3. AJOUTER À LA LISTE ==========
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onSave(
                        MobEntity(
                            id = editingId ?: java.util.UUID.randomUUID().toString(),
                            projectId = projectId,
                            nom = name,
                            identifiant = id,
                            vie = vie.toIntOrNull() ?: 20,
                            degats = dmg.toIntOrNull() ?: 4,
                            vitesse = vit.toDoubleOrNull() ?: 0.25,
                            hostile = hostile,
                            poursuite = poursuite,
                            attaque = attaque,
                            reactionDegats = reactionDegats,
                            pouvoirVitesse = pouvoirVitesse,
                            pouvoirResistance = pouvoirResistance,
                            pouvoirInvisibilite = pouvoirInvisibilite,
                            profilIA = profilIA,
                            faction = faction.ifBlank { "neutre" },
                            detectionDistance = detectionDistance.replace(',', '.').toDoubleOrNull()?.coerceIn(1.0, 128.0) ?: 24.0,
                            vitesseAttaque = vitesseAttaque.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 4.0) ?: 1.0,
                            cooldownAttaque = cooldownAttaque.replace(',', '.').toDoubleOrNull()?.coerceIn(0.0, 60.0) ?: 0.0,
                            collisionLargeur = collisionLargeur.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 4.0) ?: 0.6,
                            collisionHauteur = collisionHauteur.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 8.0) ?: 1.8,
                            textureUri = tex,
                            formeBase = formeBase
                        )
                    )
                    resetForm()
                },
                modifier = Modifier.weight(1f),
                enabled = hasProject
            ) { Text(if (editingId == null) "Ajouter à la liste" else "Enregistrer les modifications") }
            if (editingId != null) {
                OutlinedButton({ resetForm() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
            }
        }

        // Presets optionnels (pas forcés)
        GoldPrimaryButton("Presets AGW optionnels (4 créatures)", onAddPresets)

        // ========== LISTE DE TRAVAIL ==========
        Text("Liste de travail (${mobs.size})", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        mobs.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(m.nom, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.identifiant} · PV ${m.vie} · DMG ${m.degats}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        val tags = buildList {
                            if (m.hostile) add("hostile")
                            if (m.poursuite) add("poursuite")
                            if (m.attaque) add("attaque")
                            if (m.pouvoirVitesse) add("+vitesse")
                            if (m.pouvoirResistance) add("+résistance")
                            if (m.pouvoirInvisibilite) add("+invisibilité")
                            if (m.faction != "neutre") add("faction:${m.faction}")
                            add("IA:${m.profilIA}")
                            if (m.formeBase != "humanoid") add("forme:${m.formeBase}")
                            if (m.textureUri?.startsWith("asset://") == true) add("skin:biblio")
                        }
                        if (tags.isNotEmpty()) {
                            Text(tags.joinToString(" · "), color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    TextButton({ loadForEdit(m) }) { Text("✎") }
                    TextButton({ if (editingId == m.id) resetForm(); onDelete(m) }) { Text("X") }
                }
            }
        }
        if (mobs.isEmpty()) Text("Aucun monstre dans la liste. Crée-en un ci-dessus.", color = AgwColors.Sand)
    }
}
