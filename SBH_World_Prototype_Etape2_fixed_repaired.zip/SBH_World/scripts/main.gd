extends Node3D
## Studio catalogue → monde → placement ; collisions gérées joueur / terrain / marqueurs.

var bridge: StudioBridge
var world: SBHWorld
var player: SBHPlayer
var touch_controls: TouchControls
var docs_panel: DocumentPanel


func _ready() -> void:
	bridge = StudioBridge.new()
	bridge.bootstrap(true)

	world = SBHWorld.new()
	world.name = "World"
	add_child(world)
	await get_tree().process_frame

	if SaveManager.has_save():
		SaveManager.load_world(world)

	if bridge.has_studio_link():
		bridge.place_into_world(world)

	bridge.print_log()

	var player_scene := load("res://scenes/Player.tscn")
	player = player_scene.instantiate()
	player.position = Vector3(8, 5, 8)
	add_child(player)

	touch_controls = TouchControls.new()
	add_child(touch_controls)
	touch_controls.break_pressed.connect(break_block)
	touch_controls.place_pressed.connect(place_block)
	touch_controls.jump_pressed.connect(func(): player.velocity.y = player.jump_velocity)
	touch_controls.look_changed.connect(player.look_delta)

	docs_panel = DocumentPanel.new()
	docs_panel.name = "DocumentPanel"
	add_child(docs_panel)
	docs_panel.apply_requested.connect(_on_docs_apply)
	docs_panel.panel_toggled.connect(_on_docs_toggled)


func get_target_block() -> Dictionary:
	var ray: RayCast3D = player.get_node("Camera3D/RayCast3D")
	ray.collision_mask = CollisionLayers.WORLD
	ray.force_raycast_update()
	if not ray.is_colliding():
		return {}
	var point: Vector3 = ray.get_collision_point()
	var normal: Vector3 = ray.get_collision_normal()
	var break_pos := Vector3i(floor(point - normal * 0.01))
	var place_pos := Vector3i(floor(point + normal * 0.01))
	return {"break": break_pos, "place": place_pos}


func break_block() -> void:
	var target := get_target_block()
	if target.is_empty():
		return
	var pos: Vector3i = target.break
	if world.get_block(pos) == BlockTypes.Type.AIR:
		return
	world.set_block(pos, BlockTypes.Type.AIR)
	SaveManager.save_world(world)


func place_block() -> void:
	var target := get_target_block()
	if target.is_empty():
		return
	var pos: Vector3i = target.place
	# Ne pas placer dans un bloc déjà solide ni dans le corps du joueur
	if not world.can_place_block(pos, player.body_aabb()):
		return
	world.set_block(pos, BlockTypes.Type.GRASS)
	SaveManager.save_world(world)


## Panneau Documents ouvert : on masque les boutons de jeu et on coupe la caméra tactile.
func _on_docs_toggled(open: bool) -> void:
	touch_controls.visible = not open
	touch_controls.set_process_unhandled_input(not open)


## Documents modifiés / importés : on relance le pont Studio (catalogue puis placement).
func _on_docs_apply() -> void:
	bridge.bootstrap(true)
	if bridge.has_studio_link():
		bridge.place_into_world(world)
	bridge.print_log()
	docs_panel.show_status("\n".join(bridge.log_lines))


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		if world:
			SaveManager.save_world(world)
		get_tree().quit()
