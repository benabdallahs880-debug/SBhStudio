#!/usr/bin/env python3
"""Static validation for SBh Studio. No Android SDK/network required."""
from __future__ import annotations
import json, re, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors=[]; warnings=[]

def err(m): errors.append(m)
def warn(m): warnings.append(m)

def read(rel): return (ROOT/rel).read_text(encoding='utf-8')

# Version consistency
try:
    root=json.loads(read('version.json'))
    asset=json.loads(read('app/src/main/assets/version.json'))
    grad=read('app/build.gradle.kts')
    if root['versionName'] != asset['versionName'] or root['versionCode'] != asset['versionCode']:
        err('version.json racine et assets/version.json divergent')
    dynamic_ok = 'sbhVersionCode' in grad and 'sbhVersionName' in grad and 'version.json' in grad
    static_ok = f'versionCode = {root["versionCode"]}' in grad and f'versionName = "{root["versionName"]}"' in grad
    if not (dynamic_ok or static_ok):
        err('version Gradle non alignée ou non pilotée par version.json')
    if root['versionCode'] < 1: err('versionCode invalide')
except Exception as e: err(f'Erreur version: {e}')

# JSON assets
for p in (ROOT/'app/src/main/assets').rglob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: err(f'JSON invalide: {p.relative_to(ROOT)}: {e}')

# Security regression checks
for p in (ROOT/'app/src/main').rglob('*.kt'):
    s=p.read_text(encoding='utf-8')
    if 'allowUniversalAccessFromFileURLs' in s or 'allowFileAccessFromFileURLs' in s:
        err(f'WebView file access dangereux retrouvé: {p.relative_to(ROOT)}')
for p in (ROOT/'.github').rglob('*') if (ROOT/'.github').exists() else []:
    if p.is_file() and p.name.endswith(('.yml','.yaml')):
        s=p.read_text(encoding='utf-8')
        if 'debug.keystore' in s: warn(f'Référence debug.keystore dans CI: {p.relative_to(ROOT)}')
for p in ROOT.rglob('*'):
    if p.is_file() and p.name.lower() in {'debug.keystore'}:
        err(f"Clé debug versionnée/localisée dans l'arbre: {p.relative_to(ROOT)}")

# Manifest / FileProvider
manifest=read('app/src/main/AndroidManifest.xml')
if 'android:authorities="${applicationId}.fileprovider"' not in manifest:
    err('FileProvider authority n\'utilise pas ${applicationId}')
if 'android:exported="false"' not in manifest:
    err('FileProvider doit être non exporté')

# Pack generator invariants
pg=read('app/src/main/java/com/sbh/studio/generator/PackGenerator.kt')
if 'java.util.UUID.randomUUID()' in pg and 'loadPackIds' not in pg:
    err('UUID de pack potentiellement régénérés à chaque export')
if '.mcpack' not in pg or '$bpName.mcpack' not in pg or '$rpName.mcpack' not in pg:
    err('.mcaddon ne contient pas explicitement BP/RP en .mcpack')
if 'dependencies' not in pg:
    err('Dépendance RP -> BP absente du manifest')

# Update invariants
# Ces contrôles vérifient la PRÉSENCE des trois garde-fous de sécurité
# (paquet identique / signature identique / version strictement supérieure)
# par motif structurel plutôt que par nom de variable exact, pour survivre
# à un refactor (renommage de variables) sans donner de faux négatif.
um=read('app/src/main/java/com/sbh/studio/data/UpdateManager.kt')

# 1) Comparaison du nom de paquet avec celui de l'app installée.
if not re.search(r'!=\s*context\.packageName', um):
    err('Vérification update absente : comparaison du packageName avec context.packageName')

# 2) Comparaison de deux jeux d'empreintes de signature (archive vs installée).
#    signerDigests(...) doit être appelé au moins deux fois, et le résultat
#    comparé (== ou !=) quelque part.
if len(re.findall(r'signerDigests\(', um)) < 2:
    err('Vérification update absente : empreintes de signature (archive vs installée) non calculées deux fois')
elif not re.search(r'\w*[Dd]igests?\w*\s*(==|!=)\s*\w*[Dd]igests?\w*', um):
    err('Vérification update absente : comparaison des empreintes de signature (archiveDigests vs currentDigests)')

# 3) Comparaison stricte du versionCode distant vs celui installé.
if not re.search(r'\b\w*[Cc]ode\b\s*>\s*\b\w*[Cc]ode\b', um):
    err('Vérification update absente : versionCode distant > versionCode installé')

if 'sha256(input' not in um: warn('Vérification SHA-256 runtime absente')

# CI signing
ci=read('.github/workflows/build-apk.yml')
release_ci = read('.github/workflows/release.yml') if (ROOT/'.github/workflows/release.yml').exists() else ''
for needle in ['SBH_KEYSTORE_B64','SBH_KEYSTORE_PASSWORD','SBH_KEY_ALIAS','SBH_KEY_PASSWORD']:
    if needle not in release_ci: err(f'Secret CI release manquant: {needle}')
if 'debug.keystore' in ci or 'debug.keystore' in release_ci: err('CI utilise debug.keystore')
if 'version.json' not in ci or 'version.json' not in release_ci:
    err('CI ne lit pas la version depuis version.json')

print('SBh Studio static validation')
print(f'Errors: {len(errors)} | Warnings: {len(warnings)}')
for x in errors: print('ERROR:', x)
for x in warnings: print('WARN :', x)
if errors: sys.exit(1)
