# SBh Map Studio — Objets 3D (.glb)

## Contenu de cette étape

Première brique de la couche "entités de scène" (objets/personnages/véhicules),
indépendante de la grille de voxels existante.

### Éditeur 3D (mapstudio.html)
- Nouvel outil **Objets** dans la barre d'outils.
- Chargeur `.glb` maison (sans dépendance externe, pas de CDN) : géométrie
  POSITION/NORMAL/TEXCOORD_0 + indices, matériaux pbrMetallicRoughness
  (couleur + texture de base), hiérarchie de nœuds.
  **Non pris en charge pour l'instant** : animations, squelettes/skinning,
  Draco, KTX2, glTF externe (.gltf + .bin séparés — .glb autonome uniquement).
- Panneau "Objets 3D" (droite) : import, liste des objets de la scène,
  rotation (Y), échelle, dupliquer, supprimer.
- Sélection/déplacement à la souris (clic = sélectionner, glisser = déplacer
  sur le terrain).
- Ajout d'un éclairage de base (ambiant + directionnel) pour ces objets ;
  les blocs voxels restent inchangés (matériau non éclairé).

### Limites connues
- **Non persistant** : les objets importés ne sont pas encore sauvegardés
  dans le fichier de map (`serializeWorld`/export) — travail de la
  prochaine étape (modèle de données `Objet/Personnage/Véhicule` +
  sauvegarde).
- Pas encore de rotation/échelle par gizmo (TransformControls) — sliders
  provisoires en attendant.
- Un seul buffer binaire par `.glb` est supporté (cas standard des exports
  Blender/Kenney/Quaternius).

## Fichiers modifiés
- `app/src/main/assets/mapstudio.html`
