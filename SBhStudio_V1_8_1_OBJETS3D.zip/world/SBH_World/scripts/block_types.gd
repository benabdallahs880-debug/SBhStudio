class_name BlockTypes

enum Type {
	AIR,
	GRASS,
	DIRT,
	STONE
}

static func is_solid(id: int) -> bool:
	return id != Type.AIR

static func color(id: int) -> Color:
	match id:
		Type.GRASS: return Color(0.28, 0.62, 0.20)
		Type.DIRT: return Color(0.45, 0.28, 0.13)
		Type.STONE: return Color(0.42, 0.42, 0.42)
		_: return Color.WHITE
