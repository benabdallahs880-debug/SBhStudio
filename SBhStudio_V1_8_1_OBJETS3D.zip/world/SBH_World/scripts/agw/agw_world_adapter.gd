class_name AGWWorldAdapter
extends RefCounted
## Projection du World Core vers le runtime Godot.
## Les blocs restent sous la responsabilité de PlacementAdapter.

var last_message: String = ""
var markers_root: Node3D = null

func apply_to_world(core: AGWWorldCore, world: SBHWorld) -> bool:
	if core == null or core.state.is_empty():
		last_message = "AGW World Core vide — projection annulée"
		return false
	if world == null or not is_instance_valid(world):
		last_message = "Monde invalide"
		return false

	world.set_meta("agw_world_id", core.world_id())
	world.set_meta("agw_world_name", core.world_name())
	world.set_meta("agw_world_core_schema", AGWWorldCore.SCHEMA)
	world.set_meta("agw_world_core_summary", core.summary())

	var old := world.get_node_or_null("AGWWorldCore")
	if old:
		old.queue_free()
	markers_root = Node3D.new()
	markers_root.name = "AGWWorldCore"
	world.add_child(markers_root)

	var projected := 0
	for entry in core.nodes.values():
		if typeof(entry) != TYPE_DICTIONARY:
			continue
		var node_type := str(entry.get("type", ""))
		if node_type in ["map", "portal", "building", "location", "npc"]:
			var marker := _make_marker(entry)
			if marker:
				markers_root.add_child(marker)
				projected += 1

	last_message = "AGW → World OK — %s — marqueurs=%d" % [core.summary(), projected]
	return true

func _make_marker(entry: Dictionary) -> Node3D:
	var marker := Node3D.new()
	marker.name = str(entry.get("id", "agw_node")).replace(":", "_")
	marker.position = Vector3(float(entry.get("x", 0)) + 0.5, float(entry.get("y", 64)) + 0.5, float(entry.get("z", 0)) + 0.5)
	marker.set_meta("agw_id", str(entry.get("id", "")))
	marker.set_meta("agw_type", str(entry.get("type", "")))
	marker.set_meta("agw_name", str(entry.get("name", "")))
	marker.set_meta("agw_source", str(entry.get("source", "")))

	var mesh_instance := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.22
	mesh.height = 0.44
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = _color_for_type(str(entry.get("type", "")))
	material.emission_enabled = true
	material.emission = material.albedo_color * 0.25
	mesh_instance.material_override = material
	marker.add_child(mesh_instance)
	return marker

func _color_for_type(node_type: String) -> Color:
	match node_type:
		"map": return Color(0.85, 0.65, 0.20)
		"portal": return Color(0.35, 0.65, 1.0)
		"building": return Color(0.75, 0.45, 0.25)
		"location": return Color(0.45, 0.85, 0.45)
		"npc": return Color(0.80, 0.35, 0.85)
		_: return Color(0.70, 0.70, 0.70)
