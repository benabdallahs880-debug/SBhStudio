class_name AGWWorldCore
extends RefCounted
## Source de vérité AGW partagé avec SBh Studio / Map Atelier / Map Studio.
## Le runtime Godot lit un export JSON versionné ; il ne modifie pas le contrat directement.

const SCHEMA := "sbh.agw.worldcore.v1"
const RES_PATH := "res://content/agw_world_core/agw_world_core.json"
const USER_PATH := "user://agw_world_core/agw_world_core.json"

var state: Dictionary = {}
var nodes: Dictionary = {}
var last_message: String = ""

func load_core() -> bool:
	state = {}
	nodes = {}
	var path := USER_PATH if FileAccess.file_exists(USER_PATH) else RES_PATH
	if not FileAccess.file_exists(path):
		last_message = "AGW World Core introuvable"
		return false
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		last_message = "Impossible d'ouvrir le World Core"
		return false
	var parsed = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		last_message = "World Core JSON invalide"
		return false
	if str(parsed.get("schema", "")) != SCHEMA:
		last_message = "Schéma AGW incompatible: %s" % str(parsed.get("schema", ""))
		return false
	state = parsed
	for entry in state.get("nodes", []):
		if typeof(entry) != TYPE_DICTIONARY:
			continue
		var id := str(entry.get("id", ""))
		if not id.is_empty():
			nodes[id] = entry.duplicate(true)
	last_message = "AGW World Core chargé — monde=%s nœuds=%d" % [str(state.get("worldName", "Al-Zahra")), nodes.size()]
	return true

func world_id() -> String:
	return str(state.get("worldId", "agw:al_zahra"))

func world_name() -> String:
	return str(state.get("worldName", "Al-Zahra"))

func nodes_of_type(node_type: String) -> Array:
	var result: Array = []
	for entry in nodes.values():
		if str(entry.get("type", "")) == node_type:
			result.append(entry)
	return result

func summary() -> String:
	if state.is_empty():
		return "AGW World Core non chargé"
	return "%s · %d nœuds · factions=%d régions=%d cartes=%d portails=%d bâtiments=%d PNJ=%d" % [
		world_name(), nodes.size(), nodes_of_type("faction").size(), nodes_of_type("region").size(),
		nodes_of_type("map").size(), nodes_of_type("portal").size(), nodes_of_type("building").size(),
		nodes_of_type("npc").size()
	]
