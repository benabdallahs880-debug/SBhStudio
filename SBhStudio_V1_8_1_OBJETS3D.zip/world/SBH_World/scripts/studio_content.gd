class_name StudioContent
extends RefCounted
## Couche d'import contenu SBh Studio — séparée du monde de jeu (SBHWorld).
##
## Responsabilités :
## - lire sbh/protocol.json (même schéma que Studio)
## - valider la compatibilité SBh World
## - conserver les métadonnées d'import
##
## Ne modifie PAS les blocs / chunks. L'application de contenu (mobs, items…)
## viendra dans une étape ultérieure via des adaptateurs dédiés.

enum Status {
	NONE,
	LOADED,
	INCOMPATIBLE,
	ERROR
}

## Dossier utilisateur où déposer un pack / protocole à importer.
const USER_IMPORT_DIR := "user://studio_import/"
const USER_PROTOCOL_PATH := USER_IMPORT_DIR + SBhProtocol.PACK_REL_PATH
## Exemple embarqué dans le projet (démo).
const EXAMPLE_PROTOCOL_PATH := "res://content/studio_example/sbh/protocol.json"

var status: int = Status.NONE
var protocol: SBhProtocol = null
var source_path: String = ""
var message: String = "Aucun contenu Studio importé"


func has_content() -> bool:
	return status == Status.LOADED and protocol != null and protocol.valid


func clear() -> void:
	status = Status.NONE
	protocol = null
	source_path = ""
	message = "Aucun contenu Studio importé"


## Charge un fichier protocol.json explicite.
func load_protocol_file(path: String) -> bool:
	var p := SBhProtocol.from_file(path)
	source_path = path
	protocol = p
	if not p.valid:
		status = Status.INCOMPATIBLE if p.error_message.find("compatible") >= 0 else Status.ERROR
		message = p.error_message
		return false
	status = Status.LOADED
	message = p.summary()
	return true


## Cherche user://studio_import/sbh/protocol.json (dépôt manuel / futur partage Android).
func try_load_user_import() -> bool:
	if FileAccess.file_exists(USER_PROTOCOL_PATH):
		return load_protocol_file(USER_PROTOCOL_PATH)
	return false


## Charge l'exemple embarqué (démo Étape 1).
func try_load_example() -> bool:
	if FileAccess.file_exists(EXAMPLE_PROTOCOL_PATH):
		return load_protocol_file(EXAMPLE_PROTOCOL_PATH)
	return false


## Point d'entrée unique : user import prioritaire, sinon exemple optionnel.
func bootstrap(load_example_if_empty: bool = true) -> void:
	clear()
	_ensure_user_import_dir()
	if try_load_user_import():
		return
	if load_example_if_empty:
		try_load_example()


func _ensure_user_import_dir() -> void:
	var dir := DirAccess.open("user://")
	if dir and not dir.dir_exists("studio_import"):
		dir.make_dir("studio_import")
	var dir2 := DirAccess.open(USER_IMPORT_DIR)
	if dir2 and not dir2.dir_exists("sbh"):
		dir2.make_dir("sbh")


func debug_line() -> String:
	match status:
		Status.NONE:
			return "[Studio] aucun import"
		Status.LOADED:
			return "[Studio] chargé — %s" % message
		Status.INCOMPATIBLE:
			return "[Studio] incompatible — %s" % message
		Status.ERROR:
			return "[Studio] erreur — %s" % message
		_:
			return "[Studio] état inconnu"
