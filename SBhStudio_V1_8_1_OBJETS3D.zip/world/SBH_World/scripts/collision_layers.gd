class_name CollisionLayers
extends RefCounted
## Calques de collision SBH World (bits Godot 1-based dans l'éditeur = 1<< (n-1)).

const WORLD := 1		# bit 0 — terrain / chunks
const PLAYER := 2		# bit 1 — joueur
const MARKERS := 4		# bit 2 — marqueurs Studio (mobs)
const PROPS := 8		# bit 3 — réservé

static func setup_world_body(body: CollisionObject3D) -> void:
	body.collision_layer = WORLD
	body.collision_mask = 0  # statique : ne cherche pas les collisions, les subit


static func setup_player(body: CollisionObject3D) -> void:
	body.collision_layer = PLAYER
	body.collision_mask = WORLD | MARKERS | PROPS


static func setup_marker(body: CollisionObject3D) -> void:
	body.collision_layer = MARKERS
	body.collision_mask = 0
