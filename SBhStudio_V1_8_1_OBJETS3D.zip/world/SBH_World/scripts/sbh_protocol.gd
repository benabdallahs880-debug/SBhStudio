class_name SBhProtocol
extends RefCounted
## Même schéma que SBh Studio : sbh/protocol.json (SBhProtocolPayload).
## Ce n'est PAS une preuve d'import Minecraft ni une modification du monde de jeu.

const NAME := "SBH"
const VERSION := "1.0"
const PACK_REL_PATH := "sbh/protocol.json"

var protocol: String = NAME
var protocol_version: String = VERSION
var export_id: String = ""
var project_id: String = ""
var project_name: String = ""
var project_version: String = ""
var project_type: String = ""
var studio_version: String = ""
var generated_at_ms: int = 0
var target: String = ""
var compatible_targets: Array = []

var valid: bool = false
var error_message: String = ""


static func from_dictionary(data: Dictionary) -> SBhProtocol:
	var p := SBhProtocol.new()
	if data.is_empty():
		p.error_message = "Dictionnaire vide"
		return p

	p.protocol = str(data.get("protocol", ""))
	p.protocol_version = str(data.get("protocolVersion", data.get("protocol_version", "")))
	p.export_id = str(data.get("exportId", data.get("export_id", "")))
	p.project_id = str(data.get("projectId", data.get("project_id", "")))
	p.project_name = str(data.get("projectName", data.get("project_name", "")))
	p.project_version = str(data.get("projectVersion", data.get("project_version", "")))
	p.project_type = str(data.get("projectType", data.get("project_type", "")))
	p.studio_version = str(data.get("studioVersion", data.get("studio_version", "")))
	p.generated_at_ms = int(data.get("generatedAtMs", data.get("generated_at_ms", 0)))
	p.target = str(data.get("target", ""))
	var ct = data.get("compatibleTargets", data.get("compatible_targets", []))
	if typeof(ct) == TYPE_ARRAY:
		p.compatible_targets = ct.duplicate()
	else:
		p.compatible_targets = []

	p.valid = p._validate()
	return p


static func from_json_text(text: String) -> SBhProtocol:
	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		var p := SBhProtocol.new()
		p.error_message = "JSON invalide (objet attendu)"
		return p
	return from_dictionary(parsed)


static func from_file(path: String) -> SBhProtocol:
	if not FileAccess.file_exists(path):
		var p := SBhProtocol.new()
		p.error_message = "Fichier introuvable: %s" % path
		return p
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		var p2 := SBhProtocol.new()
		p2.error_message = "Lecture impossible: %s" % path
		return p2
	return from_json_text(f.get_as_text())


func _validate() -> bool:
	if protocol != NAME:
		error_message = "protocol attendu '%s', reçu '%s'" % [NAME, protocol]
		return false
	if protocol_version.is_empty():
		error_message = "protocolVersion manquant"
		return false
	if export_id.is_empty():
		error_message = "exportId manquant"
		return false
	if project_id.is_empty():
		error_message = "projectId manquant"
		return false
	if project_name.is_empty():
		error_message = "projectName manquant"
		return false
	# SBh World n'accepte que si sbh_world est listé OU target explicite
	var ok_target := target == "sbh_world"
	for t in compatible_targets:
		if str(t) == "sbh_world":
			ok_target = true
			break
	if not ok_target:
		error_message = "Pack non compatible SBh World (compatibleTargets sans sbh_world)"
		return false
	error_message = ""
	return true


func to_dictionary() -> Dictionary:
	return {
		"protocol": protocol,
		"protocolVersion": protocol_version,
		"exportId": export_id,
		"projectId": project_id,
		"projectName": project_name,
		"projectVersion": project_version,
		"projectType": project_type,
		"studioVersion": studio_version,
		"generatedAtMs": generated_at_ms,
		"target": target,
		"compatibleTargets": compatible_targets
	}


func summary() -> String:
	if not valid:
		return "Protocole invalide: %s" % error_message
	return "SBH %s | %s | export=%s | projet=%s (%s)" % [
		protocol_version, project_name, export_id, project_id, project_version
	]
