class_name DocumentPanel
extends CanvasLayer
## Panneau « Documents » : prendre un document dans le stockage, le lire, le modifier, l'adapter.
##
## Ne touche jamais au monde : « Appliquer au monde » émet apply_requested et main.gd relance
## StudioBridge (bootstrap + place_into_world), seul chemin d'écriture voxels Studio.

signal apply_requested
signal panel_toggled(open: bool)

## Correspond aux entrées du sélecteur de type (index 0 = détection automatique).
const KIND_CHOICES := ["", "blocks", "items", "mobs", "placements", "protocol"]
const KIND_LABELS_UI := ["Type : auto", "Blocs", "Objets", "Mobs", "Placements", "Protocole"]

var _toggle_button: Button
var _panel: PanelContainer
var _list: ItemList
var _editor: TextEdit
var _status: TextEdit
var _kind_option: OptionButton
var _picker: FileDialog

var _docs: Array = []
var _current_path := ""
var _loaded_text := ""


func _ready() -> void:
	layer = 10
	_build_ui()
	refresh_list()
	_set_status("Importer… : choisis un ou plusieurs fichiers (.json, .zip, .mcaddon, .txt).\nTu peux ensuite les lire, les modifier, les adapter, puis les appliquer au monde.")


func is_open() -> bool:
	return _panel != null and _panel.visible


func show_status(message: String) -> void:
	_set_status(message)


# ---------------------------------------------------------------- interface

func _build_ui() -> void:
	var hud := Control.new()
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_toggle_button = _make_button("DOCS", _on_toggle_pressed)
	_toggle_button.position = Vector2(20, 20)
	_toggle_button.size = Vector2(120, 60)
	hud.add_child(_toggle_button)

	_panel = PanelContainer.new()
	_panel.visible = false
	hud.add_child(_panel)
	_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_panel.offset_left = 40
	_panel.offset_top = 30
	_panel.offset_right = -40
	_panel.offset_bottom = -30

	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 12)
	_panel.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var head := HBoxContainer.new()
	vbox.add_child(head)
	var title := Label.new()
	title.text = "Documents Studio"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	head.add_child(_make_button("Fermer", _on_toggle_pressed))

	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 8)
	vbox.add_child(bar)
	bar.add_child(_make_button("Importer…", _on_import_pressed))
	_kind_option = OptionButton.new()
	_kind_option.custom_minimum_size = Vector2(0, 56)
	for label in KIND_LABELS_UI:
		_kind_option.add_item(label)
	bar.add_child(_kind_option)
	bar.add_child(_make_button("Adapter", _on_adapt_pressed))
	bar.add_child(_make_button("Enregistrer", _on_save_pressed))
	bar.add_child(_make_button("Appliquer au monde", _on_apply_pressed))

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 8)
	vbox.add_child(body)

	_list = ItemList.new()
	_list.custom_minimum_size = Vector2(300, 0)
	_list.item_selected.connect(_on_item_selected)
	body.add_child(_list)

	_editor = TextEdit.new()
	_editor.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_editor.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_editor.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_editor.placeholder_text = "Ouvre un document dans la liste, ou importe-en un."
	body.add_child(_editor)

	_status = TextEdit.new()
	_status.editable = false
	_status.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_status.custom_minimum_size = Vector2(0, 120)
	vbox.add_child(_status)

	_picker = FileDialog.new()
	_picker.file_mode = FileDialog.FILE_MODE_OPEN_FILES
	_picker.access = FileDialog.ACCESS_FILESYSTEM
	_picker.title = "Choisir un ou plusieurs documents"
	_picker.filters = PackedStringArray([
		"*.json,*.zip,*.mcaddon,*.mcpack,*.txt,*.md ; Documents",
		"* ; Tous les fichiers"
	])
	# Sélecteur natif du système quand il existe (Android : Godot 4.6+, sans permission de stockage).
	# set() pour rester compatible avec les versions où la propriété n'existe pas encore.
	_picker.set("use_native_dialog", true)
	_picker.files_selected.connect(_on_files_selected)
	add_child(_picker)


func _make_button(text: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 56)
	b.pressed.connect(callback)
	return b


func _set_status(message: String) -> void:
	_status.text = message
	_status.scroll_vertical = 0


# ---------------------------------------------------------------- liste

func refresh_list(select_path: String = "") -> void:
	_docs = DocumentStore.list_documents()
	_list.clear()
	for d in _docs:
		_list.add_item("%s · %s" % [d.origin, d.name])
	if not select_path.is_empty():
		_select_path(select_path)


func _select_path(path: String) -> void:
	for i in range(_docs.size()):
		if _docs[i].path == path:
			_list.select(i)
			_list.ensure_current_is_visible()
			return


func _on_item_selected(index: int) -> void:
	if index < 0 or index >= _docs.size():
		return
	var path: String = _docs[index].path
	if path != _current_path and not _save_if_dirty():
		_select_path(_current_path)
		return
	_open(path)


func _open(path: String, prefix: String = "") -> void:
	var text := DocumentStore.read_text(path)
	_editor.text = text
	_loaded_text = _editor.text
	_current_path = path
	var summary := DocumentAdapter.describe(text, path.get_file())
	if prefix.is_empty():
		_set_status(summary)
	else:
		_set_status(prefix + "\n\n" + summary)


# ---------------------------------------------------------------- actions

func _on_toggle_pressed() -> void:
	if _panel.visible:
		_panel.visible = false
	else:
		refresh_list(_current_path)
		_panel.visible = true
	_toggle_button.visible = not _panel.visible
	panel_toggled.emit(_panel.visible)


func _on_import_pressed() -> void:
	# Avant Godot 4.6 il n'y a pas de sélecteur Android natif : le dialogue intégré lit le stockage
	# partagé et demande les permissions déclarées dans le preset d'export.
	if OS.get_name() == "Android" and Engine.get_version_info().hex < 0x040600:
		OS.request_permissions()
	var start := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if not start.is_empty():
		_picker.current_dir = start
	_picker.popup_centered_ratio(0.9)


func _on_files_selected(paths: PackedStringArray) -> void:
	var report := DocumentStore.import_paths(paths)
	var open_path: String = report.open_path
	refresh_list(open_path)
	if open_path.is_empty():
		_set_status("\n".join(PackedStringArray(report.lines)))
	else:
		_open(open_path, "\n".join(PackedStringArray(report.lines)))


func _on_adapt_pressed() -> void:
	if _editor.text.strip_edges().is_empty():
		_set_status("Rien à adapter : ouvre ou importe un document d'abord.")
		return
	var source := _current_path.get_file() if not _current_path.is_empty() else "document.json"
	var forced: String = KIND_CHOICES[_kind_option.selected]
	var r := DocumentStore.adapt_and_commit(_editor.text, source, forced)
	var written: String = r.path
	if written.is_empty():
		_set_status(str(r.message))
		return
	refresh_list(written)
	_open(written, str(r.message))


func _on_save_pressed() -> void:
	_save_current()


func _on_apply_pressed() -> void:
	if not _save_if_dirty():
		return
	apply_requested.emit()


func _save_if_dirty() -> bool:
	if _current_path.is_empty() or _editor.text == _loaded_text:
		return true
	return _save_current()


## Enregistre le document ouvert. Les fichiers lus par le jeu doivent être du JSON strict.
func _save_current() -> bool:
	if _current_path.is_empty():
		_set_status("Aucun document ouvert.")
		return false
	var in_game_dir := _current_path.begins_with(DocumentStore.SBH_DIR) or _current_path.begins_with(DocumentStore.EXAMPLE_DIR)
	if in_game_dir and _current_path.get_extension().to_lower() == "json":
		var parsed := DocumentAdapter.parse_json(_editor.text, false)
		if not parsed.ok:
			_set_status("✗ Non enregistré — " + str(parsed.error))
			return false
	var target := DocumentStore.write_text(_current_path, _editor.text)
	if target.is_empty():
		_set_status("✗ Écriture impossible : " + _current_path.get_file())
		return false
	_current_path = target
	_loaded_text = _editor.text
	refresh_list(target)
	_set_status("✓ Enregistré : " + target.get_file())
	return true
