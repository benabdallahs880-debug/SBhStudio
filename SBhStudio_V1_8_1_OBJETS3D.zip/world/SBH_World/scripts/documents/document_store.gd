class_name DocumentStore
extends RefCounted
## Stockage des documents Studio importés.
##
##   user://studio_import/sbh/         ← ce que le jeu lit (protocol / blocks / items / mobs / placements .json)
##   user://studio_import/originals/   ← copie brute de chaque document importé (sauvegarde + lecture)
##
## N'accède jamais à SBHWorld : l'application au monde passe toujours par StudioBridge.

const BASE_DIR := "user://studio_import/"
const SBH_DIR := "user://studio_import/sbh/"
const ORIGINALS_DIR := "user://studio_import/originals/"
const EXAMPLE_DIR := "res://content/studio_example/sbh/"
const KNOWN_FILES := ["protocol.json", "blocks.json", "items.json", "mobs.json", "placements.json"]

const MAX_TEXT_BYTES := 2 * 1024 * 1024
const MAX_ZIP_BYTES := 20 * 1024 * 1024


static func ensure_dirs() -> void:
	for p in [BASE_DIR, SBH_DIR, ORIGINALS_DIR]:
		DirAccess.make_dir_recursive_absolute(p)


## Documents consultables : { path, name, origin } avec origin = "jeu" | "exemple" | "source".
static func list_documents() -> Array:
	ensure_dirs()
	var docs: Array = []
	var seen := {}
	for f in DirAccess.get_files_at(SBH_DIR):
		if f.begins_with("_") or f.begins_with("."):
			continue
		docs.append({"path": SBH_DIR + f, "name": f, "origin": "jeu"})
		seen[f] = true
	for f in KNOWN_FILES:
		if not seen.has(f) and FileAccess.file_exists(EXAMPLE_DIR + f):
			docs.append({"path": EXAMPLE_DIR + f, "name": f, "origin": "exemple"})
	for f in DirAccess.get_files_at(ORIGINALS_DIR):
		if f.begins_with("_") or f.begins_with("."):
			continue
		docs.append({"path": ORIGINALS_DIR + f, "name": f, "origin": "source"})
	return docs


static func read_text(path: String) -> String:
	return FileAccess.get_file_as_text(path)


## Écrit un document. Un fichier de res:// (exemple embarqué) est redirigé vers user://
## (copie personnelle qui prend le dessus). Retourne le chemin réel, ou "" en cas d'échec.
static func write_text(path: String, text: String) -> String:
	ensure_dirs()
	var target := path
	if path.begins_with("res://"):
		target = SBH_DIR + path.get_file()
	var f := FileAccess.open(target, FileAccess.WRITE)
	if f == null:
		return ""
	f.store_string(text)
	f.close()
	return target


# ---------------------------------------------------------------- adaptation + écriture

## Adapte le texte puis l'écrit dans le dossier lu par le jeu.
## Retourne { path, message } ; path vide = rien n'a été écrit.
static func adapt_and_commit(text: String, source_name: String, forced_kind: String = "") -> Dictionary:
	var res := DocumentAdapter.adapt(text, source_name, forced_kind)
	if not res.ok:
		var why: Array = []
		for n in res.notes:
			why.append("• " + str(n))
		if why.is_empty():
			why.append("• Format non reconnu — choisis un type (Blocs, Objets, Mobs…) puis réessaie")
		return {
			"path": "",
			"message": "✗ Adaptation impossible\n" + "\n".join(PackedStringArray(why))
		}
	var c := commit(res)
	var written: String = c.path
	if written.is_empty():
		return {"path": "", "message": "✗ Écriture impossible dans " + SBH_DIR}
	var lines: Array = [
		"✓ Adapté : %s (%d) → %s" % [DocumentAdapter.KIND_LABELS[res.kind], res.count, written.get_file()]
	]
	for n in res.notes:
		lines.append("• " + str(n))
	return {"path": written, "message": "\n".join(PackedStringArray(lines))}


## Écrit un résultat d'adaptation dans user://studio_import/sbh/.
## blocs / objets / mobs : fusion par identifier avec ce qui existe déjà ; protocole / placements : remplacés.
static func commit(res: Dictionary) -> Dictionary:
	ensure_dirs()
	var kind: String = res.kind
	var path := SBH_DIR + DocumentAdapter.canonical_filename(kind)
	var payload: Dictionary = {}
	if DocumentAdapter.is_entry_kind(kind):
		payload = {"entries": _merge_entries(path, res.entries)}
	else:
		payload = res.data
	return {"path": write_text(path, DocumentAdapter.stringify(payload))}


static func _merge_entries(path: String, fresh: Array) -> Array:
	var by_id := {}
	var order: Array = []
	if FileAccess.file_exists(path):
		var parsed := DocumentAdapter.parse_json(read_text(path), false)
		if parsed.ok:
			for old in DocumentAdapter.extract_entries(parsed.data):
				if old is Dictionary:
					var old_id := str(old.get("identifier", "")).strip_edges()
					if not old_id.is_empty() and not by_id.has(old_id):
						by_id[old_id] = old
						order.append(old_id)
	for entry in fresh:
		var new_id := str(entry.get("identifier", ""))
		if not by_id.has(new_id):
			order.append(new_id)
		by_id[new_id] = entry
	var merged: Array = []
	for id in order:
		merged.append(by_id[id])
	return merged


# ---------------------------------------------------------------- import depuis l'extérieur

## Importe des fichiers choisis dans le stockage (chemins fichier, ou content:// sur Android récent).
## Retourne { lines: Array[String], open_path: String }.
static func import_paths(paths: PackedStringArray) -> Dictionary:
	ensure_dirs()
	var lines: Array = []
	var open_path := ""
	for p in paths:
		var fname := p.uri_decode().get_file().validate_filename()
		var bytes := FileAccess.get_file_as_bytes(p)
		if bytes.is_empty():
			var err := FileAccess.get_open_error()
			if err != OK:
				lines.append("✗ %s : lecture impossible (%s)" % [fname, error_string(err)])
			else:
				lines.append("✗ %s : fichier vide" % fname)
			continue
		var is_zip := bytes.size() >= 4 and bytes[0] == 0x50 and bytes[1] == 0x4B
		if is_zip:
			if bytes.size() > MAX_ZIP_BYTES:
				lines.append("✗ %s : archive trop grosse (max 20 Mo)" % fname)
				continue
			var rz := _import_zip(bytes, fname)
			lines.append_array(rz.lines)
			if open_path.is_empty():
				open_path = rz.open_path
			continue
		if bytes.size() > MAX_TEXT_BYTES:
			lines.append("✗ %s : fichier trop gros (max 2 Mo)" % fname)
			continue
		if bytes.has(0):
			lines.append("✗ %s : fichier binaire non pris en charge" % fname)
			continue
		var text := bytes.get_string_from_utf8()
		if fname.get_extension().is_empty():
			# Les sélecteurs Android donnent parfois un identifiant sans nom ni extension.
			var t := text.strip_edges()
			var ext := ".json" if (t.begins_with("{") or t.begins_with("[")) else ".txt"
			fname = "document_%d%s" % [Time.get_ticks_msec(), ext]
		var r := _import_text(text, fname, true)
		lines.append_array(r.lines)
		if open_path.is_empty():
			open_path = r.open_path
	return {"lines": lines, "open_path": open_path}


static func _import_text(text: String, fname: String, keep_original: bool) -> Dictionary:
	var out := {"lines": [], "open_path": "", "recognized": false}
	var res := DocumentAdapter.adapt(text, fname)
	var original_path := ""
	if keep_original:
		original_path = write_text(ORIGINALS_DIR + fname, text)
	if res.ok:
		var c := commit(res)
		var written: String = c.path
		if written.is_empty():
			out.lines.append("✗ %s : écriture impossible" % fname)
		else:
			out.recognized = true
			out.open_path = written
			out.lines.append("✓ %s → %s (%d %s)" % [
				fname, written.get_file(), res.count,
				String(DocumentAdapter.KIND_LABELS[res.kind]).to_lower()
			])
			for n in res.notes:
				out.lines.append("   • " + str(n))
	else:
		out.open_path = original_path
		out.lines.append("⚠ %s : lu mais pas intégré au jeu" % fname)
		for n in res.notes:
			out.lines.append("   • " + str(n))
	return out


## Archive (.zip, .mcaddon, .mcpack) : chaque .json est analysé ; seuls ceux reconnus sont intégrés.
## Les noms internes ne servent qu'à la détection : rien n'est jamais écrit sous un chemin issu de l'archive.
static func _import_zip(bytes: PackedByteArray, fname: String) -> Dictionary:
	var lines: Array = []
	var open_path := ""
	var tmp := BASE_DIR + "_tmp_import.zip"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return {"lines": ["✗ %s : copie temporaire impossible" % fname], "open_path": ""}
	f.store_buffer(bytes)
	f.close()
	var zip := ZIPReader.new()
	if zip.open(tmp) != OK:
		DirAccess.remove_absolute(tmp)
		return {"lines": ["✗ %s : archive illisible" % fname], "open_path": ""}
	var integrated := 0
	var ignored := 0
	for entry in zip.get_files():
		if entry.ends_with("/") or entry.get_extension().to_lower() != "json":
			continue
		var data := zip.read_file(entry)
		if data.is_empty() or data.size() > MAX_TEXT_BYTES:
			ignored += 1
			continue
		var r := _import_text(data.get_string_from_utf8(), entry.get_file(), false)
		if r.recognized:
			integrated += 1
			lines.append_array(r.lines)
			if open_path.is_empty():
				open_path = r.open_path
		else:
			ignored += 1
	zip.close()
	DirAccess.remove_absolute(tmp)
	lines.push_front("Archive %s : %d document(s) intégré(s), %d ignoré(s)" % [fname, integrated, ignored])
	return {"lines": lines, "open_path": open_path}
