class_name DocumentAdapter
extends RefCounted
## Lit un document (JSON, éventuellement au format Bedrock) et le ramène au format SBH World.
## Données pures : ne touche ni au monde, ni au catalogue, ni au disque.
##
## Types reconnus : protocol, blocks, items, mobs, placements.
## Détection : contenu d'abord (protocole SBH, Bedrock, placements), puis nom de fichier,
## puis forme des entrées. Un type peut aussi être imposé (forced_kind).

const KIND_PROTOCOL := "protocol"
const KIND_BLOCKS := "blocks"
const KIND_ITEMS := "items"
const KIND_MOBS := "mobs"
const KIND_PLACEMENTS := "placements"
const KIND_UNKNOWN := "unknown"

const KIND_LABELS := {
	"protocol": "Protocole SBH",
	"blocks": "Blocs",
	"items": "Objets",
	"mobs": "Mobs",
	"placements": "Placements",
	"unknown": "Non reconnu"
}


static func canonical_filename(kind: String) -> String:
	return kind + ".json"


static func is_entry_kind(kind: String) -> bool:
	return kind == KIND_BLOCKS or kind == KIND_ITEMS or kind == KIND_MOBS


static func new_result() -> Dictionary:
	return {
		"ok": false,
		"kind": KIND_UNKNOWN,
		"entries": [],
		"data": {},
		"count": 0,
		"notes": [],
		"preview": []
	}


# ---------------------------------------------------------------- lecture JSON

## Lit du JSON. Si allow_comments, retente après retrait des commentaires // et /* */
## (fréquents dans les fichiers Bedrock).
static func parse_json(text: String, allow_comments: bool = true) -> Dictionary:
	var clean := text.trim_prefix("\ufeff")
	var json := JSON.new()
	if json.parse(clean) == OK:
		return {"ok": true, "data": json.data, "error": "", "comments_stripped": false}
	var first_error := "JSON invalide (ligne %d) : %s" % [json.get_error_line(), json.get_error_message()]
	if allow_comments and (clean.contains("//") or clean.contains("/*")):
		var json2 := JSON.new()
		if json2.parse(strip_comments(clean)) == OK:
			return {"ok": true, "data": json2.data, "error": "", "comments_stripped": true}
	return {"ok": false, "data": null, "error": first_error, "comments_stripped": false}


static func strip_comments(text: String) -> String:
	var out := PackedStringArray()
	var i := 0
	var n := text.length()
	var in_string := false
	while i < n:
		var c := text[i]
		if in_string:
			out.append(c)
			if c == "\\" and i + 1 < n:
				out.append(text[i + 1])
				i += 2
				continue
			if c == "\"":
				in_string = false
			i += 1
			continue
		if c == "\"":
			in_string = true
			out.append(c)
			i += 1
			continue
		if c == "/" and i + 1 < n and text[i + 1] == "/":
			while i < n and text[i] != "\n":
				i += 1
			continue
		if c == "/" and i + 1 < n and text[i + 1] == "*":
			i += 2
			while i + 1 < n and not (text[i] == "*" and text[i + 1] == "/"):
				i += 1
			i += 2
			continue
		out.append(c)
		i += 1
	return "".join(out)


# ---------------------------------------------------------------- détection

static func detect_kind(data, source_name: String, forced_kind: String = "") -> String:
	if not forced_kind.is_empty():
		return forced_kind
	var by_name := _kind_from_name(source_name)
	if data is Dictionary:
		var d: Dictionary = data
		if str(d.get("protocol", "")) == SBhProtocol.NAME:
			return KIND_PROTOCOL
		if d.has("minecraft:entity"):
			return KIND_MOBS
		if d.has("minecraft:block"):
			return KIND_BLOCKS
		if d.has("minecraft:item"):
			return KIND_ITEMS
		var has_lists: bool = d.get("blocks") is Array or d.get("mobs") is Array
		if has_lists and (_looks_like_placements(d) or by_name == KIND_PLACEMENTS):
			return KIND_PLACEMENTS
	if by_name != KIND_UNKNOWN:
		return by_name
	return _kind_from_entries(extract_entries(data))


static func _kind_from_name(source_name: String) -> String:
	var base := source_name.get_basename().to_lower()
	if base.contains("protocol"):
		return KIND_PROTOCOL
	if base.contains("placement"):
		return KIND_PLACEMENTS
	if base.contains("block") or base.contains("bloc"):
		return KIND_BLOCKS
	if base.contains("item") or base.contains("objet"):
		return KIND_ITEMS
	if base.contains("mob") or base.contains("entit"):
		return KIND_MOBS
	return KIND_UNKNOWN


static func _kind_from_entries(entries: Array) -> String:
	for e in entries:
		if e is Dictionary:
			var d: Dictionary = e
			if d.has("vie") or d.has("degats") or d.has("hostile") or d.has("health") or d.has("identifiant"):
				return KIND_MOBS
			if d.has("damage") or d.has("durability"):
				return KIND_ITEMS
			if d.has("hardness"):
				return KIND_BLOCKS
	return KIND_UNKNOWN


static func _looks_like_placements(d: Dictionary) -> bool:
	for key in ["blocks", "mobs"]:
		var arr = d.get(key)
		if arr is Array:
			for e in arr:
				if e is Dictionary and (e.has("x") or e.has("y") or e.has("z")):
					return true
	return false


## Même logique que DefinitionAdapter : tableau direct, ou { "entries": [...] } / { "items": [...] }.
static func extract_entries(data) -> Array:
	if data is Array:
		return data
	if data is Dictionary:
		var e = data.get("entries", data.get("items", []))
		if e is Array:
			return e
	return []


# ---------------------------------------------------------------- adaptation

static func adapt(text: String, source_name: String, forced_kind: String = "") -> Dictionary:
	var res := new_result()
	var parsed := parse_json(text)
	if not parsed.ok:
		res.notes.append(parsed.error)
		return res
	if parsed.comments_stripped:
		res.notes.append("Commentaires // retirés du JSON")
	var data = parsed.data
	var kind := detect_kind(data, source_name, forced_kind)
	res.kind = kind
	match kind:
		KIND_PROTOCOL:
			_adapt_protocol(data, res)
		KIND_PLACEMENTS:
			_adapt_placements(data, res)
		KIND_BLOCKS, KIND_ITEMS, KIND_MOBS:
			_adapt_entries(kind, data, res)
		_:
			res.notes.append("Format non reconnu (ni protocole, ni blocs/objets/mobs, ni placements)")
	return res


static func _adapt_protocol(data, res: Dictionary) -> void:
	if not (data is Dictionary):
		res.notes.append("Protocole : objet JSON attendu")
		return
	var d: Dictionary = data.duplicate(true)
	var targets: Array = []
	var ct = d.get("compatibleTargets", d.get("compatible_targets", []))
	if ct is Array:
		targets = ct.duplicate()
	if not targets.has("sbh_world") and str(d.get("target", "")) != "sbh_world":
		targets.append("sbh_world")
		res.notes.append("compatibleTargets : ajout de sbh_world (adaptation pour SBH World)")
	d.erase("compatible_targets")
	d["compatibleTargets"] = targets
	var p := SBhProtocol.from_dictionary(d)
	res.data = d
	res.count = 1
	res.preview.append("%s (%s)" % [p.project_name, p.export_id])
	if p.valid:
		res.ok = true
	else:
		res.notes.append("Protocole encore invalide : " + p.error_message)


static func _adapt_placements(data, res: Dictionary) -> void:
	if not (data is Dictionary):
		res.notes.append("Placements : objet JSON attendu")
		return
	var out := {"blocks": [], "mobs": []}
	var skipped := 0
	var total := 0
	for key in ["blocks", "mobs"]:
		var arr = data.get(key, [])
		if not (arr is Array):
			continue
		for e in arr:
			var n := _normalize_placement(e)
			if n.is_empty():
				skipped += 1
			else:
				out[key].append(n)
				total += 1
				if res.preview.size() < 6:
					res.preview.append(str(n.identifier))
	if skipped > 0:
		res.notes.append("%d placement(s) ignoré(s) (identifier ou x/y/z manquant)" % skipped)
	res.data = out
	res.count = total
	res.ok = total > 0
	if not res.ok:
		res.notes.append("Aucun placement exploitable")


static func _normalize_placement(e) -> Dictionary:
	if not (e is Dictionary):
		return {}
	var identifier := str(e.get("identifier", e.get("identifiant", e.get("id", "")))).strip_edges()
	if identifier.is_empty():
		return {}
	var out := {}
	for axis in ["x", "y", "z"]:
		if not e.has(axis):
			return {}
		var v = e[axis]
		if typeof(v) != TYPE_INT and typeof(v) != TYPE_FLOAT:
			return {}
		out[axis] = floori(float(v))
	out["identifier"] = identifier
	return out


static func _adapt_entries(kind: String, data, res: Dictionary) -> void:
	var entries: Array = []
	var skipped := 0
	var bedrock := _from_bedrock(kind, data)
	if not bedrock.is_empty():
		entries.append(bedrock)
		res.notes.append("Format Bedrock converti vers SBH (valeurs lues dans « components »)")
	else:
		for raw in extract_entries(data):
			var n := _normalize_entry(kind, raw)
			if n.is_empty():
				skipped += 1
			else:
				entries.append(n)
	if skipped > 0:
		res.notes.append("%d entrée(s) ignorée(s) (identifier manquant)" % skipped)
	for entry in entries:
		if res.preview.size() < 6:
			res.preview.append(str(entry.identifier))
	res.entries = entries
	res.count = entries.size()
	res.ok = entries.size() > 0
	if not res.ok:
		res.notes.append("Aucune entrée exploitable")


static func _normalize_entry(kind: String, raw) -> Dictionary:
	if not (raw is Dictionary):
		return {}
	var n: Dictionary = raw.duplicate(true)
	var identifier := str(n.get("identifier", n.get("identifiant", n.get("id", "")))).strip_edges()
	if identifier.is_empty():
		return {}
	n.erase("id")
	n.erase("identifiant")
	n["identifier"] = identifier
	if not n.has("name") and not n.has("nom"):
		n["name"] = _name_from_identifier(identifier)
	if kind == KIND_MOBS:
		_rename_key(n, "health", "vie")
		_rename_key(n, "damage", "degats")
	return n


static func _rename_key(d: Dictionary, from_key: String, to_key: String) -> void:
	if d.has(from_key) and not d.has(to_key):
		d[to_key] = d[from_key]
		d.erase(from_key)


## Conversion minimale d'un fichier Bedrock (entité / bloc / objet) vers une entrée SBH.
static func _from_bedrock(kind: String, data) -> Dictionary:
	if not (data is Dictionary):
		return {}
	var key := ""
	match kind:
		KIND_MOBS:
			key = "minecraft:entity"
		KIND_BLOCKS:
			key = "minecraft:block"
		KIND_ITEMS:
			key = "minecraft:item"
	if key.is_empty() or not data.has(key):
		return {}
	var body := _dict(data[key])
	var desc := _dict(body.get("description"))
	var comps := _dict(body.get("components"))
	var identifier := str(desc.get("identifier", "")).strip_edges()
	if identifier.is_empty():
		return {}
	var e := {"identifier": identifier, "name": _name_from_identifier(identifier)}
	match kind:
		KIND_MOBS:
			var hp = first_number(comps.get("minecraft:health"))
			if hp != null:
				e["vie"] = hp
			var dmg = first_number(_dict(comps.get("minecraft:attack")).get("damage"))
			if dmg != null:
				e["degats"] = dmg
			var families = _dict(comps.get("minecraft:type_family")).get("family", [])
			e["hostile"] = comps.has("minecraft:behavior.nearest_attackable_target") or (families is Array and families.has("monster"))
		KIND_BLOCKS:
			var mining = comps.get("minecraft:destructible_by_mining")
			if mining is Dictionary:
				var seconds = first_number(mining.get("seconds_to_destroy"))
				if seconds != null:
					e["hardness"] = seconds
		KIND_ITEMS:
			var item_damage = first_number(comps.get("minecraft:damage"))
			if item_damage != null:
				e["damage"] = item_damage
			var dur := _dict(comps.get("minecraft:durability"))
			var max_dur = first_number(dur.get("max_durability", dur.get("max_damage")))
			if max_dur != null:
				e["durability"] = max_dur
	return e


static func _dict(v) -> Dictionary:
	if v is Dictionary:
		return v
	return {}


## Premier nombre exploitable : nombre direct, { "value"/"max": n } ou dernier nombre d'un tableau [min, max].
static func first_number(v):
	match typeof(v):
		TYPE_INT, TYPE_FLOAT:
			return v
		TYPE_DICTIONARY:
			for k in ["value", "max"]:
				if v.has(k) and (typeof(v[k]) == TYPE_INT or typeof(v[k]) == TYPE_FLOAT):
					return v[k]
		TYPE_ARRAY:
			for i in range(v.size() - 1, -1, -1):
				if typeof(v[i]) == TYPE_INT or typeof(v[i]) == TYPE_FLOAT:
					return v[i]
	return null


static func _name_from_identifier(identifier: String) -> String:
	var part := identifier.get_slice(":", 1) if identifier.contains(":") else identifier
	return part.capitalize()


# ---------------------------------------------------------------- sortie

## JSON lisible ; les nombres entiers restent entiers (24 et non 24.0), l'ordre des clés est conservé.
static func stringify(data) -> String:
	return JSON.stringify(_clean_numbers(data), "  ", false)


static func _clean_numbers(v):
	match typeof(v):
		TYPE_FLOAT:
			if v == floor(v) and absf(v) < 1.0e15:
				return int(v)
			return v
		TYPE_DICTIONARY:
			var out := {}
			for k in v.keys():
				out[k] = _clean_numbers(v[k])
			return out
		TYPE_ARRAY:
			var arr := []
			for x in v:
				arr.append(_clean_numbers(x))
			return arr
	return v


## Résumé lisible d'un document (type détecté, nombre d'éléments, aperçu, remarques d'adaptation).
static func describe(text: String, source_name: String) -> String:
	var res := adapt(text, source_name)
	var lines: Array = []
	if res.kind == KIND_UNKNOWN:
		lines.append("Document non reconnu comme contenu SBH (%d caractères)." % text.length())
		for n in res.notes:
			lines.append("• " + str(n))
		return "\n".join(PackedStringArray(lines))
	lines.append("Type : %s — %d élément(s)" % [KIND_LABELS[res.kind], res.count])
	if res.preview.size() > 0:
		lines.append("Aperçu : " + ", ".join(PackedStringArray(res.preview)))
	for n in res.notes:
		lines.append("• À l'adaptation : " + str(n))
	if not res.ok:
		lines.append("⚠ Adaptation impossible en l'état.")
	return "\n".join(PackedStringArray(lines))
