class_name StudioBridge
extends RefCounted
## Pont Studio → World en deux phases :
## 1) bootstrap()     → catalogue uniquement (aucun chunk)
## 2) place_into_world() → PlacementAdapter SEUL autorisé à toucher SBHWorld

var content: StudioContent
var catalog: StudioCatalog
var adapters: Array = []
var placement: PlacementAdapter
var log_lines: PackedStringArray = PackedStringArray()


func _init() -> void:
	content = StudioContent.new()
	catalog = StudioCatalog.new()
	placement = PlacementAdapter.new()
	# Adaptateurs catalogue uniquement — pas de PlacementAdapter ici
	adapters = [
		ProtocolAdapter.new(),
		DefinitionAdapter.new()
	]


## Phase 1 : import + définitions. Sans effet sur le monde voxel.
func bootstrap(load_example_if_empty: bool = true) -> void:
	log_lines = PackedStringArray()
	catalog.clear()
	content.bootstrap(load_example_if_empty)
	log_lines.append(content.debug_line())

	for a in adapters:
		var adapter: StudioAdapter = a
		var ok := adapter.apply(content, catalog)
		log_lines.append("[%s] %s%s" % [
			adapter.adapter_name(),
			adapter.last_message,
			"" if ok else " (échec)"
		])

	log_lines.append(catalog.summary())


## Phase 2 : placement explicite dans le monde (seul chemin d'écriture voxels Studio).
func place_into_world(world: SBHWorld) -> bool:
	var ok := placement.apply_to_world(catalog, world)
	log_lines.append("[%s] %s%s" % [
		placement.adapter_name(),
		placement.last_message,
		"" if ok else " (échec)"
	])
	return ok


func has_studio_link() -> bool:
	return content.has_content() and catalog.is_bound()


func print_log() -> void:
	for line in log_lines:
		print(line)
