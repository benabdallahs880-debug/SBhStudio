class_name ProtocolAdapter
extends StudioAdapter
## Lie les métadonnées du protocole SBH au catalogue.
## N'importe aucun bloc dans le monde.

func adapter_name() -> String:
	return "ProtocolAdapter"


func apply(content: StudioContent, catalog: StudioCatalog) -> bool:
	if content == null or not content.has_content():
		success = false
		last_message = "Pas de protocole Studio valide"
		return false
	catalog.bind_protocol(content.protocol)
	success = true
	last_message = "Protocole lié: %s" % content.protocol.export_id
	return true
