class_name PlacementAdapter
extends RefCounted
## SEUL adaptateur autorisé à modifier SBHWorld.
## Lit le StudioCatalog (+ placements.json optionnel) et applique au monde.
## ProtocolAdapter / DefinitionAdapter ne doivent jamais appeler ce code.

const USER_PLACEMENTS := "user://studio_import/sbh/placements.json"
const RES_PLACEMENTS := "res://content/studio_example/sbh/placements.json"

## Mapping identifier Studio → id local BlockTypes (placeholder Étape 1).
const BLOCK_MAP := {
	"agw:night_bricks": BlockTypes.Type.STONE,
	"agw:sand_glass": BlockTypes.Type.DIRT,
	"minecraft:grass": BlockTypes.Type.GRASS,
	"minecraft:dirt": BlockTypes.Type.DIRT,
	"minecraft:stone": BlockTypes.Type.STONE
}

var last_message: String = ""
var success: bool = false
var blocks_placed: int = 0
var mobs_marked: int = 0
var skipped: int = 0

## Node parent des marqueurs mob (enfant du world).
var _markers_root: Node3D = null

## Position → id d'origine des blocs posés par la dernière application (pour pouvoir ré-appliquer).
var _previous_ids: Dictionary = {}


func adapter_name() -> String:
	return "PlacementAdapter"


## Applique le catalogue au monde. N'est PAS un StudioAdapter.apply (pas de chunks dans le bootstrap).
func apply_to_world(catalog: StudioCatalog, world: SBHWorld) -> bool:
	blocks_placed = 0
	mobs_marked = 0
	skipped = 0
	success = false

	if catalog == null or not catalog.is_bound():
		last_message = "Catalogue non lié — placement annulé"
		return false
	if world == null or not is_instance_valid(world):
		last_message = "Monde invalide"
		return false

	_revert_previous(world)
	_ensure_markers_root(world)

	var plan := _load_placements_plan()
	if plan.is_empty():
		# Plan par défaut minimal : un pilier de démo à partir des définitions blocs
		plan = _default_plan_from_catalog(catalog)

	_place_blocks(world, plan.get("blocks", []))
	_place_mob_markers(world, plan.get("mobs", []))

	success = true
	last_message = "Placement OK — blocs=%d marqueurs_mobs=%d ignorés=%d (export %s)" % [
		blocks_placed, mobs_marked, skipped, catalog.export_id
	]
	return true


## Remet le monde comme avant la précédente application (documents modifiés puis ré-appliqués).
func _revert_previous(world: SBHWorld) -> void:
	for pos in _previous_ids.keys():
		world.set_block(pos, int(_previous_ids[pos]))
	_previous_ids.clear()


func _ensure_markers_root(world: SBHWorld) -> void:
	var existing := world.get_node_or_null("StudioPlacements")
	if existing:
		existing.queue_free()
	_markers_root = Node3D.new()
	_markers_root.name = "StudioPlacements"
	world.add_child(_markers_root)


func _load_placements_plan() -> Dictionary:
	for path in [USER_PLACEMENTS, RES_PLACEMENTS]:
		if not FileAccess.file_exists(path):
			continue
		var f := FileAccess.open(path, FileAccess.READ)
		if f == null:
			continue
		var parsed = JSON.parse_string(f.get_as_text())
		if typeof(parsed) == TYPE_DICTIONARY:
			return parsed
	return {}


func _default_plan_from_catalog(catalog: StudioCatalog) -> Dictionary:
	var blocks: Array = []
	var mobs: Array = []
	var i := 0
	for id in catalog.blocks.keys():
		blocks.append({
			"x": 4 + i,
			"y": 3,
			"z": 4,
			"identifier": id
		})
		i += 1
	var j := 0
	for id in catalog.mobs.keys():
		mobs.append({
			"x": 6 + j * 2,
			"y": 3,
			"z": 8,
			"identifier": id
		})
		j += 1
	return {"blocks": blocks, "mobs": mobs}


func _resolve_block_id(identifier: String) -> int:
	if BLOCK_MAP.has(identifier):
		return int(BLOCK_MAP[identifier])
	# Inconnu → pierre pour rester visible en proto
	return BlockTypes.Type.STONE


func _place_blocks(world: SBHWorld, entries: Array) -> void:
	for e in entries:
		if typeof(e) != TYPE_DICTIONARY:
			skipped += 1
			continue
		var id_str := str(e.get("identifier", ""))
		if id_str.is_empty():
			skipped += 1
			continue
		var pos := Vector3i(int(e.get("x", 0)), int(e.get("y", 0)), int(e.get("z", 0)))
		var local_id := _resolve_block_id(id_str)
		if not _previous_ids.has(pos):
			_previous_ids[pos] = world.get_block(pos)
		world.set_block(pos, local_id)
		blocks_placed += 1


func _place_mob_markers(world: SBHWorld, entries: Array) -> void:
	for e in entries:
		if typeof(e) != TYPE_DICTIONARY:
			skipped += 1
			continue
		var id_str := str(e.get("identifier", ""))
		if id_str.is_empty():
			skipped += 1
			continue
		var pos := Vector3(
			float(e.get("x", 0)) + 0.5,
			float(e.get("y", 1)) + 0.5,
			float(e.get("z", 0)) + 0.5
		)
		var marker := _make_mob_marker(id_str)
		marker.position = pos
		_markers_root.add_child(marker)
		mobs_marked += 1


func _make_mob_marker(identifier: String) -> Node3D:
	var root := StaticBody3D.new()
	root.name = identifier.replace(":", "_")
	CollisionLayers.setup_marker(root)

	var mi := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.35
	mesh.height = 0.7
	mi.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.85, 0.25, 0.2)
	mat.emission_enabled = true
	mat.emission = Color(0.6, 0.1, 0.05)
	mi.material_override = mat
	root.add_child(mi)

	var shape := SphereShape3D.new()
	shape.radius = 0.35
	var cs := CollisionShape3D.new()
	cs.shape = shape
	root.add_child(cs)

	root.set_meta("studio_identifier", identifier)
	root.set_meta("studio_kind", "mob_marker")
	return root
