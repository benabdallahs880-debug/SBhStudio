class_name StudioAdapter
extends RefCounted
## Contrat commun des adaptateurs Studio → World.
## Un adaptateur lit du contenu Studio et remplit le StudioCatalog.
## Il ne doit jamais appeler SBHWorld.set_block ni toucher aux chunks.

var last_message: String = ""
var success: bool = false


func adapter_name() -> String:
	return "StudioAdapter"


## Applique l'adaptateur. Retourne true si quelque chose d'utile a été fait.
func apply(_content: StudioContent, _catalog: StudioCatalog) -> bool:
	success = false
	last_message = "non implémenté"
	return false
