class_name DefinitionAdapter
extends StudioAdapter
## Charge des définitions Studio (JSON) vers le catalogue.
## Chemins supportés (optionnels) :
##   user://studio_import/sbh/blocks.json
##   user://studio_import/sbh/items.json
##   user://studio_import/sbh/mobs.json
##   res://content/studio_example/sbh/{blocks,items,mobs}.json
##
## Format attendu : { "entries": [ { "identifier": "agw:...", ... }, ... ] }
## ou un tableau JSON direct.

const USER_SBH_DIR := "user://studio_import/sbh/"
const RES_SBH_DIR := "res://content/studio_example/sbh/"


func adapter_name() -> String:
	return "DefinitionAdapter"


func apply(content: StudioContent, catalog: StudioCatalog) -> bool:
	if catalog == null:
		success = false
		last_message = "Catalogue absent"
		return false

	var loaded := 0
	loaded += _load_list("blocks.json", catalog.add_block_def)
	loaded += _load_list("items.json", catalog.add_item_def)
	loaded += _load_list("mobs.json", catalog.add_mob_def)

	if loaded == 0:
		# Pas d'erreur : le protocole seul est déjà utile.
		success = true
		last_message = "Aucune définition JSON trouvée (protocole seul)"
		catalog.notes.append(last_message)
		return true

	success = true
	last_message = "Définitions chargées (%d fichiers)" % loaded
	catalog.notes.append(last_message)
	if content and content.has_content():
		catalog.notes.append("Lié à export %s" % content.protocol.export_id)
	return true


func _load_list(filename: String, adder: Callable) -> int:
	var path := _resolve(filename)
	if path.is_empty():
		return 0
	var entries := _read_entries(path)
	for e in entries:
		if typeof(e) == TYPE_DICTIONARY:
			adder.call(e)
	return 1 if entries.size() > 0 else 0


func _resolve(filename: String) -> String:
	var user_path := USER_SBH_DIR + filename
	if FileAccess.file_exists(user_path):
		return user_path
	var res_path := RES_SBH_DIR + filename
	if FileAccess.file_exists(res_path):
		return res_path
	return ""


func _read_entries(path: String) -> Array:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return []
	var parsed = JSON.parse_string(f.get_as_text())
	if typeof(parsed) == TYPE_ARRAY:
		return parsed
	if typeof(parsed) == TYPE_DICTIONARY:
		var entries = parsed.get("entries", parsed.get("items", []))
		if typeof(entries) == TYPE_ARRAY:
			return entries
	return []
