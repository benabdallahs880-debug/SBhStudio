class_name StudioCatalog
extends RefCounted
## Catalogue de définitions importées depuis SBh Studio.
## Données pures — aucun accès à SBHWorld / chunks / blocs placés.

var export_id: String = ""
var project_id: String = ""
var project_name: String = ""
var project_version: String = ""
var studio_version: String = ""

## id technique (ex. agw:ghurab) → définition
var blocks: Dictionary = {}
var items: Dictionary = {}
var mobs: Dictionary = {}

var notes: PackedStringArray = PackedStringArray()


func clear() -> void:
	export_id = ""
	project_id = ""
	project_name = ""
	project_version = ""
	studio_version = ""
	blocks.clear()
	items.clear()
	mobs.clear()
	notes = PackedStringArray()


func is_bound() -> bool:
	return not export_id.is_empty()


func bind_protocol(p: SBhProtocol) -> void:
	export_id = p.export_id
	project_id = p.project_id
	project_name = p.project_name
	project_version = p.project_version
	studio_version = p.studio_version


func add_block_def(data: Dictionary) -> void:
	var id := str(data.get("identifier", data.get("id", "")))
	if id.is_empty():
		return
	blocks[id] = data.duplicate(true)


func add_item_def(data: Dictionary) -> void:
	var id := str(data.get("identifier", data.get("id", "")))
	if id.is_empty():
		return
	items[id] = data.duplicate(true)


func add_mob_def(data: Dictionary) -> void:
	var id := str(data.get("identifier", data.get("identifiant", data.get("id", ""))))
	if id.is_empty():
		return
	mobs[id] = data.duplicate(true)


func counts_line() -> String:
	return "blocs=%d items=%d mobs=%d" % [blocks.size(), items.size(), mobs.size()]


func summary() -> String:
	if not is_bound():
		return "Catalogue vide (aucun export lié)"
	return "Catalogue [%s] %s — %s" % [export_id, project_name, counts_line()]
