class_name JoystickOverlay
extends Control

var axis := Vector2.ZERO

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
