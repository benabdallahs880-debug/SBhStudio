class_name TouchControls
extends CanvasLayer

signal break_pressed
signal place_pressed
signal jump_pressed
signal look_changed(delta_pos: Vector2)

var look_touch := -1
var last_pos := Vector2.ZERO

func _ready() -> void:
	var layer := Control.new()
	layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(layer)

	var break_button := Button.new()
	break_button.text = "CASSER"
	break_button.position = Vector2(1030, 540)
	break_button.size = Vector2(180, 70)
	break_button.pressed.connect(func(): break_pressed.emit())
	layer.add_child(break_button)

	var place_button := Button.new()
	place_button.text = "POSER"
	place_button.position = Vector2(1030, 620)
	place_button.size = Vector2(180, 70)
	place_button.pressed.connect(func(): place_pressed.emit())
	layer.add_child(place_button)

	var jump_button := Button.new()
	jump_button.text = "SAUT"
	jump_button.position = Vector2(830, 600)
	jump_button.size = Vector2(160, 70)
	jump_button.pressed.connect(func(): jump_pressed.emit())
	layer.add_child(jump_button)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and event.position.x > get_viewport().size.x * 0.5:
			look_touch = event.index
			last_pos = event.position
		elif not event.pressed and event.index == look_touch:
			look_touch = -1
	elif event is InputEventScreenDrag and event.index == look_touch:
		var d := event.position - last_pos
		last_pos = event.position
		look_changed.emit(d)
