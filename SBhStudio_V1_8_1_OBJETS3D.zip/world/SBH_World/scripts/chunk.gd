class_name SBHChunk
extends Node3D
## Chunk voxel : mesh visuel + collisions par boîtes (fiable avec CharacterBody3D).

const SIZE := 16

var blocks: Dictionary = {}
var mesh_instance: MeshInstance3D
var collision_body: StaticBody3D
var world_ref: SBHWorld = null
var chunk_coord: Vector2i = Vector2i.ZERO


func _ready() -> void:
	mesh_instance = MeshInstance3D.new()
	mesh_instance.name = "Mesh"
	add_child(mesh_instance)

	collision_body = StaticBody3D.new()
	collision_body.name = "Collision"
	CollisionLayers.setup_world_body(collision_body)
	add_child(collision_body)


func set_block(local_pos: Vector3i, id: int) -> void:
	if id == BlockTypes.Type.AIR:
		blocks.erase(local_pos)
	else:
		blocks[local_pos] = id


func get_block(local_pos: Vector3i) -> int:
	return int(blocks.get(local_pos, BlockTypes.Type.AIR))


func _neighbor_solid(local_pos: Vector3i, normal: Vector3i) -> bool:
	var n := local_pos + normal
	if n.x >= 0 and n.y >= 0 and n.z >= 0 and n.x < SIZE and n.z < SIZE:
		return get_block(n) != BlockTypes.Type.AIR
	if world_ref != null:
		var world_pos := Vector3i(
			chunk_coord.x * SIZE + local_pos.x + normal.x,
			local_pos.y + normal.y,
			chunk_coord.y * SIZE + local_pos.z + normal.z
		)
		return world_ref.get_block(world_pos) != BlockTypes.Type.AIR
	return false


func rebuild() -> void:
	if mesh_instance == null or collision_body == null:
		return
	_rebuild_mesh()
	_rebuild_collision()


func _rebuild_mesh() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var positions := [
		Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(1, 1, 0), Vector3(0, 1, 0),
		Vector3(0, 0, 1), Vector3(1, 0, 1), Vector3(1, 1, 1), Vector3(0, 1, 1)
	]
	var faces = [
		[[0, 1, 2, 3], Vector3i(0, 0, -1)],
		[[5, 4, 7, 6], Vector3i(0, 0, 1)],
		[[4, 0, 3, 7], Vector3i(-1, 0, 0)],
		[[1, 5, 6, 2], Vector3i(1, 0, 0)],
		[[3, 2, 6, 7], Vector3i(0, 1, 0)],
		[[4, 5, 1, 0], Vector3i(0, -1, 0)]
	]
	for p in blocks.keys():
		var id: int = blocks[p]
		var base := Vector3(p)
		for face in faces:
			var idxs = face[0]
			var normal: Vector3i = face[1]
			if _neighbor_solid(p, normal):
				continue
			var quad := PackedVector3Array()
			for i in idxs:
				quad.append(base + positions[i])
			for oi in [0, 1, 2, 0, 2, 3]:
				st.set_normal(Vector3(normal))
				st.set_color(BlockTypes.color(id))
				st.set_uv(Vector2.ZERO)
				st.add_vertex(quad[oi])
	mesh_instance.mesh = st.commit()


func _rebuild_collision() -> void:
	for child in collision_body.get_children():
		child.queue_free()
	for p in blocks.keys():
		var id: int = blocks[p]
		if not BlockTypes.is_solid(id):
			continue
		var shape := BoxShape3D.new()
		shape.size = Vector3.ONE
		var cs := CollisionShape3D.new()
		cs.shape = shape
		cs.position = Vector3(p) + Vector3(0.5, 0.5, 0.5)
		collision_body.add_child(cs)
