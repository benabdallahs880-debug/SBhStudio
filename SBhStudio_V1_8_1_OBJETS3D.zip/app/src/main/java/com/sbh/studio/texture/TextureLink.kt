package com.sbh.studio.texture

import android.content.Context
import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/**
 * Pont Studio Texture ↔ Atelier / Map Studio / PackGenerator.
 *
 * URI interne : sbhtex://{textureProjectId}
 * Résolue en PNG depuis les pixels enregistrés dans TextureRepository.
 */
object TextureLink {
    const val SCHEME = "sbhtex"

    fun uriFor(textureId: String): String = "$SCHEME://$textureId"

    fun isStudioUri(uri: String?): Boolean =
        uri != null && (uri.startsWith("$SCHEME://") || uri.startsWith("sbhtexture://"))

    fun idFromUri(uri: String): String? {
        if (!isStudioUri(uri)) return null
        return uri.substringAfter("://").substringBefore("?").ifBlank { null }
    }

    /** Charge les octets PNG d'une texture studio, ou null si introuvable. */
    fun loadPngBytes(context: Context, uri: String): ByteArray? {
        val id = idFromUri(uri) ?: return null
        val project = TextureRepository(context).loadAll().find { it.id == id } ?: return null
        if (project.pixels.size != project.width * project.height) return null
        if (project.width <= 0 || project.height <= 0) return null
        val bmp = Bitmap.createBitmap(project.width, project.height, Bitmap.Config.ARGB_8888)
        val px = IntArray(project.pixels.size) { project.pixels[it] }
        bmp.setPixels(px, 0, project.width, 0, 0, project.width, project.height)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return out.toByteArray()
    }

    fun labelFor(context: Context, uri: String?): String {
        if (uri == null) return "Aucune"
        if (!isStudioUri(uri)) return "Fichier externe"
        val id = idFromUri(uri) ?: return "Studio ?"
        val p = TextureRepository(context).loadAll().find { it.id == id }
        return p?.name ?: "Texture manquante"
    }
}
