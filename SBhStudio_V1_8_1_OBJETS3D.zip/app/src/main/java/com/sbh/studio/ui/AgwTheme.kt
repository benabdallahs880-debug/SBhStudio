package com.sbh.studio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** SBH Dark Forge: interface technique sombre, lisible et chaleureuse. */
object AgwColors {
    val DeepNight = Color(0xFF0D1117)
    val NightStone = Color(0xFF151B22)
    val Panel = Color(0xFF1A222C)
    val PanelRaised = Color(0xFF202A35)
    val Outline = Color(0xFF33404D)
    val SacredGold = Color(0xFFD6B45A)
    val GoldSoft = Color(0xFFF0D78A)
    val GoldMuted = Color(0xFF3A301A)
    val DesertOchre = Color(0xFFB08A4B)
    val PersianBlue = Color(0xFF2B526E)
    val PaleMarble = Color(0xFFE8E2D5)
    val Sand = Color(0xFFBDB4A3)
    val Success = Color(0xFF63B77A)
    val Warning = Color(0xFFD7A84B)
    val Error = Color(0xFFC96A6A)
    val Info = Color(0xFF6DA7C9)
    val NightGlass = Color(0xE6151B22)
    val NightGlassSoft = Color(0xE31A222C)
    val StoneGlass = Color(0xCC202A35)
    val GoldGlass = Color(0x55D6B45A)
    val GoldVeil = Color(0x1FD6B45A)
    val DriedBlood = Error
    val SandBackground = Color(0xFFF1E9D8)
}

private val SbhTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 13.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.2.sp)
)

private val DarkScheme = darkColorScheme(
    primary = AgwColors.SacredGold,
    onPrimary = AgwColors.DeepNight,
    secondary = AgwColors.PersianBlue,
    onSecondary = AgwColors.PaleMarble,
    tertiary = AgwColors.Info,
    background = AgwColors.DeepNight,
    onBackground = AgwColors.PaleMarble,
    surface = AgwColors.Panel,
    onSurface = AgwColors.PaleMarble,
    surfaceVariant = AgwColors.PanelRaised,
    onSurfaceVariant = AgwColors.Sand,
    error = AgwColors.Error,
    primaryContainer = AgwColors.GoldMuted,
    onPrimaryContainer = AgwColors.GoldSoft,
    outline = AgwColors.Outline
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF765A1E),
    onPrimary = Color.White,
    secondary = AgwColors.PersianBlue,
    background = AgwColors.SandBackground,
    onBackground = Color(0xFF1C1A17),
    surface = Color(0xFFFFFBF3),
    onSurface = Color(0xFF1C1A17),
    primaryContainer = Color(0xFFEBD8A8),
    onPrimaryContainer = Color(0xFF2A210F),
    outline = Color(0xFF8C806A)
)

@Composable
fun AgwTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = SbhTypography,
        content = content
    )
}
