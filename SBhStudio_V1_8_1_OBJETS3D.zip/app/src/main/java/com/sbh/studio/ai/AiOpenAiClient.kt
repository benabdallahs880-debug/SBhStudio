package com.sbh.studio.ai

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Client for an OpenAI-compatible gateway. The Android app never contains an OpenAI API key.
 * The gateway is responsible for authenticating with OpenAI and keeping the secret server-side.
 */
class AiOpenAiClient {
    private val json = Json { ignoreUnknownKeys = true }

    data class Result(val ok: Boolean, val text: String, val detail: String)

    fun send(gatewayUrl: String, model: String, message: String, sessionId: String): Result {
        val base = gatewayUrl.trim().trimEnd('/')
        if (base.isBlank()) return Result(false, "", "Passerelle IA non configurée.")
        if (!base.startsWith("https://")) return Result(false, "", "La passerelle doit utiliser HTTPS.")
        if (message.isBlank()) return Result(false, "", "Message vide.")

        val endpoint = if (base.endsWith("/v1/responses")) base else "$base/v1/responses"
        val body = buildJsonObject {
            put("model", model.ifBlank { "gpt-5-mini" })
            put("input", message)
            put("safety_identifier", sha256(sessionId))
        }.toString()

        return runCatching {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            connection.disconnect()
            if (code !in 200..299) return@runCatching Result(false, "", "HTTP $code: ${raw.take(800)}")
            val root = json.parseToJsonElement(raw)
            val text = extractOutputText(root)
            if (text.isBlank()) Result(false, "", "Réponse reçue mais aucun texte output_text n'a été trouvé.")
            else Result(true, text, "Réponse OpenAI reçue.")
        }.getOrElse { Result(false, "", "Connexion IA impossible : ${it.message ?: it::class.simpleName}") }
    }

    private fun extractOutputText(element: kotlinx.serialization.json.JsonElement): String {
        val hits = mutableListOf<String>()
        fun walk(node: kotlinx.serialization.json.JsonElement) {
            when (node) {
                is JsonObject -> {
                    node["output_text"]?.let { value -> if (value is JsonPrimitive) hits += value.content }
                    node.values.forEach(::walk)
                }
                is kotlinx.serialization.json.JsonArray -> node.forEach(::walk)
                else -> Unit
            }
        }
        walk(element)
        return hits.joinToString("\n").trim()
    }

    private fun sha256(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
