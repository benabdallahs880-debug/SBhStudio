package com.sbh.studio.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Formes & surfaces décoratives noir / or */
object AgwDecor {
    val CardShape = RoundedCornerShape(16.dp)
    val ChipShape = RoundedCornerShape(10.dp)
    val ButtonShape = RoundedCornerShape(11.dp)
    val TileShape = RoundedCornerShape(14.dp)

    val GoldBorder = BorderStroke(1.dp, AgwColors.Outline)
    val GoldBorderStrong = BorderStroke(1.dp, AgwColors.GoldGlass)

    val PanelBrush = Brush.verticalGradient(
        listOf(AgwColors.PanelRaised, AgwColors.Panel)
    )
    val GoldSheen = Brush.verticalGradient(
        listOf(
            AgwColors.GoldVeil,
            Color.Transparent,
            Color.Transparent
        )
    )
}

@Composable
fun GoldPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp),
        shape = AgwDecor.ButtonShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = AgwColors.SacredGold,
            contentColor = AgwColors.DeepNight,
            disabledContainerColor = AgwColors.NightStone,
            disabledContentColor = AgwColors.Sand.copy(alpha = 0.5f)
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp, pressedElevation = 1.dp)
    ) {
        Text(text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun GoldOutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 44.dp),
        shape = AgwDecor.ButtonShape,
        border = AgwDecor.GoldBorderStrong,
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = AgwColors.GoldSoft,
            containerColor = AgwColors.NightGlass
        )
    ) {
        Text(text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .border(AgwDecor.GoldBorder, AgwDecor.CardShape),
        shape = AgwDecor.CardShape,
        colors = CardDefaults.cardColors(containerColor = AgwColors.Panel),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Box {
            Box(Modifier.matchParentSize().background(AgwDecor.GoldSheen))
            Column(
                Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                content = content
            )
        }
    }
}

/**
 * Tuile de mode : icône (asset branding/icons) + libellé.
 * Utilisée sur l'accueil et dans l'atelier.
 */
@Composable
fun ModeIconTile(
    label: String,
    iconAsset: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    selected: Boolean = false,
    enabled: Boolean = true
) {
    val border = if (selected) AgwDecor.GoldBorderStrong else AgwDecor.GoldBorder
    val bg = if (selected) AgwColors.GoldMuted else AgwColors.NightGlassSoft
    val bmp = rememberAssetBitmap(iconAsset)
    val fade = if (enabled) 1f else 0.45f

    Column(
        modifier = modifier
            .clip(AgwDecor.TileShape)
            .background(bg)
            .border(border, AgwDecor.TileShape)
            .alpha(fade)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(AgwColors.DeepNight.copy(alpha = 0.45f))
                .border(1.2.dp, AgwColors.GoldGlass, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = label,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(46.dp)
                )
            } else {
                Text("◆", color = AgwColors.SacredGold, fontSize = 22.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            label,
            color = if (selected) AgwColors.DeepNight else AgwColors.PaleMarble,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.5.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
        if (subtitle != null) {
            Text(
                subtitle,
                color = if (selected) AgwColors.DeepNight.copy(alpha = 0.7f) else AgwColors.Sand,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ModeIconChip(
    label: String,
    iconAsset: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bmp = rememberAssetBitmap(iconAsset)
    val bg = if (selected) AgwColors.SacredGold else AgwColors.NightGlass
    val fg = if (selected) AgwColors.DeepNight else AgwColors.PaleMarble
    Row(
        modifier = modifier
            .clip(AgwDecor.ChipShape)
            .background(bg)
            .border(
                if (selected) BorderStroke(0.dp, Color.Transparent) else AgwDecor.GoldBorder,
                AgwDecor.ChipShape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(22.dp)
            )
        }
        Text(label, color = fg, fontWeight = FontWeight.Medium, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(bottom = 6.dp),
        fontWeight = FontWeight.Bold,
        color = AgwColors.GoldSoft,
        fontSize = 16.sp,
        letterSpacing = 0.3.sp
    )
}

@Composable
fun GoldDivider(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        AgwColors.SacredGold.copy(alpha = 0.55f),
                        Color.Transparent
                    )
                )
            )
    )
}

@Composable
fun IconBadge(
    iconAsset: String,
    size: Dp = 36.dp
) {
    val bmp = rememberAssetBitmap(iconAsset)
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(AgwColors.NightGlass)
            .border(1.dp, AgwColors.GoldGlass, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(size * 0.78f))
        }
    }
}

@Composable
fun StatusPill(text: String, ok: Boolean = true) {
    val dot = if (ok) AgwColors.Success else AgwColors.Warning
    Row(
        modifier = Modifier
            .clip(AgwDecor.ChipShape)
            .background(dot.copy(alpha = 0.12f))
            .border(1.dp, dot.copy(alpha = 0.35f), AgwDecor.ChipShape)
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(dot))
        Text(text, color = dot, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
    }
}


@Composable
fun ForgeStatusRow(
    label: String,
    detail: String,
    state: String,
    ok: Boolean = true,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(AgwDecor.ChipShape)
            .background(AgwColors.NightGlassSoft)
            .border(1.dp, AgwColors.Outline, AgwDecor.ChipShape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = AgwColors.PaleMarble, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(detail, color = AgwColors.Sand, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        StatusPill(state, ok)
    }
}

@Composable
fun ForgeMetric(
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(AgwDecor.ChipShape)
            .background(AgwColors.DeepNight.copy(alpha = 0.48f))
            .border(1.dp, AgwColors.Outline, AgwDecor.ChipShape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text(value, color = AgwColors.GoldSoft, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Text(label, color = AgwColors.Sand, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ForgeSectionCard(
    title: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable (() -> Unit))? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(AgwDecor.GoldBorder, AgwDecor.CardShape),
        shape = AgwDecor.CardShape,
        colors = CardDefaults.cardColors(containerColor = AgwColors.Panel),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = AgwColors.GoldSoft, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                trailing?.invoke()
            }
            content()
        }
    }
}

@Composable
fun NavAssetIcon(asset: String, selected: Boolean = false) {
    val bmp = rememberAssetBitmap(asset)
    Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(22.dp).alpha(if (selected) 1f else 0.72f))
        } else {
            Box(Modifier.size(7.dp).clip(CircleShape).background(if (selected) AgwColors.SacredGold else AgwColors.Sand))
        }
    }
}
