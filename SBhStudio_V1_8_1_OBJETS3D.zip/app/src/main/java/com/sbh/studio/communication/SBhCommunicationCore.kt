package com.sbh.studio.communication

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/**
 * SBh Communication Core
 *
 * Cœur central du système de communication et de rapports.
 * Indépendant de Minecraft et de SBh World.
 *
 * Responsabilités (Étape 1 — Communication Foundation) :
 * - Génération d'identifiants uniques d'export (SBH-YYYY-NNNNNN)
 * - Journal persistant des exports
 * - Suivi du statut des opérations
 * - Création et mise à jour des rapports SBhReport
 *
 * Les modules (Atelier, Map Studio, Factions, Mobs…) fournissent des données
 * à ce core, mais le diagnostic reste centralisé ici.
 */
class SBhCommunicationCore(private val context: Context) {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val journalFile: File
        get() = File(context.filesDir, "sbh_export_journal.json")

    private val sequenceFile: File
        get() = File(context.filesDir, "sbh_export_sequence.txt")

    private val reportsDir: File
        get() = File(context.filesDir, "sbh_reports").also { it.mkdirs() }

    private val sequence = AtomicLong(loadSequence())

    // -------------------------------------------------------------------------
    // Identifiant unique
    // -------------------------------------------------------------------------

    /** Génère le prochain identifiant d'export unique. */
    fun nextExportId(): ExportId {
        val next = sequence.incrementAndGet()
        persistSequence(next)
        return ExportId.generate(next)
    }

    private fun loadSequence(): Long {
        return try {
            if (sequenceFile.exists()) sequenceFile.readText().trim().toLongOrNull() ?: 0L
            else 0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun persistSequence(value: Long) {
        try {
            sequenceFile.parentFile?.mkdirs()
            sequenceFile.writeText(value.toString())
        } catch (_: Exception) {
            // non bloquant
        }
    }

    // -------------------------------------------------------------------------
    // Création de rapport
    // -------------------------------------------------------------------------

    /**
     * Crée un nouveau rapport pour un projet.
     * Doit être appelé au début d'un cycle d'export.
     */
    fun createReport(
        projectId: String,
        projectName: String,
        projectVersion: String = "",
        studioVersion: String = "",
        projectType: String = "Minecraft Bedrock Add-on"
    ): SBhReport {
        val exportId = nextExportId()
        val report = SBhReport(
            exportId = exportId,
            projectId = projectId,
            projectName = projectName,
            projectType = projectType,
            projectVersion = projectVersion,
            studioVersion = studioVersion,
            status = ExportStatus.PREPARING
        )
        // Enregistre immédiatement dans le journal
        appendToJournal(report)
        return report
    }

    // -------------------------------------------------------------------------
    // Mise à jour du rapport
    // -------------------------------------------------------------------------

    fun updateStatus(report: SBhReport, newStatus: ExportStatus): SBhReport {
        val updated = report.copy(status = newStatus)
        updateJournalEntry(updated)
        return updated
    }

    fun addEntry(report: SBhReport, entry: ReportEntry): SBhReport {
        val updated = report.copy(entries = report.entries + entry)
        updateJournalEntry(updated)
        return updated
    }

    fun addEntries(report: SBhReport, entries: List<ReportEntry>): SBhReport {
        val updated = report.copy(entries = report.entries + entries)
        updateJournalEntry(updated)
        return updated
    }

    fun setArchiveInfo(
        report: SBhReport,
        path: String?,
        sizeBytes: Long? = null,
        filesGenerated: Int? = null
    ): SBhReport {
        val updated = report.copy(
            archivePath = path,
            archiveSizeBytes = sizeBytes,
            filesGenerated = filesGenerated
        )
        updateJournalEntry(updated)
        return updated
    }

    // -------------------------------------------------------------------------
    // Journal (historique persistant)
    // -------------------------------------------------------------------------

    @Serializable
    private data class JournalData(
        val records: List<ExportRecord> = emptyList()
    )

    private fun loadJournal(): JournalData {
        return try {
            if (!journalFile.exists()) JournalData()
            else json.decodeFromString(journalFile.readText())
        } catch (_: Exception) {
            JournalData()
        }
    }

    private fun saveJournal(data: JournalData) {
        try {
            journalFile.parentFile?.mkdirs()
            val tmp = File(journalFile.parentFile, "${journalFile.name}.tmp")
            tmp.writeText(json.encodeToString(data))
            if (!tmp.renameTo(journalFile)) {
                journalFile.delete()
                tmp.renameTo(journalFile)
            }
        } catch (_: Exception) {
            // non bloquant pour l'instant
        }
    }

    private fun appendToJournal(report: SBhReport) {
        val data = loadJournal()
        val record = report.toRecord()
        // Évite les doublons (même exportId)
        val filtered = data.records.filter { it.exportId.value != report.exportId.value }
        saveJournal(JournalData(listOf(record) + filtered))
        persistFullReport(report)
    }

    private fun updateJournalEntry(report: SBhReport) {
        val data = loadJournal()
        val record = report.toRecord()
        val updated = data.records.map {
            if (it.exportId.value == report.exportId.value) record else it
        }
        // Si l'entrée n'existait pas encore, on l'ajoute
        val finalList = if (updated.any { it.exportId.value == report.exportId.value }) {
            updated
        } else {
            listOf(record) + updated
        }
        saveJournal(JournalData(finalList))
        persistFullReport(report)
    }

    private fun SBhReport.toRecord() = ExportRecord(
        exportId = exportId,
        projectId = projectId,
        projectName = projectName,
        createdAtMs = createdAtMs,
        status = status,
        errorCount = errorCount,
        warningCount = warningCount,
        infoCount = infoCount,
        criticalCount = criticalCount,
        archivePath = archivePath,
        reportSummary = shortStatus()
    )

    /** Persiste le rapport complet (entrées détaillées) pour l'écran de détail. */
    private fun persistFullReport(report: SBhReport) {
        try {
            val file = File(reportsDir, "${report.exportId.value}.json")
            val tmp = File(reportsDir, "${report.exportId.value}.json.tmp")
            tmp.writeText(json.encodeToString(report))
            if (!tmp.renameTo(file)) {
                file.delete()
                tmp.renameTo(file)
            }
        } catch (_: Exception) {
            // non bloquant
        }
    }

    /** Retourne l'historique complet (plus récent en premier) */
    fun getHistory(limit: Int = 100): List<ExportRecord> {
        return loadJournal().records.take(limit)
    }

    /** Retrouve un enregistrement résumé par son ID */
    fun findRecord(exportId: String): ExportRecord? {
        return loadJournal().records.find { it.exportId.value == exportId }
    }

    /**
     * Charge le rapport complet (avec toutes les ReportEntry) depuis le stockage persistant.
     * Retourne null si le fichier n'existe pas ou est illisible.
     */
    fun getReport(exportId: String): SBhReport? {
        return try {
            val file = File(reportsDir, "$exportId.json")
            if (!file.exists()) null
            else json.decodeFromString<SBhReport>(file.readText())
        } catch (_: Exception) {
            null
        }
    }

    // -------------------------------------------------------------------------
    // Helpers de création d'entrées de rapport
    // -------------------------------------------------------------------------

    fun info(step: LifecycleStep, title: String, detail: String = ""): ReportEntry =
        ReportEntry(level = ReportLevel.INFO, step = step, title = title, detail = detail)

    fun warning(
        step: LifecycleStep,
        title: String,
        detail: String = "",
        file: String? = null,
        cause: String? = null,
        suggestedFix: String? = null,
        code: SBhErrorCode? = null,
        autoRepairable: Boolean = false
    ): ReportEntry = ReportEntry(
        level = ReportLevel.WARNING,
        step = step,
        title = title,
        detail = detail,
        file = file,
        cause = cause,
        suggestedFix = suggestedFix,
        code = code,
        autoRepairable = autoRepairable
    )

    fun error(
        step: LifecycleStep,
        title: String,
        detail: String = "",
        file: String? = null,
        cause: String? = null,
        suggestedFix: String? = null,
        code: SBhErrorCode? = null,
        autoRepairable: Boolean = false
    ): ReportEntry = ReportEntry(
        level = ReportLevel.ERROR,
        step = step,
        title = title,
        detail = detail,
        file = file,
        cause = cause,
        suggestedFix = suggestedFix,
        code = code,
        autoRepairable = autoRepairable
    )

    fun critical(
        step: LifecycleStep,
        title: String,
        detail: String = "",
        file: String? = null,
        cause: String? = null,
        suggestedFix: String? = null,
        code: SBhErrorCode? = null
    ): ReportEntry = ReportEntry(
        level = ReportLevel.CRITICAL,
        step = step,
        title = title,
        detail = detail,
        file = file,
        cause = cause,
        suggestedFix = suggestedFix,
        code = code
    )

    // -------------------------------------------------------------------------
    // Formatage texte (pour Copier plus tard)
    // -------------------------------------------------------------------------

    fun formatAsText(report: SBhReport): String {
        val dateFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        val sb = StringBuilder()

        sb.appendLine("SBh DIAGNOSTIC REPORT")
        sb.appendLine("────────────────────────")
        sb.appendLine()
        sb.appendLine("Projet : ${report.projectName}")
        sb.appendLine("Type : ${report.projectType}")
        sb.appendLine("Version projet : ${report.projectVersion.ifBlank { "—" }}")
        sb.appendLine("Version SBh Studio : ${report.studioVersion.ifBlank { "—" }}")
        sb.appendLine("Date : ${dateFmt.format(Date(report.createdAtMs))}")
        sb.appendLine("Export : ${report.exportId}")
        sb.appendLine()
        sb.appendLine("RÉSULTAT")
        sb.appendLine(statusEmoji(report.status) + " ${report.status.name}")
        sb.appendLine(importNote(report.status))
        sb.appendLine()
        sb.appendLine("COMPTEURS")
        sb.appendLine("INFO=${report.infoCount}  WARNING=${report.warningCount}  ERROR=${report.errorCount}  CRITICAL=${report.criticalCount}")
        sb.appendLine()

        if (report.entries.isNotEmpty()) {
            sb.appendLine("DÉTAILS")
            report.entries.forEach { e ->
                val icon = when (e.level) {
                    ReportLevel.INFO -> "🟢"
                    ReportLevel.WARNING -> "🟡"
                    ReportLevel.ERROR -> "🔴"
                    ReportLevel.CRITICAL -> "⛔"
                }
                sb.appendLine("$icon ${e.title}")
                e.code?.let { sb.appendLine("   Code : ${it.code} (${it.shortName})") }
                sb.appendLine("   Niveau : ${e.level}")
                sb.appendLine("   Étape : ${e.step}")
                if (e.detail.isNotBlank()) sb.appendLine("   Détail : ${e.detail}")
                e.file?.let { sb.appendLine("   Fichier : $it") }
                e.cause?.let { sb.appendLine("   Cause : $it") }
                e.suggestedFix?.let { sb.appendLine("   Correction : $it") }
                if (e.autoRepairable) sb.appendLine("   Auto-réparable : oui")
                sb.appendLine()
            }
        }

        report.archivePath?.let {
            sb.appendLine("ARCHIVE")
            sb.appendLine("Chemin : $it")
            report.archiveSizeBytes?.let { size -> sb.appendLine("Taille : $size octets") }
            report.filesGenerated?.let { n -> sb.appendLine("Fichiers générés : $n") }
            sb.appendLine()
        }

        sb.appendLine("SBH_REPORT_ID: ${report.exportId}")
        return sb.toString().trimEnd()
    }

    /** Sérialisation JSON du SBhReport tel quel (même objet, pas une copie métier). */
    fun formatAsJson(report: SBhReport): String = json.encodeToString(report)

    /** Version HTML lisible dérivée du même SBhReport. */
    fun formatAsHtml(report: SBhReport): String {
        val dateFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        fun esc(s: String): String = s
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")

        val entriesHtml = report.entries.joinToString("\n") { e ->
            val levelClass = e.level.name.lowercase()
            val code = e.code?.let { "<div class=\"code\">${esc(it.code)} — ${esc(it.shortName)}</div>" } ?: ""
            val file = e.file?.let { "<div><b>Fichier :</b> ${esc(it)}</div>" } ?: ""
            val cause = e.cause?.let { "<div><b>Cause :</b> ${esc(it)}</div>" } ?: ""
            val fix = e.suggestedFix?.let { "<div class=\"fix\"><b>Correction :</b> ${esc(it)}</div>" } ?: ""
            val detail = if (e.detail.isNotBlank()) "<div>${esc(e.detail)}</div>" else ""
            """
            <div class="entry $levelClass">
              <div class="title">${esc(e.title)}</div>
              $code
              <div class="meta">Niveau : ${e.level} · Étape : ${e.step}</div>
              $detail
              $file
              $cause
              $fix
            </div>
            """.trimIndent()
        }

        return """
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>SBh Report ${esc(report.exportId.value)}</title>
<style>
  body { font-family: system-ui, sans-serif; background:#1A1612; color:#D8CBB0; margin:0; padding:16px; }
  h1 { color:#C9A227; margin:0 0 4px; }
  .sub { color:#E8D5A3; font-size:0.9rem; margin-bottom:16px; }
  .card { background:#2B2620cc; border:1px solid #C9A22766; border-radius:10px; padding:14px; margin-bottom:14px; }
  .badge { display:inline-block; padding:2px 8px; border-radius:6px; font-size:0.8rem; font-weight:600; }
  .entry { border-left:4px solid #666; padding:10px 12px; margin:10px 0; background:#1A161288; border-radius:6px; }
  .entry.info { border-color:#1F3A5F; }
  .entry.warning { border-color:#8C6A3F; }
  .entry.error { border-color:#6B1E1E; }
  .entry.critical { border-color:#9B1B1B; }
  .title { font-weight:700; color:#D8CBB0; }
  .code { font-family: monospace; color:#C9A227; font-size:0.85rem; margin:4px 0; }
  .meta { color:#E8D5A3; font-size:0.8rem; }
  .fix { color:#81C784; }
  .counts span { margin-right:10px; }
  footer { margin-top:20px; color:#8C6A3F; font-size:0.8rem; }
</style>
</head>
<body>
  <h1>SBh DIAGNOSTIC REPORT</h1>
  <div class="sub">${esc(report.exportId.value)}</div>
  <div class="card">
    <div><b>Projet :</b> ${esc(report.projectName)}</div>
    <div><b>Type :</b> ${esc(report.projectType)}</div>
    <div><b>Version projet :</b> ${esc(report.projectVersion.ifBlank { "—" })}</div>
    <div><b>SBh Studio :</b> ${esc(report.studioVersion.ifBlank { "—" })}</div>
    <div><b>Date :</b> ${esc(dateFmt.format(Date(report.createdAtMs)))}</div>
    <div><b>Statut :</b> ${statusEmoji(report.status)} ${report.status.name}</div>
    <div>${esc(importNote(report.status))}</div>
    <div class="counts" style="margin-top:8px">
      <span>INFO ${report.infoCount}</span>
      <span>WARNING ${report.warningCount}</span>
      <span>ERROR ${report.errorCount}</span>
      <span>CRITICAL ${report.criticalCount}</span>
    </div>
  </div>
  $entriesHtml
  <footer>SBH_REPORT_ID: ${esc(report.exportId.value)}</footer>
</body>
</html>
        """.trimIndent()
    }

    /** Nom de fichier suggéré pour export. */
    fun suggestedFileName(report: SBhReport, extension: String): String {
        val safe = report.projectName.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
        return "SBh_Report_${safe}_${report.exportId.value}.$extension"
    }

    private fun statusEmoji(status: ExportStatus): String = when (status) {
        ExportStatus.READY_TO_SEND, ExportStatus.IMPORT_CONFIRMED -> "🟢"
        ExportStatus.IMPORT_UNKNOWN, ExportStatus.IMPORT_PENDING -> "⏳"
        ExportStatus.BLOCKED, ExportStatus.FAILED -> "❌"
        ExportStatus.REPAIRED -> "🔧"
        else -> "•"
    }

    private fun importNote(status: ExportStatus): String = when (status) {
        ExportStatus.IMPORT_CONFIRMED -> "Import Minecraft : CONFIRMÉ"
        ExportStatus.IMPORT_UNKNOWN -> "Import Minecraft : NON CONFIRMÉ (SBh Studio ne peut pas l'observer)"
        ExportStatus.IMPORT_PENDING -> "Import Minecraft : en attente de confirmation"
        else -> "Import Minecraft : non applicable pour ce statut"
    }
}
