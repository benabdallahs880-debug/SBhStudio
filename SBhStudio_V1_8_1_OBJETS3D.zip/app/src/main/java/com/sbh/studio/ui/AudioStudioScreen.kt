package com.sbh.studio.ui

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.SbhSound
import com.sbh.studio.data.SoundEvents
import com.sbh.studio.data.SoundRepository
import java.util.concurrent.TimeUnit

/**
 * نشيد — Studio Audio SBh.
 *
 * - Lecteur intégré (MediaPlayer) pour les fichiers locaux
 * - Import via le sélecteur de documents Android (ogg / mp3 / m4a / wav)
 * - Bibliothèque + association à un projet
 * - Choix de l'événement Minecraft (remplacement musique de jeu)
 * - Les sons marqués « inclure dans le pack » sont exportés dans le Resource Pack
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioStudioScreen(
    back: () -> Unit,
    projectId: String? = null,
    projectName: String? = null
) {
    val context = LocalContext.current
    val repo = remember { SoundRepository(context) }

    var sounds by remember { mutableStateOf(repo.loadAll()) }
    var currentId by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableStateOf(0) }
    var durationMs by remember { mutableStateOf(0) }
    var showEventPickerFor by remember { mutableStateOf<SbhSound?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }

    fun refresh() {
        sounds = repo.loadAll()
    }

    fun stopPlayer() {
        try {
            player?.stop()
            player?.release()
        } catch (_: Exception) { }
        player = null
        isPlaying = false
        positionMs = 0
        durationMs = 0
        currentId = null
    }

    fun playSound(sound: SbhSound) {
        val file = repo.fileFor(sound) ?: run {
            Toast.makeText(context, "Fichier introuvable", Toast.LENGTH_SHORT).show()
            return
        }
        stopPlayer()
        try {
            val mp = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener {
                    isPlaying = false
                    positionMs = 0
                }
                setOnPreparedListener {
                    durationMs = it.duration
                    it.start()
                    isPlaying = true
                }
                prepareAsync()
            }
            player = mp
            currentId = sound.id
        } catch (e: Exception) {
            Toast.makeText(context, "Lecture impossible : ${e.message}", Toast.LENGTH_SHORT).show()
            stopPlayer()
        }
    }

    fun togglePlay(sound: SbhSound) {
        if (currentId == sound.id && isPlaying) {
            try {
                player?.pause()
                isPlaying = false
            } catch (_: Exception) { }
        } else if (currentId == sound.id && player != null) {
            try {
                player?.start()
                isPlaying = true
            } catch (_: Exception) { }
        } else {
            playSound(sound)
        }
    }

    // Ticker pour la barre de progression
    LaunchedEffect(isPlaying, currentId) {
        while (isPlaying && player != null) {
            try {
                positionMs = player?.currentPosition ?: 0
            } catch (_: Exception) { }
            kotlinx.coroutines.delay(400)
        }
    }

    DisposableEffect(Unit) {
        onDispose { stopPlayer() }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "nasheed"
        val result = repo.importFromUri(uri, name, projectId = projectId)
        if (result.sound != null) {
            refresh()
            val extra = when {
                result.convertedToOgg && result.sound.extension == "ogg" -> " · Ogg ✓"
                result.sound.extension == "ogg" -> " · Ogg"
                else -> " · ${result.sound.extension.uppercase()} (Ogg recommandé)"
            }
            Toast.makeText(context, "Importé : ${result.sound.name}$extra", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, result.message.ifBlank { "Échec de l'import" }, Toast.LENGTH_LONG).show()
        }
    }

    fun openQuranApp() {
        val launcher = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val chooser = Intent.createChooser(launcher, "Ouvrir une application Coran")
        try {
            context.startActivity(chooser)
        } catch (_: Exception) {
            Toast.makeText(context, "Aucune application disponible.", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareReminder() {
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_TEXT,
                "اتق الله فيما تسمع\n\nقال الله تعالى:\n﴿إِنَّ السَّمْعَ وَالْبَصَرَ وَالْفُؤَادَ كُلُّ أُولَٰئِكَ كَانَ عَنْهُ مَسْؤُولًا﴾\n\nالإسراء 17:36"
            )
        }
        context.startActivity(Intent.createChooser(share, "Partager le rappel"))
    }

    val displayed = if (projectId != null) {
        sounds.filter { it.projectId == null || it.projectId == projectId }
    } else {
        sounds
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("نشيد", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                        Text(
                            if (projectName != null) "Studio Audio · $projectName"
                            else "STUDIO AUDIO",
                            color = AgwColors.Sand,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                navigationIcon = {
                    TextButton(onClick = {
                        stopPlayer()
                        back()
                    }) { Text("‹", fontSize = 32.sp, color = AgwColors.PaleMarble) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // —— Rappel ——
                ForgeSectionCard(title = "اتق الله فيما تسمع") {
                    Text(
                        "﴿إِنَّ السَّمْعَ وَالْبَصَرَ وَالْفُؤَادَ كُلُّ أُولَٰئِكَ كَانَ عَنْهُ مَسْؤُولًا﴾",
                        color = AgwColors.PaleMarble,
                        fontSize = 16.sp,
                        lineHeight = 26.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "سورة الإسراء · 17:36",
                        color = AgwColors.DesertOchre,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                    GoldOutlineButton(
                        text = "مشاركة التذكير",
                        onClick = ::shareReminder,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // —— Actions principales ——
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    GoldPrimaryButton(
                        text = "＋ استيراد نشيد",
                        onClick = {
                            importLauncher.launch(
                                arrayOf(
                                    "audio/*",
                                    "audio/ogg",
                                    "audio/mpeg",
                                    "audio/mp4",
                                    "audio/wav",
                                    "application/ogg"
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )
                    GoldOutlineButton(
                        text = "قرآن",
                        onClick = ::openQuranApp,
                        modifier = Modifier.weight(0.55f)
                    )
                }

                // —— Lecteur courant ——
                val current = displayed.find { it.id == currentId }
                if (current != null) {
                    ForgeSectionCard(title = "▶ ${current.name}") {
                        Text(
                            "Événement : ${current.definitionKey()}",
                            color = AgwColors.Sand,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Spacer(Modifier.height(6.dp))
                        val progress = if (durationMs > 0) positionMs.toFloat() / durationMs else 0f
                        LinearProgressIndicator(
                            progress = { progress.coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = AgwColors.SacredGold,
                            trackColor = AgwColors.NightStone
                        )
                        Row(
                            Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(formatMs(positionMs), color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                            Text(formatMs(durationMs), color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GoldPrimaryButton(
                                text = if (isPlaying) "❚❚ إيقاف" else "▶ تشغيل",
                                onClick = { togglePlay(current) },
                                modifier = Modifier.weight(1f)
                            )
                            GoldOutlineButton(
                                text = "■",
                                onClick = { stopPlayer() },
                                modifier = Modifier.width(56.dp)
                            )
                        }
                    }
                }

                // —— Bibliothèque ——
                Text(
                    "المكتبة · ${displayed.size} ملف",
                    color = AgwColors.SacredGold,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Text(
                    "Cochez « Pack » pour inclure le son dans l'export Minecraft (remplacement de musique).",
                    color = AgwColors.Sand,
                    style = MaterialTheme.typography.labelSmall
                )

                if (displayed.isEmpty()) {
                    ForgeSectionCard(title = "Aucun fichier") {
                        Text(
                            "Importez un nasheed (ogg, mp3, m4a…) pour l'écouter ici et l'ajouter à vos packs de jeu.",
                            color = AgwColors.PaleMarble,
                            textAlign = TextAlign.Right
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize().padding(bottom = 12.dp)
                    ) {
                        items(displayed, key = { it.id }) { sound ->
                            SoundRow(
                                sound = sound,
                                isCurrent = sound.id == currentId,
                                isPlaying = sound.id == currentId && isPlaying,
                                onPlay = { togglePlay(sound) },
                                onTogglePack = {
                                    val updated = sound.copy(includeInPack = !sound.includeInPack)
                                    repo.update(updated)
                                    refresh()
                                },
                                onChooseEvent = { showEventPickerFor = sound },
                                onDelete = {
                                    if (currentId == sound.id) stopPlayer()
                                    repo.delete(sound.id)
                                    refresh()
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Dialogue choix d'événement Minecraft
    showEventPickerFor?.let { target ->
        EventPickerDialog(
            sound = target,
            onDismiss = { showEventPickerFor = null },
            onConfirm = { eventId, category ->
                val finalEvent = if (eventId == "custom") {
                    "sbh.music.${SbhSound.sanitize(target.fileName)}"
                } else {
                    eventId
                }
                repo.update(
                    target.copy(
                        soundEvent = finalEvent,
                        category = category
                    )
                )
                refresh()
                showEventPickerFor = null
                Toast.makeText(context, "Événement : $finalEvent", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
private fun SoundRow(
    sound: SbhSound,
    isCurrent: Boolean,
    isPlaying: Boolean,
    onPlay: () -> Unit,
    onTogglePack: () -> Unit,
    onChooseEvent: () -> Unit,
    onDelete: () -> Unit
) {
    val borderColor = if (isCurrent) AgwColors.SacredGold else AgwColors.Outline
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, AgwDecor.CardShape),
        shape = AgwDecor.CardShape,
        colors = CardDefaults.cardColors(containerColor = AgwColors.Panel)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (isPlaying) AgwColors.SacredGold else AgwColors.NightStone)
                        .clickable(onClick = onPlay),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (isPlaying) "❚❚" else "▶",
                        color = if (isPlaying) AgwColors.DeepNight else AgwColors.SacredGold,
                        fontSize = 14.sp
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        sound.name,
                        color = AgwColors.PaleMarble,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "${sound.extension.uppercase()} · ${sound.definitionKey()}",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = sound.includeInPack,
                    onClick = onTogglePack,
                    label = {
                        Text(
                            if (sound.includeInPack) "Pack ✓" else "Pack",
                            style = MaterialTheme.typography.labelSmall
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AgwColors.GoldMuted,
                        selectedLabelColor = AgwColors.GoldSoft,
                        containerColor = AgwColors.NightStone,
                        labelColor = AgwColors.Sand
                    )
                )
                TextButton(onClick = onChooseEvent) {
                    Text("Événement", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDelete) {
                    Text("حذف", color = AgwColors.Error, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EventPickerDialog(
    sound: SbhSound,
    onDismiss: () -> Unit,
    onConfirm: (eventId: String, category: String) -> Unit
) {
    var selected by remember {
        mutableStateOf(
            SoundEvents.PRESETS.find { it.id == sound.soundEvent }?.id
                ?: if (sound.soundEvent.startsWith("sbh.")) "custom" else sound.soundEvent
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AgwColors.Panel,
        title = {
            Text(
                "Remplacer / définir un son",
                color = AgwColors.SacredGold,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "« ${sound.name} » sera lié à l'événement Minecraft choisi et inclus dans le Resource Pack à l'export.",
                    color = AgwColors.Sand,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                SoundEvents.PRESETS.forEach { preset ->
                    val active = selected == preset.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (active) AgwColors.GoldMuted else AgwColors.NightStone)
                            .clickable { selected = preset.id }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = active,
                            onClick = { selected = preset.id },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = AgwColors.SacredGold,
                                unselectedColor = AgwColors.Sand
                            )
                        )
                        Column(Modifier.padding(start = 6.dp)) {
                            Text(preset.label, color = AgwColors.PaleMarble, fontWeight = FontWeight.Medium)
                            Text(preset.description, color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cat = when {
                    selected.startsWith("music") || selected.startsWith("record") || selected == "custom" -> "music"
                    selected.startsWith("ambient") -> "ambient"
                    else -> "music"
                }
                onConfirm(selected, cat)
            }) {
                Text("Valider", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler", color = AgwColors.Sand)
            }
        }
    )
}

private fun formatMs(ms: Int): String {
    if (ms <= 0) return "0:00"
    val m = TimeUnit.MILLISECONDS.toMinutes(ms.toLong())
    val s = TimeUnit.MILLISECONDS.toSeconds(ms.toLong()) % 60
    return "%d:%02d".format(m, s)
}
