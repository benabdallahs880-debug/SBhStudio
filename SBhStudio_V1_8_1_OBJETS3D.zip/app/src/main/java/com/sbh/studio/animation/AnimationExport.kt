package com.sbh.studio.animation

/**
 * Génère les JSON Bedrock (animations + controller) pour le Resource Pack.
 * V1 : animations procédurales basées sur speed / amplitude / soul (pas de timeline manuelle).
 */
object AnimationExport {

    fun animationJson(project: AnimationProject, identifier: String): String {
        val animId = identifier.replace(":", ".")
        val bonesIdle = boneMotion(project, AnimState.IDLE, gentle = true)
        val bonesWalk = boneMotion(project, AnimState.WALK, gentle = false)
        val bonesAttack = boneMotion(project, AnimState.ATTACK, strike = true)
        val bonesHurt = boneMotion(project, AnimState.HURT, flinch = true)

        fun anim(name: String, loop: Boolean, len: Float, bones: String) = """
      "animation.$animId.$name": {
        "loop": $loop,
        "animation_length": $len,
        "bones": $bones
      }""".trimIndent()

        val idle = project.states[AnimState.IDLE.name] ?: AnimStateParams()
        val walk = project.states[AnimState.WALK.name] ?: AnimStateParams()
        val attack = project.states[AnimState.ATTACK.name] ?: AnimStateParams()
        val hurt = project.states[AnimState.HURT.name] ?: AnimStateParams()

        return """
{
  "format_version": "1.8.0",
  "animations": {
${anim("idle", idle.loop, 2.0f / idle.speed.coerceAtLeast(0.25f), bonesIdle)},
${anim("walk", walk.loop, 1.0f / walk.speed.coerceAtLeast(0.25f), bonesWalk)},
${anim("attack", attack.loop, 0.6f / attack.speed.coerceAtLeast(0.25f), bonesAttack)},
${anim("hurt", hurt.loop, 0.4f / hurt.speed.coerceAtLeast(0.25f), bonesHurt)}
  }
}
""".trimIndent()
    }

    fun controllerJson(identifier: String): String {
        val animId = identifier.replace(":", ".")
        return """
{
  "format_version": "1.10.0",
  "animation_controllers": {
    "controller.animation.$animId.main": {
      "initial_state": "idle",
      "states": {
        "idle": {
          "animations": ["idle"],
          "transitions": [
            { "walk": "query.modified_move_speed > 0.1" },
            { "attack": "query.is_delayed_attacking || query.is_angry" },
            { "hurt": "query.is_hurt" }
          ]
        },
        "walk": {
          "animations": ["walk"],
          "transitions": [
            { "idle": "query.modified_move_speed <= 0.1" },
            { "attack": "query.is_delayed_attacking || query.is_angry" },
            { "hurt": "query.is_hurt" }
          ]
        },
        "attack": {
          "animations": ["attack"],
          "transitions": [
            { "idle": "!query.is_delayed_attacking && !query.is_angry" },
            { "hurt": "query.is_hurt" }
          ]
        },
        "hurt": {
          "animations": ["hurt"],
          "transitions": [
            { "idle": "!query.is_hurt" }
          ]
        }
      }
    }
  }
}
""".trimIndent()
    }

    private fun boneMotion(
        project: AnimationProject,
        state: AnimState,
        gentle: Boolean = false,
        strike: Boolean = false,
        flinch: Boolean = false
    ): String {
        val p = project.states[state.name] ?: AnimStateParams()
        val amp = p.amplitude.coerceIn(0.25f, 2f)
        val soul = runCatching { AnimSoul.valueOf(project.soul) }.getOrDefault(AnimSoul.GUARDIAN)
        val soulMul = when (soul) {
            AnimSoul.ASSASSIN -> 1.15f
            AnimSoul.BEAST -> 1.25f
            AnimSoul.MYSTIC -> 0.9f
            AnimSoul.DESERT -> 1.1f
            else -> 1f
        }
        val a = amp * soulMul
        return when {
            flinch -> """{
          "body": {
            "rotation": {
              "0.0": [0, 0, 0],
              "0.1": [${-8 * a}, 0, ${4 * a}],
              "0.4": [0, 0, 0]
            }
          },
          "head": {
            "rotation": {
              "0.0": [0, 0, 0],
              "0.1": [${-12 * a}, 0, 0],
              "0.4": [0, 0, 0]
            }
          }
        }"""
            strike -> """{
          "body": {
            "rotation": {
              "0.0": [0, 0, 0],
              "0.2": [${5 * a}, ${10 * a}, 0],
              "0.4": [${-5 * a}, ${-5 * a}, 0],
              "0.6": [0, 0, 0]
            }
          },
          "head": {
            "rotation": {
              "0.0": [0, 0, 0],
              "0.3": [${10 * a}, 0, 0],
              "0.6": [0, 0, 0]
            }
          }
        }"""
            gentle -> """{
          "body": {
            "position": {
              "0.0": [0, 0, 0],
              "1.0": [0, ${0.04 * a}, 0],
              "2.0": [0, 0, 0]
            }
          },
          "head": {
            "rotation": {
              "0.0": [0, 0, 0],
              "1.0": [${3 * a}, ${5 * a}, 0],
              "2.0": [0, 0, 0]
            }
          }
        }"""
            else -> """{
          "body": {
            "rotation": {
              "0.0": [0, 0, 0],
              "0.25": [0, 0, ${4 * a}],
              "0.5": [0, 0, 0],
              "0.75": [0, 0, ${-4 * a}],
              "1.0": [0, 0, 0]
            }
          },
          "head": {
            "rotation": {
              "0.0": [0, 0, 0],
              "0.5": [${2 * a}, 0, 0],
              "1.0": [0, 0, 0]
            }
          }
        }"""
        }
    }
}
