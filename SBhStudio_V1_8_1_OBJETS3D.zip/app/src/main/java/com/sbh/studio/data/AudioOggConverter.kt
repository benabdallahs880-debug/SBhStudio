package com.sbh.studio.data

import android.content.Context
import android.util.Log
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Conversion audio → Ogg Vorbis pour les Resource Packs Minecraft Bedrock.
 *
 * Stratégie (dans l'ordre) :
 * 1. Déjà .ogg → copie simple
 * 2. FFmpegKit (si la dépendance com.arthenica.ffmpegkit est présente au runtime)
 * 3. Binaire `ffmpeg` système (émulateur / debug rare)
 * 4. Échec → le fichier d'origine est conservé (export possible mais moins fiable)
 */
object AudioOggConverter {

    private const val TAG = "SBhOggConverter"

    data class Result(
        val success: Boolean,
        val output: File?,
        val message: String,
        /** true si le fichier final est bien du Ogg Vorbis */
        val isOgg: Boolean
    )

    fun isAlreadyOgg(file: File): Boolean {
        if (!file.extension.equals("ogg", ignoreCase = true)) return false
        // Signature OggS
        return try {
            file.inputStream().use { ins ->
                val header = ByteArray(4)
                val n = ins.read(header)
                n == 4 && header.contentEquals(byteArrayOf('O'.code.toByte(), 'g'.code.toByte(), 'g'.code.toByte(), 'S'.code.toByte()))
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Convertit [input] vers un fichier .ogg dans [outputDir].
     * Ne supprime pas [input].
     */
    fun convertToOgg(context: Context, input: File, outputDir: File, baseName: String): Result {
        if (!input.exists() || input.length() < 32) {
            return Result(false, null, "Fichier source invalide", false)
        }
        outputDir.mkdirs()
        val out = File(outputDir, "${baseName}.ogg")

        if (isAlreadyOgg(input)) {
            input.copyTo(out, overwrite = true)
            return Result(true, out, "Déjà en Ogg Vorbis", true)
        }

        // 1) FFmpegKit (réflexion — dépendance optionnelle)
        val kit = tryFfmpegKit(input, out)
        if (kit != null) return kit

        // 2) ffmpeg système
        val sys = trySystemFfmpeg(input, out)
        if (sys != null) return sys

        // 3) Échec de conversion : on ne renvoie pas de faux succès
        return Result(
            success = false,
            output = null,
            message = "Conversion Ogg indisponible sur cet appareil. Importez un fichier .ogg, ou ajoutez la dépendance ffmpeg-kit pour activer la conversion automatique.",
            isOgg = false
        )
    }

    private fun tryFfmpegKit(input: File, out: File): Result? {
        return try {
            val sessionClass = Class.forName("com.arthenica.ffmpegkit.FFmpegKit")
            val execute = sessionClass.getMethod("execute", String::class.java)
            // -y overwrite, -vn no video, libvorbis, quality ~4 (bon compromis taille/qualité)
            val cmd = "-y -i \"${input.absolutePath}\" -vn -c:a libvorbis -q:a 4 \"${out.absolutePath}\""
            val session = execute.invoke(null, cmd)
            val getReturnCode = session.javaClass.getMethod("getReturnCode")
            val returnCode = getReturnCode.invoke(session)
            val isValueSuccess = Class.forName("com.arthenica.ffmpegkit.ReturnCode")
                .getMethod("isValueSuccess", Class.forName("com.arthenica.ffmpegkit.ReturnCode"))
            val ok = isValueSuccess.invoke(null, returnCode) as Boolean
            if (ok && out.exists() && out.length() > 64) {
                Result(true, out, "Converti en Ogg (FFmpegKit)", true)
            } else {
                out.delete()
                Log.w(TAG, "FFmpegKit a échoué pour ${input.name}")
                null
            }
        } catch (e: ClassNotFoundException) {
            null // dépendance absente — normal
        } catch (e: Exception) {
            Log.w(TAG, "FFmpegKit erreur: ${e.message}")
            out.delete()
            null
        }
    }

    private fun trySystemFfmpeg(input: File, out: File): Result? {
        val ffmpeg = findFfmpegBinary() ?: return null
        return try {
            val pb = ProcessBuilder(
                ffmpeg,
                "-y",
                "-i", input.absolutePath,
                "-vn",
                "-c:a", "libvorbis",
                "-q:a", "4",
                out.absolutePath
            )
            pb.redirectErrorStream(true)
            val proc = pb.start()
            val finished = proc.waitFor(90, TimeUnit.SECONDS)
            if (!finished) {
                proc.destroyForcibly()
                out.delete()
                return null
            }
            if (proc.exitValue() == 0 && out.exists() && out.length() > 64) {
                Result(true, out, "Converti en Ogg (ffmpeg)", true)
            } else {
                out.delete()
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "ffmpeg système: ${e.message}")
            out.delete()
            null
        }
    }

    private fun findFfmpegBinary(): String? {
        val candidates = listOf(
            "ffmpeg",
            "/usr/bin/ffmpeg",
            "/system/bin/ffmpeg",
            "/data/local/tmp/ffmpeg"
        )
        for (c in candidates) {
            try {
                val p = ProcessBuilder(c, "-version").redirectErrorStream(true).start()
                val ok = p.waitFor(3, TimeUnit.SECONDS) && p.exitValue() == 0
                if (ok) return c
            } catch (_: Exception) { }
        }
        return null
    }
}
