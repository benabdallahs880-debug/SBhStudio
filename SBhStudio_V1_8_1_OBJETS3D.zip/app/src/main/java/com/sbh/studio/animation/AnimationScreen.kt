package com.sbh.studio.animation

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle
import kotlin.math.PI
import kotlin.math.sin

/**
 * Studio Animation V1 — presets d'âme, 4 états, liaison mob Atelier.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimationScreen(onBack: () -> Unit, onMessage: (String) -> Unit = {}) {
    val context = LocalContext.current
    val repo = remember { AnimationRepository(context) }
    val mobRepo = remember { MobRepository(context) }

    var projects by remember { mutableStateOf(repo.loadAll()) }
    var mobs by remember { mutableStateOf(mobRepo.loadAll()) }
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var name by rememberSaveable { mutableStateOf("Âme AGW") }
    var soulName by rememberSaveable { mutableStateOf(AnimSoul.DESERT.name) }
    var linkedMobId by rememberSaveable { mutableStateOf<String?>(null) }
    var activeState by rememberSaveable { mutableStateOf(AnimState.IDLE.name) }
    var speed by remember { mutableStateOf(1f) }
    var amplitude by remember { mutableStateOf(1f) }
    var weight by remember { mutableStateOf(1f) }
    var loop by remember { mutableStateOf(true) }
    var notes by rememberSaveable { mutableStateOf("") }
    var previewTick by remember { mutableStateOf(0f) }

    val soul = AnimSoul.entries.find { it.name == soulName } ?: AnimSoul.DESERT
    val stateEnum = AnimState.entries.find { it.name == activeState } ?: AnimState.IDLE

    // Preview animation loop
    LaunchedEffect(speed, activeState) {
        while (true) {
            kotlinx.coroutines.delay(32)
            previewTick = (previewTick + 0.032f * speed.coerceIn(0.25f, 2.5f)) % 100f
        }
    }

    fun loadStateParams(states: Map<String, AnimStateParams>) {
        val p = states[activeState] ?: AnimStateParams()
        speed = p.speed
        amplitude = p.amplitude
        weight = p.weight
        loop = p.loop
    }

    fun currentStates(): Map<String, AnimStateParams> {
        val base = if (editingId != null) {
            projects.find { it.id == editingId }?.states?.toMutableMap()
                ?: AnimationPresets.applySoul(soul).toMutableMap()
        } else {
            AnimationPresets.applySoul(soul).toMutableMap()
        }
        base[activeState] = AnimStateParams(speed, amplitude, weight, loop)
        return base
    }

    fun applySoulPreset(s: AnimSoul) {
        soulName = s.name
        val states = AnimationPresets.applySoul(s)
        loadStateParams(states)
        onMessage("Âme « ${s.label} » appliquée")
    }

    fun save() {
        val mob = mobs.find { it.id == linkedMobId }
        val states = currentStates()
        // merge all 4 states: keep others from existing or soul preset
        val full = AnimationPresets.applySoul(soul).toMutableMap()
        full.putAll(states)
        full[activeState] = AnimStateParams(speed, amplitude, weight, loop)
        val p = AnimationProject(
            id = editingId ?: java.util.UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Âme" },
            soul = soulName,
            linkedMobId = linkedMobId,
            linkedMobIdentifier = mob?.identifiant,
            states = full,
            notes = notes,
            updatedAt = System.currentTimeMillis()
        )
        val next = projects.filter { it.id != p.id } + p
        // Un mob = une âme principale
        val dedup = if (linkedMobId != null) {
            next.map {
                if (it.id != p.id && it.linkedMobId == linkedMobId) it.copy(linkedMobId = null, linkedMobIdentifier = null)
                else it
            }
        } else next
        projects = dedup
        repo.saveAll(dedup)
        editingId = p.id
        onMessage("Animation « ${p.name} » enregistrée" + (mob?.let { " → ${it.nom}" } ?: ""))
    }

    fun load(p: AnimationProject) {
        editingId = p.id
        name = p.name
        soulName = p.soul
        linkedMobId = p.linkedMobId
        notes = p.notes
        activeState = AnimState.IDLE.name
        loadStateParams(p.states)
    }

    fun reset() {
        editingId = null
        name = "Âme AGW"
        soulName = AnimSoul.DESERT.name
        linkedMobId = null
        notes = ""
        activeState = AnimState.IDLE.name
        loadStateParams(AnimationPresets.applySoul(AnimSoul.DESERT))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Studio Animation", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text("V1 · âme + 4 états · lien mob", color = AgwColors.Sand, fontSize = 11.sp)
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←", color = AgwColors.SacredGold) } },
                actions = {
                    TextButton({ save() }) { Text("Sauver", color = AgwColors.SacredGold) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                name, { name = it },
                label = { Text("Nom de l'âme") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = fieldColors()
            )

            SectionTitle("Âme (personnalité)")
            Text(soul.description, color = AgwColors.Sand, fontSize = 12.sp)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AnimSoul.entries.forEach { s ->
                    FilterChip(
                        selected = soulName == s.name,
                        onClick = { applySoulPreset(s) },
                        label = { Text(s.label, fontSize = 11.sp) }
                    )
                }
            }

            SectionTitle("État animé")
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AnimState.entries.forEach { st ->
                    FilterChip(
                        selected = activeState == st.name,
                        onClick = {
                            // save current state params into memory via speed/amp before switch
                            activeState = st.name
                            val existing = projects.find { it.id == editingId }?.states
                                ?: AnimationPresets.applySoul(soul)
                            val merged = existing.toMutableMap()
                            // keep what user set if same session - use currentStates partial
                            loadStateParams(merged)
                        },
                        label = { Text(st.label, fontSize = 12.sp) }
                    )
                }
            }

            SectionTitle("Réglages · ${stateEnum.label}")
            ParamSlider("Vitesse", speed, 0.25f, 2.5f) { speed = it }
            ParamSlider("Amplitude", amplitude, 0.25f, 2f) { amplitude = it }
            ParamSlider("Poids", weight, 0.4f, 1.6f) { weight = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(loop, { loop = it }, colors = CheckboxDefaults.colors(checkedColor = AgwColors.SacredGold))
                Text("Boucle", color = AgwColors.PaleMarble)
            }

            SectionTitle("Aperçu")
            SoulPreview(
                tick = previewTick,
                amplitude = amplitude,
                weight = weight,
                state = stateEnum,
                soul = soul
            )

            SectionTitle("Lier à un mob de l'Atelier")
            if (mobs.isEmpty()) {
                Text(
                    "Aucun mob. Crée-en dans Atelier → Mobs, puis reviens ici.",
                    color = AgwColors.Sand,
                    fontSize = 12.sp
                )
            } else {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = linkedMobId == null,
                        onClick = { linkedMobId = null },
                        label = { Text("Aucun", fontSize = 11.sp) }
                    )
                    mobs.forEach { m ->
                        FilterChip(
                            selected = linkedMobId == m.id,
                            onClick = {
                                linkedMobId = m.id
                                if (name == "Âme AGW" || name.startsWith("Âme ")) {
                                    name = "Âme · ${m.nom}"
                                }
                            },
                            label = { Text(m.nom, fontSize = 11.sp) }
                        )
                    }
                }
                linkedMobId?.let { id ->
                    val m = mobs.find { it.id == id }
                    if (m != null) {
                        Text(
                            "Lié : ${m.nom} (${m.identifiant})",
                            color = AgwColors.DesertOchre,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            OutlinedTextField(
                notes, { notes = it },
                label = { Text("Notes") },
                modifier = Modifier.fillMaxWidth(),
                colors = fieldColors()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldPrimaryButton("Enregistrer", onClick = { save() }, modifier = Modifier.weight(1f))
                GoldOutlineButton("Nouveau", onClick = { reset() }, modifier = Modifier.weight(1f))
            }

            SectionTitle("Animations enregistrées (${projects.size})")
            if (projects.isEmpty()) {
                Text("Aucune âme pour l'instant.", color = AgwColors.Sand, fontSize = 12.sp)
            } else {
                projects.sortedByDescending { it.updatedAt }.forEach { p ->
                    val mobLabel = mobs.find { it.id == p.linkedMobId }?.nom
                        ?: p.linkedMobIdentifier
                        ?: "—"
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                                Text(
                                    "${runCatching { AnimSoul.valueOf(p.soul).label }.getOrDefault(p.soul)} · mob: $mobLabel",
                                    color = AgwColors.Sand,
                                    fontSize = 11.sp
                                )
                            }
                            TextButton({ load(p) }) { Text("Ouvrir", color = AgwColors.GoldSoft) }
                            TextButton({
                                projects = projects.filter { it.id != p.id }
                                repo.saveAll(projects)
                                if (editingId == p.id) reset()
                                onMessage("Supprimé")
                            }) { Text("X", color = Color(0xFFB94E48)) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun ParamSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = AgwColors.PaleMarble, fontSize = 12.sp)
            Text("%.2f".format(value), color = AgwColors.SacredGold, fontSize = 12.sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = AgwColors.SacredGold,
                activeTrackColor = AgwColors.SacredGold,
                inactiveTrackColor = AgwColors.NightStone
            )
        )
    }
}

@Composable
private fun SoulPreview(
    tick: Float,
    amplitude: Float,
    weight: Float,
    state: AnimState,
    soul: AnimSoul
) {
    val t = tick * 2f * PI.toFloat()
    val amp = amplitude * 12f
    val bob = when (state) {
        AnimState.IDLE -> sin(t * 0.7f) * amp * 0.35f
        AnimState.WALK -> sin(t * 1.4f) * amp * 0.5f
        AnimState.ATTACK -> sin(t * 2f).coerceAtLeast(0f) * amp
        AnimState.HURT -> -sin(t * 3f).coerceAtLeast(0f) * amp * 0.8f
    }
    val lean = when (state) {
        AnimState.WALK -> sin(t * 1.4f) * amp * 0.15f * weight
        AnimState.ATTACK -> sin(t * 2f) * amp * 0.25f
        AnimState.HURT -> -amp * 0.2f
        else -> sin(t * 0.5f) * 2f
    }
    val accent = when (soul) {
        AnimSoul.ASSASSIN -> Color(0xFFAB47BC)
        AnimSoul.BEAST -> Color(0xFFB94E48)
        AnimSoul.MYSTIC -> Color(0xFF5DADE2)
        AnimSoul.DESERT -> AgwColors.SacredGold
        AnimSoul.MERCHANT -> Color(0xFF7AA66D)
        AnimSoul.GUARDIAN -> AgwColors.GoldSoft
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0A0E14))
            .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f + 20f + bob
            // ground
            drawLine(
                AgwColors.GoldSoft.copy(alpha = 0.25f),
                Offset(cx - 60f, cy + 55f),
                Offset(cx + 60f, cy + 55f),
                strokeWidth = 2f,
                cap = StrokeCap.Round
            )
            // body
            drawCircle(accent.copy(alpha = 0.9f), radius = 18f * weight.coerceIn(0.6f, 1.4f), center = Offset(cx + lean, cy))
            // head
            drawCircle(AgwColors.PaleMarble, radius = 12f, center = Offset(cx + lean * 0.5f, cy - 28f - bob * 0.2f))
            // legs
            val legSwing = if (state == AnimState.WALK || state == AnimState.ATTACK) sin(t * 1.4f) * 14f * amplitude else 0f
            drawLine(accent, Offset(cx + lean, cy + 16f), Offset(cx - 10f + legSwing, cy + 50f), 4f, StrokeCap.Round)
            drawLine(accent, Offset(cx + lean, cy + 16f), Offset(cx + 10f - legSwing, cy + 50f), 4f, StrokeCap.Round)
            // arms
            val arm = if (state == AnimState.ATTACK) sin(t * 2f) * 20f * amplitude else sin(t) * 6f
            drawLine(accent, Offset(cx + lean, cy - 4f), Offset(cx - 22f, cy + 10f + arm), 3.5f, StrokeCap.Round)
            drawLine(accent, Offset(cx + lean, cy - 4f), Offset(cx + 22f, cy + 10f - arm * 0.6f), 3.5f, StrokeCap.Round)
        }
        Text(
            state.label,
            color = AgwColors.Sand,
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AgwColors.SacredGold,
    unfocusedBorderColor = AgwColors.GoldSoft.copy(alpha = 0.4f),
    focusedTextColor = AgwColors.PaleMarble,
    unfocusedTextColor = AgwColors.PaleMarble
)
