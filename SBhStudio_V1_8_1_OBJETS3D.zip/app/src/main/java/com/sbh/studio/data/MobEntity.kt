package com.sbh.studio.data

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class MobEntity(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val nom: String,
    val identifiant: String,
    val vie: Int = 20,
    val vitesse: Double = 0.25,
    val degats: Int = 3,
    val hostile: Boolean = false,
    val poursuite: Boolean = false,
    val attaque: Boolean = false,
    val reactionDegats: Boolean = true,
    val pouvoirVitesse: Boolean = false,
    val pouvoirResistance: Boolean = false,
    val pouvoirInvisibilite: Boolean = false,
    // Atelier Mobs V0.8 : réglages avancés, tous rétrocompatibles grâce aux valeurs par défaut.
    val profilIA: String = "guerrier",
    val faction: String = "neutre",
    val detectionDistance: Double = 24.0,
    val vitesseAttaque: Double = 1.0,
    val cooldownAttaque: Double = 0.0,
    val collisionLargeur: Double = 0.6,
    val collisionHauteur: Double = 1.8,
    val textureUri: String? = null,
    val versionHistory: List<String> = listOf("v1 — création de la créature")
)
