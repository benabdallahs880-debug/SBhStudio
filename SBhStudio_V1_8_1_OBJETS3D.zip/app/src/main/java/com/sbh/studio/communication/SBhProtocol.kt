package com.sbh.studio.communication

import kotlinx.serialization.Serializable

/**
 * Protocole SBH — métadonnées embarquées dans les packs générés.
 *
 * Compatible Minecraft Bedrock : le fichier est placé dans un dossier
 * non standard (`sbh/`) que le moteur Minecraft ignore.
 * Le même schéma est prévu pour un futur SBh World (Godot).
 *
 * Ce n'est PAS une preuve d'import Minecraft.
 */
object SBhProtocol {
    const val NAME = "SBH"
    const val VERSION = "1.0"
    /** Chemin relatif dans le Behavior Pack (et optionnellement le Resource Pack). */
    const val PACK_PATH = "sbh/protocol.json"
    /** Préfixe extras PackGenerator : BP/sbh/protocol.json */
    const val BP_EXTRA_PATH = "BP/$PACK_PATH"
    const val RP_EXTRA_PATH = "RP/$PACK_PATH"
}

/**
 * Payload sérialisé dans sbh/protocol.json.
 * Les champs doivent correspondre exactement au SBhReport de l'opération.
 */
@Serializable
data class SBhProtocolPayload(
    val protocol: String = SBhProtocol.NAME,
    val protocolVersion: String = SBhProtocol.VERSION,
    val exportId: String,
    val projectId: String,
    val projectName: String,
    val projectVersion: String,
    val projectType: String = "Minecraft Bedrock Add-on",
    val studioVersion: String = "",
    val generatedAtMs: Long,
    val target: String = "minecraft_bedrock",
    /** Réservé : futur SBh World pourra lire le même fichier. */
    val compatibleTargets: List<String> = listOf("minecraft_bedrock", "sbh_world")
) {
    companion object {
        fun fromReport(report: SBhReport): SBhProtocolPayload = SBhProtocolPayload(
            exportId = report.exportId.value,
            projectId = report.projectId,
            projectName = report.projectName,
            projectVersion = report.projectVersion,
            projectType = report.projectType,
            studioVersion = report.studioVersion,
            generatedAtMs = report.createdAtMs
        )
    }
}
