package com.sbh.studio.security

import android.content.Context

/**
 * Clé temporaire de développement pour déverrouiller les fonctions de mise à jour.
 *
 * IMPORTANT : cette clé est volontairement embarquée dans l'APK pour la phase de
 * développement. Elle ne doit pas être considérée comme un secret de production.
 */
object SbhKeyManager {
    const val TEMPORARY_UPDATE_KEY = "SBH-2026-UPDATE-7391"

    private const val PREFS = "sbh_studio_security"
    private const val KEY_UNLOCKED = "update_key_unlocked"

    fun isValid(input: String): Boolean =
        input.trim() == TEMPORARY_UPDATE_KEY

    fun isUnlocked(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_UNLOCKED, false)

    fun unlock(context: Context, input: String): Boolean {
        val valid = isValid(input)
        if (valid) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_UNLOCKED, true)
                .apply()
        }
        return valid
    }

    fun lock(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_UNLOCKED, false)
            .apply()
    }
}
