package com.sbh.studio.texture

import kotlinx.serialization.Serializable
import java.util.UUID

/** Formats de texture supportés par le Studio Texture (optimisé mobile / Minecraft). */
enum class TextureFormat(
    val label: String,
    val width: Int,
    val height: Int,
    val description: String
) {
    BLOCK_16("Bloc 16×16", 16, 16, "Texture de bloc Minecraft standard"),
    ITEM_16("Item 16×16", 16, 16, "Objet / arme / outil"),
    BLOCK_32("Bloc 32×32", 32, 32, "Bloc haute résolution"),
    SKIN_64("Skin MC 64×64", 64, 64, "Skin Minecraft (Steve/Alex layout)"),
    CHAR_64("Perso 64×64", 64, 64, "Personnage / mob custom"),
    CHAR_128("Perso 128×128", 128, 128, "Personnage haute définition"),
    FILTER_MAP("Filtre monde 64×64", 64, 64, "Overlay / filtre de biome ou d'ambiance")
}

/** Filtres visuels applicables à toute la texture. */
enum class TextureFilter(val label: String) {
    NONE("Aucun"),
    BRIGHTEN("Éclaircir"),
    DARKEN("Assombrir"),
    CONTRAST("Contraste +"),
    INVERT("Inverser"),
    GRAYSCALE("Niveaux de gris"),
    SEPIA("Sépia désert"),
    GOTHIC("Teinte gothique"),
    OASIS("Teinte oasis"),
    POSTERIZE("Posteriser"),
    OUTLINE("Contour net")
}

@Serializable
data class TextureProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Nouvelle texture",
    val format: String = TextureFormat.BLOCK_16.name,
    /** Pixels ARGB empaquetés (ligne par ligne). Longueur = width * height. */
    val pixels: List<Int> = emptyList(),
    val width: Int = 16,
    val height: Int = 16,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/** Palette de couleurs rapide adaptée thème AGW / Minecraft. */
object TexturePalettes {
    val classic = listOf(
        0x00000000, // transparent
        0xFF000000.toInt(), 0xFF1A1A1A.toInt(), 0xFF4A4A4A.toInt(), 0xFF808080.toInt(),
        0xFFC0C0C0.toInt(), 0xFFFFFFFF.toInt(),
        0xFF8B4513.toInt(), 0xFFD2691E.toInt(), 0xFFF4A460.toInt(), 0xFFFFE4C4.toInt(),
        0xFF2E7D32.toInt(), 0xFF66BB6A.toInt(), 0xFFC9A227.toInt(), 0xFFFFD700.toInt(),
        0xFF1565C0.toInt(), 0xFF42A5F5.toInt(), 0xFF6A1B9A.toInt(), 0xFFAB47BC.toInt(),
        0xFFB71C1C.toInt(), 0xFFEF5350.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(),
        0xFF0D1117.toInt(), 0xFF151B22.toInt(), 0xFFD6B45A.toInt(), 0xFFB08A4B.toInt()
    )
    val desert = listOf(
        0x00000000,
        0xFF3E2723.toInt(), 0xFF5D4037.toInt(), 0xFF8D6E63.toInt(), 0xFFBCAAA4.toInt(),
        0xFFEFEBE9.toInt(), 0xFFFFCC80.toInt(), 0xFFFFB74D.toInt(), 0xFFFF8A65.toInt(),
        0xFFD4A017.toInt(), 0xFFC9A227.toInt(), 0xFF8B6914.toInt(), 0xFF5C4A1F.toInt(),
        0xFF2E7D32.toInt(), 0xFF1B5E20.toInt(), 0xFF0277BD.toInt(), 0xFF01579B.toInt()
    )
    val gothic = listOf(
        0x00000000,
        0xFF0D1117.toInt(), 0xFF1A1F2E.toInt(), 0xFF2A1A3A.toInt(), 0xFF3D2A4A.toInt(),
        0xFF5A3A6A.toInt(), 0xFFC9A227.toInt(), 0xFFD6B45A.toInt(), 0xFFF0D78A.toInt(),
        0xFF8B0000.toInt(), 0xFF4A0E0E.toInt(), 0xFF1C2833.toInt(), 0xFF566573.toInt(),
        0xFFE8E2D5.toInt(), 0xFFBDB4A3.toInt(), 0xFF6C3483.toInt(), 0xFF1A5276.toInt()
    )
}
