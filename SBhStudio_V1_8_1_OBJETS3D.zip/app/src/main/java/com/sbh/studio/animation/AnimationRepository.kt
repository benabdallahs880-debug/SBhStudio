package com.sbh.studio.animation

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

private val animJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

class AnimationRepository(private val context: Context) {
    private fun file() = File(context.filesDir, "sbh_animations.json")

    fun loadAll(): List<AnimationProject> = try {
        val f = file()
        if (!f.exists()) emptyList() else animJson.decodeFromString(f.readText())
    } catch (_: Exception) {
        emptyList()
    }

    fun saveAll(list: List<AnimationProject>) {
        val f = file()
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, "${f.name}.tmp")
        tmp.writeText(animJson.encodeToString(list))
        if (!tmp.renameTo(f)) {
            f.delete()
            tmp.renameTo(f)
        }
    }

    fun findForMob(mobId: String): AnimationProject? =
        loadAll().firstOrNull { it.linkedMobId == mobId }
}
