package com.sbh.studio.texture

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle
import kotlin.math.floor

enum class TexTool { PENCIL, ERASER, FILL, PICKER }

/**
 * Studio Texture — éditeur pixel mobile pour blocs, items, skins Minecraft et personnages.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextureScreen(onBack: () -> Unit, onMessage: (String) -> Unit = {}) {
    val context = LocalContext.current
    val repo = remember { TextureRepository(context) }

    var projects by remember { mutableStateOf(repo.loadAll()) }
    var format by rememberSaveable { mutableStateOf(TextureFormat.BLOCK_16.name) }
    var name by rememberSaveable { mutableStateOf("Texture AGW") }
    var tool by remember { mutableStateOf(TexTool.PENCIL) }
    var brushColor by remember { mutableStateOf(0xFFC9A227.toInt()) }
    var showGrid by rememberSaveable { mutableStateOf(true) }
    var showSkinGuide by rememberSaveable { mutableStateOf(true) }
    var paletteMode by rememberSaveable { mutableStateOf(0) } // 0 classic, 1 desert, 2 gothic
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }

    val fmt = TextureFormat.entries.find { it.name == format } ?: TextureFormat.BLOCK_16
    var pixels by remember(fmt) {
        mutableStateOf(TextureEngine.blankPixels(fmt.width, fmt.height))
    }
    // Historique simple (undo)
    var history by remember { mutableStateOf(listOf<List<Int>>()) }

    fun pushHistory() {
        history = (history + listOf(pixels)).takeLast(20)
    }

    fun undo() {
        if (history.isNotEmpty()) {
            pixels = history.last()
            history = history.dropLast(1)
        }
    }

    fun setPixel(x: Int, y: Int, color: Int) {
        if (x !in 0 until fmt.width || y !in 0 until fmt.height) return
        val i = y * fmt.width + x
        if (pixels[i] == color) return
        val next = pixels.toMutableList()
        next[i] = color
        pixels = next
    }

    fun paintAt(x: Int, y: Int) {
        when (tool) {
            TexTool.PENCIL -> setPixel(x, y, brushColor)
            TexTool.ERASER -> setPixel(x, y, 0x00000000)
            TexTool.FILL -> {
                pushHistory()
                val next = pixels.toMutableList()
                TextureEngine.floodFill(next, fmt.width, fmt.height, x, y, brushColor)
                pixels = next
            }
            TexTool.PICKER -> {
                if (x in 0 until fmt.width && y in 0 until fmt.height) {
                    val c = pixels[y * fmt.width + x]
                    if ((c ushr 24) != 0) brushColor = c
                }
            }
        }
    }

    fun applyFilter(f: TextureFilter) {
        if (f == TextureFilter.NONE) return
        pushHistory()
        pixels = TextureEngine.applyFilter(pixels, fmt.width, fmt.height, f)
        onMessage("Filtre « ${f.label} » appliqué")
    }

    fun newCanvas(f: TextureFormat) {
        format = f.name
        pixels = TextureEngine.blankPixels(f.width, f.height)
        history = emptyList()
        editingId = null
        name = when (f) {
            TextureFormat.SKIN_64 -> "Skin AGW"
            TextureFormat.FILTER_MAP -> "Filtre monde"
            TextureFormat.BLOCK_16, TextureFormat.BLOCK_32 -> "Bloc AGW"
            TextureFormat.ITEM_16 -> "Item AGW"
            else -> "Texture AGW"
        }
    }

    fun saveProject() {
        val p = TextureProject(
            id = editingId ?: java.util.UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Texture" },
            format = fmt.name,
            pixels = pixels,
            width = fmt.width,
            height = fmt.height,
            updatedAt = System.currentTimeMillis()
        )
        val next = projects.filter { it.id != p.id } + p
        projects = next
        repo.saveAll(next)
        editingId = p.id
        onMessage("Texture « ${p.name} » enregistrée")
    }

    fun loadProject(p: TextureProject) {
        editingId = p.id
        name = p.name
        format = p.format
        val f = TextureFormat.entries.find { it.name == p.format } ?: TextureFormat.BLOCK_16
        pixels = if (p.pixels.size == f.width * f.height) p.pixels
        else TextureEngine.blankPixels(f.width, f.height)
        history = emptyList()
    }

    fun exportPng() {
        val p = TextureProject(
            id = editingId ?: java.util.UUID.randomUUID().toString(),
            name = name, format = fmt.name, pixels = pixels,
            width = fmt.width, height = fmt.height
        )
        val file = repo.exportPng(p)
        if (file == null) {
            onMessage("Export impossible")
            return
        }
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Exporter la texture"))
            onMessage("PNG exporté : ${file.name}")
        } catch (e: Exception) {
            onMessage("PNG sauvé : ${file.name}")
        }
    }

    val palette = when (paletteMode) {
        1 -> TexturePalettes.desert
        2 -> TexturePalettes.gothic
        else -> TexturePalettes.classic
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Studio Texture", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text("${fmt.label} · ${fmt.width}×${fmt.height}", color = AgwColors.Sand, fontSize = 11.sp)
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←", color = AgwColors.SacredGold) } },
                actions = {
                    TextButton({ undo() }) { Text("↶", color = AgwColors.GoldSoft, fontSize = 18.sp) }
                    TextButton({ saveProject() }) { Text("Sauver", color = AgwColors.SacredGold) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 10.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Formats
            SectionTitle("Format")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextureFormat.entries.forEach { f ->
                    FilterChip(
                        selected = format == f.name,
                        onClick = { newCanvas(f) },
                        label = { Text(f.label, fontSize = 11.sp) }
                    )
                }
            }
            Text(fmt.description, color = AgwColors.Sand, fontSize = 11.sp)

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nom") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AgwColors.SacredGold,
                    unfocusedBorderColor = AgwColors.GoldSoft.copy(alpha = 0.4f),
                    focusedTextColor = AgwColors.PaleMarble,
                    unfocusedTextColor = AgwColors.PaleMarble
                )
            )

            // Outils
            SectionTitle("Outils")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ToolChip("✏️ Crayon", tool == TexTool.PENCIL) { tool = TexTool.PENCIL }
                ToolChip("🧽 Gomme", tool == TexTool.ERASER) { tool = TexTool.ERASER }
                ToolChip("🪣 Remplir", tool == TexTool.FILL) { tool = TexTool.FILL }
                ToolChip("💧 Pipette", tool == TexTool.PICKER) { tool = TexTool.PICKER }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = showGrid, onClick = { showGrid = !showGrid }, label = { Text("Grille", fontSize = 11.sp) })
                if (fmt == TextureFormat.SKIN_64) {
                    FilterChip(selected = showSkinGuide, onClick = { showSkinGuide = !showSkinGuide }, label = { Text("Guide skin", fontSize = 11.sp) })
                }
            }

            // Canvas pixel
            SectionTitle("Canevas")
            PixelCanvas(
                pixels = pixels,
                width = fmt.width,
                height = fmt.height,
                showGrid = showGrid,
                showSkinGuide = showSkinGuide && fmt == TextureFormat.SKIN_64,
                onPaint = { x, y ->
                    if (tool == TexTool.PENCIL || tool == TexTool.ERASER) {
                        // history once per stroke handled by drag start via callback
                    }
                    paintAt(x, y)
                },
                onStrokeStart = { pushHistory() }
            )

            // Couleur active
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(brushColor))
                        .border(2.dp, AgwColors.SacredGold, RoundedCornerShape(8.dp))
                )
                Text(
                    "#${(brushColor.toLong() and 0xFFFFFF).toString(16).padStart(6, '0').uppercase()}",
                    color = AgwColors.PaleMarble,
                    fontSize = 12.sp
                )
            }

            // Palettes
            SectionTitle("Palette")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = paletteMode == 0, onClick = { paletteMode = 0 }, label = { Text("Classique", fontSize = 11.sp) })
                FilterChip(selected = paletteMode == 1, onClick = { paletteMode = 1 }, label = { Text("Désert", fontSize = 11.sp) })
                FilterChip(selected = paletteMode == 2, onClick = { paletteMode = 2 }, label = { Text("Gothique", fontSize = 11.sp) })
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                palette.forEach { c ->
                    val isTransparent = (c ushr 24) == 0
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isTransparent) Color(0xFF1A1F28) else Color(c))
                            .border(
                                width = if (brushColor == c) 2.dp else 1.dp,
                                color = if (brushColor == c) AgwColors.SacredGold else AgwColors.GoldSoft.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable { brushColor = c },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isTransparent) Text("∅", color = AgwColors.Sand, fontSize = 10.sp)
                    }
                }
            }

            // Filtres monde / graphisme
            SectionTitle("Filtres & ambiance")
            Text("Applique un style global (monde, biome, mood) sans redessiner pixel par pixel.", color = AgwColors.Sand, fontSize = 11.sp)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TextureFilter.entries.filter { it != TextureFilter.NONE }.forEach { f ->
                    FilterChip(
                        selected = false,
                        onClick = { applyFilter(f) },
                        label = { Text(f.label, fontSize = 11.sp) }
                    )
                }
            }

            // Actions
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldPrimaryButton("Enregistrer", onClick = { saveProject() }, modifier = Modifier.weight(1f))
                GoldOutlineButton("Exporter PNG", onClick = { exportPng() }, modifier = Modifier.weight(1f))
            }
            GoldOutlineButton(
                "Nouveau canevas vide",
                onClick = { newCanvas(fmt) },
                modifier = Modifier.fillMaxWidth()
            )

            // Projets sauvegardés
            SectionTitle("Textures enregistrées (${projects.size})")
            if (projects.isEmpty()) {
                Text("Aucune texture pour l'instant. Dessine puis enregistre.", color = AgwColors.Sand, fontSize = 12.sp)
            } else {
                projects.sortedByDescending { it.updatedAt }.forEach { p ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            MiniPreview(p, Modifier.size(40.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold, fontSize = 13.sp)
                                Text("${p.width}×${p.height} · ${p.format}", color = AgwColors.Sand, fontSize = 11.sp)
                            }
                            TextButton({ loadProject(p) }) { Text("Ouvrir", color = AgwColors.GoldSoft) }
                            TextButton({
                                projects = projects.filter { it.id != p.id }
                                repo.saveAll(projects)
                                onMessage("Supprimé")
                            }) { Text("X", color = Color(0xFFB94E48)) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ToolChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 11.sp) }
    )
}

@Composable
private fun PixelCanvas(
    pixels: List<Int>,
    width: Int,
    height: Int,
    showGrid: Boolean,
    showSkinGuide: Boolean,
    onPaint: (Int, Int) -> Unit,
    onStrokeStart: () -> Unit
) {
    var strokeStarted by remember { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0A0E14))
            .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .pointerInput(width, height, pixels) {
                detectTapGestures { offset ->
                    val cellW = size.width / width.toFloat()
                    val cellH = size.height / height.toFloat()
                    val x = floor(offset.x / cellW).toInt()
                    val y = floor(offset.y / cellH).toInt()
                    onStrokeStart()
                    onPaint(x, y)
                }
            }
            .pointerInput(width, height) {
                detectDragGestures(
                    onDragStart = {
                        strokeStarted = false
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        if (!strokeStarted) {
                            onStrokeStart()
                            strokeStarted = true
                        }
                        val cellW = size.width / width.toFloat()
                        val cellH = size.height / height.toFloat()
                        val x = floor(change.position.x / cellW).toInt()
                        val y = floor(change.position.y / cellH).toInt()
                        onPaint(x, y)
                    },
                    onDragEnd = { strokeStarted = false }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cellW = this.size.width / width
            val cellH = this.size.height / height
            // Damier fond transparent
            val checker = Color(0xFF151A22)
            val checker2 = Color(0xFF0E1218)
            for (y in 0 until height) {
                for (x in 0 until width) {
                    val bg = if ((x + y) % 2 == 0) checker else checker2
                    drawRect(bg, Offset(x * cellW, y * cellH), Size(cellW + 0.5f, cellH + 0.5f))
                }
            }
            // Pixels
            if (pixels.size == width * height) {
                for (y in 0 until height) {
                    for (x in 0 until width) {
                        val c = pixels[y * width + x]
                        if ((c ushr 24) != 0) {
                            drawRect(
                                Color(c),
                                Offset(x * cellW, y * cellH),
                                Size(cellW + 0.5f, cellH + 0.5f)
                            )
                        }
                        if (showSkinGuide) {
                            TextureEngine.skinGuideOverlay(x, y)?.let { overlay ->
                                drawRect(
                                    Color(overlay),
                                    Offset(x * cellW, y * cellH),
                                    Size(cellW + 0.5f, cellH + 0.5f)
                                )
                            }
                        }
                    }
                }
            }
            // Grille
            if (showGrid && width <= 64) {
                val gridColor = Color(0x33C9A227)
                for (x in 0..width) {
                    drawLine(gridColor, Offset(x * cellW, 0f), Offset(x * cellW, this.size.height), strokeWidth = 1f)
                }
                for (y in 0..height) {
                    drawLine(gridColor, Offset(0f, y * cellH), Offset(this.size.width, y * cellH), strokeWidth = 1f)
                }
            }
            // Cadre
            drawRect(
                AgwColors.SacredGold.copy(alpha = 0.5f),
                topLeft = Offset.Zero,
                size = this.size,
                style = Stroke(width = 2f)
            )
        }
    }
}

@Composable
private fun MiniPreview(project: TextureProject, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF0A0E14))
            .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
    ) {
        val w = project.width.coerceAtLeast(1)
        val h = project.height.coerceAtLeast(1)
        val cellW = this.size.width / w
        val cellH = this.size.height / h
        if (project.pixels.size == w * h) {
            for (y in 0 until h) {
                for (x in 0 until w) {
                    val c = project.pixels[y * w + x]
                    if ((c ushr 24) != 0) {
                        drawRect(Color(c), Offset(x * cellW, y * cellH), Size(cellW + 0.5f, cellH + 0.5f))
                    }
                }
            }
        }
    }
}
