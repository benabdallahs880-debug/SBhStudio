package com.sbh.studio.communication

import kotlinx.serialization.Serializable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * SBh Communication Core — Modèles de base
 *
 * Ces modèles constituent le cœur du système de rapports et de suivi
 * du cycle de vie d'un export (Minecraft Bedrock ou futur SBh World).
 */

/** Niveau de gravité d'un élément de rapport */
@Serializable
enum class ReportLevel {
    INFO,       // 🟢 Information
    WARNING,    // 🟡 Avertissement
    ERROR,      // 🔴 Erreur
    CRITICAL    // ⛔ Critique (bloque l'import)
}

/** Étape du cycle de vie où un événement / erreur s'est produit */
@Serializable
enum class LifecycleStep {
    CREATE,
    ANALYZE,
    VALIDATE,
    EXPORT,
    TRANSMIT,
    IMPORT,
    VERIFY,
    REPORT,
    REPAIR,
    REEXPORT
}

/** Statut global d'un export */
@Serializable
enum class ExportStatus {
    PREPARING,          // En préparation
    VALIDATING,         // Validation en cours
    READY_TO_SEND,      // 🟢 Prêt à envoyer
    BLOCKED,            // 🔴 Export bloqué (erreurs critiques)
    EXPORTING,          // Génération de l'archive
    TRANSMITTING,       // Envoi vers Minecraft / SBh World
    IMPORT_PENDING,     // ⏳ En attente de confirmation d'import
    IMPORT_CONFIRMED,   // 🟢 Import confirmé
    IMPORT_UNKNOWN,     // ⚠ Confirmation impossible
    FAILED,             // Échec
    REPAIRED            // Réparé puis réexporté
}

/**
 * Identifiant unique d'export.
 * Format : SBH-YYYY-NNNNNN  (ex. SBH-2026-000027)
 */
@Serializable
data class ExportId(
    val value: String
) {
    companion object {
        private val YEAR_FORMAT = SimpleDateFormat("yyyy", Locale.US)

        fun generate(sequence: Long): ExportId {
            val year = YEAR_FORMAT.format(Date())
            return ExportId("SBH-$year-${sequence.toString().padStart(6, '0')}")
        }

        fun fromRaw(raw: String): ExportId? {
            val regex = Regex("""SBH-(\d{4})-(\d{6})""")
            return if (regex.matches(raw)) ExportId(raw) else null
        }
    }

    override fun toString(): String = value
}

/**
 * Code d'erreur structuré SBh.
 * Exemple : SBH-ERR-014
 */
@Serializable
data class SBhErrorCode(
    val code: String,           // "SBH-ERR-014"
    val shortName: String       // "Texture manquante"
) {
    companion object {
        // Codes de base (extensibles)
        val TEXTURE_MISSING     = SBhErrorCode("SBH-ERR-014", "Texture manquante")
        val MANIFEST_INVALID    = SBhErrorCode("SBH-ERR-001", "manifest.json invalide")
        val UUID_INVALID        = SBhErrorCode("SBH-ERR-002", "UUID invalide")
        val UUID_COLLISION      = SBhErrorCode("SBH-ERR-003", "Collision d'UUID")
        val IDENTIFIER_INVALID  = SBhErrorCode("SBH-ERR-010", "Identifiant invalide")
        val DEPENDENCY_MISSING  = SBhErrorCode("SBH-ERR-020", "Dépendance manquante")
        val FILE_MISSING        = SBhErrorCode("SBH-ERR-015", "Fichier manquant")
        val JSON_INVALID        = SBhErrorCode("SBH-ERR-030", "JSON invalide")
        val PACK_EMPTY          = SBhErrorCode("SBH-ERR-040", "Pack quasi vide")
        val EXPORT_FAILED       = SBhErrorCode("SBH-ERR-050", "Échec d'export")
        val IMPORT_FAILED       = SBhErrorCode("SBH-ERR-060", "Échec d'import")
        val UNKNOWN             = SBhErrorCode("SBH-ERR-999", "Erreur inconnue")
    }
}

/**
 * Entrée individuelle d'un rapport (erreur, avertissement, info…)
 */
@Serializable
data class ReportEntry(
    val id: String = UUID.randomUUID().toString(),
    val level: ReportLevel,
    val code: SBhErrorCode? = null,
    val step: LifecycleStep,
    val title: String,
    val detail: String = "",
    val file: String? = null,           // Fichier concerné
    val line: Int? = null,              // Ligne si disponible
    val cause: String? = null,
    val suggestedFix: String? = null,   // Correction proposée
    val autoRepairable: Boolean = false,
    val timestampMs: Long = System.currentTimeMillis()
)

/**
 * Rapport complet d'un export.
 * C'est l'objet central que l'on peut Copier / Télécharger / Partager.
 */
@Serializable
data class SBhReport(
    val exportId: ExportId,
    val projectId: String,
    val projectName: String,
    val projectType: String = "Minecraft Bedrock Add-on",
    val projectVersion: String = "",
    val studioVersion: String = "",
    val createdAtMs: Long = System.currentTimeMillis(),
    val status: ExportStatus = ExportStatus.PREPARING,
    val entries: List<ReportEntry> = emptyList(),
    val archivePath: String? = null,
    val archiveSizeBytes: Long? = null,
    val filesGenerated: Int? = null,
    val notes: String = ""
) {
    val errorCount: Int get() = entries.count { it.level == ReportLevel.ERROR || it.level == ReportLevel.CRITICAL }
    val warningCount: Int get() = entries.count { it.level == ReportLevel.WARNING }
    val infoCount: Int get() = entries.count { it.level == ReportLevel.INFO }
    val criticalCount: Int get() = entries.count { it.level == ReportLevel.CRITICAL }
    val hasBlockingErrors: Boolean get() = criticalCount > 0 || errorCount > 0

    /** Résumé court pour l'historique */
    fun shortStatus(): String = when {
        status == ExportStatus.IMPORT_CONFIRMED -> "🟢 OK"
        status == ExportStatus.READY_TO_SEND && !hasBlockingErrors -> "🟢 Prêt"
        hasBlockingErrors -> "❌ Erreur"
        warningCount > 0 -> "🟡 Avertissement"
        else -> status.name
    }
}

/**
 * Enregistrement dans le journal d'export (historique persistant)
 */
@Serializable
data class ExportRecord(
    val exportId: ExportId,
    val projectId: String,
    val projectName: String,
    val createdAtMs: Long,
    val status: ExportStatus,
    val errorCount: Int = 0,
    val warningCount: Int = 0,
    val infoCount: Int = 0,
    val criticalCount: Int = 0,
    val archivePath: String? = null,
    val reportSummary: String = ""
)
