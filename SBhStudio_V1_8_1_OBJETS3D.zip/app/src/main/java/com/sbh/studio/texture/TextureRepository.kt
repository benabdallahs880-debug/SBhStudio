package com.sbh.studio.texture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream

private val texJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

class TextureRepository(private val context: Context) {
    private fun file() = File(context.filesDir, "sbh_textures.json")
    private fun exportDir() = File(context.filesDir, "textures").also { it.mkdirs() }

    fun loadAll(): List<TextureProject> = try {
        val f = file()
        if (!f.exists()) emptyList() else texJson.decodeFromString(f.readText())
    } catch (_: Exception) {
        emptyList()
    }

    fun saveAll(list: List<TextureProject>) {
        val f = file()
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, "${f.name}.tmp")
        tmp.writeText(texJson.encodeToString(list))
        if (!tmp.renameTo(f)) {
            f.delete()
            tmp.renameTo(f)
        }
    }

    fun exportPng(project: TextureProject): File? {
        if (project.pixels.size != project.width * project.height) return null
        val bmp = Bitmap.createBitmap(project.width, project.height, Bitmap.Config.ARGB_8888)
        val px = IntArray(project.pixels.size) { project.pixels[it] }
        bmp.setPixels(px, 0, project.width, 0, 0, project.width, project.height)
        val out = File(exportDir(), "${sanitize(project.name)}_${project.width}x${project.height}.png")
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return out
    }

    private fun sanitize(name: String) =
        name.lowercase().replace(Regex("[^a-z0-9_\\-]+"), "_").take(40).ifBlank { "texture" }
}

/** Utilitaires pixels / filtres. */
object TextureEngine {

    fun blankPixels(w: Int, h: Int, fill: Int = 0x00000000): List<Int> =
        List(w * h) { fill }

    fun applyFilter(pixels: List<Int>, w: Int, h: Int, filter: TextureFilter): List<Int> {
        if (filter == TextureFilter.NONE || pixels.size != w * h) return pixels
        return when (filter) {
            TextureFilter.BRIGHTEN -> pixels.map { adjustBrightness(it, 30) }
            TextureFilter.DARKEN -> pixels.map { adjustBrightness(it, -30) }
            TextureFilter.CONTRAST -> pixels.map { adjustContrast(it, 1.35f) }
            TextureFilter.INVERT -> pixels.map { invert(it) }
            TextureFilter.GRAYSCALE -> pixels.map { grayscale(it) }
            TextureFilter.SEPIA -> pixels.map { tint(it, 0xFFC9A227.toInt(), 0.45f) }
            TextureFilter.GOTHIC -> pixels.map { tint(it, 0xFF2A1A3A.toInt(), 0.40f) }
            TextureFilter.OASIS -> pixels.map { tint(it, 0xFF2E7D32.toInt(), 0.35f) }
            TextureFilter.POSTERIZE -> pixels.map { posterize(it, 4) }
            TextureFilter.OUTLINE -> outline(pixels, w, h)
            TextureFilter.NONE -> pixels
        }
    }

    fun floodFill(pixels: MutableList<Int>, w: Int, h: Int, x: Int, y: Int, newColor: Int) {
        if (x !in 0 until w || y !in 0 until h) return
        val target = pixels[y * w + x]
        if (target == newColor) return
        val stack = ArrayDeque<Pair<Int, Int>>()
        stack.add(x to y)
        while (stack.isNotEmpty()) {
            val (cx, cy) = stack.removeLast()
            if (cx !in 0 until w || cy !in 0 until h) continue
            val i = cy * w + cx
            if (pixels[i] != target) continue
            pixels[i] = newColor
            stack.add(cx + 1 to cy)
            stack.add(cx - 1 to cy)
            stack.add(cx to cy + 1)
            stack.add(cx to cy - 1)
        }
    }

    private fun argb(c: Int): IntArray {
        val a = (c ushr 24) and 0xFF
        val r = (c ushr 16) and 0xFF
        val g = (c ushr 8) and 0xFF
        val b = c and 0xFF
        return intArrayOf(a, r, g, b)
    }

    private fun pack(a: Int, r: Int, g: Int, b: Int): Int =
        ((a and 0xFF) shl 24) or ((r and 0xFF) shl 16) or ((g and 0xFF) shl 8) or (b and 0xFF)

    private fun adjustBrightness(c: Int, delta: Int): Int {
        val (a, r, g, b) = argb(c)
        if (a == 0) return c
        fun clamp(v: Int) = v.coerceIn(0, 255)
        return pack(a, clamp(r + delta), clamp(g + delta), clamp(b + delta))
    }

    private fun adjustContrast(c: Int, factor: Float): Int {
        val (a, r, g, b) = argb(c)
        if (a == 0) return c
        fun adj(v: Int): Int {
            val x = ((v / 255f - 0.5f) * factor + 0.5f) * 255f
            return x.toInt().coerceIn(0, 255)
        }
        return pack(a, adj(r), adj(g), adj(b))
    }

    private fun invert(c: Int): Int {
        val (a, r, g, b) = argb(c)
        if (a == 0) return c
        return pack(a, 255 - r, 255 - g, 255 - b)
    }

    private fun grayscale(c: Int): Int {
        val (a, r, g, b) = argb(c)
        if (a == 0) return c
        val gray = (0.299 * r + 0.587 * g + 0.114 * b).toInt().coerceIn(0, 255)
        return pack(a, gray, gray, gray)
    }

    private fun tint(c: Int, tintColor: Int, amount: Float): Int {
        val (a, r, g, b) = argb(c)
        if (a == 0) return c
        val (_, tr, tg, tb) = argb(tintColor)
        fun mix(v: Int, t: Int) = ((v * (1f - amount) + t * amount).toInt()).coerceIn(0, 255)
        return pack(a, mix(r, tr), mix(g, tg), mix(b, tb))
    }

    private fun posterize(c: Int, levels: Int): Int {
        val (a, r, g, b) = argb(c)
        if (a == 0) return c
        val step = 255 / (levels - 1).coerceAtLeast(1)
        fun q(v: Int) = ((v + step / 2) / step * step).coerceIn(0, 255)
        return pack(a, q(r), q(g), q(b))
    }

    private fun outline(pixels: List<Int>, w: Int, h: Int): List<Int> {
        val out = pixels.toMutableList()
        val edge = 0xFF000000.toInt()
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val c = pixels[i]
                if ((c ushr 24) == 0) continue
                val neighbors = listOf(
                    x - 1 to y, x + 1 to y, x to y - 1, x to y + 1
                )
                val isEdge = neighbors.any { (nx, ny) ->
                    nx !in 0 until w || ny !in 0 until h || (pixels[ny * w + nx] ushr 24) == 0
                }
                if (isEdge) out[i] = edge
            }
        }
        return out
    }

    /** Guide des zones d'un skin Minecraft 64×64 (overlay léger, non destructif). */
    fun skinGuideOverlay(x: Int, y: Int): Int? {
        // Tête (8x8 face) autour de (8,8)
        val regions = listOf(
            // head front
            8 to 8, 16 to 16,
            // body
            20 to 20, 28 to 32,
            // right arm
            44 to 20, 48 to 32,
            // left arm
            36 to 52, 40 to 64,
            // right leg
            4 to 20, 8 to 32,
            // left leg
            20 to 52, 24 to 64
        )
        // Simple check: highlight head UV
        if (x in 8 until 16 && y in 8 until 16) return 0x33C9A227
        if (x in 20 until 28 && y in 20 until 32) return 0x332E7D32
        if (x in 44 until 48 && y in 20 until 32) return 0x331565C0
        if (x in 4 until 8 && y in 20 until 32) return 0x33B71C1C
        return null
    }
}
