package com.sbh.studio.workshop

import kotlinx.serialization.Serializable
import java.util.UUID

/** Zones de l'atelier SBh Studio */
enum class WorkshopZoneId {
    HUB,           // Accueil atelier / minimap
    MOBS,          // Création de monstres
    PORTALS,       // Portails Minecraft
    MAPS,          // Plans de map / structures
    BLOCKS,        // Blocs & architecture
    ITEMS,         // Objets & armes
    RECIPES,       // Recettes de craft
    SOUNDS,        // نشيد / Sons & musique de jeu
    EXPORT         // Validation & export
}

@Serializable
data class WorkshopBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val zone: String,           // WorkshopZoneId name
    val title: String,
    val notes: String = "",
    val meta: Map<String, String> = emptyMap(),
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class PortalBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val identifier: String = "agw:portal_custom",
    val width: Int = 4,
    val height: Int = 5,
    val frameBlock: String = "agw:night_bricks",
    val destinationHint: String = "Al-Zahra · الزهراء",
    // Coordonnées réelles de téléportation.
    val destX: Int = 0,
    val destY: Int = 64,
    val destZ: Int = 0,
    val destDimension: String = "minecraft:overworld",
    // Lien structurel avec une map de l'atelier.
    val linkedMapId: String? = null,
    val mapX: Int = 0,
    val mapY: Int = 64,
    val mapZ: Int = 0,
    /** Texture de cadre / portail depuis Studio Texture. */
    val frameTextureId: String? = null,
    val notes: String = ""
)

@Serializable
data class MapBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val sizeX: Int = 32,
    val sizeZ: Int = 32,
    val height: Int = 64,
    val theme: String = "desert_gothic",
    val terrain: String = "desert",
    val seed: Long = 0L,
    val worldX: Int = 0,
    val worldZ: Int = 0,
    val hasVillage: Boolean = true,
    val hasDungeon: Boolean = true,
    val hasOasis: Boolean = false,
    val hasMountains: Boolean = false,
    val hasRoads: Boolean = false,
    val dimension: String = "minecraft:overworld",
    /** Mobs de l'atelier placés / associés à cette map. */
    val linkedMobIds: List<String> = emptyList(),
    /** Items associés (loot / commerce). */
    val linkedItemIds: List<String> = emptyList(),
    /** Blocs de construction associés. */
    val linkedBlockIds: List<String> = emptyList(),
    /** Texture de filtre monde (Studio Texture). */
    val worldFilterTextureId: String? = null,
    val notes: String = ""
)

/** Recette de craft (shaped / shapeless) */
@Serializable
data class RecipeBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val identifier: String = "agw:recipe_custom",
    val type: String = "minecraft:recipe_shaped", // shaped | shapeless | furnace
    val resultId: String = "agw:item_custom",
    val resultCount: Int = 1,
    /** Grille 3x3 : 9 cases, "" = vide. Utilisé pour shaped. */
    val pattern: List<String> = listOf("", "", "", "", "", "", "", "", ""),
    /** Ingrédients shapeless (identifiants). */
    val ingredients: List<String> = emptyList(),
    val unlockHint: String = "",
    val notes: String = ""
)

/** Point sur la minimap (coordonnées logiques 0..100) */
data class MinimapPin(
    val id: String,
    val label: String,
    val x: Float,
    val y: Float,
    val zone: WorkshopZoneId,
    val colorHint: Long = 0xFFC9A227,
    val linkedMapId: String? = null
)

/** Template de contenu prêt à l'emploi */
data class WorkshopTemplate(
    val id: String,
    val name: String,
    val description: String,
    val theme: String,
    val iconColor: Long = 0xFFC9A227
)
