package com.sbh.studio.communication

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

/**
 * Transmission d'un .mcaddon vers Minecraft (ou une autre app capable).
 *
 * Mécanisme réel disponible sur Android :
 * - FileProvider → content:// URI
 * - Intent ACTION_VIEW + MIME application/mcaddon
 * - createChooser pour laisser l'utilisateur choisir Minecraft
 *
 * Ce qui EST observable :
 * - le fichier a été créé
 * - l'Intent a été lancé sans exception
 *
 * Ce qui N'EST PAS observable :
 * - Minecraft a ouvert le fichier
 * - Minecraft a accepté / refusé le pack
 * - le pack est installé dans le monde
 *
 * Aucune API publique Minecraft Bedrock (Android) ne notifie l'app source
 * du résultat d'import. Par conséquent le statut final reste IMPORT_UNKNOWN.
 */
object SBhTransmitter {

    data class TransmitResult(
        val launched: Boolean,
        val detail: String
    )

    /**
     * Prépare et lance le partage/ouverture du .mcaddon.
     * Ne met JAMAIS le rapport en IMPORT_CONFIRMED.
     */
    fun transmitMcaddon(
        context: Context,
        file: File,
        chooserTitle: String = "Ouvrir avec Minecraft"
    ): TransmitResult {
        if (!file.exists() || file.length() == 0L) {
            return TransmitResult(false, "Fichier absent ou vide : ${file.absolutePath}")
        }
        return try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/mcaddon")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, chooserTitle))
            TransmitResult(
                launched = true,
                detail = "Intent ACTION_VIEW lancé pour ${file.name}. " +
                    "Résultat d'import Minecraft non observable."
            )
        } catch (e: Exception) {
            TransmitResult(false, "Échec lancement Intent : ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * Met à jour le SBhReport après tentative de transmission.
     * Statut final : TRANSMITTING puis IMPORT_UNKNOWN (jamais IMPORT_CONFIRMED).
     */
    fun recordTransmission(
        core: SBhCommunicationCore,
        report: SBhReport,
        result: TransmitResult
    ): SBhReport {
        var r = core.updateStatus(report, ExportStatus.TRANSMITTING)
        if (result.launched) {
            r = core.addEntry(
                r,
                core.info(
                    LifecycleStep.TRANSMIT,
                    "Transmission lancée",
                    result.detail
                )
            )
            r = core.updateStatus(r, ExportStatus.IMPORT_UNKNOWN)
            r = core.addEntry(
                r,
                core.info(
                    LifecycleStep.IMPORT,
                    "Import non confirmé",
                    "SBh Studio n'a aucun moyen technique de vérifier si Minecraft a installé le pack. " +
                        "Statut : IMPORT_UNKNOWN."
                )
            )
        } else {
            r = core.addEntry(
                r,
                core.error(
                    step = LifecycleStep.TRANSMIT,
                    title = "Transmission échouée",
                    detail = result.detail,
                    code = SBhErrorCode.EXPORT_FAILED
                )
            )
            r = core.updateStatus(r, ExportStatus.FAILED)
        }
        return r
    }
}
