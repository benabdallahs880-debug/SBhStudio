package com.sbh.studio.animation

import kotlinx.serialization.Serializable
import java.util.UUID

/** États de vie supportés en V1. */
enum class AnimState(val label: String, val bedKey: String) {
    IDLE("Repos", "idle"),
    WALK("Marche", "walk"),
    ATTACK("Attaque", "attack"),
    HURT("Blessé", "hurt")
}

/** Personnalité / âme qui module les presets. */
enum class AnimSoul(val label: String, val description: String) {
    GUARDIAN("Garde", "Posture droite, gestes mesurés"),
    MERCHANT("Marchand", "Souple, accueillant"),
    ASSASSIN("Assassin", "Rapide, bas, nerveux"),
    BEAST("Bête", "Lourd, agressif"),
    MYSTIC("Mystique", "Flottant, rituel"),
    DESERT("Esprit du désert", "Large, majestueux")
}

@Serializable
data class AnimStateParams(
    val speed: Float = 1f,       // 0.25 .. 2.5
    val amplitude: Float = 1f,   // 0.25 .. 2
    val weight: Float = 1f,      // “poids” du mouvement
    val loop: Boolean = true
)

@Serializable
data class AnimationProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Nouvelle âme",
    val soul: String = AnimSoul.GUARDIAN.name,
    /** Mob Atelier lié (id interne MobEntity). */
    val linkedMobId: String? = null,
    val linkedMobIdentifier: String? = null,
    val states: Map<String, AnimStateParams> = defaultStates(),
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        fun defaultStates(): Map<String, AnimStateParams> = mapOf(
            AnimState.IDLE.name to AnimStateParams(speed = 0.8f, amplitude = 0.6f, weight = 1f, loop = true),
            AnimState.WALK.name to AnimStateParams(speed = 1.1f, amplitude = 1f, weight = 1f, loop = true),
            AnimState.ATTACK.name to AnimStateParams(speed = 1.3f, amplitude = 1.2f, weight = 1.1f, loop = false),
            AnimState.HURT.name to AnimStateParams(speed = 1.4f, amplitude = 0.9f, weight = 0.8f, loop = false)
        )
    }
}

object AnimationPresets {
    fun applySoul(soul: AnimSoul): Map<String, AnimStateParams> {
        val base = AnimationProject.defaultStates().toMutableMap()
        when (soul) {
            AnimSoul.GUARDIAN -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.7f, 0.5f, 1.2f, true)
                base[AnimState.WALK.name] = AnimStateParams(0.95f, 0.85f, 1.2f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.15f, 1.1f, 1.3f, false)
            }
            AnimSoul.MERCHANT -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.9f, 0.7f, 0.8f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.0f, 0.9f, 0.8f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.1f, 0.9f, 0.7f, false)
            }
            AnimSoul.ASSASSIN -> {
                base[AnimState.IDLE.name] = AnimStateParams(1.1f, 0.55f, 0.6f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.4f, 1.0f, 0.7f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.6f, 1.35f, 0.7f, false)
            }
            AnimSoul.BEAST -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.75f, 0.9f, 1.4f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.0f, 1.2f, 1.4f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.35f, 1.5f, 1.5f, false)
            }
            AnimSoul.MYSTIC -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.65f, 0.85f, 0.5f, true)
                base[AnimState.WALK.name] = AnimStateParams(0.85f, 0.95f, 0.5f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.0f, 1.15f, 0.6f, false)
            }
            AnimSoul.DESERT -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.75f, 0.75f, 1.1f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.05f, 1.1f, 1.1f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.25f, 1.3f, 1.2f, false)
            }
        }
        base[AnimState.HURT.name] = AnimStateParams(1.4f, 0.95f, 0.9f, false)
        return base
    }
}
