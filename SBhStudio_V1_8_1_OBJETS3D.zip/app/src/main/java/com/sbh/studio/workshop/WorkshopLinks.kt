package com.sbh.studio.workshop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.texture.TextureLink
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.SectionTitle

/**
 * Sélecteur de texture du Studio Texture pour Mobs / Items / Blocs.
 */
@Composable
fun StudioTexturePicker(
    textures: List<TextureProject>,
    selectedUri: String?,
    onSelect: (String?) -> Unit,
    preferredFormats: List<String> = emptyList()
) {
    val filtered = if (preferredFormats.isEmpty()) textures
    else textures.filter { it.format in preferredFormats }.ifEmpty { textures }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            "Texture Studio (${filtered.size})",
            color = AgwColors.SacredGold,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp
        )
        if (filtered.isEmpty()) {
            Text(
                "Aucune texture. Crée-en dans Accueil → Textures, puis reviens ici.",
                color = AgwColors.Sand,
                fontSize = 11.sp
            )
        } else {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Option aucune
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(AgwColors.NightStone)
                        .border(
                            width = if (selectedUri == null) 2.dp else 1.dp,
                            color = if (selectedUri == null) AgwColors.SacredGold else AgwColors.GoldSoft.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { onSelect(null) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("∅", color = AgwColors.Sand, fontSize = 14.sp)
                }
                filtered.forEach { t ->
                    val uri = TextureLink.uriFor(t.id)
                    val selected = selectedUri == uri
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0A0E14))
                                .border(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) AgwColors.SacredGold else AgwColors.GoldSoft.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelect(uri) }
                        ) {
                            // Mini pixels
                            androidx.compose.foundation.Canvas(Modifier.fillMaxSize().padding(4.dp)) {
                                val w = t.width.coerceAtLeast(1)
                                val h = t.height.coerceAtLeast(1)
                                if (t.pixels.size == w * h) {
                                    val cw = size.width / w
                                    val ch = size.height / h
                                    for (y in 0 until h step maxOf(1, h / 16)) {
                                        for (x in 0 until w step maxOf(1, w / 16)) {
                                            val c = t.pixels[y * w + x]
                                            if ((c ushr 24) != 0) {
                                                drawRect(
                                                    Color(c),
                                                    androidx.compose.ui.geometry.Offset(x * cw, y * ch),
                                                    androidx.compose.ui.geometry.Size(cw * maxOf(1, w / 16) + 0.5f, ch * maxOf(1, h / 16) + 0.5f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Text(t.name.take(8), color = AgwColors.PaleMarble, fontSize = 8.sp, maxLines = 1)
                    }
                }
            }
        }
        if (selectedUri != null) {
            Text(
                if (TextureLink.isStudioUri(selectedUri)) "Liée au Studio Texture"
                else "Fichier externe",
                color = AgwColors.DesertOchre,
                fontSize = 10.sp
            )
        }
    }
}

/**
 * Sélecteur multi pour lier des contenus (mobs/items/blocs) à une map.
 */
@Composable
fun <T> LinkChipRow(
    title: String,
    all: List<T>,
    selectedIds: List<String>,
    idOf: (T) -> String,
    labelOf: (T) -> String,
    onToggle: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = AgwColors.SacredGold, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        if (all.isEmpty()) {
            Text("Aucun élément disponible dans l'atelier.", color = AgwColors.Sand, fontSize = 11.sp)
        } else {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                all.forEach { item ->
                    val id = idOf(item)
                    FilterChip(
                        selected = id in selectedIds,
                        onClick = { onToggle(id) },
                        label = { Text(labelOf(item), fontSize = 11.sp) }
                    )
                }
            }
        }
    }
}

/** Résumé des connexions projet pour le Hub. */
@Composable
fun WorkshopConnectionPanel(
    maps: List<MapBlueprint>,
    portals: List<PortalBlueprint>,
    mobs: List<MobEntity>,
    items: List<SbhItem>,
    blocks: List<SbhBlock>,
    recipes: List<RecipeBlueprint>,
    textures: List<TextureProject>
) {
    val linkedPortals = portals.count { it.linkedMapId != null }
    val mapsWithMobs = maps.count { it.linkedMobIds.isNotEmpty() }
    val mapsWithFilter = maps.count { !it.worldFilterTextureId.isNullOrBlank() }
    val entitiesWithTex = mobs.count { !it.textureUri.isNullOrBlank() } +
        items.count { !it.textureUri.isNullOrBlank() } +
        blocks.count { !it.textureUri.isNullOrBlank() }
    val recipesLinked = recipes.count { r -> items.any { it.identifier == r.resultId } }

    SectionTitle("Connexions de l'atelier")
    Text(
        "Tout le contenu du projet est relié : maps ↔ portails ↔ mobs/items/blocs ↔ textures ↔ recettes.",
        color = AgwColors.Sand,
        fontSize = 11.sp
    )
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AgwColors.NightStone)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        ConnLine("Maps", "${maps.size}")
        ConnLine("Portails liés à une map", "$linkedPortals / ${portals.size}")
        ConnLine("Maps avec mobs associés", "$mapsWithMobs / ${maps.size}")
        ConnLine("Maps avec filtre texture", "$mapsWithFilter / ${maps.size}")
        ConnLine("Entités texturées (mobs/items/blocs)", "$entitiesWithTex")
        ConnLine("Recettes → item du projet", "$recipesLinked / ${recipes.size}")
        ConnLine("Textures Studio disponibles", "${textures.size}")
    }

    // Détail map → portails / mobs
    maps.take(5).forEach { map ->
        val pCount = portals.count { it.linkedMapId == map.id }
        val mNames = mobs.filter { it.id in map.linkedMobIds }.joinToString { it.nom }.ifBlank { "—" }
        Text(
            "🗺 ${map.name} · ${pCount} portail(s) · mobs: $mNames",
            color = AgwColors.PaleMarble,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun ConnLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = AgwColors.Sand, fontSize = 11.sp)
        Text(value, color = AgwColors.SacredGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}
