package com.sbh.studio.debug

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sbh.studio.data.RuntimeErrorRecord
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle
import kotlinx.coroutines.launch

/**
 * Écran Outils de débogage.
 *
 * Onglets :
 * 1. Journal   — événements runtime en direct
 * 2. Erreurs   — dernière erreur capturée + actions
 * 3. Stockage  — inspection fichiers locaux
 * 4. Actions   — dump, clear cache, inject test error
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DebugScreen(onBack: () -> Unit, onMessage: (String) -> Unit = {}) {
    val context = LocalContext.current
    val tools = remember { DebugTools(context) }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var events by remember { mutableStateOf(tools.recentEvents(60)) }
    var lastError by remember { mutableStateOf(tools.lastError()) }
    var storage by remember { mutableStateOf(tools.listStorage(2)) }
    var dumpPreview by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun refresh() {
        events = tools.recentEvents(60)
        lastError = tools.lastError()
        storage = tools.listStorage(2)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Outils de débogage", color = AgwColors.SacredGold) },
                navigationIcon = { TextButton(onBack) { Text("←", color = AgwColors.SacredGold) } },
                actions = {
                    TextButton({ refresh(); onMessage("Actualisé") }) {
                        Text("↻", color = AgwColors.GoldSoft)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 12.dp)
        ) {
            TabRow(
                selectedTabIndex = tab,
                containerColor = AgwColors.NightStone,
                contentColor = AgwColors.SacredGold
            ) {
                listOf("Journal", "Erreurs", "Stockage", "Actions").forEachIndexed { i, label ->
                    Tab(
                        selected = tab == i,
                        onClick = { tab = i },
                        text = { Text(label, fontSize = 12.sp) }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            when (tab) {
                0 -> JournalTab(events) {
                    tools.logEvent("MANUAL", it)
                    refresh()
                }
                1 -> ErrorsTab(
                    error = lastError,
                    onClear = {
                        tools.clearLastError()
                        refresh()
                        onMessage("Erreur effacée")
                    },
                    onCopy = { text ->
                        copyToClipboard(context, text)
                        onMessage("Copié dans le presse-papiers")
                    }
                )
                2 -> StorageTab(storage, tools.storageBytesUsed(), tools.workshopCounts())
                3 -> ActionsTab(
                    busy = busy,
                    dumpPreview = dumpPreview,
                    onClearLogs = {
                        tools.clearEventLog()
                        refresh()
                        onMessage("Journal vidé")
                    },
                    onClearCache = {
                        val n = tools.clearTempCaches()
                        refresh()
                        onMessage("Cache nettoyé ($n)")
                    },
                    onInjectError = {
                        tools.injectTestError()
                        refresh()
                        tab = 1
                        onMessage("Erreur de test injectée")
                    },
                    onBuildDump = {
                        busy = true
                        scope.launch {
                            val dump = tools.buildFullDump()
                            dumpPreview = dump.fullText.take(4000)
                            val file = tools.exportDumpToFile(dump)
                            busy = false
                            refresh()
                            onMessage("Dump enregistré : ${file.name}")
                        }
                    },
                    onShareDump = {
                        busy = true
                        scope.launch {
                            val dump = tools.buildFullDump()
                            val file = tools.exportDumpToFile(dump)
                            busy = false
                            shareFile(context, file, "text/plain")
                        }
                    },
                    onCopyDump = {
                        busy = true
                        scope.launch {
                            val dump = tools.buildFullDump()
                            copyToClipboard(context, dump.fullText)
                            busy = false
                            onMessage("Dump copié")
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun JournalTab(events: List<String>, onAddNote: (String) -> Unit) {
    var note by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Note manuelle…", fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AgwColors.SacredGold,
                    unfocusedBorderColor = AgwColors.GoldSoft.copy(alpha = 0.4f),
                    focusedTextColor = AgwColors.PaleMarble,
                    unfocusedTextColor = AgwColors.PaleMarble
                )
            )
            GoldOutlineButton("Ajouter", onClick = {
                if (note.isNotBlank()) {
                    onAddNote(note.trim())
                    note = ""
                }
            })
        }
        Spacer(Modifier.height(8.dp))
        SectionTitle("Événements récents (${events.size})")
        Column(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF0E1218))
                .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                .padding(10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (events.isEmpty()) {
                Text("Aucun événement enregistré.", color = AgwColors.Sand, fontSize = 12.sp)
            } else {
                events.asReversed().forEach { line ->
                    Text(
                        line,
                        color = AgwColors.PaleMarble,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ErrorsTab(
    error: RuntimeErrorRecord?,
    onClear: () -> Unit,
    onCopy: (String) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SectionTitle("Dernière erreur runtime")
        if (error == null) {
            Text("Aucune erreur capturée. Tout est calme.", color = AgwColors.Sand)
        } else {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1212)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(error.errorId, fontWeight = FontWeight.Bold, color = Color(0xFFE57373))
                    Text(error.name, color = AgwColors.SacredGold)
                    Text(error.message, color = AgwColors.PaleMarble, fontSize = 13.sp)
                    HorizontalDivider(color = AgwColors.GoldSoft.copy(alpha = 0.3f))
                    InfoLine("Module", error.module ?: "—")
                    InfoLine("Fichier", error.filename ?: "—")
                    InfoLine("Ligne", error.line?.toString() ?: "—")
                    InfoLine("Action", error.action ?: "—")
                    InfoLine("État", error.state ?: "—")
                    if (!error.interpretation.isNullOrBlank()) {
                        Text("Interprétation", fontWeight = FontWeight.Bold, color = AgwColors.DesertOchre, fontSize = 12.sp)
                        Text(error.interpretation!!, color = AgwColors.Sand, fontSize = 12.sp)
                    }
                    if (error.recentActions.isNotEmpty()) {
                        Text("Journal lié", fontWeight = FontWeight.Bold, color = AgwColors.DesertOchre, fontSize = 12.sp)
                        error.recentActions.takeLast(8).forEach {
                            Text(it, color = AgwColors.PaleMarble, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldPrimaryButton("Copier le rapport", onClick = { onCopy(error.developerReport()) }, modifier = Modifier.weight(1f))
                GoldOutlineButton("Effacer", onClick = onClear, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row {
        Text("$label : ", color = AgwColors.DesertOchre, fontSize = 12.sp)
        Text(value, color = AgwColors.PaleMarble, fontSize = 12.sp)
    }
}

@Composable
private fun StorageTab(
    entries: List<DebugTools.StorageEntry>,
    usedBytes: Long,
    workshopCounts: Map<String, Int>
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SectionTitle("Stockage application")
        Text("Utilisé ≈ ${usedBytes / 1024} Ko · ${entries.size} entrée(s) listées", color = AgwColors.Sand, fontSize = 12.sp)

        SectionTitle("Atelier")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            workshopCounts.forEach { (k, v) ->
                AssistChip(onClick = {}, label = { Text("$k: $v", fontSize = 11.sp) })
            }
        }

        SectionTitle("Fichiers")
        entries.forEach { e ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(AgwColors.NightStone)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${if (e.isDirectory) "📁" else "📄"} ${e.path}",
                    color = AgwColors.PaleMarble,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                if (!e.isDirectory) {
                    Text("${e.sizeBytes} b", color = AgwColors.Sand, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun ActionsTab(
    busy: Boolean,
    dumpPreview: String?,
    onClearLogs: () -> Unit,
    onClearCache: () -> Unit,
    onInjectError: () -> Unit,
    onBuildDump: () -> Unit,
    onShareDump: () -> Unit,
    onCopyDump: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SectionTitle("Maintenance")
        GoldOutlineButton("Vider le journal d'événements", onClick = onClearLogs, modifier = Modifier.fillMaxWidth())
        GoldOutlineButton("Nettoyer les caches temporaires", onClick = onClearCache, modifier = Modifier.fillMaxWidth())

        SectionTitle("Tests")
        Text(
            "Injecte une erreur artificielle pour vérifier que le pipeline de capture fonctionne (visible dans l'onglet Erreurs).",
            color = AgwColors.Sand,
            fontSize = 12.sp
        )
        GoldOutlineButton("Injecter une erreur de test", onClick = onInjectError, modifier = Modifier.fillMaxWidth())

        SectionTitle("Dump complet")
        Text(
            "Génère un rapport unique : diagnostic + dernière erreur + journal + stockage + compteurs atelier.",
            color = AgwColors.Sand,
            fontSize = 12.sp
        )
        if (busy) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = AgwColors.SacredGold,
                trackColor = AgwColors.NightStone
            )
        }
        GoldPrimaryButton("Générer le dump", onClick = onBuildDump, modifier = Modifier.fillMaxWidth(), enabled = !busy)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldOutlineButton("Copier", onClick = onCopyDump, modifier = Modifier.weight(1f), enabled = !busy)
            GoldOutlineButton("Partager", onClick = onShareDump, modifier = Modifier.weight(1f), enabled = !busy)
        }

        if (dumpPreview != null) {
            SectionTitle("Aperçu du dump")
            Text(
                dumpPreview,
                color = AgwColors.PaleMarble,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0E1218))
                    .padding(10.dp)
            )
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("SBh Debug", text))
}

private fun shareFile(context: Context, file: java.io.File, mime: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Partager le dump SBh"))
}
