package com.sbh.studio.debug

import android.content.Context
import android.os.Build
import com.sbh.studio.BuildConfig
import com.sbh.studio.data.AppDiagnostic
import com.sbh.studio.data.RuntimeDiagnosticStore
import com.sbh.studio.data.RuntimeErrorRecord
import com.sbh.studio.data.toShareText
import com.sbh.studio.workshop.WorkshopRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Outils de débogage centralisés pour SBh Studio.
 */
class DebugTools(private val context: Context) {

    private val store = RuntimeDiagnosticStore(context)
    private val diag = AppDiagnostic(context)
    private val wsRepo = WorkshopRepository(context)

    data class StorageEntry(
        val name: String,
        val path: String,
        val isDirectory: Boolean,
        val sizeBytes: Long,
        val lastModified: Long
    )

    data class DebugDump(
        val generatedAt: String,
        val identity: String,
        val diagnosticText: String,
        val lastError: RuntimeErrorRecord?,
        val recentEvents: List<String>,
        val storageSummary: List<String>,
        val workshopCounts: Map<String, Int>,
        val fullText: String
    )

    fun logEvent(tag: String, message: String) {
        store.appendEvent("[$tag] $message")
    }

    fun recentEvents(limit: Int = 50): List<String> = store.recentEvents(limit)

    fun lastError(): RuntimeErrorRecord? = store.latest()

    fun clearLastError() {
        val file = File(context.filesDir, "diagnostics/runtime_errors.json")
        if (file.exists()) file.writeText("[]")
        logEvent("DEBUG", "Dernière erreur runtime effacée")
    }

    fun clearEventLog() {
        val f = File(context.filesDir, "diagnostics/runtime_events.log")
        if (f.exists()) f.writeText("")
        logEvent("DEBUG", "Journal d'événements vidé")
    }

    fun listStorage(maxDepth: Int = 2): List<StorageEntry> {
        val root = context.filesDir
        val out = mutableListOf<StorageEntry>()
        fun walk(dir: File, depth: Int) {
            if (depth > maxDepth) return
            dir.listFiles()?.sortedBy { it.name }?.forEach { f ->
                out += StorageEntry(
                    name = f.name,
                    path = f.absolutePath.removePrefix(root.absolutePath).ifEmpty { "/" },
                    isDirectory = f.isDirectory,
                    sizeBytes = if (f.isFile) f.length() else 0L,
                    lastModified = f.lastModified()
                )
                if (f.isDirectory) walk(f, depth + 1)
            }
        }
        walk(root, 0)
        return out
    }

    fun storageBytesUsed(): Long {
        fun sizeOf(f: File): Long {
            if (f.isFile) return f.length()
            return f.listFiles()?.sumOf { sizeOf(it) } ?: 0L
        }
        return sizeOf(context.filesDir)
    }

    fun workshopCounts(): Map<String, Int> = mapOf(
        "portals" to wsRepo.loadPortals().size,
        "maps" to wsRepo.loadMaps().size,
        "recipes" to wsRepo.loadRecipes().size,
        "blueprints" to wsRepo.loadBlueprints().size
    )

    fun clearTempCaches(): Int {
        var n = 0
        val candidates = listOf(
            context.cacheDir,
            File(context.filesDir, "tmp"),
            File(context.filesDir, "export_tmp")
        )
        candidates.forEach { dir ->
            if (dir.exists()) {
                dir.listFiles()?.forEach { f ->
                    if (f.deleteRecursively()) n++
                }
            }
        }
        logEvent("DEBUG", "Caches temporaires nettoyés ($n éléments)")
        return n
    }

    suspend fun buildFullDump(): DebugDump = withContext(Dispatchers.IO) {
        val report = diag.runLocal()
        val lastErr = store.latest()
        val events = store.recentEvents(40)
        val storage = listStorage(2)
        val counts = workshopCounts()
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.FRANCE).format(Date())

        val identity = buildString {
            appendLine("package=${context.packageName}")
            appendLine("version=${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            appendLine("buildType=${BuildConfig.BUILD_TYPE}")
            appendLine("sdk=${Build.VERSION.SDK_INT}")
            appendLine("device=${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("filesDir=${context.filesDir.absolutePath}")
            appendLine("storageUsed≈${storageBytesUsed() / 1024} Ko")
        }

        val storageLines = storage.take(80).map { e ->
            val kind = if (e.isDirectory) "DIR " else "FILE"
            val sz = if (e.isDirectory) "" else " ${e.sizeBytes}b"
            "$kind ${e.path}$sz"
        }

        val full = buildString {
            appendLine("SBh STUDIO — DEBUG DUMP")
            appendLine("=======================")
            appendLine("Généré : $date")
            appendLine()
            appendLine("--- IDENTITÉ ---")
            append(identity)
            appendLine()
            appendLine("--- DIAGNOSTIC ---")
            appendLine(report.toShareText())
            appendLine()
            appendLine("--- DERNIÈRE ERREUR RUNTIME ---")
            if (lastErr != null) appendLine(lastErr.developerReport()) else appendLine("(aucune)")
            appendLine()
            appendLine("--- JOURNAL RÉCENT ---")
            events.forEach { appendLine(it) }
            appendLine()
            appendLine("--- ATELIER ---")
            counts.forEach { (k, v) -> appendLine("$k = $v") }
            appendLine()
            appendLine("--- STOCKAGE (aperçu) ---")
            storageLines.forEach { appendLine(it) }
        }

        DebugDump(
            generatedAt = date,
            identity = identity,
            diagnosticText = report.toShareText(),
            lastError = lastErr,
            recentEvents = events,
            storageSummary = storageLines,
            workshopCounts = counts,
            fullText = full
        )
    }

    fun injectTestError() {
        val rec = RuntimeErrorRecord(
            module = "DebugTools",
            action = "injectTestError",
            state = "manual",
            name = "TestError",
            message = "Erreur de test injectée volontairement depuis les outils de débogage.",
            filename = "DebugTools.kt",
            line = 0,
            interpretation = "Ceci est une erreur artificielle. Utilisez « Effacer » pour la retirer."
        )
        store.save(rec)
        store.appendEvent("[DEBUG] Erreur de test injectée · ${rec.errorId}")
    }

    fun exportDumpToFile(dump: DebugDump): File {
        val dir = File(context.filesDir, "diagnostics")
        dir.mkdirs()
        val name = "sbh_debug_dump_${System.currentTimeMillis()}.txt"
        val f = File(dir, name)
        f.writeText(dump.fullText)
        logEvent("DEBUG", "Dump exporté → ${f.name}")
        return f
    }
}
