package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Données AGW (Arabian Gothic World) chargées depuis assets/agw/
 * Issues de l'outil SBh-AGW-Tool intégré.
 */
@Serializable
data class AgwProject(
    val name: String = "",
    val code: String = "SBh-AGW",
    val version: String = "0.7.4",
    val prefix: String = "agw",
    val studio: String = "SBh Studio"
)

@Serializable
data class AgwLore(
    val world_name: Map<String, String> = emptyMap(),
    val tagline: Map<String, String> = emptyMap(),
    val setting: Map<String, String> = emptyMap(),
    val core_promise: Map<String, String> = emptyMap(),
    val atmosphere: List<String> = emptyList()
)

@Serializable
data class AgwNpc(
    val id: String = "",
    val name: Map<String, String> = emptyMap(),
    val title: Map<String, String> = emptyMap(),
    val faction: String = "",
    val role: String = "",
    val personality: String = ""
)

@Serializable
data class AgwBoss(
    val id: String = "",
    val name: Map<String, String> = emptyMap(),
    val title: Map<String, String> = emptyMap(),
    val phases: Int = 1,
    val location: String = ""
)

@Serializable
data class AgwCreature(
    val id: String = "",
    val name: Map<String, String> = emptyMap(),
    val biome: String = "",
    val role: String = ""
)

@Serializable
data class AgwHeroes(
    val player_role: Map<String, String> = emptyMap(),
    val npcs: List<AgwNpc> = emptyList(),
    val bosses: List<AgwBoss> = emptyList(),
    val creatures: List<AgwCreature> = emptyList()
)

@Serializable
data class AgwFaction(
    val id: String = "",
    val name: Map<String, String> = emptyMap(),
    val type: String = "",
    val culture: String = "",
    val territory: String = "",
    val reputationRange: List<Int> = listOf(-100, 100),
    val allies: List<String> = emptyList(),
    val enemies: List<String> = emptyList(),
    val neutrals: List<String> = emptyList(),
    val npcs: List<String> = emptyList()
)

@Serializable
data class AgwFactionsFile(
    val factions: List<AgwFaction> = emptyList()
)

@Serializable
data class AgwPhase(
    val id: Int = 0,
    val name: String = "",
    val status: String = "",
    val deliverables: List<String> = emptyList()
)

@Serializable
data class AgwPhasesFile(
    val phases: List<AgwPhase> = emptyList()
)

class AgwDataRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private fun readAsset(name: String): String =
        context.assets.open("agw/$name").bufferedReader().use { it.readText() }

    /**
     * Priorité : override manuel (filesDir/agw_override) puis assets embarqués.
     * Permet d'assimiler un document de mise à jour sans rebuild APK.
     */
    private fun readAgw(name: String): String {
        val override = java.io.File(context.filesDir, "agw_override/$name")
        if (override.exists()) {
            return override.readText()
        }
        return readAsset(name)
    }

    fun loadProject(): AgwProject = try {
        json.decodeFromString(readAgw("project.json"))
    } catch (_: Exception) {
        AgwProject()
    }

    fun loadLore(): AgwLore = try {
        json.decodeFromString(readAgw("lore.json"))
    } catch (_: Exception) {
        AgwLore()
    }

    fun loadHeroes(): AgwHeroes = try {
        json.decodeFromString(readAgw("heroes.json"))
    } catch (_: Exception) {
        AgwHeroes()
    }

    fun loadFactions(): List<AgwFaction> = try {
        json.decodeFromString<AgwFactionsFile>(readAgw("factions.json")).factions
    } catch (_: Exception) {
        emptyList()
    }

    fun loadPhases(): List<AgwPhase> = try {
        json.decodeFromString<AgwPhasesFile>(readAgw("phases.json")).phases
    } catch (_: Exception) {
        emptyList()
    }

    /** Résumé texte pour affichage dans l'UI */
    fun summaryFr(): String {
        val lore = loadLore()
        val heroes = loadHeroes()
        val factions = loadFactions()
        val phases = loadPhases()
        val world = lore.world_name["fr"] ?: "Al-Zahra"
        val tagline = lore.tagline["fr"] ?: ""
        val npcNames = heroes.npcs.joinToString { it.name["fr"] ?: it.id }
        val creatures = heroes.creatures.joinToString { it.name["fr"] ?: it.id }
        val done = phases.count { it.status == "done" }
        return """
            |Monde : $world
            |$tagline
            |
            |Faction : ${factions.firstOrNull()?.name?.get("fr") ?: "—"}
            |PNJ : $npcNames
            |Créatures : $creatures
            |Boss : ${heroes.bosses.firstOrNull()?.name?.get("fr") ?: "—"}
            |Phases terminées : $done / ${phases.size}
        """.trimMargin()
    }
}
