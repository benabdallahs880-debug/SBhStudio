package com.sbh.studio.workshop

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sbh.studio.data.BlockRepository
import com.sbh.studio.data.AgwDataRepository
import com.sbh.studio.data.AgwWorldCoreRepository
import com.sbh.studio.data.ItemRepository
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.generator.AdvancedPackEngine
import com.sbh.studio.foundation.SBhWorldFoundation
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AgwDecor
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.ModeIconChip
import com.sbh.studio.ui.ModeIconTile
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.SectionTitle
import com.sbh.studio.ui.GoldDivider
import com.sbh.studio.data.SoundRepository
import com.sbh.studio.data.SbhSound
import com.sbh.studio.data.SoundEvents
import com.sbh.studio.texture.TextureRepository
import com.sbh.studio.texture.TextureProject
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkshopScreen(
    project: SbhProject?,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val repo = remember { WorkshopRepository(context) }
    val agwRepo = remember { AgwDataRepository(context) }
    val worldCoreRepo = remember { AgwWorldCoreRepository(context) }
    val mobRepo = remember { MobRepository(context) }
    val itemRepo = remember { ItemRepository(context) }
    val blockRepo = remember { BlockRepository(context) }
    val engine = remember { AdvancedPackEngine(context) }

    var zone by remember { mutableStateOf(WorkshopZoneId.HUB) }
    var portals by remember { mutableStateOf(repo.loadPortals()) }
    var maps by remember { mutableStateOf(repo.loadMaps()) }
    var mobs by remember { mutableStateOf(mobRepo.loadAll()) }
    var items by remember { mutableStateOf(itemRepo.loadAll()) }
    var blocks by remember { mutableStateOf(blockRepo.loadAll()) }
    var recipes by remember { mutableStateOf(repo.loadRecipes()) }
    val texRepo = remember { TextureRepository(context) }
    var textures by remember { mutableStateOf(texRepo.loadAll()) }
    val soundRepo = remember { SoundRepository(context) }
    var sounds by remember { mutableStateOf(soundRepo.loadAll()) }
    var reportText by remember { mutableStateOf("") }
    var lastExport by remember { mutableStateOf<File?>(null) }
    var agwWorld by remember { mutableStateOf(worldCoreRepo.load()) }

    val projectId = project?.id ?: "global"
    LaunchedEffect(projectId, maps, portals) {
        agwWorld = worldCoreRepo.synchronize(agwRepo, maps, portals, projectId)
        worldCoreRepo.save(agwWorld)
    }
    LaunchedEffect(Unit) { textures = texRepo.loadAll() }
    fun projectMobs() = mobs.filter { it.projectId == projectId }
    fun projectItems() = items.filter { it.projectId == projectId }
    fun projectBlocks() = blocks.filter { it.projectId == projectId }
    fun projectPortals() = portals.filter { it.projectId == projectId }
    fun projectMaps() = maps.filter { it.projectId == projectId }
    fun projectRecipes() = recipes.filter { it.projectId == projectId }
    fun projectSounds() = sounds.filter { it.projectId == null || it.projectId == projectId }

    fun savePortals(v: List<PortalBlueprint>) { portals = v; repo.savePortals(v); agwWorld = worldCoreRepo.synchronize(agwRepo, maps, v, projectId).also(worldCoreRepo::save) }
    fun saveMaps(v: List<MapBlueprint>) { maps = v; repo.saveMaps(v); agwWorld = worldCoreRepo.synchronize(agwRepo, v, portals, projectId).also(worldCoreRepo::save) }
    fun saveMobs(v: List<MobEntity>) { mobs = v; mobRepo.saveAll(v) }
    fun saveItems(v: List<SbhItem>) { items = v; itemRepo.saveAll(v) }
    fun saveBlocks(v: List<SbhBlock>) { blocks = v; blockRepo.saveAll(v) }
    fun saveRecipes(v: List<RecipeBlueprint>) { recipes = v; repo.saveRecipes(v) }

    fun applyTemplate(t: WorkshopTemplate) {
        if (project == null) {
            onMessage("Ouvrez un projet avant d'appliquer un template")
            return
        }
        val pid = projectId
        val suffix = System.currentTimeMillis() % 10000
        when (t.id) {
            "desert_gothic" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Désert Gothique · $suffix",
                    sizeX = 96, sizeZ = 96, height = 72, theme = "desert_gothic", terrain = "desert",
                    hasVillage = true, hasDungeon = true, hasOasis = false, hasMountains = true, hasRoads = true
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Portail du Désert", identifier = "agw:portal_desert",
                    width = 5, height = 6, frameBlock = "agw:night_bricks",
                    destinationHint = "Al-Zahra · Désert", linkedMapId = mapId, mapX = 48, mapY = 70, mapZ = 48
                )
                val newMobs = listOf(
                    MobEntity(projectId = pid, nom = "Gardien du Désert", identifiant = "agw:gardien_desert", vie = 30, degats = 6, hostile = true, poursuite = true, attaque = true),
                    MobEntity(projectId = pid, nom = "Scorpion Noir", identifiant = "agw:scorpion_noir", vie = 16, degats = 4, hostile = true, poursuite = true, attaque = true)
                )
                val newItems = listOf(
                    SbhItem(projectId = pid, name = "Lame du Sirocco", identifier = "agw:lame_sirocco")
                )
                saveMaps(maps + map)
                savePortals(portals + portal)
                saveMobs(mobs + newMobs)
                saveItems(items + newItems)
                onMessage("Template « ${t.name} » appliqué : 1 map, 1 portail, 2 mobs, 1 item")
            }
            "oasis" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Oasis Vivante · $suffix",
                    sizeX = 64, sizeZ = 64, height = 64, theme = "oasis", terrain = "desert",
                    hasVillage = true, hasDungeon = false, hasOasis = true, hasMountains = false, hasRoads = true
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Portail de l'Oasis", identifier = "agw:portal_oasis",
                    width = 4, height = 5, frameBlock = "minecraft:sandstone",
                    destinationHint = "Oasis · Point d'eau", linkedMapId = mapId, mapX = 32, mapY = 65, mapZ = 32
                )
                val newRecipes = listOf(
                    RecipeBlueprint(projectId = pid, name = "Eau pure", identifier = "agw:eau_pure",
                        type = "minecraft:recipe_shapeless", resultId = "agw:eau_pure", resultCount = 1,
                        ingredients = listOf("minecraft:glass_bottle", "minecraft:water_bucket"))
                )
                saveMaps(maps + map)
                savePortals(portals + portal)
                saveRecipes(recipes + newRecipes)
                onMessage("Template « ${t.name} » appliqué : 1 map, 1 portail, 1 recette")
            }
            "forteresse" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Forteresse Noire · $suffix",
                    sizeX = 80, sizeZ = 80, height = 96, theme = "fortress", terrain = "mountains",
                    hasVillage = false, hasDungeon = true, hasOasis = false, hasMountains = true, hasRoads = false
                )
                val newMobs = listOf(
                    MobEntity(projectId = pid, nom = "Sentinelle Noire", identifiant = "agw:sentinelle_noire", vie = 40, degats = 8, hostile = true, poursuite = true, attaque = true, profilIA = "guerrier"),
                    MobEntity(projectId = pid, nom = "Archer de la Tour", identifiant = "agw:archer_tour", vie = 22, degats = 5, hostile = true, poursuite = true, attaque = true, profilIA = "archer")
                )
                saveMaps(maps + map)
                saveMobs(mobs + newMobs)
                onMessage("Template « ${t.name} » appliqué : 1 map, 2 mobs hostiles")
            }
            "route_caravane" -> {
                val mapA = MapBlueprint(
                    id = java.util.UUID.randomUUID().toString(), projectId = pid, name = "Caravansérail · $suffix",
                    sizeX = 48, sizeZ = 48, height = 64, theme = "caravan", terrain = "desert",
                    hasVillage = true, hasDungeon = false, hasOasis = false, hasMountains = false, hasRoads = true, worldX = 0, worldZ = 0
                )
                val mapB = MapBlueprint(
                    id = java.util.UUID.randomUUID().toString(), projectId = pid, name = "Poste avancé · $suffix",
                    sizeX = 32, sizeZ = 32, height = 64, theme = "caravan", terrain = "desert",
                    hasVillage = false, hasDungeon = false, hasOasis = true, hasMountains = false, hasRoads = true, worldX = 200, worldZ = 0
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Relais Caravane", identifier = "agw:portal_caravane",
                    width = 3, height = 4, frameBlock = "minecraft:cut_sandstone",
                    destinationHint = "Poste avancé", linkedMapId = mapB.id, mapX = 16, mapY = 65, mapZ = 16,
                    destX = 200, destY = 65, destZ = 0
                )
                saveMaps(maps + mapA + mapB)
                savePortals(portals + portal)
                onMessage("Template « ${t.name} » appliqué : 2 maps liées + 1 portail")
            }
            else -> onMessage("Template inconnu")
        }
    }


    fun generateFoundation() {
        onMessage("Génération de la fondation en cours…")
        try {
            val result = SBhWorldFoundation.generateAndExport(context)
            lastExport = result.addonFile

            // Import automatique dans le projet Compose (mobs + items)
            val pid = project?.id ?: "global"
            val foundationMobs = listOf(
                MobEntity(projectId = pid, nom = "Yahya ibn Harith", identifiant = "agw:yahya", vie = 32, degats = 7, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Zaynab", identifiant = "agw:zaynab", vie = 20, degats = 0, hostile = false),
                MobEntity(projectId = pid, nom = "Chef de Hibou", identifiant = "agw:chef_hibou", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Chef de Ghurab", identifiant = "agw:chef_ghurab", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Le Roi", identifiant = "agw:roi", vie = 30, degats = 5, hostile = false),
                MobEntity(projectId = pid, nom = "Garde royal", identifiant = "agw:garde_royal", vie = 24, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Combattant Hibou", identifiant = "agw:soldat_hibou", vie = 22, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Combattant Ghurab", identifiant = "agw:soldat_ghurab", vie = 22, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Templier", identifiant = "agw:templier", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Marchand bédouin", identifiant = "agw:marchand_bedouin", vie = 18, degats = 0, hostile = false),
                MobEntity(projectId = pid, nom = "Vautour", identifiant = "agw:vautour", vie = 20, degats = 4, hostile = true, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Hashashin", identifiant = "agw:hashashin", vie = 26, degats = 7, hostile = true, poursuite = true, attaque = true)
            )
            val foundationItems = listOf(
                SbhItem(projectId = pid, name = "Sabre de Hibou", identifier = "agw:sabre_hibou", damage = 7, durability = 600),
                SbhItem(projectId = pid, name = "Sabre de Ghurab", identifier = "agw:sabre_ghurab", damage = 7, durability = 600),
                SbhItem(projectId = pid, name = "Sabre royal", identifier = "agw:sabre_royal", damage = 8, durability = 650),
                SbhItem(projectId = pid, name = "Sabre templier", identifier = "agw:sabre_templier", damage = 8, durability = 650),
                SbhItem(projectId = pid, name = "Fusil royal", identifier = "agw:fusil_royal", damage = 11, durability = 400),
                SbhItem(projectId = pid, name = "Fusil de Hibou", identifier = "agw:fusil_hibou", damage = 10, durability = 380),
                SbhItem(projectId = pid, name = "Pistolet templier", identifier = "agw:pistolet_templier", damage = 8, durability = 300),
                SbhItem(projectId = pid, name = "Pistolet royal", identifier = "agw:pistolet_royal", damage = 8, durability = 300),
                SbhItem(projectId = pid, name = "Mitrailleuse lourde", identifier = "agw:mitrailleuse_lourde", damage = 14, durability = 800),
                SbhItem(projectId = pid, name = "NRJ noire", identifier = "agw:nrj_noire", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Minerai brut", identifier = "agw:minerai_brut", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Plan mécanique", identifier = "agw:plan_mecanique", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Composant rare", identifier = "agw:composant_rare", damage = 0, durability = 1)
            )
            // Les doublons ne se comparent que dans CE projet : avant, distinctBy portait sur tous les
            // projets et un 2e projet ne recevait rien alors que le message annonçait l'import.
            val mobMerge = mergeMobs(mobs, foundationMobs)
            saveMobs(mobMerge.mobs)
            val (itemList, itemsAdded) = addMissing(items, foundationItems, { it.projectId }, { it.identifier })
            saveItems(itemList)
            val alreadyThere = (foundationMobs.size - mobMerge.added) + (foundationItems.size - itemsAdded)
            val importNote = if (alreadyThere > 0) " ($alreadyThere déjà présents)" else ""

            // Régions → Map Studio (fichier partagé)
            try {
                val regionsSrc = java.io.File(result.project.mapDir, "regions.json")
                if (regionsSrc.exists()) {
                    val dest = java.io.File(context.filesDir, "map_studio_regions.json")
                    regionsSrc.copyTo(dest, overwrite = true)
                }
            } catch (_: Exception) {}

            reportText = result.message + "\n\n✅ Importé dans le projet : ${mobMerge.added} mobs, $itemsAdded items$importNote\n📍 Régions prêtes pour Map Studio"
            onMessage("Fondation + import projet OK")
            zone = WorkshopZoneId.EXPORT
        } catch (e: Exception) {
            onMessage("Erreur fondation : ${e.message}")
            reportText = "❌ ${e.message}"
        }
    }

    fun importAgwPresets() {
        if (project == null) {
            onMessage("Ouvrez un projet d'abord")
            return
        }
        val pid = project.id
        val newMobs = engine.presetMobs(pid)
        val newItems = listOf(
            SbhItem(projectId = pid, name = "Cimeterre de fer", identifier = "agw:iron_scimitar", damage = 7, durability = 250),
            SbhItem(projectId = pid, name = "Lanterne suspendue", identifier = "agw:hanging_lantern", damage = 0, durability = 100)
        )
        val newBlocks = listOf(
            SbhBlock(projectId = pid, name = "Grès sombre", identifier = "agw:dark_sandstone", hardness = 1.5),
            SbhBlock(projectId = pid, name = "Pierre arabesque", identifier = "agw:arabesque_stone", hardness = 2.0),
            SbhBlock(projectId = pid, name = "Briques de nuit", identifier = "agw:night_bricks", hardness = 1.8),
            SbhBlock(projectId = pid, name = "Mosaïque sacrée", identifier = "agw:sacred_mosaic", hardness = 1.2)
        )
        val mobMerge = mergeMobs(mobs, newMobs)
        saveMobs(mobMerge.mobs)
        val (itemList, itemsAdded) = addMissing(items, newItems, { it.projectId }, { it.identifier })
        saveItems(itemList)
        val (blockList, blocksAdded) = addMissing(blocks, newBlocks, { it.projectId }, { it.identifier })
        saveBlocks(blockList)
        val portal = PortalBlueprint(projectId = pid, name = "Portail Al-Zahra", identifier = "agw:portal_al_zahra", destinationHint = "الزهراء")
        val map = MapBlueprint(projectId = pid, name = "Cité Al-Zahra", sizeX = 48, sizeZ = 48, hasVillage = true, hasDungeon = true, hasOasis = true)
        val (portalList, portalsAdded) = addMissing(portals, listOf(portal), { it.projectId }, { it.identifier })
        savePortals(portalList)
        val (mapList, mapsAdded) = addMissing(maps, listOf(map), { it.projectId }, { it.name })
        saveMaps(mapList)
        onMessage("Monde AGW importé dans le projet")
        val repairedNote = if (mobMerge.repaired > 0) " (+${mobMerge.repaired} réparés)" else ""
        reportText = "✅ Import AGW : ${mobMerge.added} mobs$repairedNote, $itemsAdded items, $blocksAdded blocs, $portalsAdded portail, $mapsAdded map"
        zone = WorkshopZoneId.EXPORT
    }

    fun runValidate() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet (Accueil → projet) puis revenez à l'atelier."
            return
        }
        val r = engine.validateAll(project, projectMobs(), projectItems(), projectBlocks(), projectPortals(), projectMaps())
        reportText = buildString {
            append(if (r.ok) "✅ Validation OK\n" else "❌ Erreurs\n")
            append("Contenu : ${projectMobs().size} mobs · ${projectItems().size} items · ${projectBlocks().size} blocs · ${projectPortals().size} portails · ${projectMaps().size} maps\n")
            r.errors.forEach { append("· $it\n") }
            r.warnings.forEach { append("⚠ $it\n") }
        }
    }

    fun runExport() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet d'abord."
            return
        }
        val r = engine.exportAdvanced(project, projectMobs(), projectItems(), projectBlocks(), projectPortals(), projectMaps())
        lastExport = r.file
        reportText = buildString {
            append(if (r.ok) "✅ Export réussi\n" else "❌ Échec export\n")
            append("Fichier : ${r.file?.name ?: "—"}\n")
            append("Contenu : ${projectMobs().size} mobs · ${projectItems().size} items · ${projectBlocks().size} blocs · ${projectPortals().size} portails · ${projectMaps().size} maps\n")
            r.errors.forEach { append("· $it\n") }
            r.warnings.forEach { append("⚠ $it\n") }
        }
        if (r.ok && r.file != null) {
            onMessage("Pack généré : ${r.file.name}")
            try {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", r.file)
                // Même correctif que l'export du détail projet : Minecraft n'apparaît
                // jamais dans un partage générique (ACTION_SEND), seulement lors d'une
                // ouverture directe du fichier (ACTION_VIEW). Ce chemin d'export-ci avait
                // été oublié lors du premier correctif — désormais aligné.
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/mcaddon")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runCatching { context.startActivity(viewIntent) }.onFailure {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Partager le pack"))
                }
            } catch (_: Exception) { }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Atelier · الورشة", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text(project?.name ?: "Aucun projet ouvert", style = MaterialTheme.typography.labelSmall, color = AgwColors.Sand)
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(WorkshopZoneId.entries.toList()) { z ->
                    ModeIconChip(
                        label = zoneLabel(z),
                        iconAsset = zoneIcon(z),
                        selected = zone == z,
                        onClick = { zone = z }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            when (zone) {
                WorkshopZoneId.HUB -> HubZone(
                    onSelect = { zone = it },
                    mobCount = projectMobs().size,
                    portalCount = projectPortals().size,
                    mapCount = projectMaps().size,
                    itemCount = projectItems().size,
                    blockCount = projectBlocks().size,
                    recipeCount = projectRecipes().size,
                    soundCount = projectSounds().size,
                    maps = projectMaps(),
                    portals = projectPortals(),
                    mobs = projectMobs(),
                    items = projectItems(),
                    blocks = projectBlocks(),
                    recipes = projectRecipes(),
                    textures = textures,
                    onImportAgw = { importAgwPresets() },
                    onGenerateFoundation = { generateFoundation() },
                    onApplyTemplate = { t -> applyTemplate(t) },
                    agwWorldName = agwWorld.worldName,
                    agwFactionCount = agwWorld.nodes.count { it.type == "faction" },
                    agwNodeCount = agwWorld.nodes.size,
                    onComingSoon = { label -> onMessage("$label : pas encore disponible, en préparation.") }
                )
                WorkshopZoneId.MOBS -> MobZone(
                    projectId = projectId,
                    mobs = projectMobs(),
                    hasProject = project != null,
                    textures = textures,
                    onAddPresets = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val r = mergeMobs(mobs, engine.presetMobs(projectId))
                            saveMobs(r.mobs)
                            onMessage(mobMergeMessage(r))
                        }
                    },
                    onSave = { m ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@MobZone }
                        saveMobs(mobs.filter { it.id != m.id } + m)
                    },
                    onDelete = { m -> saveMobs(mobs - m) }
                )
                WorkshopZoneId.PORTALS -> PortalZone(
                    projectId = projectId,
                    portals = projectPortals(),
                    maps = projectMaps(),
                    textures = textures,
                    onSave = { p ->
                        savePortals(portals.filter { it.id != p.id } + p)
                    },
                    onDelete = { p -> savePortals(portals - p) }
                )
                WorkshopZoneId.MAPS -> MapZone(
                    projectId = projectId,
                    maps = projectMaps(),
                    portals = projectPortals(),
                    mobs = projectMobs(),
                    items = projectItems(),
                    blocks = projectBlocks(),
                    textures = textures,
                    onSave = { m -> saveMaps(maps.filter { it.id != m.id } + m) },
                    onLinkPortal = { portal, mapId ->
                        savePortals(portals.filter { it.id != portal.id } + portal.copy(linkedMapId = mapId))
                    },
                    onDelete = { m ->
                        saveMaps(maps - m)
                        savePortals(portals.map { if (it.linkedMapId == m.id) it.copy(linkedMapId = null) else it })
                    }
                )
                WorkshopZoneId.BLOCKS -> BlockZone(
                    projectId = projectId,
                    blocks = projectBlocks(),
                    textures = textures,
                    onAdd = { block -> saveBlocks(blocks + block) },
                    onDelete = { b -> saveBlocks(blocks - b) }
                )
                WorkshopZoneId.ITEMS -> ItemZone(
                    projectId = projectId,
                    items = projectItems(),
                    textures = textures,
                    onAdd = { item -> saveItems(items + item) },
                    onDelete = { i -> saveItems(items - i) }
                )
                WorkshopZoneId.RECIPES -> RecipeZone(
                    projectId = projectId,
                    recipes = projectRecipes(),
                    items = projectItems(),
                    onSave = { r ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@RecipeZone }
                        saveRecipes(recipes.filter { it.id != r.id } + r)
                    },
                    onDelete = { r -> saveRecipes(recipes - r) }
                )
                WorkshopZoneId.SOUNDS -> SoundZone(
                    projectId = projectId,
                    projectName = project?.name,
                    sounds = projectSounds(),
                    hasProject = project != null,
                    soundRepo = soundRepo,
                    onRefresh = { sounds = soundRepo.loadAll() },
                    onMessage = onMessage
                )
                WorkshopZoneId.EXPORT -> ExportZone(
                    reportText = reportText,
                    hasProject = project != null,
                    counts = "${projectMobs().size}m ${projectItems().size}i ${projectBlocks().size}b ${projectPortals().size}p ${projectMaps().size}maps ${projectRecipes().size}r ${projectSounds().size}s",
                    onValidate = { runValidate() },
                    onExport = { runExport() },
                    onImportAgw = { importAgwPresets() }
                )
            }
        }
    }
}

@Composable
private fun HubZone(
    onSelect: (WorkshopZoneId) -> Unit,
    mobCount: Int,
    portalCount: Int,
    mapCount: Int,
    itemCount: Int,
    blockCount: Int,
    recipeCount: Int,
    soundCount: Int = 0,
    maps: List<MapBlueprint>,
    portals: List<PortalBlueprint>,
    mobs: List<MobEntity>,
    items: List<SbhItem>,
    blocks: List<SbhBlock>,
    recipes: List<RecipeBlueprint>,
    textures: List<TextureProject>,
    onImportAgw: () -> Unit,
    onGenerateFoundation: () -> Unit,
    onApplyTemplate: (WorkshopTemplate) -> Unit,
    agwWorldName: String = "Al-Zahra",
    agwFactionCount: Int = 0,
    agwNodeCount: Int = 0,
    onComingSoon: (String) -> Unit = {}
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        SectionTitle("Monde AGW · $agwWorldName")
        Text("World Core : $agwNodeCount nœud(s) · $agwFactionCount faction(s) · synchronisé avec l'Atelier", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)

        GoldDivider(Modifier.padding(bottom = 6.dp))
        WorkshopConnectionPanel(
            maps = maps,
            portals = portals,
            mobs = mobs,
            items = items,
            blocks = blocks,
            recipes = recipes,
            textures = textures
        )

        GoldDivider(Modifier.padding(bottom = 6.dp))
        SectionTitle("Zones de l'atelier")
        GoldDivider(Modifier.padding(bottom = 6.dp))
        // Tuiles icônées par zone
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Mobs ($mobCount)", "branding/icons/icon_mobs.png", { onSelect(WorkshopZoneId.MOBS) }, Modifier.weight(1f))
                ModeIconTile("Portails ($portalCount)", "branding/icons/icon_portals.png", { onSelect(WorkshopZoneId.PORTALS) }, Modifier.weight(1f))
                ModeIconTile("Maps ($mapCount)", "branding/icons/icon_map.png", { onSelect(WorkshopZoneId.MAPS) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Items ($itemCount)", "branding/icons/icon_items.png", { onSelect(WorkshopZoneId.ITEMS) }, Modifier.weight(1f))
                ModeIconTile("Blocs ($blockCount)", "branding/icons/icon_blocks.png", { onSelect(WorkshopZoneId.BLOCKS) }, Modifier.weight(1f))
                ModeIconTile("Recettes ($recipeCount)", "branding/icons/icon_items.png", { onSelect(WorkshopZoneId.RECIPES) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Sons / نشيد ($soundCount)", "branding/icons/icon_export.png", { onSelect(WorkshopZoneId.SOUNDS) }, Modifier.weight(1f))
                ModeIconTile("Export", "branding/icons/icon_export.png", { onSelect(WorkshopZoneId.EXPORT) }, Modifier.weight(1f))
                Spacer(Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(4.dp))
        SectionTitle("Templates prêts à l'emploi")
        GoldDivider(Modifier.padding(bottom = 6.dp))
        Text(
            "Applique un set cohérent (map + portail + contenus) en un clic. Les éléments sont ajoutés au projet courant.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        val templates = listOf(
            WorkshopTemplate("desert_gothic", "Désert Gothique", "Map désert + portail + 2 mobs + 1 item", "desert_gothic", 0xFFC9A227),
            WorkshopTemplate("oasis", "Oasis Vivante", "Map oasis + village + portail + recettes", "oasis", 0xFF3D6B45),
            WorkshopTemplate("forteresse", "Forteresse Noire", "Map montagne + donjon + mobs hostiles", "fortress", 0xFF5A5550),
            WorkshopTemplate("route_caravane", "Route des Caravanes", "Map routes + commerce + portails liés", "caravan", 0xFFE0A458)
        )
        templates.chunked(2).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { t ->
                    GlassCard(modifier = Modifier.weight(1f).clickable { onApplyTemplate(t) }) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(t.name, fontWeight = FontWeight.Bold, color = Color(t.iconColor))
                            Text(t.description, color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(4.dp))
        SectionTitle("Bientôt disponible")
        GoldDivider(Modifier.padding(bottom = 6.dp))
        Text(
            "Ces catégories sont prévues mais pas encore fonctionnelles — pas de faux bouton qui ne mène nulle part, juste l'ampleur de ce qui reste à construire.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        val comingSoon = listOf(
            "Biomes", "Fonctions", "Projectiles",
            "Structures", "Dimensions", "Particules", "Commerce",
            "Dialogues PNJ", "Nature", "Interface", "Machines"
        )
        comingSoon.chunked(3).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { label ->
                    ModeIconTile(
                        label = label,
                        iconAsset = "branding/icons/icon_soon.png", // pas d'asset dédié -> repli automatique sur ◆
                        onClick = { onComingSoon(label) },
                        modifier = Modifier.weight(1f),
                        subtitle = "Bientôt",
                        enabled = false
                    )
                }
                // Complète la ligne si elle a moins de 3 éléments, pour garder l'alignement.
                Spacer(Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(8.dp))
        SectionTitle("Minimap de l'atelier")
        Text(
            "Vue vivante du projet : les cartes et portails enregistrés apparaissent directement dans l'atelier.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        AtelierMinimap(
            maps = maps,
            portals = portals,
            counts = listOf(mobCount, portalCount, mapCount, itemCount, blockCount, recipeCount),
            onZone = onSelect
        )
        GoldPrimaryButton(
            "Importer le monde AGW dans ce projet",
            onImportAgw,
            modifier = Modifier.fillMaxWidth()
        )
        GoldOutlineButton(
            "Générer la fondation complète (Bac à sable)",
            onGenerateFoundation,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            "Parcours : Fondation → Import AGW → ajuster zones → Export. Tout le contenu projet part dans le .mcaddon.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun AtelierMinimap(
    maps: List<MapBlueprint>,
    portals: List<PortalBlueprint>,
    counts: List<Int>,
    onZone: (WorkshopZoneId) -> Unit
) {
    var showMaps by rememberSaveable { mutableStateOf(true) }
    var showPortals by rememberSaveable { mutableStateOf(true) }
    var showTools by rememberSaveable { mutableStateOf(true) }

    // Pins dynamiques : maps en haut, portails positionnés près de leur map liée si possible
    val mapPins = maps.mapIndexed { i, m ->
        val col = i % 4
        val row = i / 4
        MinimapPin("map_${m.id}", m.name.take(12), 14f + col * 22f, 18f + row * 14f, WorkshopZoneId.MAPS, 0xFF5DADE2, m.id)
    }
    val portalPins = portals.mapIndexed { i, p ->
        val linked = mapPins.firstOrNull { it.linkedMapId == p.linkedMapId }
        val baseX = linked?.x ?: (18f + (i % 4) * 20f)
        val baseY = (linked?.y ?: 70f) + 10f
        MinimapPin("portal_${p.id}", p.name.take(10), baseX.coerceIn(8f, 92f), baseY.coerceIn(8f, 92f), WorkshopZoneId.PORTALS, 0xFFB06AB3, p.linkedMapId)
    }
    val toolPins = listOf(
        MinimapPin("hub", "Hub", 50f, 50f, WorkshopZoneId.HUB, 0xFFC9A227),
        MinimapPin("mobs", "Mobs ${counts.getOrElse(0) { 0 }}", 12f, 50f, WorkshopZoneId.MOBS, 0xFFB94E48),
        MinimapPin("items", "Items ${counts.getOrElse(3) { 0 }}", 88f, 50f, WorkshopZoneId.ITEMS, 0xFF8E7CC3),
        MinimapPin("blocks", "Blocs ${counts.getOrElse(4) { 0 }}", 50f, 88f, WorkshopZoneId.BLOCKS, 0xFF7AA66D),
        MinimapPin("recipes", "Recettes ${counts.getOrElse(5) { 0 }}", 88f, 88f, WorkshopZoneId.RECIPES, 0xFFD4A017),
        MinimapPin("export", "Export", 50f, 10f, WorkshopZoneId.EXPORT, 0xFFE0A458)
    )
    val pins = buildList {
        if (showMaps) addAll(mapPins)
        if (showPortals) addAll(portalPins)
        if (showTools) addAll(toolPins)
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        // Filtres
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = showMaps, onClick = { showMaps = !showMaps }, label = { Text("Maps", fontSize = 10.sp) })
            FilterChip(selected = showPortals, onClick = { showPortals = !showPortals }, label = { Text("Portails", fontSize = 10.sp) })
            FilterChip(selected = showTools, onClick = { showTools = !showTools }, label = { Text("Outils", fontSize = 10.sp) })
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(240.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF0E1218))
                .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
        ) {
            Canvas(Modifier.fillMaxSize()) {
                // Fond grille
                val step = size.width / 10f
                for (i in 1 until 10) {
                    drawLine(Color(0x22C9A227), Offset(i * step, 0f), Offset(i * step, size.height), 1f)
                    drawLine(Color(0x22C9A227), Offset(0f, i * (size.height / 10f)), Offset(size.width, i * (size.height / 10f)), 1f)
                }
                // Zone centrale
                drawRoundRect(
                    color = Color(0x18C9A227),
                    topLeft = Offset(size.width * 0.36f, size.height * 0.36f),
                    size = androidx.compose.ui.geometry.Size(size.width * .28f, size.height * .28f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f)
                )
                // Chemins vers les pôles
                val c = Offset(size.width * .5f, size.height * .5f)
                listOf(
                    Offset(size.width * .12f, size.height * .5f),
                    Offset(size.width * .88f, size.height * .5f),
                    Offset(size.width * .5f, size.height * .10f),
                    Offset(size.width * .5f, size.height * .90f)
                ).forEach { drawLine(Color(0x55C9A227), c, it, 2f) }
                // Traits de liaison map → portail
                if (showMaps && showPortals) {
                    for (pp in portalPins) {
                        val mp = mapPins.firstOrNull { it.linkedMapId != null && it.linkedMapId == pp.linkedMapId }
                        if (mp != null) {
                            val a = Offset(mp.x / 100f * size.width, mp.y / 100f * size.height)
                            val b = Offset(pp.x / 100f * size.width, pp.y / 100f * size.height)
                            drawLine(Color(0x66B06AB3), a, b, 1.5f)
                        }
                    }
                }
            }
            pins.forEach { pin ->
                val px = ((pin.x.coerceIn(4f, 96f)) / 100f * 92f).dp
                val py = ((pin.y.coerceIn(4f, 96f)) / 100f * 228f).dp
                Column(
                    Modifier
                        .offset(x = px, y = py)
                        .clickable { onZone(pin.zone) }
                        .padding(2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier
                            .size(if (pin.id.startsWith("map_") || pin.id.startsWith("portal_")) 12.dp else 16.dp)
                            .background(Color(pin.colorHint), CircleShape)
                            .border(1.dp, AgwColors.GoldSoft, CircleShape)
                    )
                    Text(pin.label, color = AgwColors.PaleMarble, fontSize = 8.sp, maxLines = 1)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LegendDot("Hub", 0xFFC9A227)
            LegendDot("Maps", 0xFF5DADE2)
            LegendDot("Portails", 0xFFB06AB3)
            LegendDot("Outils", 0xFF7AA66D)
        }
        Text(
            "${maps.size} carte(s) · ${portals.size} portail(s) · filtres actifs · liaisons map↔portail affichées",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.labelSmall
        )
    }
}


@Composable
private fun LegendDot(label: String, color: Long) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(Color(color), CircleShape))
        Spacer(Modifier.width(4.dp))
        Text(label, color = AgwColors.PaleMarble, fontSize = 8.sp, maxLines = 1)
    }
}

@Composable
private fun MobZone(
    projectId: String,
    mobs: List<MobEntity>,
    hasProject: Boolean,
    textures: List<TextureProject> = emptyList(),
    onAddPresets: () -> Unit,
    onSave: (MobEntity) -> Unit,
    onDelete: (MobEntity) -> Unit
) {
    val context = LocalContext.current

    // Nul tant qu'on crée un nouveau monstre ; rempli avec l'id du monstre en cours d'édition.
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }

    var name by rememberSaveable { mutableStateOf("Créature") }
    var id by rememberSaveable { mutableStateOf("agw:creature") }
    var vie by rememberSaveable { mutableStateOf("20") }
    var dmg by rememberSaveable { mutableStateOf("4") }
    var vit by rememberSaveable { mutableStateOf("0.25") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    // Comportement réel : ces booléens pilotent le JSON de comportement exporté
    // (minecraft:attack, poursuite du joueur, riposte aux dégâts subis).
    var hostile by rememberSaveable { mutableStateOf(true) }
    var poursuite by rememberSaveable { mutableStateOf(true) }
    var attaque by rememberSaveable { mutableStateOf(true) }
    var reactionDegats by rememberSaveable { mutableStateOf(true) }
    // Pouvoirs (buffs appliqués à l'entité côté PackGenerator).
    var pouvoirVitesse by rememberSaveable { mutableStateOf(false) }
    var pouvoirResistance by rememberSaveable { mutableStateOf(false) }
    var pouvoirInvisibilite by rememberSaveable { mutableStateOf(false) }
    var profilIA by rememberSaveable { mutableStateOf("guerrier") }
    var faction by rememberSaveable { mutableStateOf("neutre") }
    var detectionDistance by rememberSaveable { mutableStateOf("24") }
    var vitesseAttaque by rememberSaveable { mutableStateOf("1.0") }
    var cooldownAttaque by rememberSaveable { mutableStateOf("0") }
    var collisionLargeur by rememberSaveable { mutableStateOf("0.6") }
    var collisionHauteur by rememberSaveable { mutableStateOf("1.8") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }

    fun resetForm() {
        editingId = null
        name = "Créature"; id = "agw:creature"; vie = "20"; dmg = "4"; vit = "0.25"; tex = null
        hostile = true; poursuite = true; attaque = true; reactionDegats = true
        pouvoirVitesse = false; pouvoirResistance = false; pouvoirInvisibilite = false
        profilIA = "guerrier"; faction = "neutre"; detectionDistance = "24"; vitesseAttaque = "1.0"
        cooldownAttaque = "0"; collisionLargeur = "0.6"; collisionHauteur = "1.8"
    }

    fun loadForEdit(m: MobEntity) {
        editingId = m.id
        name = m.nom; id = m.identifiant
        vie = m.vie.toString(); dmg = m.degats.toString(); vit = m.vitesse.toString()
        tex = m.textureUri
        hostile = m.hostile; poursuite = m.poursuite; attaque = m.attaque; reactionDegats = m.reactionDegats
        pouvoirVitesse = m.pouvoirVitesse; pouvoirResistance = m.pouvoirResistance; pouvoirInvisibilite = m.pouvoirInvisibilite
        profilIA = m.profilIA; faction = m.faction; detectionDistance = m.detectionDistance.toString()
        vitesseAttaque = m.vitesseAttaque.toString(); cooldownAttaque = m.cooldownAttaque.toString()
        collisionLargeur = m.collisionLargeur.toString(); collisionHauteur = m.collisionHauteur.toString()
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Création de monstres", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        GoldPrimaryButton("Presets AGW (4 créatures)", onAddPresets)

        Text(
            if (editingId == null) "Nouveau monstre" else "Modification : ${name.ifBlank { "monstre" }}",
            fontWeight = FontWeight.SemiBold,
            color = AgwColors.GoldSoft
        )
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(vie, { vie = it }, label = { Text("PV") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(vit, { vit = it }, label = { Text("Vitesse") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Fichier image externe" else if (tex!!.startsWith("sbhtex://")) "Texture Studio liée ✓" else "Fichier externe ✓")
        }
        StudioTexturePicker(
            textures = textures,
            selectedUri = tex,
            onSelect = { tex = it },
            preferredFormats = listOf("ITEM_16", "BLOCK_16")
        )

        Text("Comportement", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text(
            "Un monstre hostile qui ne poursuit ni n'attaque restera immobile en jeu — coche les trois ensemble pour un vrai monstre agressif.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(hostile, { v -> hostile = v; if (v) { poursuite = true; attaque = true } })
            Text("Hostile", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(poursuite, { poursuite = it }); Text("Poursuit le joueur", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(attaque, { attaque = it }); Text("Attaque au contact", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(reactionDegats, { reactionDegats = it }); Text("Riposte quand on l'attaque", color = AgwColors.PaleMarble)
        }

        Text("IA avancée", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text("Profil", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("passif", "garde", "guerrier", "archer", "boss").forEach { option ->
                FilterChip(selected = profilIA == option, onClick = { profilIA = option }, label = { Text(option) })
            }
        }
        OutlinedTextField(faction, { faction = it.lowercase().replace(' ', '_') }, label = { Text("Faction") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(detectionDistance, { detectionDistance = it }, label = { Text("Détection") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(vitesseAttaque, { vitesseAttaque = it }, label = { Text("Vitesse attaque") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(cooldownAttaque, { cooldownAttaque = it }, label = { Text("Recharge (s)") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Text("Collision / taille", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(collisionLargeur, { collisionLargeur = it }, label = { Text("Largeur") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(collisionHauteur, { collisionHauteur = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
        }

        Text("Pouvoirs", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirVitesse, { pouvoirVitesse = it }); Text("Vitesse (+50%)", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirResistance, { pouvoirResistance = it }); Text("Résistance", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirInvisibilite, { pouvoirInvisibilite = it }); Text("Invisibilité", color = AgwColors.PaleMarble)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onSave(
                        MobEntity(
                            id = editingId ?: java.util.UUID.randomUUID().toString(),
                            projectId = projectId,
                            nom = name,
                            identifiant = id,
                            vie = vie.toIntOrNull() ?: 20,
                            degats = dmg.toIntOrNull() ?: 4,
                            vitesse = vit.toDoubleOrNull() ?: 0.25,
                            hostile = hostile,
                            poursuite = poursuite,
                            attaque = attaque,
                            reactionDegats = reactionDegats,
                            pouvoirVitesse = pouvoirVitesse,
                            pouvoirResistance = pouvoirResistance,
                            pouvoirInvisibilite = pouvoirInvisibilite,
                            profilIA = profilIA,
                            faction = faction.ifBlank { "neutre" },
                            detectionDistance = detectionDistance.replace(',', '.').toDoubleOrNull()?.coerceIn(1.0, 128.0) ?: 24.0,
                            vitesseAttaque = vitesseAttaque.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 4.0) ?: 1.0,
                            cooldownAttaque = cooldownAttaque.replace(',', '.').toDoubleOrNull()?.coerceIn(0.0, 60.0) ?: 0.0,
                            collisionLargeur = collisionLargeur.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 4.0) ?: 0.6,
                            collisionHauteur = collisionHauteur.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 8.0) ?: 1.8,
                            textureUri = tex
                        )
                    )
                    resetForm()
                },
                modifier = Modifier.weight(1f),
                enabled = hasProject
            ) { Text(if (editingId == null) "Ajouter" else "Enregistrer les modifications") }
            if (editingId != null) {
                OutlinedButton({ resetForm() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
            }
        }

        mobs.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(m.nom, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.identifiant} · PV ${m.vie} · DMG ${m.degats}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        val tags = buildList {
                            if (m.hostile) add("hostile")
                            if (m.poursuite) add("poursuite")
                            if (m.attaque) add("attaque")
                            if (m.pouvoirVitesse) add("+vitesse")
                            if (m.pouvoirResistance) add("+résistance")
                            if (m.pouvoirInvisibilite) add("+invisibilité")
                            if (m.faction != "neutre") add("faction:${m.faction}")
                            add("IA:${m.profilIA}")
                        }
                        if (tags.isNotEmpty()) {
                            Text(tags.joinToString(" · "), color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    TextButton({ loadForEdit(m) }) { Text("✎") }
                    TextButton({ if (editingId == m.id) resetForm(); onDelete(m) }) { Text("X") }
                }
            }
        }
        if (mobs.isEmpty()) Text("Aucun monstre pour ce projet.", color = AgwColors.Sand)
    }
}

private val PORTAL_DIMENSIONS = listOf("minecraft:overworld", "minecraft:nether", "minecraft:the_end")
private fun dimensionLabel(id: String) = when (id) {
    "minecraft:nether" -> "Nether"
    "minecraft:the_end" -> "End"
    else -> "Overworld"
}

private fun portalCodeTokens(line: String): List<String> =
    Regex("\\\"[^\\\"]*\\\"|'[^']*'|[^\\s]+")
        .findAll(line.trim())
        .map { it.value.trim('\"', '\'') }
        .toList()

private fun portalCodeUnquote(value: String): String = value.trim().trim('\"', '\'')

private fun validatePortalCode(source: String): List<String> {
    val errors = mutableListOf<String>()
    source.lines().forEachIndexed { index, raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) return@forEachIndexed
        val t = portalCodeTokens(line)
        when (t.firstOrNull()) {
            "portal.create" -> if (t.size < 2) errors += "Ligne ${index + 1} : portal.create(\"Nom\")"
            "portal.size" -> if (t.size < 3 || t[1].toIntOrNull() == null || t[2].toIntOrNull() == null) errors += "Ligne ${index + 1} : portal.size(largeur hauteur)"
            "portal.frame" -> if (t.size < 2) errors += "Ligne ${index + 1} : portal.frame(\"namespace:bloc\")"
            "portal.destination" -> if (t.size < 5 || t[1].toIntOrNull() == null || t[2].toIntOrNull() == null || t[3].toIntOrNull() == null) errors += "Ligne ${index + 1} : portal.destination(X Y Z \"dimension\")"
            "portal.description" -> if (t.size < 2) errors += "Ligne ${index + 1} : portal.description(\"Description\")"
            "portal.map" -> if (t.size < 5 || t[2].toIntOrNull() == null || t[3].toIntOrNull() == null || t[4].toIntOrNull() == null) errors += "Ligne ${index + 1} : portal.map(\"mapId\" X Y Z)"
            else -> errors += "Ligne ${index + 1} : commande inconnue « ${t.firstOrNull() ?: ""} »"
        }
    }
    return errors
}

private fun applyPortalCode(source: String, base: PortalBlueprint): PortalBlueprint {
    var result = base
    source.lines().forEach { raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) return@forEach
        val t = portalCodeTokens(line)
        when (t.firstOrNull()) {
            "portal.create" -> if (t.size >= 2) result = result.copy(name = portalCodeUnquote(t[1]))
            "portal.size" -> if (t.size >= 3) result = result.copy(width = t[1].toIntOrNull() ?: result.width, height = t[2].toIntOrNull() ?: result.height)
            "portal.frame" -> if (t.size >= 2) result = result.copy(frameBlock = portalCodeUnquote(t[1]))
            "portal.destination" -> if (t.size >= 5) result = result.copy(
                destX = t[1].toIntOrNull() ?: result.destX,
                destY = t[2].toIntOrNull() ?: result.destY,
                destZ = t[3].toIntOrNull() ?: result.destZ,
                destDimension = portalCodeUnquote(t[4])
            )
            "portal.description" -> if (t.size >= 2) result = result.copy(destinationHint = portalCodeUnquote(t[1]))
            "portal.map" -> if (t.size >= 5) result = result.copy(linkedMapId = portalCodeUnquote(t[1]), mapX = t[2].toIntOrNull() ?: result.mapX, mapY = t[3].toIntOrNull() ?: result.mapY, mapZ = t[4].toIntOrNull() ?: result.mapZ)
        }
    }
    return result
}

@Composable
private fun PortalPreview(portal: PortalBlueprint) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("👁 Aperçu visuel du portail", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
            Text("Vue frontale · ${portal.width}×${portal.height} · ${portal.frameBlock}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(AgwColors.DeepNight)
            ) {
                val cols = portal.width.coerceIn(2, 16)
                val rows = portal.height.coerceIn(3, 16)
                val cell = minOf(size.width / (cols + 4f), size.height / (rows + 4f))
                val totalW = cols * cell
                val totalH = rows * cell
                val left = (size.width - totalW) / 2f
                val top = (size.height - totalH) / 2f
                val frameColor = AgwColors.DesertOchre
                val innerColor = Color(0xFF24163A)
                val glowColor = AgwColors.SacredGold.copy(alpha = 0.28f)
                drawRect(glowColor, Offset(left + cell, top + cell), androidx.compose.ui.geometry.Size(totalW - 2 * cell, totalH - 2 * cell))
                for (x in 0 until cols) for (y in 0 until rows) {
                    val isFrame = x == 0 || x == cols - 1 || y == 0 || y == rows - 1
                    drawRect(
                        if (isFrame) frameColor else innerColor,
                        Offset(left + x * cell, top + y * cell),
                        androidx.compose.ui.geometry.Size(cell - 1.5f, cell - 1.5f)
                    )
                }
                drawRect(frameColor, Offset(left, top), androidx.compose.ui.geometry.Size(totalW, totalH), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f))
            }
            Text("Destination : ${portal.destinationHint} · (${portal.destX}, ${portal.destY}, ${portal.destZ}) · ${dimensionLabel(portal.destDimension)}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
            if (portal.linkedMapId != null) Text("🔗 Map liée : ${portal.linkedMapId} · position (${portal.mapX}, ${portal.mapY}, ${portal.mapZ})", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PortalZone(
    projectId: String,
    portals: List<PortalBlueprint>,
    maps: List<MapBlueprint>,
    textures: List<TextureProject> = emptyList(),
    onSave: (PortalBlueprint) -> Unit,
    onDelete: (PortalBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var codeMode by rememberSaveable { mutableStateOf(false) }
    var codeStatus by rememberSaveable { mutableStateOf("Prêt") }
    var code by rememberSaveable {
        mutableStateOf(
            "portal.create(\"Portail Al-Zahra\")\n" +
            "portal.size(4 5)\n" +
            "portal.frame(\"agw:night_bricks\")\n" +
            "portal.destination(0 64 0 \"minecraft:overworld\")\n" +
            "portal.description(\"الزهراء · Al-Zahra\")" + if (maps.isNotEmpty()) "\nportal.map(\"${maps.first().id}\" 8 64 8)" else ""
        )
    }

    var name by rememberSaveable { mutableStateOf("Portail Al-Zahra") }
    var identifier by rememberSaveable { mutableStateOf("agw:portal_custom") }
    var width by rememberSaveable { mutableStateOf("4") }
    var height by rememberSaveable { mutableStateOf("5") }
    var frame by rememberSaveable { mutableStateOf("agw:night_bricks") }
    var dest by rememberSaveable { mutableStateOf("الزهراء · Al-Zahra") }
    var destX by rememberSaveable { mutableStateOf("0") }
    var destY by rememberSaveable { mutableStateOf("64") }
    var destZ by rememberSaveable { mutableStateOf("0") }
    var destDim by rememberSaveable { mutableStateOf(PORTAL_DIMENSIONS[0]) }
    var linkedMapId by rememberSaveable { mutableStateOf<String?>(null) }
    var mapX by rememberSaveable { mutableStateOf("0") }
    var mapY by rememberSaveable { mutableStateOf("64") }
    var mapZ by rememberSaveable { mutableStateOf("0") }

    fun currentPortal() = PortalBlueprint(
        id = editingId ?: java.util.UUID.randomUUID().toString(), projectId = projectId,
        name = name, identifier = identifier, width = width.toIntOrNull() ?: 4, height = height.toIntOrNull() ?: 5,
        frameBlock = frame, destinationHint = dest, destX = destX.toIntOrNull() ?: 0,
        destY = destY.toIntOrNull() ?: 64, destZ = destZ.toIntOrNull() ?: 0, destDimension = destDim,
        linkedMapId = linkedMapId, mapX = mapX.toIntOrNull() ?: 0, mapY = mapY.toIntOrNull() ?: 64, mapZ = mapZ.toIntOrNull() ?: 0
    )

    fun loadIntoForm(p: PortalBlueprint) {
        editingId = p.id; name = p.name; identifier = p.identifier; width = p.width.toString(); height = p.height.toString()
        frame = p.frameBlock; dest = p.destinationHint; destX = p.destX.toString(); destY = p.destY.toString(); destZ = p.destZ.toString(); destDim = p.destDimension
        linkedMapId = p.linkedMapId; mapX = p.mapX.toString(); mapY = p.mapY.toString(); mapZ = p.mapZ.toString()
        code = "portal.create(\"${p.name}\")\nportal.size(${p.width} ${p.height})\nportal.frame(\"${p.frameBlock}\")\nportal.destination(${p.destX} ${p.destY} ${p.destZ} \"${p.destDimension}\")\nportal.description(\"${p.destinationHint}\")" + if (p.linkedMapId != null) "\nportal.map(\"${p.linkedMapId}\" ${p.mapX} ${p.mapY} ${p.mapZ})" else ""
    }

    fun resetForm() {
        editingId = null; name = "Portail Al-Zahra"; identifier = "agw:portal_custom"; width = "4"; height = "5"; frame = "agw:night_bricks"
        dest = "الزهراء · Al-Zahra"; destX = "0"; destY = "64"; destZ = "0"; destDim = PORTAL_DIMENSIONS[0]
        linkedMapId = null; mapX = "0"; mapY = "64"; mapZ = "0"
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Portails Minecraft", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                Text("Crée le portail visuellement ou par code, puis vérifie immédiatement son apparence.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = { codeMode = !codeMode }) { Text(if (codeMode) "✎ Formulaire" else "💻 Code") }
        }

        if (codeMode) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💻 SBh PORTAL CODE", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold, modifier = Modifier.weight(1f))
                        Text(codeStatus, color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("Écris les commandes du portail. Le clavier Android apparaît directement dans le champ.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it; codeStatus = "Modifié" },
                        modifier = Modifier.fillMaxWidth().height(210.dp),
                        textStyle = LocalTextStyle.current.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                        label = { Text("Code de génération") }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("()", "{}", "[ ]", "\"\"", "=", ",").forEach { key ->
                            OutlinedButton(onClick = { code += key.first().toString() }) { Text(key) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val errors = validatePortalCode(code)
                            codeStatus = if (errors.isEmpty()) "✓ Code valide" else "✕ ${errors.first()}"
                        }, modifier = Modifier.weight(1f)) { Text("✓ Vérifier") }
                        Button(onClick = {
                            val errors = validatePortalCode(code)
                            if (errors.isNotEmpty()) { codeStatus = "✕ ${errors.first()}"; return@Button }
                            val p = applyPortalCode(code, currentPortal())
                            loadIntoForm(p)
                            codeStatus = "✓ Portail généré"
                        }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)) { Text("▶ Générer") }
                    }
                }
            }
            PortalPreview(currentPortal())
        } else {
            Text("Marcher sur le bloc du portail téléporte réellement le joueur aux coordonnées choisies ci-dessous (script embarqué dans le pack).", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(width, { width = it }, label = { Text("Largeur") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(height, { height = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            OutlinedTextField(frame, { frame = it }, label = { Text("Bloc cadre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(dest, { dest = it }, label = { Text("Description destination") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Coordonnées de téléportation", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(destX, { destX = it }, label = { Text("X") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(destY, { destY = it }, label = { Text("Y") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(destZ, { destZ = it }, label = { Text("Z") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PORTAL_DIMENSIONS.forEach { d ->
                    val selected = destDim == d
                    OutlinedButton(onClick = { destDim = d }, colors = if (selected) ButtonDefaults.outlinedButtonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight) else ButtonDefaults.outlinedButtonColors(contentColor = AgwColors.PaleMarble)) { Text(dimensionLabel(d)) }
                }
            }
            Text("🔗 Connexion à une map", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
            Text("Le portail peut maintenant appartenir à une map et transmettre sa position au mode Map.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                OutlinedButton(onClick = { linkedMapId = null }) { Text(if (linkedMapId == null) "Aucune map" else "Déconnecter") }
                maps.forEach { m ->
                    val selected = linkedMapId == m.id
                    OutlinedButton(onClick = { linkedMapId = m.id }, colors = if (selected) ButtonDefaults.outlinedButtonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight) else ButtonDefaults.outlinedButtonColors(contentColor = AgwColors.PaleMarble)) { Text(m.name) }
                }
            }
            if (linkedMapId != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(mapX, { mapX = it }, label = { Text("Map X") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(mapY, { mapY = it }, label = { Text("Map Y") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(mapZ, { mapZ = it }, label = { Text("Map Z") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
            PortalPreview(currentPortal())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onSave(currentPortal()); resetForm() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)) { Text(if (editingId == null) "Enregistrer le portail" else "Enregistrer les modifications") }
                if (editingId != null) OutlinedButton({ resetForm() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
            }
        }

        portals.forEach { p ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${p.identifier} · ${p.width}×${p.height}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        Text("→ ${p.destinationHint} · (${p.destX}, ${p.destY}, ${p.destZ}) ${dimensionLabel(p.destDimension)}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ loadIntoForm(p) }) { Text("✎") }
                    TextButton({ if (editingId == p.id) resetForm(); onDelete(p) }) { Text("X") }
                }
            }
        }
        if (portals.isEmpty()) Text("Aucun portail pour ce projet.", color = AgwColors.Sand)
    }
}

@Composable
private fun MapZone(
    projectId: String,
    maps: List<MapBlueprint>,
    portals: List<PortalBlueprint>,
    mobs: List<MobEntity> = emptyList(),
    items: List<SbhItem> = emptyList(),
    blocks: List<SbhBlock> = emptyList(),
    textures: List<TextureProject> = emptyList(),
    onSave: (MapBlueprint) -> Unit,
    onLinkPortal: (PortalBlueprint, String?) -> Unit,
    onDelete: (MapBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var name by rememberSaveable { mutableStateOf("Nouvelle map") }
    var sizeX by rememberSaveable { mutableStateOf("64") }
    var sizeZ by rememberSaveable { mutableStateOf("64") }
    var height by rememberSaveable { mutableStateOf("64") }
    var terrain by rememberSaveable { mutableStateOf("desert") }
    var dimension by rememberSaveable { mutableStateOf("minecraft:overworld") }
    var seed by rememberSaveable { mutableStateOf("0") }
    var worldX by rememberSaveable { mutableStateOf("0") }
    var worldZ by rememberSaveable { mutableStateOf("0") }
    var village by rememberSaveable { mutableStateOf(true) }
    var dungeon by rememberSaveable { mutableStateOf(true) }
    var oasis by rememberSaveable { mutableStateOf(false) }
    var mountains by rememberSaveable { mutableStateOf(false) }
    var roads by rememberSaveable { mutableStateOf(false) }
    var notes by rememberSaveable { mutableStateOf("") }
    var showErrors by rememberSaveable { mutableStateOf(false) }
    var linkedMobIds by remember { mutableStateOf(listOf<String>()) }
    var linkedItemIds by remember { mutableStateOf(listOf<String>()) }
    var linkedBlockIds by remember { mutableStateOf(listOf<String>()) }
    var worldFilterTextureId by rememberSaveable { mutableStateOf<String?>(null) }

    val parsedX = sizeX.toIntOrNull()
    val parsedZ = sizeZ.toIntOrNull()
    val parsedH = height.toIntOrNull()
    val valid = name.isNotBlank() && parsedX != null && parsedX in 8..512 && parsedZ != null && parsedZ in 8..512 && parsedH != null && parsedH in 16..384
    val current = maps.firstOrNull { it.id == editingId }

    fun reset() {
        editingId = null
        name = "Nouvelle map"; sizeX = "64"; sizeZ = "64"; height = "64"
        terrain = "desert"; dimension = "minecraft:overworld"; seed = "0"; worldX = "0"; worldZ = "0"
        village = true; dungeon = true; oasis = false; mountains = false; roads = false; notes = ""; showErrors = false
        linkedMobIds = emptyList(); linkedItemIds = emptyList(); linkedBlockIds = emptyList(); worldFilterTextureId = null
    }

    fun load(m: MapBlueprint) {
        editingId = m.id; name = m.name; sizeX = m.sizeX.toString(); sizeZ = m.sizeZ.toString(); height = m.height.toString()
        terrain = m.terrain; dimension = m.dimension; seed = m.seed.toString(); worldX = m.worldX.toString(); worldZ = m.worldZ.toString()
        village = m.hasVillage; dungeon = m.hasDungeon; oasis = m.hasOasis; mountains = m.hasMountains; roads = m.hasRoads; notes = m.notes; showErrors = false
        linkedMobIds = m.linkedMobIds; linkedItemIds = m.linkedItemIds; linkedBlockIds = m.linkedBlockIds
        worldFilterTextureId = m.worldFilterTextureId
    }

    fun submit() {
        if (!valid) { showErrors = true; return }
        val existing = current
        onSave(MapBlueprint(
            id = existing?.id ?: java.util.UUID.randomUUID().toString(),
            projectId = projectId,
            name = name.trim(),
            sizeX = parsedX ?: 64,
            sizeZ = parsedZ ?: 64,
            height = parsedH ?: 64,
            theme = "desert_gothic",
            terrain = terrain,
            seed = seed.toLongOrNull() ?: 0L,
            worldX = worldX.toIntOrNull() ?: 0,
            worldZ = worldZ.toIntOrNull() ?: 0,
            hasVillage = village,
            hasDungeon = dungeon,
            hasOasis = oasis,
            hasMountains = mountains,
            hasRoads = roads,
            dimension = dimension.trim().ifBlank { "minecraft:overworld" },
            linkedMobIds = linkedMobIds,
            linkedItemIds = linkedItemIds,
            linkedBlockIds = linkedBlockIds,
            worldFilterTextureId = worldFilterTextureId,
            notes = notes.trim()
        ))
        reset()
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("🗺️ Cartes du monde", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold, fontSize = 20.sp)
        Text("Cette map est reliée à l'Atelier (mobs, items, blocs, portails, textures). Map Studio peut l'utiliser comme base 3D.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)

        Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (editingId == null) "Nouvelle carte" else "Modifier la carte", fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(sizeX, { sizeX = it }, label = { Text("Largeur X") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(sizeZ, { sizeZ = it }, label = { Text("Longueur Z") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(height, { height = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(worldX, { worldX = it }, label = { Text("Monde X") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(worldZ, { worldZ = it }, label = { Text("Monde Z") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(seed, { seed = it }, label = { Text("Seed") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(terrain, { terrain = it }, label = { Text("Terrain / biome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(dimension, { dimension = it }, label = { Text("Dimension") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(village, { village = it }); Text("Village", color = AgwColors.PaleMarble)
                    Checkbox(dungeon, { dungeon = it }); Text("Donjon", color = AgwColors.PaleMarble)
                    Checkbox(oasis, { oasis = it }); Text("Oasis", color = AgwColors.PaleMarble)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(mountains, { mountains = it }); Text("Montagnes", color = AgwColors.PaleMarble)
                    Checkbox(roads, { roads = it }); Text("Routes", color = AgwColors.PaleMarble)
                }
                Text("Liaisons atelier", fontWeight = FontWeight.SemiBold, color = AgwColors.SacredGold)
                LinkChipRow(
                    title = "Mobs sur cette map",
                    all = mobs,
                    selectedIds = linkedMobIds,
                    idOf = { it.id },
                    labelOf = { it.nom },
                    onToggle = { id ->
                        linkedMobIds = if (id in linkedMobIds) linkedMobIds - id else linkedMobIds + id
                    }
                )
                LinkChipRow(
                    title = "Items (loot / commerce)",
                    all = items,
                    selectedIds = linkedItemIds,
                    idOf = { it.id },
                    labelOf = { it.name },
                    onToggle = { id ->
                        linkedItemIds = if (id in linkedItemIds) linkedItemIds - id else linkedItemIds + id
                    }
                )
                LinkChipRow(
                    title = "Blocs de construction",
                    all = blocks,
                    selectedIds = linkedBlockIds,
                    idOf = { it.id },
                    labelOf = { it.name },
                    onToggle = { id ->
                        linkedBlockIds = if (id in linkedBlockIds) linkedBlockIds - id else linkedBlockIds + id
                    }
                )
                StudioTexturePicker(
                    textures = textures,
                    selectedUri = worldFilterTextureId?.let { "sbhtex://$it" },
                    onSelect = { uri ->
                        worldFilterTextureId = uri?.removePrefix("sbhtex://")
                    },
                    preferredFormats = listOf("FILTER_MAP", "BLOCK_32", "BLOCK_16")
                )
                Text("Filtre monde (texture d'ambiance)", color = AgwColors.Sand, fontSize = 11.sp)

                OutlinedTextField(notes, { notes = it }, label = { Text("Notes / description") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                if (showErrors && !valid) Text("⚠ Vérifie le nom et les dimensions : X/Z 8–512, hauteur 16–384.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { submit() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)) {
                        Text(if (editingId == null) "Créer la map" else "Enregistrer")
                    }
                    if (editingId != null) OutlinedButton(onClick = { reset() }) { Text("Annuler") }
                }
            }
        }

        maps.forEach { m ->
            val linked = portals.filter { it.linkedMapId == m.id }
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(m.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                            Text("ID: ${m.id}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                            Text("${m.sizeX}×${m.sizeZ}×${m.height} · ${m.terrain} · ${m.dimension}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                            Text("Position monde : ${m.worldX}, ${m.worldZ} · Seed : ${m.seed}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        }
                        Row {
                            TextButton({ load(m) }) { Text("✎") }
                            TextButton({ onDelete(m); if (editingId == m.id) reset() }) { Text("X") }
                        }
                    }

                    MapPreviewCard(m)

                    Text("🔗 Portails liés : ${linked.size}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    if (portals.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            portals.forEach { p ->
                                val selected = p.linkedMapId == m.id
                                OutlinedButton(
                                    onClick = { onLinkPortal(p, if (selected) null else m.id) },
                                    colors = if (selected) ButtonDefaults.outlinedButtonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight) else ButtonDefaults.outlinedButtonColors(contentColor = AgwColors.PaleMarble)
                                ) { Text(if (selected) "✓ ${p.name}" else "+ ${p.name}") }
                            }
                        }
                    } else {
                        Text("Crée d’abord un portail pour le rattacher à cette map.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        if (maps.isEmpty()) Text("Aucune map. Crée la première carte ci-dessus.", color = AgwColors.Sand)
    }
}

@Composable
private fun MapPreviewCard(map: MapBlueprint) {
    Card(colors = CardDefaults.cardColors(containerColor = AgwColors.DeepNight), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(8.dp)) {
            Text("Aperçu logique · ${map.terrain}", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
            Canvas(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF15110D))) {
                val w = size.width
                val h = size.height
                val cols = maxOf(8, minOf(32, map.sizeX / 4))
                val rows = maxOf(8, minOf(24, map.sizeZ / 4))
                val cw = w / cols
                val rh = h / rows
                for (z in 0 until rows) {
                    for (x in 0 until cols) {
                        val nx = x.toFloat() / cols
                        val nz = z.toFloat() / rows
                        val oasis = map.hasOasis && ((nx - 0.35f) * (nx - 0.35f) + (nz - 0.55f) * (nz - 0.55f) < 0.025f)
                        val mountain = map.hasMountains && (nz < 0.25f && nx > 0.45f)
                        val c = when {
                            oasis -> Color(0xFF3D6B45)
                            mountain -> Color(0xFF5A5550)
                            map.terrain.contains("snow", true) -> Color(0xFFD9D3C7)
                            map.terrain.contains("forest", true) -> Color(0xFF40553B)
                            map.terrain.contains("plains", true) -> Color(0xFF6D7144)
                            else -> Color(0xFF8C6B43)
                        }
                        drawRect(c, Offset(x * cw, z * rh), androidx.compose.ui.geometry.Size(cw + 1f, rh + 1f))
                    }
                }
                if (map.hasRoads) {
                    drawLine(Color(0xFFD8B56A), Offset(0f, h * 0.68f), Offset(w, h * 0.68f), strokeWidth = 4f)
                    drawLine(Color(0xFFD8B56A), Offset(w * 0.58f, 0f), Offset(w * 0.58f, h), strokeWidth = 4f)
                }
                if (map.hasVillage) {
                    drawCircle(Color(0xFFE2C15A), radius = 8f, center = Offset(w * 0.58f, h * 0.68f))
                }
                if (map.hasDungeon) {
                    drawCircle(Color(0xFFB34B4B), radius = 7f, center = Offset(w * 0.72f, h * 0.32f))
                }
            }
        }
    }
}

@Composable
private fun ItemZone(
    projectId: String,
    items: List<SbhItem>,
    textures: List<TextureProject> = emptyList(),
    onAdd: (SbhItem) -> Unit,
    onDelete: (SbhItem) -> Unit
) {
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("Nouvel item") }
    var id by rememberSaveable { mutableStateOf("agw:nouvel_item") }
    var dmg by rememberSaveable { mutableStateOf("0") }
    var dur by rememberSaveable { mutableStateOf("100") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Objets & armes", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(dur, { dur = it }, label = { Text("Durabilité") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Fichier image externe" else if (tex!!.startsWith("sbhtex://")) "Texture Studio liée ✓" else "Fichier externe ✓")
        }
        StudioTexturePicker(
            textures = textures,
            selectedUri = tex,
            onSelect = { tex = it },
            preferredFormats = listOf("BLOCK_16", "BLOCK_32", "FILTER_MAP")
        )
        Button(
            onClick = {
                onAdd(SbhItem(projectId = projectId, name = name, identifier = id, damage = dmg.toIntOrNull() ?: 0, durability = dur.toIntOrNull() ?: 100, textureUri = tex))
                tex = null
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Ajouter l'item") }

        items.forEach { i ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(i.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${i.identifier} · DMG ${i.damage} · Dur ${i.durability}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(i) }) { Text("X") }
                }
            }
        }
        if (items.isEmpty()) Text("Aucun item pour ce projet.", color = AgwColors.Sand)
    }
}

@Composable
private fun BlockZone(
    projectId: String,
    blocks: List<SbhBlock>,
    textures: List<TextureProject> = emptyList(),
    onAdd: (SbhBlock) -> Unit,
    onDelete: (SbhBlock) -> Unit
) {
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("Nouveau bloc") }
    var id by rememberSaveable { mutableStateOf("agw:nouveau_bloc") }
    var hardness by rememberSaveable { mutableStateOf("1.0") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Blocs & architecture", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(hardness, { hardness = it }, label = { Text("Résistance") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Fichier image externe" else if (tex!!.startsWith("sbhtex://")) "Texture Studio liée ✓" else "Fichier externe ✓")
        }
        StudioTexturePicker(
            textures = textures,
            selectedUri = tex,
            onSelect = { tex = it },
            preferredFormats = listOf("BLOCK_16", "BLOCK_32", "FILTER_MAP")
        )
        Button(
            onClick = {
                onAdd(SbhBlock(projectId = projectId, name = name, identifier = id, hardness = hardness.toDoubleOrNull() ?: 1.0, textureUri = tex))
                tex = null
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Ajouter le bloc") }

        blocks.forEach { b ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(b.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${b.identifier} · Résistance ${b.hardness}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(b) }) { Text("X") }
                }
            }
        }
        if (blocks.isEmpty()) Text("Aucun bloc pour ce projet.", color = AgwColors.Sand)
    }
}

@Composable
private fun ExportZone(
    reportText: String,
    hasProject: Boolean,
    counts: String,
    onValidate: () -> Unit,
    onExport: () -> Unit,
    onImportAgw: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Validation & export complet", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Projet : ${if (hasProject) "ouvert" else "aucun"} · $counts", color = AgwColors.Sand)
        if (!hasProject) {
            Text("Astuce : Accueil → ouvrez un projet → Atelier.", color = AgwColors.DesertOchre)
        }
        GoldOutlineButton("Importer AGW puis exporter", onImportAgw, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldOutlineButton("Valider", onValidate, modifier = Modifier.weight(1f))
            GoldPrimaryButton("Exporter", onExport, modifier = Modifier.weight(1f))
        }
        if (reportText.isNotBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = AgwColors.NightGlass),
                shape = AgwDecor.CardShape,
                modifier = Modifier.fillMaxWidth().border(AgwDecor.GoldBorder, AgwDecor.CardShape)
            ) {
                Text(reportText, Modifier.padding(12.dp), color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}


@Composable
private fun RecipeZone(
    projectId: String,
    recipes: List<RecipeBlueprint>,
    items: List<SbhItem>,
    onSave: (RecipeBlueprint) -> Unit,
    onDelete: (RecipeBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var name by rememberSaveable { mutableStateOf("Nouvelle recette") }
    var identifier by rememberSaveable { mutableStateOf("agw:recipe_custom") }
    var type by rememberSaveable { mutableStateOf("minecraft:recipe_shaped") }
    var resultId by rememberSaveable { mutableStateOf("agw:item_custom") }
    var resultCount by rememberSaveable { mutableStateOf("1") }
    // 9 cases pour shaped
    var c0 by rememberSaveable { mutableStateOf("") }
    var c1 by rememberSaveable { mutableStateOf("") }
    var c2 by rememberSaveable { mutableStateOf("") }
    var c3 by rememberSaveable { mutableStateOf("") }
    var c4 by rememberSaveable { mutableStateOf("") }
    var c5 by rememberSaveable { mutableStateOf("") }
    var c6 by rememberSaveable { mutableStateOf("") }
    var c7 by rememberSaveable { mutableStateOf("") }
    var c8 by rememberSaveable { mutableStateOf("") }
    var ingredientsText by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }

    fun patternList() = listOf(c0, c1, c2, c3, c4, c5, c6, c7, c8)

    fun reset() {
        editingId = null
        name = "Nouvelle recette"; identifier = "agw:recipe_custom"
        type = "minecraft:recipe_shaped"; resultId = "agw:item_custom"; resultCount = "1"
        c0 = ""; c1 = ""; c2 = ""; c3 = ""; c4 = ""; c5 = ""; c6 = ""; c7 = ""; c8 = ""
        ingredientsText = ""; notes = ""
    }

    fun load(r: RecipeBlueprint) {
        editingId = r.id; name = r.name; identifier = r.identifier; type = r.type
        resultId = r.resultId; resultCount = r.resultCount.toString(); notes = r.notes
        val p = r.pattern + List(9) { "" }
        c0 = p[0]; c1 = p[1]; c2 = p[2]; c3 = p[3]; c4 = p[4]; c5 = p[5]; c6 = p[6]; c7 = p[7]; c8 = p[8]
        ingredientsText = r.ingredients.joinToString(", ")
    }

    fun submit() {
        val r = RecipeBlueprint(
            id = editingId ?: java.util.UUID.randomUUID().toString(),
            projectId = projectId,
            name = name.trim().ifBlank { "Recette" },
            identifier = identifier.trim().ifBlank { "agw:recipe_custom" },
            type = type,
            resultId = resultId.trim().ifBlank { "agw:item_custom" },
            resultCount = resultCount.toIntOrNull()?.coerceIn(1, 64) ?: 1,
            pattern = patternList(),
            ingredients = ingredientsText.split(",", ";", "\n").map { it.trim() }.filter { it.isNotEmpty() },
            notes = notes
        )
        onSave(r)
        reset()
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Recettes de craft", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Crée des recettes shaped, shapeless ou four. La grille 3×3 est utilisée pour le type shaped.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)

        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "minecraft:recipe_shaped" to "Shaped",
                "minecraft:recipe_shapeless" to "Shapeless",
                "minecraft:recipe_furnace" to "Four"
            ).forEach { (id, label) ->
                FilterChip(selected = type == id, onClick = { type = id }, label = { Text(label, fontSize = 11.sp) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(resultId, { resultId = it }, label = { Text("Résultat") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(resultCount, { resultCount = it }, label = { Text("Qté") }, modifier = Modifier.width(80.dp), singleLine = true)
        }

        if (type == "minecraft:recipe_shaped") {
            Text("Grille 3×3 (identifiant de bloc/item ou vide)", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
            // Preview visuelle de la grille
            RecipeGridPreview(patternList(), resultId, resultCount.toIntOrNull() ?: 1)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(c0, { c0 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c1, { c1 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c2, { c2 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(c3, { c3 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c4, { c4 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c5, { c5 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(c6, { c6 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c7, { c7 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c8, { c8 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
            }
        } else {
            OutlinedTextField(
                ingredientsText,
                { ingredientsText = it },
                label = { Text("Ingrédients (séparés par ,)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
        }

        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldPrimaryButton(if (editingId != null) "Mettre à jour" else "Ajouter", onClick = { submit() }, modifier = Modifier.weight(1f))
            if (editingId != null) {
                GoldOutlineButton("Annuler", onClick = { reset() }, modifier = Modifier.weight(1f))
            }
        }

        SectionTitle("Recettes du projet (${recipes.size})")
        if (recipes.isEmpty()) {
            Text("Aucune recette. Créez-en une ci-dessus ou appliquez un template depuis le Hub.", color = AgwColors.Sand)
        } else {
            recipes.forEach { r ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                            Text("${r.identifier} → ${r.resultCount}× ${r.resultId}", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                            Text(r.type.removePrefix("minecraft:recipe_"), color = AgwColors.DesertOchre, style = MaterialTheme.typography.labelSmall)
                        }
                        TextButton(onClick = { load(r) }) { Text("Éditer", color = AgwColors.GoldSoft) }
                        TextButton(onClick = { onDelete(r) }) { Text("Suppr.", color = Color(0xFFB94E48)) }
                    }
                }
            }
        }

        if (items.isNotEmpty()) {
            Text("Astuce : items du projet disponibles comme résultat → ${items.take(5).joinToString { it.identifier }}", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RecipeGridPreview(pattern: List<String>, resultId: String, resultCount: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Grille 3x3
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (row in 0 until 3) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (col in 0 until 3) {
                        val idx = row * 3 + col
                        val cell = pattern.getOrElse(idx) { "" }
                        Box(
                            Modifier
                                .size(28.dp)
                                .background(if (cell.isBlank()) Color(0xFF1A1F28) else Color(0xFF2A3544), RoundedCornerShape(4.dp))
                                .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.4f), RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (cell.isNotBlank()) {
                                Text(cell.takeLast(3), color = AgwColors.PaleMarble, fontSize = 7.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        Text("→", color = AgwColors.SacredGold, fontSize = 20.sp)
        Box(
            Modifier
                .size(40.dp)
                .background(Color(0xFF2A3544), RoundedCornerShape(6.dp))
                .border(1.dp, AgwColors.SacredGold, RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(resultId.takeLast(4), color = AgwColors.PaleMarble, fontSize = 8.sp, maxLines = 1)
                if (resultCount > 1) Text("×$resultCount", color = AgwColors.SacredGold, fontSize = 9.sp)
            }
        }
    }
}


private fun zoneLabel(z: WorkshopZoneId) = when (z) {
    WorkshopZoneId.HUB -> "Hub"
    WorkshopZoneId.MOBS -> "Monstres"
    WorkshopZoneId.PORTALS -> "Portails"
    WorkshopZoneId.MAPS -> "Maps"
    WorkshopZoneId.BLOCKS -> "Blocs"
    WorkshopZoneId.ITEMS -> "Items"
    WorkshopZoneId.RECIPES -> "Recettes"
    WorkshopZoneId.SOUNDS -> "Sons"
    WorkshopZoneId.EXPORT -> "Export"
}

private fun zoneIcon(z: WorkshopZoneId) = when (z) {
    WorkshopZoneId.HUB -> "branding/icons/icon_hub.png"
    WorkshopZoneId.MOBS -> "branding/icons/icon_mobs.png"
    WorkshopZoneId.PORTALS -> "branding/icons/icon_portals.png"
    WorkshopZoneId.MAPS -> "branding/icons/icon_map.png"
    WorkshopZoneId.BLOCKS -> "branding/icons/icon_blocks.png"
    WorkshopZoneId.ITEMS -> "branding/icons/icon_items.png"
    WorkshopZoneId.RECIPES -> "branding/icons/icon_items.png"
    WorkshopZoneId.SOUNDS -> "branding/icons/icon_export.png"
    WorkshopZoneId.EXPORT -> "branding/icons/icon_export.png"
}

/** Résultat d'un ajout de monstres : liste complète + compteurs réels. */
private data class MobMerge(val mobs: List<MobEntity>, val added: Int, val repaired: Int)

/**
 * Ajoute [incoming] à [all] en ne comparant les identifiants que dans le projet du monstre ajouté.
 * Répare aussi un monstre déjà présent dans le projet qui est hostile mais inerte (ni poursuite ni attaque,
 * ancien bug des presets AGW) quand le preset correspondant est, lui, actif. Rien d'autre n'est modifié.
 */
private fun mergeMobs(all: List<MobEntity>, incoming: List<MobEntity>): MobMerge {
    var result = all
    var added = 0
    var repaired = 0
    for (m in incoming) {
        val existing = result.firstOrNull { it.projectId == m.projectId && it.identifiant == m.identifiant }
        if (existing == null) {
            result = result + listOf(m)
            added++
        } else if (existing.hostile && !existing.poursuite && !existing.attaque && (m.poursuite || m.attaque)) {
            result = result.map {
                if (it.id == existing.id) it.copy(poursuite = m.poursuite, attaque = m.attaque) else it
            }
            repaired++
        }
    }
    return MobMerge(result, added, repaired)
}

private fun mobMergeMessage(r: MobMerge): String =
    if (r.added == 0 && r.repaired == 0) {
        "Presets monstres déjà présents dans ce projet"
    } else {
        "Presets monstres : ${r.added} ajouté(s)" + if (r.repaired > 0) ", ${r.repaired} réparé(s)" else ""
    }

/** Ajoute les éléments de [incoming] absents du projet (même projet + même clé), et renvoie combien ont été ajoutés. */
private fun <T> addMissing(
    all: List<T>,
    incoming: List<T>,
    projectOf: (T) -> String,
    keyOf: (T) -> String
): Pair<List<T>, Int> {
    var result = all
    var added = 0
    for (n in incoming) {
        if (result.none { projectOf(it) == projectOf(n) && keyOf(it) == keyOf(n) }) {
            result = result + listOf(n)
            added++
        }
    }
    return result to added
}

/* ───────────────────────── Zone Sons / نشيد ───────────────────────── */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SoundZone(
    projectId: String,
    projectName: String?,
    sounds: List<SbhSound>,
    hasProject: Boolean,
    soundRepo: SoundRepository,
    onRefresh: () -> Unit,
    onMessage: (String) -> Unit
) {
    var eventTarget by remember { mutableStateOf<SbhSound?>(null) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        if (!hasProject) {
            onMessage("Ouvrez un projet avant d'importer un son")
            return@rememberLauncherForActivityResult
        }
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "nasheed"
        val result = soundRepo.importFromUri(uri, name, projectId = projectId)
        onRefresh()
        if (result.sound != null) {
            val tag = if (result.sound.extension == "ogg") "Ogg OK" else result.sound.extension.uppercase()
            onMessage("Importé : ${result.sound.name} ($tag) — ${result.message}")
        } else {
            onMessage(result.message.ifBlank { "Échec de l'import" })
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionTitle("Sons / نشيد · ${projectName ?: "projet"}")
        Text(
            "Importez des nasheeds ou musiques pour ce projet. Cochez Pack pour les inclure dans l'export Minecraft.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        GoldPrimaryButton(
            text = "+ Importer un son",
            onClick = {
                if (!hasProject) onMessage("Ouvrez un projet")
                else importLauncher.launch(
                    arrayOf("audio/*", "audio/ogg", "audio/mpeg", "audio/mp4", "audio/wav", "application/ogg")
                )
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = hasProject
        )

        Text(
            "${sounds.size} son(s) · ${sounds.count { it.includeInPack }} dans le pack",
            color = AgwColors.SacredGold,
            fontWeight = FontWeight.SemiBold
        )

        if (sounds.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AgwColors.Panel),
                shape = AgwDecor.CardShape
            ) {
                Column(
                    Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Aucun son dans ce projet", color = AgwColors.PaleMarble, fontWeight = FontWeight.Medium)
                    Text(
                        "Formats : ogg (recommandé), mp3, m4a, wav.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else {
            sounds.forEach { sound ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AgwColors.Panel),
                    shape = AgwDecor.CardShape
                ) {
                    Column(
                        Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(sound.name, color = AgwColors.PaleMarble, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${sound.extension.uppercase()} · ${sound.definitionKey()}" +
                                if (sound.notes.isNotBlank()) " · ${sound.notes}" else "",
                            color = AgwColors.Sand,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = sound.includeInPack,
                                onClick = {
                                    soundRepo.update(sound.copy(includeInPack = !sound.includeInPack))
                                    onRefresh()
                                },
                                label = {
                                    Text(
                                        if (sound.includeInPack) "Pack OK" else "Pack",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AgwColors.GoldMuted,
                                    selectedLabelColor = AgwColors.GoldSoft,
                                    containerColor = AgwColors.NightStone,
                                    labelColor = AgwColors.Sand
                                )
                            )
                            TextButton(onClick = { eventTarget = sound }) {
                                Text("Événement", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelSmall)
                            }
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = {
                                soundRepo.delete(sound.id)
                                onRefresh()
                                onMessage("Supprimé : ${sound.name}")
                            }) {
                                Text("Supprimer", color = AgwColors.Error, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        SectionTitle("Événements Minecraft utiles")
        Text(
            "music.game · music.menu · music.game.creative · record.cat · ambient.cave · ou sbh.music.*",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.labelSmall
        )
    }

    val target = eventTarget
    if (target != null) {
        var selected by remember(target.id) {
            mutableStateOf(
                SoundEvents.PRESETS.find { it.id == target.soundEvent }?.id
                    ?: if (target.soundEvent.startsWith("sbh.")) "custom" else target.soundEvent
            )
        }
        AlertDialog(
            onDismissRequest = { eventTarget = null },
            containerColor = AgwColors.Panel,
            title = {
                Text("Événement pour ${target.name}", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SoundEvents.PRESETS.forEach { preset ->
                        val active = selected == preset.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = preset.id }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = active,
                                onClick = { selected = preset.id },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = AgwColors.SacredGold,
                                    unselectedColor = AgwColors.Sand
                                )
                            )
                            Column {
                                Text(preset.label, color = AgwColors.PaleMarble)
                                Text(preset.description, color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val finalEvent = if (selected == "custom") {
                        "sbh.music.${SbhSound.sanitize(target.fileName)}"
                    } else selected
                    val cat = when {
                        selected.startsWith("music") || selected.startsWith("record") || selected == "custom" -> "music"
                        selected.startsWith("ambient") -> "ambient"
                        else -> "music"
                    }
                    soundRepo.update(target.copy(soundEvent = finalEvent, category = cat))
                    onRefresh()
                    eventTarget = null
                    onMessage("Événement : $finalEvent")
                }) { Text("Valider", color = AgwColors.SacredGold) }
            },
            dismissButton = {
                TextButton(onClick = { eventTarget = null }) {
                    Text("Annuler", color = AgwColors.Sand)
                }
            }
        )
    }
}
