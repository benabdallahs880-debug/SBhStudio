package com.sbh.studio.data

import android.content.Context
import android.net.Uri
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream

/**
 * Bibliothèque audio de SBh Studio (nasheeds / musiques de jeu).
 * Métadonnées en JSON + fichiers bruts sous filesDir/sounds/.
 * Conversion automatique vers Ogg Vorbis quand possible (Minecraft Bedrock).
 */
class SoundRepository(private val context: Context) {

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    private fun metaFile() = File(context.filesDir, "sbh_sounds.json")
    private fun soundsDir() = File(context.filesDir, "sounds").also { it.mkdirs() }
    private fun tempDir() = File(context.cacheDir, "sound_import").also { it.mkdirs() }

    fun loadAll(): List<SbhSound> = try {
        val f = metaFile()
        if (!f.exists()) emptyList()
        else json.decodeFromString(f.readText())
    } catch (_: Exception) {
        emptyList()
    }

    fun saveAll(list: List<SbhSound>) {
        atomicWrite(metaFile(), json.encodeToString(list))
    }

    fun forProject(projectId: String): List<SbhSound> =
        loadAll().filter { it.projectId == null || it.projectId == projectId }

    fun loadForExport(projectId: String): List<SbhSound> =
        loadAll().filter { it.includeInPack && (it.projectId == null || it.projectId == projectId) }

    data class ImportResult(
        val sound: SbhSound?,
        val convertedToOgg: Boolean,
        val message: String
    )

    /**
     * Importe un fichier audio depuis un Uri (SAF).
     * Tente une conversion automatique vers .ogg (format recommandé Bedrock).
     */
    fun importFromUri(
        uri: Uri,
        displayName: String?,
        projectId: String? = null,
        soundEvent: String = "custom"
    ): ImportResult {
        return try {
            val nameGuess = displayName?.substringBeforeLast('.')?.ifBlank { null }
                ?: "نشيد_${System.currentTimeMillis() % 100000}"
            val extGuess = (displayName?.substringAfterLast('.', "") ?: "").lowercase().ifBlank {
                context.contentResolver.getType(uri)?.let { mime ->
                    when {
                        mime.contains("ogg") -> "ogg"
                        mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
                        mime.contains("mp4") || mime.contains("m4a") -> "m4a"
                        mime.contains("wav") -> "wav"
                        else -> "bin"
                    }
                } ?: "bin"
            }.take(5)

            val id = java.util.UUID.randomUUID().toString()
            val fileName = SbhSound.sanitize(nameGuess)

            // 1) Copie temporaire de la source
            val tempSrc = File(tempDir(), "src_$id.$extGuess")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempSrc).use { output -> input.copyTo(output) }
            } ?: return ImportResult(null, false, "Impossible de lire le fichier")

            if (!tempSrc.exists() || tempSrc.length() < 64) {
                tempSrc.delete()
                return ImportResult(null, false, "Fichier trop petit ou vide")
            }

            // 2) Conversion Ogg
            val conv = AudioOggConverter.convertToOgg(context, tempSrc, soundsDir(), id)
            val finalFile: File
            val finalExt: String
            val converted: Boolean
            val msg: String

            if (conv.success && conv.output != null) {
                finalFile = conv.output
                finalExt = "ogg"
                converted = !AudioOggConverter.isAlreadyOgg(tempSrc)
                msg = conv.message
                tempSrc.delete()
            } else {
                // Conservé tel quel
                finalExt = extGuess.ifBlank { "ogg" }
                finalFile = File(soundsDir(), "$id.$finalExt")
                tempSrc.copyTo(finalFile, overwrite = true)
                tempSrc.delete()
                converted = false
                msg = conv.message
            }

            val event = if (soundEvent == "custom" || soundEvent.isBlank()) {
                "sbh.music.$fileName"
            } else {
                soundEvent
            }

            val sound = SbhSound(
                id = id,
                name = nameGuess,
                fileName = fileName,
                extension = finalExt,
                storagePath = "sounds/${finalFile.name}",
                projectId = projectId,
                soundEvent = event,
                category = if (event.startsWith("music") || event.startsWith("record") || event.startsWith("sbh.music")) "music" else "ambient",
                includeInPack = true,
                notes = if (!converted && finalExt != "ogg") "Format $finalExt (conversion Ogg non disponible)" else ""
            )

            val all = loadAll().toMutableList()
            all.add(0, sound)
            saveAll(all)
            ImportResult(sound, converted || finalExt == "ogg", msg)
        } catch (e: Exception) {
            ImportResult(null, false, e.message ?: "Échec de l'import")
        }
    }

    /** Compatibilité avec l'ancien appelant qui attendait SbhSound? */
    fun importFromUriLegacy(
        uri: Uri,
        displayName: String?,
        projectId: String? = null,
        soundEvent: String = "custom"
    ): SbhSound? = importFromUri(uri, displayName, projectId, soundEvent).sound

    fun delete(id: String) {
        val all = loadAll()
        val target = all.find { it.id == id }
        if (target != null) {
            fileFor(target)?.delete()
            saveAll(all.filter { it.id != id })
        }
    }

    fun update(sound: SbhSound) {
        val all = loadAll().map { if (it.id == sound.id) sound else it }
        saveAll(all)
    }

    fun assignToProject(soundId: String, projectId: String?) {
        val all = loadAll().map {
            if (it.id == soundId) it.copy(projectId = projectId) else it
        }
        saveAll(all)
    }

    fun fileFor(sound: SbhSound): File? {
        if (sound.storagePath.isBlank()) return null
        val f = File(context.filesDir, sound.storagePath)
        return if (f.exists()) f else null
    }

    fun bytesFor(sound: SbhSound): ByteArray? = fileFor(sound)?.readBytes()

    fun buildSoundDefinitionsJson(sounds: List<SbhSound>): String {
        if (sounds.isEmpty()) return """{"format_version":"1.14.0","sound_definitions":{}}"""

        val grouped = sounds.groupBy { it.definitionKey() }

        val defs = grouped.entries.joinToString(",\n") { (key, list) ->
            val first = list.first()
            val paths = list.joinToString(",\n") { s ->
                """      { "name": "${s.packSoundPath()}", "volume": ${s.volume.coerceIn(0.05f, 1f)}, "stream": true }"""
            }
            """  "$key": {
    "category": "${first.category}",
    "min_distance": 0.0,
    "max_distance": 64.0,
    "sounds": [
$paths
    ]
  }"""
        }

        return """{
  "format_version": "1.14.0",
  "sound_definitions": {
$defs
  }
}"""
    }
}
