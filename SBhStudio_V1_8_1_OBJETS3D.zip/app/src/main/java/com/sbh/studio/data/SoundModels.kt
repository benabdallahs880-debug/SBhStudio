package com.sbh.studio.data

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * Événements sonores Minecraft Bedrock courants (remplacement de musique / sons).
 * L'utilisateur peut aussi saisir un identifiant personnalisé (ex. sbh.music.mon_nasheed).
 */
object SoundEvents {
    val PRESETS = listOf(
        SoundEventPreset("music.game", "Musique de jeu", "Remplace la musique d'exploration"),
        SoundEventPreset("music.game.creative", "Musique créative", "Remplace la musique du mode créatif"),
        SoundEventPreset("music.menu", "Musique du menu", "Remplace la musique du menu principal"),
        SoundEventPreset("music.game.end", "Musique de fin", "Remplace la musique de l'End"),
        SoundEventPreset("music.game.nether", "Musique du Nether", "Remplace la musique du Nether"),
        SoundEventPreset("record.cat", "Disque Cat", "Remplace le disque de musique Cat"),
        SoundEventPreset("record.blocks", "Disque Blocks", "Remplace le disque Blocks"),
        SoundEventPreset("ambient.cave", "Ambiance grotte", "Sons d'ambiance de grotte"),
        SoundEventPreset("custom", "Personnalisé (sbh.music…)", "Identifiant libre pour /playsound")
    )
}

@Serializable
data class SoundEventPreset(
    val id: String,
    val label: String,
    val description: String
)

/**
 * Un fichier audio (nasheed, musique, ambiance) importé dans SBh Studio.
 * Stocké localement ; peut être lié à un projet et exporté dans le Resource Pack.
 */
@Serializable
data class SbhSound(
    val id: String = UUID.randomUUID().toString(),
    /** Nom affiché (ex. « نشيد الفجر ») */
    val name: String,
    /** Nom de fichier technique (sans extension), pour le pack : sounds/sbh/<fileName>.ogg */
    val fileName: String,
    /** Extension d'origine : ogg, mp3, m4a, wav… */
    val extension: String = "ogg",
    /** Chemin relatif sous filesDir (ex. sounds/<id>.ogg) — géré par SoundRepository */
    val storagePath: String = "",
    /** Projet associé (null = bibliothèque globale) */
    val projectId: String? = null,
    /**
     * Événement Minecraft à remplacer / définir.
     * Ex. "music.game", "music.menu", ou "sbh.music.nasheed1"
     */
    val soundEvent: String = "sbh.music.custom",
    /** Catégorie Bedrock : music | ambient | record | ui | neutral… */
    val category: String = "music",
    /** Volume 0.0–1.0 dans le pack */
    val volume: Float = 1.0f,
    /** Inclus dans le prochain export du projet */
    val includeInPack: Boolean = true,
    val durationMs: Long = 0L,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    /** Identifiant de son dans sound_definitions (sans chemin). */
    fun definitionKey(): String {
        val ev = soundEvent.trim()
        return when {
            ev.isBlank() || ev == "custom" -> "sbh.music.${sanitize(fileName)}"
            ev.startsWith("sbh.") -> ev
            else -> ev // music.game, record.cat, etc.
        }
    }

    /** Chemin relatif dans le RP (sans extension, convention Bedrock). */
    fun packSoundPath(): String = "sounds/sbh/${sanitize(fileName)}"

    companion object {
        fun sanitize(s: String): String =
            s.lowercase()
                .replace(Regex("[^a-z0-9_\\-]+"), "_")
                .trim('_')
                .take(48)
                .ifBlank { "sound" }
    }
}
