# SBh Atelier 2.0 Core

Cette étape prépare la chaîne de création d’un jeu 3D mobile autonome, sans supprimer l’Atelier Minecraft.

Projet → Blueprint JSON → scènes/ressources → profil mobile → validation → build Android.

Préparé : schéma SBH 3D GAME, profils LIGHT/BALANCED/PERFORMANCE, contrôles tactiles, LOD, occlusion et monde prototype.

Étapes suivantes : éditeur de scènes 3D, import d’assets, génération de scènes Godot, aperçu jouable, validation mobile, export APK/AAB.
