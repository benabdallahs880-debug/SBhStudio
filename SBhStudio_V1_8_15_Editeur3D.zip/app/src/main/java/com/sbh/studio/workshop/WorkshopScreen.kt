package com.sbh.studio.workshop

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sbh.studio.data.BlockRepository
import com.sbh.studio.data.AgwDataRepository
import com.sbh.studio.data.AgwWorldCoreRepository
import com.sbh.studio.data.ItemRepository
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.generator.AdvancedPackEngine
import com.sbh.studio.foundation.SBhWorldFoundation
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AgwDecor
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.ModeIconChip
import com.sbh.studio.ui.ModeIconTile
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.SectionTitle
import com.sbh.studio.ui.GoldDivider
import com.sbh.studio.data.SoundRepository
import com.sbh.studio.character.CharacterRepository
import com.sbh.studio.data.SbhSound
import com.sbh.studio.data.SoundEvents
import com.sbh.studio.texture.TextureRepository
import com.sbh.studio.texture.TextureProject
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkshopScreen(
    project: SbhProject?,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onOpenMapEditor: () -> Unit = {}
) {
    val context = LocalContext.current
    val repo = remember { WorkshopRepository(context) }
    val characterRepo = remember { CharacterRepository(context) }
    val agwRepo = remember { AgwDataRepository(context) }
    val worldCoreRepo = remember { AgwWorldCoreRepository(context) }
    val mobRepo = remember { MobRepository(context) }
    val itemRepo = remember { ItemRepository(context) }
    val blockRepo = remember { BlockRepository(context) }
    val engine = remember { AdvancedPackEngine(context) }

    var zone by remember { mutableStateOf(WorkshopZoneId.HUB) }
    var selectedVisualId by remember { mutableStateOf<String?>(null) }
    var showEditor3D by remember { mutableStateOf(false) }
    var portals by remember { mutableStateOf(repo.loadPortals()) }
    var maps by remember { mutableStateOf(repo.loadMaps()) }
    var mobs by remember { mutableStateOf(mobRepo.loadAll()) }
    var items by remember { mutableStateOf(itemRepo.loadAll()) }
    var blocks by remember { mutableStateOf(blockRepo.loadAll()) }
    var recipes by remember { mutableStateOf(repo.loadRecipes()) }
    var entities by remember { mutableStateOf(repo.loadEntities()) }
    var characterProjects by remember { mutableStateOf(characterRepo.loadAll()) }
    val gameBuilderRepo = remember { GameBuilderRepository(context) }
    var gameBlueprints by remember { mutableStateOf(gameBuilderRepo.loadAll()) }
    val gameTemplates = remember { gameBuilderRepo.loadTemplates() }
    val texRepo = remember { TextureRepository(context) }
    var textures by remember { mutableStateOf(texRepo.loadAll()) }
    val soundRepo = remember { SoundRepository(context) }
    var sounds by remember { mutableStateOf(soundRepo.loadAll()) }
    var reportText by remember { mutableStateOf("") }
    var lastExport by remember { mutableStateOf<File?>(null) }
    var agwWorld by remember { mutableStateOf(worldCoreRepo.load()) }

    val projectId = project?.id ?: "global"
    LaunchedEffect(projectId, maps, portals) {
        agwWorld = worldCoreRepo.synchronize(agwRepo, maps, portals, projectId)
        worldCoreRepo.save(agwWorld)
    }
    LaunchedEffect(Unit) { textures = texRepo.loadAll() }
    fun projectMobs() = mobs.filter { it.projectId == projectId }
    fun projectItems() = items.filter { it.projectId == projectId }
    fun projectBlocks() = blocks.filter { it.projectId == projectId }
    fun projectPortals() = portals.filter { it.projectId == projectId }
    fun projectMaps() = maps.filter { it.projectId == projectId }
    fun projectRecipes() = recipes.filter { it.projectId == projectId }
    fun projectEntities() = entities.filter { it.projectId == projectId }
    fun projectCharacters() = characterProjects.filter { it.projectId == projectId }
    fun projectGameBlueprints() = gameBlueprints.filter { it.projectId == projectId }
    fun projectSounds() = sounds.filter { it.projectId == null || it.projectId == projectId }

    fun savePortals(v: List<PortalBlueprint>) { portals = v; repo.savePortals(v); agwWorld = worldCoreRepo.synchronize(agwRepo, maps, v, projectId).also(worldCoreRepo::save) }
    fun saveMaps(v: List<MapBlueprint>) { maps = v; repo.saveMaps(v); agwWorld = worldCoreRepo.synchronize(agwRepo, v, portals, projectId).also(worldCoreRepo::save) }
    fun saveMobs(v: List<MobEntity>) { mobs = v; mobRepo.saveAll(v) }
    fun saveItems(v: List<SbhItem>) { items = v; itemRepo.saveAll(v) }
    fun saveBlocks(v: List<SbhBlock>) { blocks = v; blockRepo.saveAll(v) }
    fun saveRecipes(v: List<RecipeBlueprint>) { recipes = v; repo.saveRecipes(v) }
    fun saveEntities(v: List<SceneEntity>) { entities = v; repo.saveEntities(v) }
    fun saveGameBlueprints(v: List<GameProjectBlueprint>) { gameBlueprints = v; gameBuilderRepo.saveAll(v) }

    fun applyTemplate(t: WorkshopTemplate) {
        if (project == null) {
            onMessage("Ouvrez un projet avant d'appliquer un template")
            return
        }
        val pid = projectId
        val suffix = System.currentTimeMillis() % 10000
        when (t.id) {
            "desert_gothic" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Désert Gothique · $suffix",
                    sizeX = 96, sizeZ = 96, height = 72, theme = "desert_gothic", terrain = "desert",
                    hasVillage = true, hasDungeon = true, hasOasis = false, hasMountains = true, hasRoads = true
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Portail du Désert", identifier = "agw:portal_desert",
                    width = 5, height = 6, frameBlock = "agw:night_bricks",
                    destinationHint = "Al-Zahra · Désert", linkedMapId = mapId, mapX = 48, mapY = 70, mapZ = 48
                )
                val newMobs = listOf(
                    MobEntity(projectId = pid, nom = "Gardien du Désert", identifiant = "agw:gardien_desert", vie = 30, degats = 6, hostile = true, poursuite = true, attaque = true),
                    MobEntity(projectId = pid, nom = "Scorpion Noir", identifiant = "agw:scorpion_noir", vie = 16, degats = 4, hostile = true, poursuite = true, attaque = true)
                )
                val newItems = listOf(
                    SbhItem(projectId = pid, name = "Lame du Sirocco", identifier = "agw:lame_sirocco")
                )
                saveMaps(maps + map)
                savePortals(portals + portal)
                saveMobs(mobs + newMobs)
                saveItems(items + newItems)
                onMessage("Template « ${t.name} » appliqué : 1 map, 1 portail, 2 mobs, 1 item")
            }
            "oasis" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Oasis Vivante · $suffix",
                    sizeX = 64, sizeZ = 64, height = 64, theme = "oasis", terrain = "desert",
                    hasVillage = true, hasDungeon = false, hasOasis = true, hasMountains = false, hasRoads = true
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Portail de l'Oasis", identifier = "agw:portal_oasis",
                    width = 4, height = 5, frameBlock = "minecraft:sandstone",
                    destinationHint = "Oasis · Point d'eau", linkedMapId = mapId, mapX = 32, mapY = 65, mapZ = 32
                )
                val newRecipes = listOf(
                    RecipeBlueprint(projectId = pid, name = "Eau pure", identifier = "agw:eau_pure",
                        type = "minecraft:recipe_shapeless", resultId = "agw:eau_pure", resultCount = 1,
                        ingredients = listOf("minecraft:glass_bottle", "minecraft:water_bucket"))
                )
                saveMaps(maps + map)
                savePortals(portals + portal)
                saveRecipes(recipes + newRecipes)
                onMessage("Template « ${t.name} » appliqué : 1 map, 1 portail, 1 recette")
            }
            "forteresse" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Forteresse Noire · $suffix",
                    sizeX = 80, sizeZ = 80, height = 96, theme = "fortress", terrain = "mountains",
                    hasVillage = false, hasDungeon = true, hasOasis = false, hasMountains = true, hasRoads = false
                )
                val newMobs = listOf(
                    MobEntity(projectId = pid, nom = "Sentinelle Noire", identifiant = "agw:sentinelle_noire", vie = 40, degats = 8, hostile = true, poursuite = true, attaque = true, profilIA = "guerrier"),
                    MobEntity(projectId = pid, nom = "Archer de la Tour", identifiant = "agw:archer_tour", vie = 22, degats = 5, hostile = true, poursuite = true, attaque = true, profilIA = "archer")
                )
                saveMaps(maps + map)
                saveMobs(mobs + newMobs)
                onMessage("Template « ${t.name} » appliqué : 1 map, 2 mobs hostiles")
            }
            "route_caravane" -> {
                val mapA = MapBlueprint(
                    id = java.util.UUID.randomUUID().toString(), projectId = pid, name = "Caravansérail · $suffix",
                    sizeX = 48, sizeZ = 48, height = 64, theme = "caravan", terrain = "desert",
                    hasVillage = true, hasDungeon = false, hasOasis = false, hasMountains = false, hasRoads = true, worldX = 0, worldZ = 0
                )
                val mapB = MapBlueprint(
                    id = java.util.UUID.randomUUID().toString(), projectId = pid, name = "Poste avancé · $suffix",
                    sizeX = 32, sizeZ = 32, height = 64, theme = "caravan", terrain = "desert",
                    hasVillage = false, hasDungeon = false, hasOasis = true, hasMountains = false, hasRoads = true, worldX = 200, worldZ = 0
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Relais Caravane", identifier = "agw:portal_caravane",
                    width = 3, height = 4, frameBlock = "minecraft:cut_sandstone",
                    destinationHint = "Poste avancé", linkedMapId = mapB.id, mapX = 16, mapY = 65, mapZ = 16,
                    destX = 200, destY = 65, destZ = 0
                )
                saveMaps(maps + mapA + mapB)
                savePortals(portals + portal)
                onMessage("Template « ${t.name} » appliqué : 2 maps liées + 1 portail")
            }
            else -> onMessage("Template inconnu")
        }
    }


    fun generateFoundation() {
        onMessage("Génération de la fondation en cours…")
        try {
            val result = SBhWorldFoundation.generateAndExport(context)
            lastExport = result.addonFile

            // Import automatique dans le projet Compose (mobs + items)
            val pid = project?.id ?: "global"
            val foundationMobs = listOf(
                MobEntity(projectId = pid, nom = "Yahya ibn Harith", identifiant = "agw:yahya", vie = 32, degats = 7, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Zaynab", identifiant = "agw:zaynab", vie = 20, degats = 0, hostile = false),
                MobEntity(projectId = pid, nom = "Chef de Hibou", identifiant = "agw:chef_hibou", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Chef de Ghurab", identifiant = "agw:chef_ghurab", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Le Roi", identifiant = "agw:roi", vie = 30, degats = 5, hostile = false),
                MobEntity(projectId = pid, nom = "Garde royal", identifiant = "agw:garde_royal", vie = 24, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Combattant Hibou", identifiant = "agw:soldat_hibou", vie = 22, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Combattant Ghurab", identifiant = "agw:soldat_ghurab", vie = 22, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Templier", identifiant = "agw:templier", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Marchand bédouin", identifiant = "agw:marchand_bedouin", vie = 18, degats = 0, hostile = false),
                MobEntity(projectId = pid, nom = "Vautour", identifiant = "agw:vautour", vie = 20, degats = 4, hostile = true, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Hashashin", identifiant = "agw:hashashin", vie = 26, degats = 7, hostile = true, poursuite = true, attaque = true)
            )
            val foundationItems = listOf(
                SbhItem(projectId = pid, name = "Sabre de Hibou", identifier = "agw:sabre_hibou", damage = 7, durability = 600),
                SbhItem(projectId = pid, name = "Sabre de Ghurab", identifier = "agw:sabre_ghurab", damage = 7, durability = 600),
                SbhItem(projectId = pid, name = "Sabre royal", identifier = "agw:sabre_royal", damage = 8, durability = 650),
                SbhItem(projectId = pid, name = "Sabre templier", identifier = "agw:sabre_templier", damage = 8, durability = 650),
                SbhItem(projectId = pid, name = "Fusil royal", identifier = "agw:fusil_royal", damage = 11, durability = 400),
                SbhItem(projectId = pid, name = "Fusil de Hibou", identifier = "agw:fusil_hibou", damage = 10, durability = 380),
                SbhItem(projectId = pid, name = "Pistolet templier", identifier = "agw:pistolet_templier", damage = 8, durability = 300),
                SbhItem(projectId = pid, name = "Pistolet royal", identifier = "agw:pistolet_royal", damage = 8, durability = 300),
                SbhItem(projectId = pid, name = "Mitrailleuse lourde", identifier = "agw:mitrailleuse_lourde", damage = 14, durability = 800),
                SbhItem(projectId = pid, name = "NRJ noire", identifier = "agw:nrj_noire", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Minerai brut", identifier = "agw:minerai_brut", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Plan mécanique", identifier = "agw:plan_mecanique", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Composant rare", identifier = "agw:composant_rare", damage = 0, durability = 1)
            )
            // Les doublons ne se comparent que dans CE projet : avant, distinctBy portait sur tous les
            // projets et un 2e projet ne recevait rien alors que le message annonçait l'import.
            val mobMerge = mergeMobs(mobs, foundationMobs)
            saveMobs(mobMerge.mobs)
            val (itemList, itemsAdded) = addMissing(items, foundationItems, { it.projectId }, { it.identifier })
            saveItems(itemList)
            val alreadyThere = (foundationMobs.size - mobMerge.added) + (foundationItems.size - itemsAdded)
            val importNote = if (alreadyThere > 0) " ($alreadyThere déjà présents)" else ""

            // Régions → Map Studio (fichier partagé)
            try {
                val regionsSrc = java.io.File(result.project.mapDir, "regions.json")
                if (regionsSrc.exists()) {
                    val dest = java.io.File(context.filesDir, "map_studio_regions.json")
                    regionsSrc.copyTo(dest, overwrite = true)
                }
            } catch (_: Exception) {}

            reportText = result.message + "\n\n✅ Importé dans le projet : ${mobMerge.added} mobs, $itemsAdded items$importNote\n📍 Régions prêtes pour Map Studio"
            onMessage("Fondation + import projet OK")
            zone = WorkshopZoneId.EXPORT
        } catch (e: Exception) {
            onMessage("Erreur fondation : ${e.message}")
            reportText = "❌ ${e.message}"
        }
    }

    fun importAgwPresets() {
        if (project == null) {
            onMessage("Ouvrez un projet d'abord")
            return
        }
        val pid = project.id
        val newMobs = engine.presetMobs(pid)
        val newItems = listOf(
            SbhItem(projectId = pid, name = "Cimeterre de fer", identifier = "agw:iron_scimitar", damage = 7, durability = 250),
            SbhItem(projectId = pid, name = "Lanterne suspendue", identifier = "agw:hanging_lantern", damage = 0, durability = 100)
        )
        val newBlocks = listOf(
            SbhBlock(projectId = pid, name = "Grès sombre", identifier = "agw:dark_sandstone", hardness = 1.5),
            SbhBlock(projectId = pid, name = "Pierre arabesque", identifier = "agw:arabesque_stone", hardness = 2.0),
            SbhBlock(projectId = pid, name = "Briques de nuit", identifier = "agw:night_bricks", hardness = 1.8),
            SbhBlock(projectId = pid, name = "Mosaïque sacrée", identifier = "agw:sacred_mosaic", hardness = 1.2)
        )
        val mobMerge = mergeMobs(mobs, newMobs)
        saveMobs(mobMerge.mobs)
        val (itemList, itemsAdded) = addMissing(items, newItems, { it.projectId }, { it.identifier })
        saveItems(itemList)
        val (blockList, blocksAdded) = addMissing(blocks, newBlocks, { it.projectId }, { it.identifier })
        saveBlocks(blockList)
        val portal = PortalBlueprint(projectId = pid, name = "Portail Al-Zahra", identifier = "agw:portal_al_zahra", destinationHint = "الزهراء")
        val map = MapBlueprint(projectId = pid, name = "Cité Al-Zahra", sizeX = 48, sizeZ = 48, hasVillage = true, hasDungeon = true, hasOasis = true)
        val (portalList, portalsAdded) = addMissing(portals, listOf(portal), { it.projectId }, { it.identifier })
        savePortals(portalList)
        val (mapList, mapsAdded) = addMissing(maps, listOf(map), { it.projectId }, { it.name })
        saveMaps(mapList)
        onMessage("Monde AGW importé dans le projet")
        val repairedNote = if (mobMerge.repaired > 0) " (+${mobMerge.repaired} réparés)" else ""
        reportText = "✅ Import AGW : ${mobMerge.added} mobs$repairedNote, $itemsAdded items, $blocksAdded blocs, $portalsAdded portail, $mapsAdded map"
        zone = WorkshopZoneId.EXPORT
    }

    fun runValidate() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet (Accueil → projet) puis revenez à l'atelier."
            return
        }
        val r = engine.validateAll(
            project,
            projectMobs(), projectItems(), projectBlocks(),
            projectPortals(), projectMaps(),
            projectRecipes(), projectEntities(), projectSounds()
        )
        reportText = buildString {
            append(if (r.ok) "✅ Validation OK\n" else "❌ Erreurs bloquantes\n")
            append("Contenu : ${projectMobs().size}m · ${projectItems().size}i · ${projectBlocks().size}b · ${projectPortals().size}p · ${projectMaps().size}maps · ${projectRecipes().size}r · ${projectEntities().size}e · ${projectSounds().size}s\n")
            append("Résultat : ${r.errors.size} erreur(s) · ${r.warnings.size} avertissement(s)\n")
            if (r.errors.isNotEmpty()) {
                append("\n── Erreurs ──\n")
                r.errors.forEach { append("· $it\n") }
            }
            if (r.warnings.isNotEmpty()) {
                append("\n── Avertissements ──\n")
                r.warnings.forEach { append("⚠ $it\n") }
            }
            if (r.ok && r.errors.isEmpty() && r.warnings.isEmpty()) {
                append("\nAucune anomalie détectée. Prêt pour l'export.\n")
            }
        }
    }

    fun runExport() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet d'abord."
            return
        }
        val r = engine.exportAdvanced(
            project,
            projectMobs(), projectItems(), projectBlocks(),
            projectPortals(), projectMaps(),
            projectRecipes(), projectEntities(), projectSounds()
        )
        lastExport = r.file
        reportText = buildString {
            append(if (r.ok) "✅ Export réussi\n" else "❌ Échec export\n")
            append("Fichier : ${r.file?.name ?: "—"}\n")
            append("Contenu : ${projectMobs().size}m · ${projectItems().size}i · ${projectBlocks().size}b · ${projectPortals().size}p · ${projectMaps().size}maps · ${projectRecipes().size}r · ${projectEntities().size}e · ${projectSounds().size}s\n")
            append("Résultat : ${r.errors.size} erreur(s) · ${r.warnings.size} avertissement(s)\n")
            if (r.errors.isNotEmpty()) {
                append("\n── Erreurs ──\n")
                r.errors.forEach { append("· $it\n") }
            }
            if (r.warnings.isNotEmpty()) {
                append("\n── Avertissements ──\n")
                r.warnings.forEach { append("⚠ $it\n") }
            }
        }
        if (r.ok && r.file != null) {
            onMessage("Pack généré : ${r.file.name}")
            try {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", r.file)
                // Même correctif que l'export du détail projet : Minecraft n'apparaît
                // jamais dans un partage générique (ACTION_SEND), seulement lors d'une
                // ouverture directe du fichier (ACTION_VIEW). Ce chemin d'export-ci avait
                // été oublié lors du premier correctif — désormais aligné.
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/mcaddon")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runCatching { context.startActivity(viewIntent) }.onFailure {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Partager le pack"))
                }
            } catch (_: Exception) { }
        }
    }

    if (showEditor3D) {
        Editor3DScreen(projectId = projectId, onClose = { showEditor3D = false })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Atelier · الورشة", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text(project?.name ?: "Aucun projet ouvert", style = MaterialTheme.typography.labelSmall, color = AgwColors.Sand)
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(WorkshopZoneId.entries.toList()) { z ->
                    ModeIconChip(
                        label = zoneLabel(z),
                        iconAsset = zoneIcon(z),
                        selected = zone == z,
                        onClick = {
                            zone = z
                            selectedVisualId = null
                        }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            VisualWorkshopPreview(
                zone = zone,
                items = projectItems(),
                blocks = projectBlocks(),
                mobs = projectMobs(),
                entities = projectEntities(),
                characters = projectCharacters(),
                maps = projectMaps(),
                recipes = projectRecipes(),
                portals = projectPortals(),
                sounds = projectSounds(),
                games = projectGameBlueprints(),
                selectedId = selectedVisualId,
                onSelect = { selectedVisualId = it }
            )
            Spacer(Modifier.height(10.dp))

            when (zone) {
                WorkshopZoneId.HUB -> {
                    val hubValidation = computeHubValidation(
                        portals = projectPortals(),
                        maps = projectMaps(),
                        mobs = projectMobs(),
                        items = projectItems(),
                        blocks = projectBlocks(),
                        recipes = projectRecipes(),
                        entities = projectEntities(),
                        sounds = projectSounds()
                    )
                    HubZone(
                        onSelect = { zone = it },
                        mobCount = projectMobs().size,
                        portalCount = projectPortals().size,
                        mapCount = projectMaps().size,
                        itemCount = projectItems().size,
                        blockCount = projectBlocks().size,
                        recipeCount = projectRecipes().size,
                        soundCount = projectSounds().size,
                        entityCount = projectEntities().size,
                        gameBuilderCount = projectGameBlueprints().size,
                        maps = projectMaps(),
                        portals = projectPortals(),
                        mobs = projectMobs(),
                        items = projectItems(),
                        blocks = projectBlocks(),
                        recipes = projectRecipes(),
                        textures = textures,
                        onImportAgw = { importAgwPresets() },
                        onGenerateFoundation = { generateFoundation() },
                        onApplyTemplate = { t -> applyTemplate(t) },
                        agwWorldName = agwWorld.worldName,
                        agwFactionCount = agwWorld.nodes.count { it.type == "faction" },
                        agwNodeCount = agwWorld.nodes.size,
                        validation = hubValidation,
                        onOpenExport = { zone = WorkshopZoneId.EXPORT },
                        onComingSoon = { label -> onMessage("$label : pas encore disponible, en préparation.") }
                    )
                }
                WorkshopZoneId.MOBS -> MobZone(
                    projectId = projectId,
                    mobs = projectMobs(),
                    hasProject = project != null,
                    textures = textures,
                    onAddPresets = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val r = mergeMobs(mobs, engine.presetMobs(projectId))
                            saveMobs(r.mobs)
                            onMessage(mobMergeMessage(r))
                        }
                    },
                    onSave = { m ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@MobZone }
                        saveMobs(mobs.filter { it.id != m.id } + m)
                    },
                    onDelete = { m -> saveMobs(mobs - m) }
                )
                WorkshopZoneId.PORTALS -> PortalZone(
                    projectId = projectId,
                    portals = projectPortals(),
                    maps = projectMaps(),
                    textures = textures,
                    onSave = { p ->
                        savePortals(portals.filter { it.id != p.id } + p)
                    },
                    onDelete = { p -> savePortals(portals - p) }
                )
                WorkshopZoneId.MAPS -> MapZone(
                    projectId = projectId,
                    maps = projectMaps(),
                    portals = projectPortals(),
                    mobs = projectMobs(),
                    items = projectItems(),
                    blocks = projectBlocks(),
                    textures = textures,
                    onSave = { m -> saveMaps(maps.filter { it.id != m.id } + m) },
                    onLinkPortal = { portal, mapId ->
                        savePortals(portals.filter { it.id != portal.id } + portal.copy(linkedMapId = mapId))
                    },
                    onDelete = { m ->
                        saveMaps(maps - m)
                        savePortals(portals.map { if (it.linkedMapId == m.id) it.copy(linkedMapId = null) else it })
                    }
                )
                WorkshopZoneId.BLOCKS -> BlockZone(
                    projectId = projectId,
                    blocks = projectBlocks(),
                    textures = textures,
                    onAdd = { block -> saveBlocks(blocks + block) },
                    onDelete = { b -> saveBlocks(blocks - b) }
                )
                WorkshopZoneId.ITEMS -> ItemZone(
                    projectId = projectId,
                    items = projectItems(),
                    textures = textures,
                    onAdd = { item -> saveItems(items + item) },
                    onDelete = { i -> saveItems(items - i) }
                )
                WorkshopZoneId.RECIPES -> RecipeZone(
                    projectId = projectId,
                    recipes = projectRecipes(),
                    items = projectItems(),
                    onSave = { r ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@RecipeZone }
                        saveRecipes(recipes.filter { it.id != r.id } + r)
                    },
                    onDelete = { r -> saveRecipes(recipes - r) }
                )
                WorkshopZoneId.SOUNDS -> SoundZone(
                    projectId = projectId,
                    projectName = project?.name,
                    sounds = projectSounds(),
                    hasProject = project != null,
                    soundRepo = soundRepo,
                    onRefresh = { sounds = soundRepo.loadAll() },
                    onMessage = onMessage
                )
                WorkshopZoneId.ENTITIES -> Column {
                    GoldPrimaryButton(
                        text = "Ouvrir l'Éditeur 3D plein écran",
                        onClick = {
                            if (project == null) onMessage("Ouvrez un projet") else showEditor3D = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    EntityZone(
                    projectId = projectId,
                    entities = projectEntities(),
                    maps = projectMaps(),
                    hasProject = project != null,
                    onSave = { e ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@EntityZone }
                        saveEntities(entities.filter { it.id != e.id } + e)
                    },
                    onDelete = { e -> saveEntities(entities - e) },
                    onMessage = onMessage
                )
                }
                WorkshopZoneId.CHARACTER_STUDIO -> CharacterStudioZone(
                    projectId = projectId,
                    hasProject = project != null,
                    projects = projectCharacters(),
                    onSave = { character ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@CharacterStudioZone }
                        characterProjects = characterProjects.filter { it.id != character.id } + character
                        characterRepo.saveAll(characterProjects)
                    },
                    onDelete = { character ->
                        characterProjects = characterProjects.filter { it.id != character.id }
                        characterRepo.saveAll(characterProjects)
                    },
                    onMessage = onMessage,
                    onSendToMapStudio = { filePath, displayName ->
                        com.sbh.studio.mapeditor.PendingMapImport.offer(filePath, displayName)
                        onOpenMapEditor()
                    }
                )
                WorkshopZoneId.GAME_BUILDER -> GameBuilderZone(
                    projectId = projectId,
                    hasProject = project != null,
                    blueprints = projectGameBlueprints(),
                    templates = gameTemplates,
                    onSave = { b ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@GameBuilderZone }
                        val withProfile = b.copy(profileJson = gameBuilderRepo.profileJsonFor(b.performance))
                        saveGameBlueprints(gameBlueprints.filter { it.id != withProfile.id } + withProfile)
                    },
                    onDelete = { b -> saveGameBlueprints(gameBlueprints - b) },
                    onApplyTemplate = { assetName ->
                        val created = gameBuilderRepo.blueprintFromWorldTemplate(projectId, assetName)
                        if (created == null) onMessage("Template illisible : $assetName")
                        else {
                            val withProfile = created.copy(profileJson = gameBuilderRepo.profileJsonFor(created.performance))
                            saveGameBlueprints(gameBlueprints + withProfile)
                            onMessage("Template appliqué : ${withProfile.name}")
                        }
                    },
                    onMessage = onMessage
                )
                WorkshopZoneId.EXPORT -> ExportZone(
                    reportText = reportText,
                    hasProject = project != null,
                    counts = "${projectMobs().size}m ${projectItems().size}i ${projectBlocks().size}b ${projectPortals().size}p ${projectMaps().size}maps ${projectRecipes().size}r ${projectSounds().size}s ${projectEntities().size}e ${projectCharacters().size}ch ${projectGameBlueprints().size}gb",
                    onValidate = { runValidate() },
                    onExport = { runExport() },
                    onImportAgw = { importAgwPresets() }
                )
            }
        }
    }
}
