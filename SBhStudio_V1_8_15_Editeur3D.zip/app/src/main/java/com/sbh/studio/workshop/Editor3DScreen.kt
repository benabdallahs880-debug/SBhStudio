package com.sbh.studio.workshop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.sbh.studio.ui.AgwColors
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Éditeur 3D plein écran : la scène EST l'écran, les commandes flottent par-dessus.
 * Rendu 3D léger calculé dans Compose (perspective, grille, ombres, éclairage, contour de
 * sélection, flèches d'axes) : aucun service externe, fonctionne sur tout téléphone.
 * Gestes : 1 doigt = orbite de la caméra, 2 doigts = zoom, toucher = sélectionner,
 * glisser une flèche = déplacer / mettre à l'échelle selon l'outil.
 */
internal enum class EditorTool { MOVE, ROTATE, SCALE }

private enum class GMode { CAMERA, AXIS, BODY, ROTATE }

private val PALETTE = listOf(-1f, 45f, 0f, 120f, 210f, 280f)
private val AXIS_COLORS = listOf(Color(0xFFE23B3B), Color(0xFF2ECC2E), Color(0xFF3D5BFF))
private val ORANGE = Color(0xFFFF9A2E)

@Composable
internal fun Editor3DScreen(projectId: String, onClose: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { Editor3DRepository(context) }

    var objects by remember {
        mutableStateOf(
            repo.load(projectId) ?: listOf(
                EditorObject(name = "Cube 1", kind = EditorKind.CUBE.name),
                EditorObject(name = "Cylindre 1", kind = EditorKind.CYLINDER.name, x = 2.2f, z = 0.8f)
            )
        )
    }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var tool by remember { mutableStateOf(EditorTool.MOVE) }
    var yaw by remember { mutableStateOf(0.7f) }
    var pitch by remember { mutableStateOf(0.55f) }
    var dist by remember { mutableStateOf(9f) }
    var activeAxis by remember { mutableStateOf(-1) }
    var showList by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var canvasW by remember { mutableStateOf(1080f) }
    var canvasH by remember { mutableStateOf(1900f) }
    val undo = remember { mutableStateListOf<List<EditorObject>>() }
    val redo = remember { mutableStateListOf<List<EditorObject>>() }

    val latest by rememberUpdatedState(objects)
    LaunchedEffect(objects) {
        delay(400)
        repo.save(projectId, objects)
    }
    DisposableEffect(Unit) { onDispose { repo.save(projectId, latest) } }

    fun cam() = Cam(yaw, pitch, dist, canvasW, canvasH)
    fun pushUndo() {
        undo.add(objects)
        if (undo.size > 60) undo.removeAt(0)
        redo.clear()
    }
    fun update(id: String?, f: (EditorObject) -> EditorObject) {
        objects = objects.map { if (it.id == id) f(it) else it }
    }
    fun add(kind: EditorKind) {
        pushUndo()
        val n = objects.count { it.kind == kind.name } + 1
        val i = objects.size
        val o = EditorObject(
            name = "${kind.label} $n", kind = kind.name,
            x = ((i % 4) - 1.5f) * 1.6f, z = (i / 4) * 1.6f
        )
        objects = objects + o
        selectedId = o.id
    }

    val selected = objects.firstOrNull { it.id == selectedId }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color(0xFF0A101B))) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasW = it.width.toFloat(); canvasH = it.height.toFloat() }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val cam0 = cam()
                            val sel0 = objects.firstOrNull { it.id == selectedId }
                            var mode = GMode.CAMERA
                            var axis = -1
                            if (sel0 != null) {
                                if (tool == EditorTool.ROTATE) {
                                    if (bodyHit(cam0, sel0, down.position, 1.7f)) mode = GMode.ROTATE
                                } else {
                                    val a = hitAxis(cam0, sel0, down.position)
                                    if (a >= 0) {
                                        mode = GMode.AXIS
                                        axis = a
                                    } else if (tool == EditorTool.MOVE && bodyHit(cam0, sel0, down.position, 1f)) {
                                        mode = GMode.BODY
                                    }
                                }
                            }
                            activeAxis = axis
                            var total = 0f
                            var pushed = false
                            while (true) {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.isEmpty()) break
                                if (pressed.size >= 2) {
                                    val a = pressed[0]
                                    val b = pressed[1]
                                    val prev = (a.previousPosition - b.previousPosition).getDistance()
                                    val cur = (a.position - b.position).getDistance()
                                    if (prev > 1f && cur > 1f) dist = (dist * prev / cur).coerceIn(2.5f, 40f)
                                    total += 100f
                                    pressed.forEach { it.consume() }
                                    continue
                                }
                                val c = pressed[0]
                                val d = c.position - c.previousPosition
                                total += d.getDistance()
                                if (d == Offset.Zero) continue
                                val cam = cam()
                                val o = objects.firstOrNull { it.id == selectedId }
                                if (mode != GMode.CAMERA && !pushed && total > 6f) {
                                    pushUndo()
                                    pushed = true
                                }
                                when (mode) {
                                    GMode.CAMERA -> {
                                        yaw -= d.x * 0.008f
                                        pitch = (pitch + d.y * 0.006f).coerceIn(0.05f, 1.45f)
                                    }
                                    GMode.ROTATE -> if (o != null) {
                                        update(o.id) { it.copy(rotY = (it.rotY + d.x * 0.6f) % 360f) }
                                    }
                                    GMode.AXIS -> if (o != null) {
                                        val len3 = gizmoLen(o)
                                        val c0 = cam.toCam(centerOf(o))
                                        val axes = AXES
                                        val c1 = cam.toCam(centerOf(o) + axes[axis] * len3)
                                        if (c0.z > 0.1f && c1.z > 0.1f) {
                                            val v = cam.proj(c1) - cam.proj(c0)
                                            val len = v.getDistance()
                                            if (len > 6f) {
                                                val amount = (d.x * v.x + d.y * v.y) / len
                                                val units = amount * len3 / len
                                                if (tool == EditorTool.SCALE) {
                                                    update(o.id) { it.copy(scale = (it.scale + units * 0.6f).coerceIn(0.2f, 6f)) }
                                                } else {
                                                    update(o.id) {
                                                        when (axis) {
                                                            0 -> it.copy(x = it.x + units)
                                                            1 -> it.copy(y = max(0f, it.y + units))
                                                            else -> it.copy(z = it.z + units)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    GMode.BODY -> if (o != null) {
                                        val y0 = centerOf(o).y
                                        val pa = planeHit(cam, c.previousPosition, y0)
                                        val pb = planeHit(cam, c.position, y0)
                                        if (pa != null && pb != null) {
                                            update(o.id) { it.copy(x = it.x + (pb.x - pa.x), z = it.z + (pb.z - pa.z)) }
                                        }
                                    }
                                }
                                c.consume()
                            }
                            activeAxis = -1
                            if (mode == GMode.CAMERA && total < 14f) {
                                selectedId = pickAt(cam(), objects, down.position)?.id
                            }
                        }
                    }
            ) {
                val cam = Cam(yaw, pitch, dist, size.width, size.height)
                drawWorld(cam)
                drawObjects(cam, objects, selectedId)
                val sel = objects.firstOrNull { it.id == selectedId }
                if (sel != null) drawGizmo(cam, sel, tool, activeAxis)
            }

            // ── Commandes flottantes ──
            Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
                Row(
                    Modifier.fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        FloatBtn("←", true) { onClose() }
                        if (selected != null) PosReadout(selected)
                    }
                    Spacer(Modifier.weight(1f))
                    Box(
                        Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xCC1B1F26))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            selected?.name ?: "Éditeur 3D",
                            color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.End) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FloatBtn("↶", undo.isNotEmpty()) {
                                val prev = undo.removeAt(undo.size - 1)
                                redo.add(objects)
                                objects = prev
                            }
                            FloatBtn("↷", redo.isNotEmpty()) {
                                val next = redo.removeAt(redo.size - 1)
                                undo.add(objects)
                                objects = next
                            }
                            FloatBtn("≡", true) { showList = !showList }
                        }
                        if (showList) {
                            Column(
                                Modifier.width(180.dp).heightIn(max = 260.dp)
                                    .clip(RoundedCornerShape(12.dp)).background(Color(0xE61B1F26))
                                    .verticalScroll(rememberScrollState()).padding(6.dp)
                            ) {
                                Text("Scène · ${objects.size}", color = AgwColors.SilverMuted, fontSize = 11.sp, modifier = Modifier.padding(6.dp))
                                objects.forEach { o ->
                                    Text(
                                        o.name,
                                        color = if (o.id == selectedId) AgwColors.SacredGold else Color.White,
                                        fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                                            .clickable { selectedId = o.id }.padding(8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                if (selected == null) {
                    Text(
                        "Glisse : tourner · Pince : zoom · Touche un objet pour le sélectionner",
                        color = Color(0xCCFFFFFF), fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp)
                    )
                }
                Row(
                    Modifier.fillMaxWidth().background(Color(0xF017191E)).horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Box {
                        ToolBtn("＋", "Ajouter", false, true) { menuOpen = true }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            EditorKind.values().forEach { k ->
                                DropdownMenuItem(text = { Text(k.label) }, onClick = { add(k); menuOpen = false })
                            }
                        }
                    }
                    ToolBtn("✥", "Déplacer", tool == EditorTool.MOVE, true) { tool = EditorTool.MOVE }
                    ToolBtn("⟳", "Tourner", tool == EditorTool.ROTATE, true) { tool = EditorTool.ROTATE }
                    ToolBtn("⤢", "Échelle", tool == EditorTool.SCALE, true) { tool = EditorTool.SCALE }
                    ToolBtn("◐", "Couleur", false, selected != null) {
                        val s = selected ?: return@ToolBtn
                        pushUndo()
                        val idx = PALETTE.indexOfFirst { it == s.hue }
                        update(s.id) { it.copy(hue = PALETTE[(idx + 1) % PALETTE.size]) }
                    }
                    ToolBtn("⧉", "Dupliquer", false, selected != null) {
                        val s = selected ?: return@ToolBtn
                        pushUndo()
                        val c = s.copy(id = UUID.randomUUID().toString(), name = s.name + " copie", x = s.x + 1.2f)
                        objects = objects + c
                        selectedId = c.id
                    }
                    ToolBtn("🗑", "Supprimer", false, selected != null) {
                        val s = selected ?: return@ToolBtn
                        pushUndo()
                        objects = objects.filter { it.id != s.id }
                        selectedId = null
                    }
                }
            }
        }
    }
}

// ───────────────────────── Petits composables ─────────────────────────

@Composable
private fun FloatBtn(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xCC1B1F26))
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (enabled) Color.White else Color(0x55FFFFFF), fontSize = 22.sp)
    }
}

@Composable
private fun ToolBtn(icon: String, label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val col = when {
        !enabled -> Color(0x44FFFFFF)
        selected -> AgwColors.SacredGold
        else -> Color.White
    }
    Column(
        Modifier.width(72.dp).clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(0x33D6B45A) else Color.Transparent)
            .clickable(enabled = enabled) { onClick() }.padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, color = col, fontSize = 22.sp)
        Text(label, color = col, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun PosReadout(o: EditorObject) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xCC1B1F26)).padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text("Pos. (cm)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("X  ${(o.x * 100).roundToInt()}", color = AXIS_COLORS[0], fontSize = 13.sp)
        Text("Y  ${(o.y * 100).roundToInt()}", color = AXIS_COLORS[1], fontSize = 13.sp)
        Text("Z  ${(o.z * 100).roundToInt()}", color = AXIS_COLORS[2], fontSize = 13.sp)
    }
}

// ───────────────────────── Maths 3D ─────────────────────────

private val AXES = listOf(V3(1f, 0f, 0f), V3(0f, 1f, 0f), V3(0f, 0f, 1f))
private val LIGHT = V3(-0.4f, 0.9f, 0.5f).norm()
private const val NEAR = 0.1f

private data class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3) = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3) = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(k: Float) = V3(x * k, y * k, z * k)
    fun dot(o: V3) = x * o.x + y * o.y + z * o.z
    fun cross(o: V3) = V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun norm(): V3 {
        val l = sqrt(x * x + y * y + z * z)
        return if (l < 1e-6f) this else V3(x / l, y / l, z / l)
    }
}

/** Caméra orbitale autour de (0, 0.5, 0). */
private class Cam(yaw: Float, pitch: Float, dist: Float, val w: Float, val h: Float) {
    val target = V3(0f, 0.5f, 0f)
    val pos: V3 = target + V3(cos(pitch) * sin(yaw), sin(pitch), cos(pitch) * cos(yaw)) * dist
    val f: V3 = (target - pos).norm()
    val r: V3 = f.cross(V3(0f, 1f, 0f)).norm()
    val u: V3 = r.cross(f)
    val focal: Float = w * 1.15f
    val cy: Float = h * 0.45f
    fun toCam(p: V3): V3 {
        val d = p - pos
        return V3(d.dot(r), d.dot(u), d.dot(f))
    }
    fun proj(c: V3) = Offset(w / 2f + c.x / c.z * focal, cy - c.y / c.z * focal)
    fun ray(p: Offset): V3 {
        val dx = (p.x - w / 2f) / focal
        val dy = -(p.y - cy) / focal
        return (r * dx + u * dy + f).norm()
    }
}

private class Face(val v: List<V3>, val n: V3)

private val cubeMesh: List<Face> = run {
    val h = 0.5f
    listOf(
        Face(listOf(V3(-h, -h, h), V3(h, -h, h), V3(h, h, h), V3(-h, h, h)), V3(0f, 0f, 1f)),
        Face(listOf(V3(h, -h, -h), V3(-h, -h, -h), V3(-h, h, -h), V3(h, h, -h)), V3(0f, 0f, -1f)),
        Face(listOf(V3(h, -h, h), V3(h, -h, -h), V3(h, h, -h), V3(h, h, h)), V3(1f, 0f, 0f)),
        Face(listOf(V3(-h, -h, -h), V3(-h, -h, h), V3(-h, h, h), V3(-h, h, -h)), V3(-1f, 0f, 0f)),
        Face(listOf(V3(-h, h, h), V3(h, h, h), V3(h, h, -h), V3(-h, h, -h)), V3(0f, 1f, 0f)),
        Face(listOf(V3(-h, -h, -h), V3(h, -h, -h), V3(h, -h, h), V3(-h, -h, h)), V3(0f, -1f, 0f))
    )
}

private val cylinderMesh: List<Face> = run {
    val n = 20
    val out = ArrayList<Face>()
    val top = ArrayList<V3>()
    val bottom = ArrayList<V3>()
    for (i in 0 until n) {
        val a0 = (2.0 * PI * i / n).toFloat()
        val a1 = (2.0 * PI * (i + 1) / n).toFloat()
        val am = (a0 + a1) / 2f
        val b0 = V3(cos(a0) * 0.5f, -0.5f, sin(a0) * 0.5f)
        val b1 = V3(cos(a1) * 0.5f, -0.5f, sin(a1) * 0.5f)
        val t0 = V3(b0.x, 0.5f, b0.z)
        val t1 = V3(b1.x, 0.5f, b1.z)
        out.add(Face(listOf(b0, b1, t1, t0), V3(cos(am), 0f, sin(am))))
        top.add(t0)
        bottom.add(b0)
    }
    out.add(Face(top, V3(0f, 1f, 0f)))
    out.add(Face(bottom, V3(0f, -1f, 0f)))
    out
}

private val sphereMesh: List<Face> = run {
    val la = 10
    val lo = 16
    fun pt(i: Int, j: Int): V3 {
        val th = (PI * i / la).toFloat()
        val ph = (2.0 * PI * j / lo).toFloat()
        return V3(0.5f * sin(th) * cos(ph), 0.5f * cos(th), 0.5f * sin(th) * sin(ph))
    }
    val out = ArrayList<Face>()
    for (i in 0 until la) {
        for (j in 0 until lo) {
            val a = pt(i, j)
            val b = pt(i, j + 1)
            val c = pt(i + 1, j + 1)
            val d = pt(i + 1, j)
            out.add(Face(listOf(a, b, c, d), ((a + b + c + d) * 0.25f).norm()))
        }
    }
    out
}

private fun meshOf(kind: String): List<Face> = when (kind) {
    EditorKind.SPHERE.name -> sphereMesh
    EditorKind.CYLINDER.name -> cylinderMesh
    else -> cubeMesh
}

private fun centerOf(o: EditorObject) = V3(o.x, o.y + 0.5f * o.scale, o.z)
private fun gizmoLen(o: EditorObject) = 0.9f * o.scale + 0.5f

private fun toWorld(o: EditorObject, p: V3): V3 {
    val a = Math.toRadians(o.rotY.toDouble()).toFloat()
    val c = cos(a)
    val s = sin(a)
    val x = p.x * o.scale
    val z = p.z * o.scale
    return V3(x * c + z * s + o.x, p.y * o.scale + o.y + 0.5f * o.scale, -x * s + z * c + o.z)
}

private fun normalToWorld(o: EditorObject, n: V3): V3 {
    val a = Math.toRadians(o.rotY.toDouble()).toFloat()
    val c = cos(a)
    val s = sin(a)
    return V3(n.x * c + n.z * s, n.y, -n.x * s + n.z * c)
}

private fun clipNear(pts: List<V3>): List<V3> {
    val out = ArrayList<V3>()
    for (i in pts.indices) {
        val a = pts[i]
        val b = pts[(i + 1) % pts.size]
        val ain = a.z >= NEAR
        val bin = b.z >= NEAR
        if (ain) out.add(a)
        if (ain != bin) {
            val t = (NEAR - a.z) / (b.z - a.z)
            out.add(V3(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, NEAR))
        }
    }
    return out
}

private fun bodyHit(cam: Cam, o: EditorObject, p: Offset, pad: Float): Boolean {
    val c = cam.toCam(centerOf(o))
    if (c.z < NEAR) return false
    val s = cam.proj(c)
    val rad = 0.72f * o.scale / c.z * cam.focal * pad
    return (p - s).getDistance() <= rad
}

private fun pickAt(cam: Cam, list: List<EditorObject>, p: Offset): EditorObject? =
    list.filter { bodyHit(cam, it, p, 1f) }.minByOrNull { cam.toCam(centerOf(it)).z }

/** Distance point → segment, en pixels. */
private fun segDist(p: Offset, a: Offset, b: Offset): Float {
    val ab = b - a
    val l2 = ab.x * ab.x + ab.y * ab.y
    if (l2 < 1e-3f) return (p - a).getDistance()
    val t = (((p.x - a.x) * ab.x + (p.y - a.y) * ab.y) / l2).coerceIn(0f, 1f)
    return (p - (a + ab * t)).getDistance()
}

private fun hitAxis(cam: Cam, o: EditorObject, p: Offset): Int {
    val c = centerOf(o)
    val len = gizmoLen(o)
    var best = -1
    var bestD = 46f
    for (i in 0..2) {
        val c0 = cam.toCam(c)
        val c1 = cam.toCam(c + AXES[i] * len)
        if (c0.z < NEAR || c1.z < NEAR) continue
        val d = segDist(p, cam.proj(c0), cam.proj(c1))
        if (d < bestD) {
            bestD = d
            best = i
        }
    }
    return best
}

private fun planeHit(cam: Cam, p: Offset, y0: Float): V3? {
    val dir = cam.ray(p)
    if (abs(dir.y) < 1e-4f) return null
    val t = (y0 - cam.pos.y) / dir.y
    if (t <= 0f) return null
    return cam.pos + dir * t
}

// ───────────────────────── Dessin ─────────────────────────

private fun DrawScope.fillPoly(cam: Cam, pts: List<V3>, color: Color) {
    val cs = clipNear(pts.map { cam.toCam(it) })
    if (cs.size < 3) return
    val path = Path()
    cs.forEachIndexed { i, c ->
        val p = cam.proj(c)
        if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
    }
    path.close()
    drawPath(path, color)
}

private fun DrawScope.seg(cam: Cam, a: V3, b: V3, color: Color, width: Float) {
    var ca = cam.toCam(a)
    var cb = cam.toCam(b)
    if (ca.z < NEAR && cb.z < NEAR) return
    if (ca.z < NEAR) {
        val t = (NEAR - ca.z) / (cb.z - ca.z)
        ca = V3(ca.x + (cb.x - ca.x) * t, ca.y + (cb.y - ca.y) * t, NEAR)
    } else if (cb.z < NEAR) {
        val t = (NEAR - cb.z) / (ca.z - cb.z)
        cb = V3(cb.x + (ca.x - cb.x) * t, cb.y + (ca.y - cb.y) * t, NEAR)
    }
    drawLine(color, cam.proj(ca), cam.proj(cb), width)
}

/** Ciel, sol, grille au sol et axes X (rouge) / Z (bleu). */
private fun DrawScope.drawWorld(cam: Cam) {
    drawRect(Brush.verticalGradient(colors = listOf(Color(0xFF0A101B), Color(0xFF2A3B52)), startY = 0f, endY = size.height * 0.6f))
    val big = 300f
    fillPoly(cam, listOf(V3(-big, 0f, -big), V3(big, 0f, -big), V3(big, 0f, big), V3(-big, 0f, big)), Color(0xFF262B33))
    for (i in -20..20) {
        val major = i % 5 == 0
        val col = AgwColors.SilverMuted.copy(alpha = if (major) 0.30f else 0.12f)
        val w = if (major) 2f else 1.2f
        seg(cam, V3(-20f, 0f, i.toFloat()), V3(20f, 0f, i.toFloat()), col, w)
        seg(cam, V3(i.toFloat(), 0f, -20f), V3(i.toFloat(), 0f, 20f), col, w)
    }
    seg(cam, V3(-20f, 0f, 0f), V3(20f, 0f, 0f), AXIS_COLORS[0].copy(alpha = 0.8f), 3f)
    seg(cam, V3(0f, 0f, -20f), V3(0f, 0f, 20f), AXIS_COLORS[2].copy(alpha = 0.8f), 3f)
}

private class FaceDraw(val path: Path, val color: Color)

private fun DrawScope.drawObjects(cam: Cam, objects: List<EditorObject>, selectedId: String?) {
    val order = objects.sortedByDescending { cam.toCam(centerOf(it)).z }
    for (o in order) {
        // Ombre portée (disque au sol)
        val rs = (if (o.kind == EditorKind.CUBE.name) 0.75f else 0.52f) * o.scale
        val shadow = (0 until 20).map { i ->
            val a = (2.0 * PI * i / 20).toFloat()
            V3(o.x + cos(a) * rs, 0.004f, o.z + sin(a) * rs)
        }
        fillPoly(cam, shadow, Color.Black.copy(alpha = 0.35f))

        val faces = ArrayList<FaceDraw>()
        for (f in meshOf(o.kind)) {
            val wn = normalToWorld(o, f.n)
            val ws = f.v.map { toWorld(o, it) }
            var cen = V3(0f, 0f, 0f)
            ws.forEach { cen = cen + it }
            cen = cen * (1f / ws.size)
            if (wn.dot(cam.pos - cen) <= 0f) continue
            val cs = clipNear(ws.map { cam.toCam(it) })
            if (cs.size < 3) continue
            val path = Path()
            cs.forEachIndexed { i, c ->
                val p = cam.proj(c)
                if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            }
            path.close()
            val shade = 0.38f + 0.62f * max(0f, wn.dot(LIGHT))
            val neutral = o.hue < 0f
            val col = Color.hsv(if (neutral) 0f else o.hue, if (neutral) 0f else 0.5f, (0.4f + 0.55f * shade).coerceAtMost(1f))
            faces.add(FaceDraw(path, col))
        }
        if (o.id == selectedId) {
            faces.forEach { drawPath(it.path, ORANGE, style = Stroke(width = 9f, join = StrokeJoin.Round)) }
        }
        faces.forEach {
            drawPath(it.path, it.color)
            drawPath(it.path, Color.Black.copy(alpha = 0.22f), style = Stroke(width = 1.5f))
        }
    }
}

private fun DrawScope.drawGizmo(cam: Cam, o: EditorObject, tool: EditorTool, activeAxis: Int) {
    val c = centerOf(o)
    val len = gizmoLen(o)
    if (tool == EditorTool.ROTATE) {
        val n = 48
        for (k in 0 until n) {
            val a0 = (2.0 * PI * k / n).toFloat()
            val a1 = (2.0 * PI * (k + 1) / n).toFloat()
            seg(
                cam,
                c + V3(cos(a0) * len, 0f, sin(a0) * len),
                c + V3(cos(a1) * len, 0f, sin(a1) * len),
                AXIS_COLORS[1], 6f
            )
        }
    } else {
        for (i in 0..2) {
            val c0 = cam.toCam(c)
            val c1 = cam.toCam(c + AXES[i] * len)
            if (c0.z < NEAR || c1.z < NEAR) continue
            val p0 = cam.proj(c0)
            val p1 = cam.proj(c1)
            val v = p1 - p0
            val l = v.getDistance()
            if (l < 2f) continue
            val dir = v / l
            val perp = Offset(-dir.y, dir.x)
            val active = i == activeAxis
            val col = if (active) Color.White else AXIS_COLORS[i]
            drawLine(col, p0, p1, if (active) 9f else 6f, StrokeCap.Round)
            val head = Path().apply {
                if (tool == EditorTool.MOVE) {
                    val tip = p1 + dir * 30f
                    moveTo(tip.x, tip.y)
                    lineTo(p1.x + perp.x * 14f, p1.y + perp.y * 14f)
                    lineTo(p1.x - perp.x * 14f, p1.y - perp.y * 14f)
                } else {
                    val q = 13f
                    moveTo(p1.x + dir.x * q + perp.x * q, p1.y + dir.y * q + perp.y * q)
                    lineTo(p1.x + dir.x * q - perp.x * q, p1.y + dir.y * q - perp.y * q)
                    lineTo(p1.x - dir.x * q - perp.x * q, p1.y - dir.y * q - perp.y * q)
                    lineTo(p1.x - dir.x * q + perp.x * q, p1.y - dir.y * q + perp.y * q)
                }
                close()
            }
            drawPath(head, col)
        }
    }
    val cc = cam.toCam(c)
    if (cc.z > NEAR) drawCircle(Color.White, 7f, cam.proj(cc))
}
