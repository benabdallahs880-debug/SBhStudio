"""Signale les fonctions locales Kotlin utilisées avant leur déclaration (erreur « Unresolved reference »).
Usage : python3 tools/checks/local_fun_order.py app/src/main/java"""
import re,glob,sys
root=sys.argv[1]
for p in glob.glob(root+'/**/*.kt',recursive=True):
    L=open(p,encoding='utf-8').read().split('\n')
    for i,l in enumerate(L):
        m=re.match(r'^(\s+)fun (\w+)\(',l)
        if m and len(m.group(1))>=4:
            j=i
            while j>0 and (L[j][:1] in (' ','}',')','') ): j-=1
            if not re.search(r'\bfun\b',L[j]) and not L[j].startswith('@'): continue
            name=m.group(2)
            for k in range(j,i):
                if re.search(r'(?<![\w.])'+name+r'\(',L[k]) and not re.match(r'^\s+fun '+name,L[k]):
                    print(f"{p}:{k+1} uses {name} declared at {i+1}"); break
