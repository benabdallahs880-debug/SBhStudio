# SBh Studio

SBh Studio 0.7.4 — Android studio for SBh / Minecraft Bedrock projects.

## Build

Debug local : `./gradlew assembleDebug`

Release CI requires these GitHub Actions secrets:
- `SBH_KEYSTORE_B64`
- `SBH_KEYSTORE_PASSWORD`
- `SBH_KEY_ALIAS`
- `SBH_KEY_PASSWORD`

The release keystore is never stored in the repository. The update manager verifies that a downloaded APK has the same application ID and signing certificate as the installed application before offering installation.

## Version

The source of truth is `version.json`.
