package com.sbh.studio.generator

import android.content.Context
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.workshop.MapBlueprint
import com.sbh.studio.workshop.PortalBlueprint
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/**
 * Moteur de fabrication avancé SBh Studio.
 * Enrichit PackGenerator : validation stricte, portails, plans de map,
 * fichiers lang, structure BP/RP plus complète.
 */
class AdvancedPackEngine(private val context: Context) {
    private val base = PackGenerator(context)
    private val json = Json { prettyPrint = true }

    data class BuildReport(
        val ok: Boolean,
        val errors: List<String>,
        val warnings: List<String>,
        val file: File? = null
    )

    fun validateAll(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint> = emptyList(),
        maps: List<MapBlueprint> = emptyList()
    ): BuildReport {
        val errors = base.validate(project, mobs, items, blocks).toMutableList()
        val warnings = mutableListOf<String>()

        val allIds = mutableListOf<String>()
        allIds += mobs.map { it.identifiant }
        allIds += items.map { it.identifier }
        allIds += blocks.map { it.identifier }
        allIds += portals.map { it.identifier }
        val dup = allIds.groupingBy { it }.eachCount().filter { it.value > 1 }.keys
        if (dup.isNotEmpty()) errors += "Identifiants en double : ${dup.joinToString()}"

        portals.forEach { p ->
            if (p.width < 2 || p.height < 3) errors += "Portail « ${p.name} » : taille trop petite (min 2×3)."
            if (p.width > 16 || p.height > 16) warnings += "Portail « ${p.name} » : très grand, performance à surveiller."
            if (!p.identifier.contains(":")) errors += "Portail « ${p.name} » : identifiant sans namespace."
        }
        maps.forEach { m ->
            if (m.sizeX < 8 || m.sizeZ < 8) errors += "Map « ${m.name} » : taille minimale 8×8."
            if (m.sizeX * m.sizeZ > 128 * 128) warnings += "Map « ${m.name} » : très large pour Bedrock."
        }
        if (mobs.isEmpty() && items.isEmpty() && blocks.isEmpty() && portals.isEmpty()) {
            warnings += "Pack quasi vide : ajoutez au moins un contenu."
        }
        return BuildReport(errors.isEmpty(), errors, warnings)
    }

    /** Export .mcaddon enrichi (base + stubs portails/maps + texts). */
    fun exportAdvanced(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint> = emptyList(),
        maps: List<MapBlueprint> = emptyList()
    ): BuildReport {
        val report = validateAll(project, mobs, items, blocks, portals, maps)
        if (!report.ok) return report

        return try {
            val bp = "BP"
            val extras = linkedMapOf<String, String>()
            portals.forEach { portal ->
                val id = portal.identifier.substringAfter(":", portal.identifier)
                extras["$bp/blocks/$id.json"] = portalBlockJson(portal)
                extras["$bp/docs/portal_${id}.txt"] = "Portal ${portal.name} ${portal.width}x${portal.height} frame=${portal.frameBlock} dest=${portal.destinationHint}"
            }
            maps.forEach { m ->
                val sid = safe(m.name).lowercase()
                extras["$bp/docs/map_${sid}.json"] = mapDocJson(m)
            }
            extras["RP/texts/languages.json"] = "[\"en_US\",\"fr_FR\"]"
            extras["RP/texts/fr_FR.lang"] = buildLang(project, mobs, items, blocks, "fr")
            extras["RP/texts/en_US.lang"] = buildLang(project, mobs, items, blocks, "en")
            val out = base.export(project, mobs, items, blocks, extras)
            BuildReport(true, emptyList(), report.warnings, out)
        } catch (e: Exception) {
            BuildReport(false, listOf(e.message ?: "Export failed"), report.warnings, null)
        }
    }

    private fun portalBlockJson(p: PortalBlueprint): String {
        val (ns, id) = split(p.identifier)
        return buildJsonObject {
            put("format_version", "1.21.0")
            putJsonObject("minecraft:block") {
                putJsonObject("description") { put("identifier", "$ns:$id") }
                putJsonObject("components") {
                    put("minecraft:destroy_time", 2.0)
                    put("minecraft:light_emission", 8)
                }
            }
        }.toString()
    }

    private fun mapDocJson(m: MapBlueprint): String = buildJsonObject {
        put("name", m.name)
        put("size_x", m.sizeX)
        put("size_z", m.sizeZ)
        put("theme", m.theme)
        put("village", m.hasVillage)
        put("dungeon", m.hasDungeon)
        put("oasis", m.hasOasis)
        put("notes", m.notes)
        put("hint", "Plan logique — à construire in-game ou via structure BP.")
    }.toString()

    private fun buildLang(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        lang: String
    ): String = buildString {
        appendLine("pack.name=${project.name}")
        appendLine("pack.description=SBh Studio pack")
        mobs.forEach { appendLine("entity.${it.identifiant}.name=${it.nom}") }
        items.forEach { appendLine("item.${it.identifier}=${it.name}") }
        blocks.forEach { appendLine("tile.${it.identifier}.name=${it.name}") }
        if (lang == "fr") appendLine("agw.studio=Généré par SBh Studio")
        else appendLine("agw.studio=Generated by SBh Studio")
    }

    private fun split(id: String): Pair<String, String> {
        val p = id.split(":", limit = 2)
        return if (p.size == 2) p[0] to p[1] else "agw" to id
    }

    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
    private fun writeText(zip: ZipOutputStream, path: String, text: String) {
        zip.putNextEntry(ZipEntry(path))
        zip.write(text.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    /** Presets monstre AGW pour faciliter la création */
    fun presetMobs(projectId: String): List<MobEntity> = listOf(
        MobEntity(projectId = projectId, nom = "Scorpion des Dunes", identifiant = "agw:dune_scorpion", vie = 24, vitesse = 0.3, degats = 5, hostile = true),
        MobEntity(projectId = projectId, nom = "Spectre des Ruines", identifiant = "agw:ruin_specter", vie = 30, vitesse = 0.22, degats = 4, hostile = true),
        MobEntity(projectId = projectId, nom = "Djinn Nocturne", identifiant = "agw:night_djinn", vie = 40, vitesse = 0.28, degats = 7, hostile = true),
        MobEntity(projectId = projectId, nom = "Sultan-Djinn", identifiant = "agw:djinn_sultan", vie = 200, vitesse = 0.2, degats = 12, hostile = true)
    )
}
