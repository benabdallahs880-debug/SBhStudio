package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

private val contentJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

class ItemRepository(private val context: Context) {
    private val file get() = File(context.filesDir, "sbh_items.json")
    fun loadAll(): List<SbhItem> = try { if (!file.exists()) emptyList() else contentJson.decodeFromString(file.readText()) } catch (_: Exception) { emptyList() }
    fun saveAll(value: List<SbhItem>) = atomicWrite(file, contentJson.encodeToString(value))
}
class BlockRepository(private val context: Context) {
    private val file get() = File(context.filesDir, "sbh_blocks.json")
    fun loadAll(): List<SbhBlock> = try { if (!file.exists()) emptyList() else contentJson.decodeFromString(file.readText()) } catch (_: Exception) { emptyList() }
    fun saveAll(value: List<SbhBlock>) = atomicWrite(file, contentJson.encodeToString(value))
}
