package com.sbh.studio.foundation.core

import android.content.Context
import java.io.File
import java.util.UUID
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Gestion du projet de fondation AGW.
 * Crée l'arborescence BP/RP + dossiers annexes.
 */
class FoundationProject(
    context: Context,
    val projectName: String = "SBh-AGW-Foundation"
) {
    companion object {
        const val PREFIX = "agw"
        const val VERSION = "0.7.4"
        val MIN_ENGINE = listOf(1, 21, 0)
    }

    val root: File = File(context.getExternalFilesDir(null), projectName)
    val behaviorPack: File = File(root, "behavior_pack")
    val resourcePack: File = File(root, "resource_pack")
    val exports: File = File(root, "exports")
    val factionsDir: File = File(root, "factions")
    val dialoguesDir: File = File(root, "dialogues")
    val mapDir: File = File(root, "map")

    init {
        ensureStructure()
    }

    private fun ensureStructure() {
        listOf(
            "behavior_pack/entities",
            "behavior_pack/items",
            "behavior_pack/blocks",
            "behavior_pack/loot_tables/entities",
            "behavior_pack/spawn_rules",
            "behavior_pack/scripts",
            "resource_pack/entity",
            "resource_pack/attachables",
            "resource_pack/textures/items",
            "resource_pack/textures/blocks",
            "resource_pack/textures/entity",
            "resource_pack/textures/models/armor",
            "resource_pack/texts",
            "exports",
            "factions",
            "dialogues",
            "map"
        ).forEach { File(root, it).mkdirs() }

        writeManifests()
        writeLanguages()
    }

    private fun writeManifests() {
        val idsFile = File(root, ".pack-uuids.json")
        val existing = runCatching {
            if (!idsFile.exists()) null else Json.parseToJsonElement(idsFile.readText()).jsonObject
        }.getOrNull()
        val bpUuid = existing?.get("bp")?.jsonPrimitive?.content ?: UUID.randomUUID().toString()
        val bpModUuid = existing?.get("bpModule")?.jsonPrimitive?.content ?: UUID.randomUUID().toString()
        val rpUuid = existing?.get("rp")?.jsonPrimitive?.content ?: UUID.randomUUID().toString()
        val rpModUuid = existing?.get("rpModule")?.jsonPrimitive?.content ?: UUID.randomUUID().toString()
        idsFile.writeText("""{
  "bp": "$bpUuid",
  "bpModule": "$bpModUuid",
  "rp": "$rpUuid",
  "rpModule": "$rpModUuid"
}
""")

        writeText(File(behaviorPack, "manifest.json"), """
            {
              "format_version": 2,
              "header": {
                "name": "SBh AGW BP",
                "description": "SBh Arabian Gothic World — Fondation $VERSION",
                "uuid": "$bpUuid",
                "version": [0, 7, 4],
                "min_engine_version": [1, 21, 0]
              },
              "modules": [{
                "type": "data",
                "uuid": "$bpModUuid",
                "version": [0, 7, 4]
              }]
            }
        """.trimIndent())

        writeText(File(resourcePack, "manifest.json"), """
            {
              "format_version": 2,
              "header": {
                "name": "SBh AGW RP",
                "description": "SBh Arabian Gothic World — Ressources $VERSION",
                "uuid": "$rpUuid",
                "version": [0, 7, 4],
                "min_engine_version": [1, 21, 0]
              },
              "modules": [{
                "type": "resources",
                "uuid": "$rpModUuid",
                "version": [0, 7, 4]
              }]
            }
        """.trimIndent())
    }

    private fun writeLanguages() {
        writeText(File(resourcePack, "texts/languages.json"), """["fr_FR", "en_US"]""")
        File(resourcePack, "texts/fr_FR.lang").takeIf { !it.exists() }?.writeText("")
        File(resourcePack, "texts/en_US.lang").takeIf { !it.exists() }?.writeText("")
    }

    fun appendLang(fr: String, en: String) {
        appendUnique(File(resourcePack, "texts/fr_FR.lang"), fr)
        appendUnique(File(resourcePack, "texts/en_US.lang"), en)
    }

    private fun appendUnique(file: File, line: String) {
        val normalized = line.trimEnd()
        val existing = if (file.exists()) file.readLines().toSet() else emptySet()
        if (normalized.isNotBlank() && normalized !in existing) {
            file.appendText(normalized + "\n")
        }
    }

    fun writeText(file: File, content: String) {
        file.parentFile?.mkdirs()
        file.writeText(content.trimIndent())
    }
}
