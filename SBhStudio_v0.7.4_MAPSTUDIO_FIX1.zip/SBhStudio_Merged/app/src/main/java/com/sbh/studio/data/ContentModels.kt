package com.sbh.studio.data

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class SbhItem(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val identifier: String,
    val damage: Int = 0,
    val durability: Int = 100,
    val textureUri: String? = null
)

@Serializable
data class SbhBlock(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val identifier: String,
    val hardness: Double = 1.0,
    val textureUri: String? = null
)
