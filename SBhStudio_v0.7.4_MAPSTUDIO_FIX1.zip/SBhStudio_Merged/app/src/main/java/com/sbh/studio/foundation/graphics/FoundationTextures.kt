package com.sbh.studio.foundation.graphics

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import com.sbh.studio.foundation.core.FoundationProject
import java.io.File
import java.io.FileOutputStream
import kotlin.random.Random

/**
 * Génération de textures PNG procédurales (placeholders 16×16 / 32×32).
 * Suffisant pour valider le pipeline et avoir un pack non-vide visuellement.
 */
object FoundationTextures {

    fun generateAll(p: FoundationProject) {
        val texItems = File(p.resourcePack, "textures/items")
        val texEntity = File(p.resourcePack, "textures/entity")
        texItems.mkdirs()
        texEntity.mkdirs()

        // Armes
        val weapons = listOf(
            "agw_sabre_hibou", "agw_sabre_ghurab", "agw_sabre_royal", "agw_sabre_templier",
            "agw_fusil_royal", "agw_fusil_hibou", "agw_pistolet_templier",
            "agw_pistolet_royal", "agw_mitrailleuse_lourde"
        )
        weapons.forEach { generateItemTexture(texItems, it, 0xFFB9B9C3.toInt(), isWeapon = true) }

        // Armures
        val armorFamilies = listOf("hibou", "ghurab", "royal", "templier")
        val armorColors = listOf(0xFF8C6A3F.toInt(), 0xFF5C3A2B.toInt(), 0xFF6B1E1E.toInt(), 0xFF4A4A55.toInt())
        armorFamilies.forEachIndexed { i, fam ->
            val c = armorColors[i]
            listOf("helmet", "chestplate", "leggings", "boots").forEach { slot ->
                generateItemTexture(texItems, "agw_armor_${fam}_$slot", c, isWeapon = false)
            }
        }

        // Ressources
        generateItemTexture(texItems, "agw_nrj_noire", 0xFF1A1512.toInt(), false)
        generateItemTexture(texItems, "agw_minerai_brut", 0xFF4A4030.toInt(), false)
        generateItemTexture(texItems, "agw_plan_mecanique", 0xFFD8CBB0.toInt(), false)
        generateItemTexture(texItems, "agw_composant_rare", 0xFFC9A227.toInt(), false)

        // Entités
        val characters = listOf(
            "agw_yahya", "agw_zaynab", "agw_chef_hibou", "agw_chef_ghurab",
            "agw_roi", "agw_garde_royal", "agw_soldat_hibou", "agw_soldat_ghurab",
            "agw_templier", "agw_marchand_bedouin", "agw_vautour", "agw_hashashin"
        )
        val charColors = listOf(
            0xFF8C6A3F.toInt(), 0xFFD8CBB0.toInt(), 0xFF3A2E1F.toInt(), 0xFF2B2620.toInt(),
            0xFF6B1E1E.toInt(), 0xFF5C4A3A.toInt(), 0xFF4A3520.toInt(), 0xFF3A2620.toInt(),
            0xFF4A4A55.toInt(), 0xFF8C6A3F.toInt(), 0xFF4A2A1A.toInt(), 0xFF1A1A1A.toInt()
        )
        characters.forEachIndexed { i, name ->
            generateEntityTexture(texEntity, name, charColors[i], 0xFFC9A227.toInt())
        }
    }

    private fun generateItemTexture(dir: File, name: String, baseColor: Int, isWeapon: Boolean) {
        val bmp = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        if (isWeapon) {
            val light = shade(baseColor, 40)
            val dark = shade(baseColor, -50)
            // lame diagonale
            listOf(5 to 10, 6 to 9, 7 to 8, 8 to 7, 9 to 6, 10 to 5, 11 to 4, 12 to 3, 13 to 2, 14 to 1)
                .forEach { (x, y) -> bmp.setPixel(x, y, light) }
            listOf(6 to 10, 7 to 9, 8 to 8, 9 to 7, 10 to 6, 11 to 5, 12 to 4, 13 to 3)
                .forEach { (x, y) -> bmp.setPixel(x, y, baseColor) }
            // garde or
            bmp.setPixel(4, 11, 0xFFC9A227.toInt())
            bmp.setPixel(5, 11, 0xFFC9A227.toInt())
            // poignée
            bmp.setPixel(3, 12, 0xFF4B2D19.toInt())
            bmp.setPixel(3, 13, 0xFF2D190F.toInt())
        } else {
            val r = Random(name.hashCode())
            for (y in 0 until 16) for (x in 0 until 16) {
                val v = r.nextInt(21) - 10
                val edge = x < 2 || x > 13 || y < 2 || y > 13
                bmp.setPixel(x, y, if (edge) shade(baseColor, -40) else shade(baseColor, v))
            }
            // centre plus clair
            for (y in 5 until 11) for (x in 5 until 11) {
                bmp.setPixel(x, y, shade(baseColor, 15 + r.nextInt(10)))
            }
            // point d'or pour objets rares
            if (name.contains("rare") || name.contains("nrj") || name.contains("royal")) {
                bmp.setPixel(8, 8, 0xFFC9A227.toInt())
                bmp.setPixel(7, 8, 0xFFE8C84A.toInt())
                bmp.setPixel(8, 7, 0xFFE8C84A.toInt())
            }
        }
        save(bmp, File(dir, "$name.png"))
    }

    private fun generateEntityTexture(dir: File, name: String, baseColor: Int, accent: Int) {
        val bmp = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        val r = Random(name.hashCode())
        val br = Color.red(baseColor)
        val bg = Color.green(baseColor)
        val bb = Color.blue(baseColor)
        for (y in 0 until 32) for (x in 0 until 32) {
            val v = r.nextInt(31) - 15
            bmp.setPixel(x, y, Color.rgb(clamp(br + v), clamp(bg + v), clamp(bb + v)))
        }
        // yeux
        bmp.setPixel(10, 12, 0xFFFFDC96.toInt())
        bmp.setPixel(21, 12, 0xFFFFDC96.toInt())
        save(bmp, File(dir, "$name.png"))
    }

    private fun clamp(v: Int) = v.coerceIn(0, 255)
    private fun shade(color: Int, delta: Int) = Color.rgb(
        clamp(Color.red(color) + delta),
        clamp(Color.green(color) + delta),
        clamp(Color.blue(color) + delta)
    )

    private fun save(bmp: Bitmap, file: File) {
        file.parentFile?.mkdirs()
        FileOutputStream(file).use { fos ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
        }
    }
}
