package com.sbh.studio.foundation

import android.content.Context
import com.sbh.studio.foundation.content.FoundationGenerators
import com.sbh.studio.foundation.core.FoundationPackager
import com.sbh.studio.foundation.core.FoundationProject
import com.sbh.studio.foundation.graphics.FoundationTextures
import java.io.File

/**
 * Classe maîtresse — Bac à sable SBh AGW.
 * Un seul appel génère tout le contenu de fondation + textures + packs.
 *
 * Usage :
 *   val project = SBhWorldFoundation.generateAll(context)
 *   val addon = SBhWorldFoundation.exportAddon(project)
 */
object SBhWorldFoundation {

    data class Result(
        val project: FoundationProject,
        val addonFile: File?,
        val message: String
    )

    /**
     * Génère l’intégralité de la fondation.
     * @return le projet créé (dossiers + fichiers)
     */
    fun generateAll(context: Context, projectName: String = "SBh-AGW-Foundation"): FoundationProject {
        val p = FoundationProject(context, projectName)

        FoundationGenerators.generateFactions(p)
        FoundationGenerators.generateCharacters(p)
        FoundationGenerators.generateWeapons(p)
        FoundationGenerators.generateArmors(p)
        FoundationGenerators.generateMaterials(p)
        FoundationGenerators.generateRegions(p)
        FoundationGenerators.generateDialogues(p)
        FoundationTextures.generateAll(p)

        return p
    }

    /**
     * Génère + package en .mcaddon prêt à installer.
     */
    fun generateAndExport(context: Context, projectName: String = "SBh-AGW-Foundation"): Result {
        val project = generateAll(context, projectName)
        val addon = try {
            FoundationPackager.createAddon(project)
        } catch (e: Exception) {
            return Result(project, null, "Génération OK, export échoué : ${e.message}")
        }
        return Result(
            project,
            addon,
            "Fondation générée ✓\n" +
            "• 8 factions\n" +
            "• 12 personnages\n" +
            "• 9 armes + 16 pièces d’armure\n" +
            "• 4 ressources\n" +
            "• 8 régions + 4 dialogues\n" +
            "• Textures PNG\n" +
            "• .mcaddon prêt : ${addon.name}"
        )
    }

    fun exportAddon(project: FoundationProject): File =
        FoundationPackager.createAddon(project)
}
