package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

private val mobJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

class MobRepository(private val context: Context) {
    private val storageFile get() = File(context.filesDir, "sbh_mobs.json")
    fun loadAll(): List<MobEntity> = try {
        if (!storageFile.exists()) emptyList() else mobJson.decodeFromString(storageFile.readText())
    } catch (_: Exception) { emptyList() }
    fun loadForProject(projectId: String) = loadAll().filter { it.projectId == projectId }
    fun saveAll(mobs: List<MobEntity>) = atomicWrite(storageFile, mobJson.encodeToString(mobs))
}
