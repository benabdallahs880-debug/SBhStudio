package com.sbh.studio.foundation.core

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Packaging BP / RP / .mcaddon.
 */
object FoundationPackager {

    fun createBehaviorPack(project: FoundationProject): File {
        val out = File(project.exports, "SBh-AGW-BP.mcpack")
        zipFolder(project.behaviorPack, out)
        return out
    }

    fun createResourcePack(project: FoundationProject): File {
        val out = File(project.exports, "SBh-AGW-RP.mcpack")
        zipFolder(project.resourcePack, out)
        return out
    }

    fun createAddon(project: FoundationProject): File {
        createBehaviorPack(project)
        createResourcePack(project)
        val addon = File(project.exports, "SBh-AGW.mcaddon")
        ZipOutputStream(FileOutputStream(addon)).use { zos ->
            addFile(zos, File(project.exports, "SBh-AGW-BP.mcpack"), "SBh-AGW-BP.mcpack")
            addFile(zos, File(project.exports, "SBh-AGW-RP.mcpack"), "SBh-AGW-RP.mcpack")
        }
        return addon
    }

    private fun zipFolder(source: File, output: File) {
        ZipOutputStream(FileOutputStream(output)).use { zos ->
            source.walkTopDown().filter { it.isFile && !it.name.startsWith(".") }.forEach { file ->
                val rel = source.toURI().relativize(file.toURI()).path
                zos.putNextEntry(ZipEntry(rel))
                FileInputStream(file).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun addFile(zos: ZipOutputStream, file: File, entryName: String) {
        zos.putNextEntry(ZipEntry(entryName))
        FileInputStream(file).use { it.copyTo(zos) }
        zos.closeEntry()
    }
}
