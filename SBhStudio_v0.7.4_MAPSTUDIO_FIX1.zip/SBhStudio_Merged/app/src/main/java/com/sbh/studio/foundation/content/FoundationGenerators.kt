package com.sbh.studio.foundation.content

import com.sbh.studio.foundation.core.FoundationProject
import java.io.File

/**
 * Générateurs de contenu fondation (factions, personnages, armes, armures, ressources, régions, dialogues).
 * Version Kotlin propre, JSON minimal mais valide 1.21.
 */
object FoundationGenerators {

    // ─── FACTIONS ───────────────────────────────────────────────
    fun generateFactions(p: FoundationProject) {
        data class Faction(val id: String, val nameFr: String, val nameEn: String,
                           val allies: List<String>, val enemies: List<String>, val neutrals: List<String>)

        val factions = listOf(
            Faction("hibou", "Hibou", "Hibou", listOf("ghurab"), listOf("templiers", "vautours"),
                listOf("royaume", "perses", "hashashin", "bedouins")),
            Faction("ghurab", "Ghurab", "Ghurab", listOf("hibou"), listOf("templiers", "vautours"),
                listOf("royaume", "perses", "hashashin", "bedouins")),
            Faction("royaume", "Royaume", "Kingdom", listOf("templiers"), listOf("hibou", "ghurab"),
                listOf("perses", "vautours", "hashashin", "bedouins")),
            Faction("templiers", "Templiers", "Templars", listOf("royaume"), listOf("hibou", "ghurab"),
                listOf("perses", "vautours", "hashashin", "bedouins")),
            Faction("perses", "Perses", "Persians", emptyList(), emptyList(),
                listOf("hibou", "ghurab", "royaume", "templiers", "vautours", "hashashin", "bedouins")),
            Faction("vautours", "Vautours", "Vultures", emptyList(), listOf("hibou", "ghurab"),
                listOf("royaume", "templiers", "perses", "hashashin", "bedouins")),
            Faction("hashashin", "Hashashin", "Hashashin", emptyList(), emptyList(),
                listOf("hibou", "ghurab", "royaume", "templiers", "perses", "vautours", "bedouins")),
            Faction("bedouins", "Bédouins", "Bedouins", emptyList(), emptyList(),
                listOf("hibou", "ghurab", "royaume", "templiers", "perses", "vautours", "hashashin"))
        )

        factions.forEach { f ->
            val json = """
                {
                  "format_version": 1,
                  "faction": {
                    "id": "${f.id}",
                    "name_fr": "${f.nameFr}",
                    "name_en": "${f.nameEn}",
                    "allies": [${f.allies.joinToString(",") { "\"$it\"" }}],
                    "enemies": [${f.enemies.joinToString(",") { "\"$it\"" }}],
                    "neutrals": [${f.neutrals.joinToString(",") { "\"$it\"" }}]
                  }
                }
            """.trimIndent()
            p.writeText(File(p.factionsDir, "${f.id}.json"), json)
        }
    }

    // ─── PERSONNAGES / ENTITÉS ──────────────────────────────────
    fun generateCharacters(p: FoundationProject) {
        data class Char(
            val id: String, val nameFr: String, val nameEn: String,
            val hp: Int, val damage: Int, val speed: Double,
            val faction: String, val isGuard: Boolean, val canStroll: Boolean
        )

        val chars = listOf(
            Char("yahya", "Yahya ibn Harith", "Yahya ibn Harith", 32, 7, 0.25, "hibou", true, true),
            Char("zaynab", "Zaynab", "Zaynab", 20, 0, 0.2, "ghurab", false, true),
            Char("chef_hibou", "Chef de Hibou", "Hibou Leader", 28, 6, 0.23, "hibou", true, false),
            Char("chef_ghurab", "Chef de Ghurab", "Ghurab Leader", 28, 6, 0.23, "ghurab", true, false),
            Char("roi", "Le Roi", "The King", 30, 5, 0.2, "royaume", false, false),
            Char("garde_royal", "Garde royal", "Royal Guard", 24, 5, 0.25, "royaume", true, true),
            Char("soldat_hibou", "Combattant Hibou", "Hibou Fighter", 22, 5, 0.25, "hibou", true, true),
            Char("soldat_ghurab", "Combattant Ghurab", "Ghurab Fighter", 22, 5, 0.25, "ghurab", true, true),
            Char("templier", "Templier", "Templar", 28, 6, 0.24, "templiers", true, true),
            Char("marchand_bedouin", "Marchand bédouin", "Bedouin Merchant", 18, 0, 0.2, "bedouins", false, true),
            Char("vautour", "Vautour", "Vulture", 20, 4, 0.26, "vautours", true, true),
            Char("hashashin", "Hashashin", "Hashashin", 26, 7, 0.28, "hashashin", true, true)
        )

        chars.forEach { c ->
            val eid = "${FoundationProject.PREFIX}:${c.id}"
            val behaviors = buildString {
                append(""""minecraft:behavior.float":{"priority":0},""")
                append(""""minecraft:behavior.look_at_player":{"priority":7,"look_distance":6,"probability":0.02},""")
                append(""""minecraft:behavior.random_look_around":{"priority":8}""")
                if (c.canStroll) append(""", "minecraft:behavior.random_stroll":{"priority":6,"speed_multiplier":0.8}""")
                if (c.isGuard) {
                    append(""", "minecraft:attack":{"damage":${c.damage}}""")
                    append(""", "minecraft:behavior.melee_attack":{"priority":2,"speed_multiplier":1.0,"track_target":true}""")
                }
            }

            val bp = """
                {
                  "format_version": "1.21.0",
                  "minecraft:entity": {
                    "description": {
                      "identifier": "$eid",
                      "is_spawnable": true,
                      "is_summonable": true
                    },
                    "components": {
                      "minecraft:type_family": {"family": ["agw_npc", "${c.faction}", "mob"]},
                      "minecraft:health": {"value": ${c.hp}, "max": ${c.hp}},
                      "minecraft:movement": {"value": ${c.speed}},
                      "minecraft:navigation.walk": {"can_path_over_water": false},
                      "minecraft:movement.basic": {},
                      "minecraft:jump.static": {},
                      "minecraft:can_climb": {},
                      "minecraft:physics": {},
                      "minecraft:collision_box": {"width": 0.6, "height": 1.8},
                      "minecraft:nameable": {"always_show": true},
                      "minecraft:persistent": {},
                      "minecraft:pushable": {"is_pushable": false, "is_pushable_by_piston": true},
                      $behaviors
                    }
                  }
                }
            """.trimIndent()

            p.writeText(File(p.behaviorPack, "entities/${c.id}.json"), bp)

            val rp = """
                {
                  "format_version": "1.10.0",
                  "minecraft:client_entity": {
                    "description": {
                      "identifier": "$eid",
                      "materials": {"default": "default"},
                      "textures": {"default": "textures/entity/${FoundationProject.PREFIX}_${c.id}"},
                      "geometry": {"default": "geometry.humanoid"},
                      "animations": {
                        "walk": "animation.humanoid.move",
                        "look": "animation.humanoid.look_at_target"
                      },
                      "scripts": {"animate": ["walk", "look"]},
                      "render_controllers": ["controller.render.default"],
                      "spawn_egg": {"base_color": "#8C6A3F", "overlay_color": "#2B2620"}
                    }
                  }
                }
            """.trimIndent()

            p.writeText(File(p.resourcePack, "entity/${c.id}.entity.json"), rp)
            p.appendLang("entity.$eid.name=${c.nameFr}", "entity.$eid.name=${c.nameEn}")
        }
    }

    // ─── ARMES ──────────────────────────────────────────────────
    fun generateWeapons(p: FoundationProject) {
        data class Weapon(val id: String, val nameFr: String, val nameEn: String, val damage: Int, val durability: Int)

        val weapons = listOf(
            Weapon("sabre_hibou", "Sabre de Hibou", "Hibou Saber", 7, 600),
            Weapon("sabre_ghurab", "Sabre de Ghurab", "Ghurab Saber", 7, 600),
            Weapon("sabre_royal", "Sabre royal", "Royal Saber", 8, 650),
            Weapon("sabre_templier", "Sabre templier", "Templar Saber", 8, 650),
            Weapon("fusil_royal", "Fusil royal", "Royal Rifle", 11, 400),
            Weapon("fusil_hibou", "Fusil de Hibou", "Hibou Rifle", 10, 380),
            Weapon("pistolet_templier", "Pistolet templier", "Templar Pistol", 8, 300),
            Weapon("pistolet_royal", "Pistolet royal", "Royal Pistol", 8, 300),
            Weapon("mitrailleuse_lourde", "Mitrailleuse lourde", "Heavy MG", 14, 800)
        )

        weapons.forEach { w ->
            val iid = "${FoundationProject.PREFIX}:${w.id}"
            val json = """
                {
                  "format_version": "1.21.0",
                  "minecraft:item": {
                    "description": {
                      "identifier": "$iid",
                      "menu_category": {"category": "equipment", "group": "minecraft:itemGroup.name.sword"}
                    },
                    "components": {
                      "minecraft:icon": "${FoundationProject.PREFIX}_${w.id}",
                      "minecraft:display_name": {"value": "${w.nameFr}"},
                      "minecraft:max_stack_size": 1,
                      "minecraft:hand_equipped": true,
                      "minecraft:durability": {"max_durability": ${w.durability}},
                      "minecraft:damage": ${w.damage},
                      "minecraft:enchantable": {"value": 10, "slot": "sword"},
                      "minecraft:tags": {"tags": ["minecraft:is_sword"]}
                    }
                  }
                }
            """.trimIndent()
            p.writeText(File(p.behaviorPack, "items/${w.id}.json"), json)
            addItemTextureEntry(p, "${FoundationProject.PREFIX}_${w.id}")
            p.appendLang("item.$iid.name=${w.nameFr}", "item.$iid.name=${w.nameEn}")
        }
    }

    // ─── ARMURES ────────────────────────────────────────────────
    fun generateArmors(p: FoundationProject) {
        data class ArmorSet(val family: String, val nameFr: String, val nameEn: String,
                            val prot: IntArray, val dur: IntArray)

        val sets = listOf(
            ArmorSet("hibou", "de Hibou", "Hibou", intArrayOf(2, 4, 3, 1), intArrayOf(180, 240, 220, 190)),
            ArmorSet("ghurab", "de Ghurab", "Ghurab", intArrayOf(2, 4, 3, 1), intArrayOf(180, 240, 220, 190)),
            ArmorSet("royal", "royale", "Royal", intArrayOf(3, 6, 5, 2), intArrayOf(300, 450, 420, 360)),
            ArmorSet("templier", "templière", "Templar", intArrayOf(4, 7, 6, 3), intArrayOf(400, 600, 550, 480))
        )

        val slots = listOf("helmet", "chestplate", "leggings", "boots")
        val labelsFr = listOf("Casque", "Plastron", "Jambières", "Bottes")
        val wearable = listOf("slot.armor.head", "slot.armor.chest", "slot.armor.legs", "slot.armor.feet")

        sets.forEach { s ->
            slots.forEachIndexed { i, slot ->
                val iid = "${FoundationProject.PREFIX}:armor_${s.family}_$slot"
                val icon = "${FoundationProject.PREFIX}_armor_${s.family}_$slot"
                val fullFr = "${labelsFr[i]} ${s.nameFr}"
                val fullEn = "${s.nameEn} $slot"

                val json = """
                    {
                      "format_version": "1.21.0",
                      "minecraft:item": {
                        "description": {
                          "identifier": "$iid",
                          "menu_category": {"category": "equipment", "group": "minecraft:itemGroup.name.$slot"}
                        },
                        "components": {
                          "minecraft:icon": "$icon",
                          "minecraft:display_name": {"value": "$fullFr"},
                          "minecraft:max_stack_size": 1,
                          "minecraft:durability": {"max_durability": ${s.dur[i]}},
                          "minecraft:wearable": {"slot": "${wearable[i]}", "protection": ${s.prot[i]}},
                          "minecraft:armor": {"protection": ${s.prot[i]}}
                        }
                      }
                    }
                """.trimIndent()
                p.writeText(File(p.behaviorPack, "items/armor_${s.family}_$slot.json"), json)
                addItemTextureEntry(p, icon)
                p.appendLang("item.$iid.name=$fullFr", "item.$iid.name=$fullEn")
            }
        }
    }

    // ─── RESSOURCES ─────────────────────────────────────────────
    fun generateMaterials(p: FoundationProject) {
        data class Mat(val id: String, val nameFr: String, val nameEn: String)

        listOf(
            Mat("nrj_noire", "NRJ noire", "Black NRJ"),
            Mat("minerai_brut", "Minerai brut", "Raw Ore"),
            Mat("plan_mecanique", "Plan mécanique", "Mechanical Blueprint"),
            Mat("composant_rare", "Composant rare", "Rare Component")
        ).forEach { m ->
            val iid = "${FoundationProject.PREFIX}:${m.id}"
            val json = """
                {
                  "format_version": "1.21.0",
                  "minecraft:item": {
                    "description": {
                      "identifier": "$iid",
                      "menu_category": {"category": "items"}
                    },
                    "components": {
                      "minecraft:icon": "${FoundationProject.PREFIX}_${m.id}",
                      "minecraft:display_name": {"value": "${m.nameFr}"},
                      "minecraft:max_stack_size": 64
                    }
                  }
                }
            """.trimIndent()
            p.writeText(File(p.behaviorPack, "items/${m.id}.json"), json)
            addItemTextureEntry(p, "${FoundationProject.PREFIX}_${m.id}")
            p.appendLang("item.$iid.name=${m.nameFr}", "item.$iid.name=${m.nameEn}")
        }
    }

    // ─── RÉGIONS ────────────────────────────────────────────────
    fun generateRegions(p: FoundationProject) {
        data class Marker(val name: String, val x: Int, val y: Int, val z: Int, val type: String, val faction: String, val note: String)

        val markers = listOf(
            Marker("Camp principal Hibou", 500, 70, 300, "fort", "hibou", "QG opérationnel"),
            Marker("Village Hibou Nord", 400, 65, 150, "village", "hibou", "Soutien logistique"),
            Marker("Territoire Ghurab Est", 800, 68, 500, "fort", "ghurab", "Zone montagneuse"),
            Marker("Capitale du Royaume", 0, 64, 0, "capitale", "royaume", "Ambassades, banques, palais"),
            Marker("Base maritime Templiers", -600, 60, -400, "fort", "templiers", "Port et navires"),
            Marker("Base intérieure Templiers", -400, 70, -200, "fort", "templiers", "Aérodrome primitif"),
            Marker("École de Zaynab", -50, 64, 30, "village", "royaume", "École religieuse — DÉTRUITE"),
            Marker("Montagnes Vertes", -900, 120, -600, "ruine", "neutre", "Frontière naturelle")
        )

        val json = buildString {
            append("{\n  \"format_version\": 1,\n  \"regions\": [\n")
            markers.forEachIndexed { i, m ->
                append("""    {"name":"${m.name}","x":${m.x},"y":${m.y},"z":${m.z},"type":"${m.type}","faction":"${m.faction}","note":"${m.note}"}""")
                if (i < markers.lastIndex) append(",")
                append("\n")
            }
            append("  ]\n}")
        }
        p.writeText(File(p.mapDir, "regions.json"), json)
    }

    // ─── DIALOGUES ──────────────────────────────────────────────
    fun generateDialogues(p: FoundationProject) {
        data class Dia(val id: String, val faction: String, val linesFr: List<String>, val linesEn: List<String>)

        listOf(
            Dia("hibou_intro", "hibou",
                listOf("Combattant Hibou : Halte.", "Combattant Hibou : Nous ne faisons pas confiance aux étrangers."),
                listOf("Hibou Fighter : Stop.", "Hibou Fighter : We don't trust strangers.")),
            Dia("ghurab_intro", "ghurab",
                listOf("Combattant Ghurab : Approche pas trop près.", "Combattant Ghurab : On ne fait confiance à personne ici."),
                listOf("Ghurab Fighter : Don't come too close.", "Ghurab Fighter : We trust no one here.")),
            Dia("templier_neutre", "templiers",
                listOf("Templier : Bonjour, étranger.", "Templier : Nous sommes ici pour aider ce royaume."),
                listOf("Templar : Hello, stranger.", "Templar : We're here to help this kingdom.")),
            Dia("roi_audience", "royaume",
                listOf("Le Roi : Approche.", "Le Roi : Ce royaume traverse une période difficile."),
                listOf("The King : Come closer.", "The King : This kingdom is going through hard times."))
        ).forEach { d ->
            val json = """
                {
                  "id": "${d.id}",
                  "faction": "${d.faction}",
                  "lines_fr": [${d.linesFr.joinToString(",") { "\"$it\"" }}],
                  "lines_en": [${d.linesEn.joinToString(",") { "\"$it\"" }}]
                }
            """.trimIndent()
            p.writeText(File(p.dialoguesDir, "${d.id}.json"), json)
        }
    }

    // ─── HELPER TEXTURE INDEX ───────────────────────────────────
    private fun addItemTextureEntry(p: FoundationProject, iconName: String) {
        val f = File(p.resourcePack, "textures/item_texture.json")
        val entry = "\"$iconName\":{\"textures\":\"textures/items/$iconName\"}"
        if (!f.exists() || !f.readText().contains("\"texture_data\"")) {
            p.writeText(f, """{"resource_pack_name":"SBh AGW","texture_name":"atlas.items","texture_data":{$entry}}""")
        } else {
            val updated = f.readText().replaceFirst(Regex("""\}\}\s*$"""), ",$entry}}")
            f.writeText(updated)
        }
    }
}
