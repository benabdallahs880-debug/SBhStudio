package com.sbh.studio.ui

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Charge une image depuis assets/branding/
 */
@Composable
fun rememberAssetBitmap(path: String): androidx.compose.ui.graphics.ImageBitmap? {
    val context = LocalContext.current
    return remember(path) {
        runCatching {
            context.assets.open(path).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
        }.getOrNull()
    }
}

@Composable
fun BrandLogo(
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 96.dp
) {
    val bmp = rememberAssetBitmap("branding/logo_owl_gothic.jpg")
        ?: rememberAssetBitmap("branding/logo_owl_celtic.jpg")

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .border(2.dp, AgwColors.GoldSoft, CircleShape)
            .background(AgwColors.NightStone),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = "SBh Studio Logo",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text("🦉", fontSize = 40.sp)
        }
    }
}

@Composable
fun HomeAtmosphereBackground(modifier: Modifier = Modifier) {
    val bmp = rememberAssetBitmap("branding/bg_raven_owl.png")
        ?: rememberAssetBitmap("branding/bg_owl_moon.png")

    Box(modifier = modifier) {
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                alpha = 0.35f
            )
        }
        // Voile sombre + gradient ocre pour lisibilité
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xE61A1612),
                            Color(0xCC1A1612),
                            Color(0xF01A1612)
                        )
                    )
                )
        )
    }
}

@Composable
fun StudioBrandHeader(lang: AppLang) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
    ) {
        BrandLogo(size = 100.dp)
        Spacer(Modifier.height(12.dp))
        Text(
            S.t(lang, "app_name"),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = AgwColors.SacredGold
        )
        Text(
            "صباح · SBh Studio",
            style = MaterialTheme.typography.labelMedium,
            color = AgwColors.Sand
        )
        Text(
            S.t(lang, "owl_motto"),
            style = MaterialTheme.typography.bodySmall,
            color = AgwColors.DesertOchre,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp, start = 20.dp, end = 20.dp)
        )
    }
}
