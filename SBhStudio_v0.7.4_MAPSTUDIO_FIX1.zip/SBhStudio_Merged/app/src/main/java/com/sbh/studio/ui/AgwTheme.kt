package com.sbh.studio.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Palette SBh-AGW — arabo-gothique */
object AgwColors {
    val NightStone = Color(0xFF2B2620)
    val DesertOchre = Color(0xFF8C6A3F)
    val SacredGold = Color(0xFFC9A227)
    val DriedBlood = Color(0xFF6B1E1E)
    val PersianBlue = Color(0xFF1F3A5F)
    val PaleMarble = Color(0xFFD8CBB0)
    val Sand = Color(0xFFE8D5A3)
    val DeepNight = Color(0xFF1A1612)
    val GoldSoft = Color(0xFFE8C84A)
}

private val DarkScheme = darkColorScheme(
    primary = AgwColors.SacredGold,
    onPrimary = AgwColors.DeepNight,
    secondary = AgwColors.DesertOchre,
    onSecondary = AgwColors.PaleMarble,
    tertiary = AgwColors.PersianBlue,
    background = AgwColors.DeepNight,
    onBackground = AgwColors.PaleMarble,
    surface = AgwColors.NightStone,
    onSurface = AgwColors.PaleMarble,
    surfaceVariant = Color(0xFF3A342C),
    onSurfaceVariant = AgwColors.Sand,
    error = AgwColors.DriedBlood,
    primaryContainer = Color(0xFF4A3A12),
    onPrimaryContainer = AgwColors.GoldSoft
)

private val LightScheme = lightColorScheme(
    primary = AgwColors.DesertOchre,
    onPrimary = Color.White,
    secondary = AgwColors.PersianBlue,
    background = AgwColors.PaleMarble,
    onBackground = AgwColors.NightStone,
    surface = Color(0xFFF5EDE0),
    onSurface = AgwColors.NightStone,
    primaryContainer = AgwColors.Sand,
    onPrimaryContainer = AgwColors.NightStone
)

@Composable
fun AgwTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        content = content
    )
}
