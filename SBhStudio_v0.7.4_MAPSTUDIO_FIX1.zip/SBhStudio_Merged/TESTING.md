# SBh Studio 0.7.4 — plan de tests

## État A — fonctionnement correct
1. Créer un projet.
2. Ajouter 1 mob, 1 item et 1 bloc.
3. Exporter deux fois le même projet.
4. Vérifier que le `.mcaddon` contient deux `.mcpack` : BP et RP.
5. Ouvrir les `.mcpack` et vérifier `manifest.json`.
6. Vérifier que les UUID restent identiques entre les deux exports.
7. Importer le `.mcaddon` dans Minecraft Bedrock 1.21.132.1.
8. Ouvrir Map Studio, charger les régions et tester rotation/sélection/export.

## État B — défaillance volontaire
- Modifier manuellement le certificat de signature d'un APK de test : l'installation de mise à jour doit être refusée.
- Modifier le SHA-256 attendu dans le body `version.json` : le téléchargement doit être rejeté avant installation.
- Supprimer `manifest.json` d'un pack de test : la validation doit signaler l'erreur.
- Fournir un identifiant `bad id` : la validation doit le refuser.

## État C — intermédiaire
- Pack avec mob valide mais texture absente.
- Pack avec plusieurs contenus mais un seul champ invalide.
- Map Studio avec fichier de régions absent ou JSON partiellement invalide.
- APK téléchargé correctement mais autorisation d'installation inconnue non accordée : l'application doit ouvrir le réglage Android correspondant sans lancer une installation non vérifiée.

## Validation finale sur appareil
- Android 14/15 réel.
- Build Debug puis Release signé.
- Import/export `.mcaddon`.
- Installation depuis Minecraft.
- Rotation/navigation sans perte des champs importants.
- Mise à jour depuis une Release GitHub signée avec la même clé.
