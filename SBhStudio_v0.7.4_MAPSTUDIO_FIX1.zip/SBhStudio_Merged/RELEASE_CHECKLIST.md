# SBh Studio 0.7.4 — release checklist

## GitHub Actions
Create these repository secrets before a Release build:

- `SBH_KEYSTORE_B64`: base64 du keystore de publication
- `SBH_KEYSTORE_PASSWORD`: mot de passe du keystore
- `SBH_KEY_ALIAS`: alias de la clé
- `SBH_KEY_PASSWORD`: mot de passe de la clé

La clé privée ne doit jamais être commitée dans Git.

## Build

1. Push sur `main`/`master` ou lancer `workflow_dispatch`.
2. Vérifier `assembleRelease`.
3. Vérifier l'artefact APK.
4. Vérifier que le SHA-256 publié correspond à l'APK.
5. Vérifier que la Release contient l'APK et `version-0.7.4.json`.

## Téléphone

1. Installer la première version signée.
2. Activer l'autorisation d'installation d'applications inconnues pour SBh Studio si Android la demande.
3. Vérifier une mise à jour vers un `versionCode` supérieur.
4. Vérifier qu'un APK signé avec une autre clé est refusé.
5. Vérifier qu'un APK dont le SHA-256 ne correspond pas au manifeste de release est refusé.
6. Tester import/export Minecraft Bedrock.
7. Tester Map Studio.
