# SBh Studio 0.6.1

SBh Studio est un atelier Android orienté Minecraft Bedrock.

## Fonctionnalités
- projets sauvegardés avec écritures atomiques ;
- créatures, items et blocs configurables ;
- sélection de textures depuis le téléphone ;
- validation avant génération ;
- génération de structures Behavior Pack / Resource Pack ;
- export `.mcaddon` ;
- Mine Edit avec deux positions, normalisation, calcul du volume et confirmation avant opération ;
- système de mise à jour GitHub / APK.

## Limites volontairement conservées
Mine Edit prépare encore les opérations de monde mais ne modifie pas directement un monde Bedrock dans cette version. La génération Bedrock est une base automatisée et doit être testée sur la version Minecraft cible avant distribution.

## Tests
Le projet distingue les flux normaux, les entrées invalides et les opérations destructives protégées par confirmation.
