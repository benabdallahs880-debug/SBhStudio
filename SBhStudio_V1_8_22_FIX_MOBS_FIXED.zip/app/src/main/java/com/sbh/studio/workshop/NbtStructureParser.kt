package com.sbh.studio.workshop

import java.io.ByteArrayInputStream
import java.io.DataInputStream
import java.io.InputStream
import java.util.zip.GZIPInputStream

/**
 * Parseur NBT minimal orienté structures Minecraft (.nbt / .nbt.gz).
 * Supporte les tags nécessaires aux fichiers de structure :
 * size (IntArray), palette (List<Compound>), blocks (List<Compound>), entities.
 *
 * Pas de dépendance externe. Compatible Android.
 */
object NbtStructureParser {

    // ── Types NBT ──────────────────────────────────────────────────────────
    private const val TAG_END = 0
    private const val TAG_BYTE = 1
    private const val TAG_SHORT = 2
    private const val TAG_INT = 3
    private const val TAG_LONG = 4
    private const val TAG_FLOAT = 5
    private const val TAG_DOUBLE = 6
    private const val TAG_BYTE_ARRAY = 7
    private const val TAG_STRING = 8
    private const val TAG_LIST = 9
    private const val TAG_COMPOUND = 10
    private const val TAG_INT_ARRAY = 11
    private const val TAG_LONG_ARRAY = 12

    sealed class NbtValue {
        data class ByteVal(val v: Byte) : NbtValue()
        data class ShortVal(val v: Short) : NbtValue()
        data class IntVal(val v: Int) : NbtValue()
        data class LongVal(val v: Long) : NbtValue()
        data class FloatVal(val v: Float) : NbtValue()
        data class DoubleVal(val v: Double) : NbtValue()
        data class ByteArrayVal(val v: ByteArray) : NbtValue()
        data class StringVal(val v: String) : NbtValue()
        data class ListVal(val elementType: Int, val v: List<NbtValue>) : NbtValue()
        data class CompoundVal(val v: Map<String, NbtValue>) : NbtValue()
        data class IntArrayVal(val v: IntArray) : NbtValue()
        data class LongArrayVal(val v: LongArray) : NbtValue()
    }

    // ── API publique ───────────────────────────────────────────────────────

    /**
     * Parse un fichier de structure Minecraft (gzip ou brut).
     * Retourne une StructureLoader.StructureDef prête à l'emploi, ou null si invalide.
     */
    fun parseStructure(bytes: ByteArray, fallbackName: String = "Structure importée"): StructureLoader.StructureDef? {
        return try {
            val root = parseRoot(bytes) ?: return null
            convertToStructureDef(root, fallbackName)
        } catch (_: Exception) {
            null
        }
    }

    fun parseStructure(stream: InputStream, fallbackName: String = "Structure importée"): StructureLoader.StructureDef? {
        return try {
            parseStructure(stream.readBytes(), fallbackName)
        } catch (_: Exception) {
            null
        }
    }

    // ── Parsing bas niveau ─────────────────────────────────────────────────

    private fun parseRoot(bytes: ByteArray): Map<String, NbtValue>? {
        // Détecte gzip (magic 1f 8b)
        val input = if (bytes.size >= 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()) {
            GZIPInputStream(ByteArrayInputStream(bytes))
        } else {
            ByteArrayInputStream(bytes)
        }
        DataInputStream(input).use { dis ->
            val type = dis.readUnsignedByte()
            if (type != TAG_COMPOUND) return null
            // Nom de la racine (souvent vide pour les structures)
            readString(dis)
            return readCompound(dis)
        }
    }

    private fun readString(dis: DataInputStream): String {
        val len = dis.readUnsignedShort()
        if (len == 0) return ""
        val buf = ByteArray(len)
        dis.readFully(buf)
        return String(buf, Charsets.UTF_8)
    }

    private fun readCompound(dis: DataInputStream): Map<String, NbtValue> {
        val map = linkedMapOf<String, NbtValue>()
        while (true) {
            val type = dis.readUnsignedByte()
            if (type == TAG_END) break
            val name = readString(dis)
            map[name] = readPayload(dis, type)
        }
        return map
    }

    private fun readPayload(dis: DataInputStream, type: Int): NbtValue {
        return when (type) {
            TAG_BYTE -> NbtValue.ByteVal(dis.readByte())
            TAG_SHORT -> NbtValue.ShortVal(dis.readShort())
            TAG_INT -> NbtValue.IntVal(dis.readInt())
            TAG_LONG -> NbtValue.LongVal(dis.readLong())
            TAG_FLOAT -> NbtValue.FloatVal(dis.readFloat())
            TAG_DOUBLE -> NbtValue.DoubleVal(dis.readDouble())
            TAG_BYTE_ARRAY -> {
                val len = dis.readInt()
                val arr = ByteArray(len)
                dis.readFully(arr)
                NbtValue.ByteArrayVal(arr)
            }
            TAG_STRING -> NbtValue.StringVal(readString(dis))
            TAG_LIST -> {
                val elemType = dis.readUnsignedByte()
                val len = dis.readInt()
                val list = ArrayList<NbtValue>(len.coerceAtLeast(0))
                repeat(len) { list.add(readPayload(dis, elemType)) }
                NbtValue.ListVal(elemType, list)
            }
            TAG_COMPOUND -> NbtValue.CompoundVal(readCompound(dis))
            TAG_INT_ARRAY -> {
                val len = dis.readInt()
                val arr = IntArray(len) { dis.readInt() }
                NbtValue.IntArrayVal(arr)
            }
            TAG_LONG_ARRAY -> {
                val len = dis.readInt()
                val arr = LongArray(len) { dis.readLong() }
                NbtValue.LongArrayVal(arr)
            }
            else -> throw IllegalArgumentException("Tag NBT inconnu: $type")
        }
    }

    // ── Conversion vers StructureDef ───────────────────────────────────────

    private fun convertToStructureDef(root: Map<String, NbtValue>, fallbackName: String): StructureLoader.StructureDef? {
        val sizeArr = (root["size"] as? NbtValue.IntArrayVal)?.v
            ?: return null
        if (sizeArr.size < 3) return null

        val sizeX = sizeArr[0]
        val sizeY = sizeArr[1]
        val sizeZ = sizeArr[2]

        // Palette
        val paletteList = (root["palette"] as? NbtValue.ListVal)?.v ?: emptyList()
        val palette = paletteList.mapNotNull { entry ->
            val compound = (entry as? NbtValue.CompoundVal)?.v ?: return@mapNotNull null
            val name = (compound["Name"] as? NbtValue.StringVal)?.v ?: return@mapNotNull null
            val propsRaw = (compound["Properties"] as? NbtValue.CompoundVal)?.v
            val props = propsRaw?.mapNotNull { (k, v) ->
                val sv = (v as? NbtValue.StringVal)?.v
                if (sv != null) k to sv else null
            }?.toMap()
            StructureLoader.StructureBlockState(Name = name, Properties = props)
        }

        if (palette.isEmpty()) return null

        // Blocks
        val blocksList = (root["blocks"] as? NbtValue.ListVal)?.v ?: emptyList()
        val blocks = blocksList.mapNotNull { entry ->
            val compound = (entry as? NbtValue.CompoundVal)?.v ?: return@mapNotNull null
            val pos = (compound["pos"] as? NbtValue.IntArrayVal)?.v
                ?: (compound["pos"] as? NbtValue.ListVal)?.v?.mapNotNull {
                    (it as? NbtValue.IntVal)?.v
                }?.toIntArray()
            if (pos == null || pos.size < 3) return@mapNotNull null
            val state = when (val s = compound["state"]) {
                is NbtValue.IntVal -> s.v
                is NbtValue.ByteVal -> s.v.toInt()
                is NbtValue.ShortVal -> s.v.toInt()
                else -> return@mapNotNull null
            }
            // On ignore l'air pour alléger
            val blockName = palette.getOrNull(state)?.Name ?: ""
            if (blockName == "minecraft:air" || blockName.endsWith(":air")) return@mapNotNull null
            StructureLoader.StructureBlock(x = pos[0], y = pos[1], z = pos[2], state = state)
        }

        val id = fallbackName
            .lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "structure_import" }

        return StructureLoader.StructureDef(
            id = id,
            name = fallbackName,
            description = "Importée depuis un fichier NBT Minecraft (${sizeX}×${sizeY}×${sizeZ})",
            size = StructureLoader.StructureSize(x = sizeX, y = sizeY, z = sizeZ),
            palette = palette,
            blocks = blocks
        )
    }
}
