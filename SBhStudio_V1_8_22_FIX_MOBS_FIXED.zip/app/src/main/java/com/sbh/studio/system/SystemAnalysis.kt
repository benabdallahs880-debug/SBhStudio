package com.sbh.studio.system

import android.content.Context
import com.sbh.studio.data.AppDiagnostic
import com.sbh.studio.data.DiagItem
import com.sbh.studio.data.DiagStatus
import com.sbh.studio.data.DiagnosticReport
import com.sbh.studio.debug.DebugTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Point d'entrée unique pour analyses / diagnostics SBh Studio.
 * Agrège AppDiagnostic, runtime errors, et contrôles structures / studio_import.
 */
class SystemAnalysis(private val context: Context) {

    private val diagnostic = AppDiagnostic(context)
    private val debugTools = DebugTools(context)

    fun runLocal(): DiagnosticReport {
        val base = diagnostic.runLocal()
        return mergeExtra(base, extraLocalChecks())
    }

    suspend fun runFull(): DiagnosticReport = withContext(Dispatchers.IO) {
        val base = diagnostic.runFull()
        mergeExtra(base, extraLocalChecks() + extraStructureChecks())
    }

    fun identitySummary(): String {
        val id = diagnostic.identity()
        return "${id.packageName} v${id.versionName} (${id.versionCode})"
    }

    fun lastRuntimeError() = debugTools.lastError()

    fun recentEvents(limit: Int = 40) = debugTools.recentEvents(limit)

    fun storageSnapshot() = debugTools.listStorage(2)

    fun unlockStatus(): String {
        return if (SystemUnlock.isUnlocked(context)) {
            val src = SystemUnlock.unlockSource(context)
            val at = SystemUnlock.unlockedAtMs(context)
            "Débloqué (source=$src, at=$at)"
        } else {
            "Verrouillé"
        }
    }

    /** Rapport texte prêt à partager. */
    fun toShareText(report: DiagnosticReport): String = buildString {
        appendLine("SBh Studio — Analyse système")
        appendLine(identitySummary())
        appendLine("Unlock: ${unlockStatus()}")
        appendLine("OK=${report.okCount} WARN=${report.warnCount} FAIL=${report.failCount}")
        appendLine("---")
        report.items.forEach { item ->
            appendLine("[${item.status}] ${item.category} · ${item.title}: ${item.detail}")
        }
    }

    private fun extraLocalChecks(): List<DiagItem> {
        val items = mutableListOf<DiagItem>()
        // Unlock
        items += DiagItem(
            id = "system_unlock",
            title = "Déblocage fonctions avancées",
            category = "système",
            status = if (SystemUnlock.isUnlocked(context)) DiagStatus.OK else DiagStatus.WARN,
            detail = unlockStatus()
        )
        // studio_import
        val dirs = SystemPaths.allStudioImportDirs(context)
        val anyPlacements = dirs.any { SystemPaths.placementsFile(it).exists() }
        items += DiagItem(
            id = "studio_import",
            title = "Export scène jouable (studio_import)",
            category = "données",
            status = when {
                anyPlacements -> DiagStatus.OK
                dirs.isNotEmpty() -> DiagStatus.WARN
                else -> DiagStatus.FAIL
            },
            detail = if (anyPlacements) {
                val paths = dirs.filter { SystemPaths.placementsFile(it).exists() }
                    .joinToString { it.absolutePath }
                "placements.json présent: $paths"
            } else {
                "Aucun placements.json — lancer ▶ Tester le village forge"
            }
        )
        return items
    }

    private fun extraStructureChecks(): List<DiagItem> {
        val items = mutableListOf<DiagItem>()
        val assetOk = try {
            context.assets.open(SystemPaths.ASSET_FORGE_STRUCTURE).use { it.read() >= 0 }
            true
        } catch (_: Exception) {
            false
        }
        items += DiagItem(
            id = "asset_forge",
            title = "Asset structure Maison de forgeron",
            category = "module",
            status = if (assetOk) DiagStatus.OK else DiagStatus.FAIL,
            detail = if (assetOk) SystemPaths.ASSET_FORGE_STRUCTURE else "Asset manquant dans l'APK"
        )
        return items
    }

    private fun mergeExtra(base: DiagnosticReport, extra: List<DiagItem>): DiagnosticReport {
        val items = base.items + extra
        return base.copy(
            items = items,
            okCount = items.count { it.status == DiagStatus.OK },
            warnCount = items.count { it.status == DiagStatus.WARN },
            failCount = items.count { it.status == DiagStatus.FAIL }
        )
    }
}
