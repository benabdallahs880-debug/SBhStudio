package com.sbh.studio.workshop

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

private val edJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

/** Forme de base de l'Éditeur 3D. */
enum class EditorKind(val label: String) {
    CUBE("Cube"), SPHERE("Sphère"), CYLINDER("Cylindre")
}

/**
 * Objet de la scène de l'Éditeur 3D plein écran.
 * Unité = mètre. (x, y, z) = position de la base de l'objet ; y = hauteur au-dessus du sol.
 * hue < 0 = gris neutre, sinon teinte 0..360.
 */
@Serializable
data class EditorObject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String = EditorKind.CUBE.name,
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f,
    val rotY: Float = 0f,
    val scale: Float = 1f,
    val hue: Float = -1f
)

/** Persistance locale : une scène par projet, écriture atomique. */
class Editor3DRepository(private val context: Context) {
    private fun file(projectId: String): File {
        val safe = projectId.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.ifBlank { "default" }
        return File(context.filesDir, "sbh_editor3d_$safe.json")
    }

    /** null = jamais sauvegardée (première ouverture) ; liste vide = scène vidée volontairement. */
    fun load(projectId: String): List<EditorObject>? = try {
        val f = file(projectId)
        if (!f.exists()) null else edJson.decodeFromString<List<EditorObject>>(f.readText())
    } catch (_: Exception) {
        null
    }

    fun save(projectId: String, list: List<EditorObject>) {
        try {
            val f = file(projectId)
            val tmp = File(f.parentFile, "${f.name}.tmp")
            tmp.writeText(edJson.encodeToString(list))
            if (!tmp.renameTo(f)) {
                f.delete()
                tmp.renameTo(f)
            }
        } catch (_: Exception) {
        }
    }
}
