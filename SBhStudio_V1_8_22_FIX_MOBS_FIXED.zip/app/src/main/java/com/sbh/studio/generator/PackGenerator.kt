package com.sbh.studio.generator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import com.sbh.studio.data.Identifiers
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.workshop.PortalBlueprint
import com.sbh.studio.texture.TextureLink
import com.sbh.studio.animation.AnimationRepository
import com.sbh.studio.animation.AnimationExport
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObjectBuilder
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/**
 * Générateur de structure Bedrock BP/RP et export .mcaddon.
 *
 * Les composants générés suivent ceux que la « fondation » (foundation/) utilise déjà :
 * avant, ce générateur (celui de l'export projet) produisait des créatures sans déplacement
 * ni rendu, des items sans icône ni dégâts et des blocs sans texture reliée.
 */
class PackGenerator(private val context: Context) {

    data class ExportResult(val file: File, val warnings: List<String>)

    fun validate(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint> = emptyList()
    ): List<String> {
        val errors = mutableListOf<String>()
        if (project.name.isBlank()) errors += "Le projet doit avoir un nom."

        mobs.forEach { m -> Identifiers.explain(m.identifiant)?.let { errors += "Créature « ${m.nom} » : $it (${m.identifiant})" } }
        items.forEach { i -> Identifiers.explain(i.identifier)?.let { errors += "Item « ${i.name} » : $it (${i.identifier})" } }
        blocks.forEach { b -> Identifiers.explain(b.identifier)?.let { errors += "Bloc « ${b.name} » : $it (${b.identifier})" } }
        portals.forEach { p -> Identifiers.explain(p.identifier)?.let { errors += "Portail « ${p.name} » : $it (${p.identifier})" } }

        mobs.filter { it.vie <= 0 || it.degats < 0 || it.vitesse <= 0 }
            .forEach { errors += "Créature « ${it.nom} » : vie, dégâts ou vitesse invalides." }
        items.filter { it.damage < 0 || it.durability <= 0 }
            .forEach { errors += "Item « ${it.name} » : dégâts ou durabilité invalides." }
        blocks.filter { it.hardness < 0 }
            .forEach { errors += "Bloc « ${it.name} » : résistance négative." }

        // Deux identifiants d'espaces différents mais de même nom technique (agw:roi / sbh:roi) écriraient
        // le même fichier dans le pack ; auparavant l'export échouait avec une erreur de zip cryptique.
        fun collisions(kind: String, ids: List<String>) {
            ids.filter { Identifiers.isValid(it) }
                .groupBy { Identifiers.nameOf(it) }
                .filter { it.value.size > 1 }
                .forEach { (name, list) -> errors += "$kind : le nom technique « $name » est partagé par ${list.joinToString()}." }
            ids.filter { Identifiers.isValid(it) }
                .groupBy { textureKey(it) }
                .filter { it.value.size > 1 }
                .forEach { (key, list) -> errors += "$kind : la clé de texture « $key » est partagée par ${list.joinToString()}." }
        }
        collisions("Créatures", mobs.map { it.identifiant })
        collisions("Items", items.map { it.identifier })
        collisions("Blocs et portails", blocks.map { it.identifier } + portals.map { it.identifier })
        return errors.distinct()
    }

    fun export(project: SbhProject, mobs: List<MobEntity>, items: List<SbhItem>, blocks: List<SbhBlock>): File =
        export(project, mobs, items, blocks, emptyMap())

    fun export(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        extraFiles: Map<String, String>
    ): File = exportDetailed(project, mobs, items, blocks, emptyList(), extraFiles).file

    /**
     * Produit un vrai .mcaddon : deux .mcpack internes (BP + RP).
     * Les UUID de pack/module sont persistants par projet afin d'éviter de casser
     * les dépendances Minecraft à chaque export.
     *
     * [extraBinaryFiles] : fichiers binaires supplémentaires (chemin préfixé « BP/ » ou « RP/ »).
     */
    fun exportDetailed(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint>,
        extraFiles: Map<String, String>,
        extraBinaryFiles: Map<String, ByteArray> = emptyMap()
    ): ExportResult {
        val errors = validate(project, mobs, items, blocks, portals)
        require(errors.isEmpty()) { errors.joinToString("\n") }

        val warnings = mutableListOf<String>()
        val content = Content(project, mobs, items, blocks, portals)
        val bpName = "SBh_${safe(project.name)}_BP"
        val rpName = "SBh_${safe(project.name)}_RP"
        val ids = loadPackIds(project.id)
        val scriptModuleUuid = if (portals.isNotEmpty()) ids.bpScriptModuleUuid else null
        val bpPack = zipPack(bpName, "data", ids.bpUuid, ids.bpModuleUuid, content, extraFiles, extraBinaryFiles, true, null, warnings, scriptModuleUuid)
        val rpPack = zipPack(rpName, "resources", ids.rpUuid, ids.rpModuleUuid, content, extraFiles, extraBinaryFiles, false, ids.bpUuid, warnings, null)

        val out = File(context.cacheDir, "${safe(project.name)}-${project.version}.mcaddon")
        ZipOutputStream(out.outputStream().buffered()).use { addon ->
            val w = EntryWriter(addon)
            w.bytes("$bpName.mcpack", bpPack)
            w.bytes("$rpName.mcpack", rpPack)
            w.text("README.txt", "SBh Studio ${project.version}\nPack BP + RP généré pour Minecraft Bedrock.\n")
        }
        return ExportResult(out, warnings.distinct())
    }

    private class Content(
        val project: SbhProject,
        val mobs: List<MobEntity>,
        val items: List<SbhItem>,
        val blocks: List<SbhBlock>,
        val portals: List<PortalBlueprint>
    )

    /** Écrit dans un zip en ignorant un chemin déjà écrit (un doublon ferait échouer tout l'export). */
    private class EntryWriter(private val zip: ZipOutputStream) {
        private val seen = HashSet<String>()
        fun text(path: String, content: String) = bytes(path, content.toByteArray(Charsets.UTF_8))
        fun bytes(path: String, data: ByteArray) {
            if (!seen.add(path)) return
            zip.putNextEntry(ZipEntry(path))
            zip.write(data)
            zip.closeEntry()
        }
    }

    private data class PackIds(
        val bpUuid: String,
        val bpModuleUuid: String,
        val rpUuid: String,
        val rpModuleUuid: String,
        // Module de script BP (téléportation des portails). Séparé du module "data"
        // ci-dessus ; persistant pour ne pas casser le pack à chaque export.
        val bpScriptModuleUuid: String
    )

    private fun loadPackIds(projectId: String): PackIds {
        val file = File(context.filesDir, "sbh_pack_ids_${safe(projectId)}.json")
        val existing = runCatching {
            if (!file.exists()) null else Json.parseToJsonElement(file.readText()).jsonObject
        }.getOrNull()
        fun stored(key: String): String? = existing?.get(key)?.jsonPrimitive?.content?.takeIf { it.isNotBlank() }
        val ids = PackIds(
            stored("bp") ?: java.util.UUID.randomUUID().toString(),
            stored("bpModule") ?: java.util.UUID.randomUUID().toString(),
            stored("rp") ?: java.util.UUID.randomUUID().toString(),
            stored("rpModule") ?: java.util.UUID.randomUUID().toString(),
            stored("bpScriptModule") ?: java.util.UUID.randomUUID().toString()
        )
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, "${file.name}.tmp")
        tmp.writeText(buildJsonObject {
            put("bp", ids.bpUuid); put("bpModule", ids.bpModuleUuid)
            put("rp", ids.rpUuid); put("rpModule", ids.rpModuleUuid)
            put("bpScriptModule", ids.bpScriptModuleUuid)
        }.toString())
        if (!tmp.renameTo(file)) { file.delete(); require(tmp.renameTo(file)) { "Impossible d'enregistrer les UUID de packs" } }
        return ids
    }

    private fun zipPack(
        name: String, type: String, uuid: String, moduleUuid: String,
        c: Content,
        extraFiles: Map<String, String>,
        extraBinaryFiles: Map<String, ByteArray>,
        isBp: Boolean,
        dependencyUuid: String?,
        warnings: MutableList<String>,
        scriptModuleUuid: String? = null
    ): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            val w = EntryWriter(zip)
            w.text("manifest.json", manifest(name, type, uuid, moduleUuid, c.project.version, dependencyUuid, scriptModuleUuid))
            if (isBp && scriptModuleUuid != null && c.portals.isNotEmpty()) {
                w.text("scripts/main.js", portalScriptJs(c.portals))
            }
            if (isBp) {
                c.mobs.forEach { mob ->
                    val (ns, id) = splitId(mob.identifiant)
                    w.text("entities/$id.json", mobJson(mob, ns, id))
                }
                c.items.forEach { item ->
                    val (ns, id) = splitId(item.identifier)
                    w.text("items/$id.json", itemJson(item, ns, id))
                }
                c.blocks.forEach { block ->
                    val (ns, id) = splitId(block.identifier)
                    w.text("blocks/$id.json", blockJson(ns, id, block.hardness, null))
                }
                c.portals.forEach { portal ->
                    val (ns, id) = splitId(portal.identifier)
                    w.text("blocks/$id.json", blockJson(ns, id, 2.0, 8))
                }
            } else {
                // Correctif critique : le client_entity de chaque mob référence
                // "controller.render.default" (ligne resourceEntityJson) mais ce contrôleur
                // n'était jamais défini nulle part dans le Resource Pack — sans lui, Minecraft
                // ne sait pas quel geometry/texture/material associer et le mob reste invisible
                // en jeu, quelle que soit la texture ou la géométrie choisies.
                if (c.mobs.isNotEmpty()) {
                    w.text("render_controllers/sbh_default.render_controllers.json", defaultRenderControllerJson())
                }
                if (c.items.isNotEmpty()) {
                    w.text("textures/item_texture.json", textureAtlasJson("atlas.items", "textures/items", c.items.map { textureKey(it.identifier) }))
                }
                val terrainKeys = c.blocks.map { textureKey(it.identifier) } + c.portals.map { textureKey(it.identifier) }
                if (terrainKeys.isNotEmpty()) {
                    w.text("textures/terrain_texture.json", textureAtlasJson("atlas.terrain", "textures/blocks", terrainKeys))
                }
                val animRepo = AnimationRepository(context)
                val animProjects = animRepo.loadAll()
                c.mobs.forEach { mob ->
                    val (ns, id) = splitId(mob.identifiant)
                    val key = textureKey(mob.identifiant)
                    val linkedAnim = animProjects.firstOrNull { it.linkedMobId == mob.id || it.linkedMobIdentifier == mob.identifiant }
                    w.text("entity/$id.entity.json", resourceEntityJson(mob, ns, id, key, linkedAnim != null))
                    w.bytes("textures/entity/$key.png", normalizeMobSkin(mob.textureUri, mob.nom, key, warnings))
                    if (linkedAnim != null) {
                        w.text("animations/${id}.animation.json", AnimationExport.animationJson(linkedAnim, mob.identifiant))
                        w.text("animation_controllers/${id}.controller.json", AnimationExport.controllerJson(mob.identifiant))
                    }
                }
                c.items.forEach { item ->
                    val key = textureKey(item.identifier)
                    w.bytes("textures/items/$key.png", textureBytes(item.textureUri, 16, item.name, key, warnings))
                }
                c.blocks.forEach { block ->
                    val key = textureKey(block.identifier)
                    w.bytes("textures/blocks/$key.png", textureBytes(block.textureUri, 16, block.name, key, warnings))
                }
                c.portals.forEach { portal ->
                    val key = textureKey(portal.identifier)
                    w.bytes("textures/blocks/$key.png", textureBytes(null, 16, portal.name, key, warnings))
                }
            }
            val prefix = if (isBp) "BP/" else "RP/"
            extraFiles.forEach { (path, content) ->
                if (path.startsWith(prefix)) w.text(path.removePrefix(prefix), content)
            }
            extraBinaryFiles.forEach { (path, data) ->
                if (path.startsWith(prefix)) w.bytes(path.removePrefix(prefix), data)
            }
            if (!isBp) w.text("README.txt", "SBh Studio ${c.project.version} — Resource Pack")
        }
        return out.toByteArray()
    }

    /**
     * [scriptModuleUuid] : si non nul, ajoute un module "script" (téléportation des portails,
     * scripts/main.js) et sa dépendance @minecraft/server — uniquement sur le manifest BP,
     * et seulement quand le projet contient au moins un portail.
     */
    private fun manifest(
        name: String, type: String, uuid: String, moduleUuid: String, versionName: String,
        dependencyUuid: String?, scriptModuleUuid: String? = null
    ): String = buildJsonObject {
        put("format_version", 2)
        putJsonObject("header") {
            put("name", name)
            put("description", "Generated by SBh Studio")
            put("uuid", uuid)
            put("version", versionArray(versionName))
            putJsonArray("min_engine_version") { add(1); add(21); add(0) }
        }
        putJsonArray("modules") {
            add(buildJsonObject {
                put("type", type)
                put("uuid", moduleUuid)
                put("version", versionArray(versionName))
            })
            if (scriptModuleUuid != null) add(buildJsonObject {
                put("type", "script")
                put("language", "javascript")
                put("uuid", scriptModuleUuid)
                put("entry", "scripts/main.js")
                put("version", versionArray(versionName))
            })
        }
        if (dependencyUuid != null || scriptModuleUuid != null) putJsonArray("dependencies") {
            if (dependencyUuid != null) add(buildJsonObject {
                put("uuid", dependencyUuid)
                put("version", versionArray(versionName))
            })
            // Version stable de @minecraft/server compatible avec le moteur 1.21.x ciblé par SBh Studio.
            if (scriptModuleUuid != null) add(buildJsonObject {
                put("module_name", "@minecraft/server")
                put("version", "1.17.0")
            })
        }
    }.toString()

    private fun versionArray(value: String) = buildJsonArray {
        val parts = value.split('.').take(3).map { it.toIntOrNull() ?: 0 }
        parts.forEach { add(it) }
        repeat((3 - parts.size).coerceAtLeast(0)) { add(0) }
    }

    // ── Textures ──────────────────────────────────────────────────────────

    /**
     * Texture fournie par l'utilisateur (ré-encodée en vrai PNG : le sélecteur accepte aussi les JPEG,
     * qui étaient auparavant copiés tels quels sous une extension .png), sinon texture provisoire.
     * Auparavant une texture absente ou illisible était ignorée sans rien dire et le jeu affichait
     * la texture « manquante » violette et noire.
     */
    private fun textureBytes(uri: String?, size: Int, label: String, key: String, warnings: MutableList<String>): ByteArray {
        if (uri != null) {
            val png = loadPng(uri)
            if (png != null) return png
            warnings += "Texture illisible pour « $label » (fichier déplacé ou supprimé ?) — texture provisoire utilisée."
        }
        return placeholderPng(size, key)
    }

    /**
     * Correctif critique : tant que chaque mob n'a pas sa propre géométrie 3D (étape suivante,
     * pont Character Studio → Mob Editor), tous les mobs utilisent le corps humanoid vanilla, qui
     * exige un skin 64x64. Avant ce correctif, l'image choisie par l'utilisateur était envoyée
     * telle quelle, quelle que soit sa taille : Minecraft l'étirait ou la coupait au chargement,
     * donnant un mob visuellement cassé en jeu (pas juste « moche à l'aperçu »).
     *
     * Ici on redimensionne l'image en conservant ses proportions (pas d'étirement), on la centre
     * sur un canevas 64x64 transparent, et on prévient l'utilisateur par un avertissement que la
     * forme reste celle d'un humanoïde tant que la géométrie personnalisée n'est pas branchée.
     */
    private fun normalizeMobSkin(uri: String?, label: String, key: String, warnings: MutableList<String>): ByteArray {
        val raw = uri?.let { loadPng(it) }
        val src = raw?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size) }.getOrNull() }
        if (uri != null && src == null) {
            warnings += "Texture illisible pour « $label » (fichier déplacé ou supprimé ?) — texture provisoire utilisée."
        }
        if (src == null) return placeholderPng(64, key)

        val target = 64
        if (src.width != target || src.height != target) {
            warnings += "Texture « $label » redimensionnée en ${target}x${target} (taille d'origine ${src.width}x${src.height}). " +
                "Ce mob utilise encore un corps humanoïde standard : la texture peut ne pas correspondre parfaitement " +
                "à une créature à la forme différente tant que sa géométrie personnalisée n'est pas ajoutée."
        }
        val scale = minOf(target.toFloat() / src.width, target.toFloat() / src.height)
        val w = (src.width * scale).roundToInt().coerceIn(1, target)
        val h = (src.height * scale).roundToInt().coerceIn(1, target)
        // filter=false : mise à l'échelle « pixel art », sans flou, cohérente avec le style des skins Minecraft.
        val scaled = Bitmap.createScaledBitmap(src, w, h, false)
        val canvas = Bitmap.createBitmap(target, target, Bitmap.Config.ARGB_8888)
        Canvas(canvas).drawBitmap(scaled, ((target - w) / 2).toFloat(), ((target - h) / 2).toFloat(), null)

        val out = ByteArrayOutputStream()
        canvas.compress(Bitmap.CompressFormat.PNG, 100, out)
        src.recycle()
        if (scaled !== src) scaled.recycle()
        canvas.recycle()
        return out.toByteArray()
    }

    private fun loadPng(uriString: String): ByteArray? {
        // Textures créées dans le Studio Texture (sbhtex://id)
        if (TextureLink.isStudioUri(uriString)) {
            return TextureLink.loadPngBytes(context, uriString)
        }
        return try {
        val uri = Uri.parse(uriString)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            null
        } else {
            var sample = 1
            while (bounds.outWidth / sample > MAX_TEXTURE || bounds.outHeight / sample > MAX_TEXTURE) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp == null) {
                null
            } else {
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                bmp.recycle()
                out.toByteArray()
            }
        }
    } catch (_: Exception) {
        null
    }
    }

    private fun placeholderPng(size: Int, seed: String): ByteArray {
        val hash = seed.hashCode()
        val base = Color.HSVToColor(floatArrayOf(((hash and 0x7fffffff) % 360).toFloat(), 0.35f, 0.55f))
        val rnd = Random(hash)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (y in 0 until size) for (x in 0 until size) {
            val v = rnd.nextInt(31) - 15
            bmp.setPixel(x, y, Color.rgb(clamp(Color.red(base) + v), clamp(Color.green(base) + v), clamp(Color.blue(base) + v)))
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return out.toByteArray()
    }

    private fun clamp(v: Int) = v.coerceIn(0, 255)

    private fun eggColor(seed: String, value: Float): String {
        val rgb = Color.HSVToColor(floatArrayOf(((seed.hashCode() and 0x7fffffff) % 360).toFloat(), 0.45f, value)) and 0xFFFFFF
        return String.format("#%06X", rgb)
    }

    private fun textureAtlasJson(atlas: String, dir: String, keys: List<String>): String = buildJsonObject {
        put("resource_pack_name", "vanilla")
        put("texture_name", atlas)
        putJsonObject("texture_data") {
            keys.distinct().forEach { key -> putJsonObject(key) { put("textures", "$dir/$key") } }
        }
    }.toString()

    /** Échappe une chaîne pour un littéral JS/JSON double-quoté. */
    private fun jsString(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    /**
     * Script BP qui rend les portails réellement fonctionnels : avant, un portail n'était
     * qu'un bloc décoratif (lumineux) sans aucun effet — ce script téléporte le joueur qui
     * marche dessus vers les coordonnées choisies dans l'Atelier, avec un cooldown pour éviter
     * les allers-retours en boucle entre deux portails proches.
     */
    private fun portalScriptJs(portals: List<PortalBlueprint>): String {
        val entries = portals.joinToString(",\n") { p ->
            val (ns, id) = splitId(p.identifier)
            val typeId = jsString("$ns:$id")
            val dim = jsString(p.destDimension)
            "  ${typeId}: { x: ${p.destX}, y: ${p.destY}, z: ${p.destZ}, dimension: $dim }"
        }
        return """
            |import { world, system } from "@minecraft/server";
            |
            |// Portails générés par SBh Studio : bloc -> destination.
            |const PORTALS = {
            |$entries
            |};
            |
            |const COOLDOWN_TICKS = 40;
            |const lastTeleport = new Map();
            |
            |system.runInterval(() => {
            |  const now = system.currentTick;
            |  for (const player of world.getPlayers()) {
            |    const last = lastTeleport.get(player.id) ?? -Infinity;
            |    if (now - last < COOLDOWN_TICKS) continue;
            |    let block;
            |    try { block = player.dimension.getBlock(player.location); } catch (e) { continue; }
            |    if (!block) continue;
            |    const dest = PORTALS[block.typeId];
            |    if (!dest) continue;
            |    try {
            |      const targetDimension = world.getDimension(dest.dimension);
            |      player.teleport(
            |        { x: dest.x + 0.5, y: dest.y, z: dest.z + 0.5 },
            |        { dimension: targetDimension }
            |      );
            |      lastTeleport.set(player.id, now);
            |    } catch (e) {
            |      // Dimension ou coordonnées invalides : on ignore plutôt que de faire planter le script.
            |    }
            |  }
            |}, 5);
            |""".trimMargin()
    }

    // ── Contenu Bedrock ───────────────────────────────────────────────────

    private fun mobJson(m: MobEntity, ns: String, id: String): String {
        val speed = ((if (m.pouvoirVitesse) m.vitesse * 1.5 else m.vitesse) * 1000).roundToInt() / 1000.0
        return buildJsonObject {
            put("format_version", "1.21.0")
            putJsonObject("minecraft:entity") {
                putJsonObject("description") {
                    put("identifier", "$ns:$id")
                    put("is_spawnable", true)
                    put("is_summonable", true)
                }
                putJsonObject("components") {
                    putJsonObject("minecraft:type_family") {
                        putJsonArray("family") {
                            if (m.hostile) { add("monster"); add("sbh_hostile") } else add("sbh_creature")
                            add("mob")
                            if (m.faction.isNotBlank() && m.faction != "neutre") add("sbh_faction_${safe(m.faction)}")
                        }
                    }
                    putJsonObject("minecraft:health") { put("value", m.vie); put("max", m.vie) }
                    putJsonObject("minecraft:movement") { put("value", speed) }
                    // Réglages Atelier V0.8 : résistance, invisibilité et collision ne sont plus
                    // des champs décoratifs, ils sont réellement traduits dans l'entité Bedrock.
                    if (m.pouvoirResistance) putJsonObject("minecraft:damage_sensor") {
                        putJsonArray("triggers") {
                            add(buildJsonObject {
                                put("cause", "all")
                                putJsonObject("deals_damage") { put("value", false) }
                            })
                        }
                    }
                    if (m.pouvoirInvisibilite) putJsonObject("minecraft:spell_effects") {
                        putJsonArray("add_effects") {
                            add(buildJsonObject { put("effect", "invisibility"); put("duration", 2147483647); put("amplifier", 0); put("visible", false) })
                        }
                    }
                    // Sans ces composants (repris de la fondation), la créature ne marchait pas,
                    // ne tombait pas et n'avait aucune collision.
                    // Correctif : "minecraft:can_climb" était ajouté sans condition à TOUTES les
                    // créatures — même un simple scorpion grimpait aux murs comme une araignée,
                    // sans qu'aucun réglage ne permette de le désactiver. Retiré par défaut ;
                    // reviendra comme vraie option cochable à l'étape "comportements avancés".
                    putJsonObject("minecraft:navigation.walk") { put("can_path_over_water", false) }
                    putJsonObject("minecraft:movement.basic") {}
                    putJsonObject("minecraft:jump.static") {}
                    putJsonObject("minecraft:physics") {}
                    putJsonObject("minecraft:collision_box") {
                        put("width", m.collisionLargeur.coerceIn(0.1, 4.0))
                        put("height", m.collisionHauteur.coerceIn(0.1, 8.0))
                    }
                    putJsonObject("minecraft:nameable") {}
                    putJsonObject("minecraft:persistent") {}
                    putJsonObject("minecraft:pushable") { put("is_pushable", true); put("is_pushable_by_piston", true) }
                    putJsonObject("minecraft:behavior.float") { put("priority", 0) }
                    putJsonObject("minecraft:behavior.random_stroll") { put("priority", 6); put("speed_multiplier", 0.8) }
                    putJsonObject("minecraft:behavior.look_at_player") { put("priority", 7); put("look_distance", 6); put("probability", 0.02) }
                    putJsonObject("minecraft:behavior.random_look_around") { put("priority", 8) }
                    if (m.attaque) putJsonObject("minecraft:attack") { put("damage", m.degats) }
                    // Correctif : le profil « archer » utilisait avant le même comportement de mêlée
                    // que tous les autres profils (bug silencieux — le choix de l'utilisateur n'avait
                    // aucun effet réel). Un archer utilise maintenant une vraie attaque à distance.
                    val isArcher = m.profilIA.lowercase() == "archer"
                    if (isArcher && m.attaque) {
                        val interval = m.cooldownAttaque.takeIf { it > 0 } ?: 1.0
                        putJsonObject("minecraft:behavior.ranged_attack") {
                            put("priority", 3)
                            put("attack_interval_min", interval.coerceIn(0.5, 30.0))
                            put("attack_interval_max", (interval + 2.0).coerceIn(1.0, 60.0))
                            put("attack_radius", m.detectionDistance.coerceIn(4.0, 32.0))
                            put("speed_multiplier", m.vitesseAttaque.coerceIn(0.1, 4.0))
                        }
                        putJsonObject("minecraft:shooter") { put("def", "minecraft:arrow") }
                    } else if (m.attaque || m.poursuite) {
                        putJsonObject("minecraft:behavior.melee_attack") {
                            put("priority", 3)
                            put("speed_multiplier", m.vitesseAttaque.coerceIn(0.1, 4.0))
                            put("track_target", true)
                            if (m.cooldownAttaque > 0) put("cooldown_time", m.cooldownAttaque.coerceIn(0.0, 60.0))
                        }
                    }
                    if (m.reactionDegats) putJsonObject("minecraft:behavior.hurt_by_target") { put("priority", 1) }
                    // « Poursuite » : une créature hostile repère les joueurs. Auparavant la cible n'était pas
                    // précisée et le comportement n'avait aucun effet. Une créature non hostile ne riposte
                    // que lorsqu'on l'attaque (voir reactionDegats).
                    val profileAllowsPursuit = m.profilIA.lowercase() != "passif"
                    if (m.poursuite && m.hostile && profileAllowsPursuit) {
                        putJsonObject("minecraft:behavior.nearest_attackable_target") {
                            put("priority", 2)
                            put("must_see", true)
                            putJsonArray("entity_types") {
                                add(buildJsonObject {
                                    putJsonObject("filters") {
                                        put("test", "is_family")
                                        put("subject", "other")
                                        put("value", "player")
                                    }
                                    put("max_dist", (if (m.profilIA.lowercase() == "garde") minOf(m.detectionDistance, 16.0) else m.detectionDistance).coerceIn(1.0, 128.0))
                                })
                            }
                        }
                    }
                }
            }
        }.toString()
    }

    private fun resourceEntityJson(m: MobEntity, ns: String, id: String, key: String, hasAnim: Boolean = false): String = buildJsonObject {
        put("format_version", "1.10.0")
        putJsonObject("minecraft:client_entity") {
            putJsonObject("description") {
                put("identifier", "$ns:$id")
                putJsonObject("materials") { put("default", "entity_alphatest") }
                putJsonObject("textures") { put("default", "textures/entity/$key") }
                putJsonObject("geometry") { put("default", "geometry.humanoid") }
                // Correctif : "controller.render.default" est maintenant réellement défini
                // (voir defaultRenderControllerJson, écrit dans RP/render_controllers/) —
                // avant, cette référence pointait dans le vide et le mob restait invisible.
                putJsonArray("render_controllers") { add("controller.render.default") }
                putJsonObject("spawn_egg") {
                    put("base_color", eggColor(m.identifiant, 0.6f))
                    put("overlay_color", "#C9A227")
                }
                if (hasAnim) {
                    val animId = m.identifiant.replace(":", ".")
                    putJsonObject("scripts") {
                        putJsonArray("animate") { add("main") }
                    }
                    putJsonObject("animations") {
                        put("idle", "animation.$animId.idle")
                        put("walk", "animation.$animId.walk")
                        put("attack", "animation.$animId.attack")
                        put("hurt", "animation.$animId.hurt")
                        put("main", "controller.animation.$animId.main")
                    }
                }
            }
        }
    }.toString()

    /**
     * Contrôleur de rendu générique, partagé par tous les mobs du projet.
     * Il relie les clés "default" (geometry/materials/textures) déclarées dans le
     * client_entity de chaque mob (resourceEntityJson) à un rendu réel — sans ce
     * fichier, "controller.render.default" ne correspond à rien et Minecraft
     * n'affiche pas l'entité, quelle que soit sa texture ou sa géométrie.
     */
    private fun defaultRenderControllerJson(): String = buildJsonObject {
        put("format_version", "1.10.0")
        putJsonObject("render_controllers") {
            putJsonObject("controller.render.default") {
                put("geometry", "Geometry.default")
                putJsonArray("materials") { add(buildJsonObject { put("*", "Material.default") }) }
                putJsonArray("textures") { add("Texture.default") }
            }
        }
    }.toString()

    private fun itemJson(i: SbhItem, ns: String, id: String): String {
        // Arme/outil dès qu'il a des dégâts ou une vraie durabilité ; sinon simple ressource empilable.
        val tool = i.damage > 0 || i.durability > 1
        return buildJsonObject {
            put("format_version", "1.21.0")
            putJsonObject("minecraft:item") {
                putJsonObject("description") {
                    put("identifier", "$ns:$id")
                    putJsonObject("menu_category") { put("category", if (tool) "equipment" else "items") }
                }
                putJsonObject("components") {
                    put("minecraft:icon", textureKey("$ns:$id"))
                    putJsonObject("minecraft:display_name") { put("value", i.name) }
                    put("minecraft:max_stack_size", if (tool) 1 else 64)
                    if (tool) {
                        put("minecraft:hand_equipped", true)
                        if (i.durability > 1) putJsonObject("minecraft:durability") { put("max_durability", i.durability) }
                        // Les dégâts de l'item n'étaient auparavant jamais écrits dans le pack.
                        if (i.damage > 0) put("minecraft:damage", i.damage)
                    }
                }
            }
        }.toString()
    }

    /**
     * Bloc plein : material_instances relie enfin le bloc à sa texture (terrain_texture.json), et
     * menu_category le rend accessible dans l'inventaire créatif. Les anciens fichiers `les anciens fichiers JSON de blocs`
     * n'étaient pas un format valide côté ressources et ont été supprimés.
     */
    private fun blockJson(ns: String, id: String, destroyTime: Double, lightEmission: Int?): String = buildJsonObject {
        put("format_version", "1.21.0")
        putJsonObject("minecraft:block") {
            putJsonObject("description") {
                put("identifier", "$ns:$id")
                putJsonObject("menu_category") { put("category", "construction") }
            }
            putJsonObject("components") {
                put("minecraft:destroy_time", destroyTime)
                if (lightEmission != null) put("minecraft:light_emission", lightEmission)
                putJsonObject("minecraft:material_instances") {
                    putJsonObject("*") {
                        put("texture", textureKey("$ns:$id"))
                        put("render_method", "opaque")
                    }
                }
            }
        }
    }.toString()

    private fun splitId(value: String): Pair<String, String> = Identifiers.namespaceOf(value) to Identifiers.nameOf(value)
    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)

    companion object {
        private const val MAX_TEXTURE = 1024

        /** Clé de texture unique dans l'atlas : `agw:sabre` → `agw_sabre` (même convention que la fondation). */
        fun textureKey(identifier: String): String = identifier.replace(':', '_')
    }
}
