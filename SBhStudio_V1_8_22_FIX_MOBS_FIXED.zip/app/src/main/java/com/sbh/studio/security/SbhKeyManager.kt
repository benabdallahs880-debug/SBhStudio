package com.sbh.studio.security

import android.content.Context
import com.sbh.studio.system.SystemUnlock

/**
 * Compatibilité : délègue au module unifié [SystemUnlock].
 * Préférer `com.sbh.studio.system.SystemHub` / `SystemUnlock` dans le nouveau code.
 */
@Deprecated("Utiliser com.sbh.studio.system.SystemUnlock ou SystemHub", ReplaceWith("SystemUnlock", "com.sbh.studio.system.SystemUnlock"))
object SbhKeyManager {
    const val TEMPORARY_UPDATE_KEY = SystemUnlock.DEV_UNLOCK_KEY

    fun isValid(input: String): Boolean =
        input.trim() == SystemUnlock.DEV_UNLOCK_KEY

    fun isUnlocked(context: Context): Boolean =
        SystemUnlock.isUnlocked(context)

    fun unlock(context: Context, input: String): Boolean =
        SystemUnlock.tryUnlock(context, input).ok

    fun lock(context: Context) =
        SystemUnlock.lock(context)
}
