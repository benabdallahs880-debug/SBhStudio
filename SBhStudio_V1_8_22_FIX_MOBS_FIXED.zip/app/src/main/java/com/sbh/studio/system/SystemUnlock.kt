package com.sbh.studio.system

import android.content.Context
import com.sbh.studio.BuildConfig

/**
 * Déblocage des fonctions avancées (mises à jour manuelles, outils sensibles).
 * Centralisé — ne plus disperser les clés / prefs ailleurs.
 */
object SystemUnlock {

    private const val PREFS = "sbh_system_unlock"
    private const val LEGACY_PREFS = "sbh_studio_security"
    private const val KEY_UNLOCKED = "unlocked"
    private const val KEY_LEGACY_UNLOCKED = "update_key_unlocked"
    private const val KEY_UNLOCKED_AT = "unlocked_at_ms"
    private const val KEY_SOURCE = "unlock_source"

    const val DEV_UNLOCK_KEY = "SBH-2026-UPDATE-7391"

    enum class Feature {
        MANUAL_UPDATE,
        DEBUG_TOOLS,
        ADVANCED_EXPORT
    }

    private fun migrateIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.contains(KEY_UNLOCKED)) return
        val legacy = context.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE)
        if (legacy.getBoolean(KEY_LEGACY_UNLOCKED, false)) {
            prefs.edit()
                .putBoolean(KEY_UNLOCKED, true)
                .putLong(KEY_UNLOCKED_AT, System.currentTimeMillis())
                .putString(KEY_SOURCE, "migrated_legacy")
                .apply()
            SystemLog.i("Unlock", "migration prefs legacy → system_unlock")
        }
    }

    fun isUnlocked(context: Context): Boolean {
        migrateIfNeeded(context)
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_UNLOCKED, false)
    }

    fun unlockedAtMs(context: Context): Long {
        migrateIfNeeded(context)
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_UNLOCKED_AT, 0L)
    }

    fun unlockSource(context: Context): String {
        migrateIfNeeded(context)
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_SOURCE, "") ?: ""
    }

    fun isFeatureEnabled(context: Context, feature: Feature): Boolean {
        if (!isUnlocked(context)) return false
        return when (feature) {
            Feature.MANUAL_UPDATE,
            Feature.DEBUG_TOOLS,
            Feature.ADVANCED_EXPORT -> true
        }
    }

    fun tryUnlock(context: Context, input: String): UnlockResult {
        migrateIfNeeded(context)
        val key = input.trim()
        if (key.isEmpty()) {
            return UnlockResult(false, "Saisissez une clé de déblocage.")
        }
        if (key != DEV_UNLOCK_KEY) {
            SystemLog.w("Unlock", "tentative clé invalide")
            return UnlockResult(false, "Clé invalide.")
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_UNLOCKED, true)
            .putLong(KEY_UNLOCKED_AT, System.currentTimeMillis())
            .putString(KEY_SOURCE, if (BuildConfig.DEBUG) "dev_key_debug" else "dev_key_release")
            .apply()
        val warn = if (!BuildConfig.DEBUG) {
            " (⚠ clé de dev en build release — à remplacer avant publication)"
        } else ""
        SystemLog.i("Unlock", "débloqué source=" + (if (BuildConfig.DEBUG) "dev_key_debug" else "dev_key_release"))
        return UnlockResult(true, "Fonctions avancées débloquées.$warn")
    }

    fun lock(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_UNLOCKED, false)
            .putLong(KEY_UNLOCKED_AT, 0L)
            .putString(KEY_SOURCE, "")
            .apply()
        // Nettoie aussi l'ancien stockage
        context.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_LEGACY_UNLOCKED, false)
            .apply()
        SystemLog.i("Unlock", "verrouillage demandé")
    }

    data class UnlockResult(val ok: Boolean, val message: String)
}
