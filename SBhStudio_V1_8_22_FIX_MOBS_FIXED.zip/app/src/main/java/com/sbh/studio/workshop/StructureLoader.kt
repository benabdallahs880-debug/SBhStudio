package com.sbh.studio.workshop

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Chargeur de structures voxel (JSON SBh ou NBT Minecraft).
 * Utilisé par l'Éditeur 3D, Maps et PlayableSceneBuilder.
 */
object StructureLoader {

    private val json = Json { ignoreUnknownKeys = true }

    @Serializable
    data class StructureSize(val x: Int, val y: Int, val z: Int)

    @Serializable
    data class StructureBlockState(
        val Name: String,
        val Properties: Map<String, String>? = null
    )

    @Serializable
    data class StructureBlock(
        val x: Int,
        val y: Int,
        val z: Int,
        val state: Int
    )

    @Serializable
    data class StructureDef(
        val id: String = "",
        val name: String = "",
        val description: String = "",
        val size: StructureSize,
        val palette: List<StructureBlockState>,
        val blocks: List<StructureBlock>
    )

    data class StructureInfo(
        val id: String,
        val displayName: String,
        val assetPath: String,
        val description: String
    )

    val KNOWN_STRUCTURES = listOf(
        StructureInfo(
            id = "maison_forgeron",
            displayName = "Maison de forgeron",
            assetPath = "structures/structure_maison_forgeron.json",
            description = "Forge de village (15×12×20, ~597 blocs)"
        )
    )

    fun loadFromAssets(context: Context, assetPath: String): StructureDef? {
        return try {
            context.assets.open(assetPath).use { stream ->
                val text = BufferedReader(InputStreamReader(stream)).readText()
                json.decodeFromString<StructureDef>(text)
            }
        } catch (_: Exception) {
            null
        }
    }

    fun loadFromFile(file: java.io.File, nameHint: String? = null): StructureDef? {
        if (!file.exists() || !file.canRead()) return null
        val bytes = try {
            file.readBytes()
        } catch (_: Exception) {
            return null
        }
        val name = nameHint ?: file.nameWithoutExtension
        return loadFromBytes(bytes, name, file.extension.lowercase())
    }

    /**
     * Détecte JSON vs NBT via magic bytes (fiable même sans extension content://).
     */
    fun loadFromBytes(
        bytes: ByteArray,
        nameHint: String = "Structure",
        extensionHint: String = ""
    ): StructureDef? {
        if (bytes.isEmpty()) return null
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = if (bytes.size > 1) bytes[1].toInt() and 0xFF else 0
        val looksGzipNbt = b0 == 0x1f && b1 == 0x8b
        val looksRawNbt = b0 == 0x0a
        val looksJson = b0 == 0x7B || b0 == 0xEF
        val ext = extensionHint.lowercase()

        if (looksJson || ext == "json") {
            try {
                val text = bytes.toString(Charsets.UTF_8).trimStart('\uFEFF')
                if (text.startsWith("{")) {
                    return json.decodeFromString<StructureDef>(text)
                }
            } catch (_: Exception) {
                // fallback NBT
            }
        }

        if (looksGzipNbt || looksRawNbt || ext == "nbt" || ext == "schematic" || !looksJson) {
            val nbt = NbtStructureParser.parseStructure(bytes, nameHint)
            if (nbt != null) return nbt
        }

        return try {
            val text = bytes.toString(Charsets.UTF_8).trimStart('\uFEFF')
            if (text.startsWith("{")) {
                json.decodeFromString<StructureDef>(text)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    fun loadFromStream(
        stream: java.io.InputStream,
        nameHint: String = "Structure",
        extensionHint: String = ""
    ): StructureDef? {
        return try {
            loadFromBytes(stream.readBytes(), nameHint, extensionHint)
        } catch (_: Exception) {
            null
        }
    }

    fun toEditorObjects(
        structure: StructureDef,
        maxBlocks: Int = 800,
        originX: Float = 0f,
        originY: Float = 0f,
        originZ: Float = 0f
    ): List<EditorObject> {
        val cx = structure.size.x / 2f
        val cz = structure.size.z / 2f
        val sorted = structure.blocks
            .sortedWith(compareBy({ it.y }, { it.z }, { it.x }))
            .take(maxBlocks)

        return sorted.mapIndexed { index, b ->
            val state = structure.palette.getOrNull(b.state)
            val name = state?.Name ?: "minecraft:stone"
            val hue = hueForBlock(name)
            EditorObject(
                id = java.util.UUID.randomUUID().toString(),
                name = "bloc_" + (index + 1),
                kind = EditorKind.CUBE.name,
                x = originX + (b.x - cx),
                y = originY + b.y.toFloat(),
                z = originZ + (b.z - cz),
                scale = 0.95f,
                hue = hue
            )
        }
    }

    fun hueForBlock(blockName: String): Float {
        val n = blockName.lowercase()
        return when {
            "grass" in n || "leaves" in n -> 120f
            "dirt" in n || "gravel" in n || "sand" in n -> 35f
            "cobble" in n || "stone_brick" in n || "stone" in n -> -1f
            "plank" in n || "log" in n || "wood" in n || "fence" in n -> 30f
            "coal" in n -> 280f
            "iron" in n || "anvil" in n || "hopper" in n -> 210f
            "furnace" in n || "crafting" in n || "chest" in n -> 20f
            "sandstone" in n -> 45f
            "carpet" in n || "wool" in n -> 0f
            "ladder" in n || "torch" in n -> 45f
            "piston" in n || "repeater" in n || "redstone" in n -> 0f
            "web" in n || "cobweb" in n -> -1f
            else -> -1f
        }
    }
}
