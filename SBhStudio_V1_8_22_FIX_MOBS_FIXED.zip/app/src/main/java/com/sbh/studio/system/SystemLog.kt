package com.sbh.studio.system

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Logger centralisé SBh Studio.
 *
 * - Écrit dans Logcat (tag SBH)
 * - Persiste les lignes dans filesDir/diagnostics/system.log
 * - Niveaux : D / I / W / E
 *
 * Usage :
 *   SystemLog.i("Unlock", "clé acceptée")
 *   SystemLog.e("Import", "NBT invalide", exception)
 */
object SystemLog {

    private const val TAG = "SBH"
    private const val MAX_FILE_BYTES = 512_000 // ~512 Ko puis rotation
    private val lock = ReentrantLock()
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    @Volatile private var appContext: Context? = null

    /** À appeler une fois au démarrage (MainActivity.onCreate). */
    fun init(context: Context) {
        appContext = context.applicationContext
        i("SystemLog", "init ok")
    }

    fun d(module: String, message: String) = write('D', module, message, null)
    fun i(module: String, message: String) = write('I', module, message, null)
    fun w(module: String, message: String) = write('W', module, message, null)
    fun e(module: String, message: String, error: Throwable? = null) =
        write('E', module, message, error)

    fun recentLines(limit: Int = 100): List<String> {
        val ctx = appContext ?: return emptyList()
        val file = logFile(ctx)
        if (!file.exists()) return emptyList()
        return try {
            file.readLines().takeLast(limit)
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clear() {
        val ctx = appContext ?: return
        lock.withLock {
            try {
                logFile(ctx).writeText("")
            } catch (_: Exception) { }
        }
        i("SystemLog", "journal effacé")
    }

    private fun logFile(context: Context): File =
        File(SystemPaths.diagnosticsDir(context), "system.log")

    private fun write(level: Char, module: String, message: String, error: Throwable?) {
        val line = buildString {
            append(fmt.format(Date()))
            append(" ")
            append(level)
            append("/")
            append(module)
            append(": ")
            append(message)
            if (error != null) {
                append(" | ")
                append(error.javaClass.simpleName)
                append(": ")
                append(error.message ?: "")
            }
        }
        when (level) {
            'D' -> Log.d(TAG, "$module: $message", error)
            'I' -> Log.i(TAG, "$module: $message", error)
            'W' -> Log.w(TAG, "$module: $message", error)
            'E' -> Log.e(TAG, "$module: $message", error)
        }
        val ctx = appContext ?: return
        lock.withLock {
            try {
                val f = logFile(ctx)
                if (f.exists() && f.length() > MAX_FILE_BYTES) {
                    val bak = File(f.parentFile, "system.log.bak")
                    bak.delete()
                    f.renameTo(bak)
                }
                f.appendText(line + "\n")
            } catch (_: Exception) {
                // ne jamais faire planter l'app pour un log
            }
        }
    }
}
