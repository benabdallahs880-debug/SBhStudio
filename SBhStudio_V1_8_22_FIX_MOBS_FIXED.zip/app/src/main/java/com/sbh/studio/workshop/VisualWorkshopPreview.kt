package com.sbh.studio.workshop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.character.CharacterPreview3D
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhSound
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AgwDecor
import com.sbh.studio.ui.LiveBadge
import java.util.Random
import kotlin.math.max
import kotlin.math.min

/**
 * Aperçu partagé de l'Atelier. Chaque aperçu est dessiné à partir des DONNÉES réelles de
 * l'élément sélectionné (couleur, dimensions, stats, contenu de la carte, grille de recette…)
 * et non plus d'une image générique. Sans élément, on montre un fantôme + un message clair,
 * et le badge indique « VIDE » au lieu de « EN DIRECT ».
 * 100 % local, déterministe, sans service en ligne ni nouvelle dépendance.
 */
@Composable
internal fun VisualWorkshopPreview(
    zone: WorkshopZoneId,
    items: List<SbhItem>,
    blocks: List<SbhBlock>,
    mobs: List<MobEntity>,
    entities: List<SceneEntity>,
    characters: List<com.sbh.studio.character.CharacterProject>,
    maps: List<MapBlueprint>,
    recipes: List<RecipeBlueprint> = emptyList(),
    portals: List<PortalBlueprint> = emptyList(),
    sounds: List<SbhSound> = emptyList(),
    games: List<GameProjectBlueprint> = emptyList(),
    selectedId: String? = null,
    onSelect: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val title = when (zone) {
        WorkshopZoneId.BLOCKS -> "Aperçu du bloc"
        WorkshopZoneId.ITEMS -> "Aperçu de l'objet"
        WorkshopZoneId.MOBS -> "Aperçu de la créature"
        WorkshopZoneId.ENTITIES -> "Aperçu de la scène 3D"
        WorkshopZoneId.CHARACTER_STUDIO -> "Aperçu du personnage"
        WorkshopZoneId.MAPS -> "Aperçu de la carte"
        WorkshopZoneId.GAME_BUILDER -> "Aperçu du jeu"
        WorkshopZoneId.RECIPES -> "Aperçu de la recette"
        WorkshopZoneId.PORTALS -> "Aperçu du portail"
        WorkshopZoneId.SOUNDS -> "Aperçu du son"
        else -> "Aperçu visuel"
    }

    val block = blocks.firstOrNull { it.id == selectedId } ?: blocks.firstOrNull()
    val item = items.firstOrNull { it.id == selectedId } ?: items.firstOrNull()
    val mob = mobs.firstOrNull { it.id == selectedId } ?: mobs.firstOrNull()
    val mapItem = maps.firstOrNull { it.id == selectedId } ?: maps.firstOrNull()
    val recipe = recipes.firstOrNull { it.id == selectedId } ?: recipes.firstOrNull()
    val portal = portals.firstOrNull { it.id == selectedId } ?: portals.firstOrNull()
    val sound = sounds.firstOrNull { it.id == selectedId } ?: sounds.firstOrNull()
    val game = games.firstOrNull { it.id == selectedId } ?: games.firstOrNull()
    val character = characters.firstOrNull { it.id == selectedId } ?: characters.firstOrNull()
    val entity = entities.firstOrNull { it.id == selectedId && !it.glbUri.isNullOrBlank() }
        ?: entities.firstOrNull { !it.glbUri.isNullOrBlank() }

    val hasContent = when (zone) {
        WorkshopZoneId.BLOCKS -> block != null
        WorkshopZoneId.ITEMS -> item != null
        WorkshopZoneId.MOBS -> mob != null
        WorkshopZoneId.MAPS -> mapItem != null
        WorkshopZoneId.RECIPES -> recipe != null
        WorkshopZoneId.PORTALS -> portal != null
        WorkshopZoneId.SOUNDS -> sound != null
        WorkshopZoneId.GAME_BUILDER -> game != null
        WorkshopZoneId.CHARACTER_STUDIO -> character != null
        WorkshopZoneId.ENTITIES -> entity != null
        else -> false
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(AgwDecor.ViewportShape)
            .background(AgwDecor.ViewportFrameBrush)
            .border(AgwDecor.ViewportBorder, AgwDecor.ViewportShape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = AgwColors.PaleMarble, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    "Créer → sélectionner → voir → modifier",
                    color = AgwColors.SilverMuted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            LiveBadge(text = if (hasContent) "EN DIRECT" else "VIDE")
        }

        val selectable = when (zone) {
            WorkshopZoneId.BLOCKS -> blocks.map { it.id to it.name }
            WorkshopZoneId.ITEMS -> items.map { it.id to it.name }
            WorkshopZoneId.MOBS -> mobs.map { it.id to it.nom }
            WorkshopZoneId.ENTITIES -> entities.map { it.id to it.name }
            WorkshopZoneId.CHARACTER_STUDIO -> characters.map { it.id to it.name }
            WorkshopZoneId.MAPS -> maps.map { it.id to it.name }
            WorkshopZoneId.RECIPES -> recipes.map { it.id to it.name }
            WorkshopZoneId.PORTALS -> portals.map { it.id to it.name }
            WorkshopZoneId.SOUNDS -> sounds.map { it.id to it.name }
            WorkshopZoneId.GAME_BUILDER -> games.map { it.id to it.name }
            else -> emptyList()
        }
        if (selectable.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                selectable.forEach { (id, name) ->
                    val selected = selectedId == id
                    FilterChip(
                        selected = selected,
                        onClick = { onSelect(id) },
                        label = {
                            Text(
                                name,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = AgwColors.DeepNight.copy(alpha = 0.55f),
                            labelColor = AgwColors.Sand,
                            selectedContainerColor = AgwColors.SacredGold.copy(alpha = 0.22f),
                            selectedLabelColor = AgwColors.GoldSoft
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = AgwColors.SilverMuted.copy(alpha = 0.28f),
                            selectedBorderColor = AgwColors.SacredGold.copy(alpha = 0.55f)
                        )
                    )
                }
            }
        }

        when (zone) {
            WorkshopZoneId.CHARACTER_STUDIO -> {
                if (character != null) {
                    CharacterPreview3D(
                        modelUri = character.modelUri,
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                } else {
                    EmptyVisual("Crée un personnage pour le voir ici")
                }
            }
            WorkshopZoneId.ENTITIES -> {
                if (entity != null) {
                    CharacterPreview3D(
                        modelUri = entity.glbUri,
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                } else {
                    Stage("Scène vide", "Importe un .glb pour le voir ici en 3D", ghost = true) { a ->
                        val base = groundY()
                        val s = unit()
                        isoCube(size.width * .42f, base, s * .8f, AgwColors.SacredGold, a)
                        figure(size.width * .66f, base, s * .8f, AgwColors.Sand, AgwColors.SilverMuted, AgwColors.DeepNight, a)
                    }
                }
            }
            WorkshopZoneId.BLOCKS -> {
                val c = tint(block?.identifier ?: "block")
                Stage(
                    block?.name ?: "Aucun bloc — crée le premier ci-dessous",
                    if (block != null) "Dureté ${block.hardness} · ${block.identifier}" else "",
                    ghost = block == null
                ) { a ->
                    isoCube(size.width / 2f, groundY(), unit() * 1.15f, c, a)
                }
            }
            WorkshopZoneId.ITEMS -> {
                val c = tint(item?.identifier ?: "item")
                val dmg = item?.damage ?: 4
                Stage(
                    item?.name ?: "Aucun objet — crée le premier ci-dessous",
                    if (item != null) "Dégâts ${item.damage} · durabilité ${item.durability}" else "",
                    ghost = item == null
                ) { a ->
                    val s = unit()
                    val base = groundY()
                    val x = size.width / 2f
                    val bladeLen = s * (1.2f + min(dmg, 20) * 0.05f)
                    drawOval(Color.Black.copy(alpha = .35f * a), Offset(x - s * .9f, base - s * .08f), Size(s * 1.8f, s * .16f))
                    rotate(-32f, Offset(x, base - s * 1.0f)) {
                        val blade = lerp(AgwColors.Silver, c, .3f).fade(a)
                        drawRect(blade, Offset(x - s * .13f, base - s * 1.0f - bladeLen), Size(s * .26f, bladeLen))
                        drawRect(AgwColors.SilverSoft.fade(a * .8f), Offset(x - s * .03f, base - s * 1.0f - bladeLen), Size(s * .06f, bladeLen))
                        drawRect(AgwColors.SacredGold.fade(a), Offset(x - s * .5f, base - s * 1.0f), Size(s * 1.0f, s * .13f))
                        drawRect(lerp(AgwColors.DesertOchre, Color.Black, .35f).fade(a), Offset(x - s * .09f, base - s * .87f), Size(s * .18f, s * .55f))
                        drawCircle(AgwColors.SacredGold.fade(a), s * .13f, Offset(x, base - s * .3f))
                    }
                }
            }
            WorkshopZoneId.MOBS -> {
                val hostile = mob?.hostile ?: false
                val seed = mob?.identifiant ?: "mob"
                val body = lerp(if (hostile) AgwColors.Error else AgwColors.Success, tint(seed), .2f)
                Stage(
                    mob?.nom ?: "Aucune créature — crée la première ci-dessous",
                    if (mob != null) "❤ ${mob.vie} · ⚔ ${mob.degats} · vitesse ${mob.vitesse} · ${if (hostile) "hostile" else "passive"}" else "",
                    ghost = mob == null
                ) { a ->
                    val hMul = ((mob?.collisionHauteur ?: 1.8) / 1.8).toFloat().coerceIn(.45f, 1.5f)
                    val wMul = ((mob?.collisionLargeur ?: 0.6) / 0.6).toFloat().coerceIn(.6f, 1.6f)
                    val fade = if (mob?.pouvoirInvisibilite == true) a * .45f else a
                    figure(
                        size.width / 2f, groundY(), unit() * 1.15f,
                        body, lerp(body, AgwColors.PaleMarble, .35f),
                        if (hostile) Color(0xFFFF4D4D) else AgwColors.PaleMarble,
                        fade, hMul, wMul
                    )
                }
            }
            WorkshopZoneId.MAPS -> {
                Stage(
                    mapItem?.name ?: "Aucune carte — crée la première ci-dessous",
                    if (mapItem != null) mapSummary(mapItem) else "",
                    flat = true, ghost = mapItem == null
                ) { a -> drawMap(mapItem ?: MapBlueprint(projectId = "", name = ""), a) }
            }
            WorkshopZoneId.PORTALS -> {
                Stage(
                    portal?.name ?: "Aucun portail — crée le premier ci-dessous",
                    if (portal != null) "${portal.width}×${portal.height} · vers ${portal.destinationHint}" else "",
                    ghost = portal == null
                ) { a -> drawPortal(portal ?: PortalBlueprint(projectId = "", name = ""), a) }
            }
            WorkshopZoneId.SOUNDS -> {
                Stage(
                    sound?.name ?: "Aucun son — importe le premier ci-dessous",
                    if (sound != null) {
                        val secs = if (sound.durationMs > 0) " · ${sound.durationMs / 1000} s" else ""
                        "${sound.category}$secs · ${if (sound.includeInPack) "dans le pack" else "hors pack"}"
                    } else "",
                    flat = true, ghost = sound == null
                ) { a -> drawWave(sound?.fileName ?: "son", a) }
            }
            WorkshopZoneId.RECIPES -> RecipeVisual(recipe)
            WorkshopZoneId.GAME_BUILDER -> {
                Stage(
                    game?.name ?: "Aucun jeu — crée le premier ci-dessous",
                    if (game != null) "Monde ${game.worldSizeX}×${game.worldSizeZ} · ${game.engine} · ${game.performance}" else "",
                    ghost = game == null
                ) { a -> drawGame(game, a) }
            }
            else -> {
                Stage("Sélectionne un élément à construire", "", ghost = true) { a ->
                    isoCube(size.width / 2f, groundY(), unit(), AgwColors.SacredGold, a)
                }
            }
        }
    }
}

// ───────────────────────── Composables de scène ─────────────────────────

@Composable
private fun EmptyVisual(message: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(AgwColors.DeepNight.copy(alpha = 0.55f))
            .border(1.dp, AgwColors.SilverMuted.copy(alpha = 0.18f), RoundedCornerShape(14.dp))
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("◇", color = AgwColors.SilverMuted, fontSize = 22.sp)
        Spacer(Modifier.height(8.dp))
        Text(message, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
    }
}

/** Scène commune : ciel, horizon, sol en perspective (ou plan à plat), puis dessin fourni. */
@Composable
private fun Stage(
    caption: String,
    detail: String,
    flat: Boolean = false,
    ghost: Boolean = false,
    draw: DrawScope.(Float) -> Unit
) {
    val a = if (ghost) 0.28f else 1f
    Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(14.dp)).background(AgwColors.DeepNight)) {
        Canvas(Modifier.fillMaxSize()) {
            drawStage(flat)
            draw(a)
        }
        Column(
            Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp).padding(bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                caption, color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
            if (detail.isNotBlank()) {
                Text(
                    detail, color = AgwColors.SilverMuted, fontSize = 11.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                )
            }
        }
    }
}

/** Recette : vraie grille 3×3 (shaped) ou liste d'ingrédients, flèche, résultat. */
@Composable
private fun RecipeVisual(recipe: RecipeBlueprint?) {
    val r = recipe ?: RecipeBlueprint(projectId = "", name = "")
    val shaped = !r.type.contains("shapeless") && !r.type.contains("furnace") && !r.type.contains("four")
    Box(
        Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(14.dp)).background(AgwColors.DeepNight),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (shaped) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (row in 0..2) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                for (col in 0..2) Slot(r.pattern.getOrNull(row * 3 + col).orEmpty(), 0, 44.dp)
                            }
                        }
                    }
                } else {
                    val ing = r.ingredients.take(6)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        (if (ing.isEmpty()) listOf("") else ing).chunked(3).forEach { line ->
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                line.forEach { Slot(it, 0, 44.dp) }
                            }
                        }
                    }
                }
                Text("→", color = AgwColors.SacredGold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Slot(if (recipe == null) "" else r.resultId, r.resultCount, 56.dp)
            }
            Text(
                recipe?.name ?: "Aucune recette — la grille est prête",
                color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun Slot(id: String, count: Int, size: Dp) {
    val filled = id.isNotBlank()
    val c = tint(id.ifBlank { "vide" })
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(8.dp))
            .background(if (filled) c.copy(alpha = .35f) else AgwColors.Panel.copy(alpha = .6f))
            .border(1.dp, if (filled) c.copy(alpha = .8f) else AgwColors.Outline, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (filled) {
            Text(
                id.substringAfter(':').take(5), color = AgwColors.PaleMarble, fontSize = 10.sp,
                maxLines = 1, overflow = TextOverflow.Clip
            )
            if (count > 1) {
                Text(
                    "$count", color = AgwColors.GoldSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(end = 4.dp, bottom = 2.dp)
                )
            }
        }
    }
}

// ───────────────────────── Dessin (DrawScope) ─────────────────────────

private fun Color.fade(a: Float): Color = copy(alpha = alpha * a)

/** Couleur stable dérivée d'un identifiant : le même bloc/objet a toujours la même teinte. */
private fun tint(seed: String, sat: Float = .5f, value: Float = .78f): Color =
    Color.hsv(((seed.hashCode() and 0x7fffffff) % 360).toFloat(), sat, value)

private fun DrawScope.unit(): Float = min(size.width, size.height) * .19f
private fun DrawScope.horizonY(): Float = size.height * .62f
private fun DrawScope.groundY(): Float = horizonY() + (size.height - horizonY()) * .42f

private fun DrawScope.drawStage(flat: Boolean) {
    val w = size.width
    val h = size.height
    if (flat) {
        drawRect(Brush.verticalGradient(colors = listOf(Color(0xFF141B24), AgwColors.DeepNight)))
        val step = w / 14f
        var gx = 0f
        while (gx <= w) { drawLine(AgwColors.SilverMuted.copy(alpha = .06f), Offset(gx, 0f), Offset(gx, h), 1f); gx += step }
        var gy = 0f
        while (gy <= h) { drawLine(AgwColors.SilverMuted.copy(alpha = .06f), Offset(0f, gy), Offset(w, gy), 1f); gy += step }
        return
    }
    val hz = horizonY()
    drawRect(
        Brush.verticalGradient(colors = listOf(Color(0xFF0A101B), Color(0xFF1D2A3B)), startY = 0f, endY = hz),
        topLeft = Offset(0f, 0f), size = Size(w, hz)
    )
    drawRect(
        Brush.verticalGradient(colors = listOf(Color(0xFF1B232E), AgwColors.DeepNight), startY = hz, endY = h),
        topLeft = Offset(0f, hz), size = Size(w, h - hz)
    )
    for (i in -7..7) {
        drawLine(
            AgwColors.SilverMuted.copy(alpha = .10f),
            Offset(w / 2f + i * w * .03f, hz), Offset(w / 2f + i * w * .17f, h), 1.5f
        )
    }
    var y = hz
    var step = h * .02f
    while (y < h) {
        drawLine(AgwColors.SilverMuted.copy(alpha = .08f), Offset(0f, y), Offset(w, y), 1.5f)
        y += step
        step *= 1.35f
    }
    drawLine(AgwColors.SacredGold.copy(alpha = .28f), Offset(0f, hz), Offset(w, hz), 2f)
}

/** Cube isométrique (bloc) posé sur le sol : haut, face gauche, face droite, arêtes. */
private fun DrawScope.isoCube(x: Float, base: Float, s: Float, c: Color, a: Float) {
    val hw = s * .87f
    drawOval(Color.Black.copy(alpha = .35f * a), Offset(x - hw * 1.1f, base - s * .12f), Size(hw * 2.2f, s * .3f))
    val top = Path().apply { moveTo(x, base - s); lineTo(x - hw, base - s * 1.5f); lineTo(x, base - s * 2f); lineTo(x + hw, base - s * 1.5f); close() }
    val left = Path().apply { moveTo(x, base); lineTo(x - hw, base - s * .5f); lineTo(x - hw, base - s * 1.5f); lineTo(x, base - s); close() }
    val right = Path().apply { moveTo(x, base); lineTo(x + hw, base - s * .5f); lineTo(x + hw, base - s * 1.5f); lineTo(x, base - s); close() }
    drawPath(top, lerp(c, Color.White, .22f).fade(a))
    drawPath(left, lerp(c, Color.Black, .45f).fade(a))
    drawPath(right, lerp(c, Color.Black, .25f).fade(a))
    val edge = Color.Black.copy(alpha = .35f * a)
    drawPath(top, edge, style = Stroke(2f))
    drawPath(left, edge, style = Stroke(2f))
    drawPath(right, edge, style = Stroke(2f))
}

/** Personnage / créature « voxel » : jambes, torse, bras, tête carrée, yeux. */
private fun DrawScope.figure(
    x: Float, base: Float, s: Float,
    body: Color, head: Color, eye: Color, a: Float,
    hMul: Float = 1f, wMul: Float = 1f
) {
    val t = s * 2.2f * hMul
    val w = s * .9f * wMul
    drawOval(Color.Black.copy(alpha = .35f * a), Offset(x - w * .9f, base - t * .04f), Size(w * 1.8f, t * .08f))
    val legs = lerp(body, Color.Black, .35f).fade(a)
    drawRect(legs, Offset(x - w * .48f, base - t * .38f), Size(w * .44f, t * .38f))
    drawRect(legs, Offset(x + w * .04f, base - t * .38f), Size(w * .44f, t * .38f))
    drawRect(body.fade(a), Offset(x - w * .5f, base - t * .74f), Size(w, t * .36f))
    val arm = lerp(body, Color.Black, .15f).fade(a)
    drawRect(arm, Offset(x - w * .5f - w * .26f, base - t * .74f), Size(w * .26f, t * .36f))
    drawRect(arm, Offset(x + w * .5f, base - t * .74f), Size(w * .26f, t * .36f))
    val hs = t * .26f
    drawRect(head.fade(a), Offset(x - hs / 2f, base - t * .74f - hs), Size(hs, hs))
    drawRect(eye.fade(a), Offset(x - hs * .32f, base - t * .74f - hs * .62f), Size(hs * .18f, hs * .18f))
    drawRect(eye.fade(a), Offset(x + hs * .14f, base - t * .74f - hs * .62f), Size(hs * .18f, hs * .18f))
}

private fun mapSummary(m: MapBlueprint): String {
    val feats = buildList {
        if (m.hasVillage) add("village")
        if (m.hasDungeon) add("donjon")
        if (m.hasOasis) add("oasis")
        if (m.hasMountains) add("montagnes")
        if (m.hasRoads) add("routes")
    }
    return "${m.sizeX}×${m.sizeZ} · ${m.terrain}" + if (feats.isEmpty()) "" else " · " + feats.joinToString(", ")
}

/** Vue de dessus de la vraie carte : terrain, village, donjon, oasis, montagnes, routes. */
private fun DrawScope.drawMap(m: MapBlueprint, a: Float) {
    val maxW = size.width * .72f
    val maxH = size.height * .58f
    val aspect = m.sizeX.toFloat() / max(1, m.sizeZ).toFloat()
    val pw: Float
    val ph: Float
    if (aspect >= maxW / maxH) { pw = maxW; ph = maxW / aspect } else { ph = maxH; pw = maxH * aspect }
    val left = (size.width - pw) / 2f
    val top = size.height * .08f + (maxH - ph) / 2f
    val t = m.terrain.lowercase()
    val ground = when {
        t.contains("desert") || t.contains("sand") -> Color(0xFFD2B77A)
        t.contains("snow") || t.contains("tundra") || t.contains("ice") -> Color(0xFFDCE7EE)
        t.contains("swamp") -> Color(0xFF4B6B4A)
        t.contains("mount") || t.contains("rock") -> Color(0xFF8A8F94)
        t.contains("forest") || t.contains("jungle") || t.contains("plain") || t.contains("grass") -> Color(0xFF5E8C4B)
        else -> AgwColors.Sand
    }
    val rng = Random(m.seed + m.id.hashCode())
    val vx = left + pw * (.25f + rng.nextFloat() * .5f)
    val vy = top + ph * (.25f + rng.nextFloat() * .5f)
    val dx = left + pw * (.15f + rng.nextFloat() * .7f)
    val dy = top + ph * (.15f + rng.nextFloat() * .7f)
    drawRoundRect(ground.fade(a), Offset(left, top), Size(pw, ph), CornerRadius(10f, 10f))
    drawRoundRect(AgwColors.SilverSoft.copy(alpha = .35f * a), Offset(left, top), Size(pw, ph), CornerRadius(10f, 10f), style = Stroke(2f))
    if (m.hasRoads) {
        val road = Color(0xFF7A6A4A).fade(a)
        drawLine(road, Offset(left, vy), Offset(left + pw, vy), max(3f, ph * .03f))
        drawLine(road, Offset(dx, top), Offset(dx, top + ph), max(3f, pw * .02f))
    }
    if (m.hasMountains) {
        repeat(4) {
            val mx = left + pw * (.1f + rng.nextFloat() * .8f)
            val my = top + ph * (.2f + rng.nextFloat() * .6f)
            val r = min(pw, ph) * (.07f + rng.nextFloat() * .05f)
            val p = Path().apply { moveTo(mx, my - r); lineTo(mx - r, my + r * .6f); lineTo(mx + r, my + r * .6f); close() }
            drawPath(p, Color(0xFF6E747A).fade(a))
            drawCircle(Color.White.fade(a * .8f), r * .18f, Offset(mx, my - r * .7f))
        }
    }
    if (m.hasOasis) {
        val ox = left + pw * (.15f + rng.nextFloat() * .7f)
        val oy = top + ph * (.15f + rng.nextFloat() * .7f)
        drawOval(Color(0xFF3E8A4B).fade(a), Offset(ox - pw * .09f, oy - ph * .09f), Size(pw * .18f, ph * .18f))
        drawOval(Color(0xFF3FA7D6).fade(a), Offset(ox - pw * .06f, oy - ph * .06f), Size(pw * .12f, ph * .12f))
    }
    if (m.hasDungeon) {
        val ds = min(pw, ph) * .12f
        drawRect(Color(0xFF1B1B22).fade(a), Offset(dx - ds / 2f, dy - ds / 2f), Size(ds, ds))
        drawRect(AgwColors.SacredGold.fade(a), Offset(dx - ds / 2f, dy - ds / 2f), Size(ds, ds), style = Stroke(3f))
    }
    if (m.hasVillage) {
        val hs = min(pw, ph) * .05f
        repeat(6) {
            val hx = vx + (rng.nextFloat() - .5f) * pw * .16f
            val hy = vy + (rng.nextFloat() - .5f) * ph * .16f
            drawRect(Color(0xFF8B5E3C).fade(a), Offset(hx, hy), Size(hs, hs))
            drawRect(Color(0xFF5A3A24).fade(a), Offset(hx, hy), Size(hs, hs * .35f))
        }
    }
    // Nord
    drawLine(AgwColors.PaleMarble.fade(a), Offset(left + pw - 14f, top + 30f), Offset(left + pw - 14f, top + 10f), 3f)
    drawCircle(AgwColors.PaleMarble.fade(a), 4f, Offset(left + pw - 14f, top + 8f))
}

/** Portail : cadre aux vraies dimensions (largeur × hauteur en blocs) + surface violette. */
private fun DrawScope.drawPortal(p: PortalBlueprint, a: Float) {
    val base = groundY()
    val x = size.width / 2f
    val cw = max(3, p.width)
    val ch = max(3, p.height)
    val cell = min(size.width * .5f / cw, size.height * .55f / ch)
    val pw = cell * cw
    val ph = cell * ch
    val left = x - pw / 2f
    val top = base - ph
    val frame = lerp(tint(p.frameBlock, .35f, .45f), Color.Black, .2f)
    drawOval(Color.Black.copy(alpha = .35f * a), Offset(left - cell * .2f, base - cell * .15f), Size(pw + cell * .4f, cell * .4f))
    drawRect(frame.fade(a), Offset(left, top), Size(pw, ph))
    val ix = left + cell
    val iy = top + cell
    val iw = pw - 2 * cell
    val ih = ph - 2 * cell
    drawRect(
        Brush.verticalGradient(colors = listOf(Color(0xFF7A3FD1).fade(a), Color(0xFF2B1466).fade(a)), startY = iy, endY = iy + ih),
        topLeft = Offset(ix, iy), size = Size(iw, ih)
    )
    repeat(3) { i ->
        val k = (i + 1) / 4f
        drawOval(
            Color(0xFFD9B8FF).copy(alpha = .35f * a),
            Offset(ix + iw * (.5f - .4f * k), iy + ih * (.5f - .4f * k)),
            Size(iw * .8f * k, ih * .8f * k), style = Stroke(2f)
        )
    }
    // Reflets de briques sur le cadre
    val line = Color.Black.copy(alpha = .25f * a)
    for (i in 1 until cw) drawLine(line, Offset(left + i * cell, top), Offset(left + i * cell, top + cell), 1.5f)
    for (j in 1 until ch) drawLine(line, Offset(left, top + j * cell), Offset(left + cell, top + j * cell), 1.5f)
}

/** Forme d'onde stable (issue du nom du fichier) + bouton lecture. */
private fun DrawScope.drawWave(seed: String, a: Float) {
    val rng = Random(seed.hashCode().toLong())
    val bars = 44
    val left = size.width * .22f
    val width = size.width * .68f
    val midY = size.height * .42f
    val bw = width / bars
    for (i in 0 until bars) {
        val env = kotlin.math.sin(Math.PI * i / bars).toFloat()
        val hgt = size.height * .34f * (.15f + .85f * rng.nextFloat()) * (.35f + .65f * env)
        drawRect(
            AgwColors.SacredGold.fade(a), Offset(left + i * bw + bw * .15f, midY - hgt / 2f), Size(bw * .7f, max(2f, hgt))
        )
    }
    val cx = size.width * .11f
    drawCircle(AgwColors.SacredGold.copy(alpha = .18f * a), size.height * .1f, Offset(cx, midY))
    drawCircle(AgwColors.SacredGold.fade(a), size.height * .1f, Offset(cx, midY), style = Stroke(3f))
    val r = size.height * .045f
    val tri = Path().apply { moveTo(cx - r * .6f, midY - r); lineTo(cx - r * .6f, midY + r); lineTo(cx + r, midY); close() }
    drawPath(tri, AgwColors.GoldSoft.fade(a))
}

/** Scène de jeu : le joueur au centre, les factions autour, quelques bâtiments au fond. */
private fun DrawScope.drawGame(g: GameProjectBlueprint?, a: Float) {
    val base = groundY()
    val s = unit()
    val cx = size.width / 2f
    val buildings = min(3, max(1, g?.missions?.size ?: 1))
    for (i in 0 until buildings) {
        val bx = size.width * (.2f + .3f * i)
        isoCube(bx, base - s * .55f, s * .42f, tint((g?.name ?: "jeu") + i, .25f, .6f), a * .8f)
    }
    val others = (g?.factions ?: listOf("player", "neutral", "enemy")).filter { it != "player" }.take(4)
    others.forEachIndexed { i, f ->
        val fx = if (i % 2 == 0) cx - s * (1.6f + i * .5f) else cx + s * (1.6f + i * .5f)
        val col = when (f) {
            "enemy" -> AgwColors.Error
            "neutral" -> AgwColors.Silver
            else -> tint(f)
        }
        figure(fx, base + s * .1f, s * .8f, col, lerp(col, Color.White, .3f), AgwColors.DeepNight, a)
    }
    figure(cx, base + s * .2f, s * 1.05f, AgwColors.SacredGold, AgwColors.GoldSoft, AgwColors.DeepNight, a)
}
