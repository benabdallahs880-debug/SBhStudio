package com.sbh.studio.workshop

import android.content.Context
import com.sbh.studio.data.MobEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import com.sbh.studio.system.SystemPaths
import java.io.File

/**
 * Construit une scène jouable (placements.json + protocol.json) à partir
 * d'une structure voxel + mobs.
 *
 * Écriture multi-cibles pour maximiser la chance que Godot (user://) ou un
 * outil externe retrouve les fichiers :
 *  1. context.filesDir/studio_import/sbh/          (interne app Studio)
 *  2. context.getExternalFilesDir()/studio_import/sbh/  (visible, partageable)
 *
 * Les écritures sont atomiques (.tmp puis rename).
 */
object PlayableSceneBuilder {

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    @Serializable
    data class PlacementBlock(val x: Int, val y: Int, val z: Int, val identifier: String)

    @Serializable
    data class PlacementMob(val x: Int, val y: Int, val z: Int, val identifier: String)

    @Serializable
    data class SpawnPoint(val x: Int, val y: Int, val z: Int)

    @Serializable
    data class PlacementsFile(
        val blocks: List<PlacementBlock> = emptyList(),
        val mobs: List<PlacementMob> = emptyList(),
        val spawn: SpawnPoint? = null,
        val structureId: String = "",
        val structureName: String = ""
    )

    @Serializable
    data class ProtocolFile(
        val protocol: String = "SBH",
        val protocolVersion: String = "1.0",
        val exportId: String,
        val projectId: String,
        val projectName: String,
        val projectVersion: String = "1.0.0",
        val projectType: String = "SBh World Playable",
        val studioVersion: String = "1.8.18",
        val generatedAtMs: Long = System.currentTimeMillis(),
        val target: String = "sbh_world",
        val compatibleTargets: List<String> = listOf("sbh_world", "minecraft_bedrock")
    )

    data class BuildResult(
        val ok: Boolean,
        val message: String,
        val blocksCount: Int = 0,
        val mobsCount: Int = 0,
        val exportDirs: List<File> = emptyList()
    )

    fun importDirInternal(context: Context): File = SystemPaths.studioImportInternal(context)

    fun importDirExternal(context: Context): File? = SystemPaths.studioImportExternal(context)

    fun allImportDirs(context: Context): List<File> = SystemPaths.allStudioImportDirs(context)

    private fun writeAtomic(dir: File, name: String, content: String) {
        dir.mkdirs()
        val target = File(dir, name)
        val tmp = File(dir, "$name.tmp")
        tmp.writeText(content)
        if (!tmp.renameTo(target)) {
            target.delete()
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
    }

    fun buildVillageForge(
        context: Context,
        projectId: String,
        projectName: String,
        structure: StructureLoader.StructureDef,
        originX: Int = 4,
        originY: Int = 1,
        originZ: Int = 4,
        mobs: List<MobEntity> = emptyList()
    ): BuildResult {
        return try {
            val blocks = structure.blocks.map { b ->
                val name = structure.palette.getOrNull(b.state)?.Name ?: "minecraft:stone"
                PlacementBlock(
                    x = originX + b.x,
                    y = originY + b.y,
                    z = originZ + b.z,
                    identifier = name
                )
            }

            val forgeMobs = mobs.mapIndexed { i, m ->
                PlacementMob(
                    x = originX + structure.size.x / 2 + i,
                    y = originY + 1,
                    z = originZ + structure.size.z + 2,
                    identifier = m.identifiant.ifBlank { "agw:forgeron_village" }
                )
            }.ifEmpty {
                listOf(
                    PlacementMob(
                        x = originX + structure.size.x / 2,
                        y = originY + 1,
                        z = originZ + structure.size.z + 2,
                        identifier = "agw:forgeron_village"
                    )
                )
            }

            val spawn = SpawnPoint(
                x = originX + structure.size.x / 2,
                y = originY + 2,
                z = originZ + structure.size.z + 6
            )

            val placements = PlacementsFile(
                blocks = blocks,
                mobs = forgeMobs,
                spawn = spawn,
                structureId = structure.id,
                structureName = structure.name
            )

            val protocol = ProtocolFile(
                exportId = "SBH-PLAYABLE-${System.currentTimeMillis() % 1000000}",
                projectId = projectId,
                projectName = projectName
            )

            val placementsJson = json.encodeToString(placements)
            val protocolJson = json.encodeToString(protocol)
            val refJson =
                """{"id":"${structure.id}","name":"${structure.name}","size":{"x":${structure.size.x},"y":${structure.size.y},"z":${structure.size.z}},"blockCount":${structure.blocks.size}}"""

            val dirs = allImportDirs(context)
            if (dirs.isEmpty()) {
                return BuildResult(false, "Aucun dossier d'export accessible")
            }
            for (dir in dirs) {
                writeAtomic(dir, "placements.json", placementsJson)
                writeAtomic(dir, "protocol.json", protocolJson)
                writeAtomic(dir, "structure_ref.json", refJson)
            }

            val pathsHint = dirs.joinToString(" | ") { it.absolutePath }
            BuildResult(
                ok = true,
                message = "Scène jouable : ${blocks.size} blocs, ${forgeMobs.size} mob(s), spawn (${spawn.x},${spawn.y},${spawn.z}). Export : $pathsHint",
                blocksCount = blocks.size,
                mobsCount = forgeMobs.size,
                exportDirs = dirs
            )
        } catch (e: Exception) {
            BuildResult(ok = false, message = "Échec construction scène : ${e.message}")
        }
    }

    fun buildDefaultForgeScene(
        context: Context,
        projectId: String,
        projectName: String,
        mobs: List<MobEntity> = emptyList()
    ): BuildResult {
        val structure = StructureLoader.loadFromAssets(
            context,
            SystemPaths.ASSET_FORGE_STRUCTURE
        ) ?: return BuildResult(false, "Structure maison_forgeron introuvable dans les assets")
        return buildVillageForge(context, projectId, projectName, structure, mobs = mobs)
    }
}
