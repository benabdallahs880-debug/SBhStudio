package com.sbh.studio.system

import android.content.Context

/**
 * Façade unique « système supérieur » :
 * - déblocage (SystemUnlock)
 * - analyses (SystemAnalysis)
 * - chemins (SystemPaths)
 *
 * UI / Atelier / Update doivent passer par ici plutôt que d'importer
 * SbhKeyManager / AppDiagnostic / chemins en dur.
 */
class SystemHub(private val context: Context) {

    val analysis: SystemAnalysis by lazy { SystemAnalysis(context) }

    fun isUnlocked(): Boolean = SystemUnlock.isUnlocked(context)

    fun tryUnlock(key: String): SystemUnlock.UnlockResult =
        SystemUnlock.tryUnlock(context, key)

    fun lock() = SystemUnlock.lock(context)

    fun isManualUpdateAllowed(): Boolean =
        SystemUnlock.isFeatureEnabled(context, SystemUnlock.Feature.MANUAL_UPDATE)

    fun studioImportDirs() = SystemPaths.allStudioImportDirs(context)

    suspend fun fullReport() = analysis.runFull()

    fun localReport() = analysis.runLocal()
}
