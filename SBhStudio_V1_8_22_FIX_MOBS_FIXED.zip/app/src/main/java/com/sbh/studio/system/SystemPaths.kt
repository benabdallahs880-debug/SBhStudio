package com.sbh.studio.system

import android.content.Context
import java.io.File

/**
 * Chemins centralisés SBh Studio (atelier, runtime, diagnostics).
 * Un seul endroit pour savoir où lit/écrit le système.
 */
object SystemPaths {

    const val STUDIO_IMPORT_REL = "studio_import/sbh"
    const val DIAGNOSTICS_REL = "diagnostics"

    fun filesRoot(context: Context): File = context.filesDir

    fun studioImportInternal(context: Context): File =
        File(context.filesDir, STUDIO_IMPORT_REL).also { it.mkdirs() }

    fun studioImportExternal(context: Context): File? =
        context.getExternalFilesDir(null)?.let { File(it, STUDIO_IMPORT_REL).also { d -> d.mkdirs() } }

    fun allStudioImportDirs(context: Context): List<File> =
        listOfNotNull(studioImportInternal(context), studioImportExternal(context))

    fun placementsFile(dir: File): File = File(dir, "placements.json")
    fun protocolFile(dir: File): File = File(dir, "protocol.json")
    fun structureRefFile(dir: File): File = File(dir, "structure_ref.json")

    fun diagnosticsDir(context: Context): File =
        File(context.filesDir, DIAGNOSTICS_REL).also { it.mkdirs() }

    fun runtimeErrorsFile(context: Context): File =
        File(diagnosticsDir(context), "runtime_errors.json")

    fun runtimeEventsFile(context: Context): File =
        File(diagnosticsDir(context), "runtime_events.log")

    /** Asset structure forge embarquée. */
    const val ASSET_FORGE_STRUCTURE = "structures/structure_maison_forgeron.json"
}
