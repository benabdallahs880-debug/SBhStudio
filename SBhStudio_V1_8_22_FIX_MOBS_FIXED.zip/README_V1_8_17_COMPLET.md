# SBh Studio V1.8.17 — Version complète

Toutes les modifications ajoutées depuis le début de la session, dans un seul projet.

## Contenu livré (récapitulatif)

### 1. Template « Maison de forgeron » (Hub)
- Carte template dans Atelier → Hub
- Crée : map village, forgeron, 3 items, 2 blocs custom
- Déclenche aussi l’export scène jouable

### 2. Structure voxel embarquée
- `app/src/main/assets/structures/structure_maison_forgeron.json`
- 15×12×20, 597 blocs non-air (converti depuis le NBT d’origine)

### 3. Éditeur 3D
- Menu ＋ → 📦 Maison de forgeron (asset)
- Menu ＋ → 📂 Importer .nbt / .json…
- Chargement auto des cubes colorés + cadrage caméra
- Ouverture depuis ▶ Tester avec structure préchargée

### 4. Zone Maps
- Aperçu silhouette forge si structure rattachée
- Bouton « Placer la structure · Maison de forgeron »
- Bouton « Importer un fichier .nbt / .json… »
- Bouton « ▶ Tester cette map » si forge présente

### 5. Support NBT natif
- `NbtStructureParser.kt` — parseur pur Kotlin (gzip + brut)
- `StructureLoader.kt` — JSON + NBT + fichiers + streams

### 6. Parcours jouable (moteur à 100 %)
- `PlayableSceneBuilder.kt` → `filesDir/studio_import/sbh/`
  - protocol.json
  - placements.json (blocs + mobs + spawn)
  - structure_ref.json
- Bouton **▶ Tester le village forge** (Hub + Maps)
- Godot : BLOCK_MAP élargi + spawn lu depuis placements.json

## Fichiers nouveaux
```
app/src/main/java/com/sbh/studio/workshop/StructureLoader.kt
app/src/main/java/com/sbh/studio/workshop/NbtStructureParser.kt
app/src/main/java/com/sbh/studio/workshop/PlayableSceneBuilder.kt
app/src/main/assets/structures/structure_maison_forgeron.json
```

## Fichiers modifiés (principaux)
```
workshop/HubZone.kt
workshop/WorkshopScreen.kt
workshop/Editor3DScreen.kt
workshop/MapZone.kt
world/SBH_World/scripts/adapters/placement_adapter.gd
world/SBH_World/scripts/main.gd
version.json → 1.8.17 (versionCode 52)
```

## Parcours recommandé
1. Ouvrir un projet
2. Atelier → Hub → **Maison de forgeron**
3. **▶ Tester le village forge**
4. Vérifier l’Éditeur 3D + dossier `studio_import/sbh/`
5. Lancer SBH World (Godot) pour le placement runtime

## Build
```bash
./gradlew assembleDebug
```
