# SBh Studio V1.8.22 — Version complète de session

Projet Android + runtime Godot avec **tous les ajouts** de la session.

## Contenu ajouté

### Atelier / structures
- Template Hub **Maison de forgeron**
- Asset `structures/structure_maison_forgeron.json` (15×12×20, 597 blocs)
- `StructureLoader` + `NbtStructureParser` (JSON + NBT magic bytes)
- Éditeur 3D : chargement structure, import fichier, messages status, parse hors UI, LOD
- Maps : aperçu, placer structure, import, ▶ Tester
- `PlayableSceneBuilder` → `studio_import/sbh/` (interne + externe, écriture atomique)
- Bouton **▶ Tester le village forge** (Hub + Maps)

### Module system (`com.sbh.studio.system`)
- `SystemHub` — façade
- `SystemUnlock` — déblocage + **migration prefs**
- `SystemAnalysis` — diagnostics enrichis
- `SystemPaths` — chemins centralisés
- `SystemLog` — logger Logcat + fichier
- `SbhKeyManager` — compat (délègue à SystemUnlock)

### Godot SBH World
- Placement **bulk** (`set_block_silent` + `flush_dirty_chunks`)
- Collisions par colonne si chunk dense
- **Greedy meshing** des faces

### Docs
- `docs/changelog/` — historiques
- `docs/system/` — module système

## Non inclus / limites
- Clé unlock encore en clair dans l’APK (dev)
- Pont auto Android filesDir → Godot user:// si **apps séparées** (copie manuelle possible)
- Pas de tests UI automatisés device dans ce ZIP
- Rendu Éditeur 3D = software Compose (LOD, pas GPU native)

## Build
```bash
./gradlew assembleDebug
```
