# SBh Studio V1.8.18 — Correctifs prioritaires (audit)

## CRIT-01 — Export scène jouable
- Écriture **atomique** (`.tmp` → rename)
- **Deux cibles** : `filesDir/studio_import/sbh/` + `getExternalFilesDir()/studio_import/sbh/`
- Message avec chemins absolus
- Godot : recherche élargie des `placements.json` + logs

> Pour un Godot **séparé**, copier le dossier `studio_import/sbh` vers `user://studio_import/sbh` du runtime.

## MAJ-01 / MAJ-02 — Import NBT
- Détection par **magic bytes** (`1f 8b` gzip, `0x0a` compound, `{` JSON)
- Moins dépendant de l’extension `content://`
- Messages d’état visibles dans l’Éditeur 3D (succès / échec / annulé)

## MAJ-03 / MAJ-04 — Perf
- Parse + conversion voxels sur **Dispatchers.IO / Default**
- Undo limité à **12** niveaux si > 200 objets (anti-OOM)

## MAJ-05 — UpdateScreen
- `report!!` remplacé par accès null-safe

## Non traité dans ce patch
- CRIT-02 clé update en clair (changement produit / backend)
- Rendu 700 cubes (LOD / chunks — étape suivante)
