# SBh Studio V1.8.14 — Aperçus réels dans l'Atelier

## Problème
Le cadre « Aperçu visuel » affichait presque toujours le même cube doré / bonhomme, avec un badge « EN DIRECT » permanent.

## Changements (VisualWorkshopPreview.kt)
- Scène commune : ciel, horizon, sol en perspective avec ombre (plan à plat pour carte / son).
- Bloc : cube isométrique, couleur stable issue de l'identifiant, dureté affichée.
- Objet : épée dont la lame suit les dégâts ; durabilité affichée.
- Créature : silhouette voxel dont la taille suit la collision (hauteur/largeur), rouge si hostile, semi-transparente si invisible ; vie / dégâts / vitesse affichés.
- Carte : vue de dessus aux proportions réelles (terrain, village, donjon, oasis, montagnes, routes), stable grâce à la seed.
- Recette : vraie grille 3×3 (shaped) ou liste d'ingrédients, flèche, résultat × quantité.
- Portail : cadre aux vraies dimensions, surface violette.
- Son : forme d'onde stable + bouton lecture, catégorie, durée, dans le pack ou non.
- Jeu : joueur, factions, bâtiments selon les missions, taille du monde.
- Sans élément : fantôme + message clair, badge « VIDE » (au lieu de « EN DIRECT »).
- Puces de sélection ajoutées pour recettes, portails, sons et jeux.

## Non testé ici
Compilation non exécutée dans l'environnement de rédaction (pas de SDK Android) : à valider par le workflow GitHub build-apk.
