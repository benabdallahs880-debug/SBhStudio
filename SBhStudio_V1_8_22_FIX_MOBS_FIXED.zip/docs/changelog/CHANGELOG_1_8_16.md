# SBh Studio V1.8.16 — Structures + NBT

## Installé dans cette version

### 1. Template « Maison de forgeron »
- Atelier → Hub → Templates prêts à l'emploi
- Crée map village + forgeron + 3 items + 2 blocs custom
- Structure voxel embarquée (15×12×20, 597 blocs)

### 2. Structures dans l'Éditeur 3D
- Menu ＋ → 📦 Maison de forgeron (asset intégré)
- Menu ＋ → 📂 Importer .nbt / .json… (fichier externe)
- Cubes colorés selon le type de bloc, caméra cadrée

### 3. Zone Maps
- Aperçu silhouette forge quand structure rattachée
- Bouton « Placer la structure · Maison de forgeron »
- Bouton « Importer un fichier .nbt / .json… »

### 4. Support NBT natif
- `NbtStructureParser.kt` — parseur pur Kotlin (gzip + brut)
- `StructureLoader` unifié JSON + NBT + streams/fichiers

## Fichiers nouveaux / modifiés
- workshop/HubZone.kt
- workshop/WorkshopScreen.kt
- workshop/Editor3DScreen.kt
- workshop/MapZone.kt
- workshop/StructureLoader.kt (nouveau)
- workshop/NbtStructureParser.kt (nouveau)
- assets/structures/structure_maison_forgeron.json (nouveau)
