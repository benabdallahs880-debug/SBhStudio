# SBh Studio — Template « Maison de forgeron »

## Ajout
Nouveau template prêt à l'emploi dans l'Atelier (Hub).

### Accès
Atelier → Hub → section « Templates prêts à l'emploi » → **Maison de forgeron**

### Ce que le template crée
- 1 **MapBlueprint** « Village · Maison du forgeron » (32×32, thème village / plains)
- 1 **Mob** : Forgeron du village (`agw:forgeron_village`) — pacifique
- 3 **Items** :
  - Marteau de forgeron
  - Lingot de fer raffiné
  - Kit de réparation
- 2 **Blocs custom** :
  - Pierre de forge
  - Brique de fourneau
- Référence à la structure voxel embarquée (15×12×20, 597 blocs non-air)

### Fichier structure
`app/src/main/assets/structures/structure_maison_forgeron.json`

Format :
```json
{
  "id": "maison_forgeron",
  "name": "Maison de forgeron",
  "size": {"x": 15, "y": 12, "z": 20},
  "palette": [ ... ],
  "blocks": [ {"x":.., "y":.., "z":.., "state": index}, ... ]
}
```

### Origine
Converti depuis le fichier NBT Minecraft `frm_struct_RA6V_Maison_de_forgeron.nbt`.

### Prochaines étapes possibles
- Charger réellement les blocs de la structure dans l'Éditeur 3D / Map Studio
- Afficher un aperçu 3D de la forge dans la carte template
- Bouton « Placer la structure » dans MapZone
