# SBh Studio — Structures voxel dans l'Éditeur 3D & Maps

## Nouveautés

### 1. Chargement réel des 597 blocs dans l'Éditeur 3D
- Menu **＋ Ajouter** → entrée **📦 Maison de forgeron**
- Charge la structure depuis `assets/structures/structure_maison_forgeron.json`
- Chaque bloc non-air devient un cube coloré (teinte selon le type de bloc)
- Caméra cadrée automatiquement sur la structure
- Limite de sécurité : 700 objets max (performance rendu logiciel)

### 2. Aperçu de la forge sur la carte template / Map
- Dans **MapZone**, si la map a la structure rattachée :
  - Aperçu Canvas affiche une **silhouette de maison + cheminée**
  - Badge « Structure embarquée : Maison de forgeron (15×12×20) »

### 3. Bouton « Placer la structure » dans Maps
- Sur chaque carte de map : bouton **📦 Placer la structure · Maison de forgeron**
- Ajoute la référence dans les notes de la map + force `hasVillage = true`
- Le bouton passe en état « ✓ Structure forge rattachée » une fois placée

## Fichiers concernés
- `StructureLoader.kt` (nouveau)
- `Editor3DScreen.kt` (menu + loadStructure)
- `MapZone.kt` (aperçu + bouton)
- `assets/structures/structure_maison_forgeron.json`

## Utilisation
1. Atelier → Hub → appliquer le template « Maison de forgeron » (crée map + contenus)
2. Atelier → Maps → sur la map créée → « Placer la structure »
3. Atelier → Entités 3D → « Ouvrir l'Éditeur 3D » → ＋ → 📦 Maison de forgeron
