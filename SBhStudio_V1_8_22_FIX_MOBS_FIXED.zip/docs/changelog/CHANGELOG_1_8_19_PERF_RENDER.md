# SBh Studio V1.8.19 — Perf rendu structures

## Problème
~700 cubes en mesh complet + ombre 20 segments + tri + contours = FPS très bas.

## Solutions
1. **Culling** : ignore objets derrière la caméra ou z > 55
2. **Cap de dessin** : max ~420 objets/frame (les plus proches)
3. **LOD cubes**
   - loin (z > 22) : billboard carré écran
   - moyen (z > 10) : 1 face orientée caméra
   - proche / sélectionné : mesh complet
4. **Ombres** : désactivées en scène lourde sauf sélection ; 8 segments si présentes
5. **Contours** : uniquement scène légère ou sélection
6. **Pick** : limite z + hit un peu élargi en scène dense

## Résultat attendu
La forge (~597 blocs) reste navigable (orbite / zoom) sur téléphone milieu de gamme.
