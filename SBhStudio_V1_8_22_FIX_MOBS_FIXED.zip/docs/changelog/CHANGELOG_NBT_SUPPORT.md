# SBh Studio — Support natif des fichiers NBT

## Ce qui est ajouté

### Parseur NBT pur Kotlin
- Fichier : `NbtStructureParser.kt`
- Lit les fichiers de structure Minecraft (`.nbt` gzip ou non compressés)
- Tags supportés : Compound, List, IntArray, String, Int, Byte, Short…
- Convertit automatiquement en `StructureDef` (même format que le JSON interne)
- Ignore les blocs `minecraft:air` pour alléger

### StructureLoader enrichi
- `loadFromFile(File)`
- `loadFromBytes(ByteArray, name, extension)`
- `loadFromStream(InputStream, name, extension)`
- Détection auto JSON vs NBT

### Éditeur 3D
Menu **＋** → **📂 Importer .nbt / .json…**
- Ouvre le sélecteur de fichiers système
- Parse le NBT → génère les cubes colorés
- Cadre la caméra sur la structure

### Zone Maps
Sur chaque map :
- **📂 Importer un fichier .nbt / .json…**
- Attache la structure aux notes de la map
- Message de confirmation (nombre de blocs, dimensions)

## Formats acceptés
| Extension | Support |
|-----------|---------|
| `.nbt` (gzip, cas standard Minecraft) | ✅ |
| `.nbt` (non compressé) | ✅ |
| `.json` (format SBh StructureDef) | ✅ |

## Limites actuelles
- Rendu Éditeur 3D : max ~800 blocs (performance Compose)
- Les propriétés complexes (orientation fine des stairs, waterlogged…) sont lues mais le rendu 3D reste en cubes simples colorés
- Pas encore d’export NBT (uniquement import)

## Fichiers
- `NbtStructureParser.kt` (nouveau)
- `StructureLoader.kt` (étendu)
- `Editor3DScreen.kt` (menu import)
- `MapZone.kt` (bouton import par map)
