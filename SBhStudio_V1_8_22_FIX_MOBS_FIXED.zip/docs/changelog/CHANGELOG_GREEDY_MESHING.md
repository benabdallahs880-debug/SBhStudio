# SBH World — Greedy meshing

## Principe
Au lieu d’émettre 2 triangles par face de voxel exposée, on fusionne les faces
**coplanaires**, **adjacentes** et du **même type de bloc** en grands quads.

## Algorithme (par chunk)
Pour chaque axe (X, Y, Z) et chaque sens (±) :
1. Pour chaque tranche perpendiculaire à l’axe, construire un masque 2D
   (id du bloc si face exposée, sinon 0)
2. Parcourir le masque et étendre en largeur puis hauteur tant que le type est identique
3. Émettre un quad (2 triangles) pour chaque rectangle fusionné

## Impact
- Sol plat 16×16 : **1 quad** au lieu de 256 faces
- Murs / toits de la forge : fortement réduits en nombre de triangles
- Combiné au placement bulk (1.8.20) : import + rendu beaucoup plus légers

## Fichier
`world/SBH_World/scripts/chunk.gd` → `_rebuild_mesh_greedy()`
