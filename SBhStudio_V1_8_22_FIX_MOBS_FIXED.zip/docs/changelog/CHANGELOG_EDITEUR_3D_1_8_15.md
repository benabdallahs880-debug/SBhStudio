# SBh Studio V1.8.15 — Éditeur 3D plein écran

## Accès
Atelier → onglet « Entités 3D » → bouton « Ouvrir l'Éditeur 3D plein écran ».

## Ce que ça fait
- La scène occupe tout l'écran (ciel, sol, grille au mètre, axes X rouge / Z bleu, ombres portées, éclairage).
- Formes de base : Cube, Sphère, Cylindre (menu « + Ajouter »). Une scène de départ contient un cube et un cylindre.
- Sélection en touchant un objet : contour orange, nom en haut, position X / Y / Z en cm.
- Barre du bas : Ajouter, Déplacer, Tourner, Échelle, Couleur, Dupliquer, Supprimer.
- Déplacer : glisser une flèche (axe) ou le corps de l'objet (plan du sol). Tourner : glisser sur l'objet. Échelle : glisser une poignée.
- Caméra : 1 doigt = orbite, 2 doigts = zoom.
- Annuler / rétablir (60 niveaux), liste des objets de la scène (≡).
- Sauvegarde automatique par projet (filesDir/sbh_editor3d_<projet>.json).

## Choix technique
Rendu 3D calculé dans Compose (perspective, culling, éclairage) : aucune dépendance ajoutée.
Prochaine étape : afficher les .glb dans cette même scène (moteur Filament de Character Studio) et ▶ Jouer.

## Non testé ici
Compilation non exécutée dans l'environnement de rédaction : à valider par le workflow GitHub build-apk.
