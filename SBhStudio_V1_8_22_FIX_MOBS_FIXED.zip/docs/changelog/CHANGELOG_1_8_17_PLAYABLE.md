# SBh Studio V1.8.17 — Parcours jouable « Village forge »

## Objectif
Utiliser le moteur à 100 % sur un scénario de bout en bout :
**template → structure posée → forgeron → spawn → ▶ Tester**.

## Chaîne
1. **Hub** → template « Maison de forgeron »
   - Crée map + mobs + items + blocs
   - Écrit automatiquement `filesDir/studio_import/sbh/placements.json` + `protocol.json`
2. **Hub / Maps** → **▶ Tester le village forge**
   - Régénère les placements
   - Ouvre l’Éditeur 3D avec les ~597 blocs chargés
3. **Runtime Godot** (SBH World)
   - Lit `user://studio_import/sbh/placements.json`
   - Place les blocs (BLOCK_MAP élargi)
   - Marqueurs mobs (forgeron)
   - Spawn joueur depuis le champ `spawn`

## Fichiers nouveaux / modifiés
- `workshop/PlayableSceneBuilder.kt` (nouveau)
- `workshop/WorkshopScreen.kt` — applyTemplate + playVillageForge
- `workshop/HubZone.kt` — bouton ▶ Tester
- `workshop/MapZone.kt` — bouton ▶ Tester si structure rattachée
- `workshop/Editor3DScreen.kt` — `loadStructureAsset`
- `world/.../placement_adapter.gd` — mapping minecraft:* de la forge
- `world/.../main.gd` — spawn depuis placements.json

## Dossier export runtime
```
filesDir/studio_import/sbh/
  protocol.json
  placements.json   ← blocks + mobs + spawn
  structure_ref.json
```
