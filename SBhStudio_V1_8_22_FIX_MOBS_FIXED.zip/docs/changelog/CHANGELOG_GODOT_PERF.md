# SBH World — Optimisations performances Godot

## Problème
`set_block()` reconstruisait le mesh **et les 8 voisins** à **chaque** bloc.
Importer la forge (~597 blocs) ≈ milliers de rebuilds → freeze.

## Correctifs

### world.gd
- `set_block_silent()` : écrit sans rebuild
- `flush_dirty_chunks()` : un rebuild par chunk touché
- `set_blocks_bulk()` : API pratique pour imports
- Création auto de chunks manquants à l’écriture
- Marquage dirty **uniquement** bord de chunk pour voisins

### chunk.gd
- Matériau **partagé** (vertex colors)
- Collision :
  - ≤ 48 blocs → 1 box / bloc (précis)
  - > 48 blocs → 1 box / **colonne** (x,z) minY–maxY (beaucoup moins de shapes)

### placement_adapter.gd
- Import structure en `set_block_silent` + **un** `flush_dirty_chunks()`
- Revert précédent aussi en bulk

## Gain attendu
Import forge : de « plusieurs secondes / freeze » → rebuild de quelques chunks seulement (typiquement 1–4).
