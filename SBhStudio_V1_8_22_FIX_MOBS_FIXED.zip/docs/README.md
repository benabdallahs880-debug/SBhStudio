# Documentation SBh Studio

## Système
- [Module système (unlock + analyses)](system/README.md)
- [Mise à jour manuelle](MANUAL_UPDATE_PACK.md)

## Historique des versions
Voir [changelog/](changelog/) — tous les CHANGELOG_*.md y sont rangés.

## Parcours jouable
Template Maison de forgeron → ▶ Tester → `studio_import/sbh/` → runtime Godot (bulk + greedy mesh).
