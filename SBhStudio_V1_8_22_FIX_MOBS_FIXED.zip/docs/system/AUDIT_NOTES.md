# Notes d'analyse — points encore fragiles

## Corrigé / rangé dans 1.8.22
- Unlock + analyses + chemins regroupés dans `com.sbh.studio.system`
- Migration prefs legacy `sbh_studio_security` → `sbh_system_unlock`
- Diagnostic enrichi : unlock, studio_import, asset forge
- Changelogs déplacés dans `docs/changelog/`

## Encore à surveiller
1. **Clé de dev dans l'APK** — acceptable en debug ; dangereux en release publique
2. **Godot user:// vs filesDir** — toujours deux espaces si apps séparées
3. **Exceptions avalées** nombreuses hors module system
4. **GoldPrimaryButton** parfois positionnel / nommé (OK Kotlin, style inégal)
5. **Editor3D** 700 cubes : LOD présent, pas encore de chunks Compose

## Travail mal fait évité
- Ne plus ajouter de chemins `studio_import` en dur
- Ne plus lire/écrire la clé hors `SystemUnlock`
- Ne plus lancer un diagnostic « complet » sans passer par `SystemAnalysis` si on veut les checks structure
