# Module système unifié (`com.sbh.studio.system`)

## Rôle
Regroupe **déblocage**, **analyses** et **chemins** au même endroit.

| Classe | Responsabilité |
|--------|----------------|
| `SystemHub` | Façade unique pour l'UI |
| `SystemUnlock` | Clés / features avancées |
| `SystemAnalysis` | Diagnostics + contrôles structure / import |
| `SystemPaths` | Chemins `studio_import`, diagnostics, assets |

## Compatibilité
- `SbhKeyManager` délègue à `SystemUnlock` (déprécié)
- `AppDiagnostic` reste le moteur bas niveau ; `SystemAnalysis` l'enrichit

## Usage recommandé
```kotlin
val hub = SystemHub(context)
hub.tryUnlock(key)
hub.localReport()
hub.studioImportDirs()
```
