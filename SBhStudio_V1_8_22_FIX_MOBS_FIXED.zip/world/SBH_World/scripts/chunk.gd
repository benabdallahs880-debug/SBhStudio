class_name SBHChunk
extends Node3D
## Chunk voxel 16×16 avec greedy meshing (fusion de faces coplanaires / même type).
## Collisions : 1 box/bloc si peu de blocs, sinon 1 box/colonne.

const SIZE := 16
const MAX_Y := 64

var blocks: Dictionary = {}
var mesh_instance: MeshInstance3D
var collision_body: StaticBody3D
var world_ref: SBHWorld = null
var chunk_coord: Vector2i = Vector2i.ZERO

static var _shared_mat: StandardMaterial3D = null


func _ready() -> void:
	mesh_instance = MeshInstance3D.new()
	mesh_instance.name = "Mesh"
	add_child(mesh_instance)
	collision_body = StaticBody3D.new()
	collision_body.name = "Collision"
	CollisionLayers.setup_world_body(collision_body)
	add_child(collision_body)
	if _shared_mat == null:
		_shared_mat = StandardMaterial3D.new()
		_shared_mat.vertex_color_use_as_albedo = true
		_shared_mat.roughness = 0.9


func set_block(local_pos: Vector3i, id: int) -> void:
	if id == BlockTypes.Type.AIR:
		blocks.erase(local_pos)
	else:
		blocks[local_pos] = id


func get_block(local_pos: Vector3i) -> int:
	return int(blocks.get(local_pos, BlockTypes.Type.AIR))


## Bloc en coordonnées locales étendues (peut sortir du chunk → monde).
func _get_block_world_local(lx: int, ly: int, lz: int) -> int:
	if ly < 0 or ly >= MAX_Y:
		return BlockTypes.Type.AIR
	if lx >= 0 and lx < SIZE and lz >= 0 and lz < SIZE:
		return get_block(Vector3i(lx, ly, lz))
	if world_ref == null:
		return BlockTypes.Type.AIR
	var wx := chunk_coord.x * SIZE + lx
	var wz := chunk_coord.y * SIZE + lz
	return world_ref.get_block(Vector3i(wx, ly, wz))


func rebuild() -> void:
	if mesh_instance == null or collision_body == null:
		return
	_rebuild_mesh_greedy()
	_rebuild_collision()


# ───────────────────────── Greedy meshing ─────────────────────────

func _rebuild_mesh_greedy() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	if blocks.is_empty():
		mesh_instance.mesh = st.commit()
		return

	# Hauteur utile
	var y_max := 0
	for p in blocks.keys():
		if p.y > y_max:
			y_max = p.y
	y_max = mini(y_max + 1, MAX_Y)

	# 3 axes × 2 sens : (axis, positive_side)
	# axis 0 = X, 1 = Y, 2 = Z
	for axis in range(3):
		_greedy_axis(st, axis, true, y_max)
		_greedy_axis(st, axis, false, y_max)

	var mesh := st.commit()
	mesh_instance.mesh = mesh
	if mesh != null and _shared_mat != null:
		mesh_instance.material_override = _shared_mat


## Greedy meshing sur les faces perpendiculaires à `axis`.
func _greedy_axis(st: SurfaceTool, axis: int, positive: bool, y_max: int) -> void:
	# Dimensions du plan de coupe (u, v) et plage de slices (w)
	var dims := [SIZE, y_max, SIZE] # x, y, z
	var u_axis := (axis + 1) % 3
	var v_axis := (axis + 2) % 3
	var u_size: int = dims[u_axis]
	var v_size: int = dims[v_axis]
	var w_size: int = dims[axis]

	var mask := PackedInt32Array()
	mask.resize(u_size * v_size)

	var normal := Vector3.ZERO
	normal[axis] = 1.0 if positive else -1.0

	for w in range(w_size):
		# 1) Remplir le masque : type de bloc si face exposée, sinon 0
		for v in range(v_size):
			for u in range(u_size):
				var coord := _slice_to_xyz(axis, w, u, v)
				var id := _get_block_world_local(coord.x, coord.y, coord.z)
				var idx := u + v * u_size
				if id == BlockTypes.Type.AIR:
					mask[idx] = 0
					continue
				var nx := coord.x
				var ny := coord.y
				var nz := coord.z
				if axis == 0:
					nx += 1 if positive else -1
				elif axis == 1:
					ny += 1 if positive else -1
				else:
					nz += 1 if positive else -1
				var neighbor := _get_block_world_local(nx, ny, nz)
				if neighbor != BlockTypes.Type.AIR:
					mask[idx] = 0
				else:
					mask[idx] = id

		# 2) Fusion greedy sur le masque 2D
		var v := 0
		while v < v_size:
			var u := 0
			while u < u_size:
				var idx := u + v * u_size
				var type_id: int = mask[idx]
				if type_id == 0:
					u += 1
					continue
				# Étendue en largeur (u)
				var width := 1
				while u + width < u_size and mask[u + width + v * u_size] == type_id:
					width += 1
				# Étendue en hauteur (v)
				var height := 1
				var done := false
				while v + height < v_size and not done:
					for du in range(width):
						if mask[u + du + (v + height) * u_size] != type_id:
							done = true
							break
					if not done:
						height += 1
				# Marquer consommé
				for dv in range(height):
					for du in range(width):
						mask[u + du + (v + dv) * u_size] = 0
				# Émettre le quad
				_emit_quad(st, axis, positive, w, u, v, width, height, type_id, normal)
				u += width
			v += 1


func _slice_to_xyz(axis: int, w: int, u: int, v: int) -> Vector3i:
	# u suit le premier axe perpendiculaire, v le second
	# axis X(0): u=Y, v=Z
	# axis Y(1): u=Z, v=X
	# axis Z(2): u=X, v=Y
	match axis:
		0:
			return Vector3i(w, u, v)
		1:
			return Vector3i(v, w, u)
		_:
			return Vector3i(u, v, w)


func _emit_quad(
	st: SurfaceTool,
	axis: int,
	positive: bool,
	w: int,
	u0: int,
	v0: int,
	width: int,
	height: int,
	type_id: int,
	normal: Vector3
) -> void:
	# Coin origin du quad en coordonnées locales chunk
	# La face se place sur le bord du voxel (w ou w+1)
	var plane := float(w + 1) if positive else float(w)
	var col := BlockTypes.color(type_id)

	var p0 := Vector3.ZERO
	var p1 := Vector3.ZERO
	var p2 := Vector3.ZERO
	var p3 := Vector3.ZERO

	match axis:
		0: # face ±X : u=Y, v=Z
			p0 = Vector3(plane, float(u0), float(v0))
			p1 = Vector3(plane, float(u0 + width), float(v0))
			p2 = Vector3(plane, float(u0 + width), float(v0 + height))
			p3 = Vector3(plane, float(u0), float(v0 + height))
		1: # face ±Y : u=Z, v=X
			p0 = Vector3(float(v0), plane, float(u0))
			p1 = Vector3(float(v0 + height), plane, float(u0))
			p2 = Vector3(float(v0 + height), plane, float(u0 + width))
			p3 = Vector3(float(v0), plane, float(u0 + width))
		2: # face ±Z : u=X, v=Y
			p0 = Vector3(float(u0), float(v0), plane)
			p1 = Vector3(float(u0 + width), float(v0), plane)
			p2 = Vector3(float(u0 + width), float(v0 + height), plane)
			p3 = Vector3(float(u0), float(v0 + height), plane)

	# Ordre des sommets selon le sens de la normale (winding)
	var a: Vector3
	var b: Vector3
	var c: Vector3
	var d: Vector3
	if positive:
		a = p0
		b = p1
		c = p2
		d = p3
	else:
		a = p0
		b = p3
		c = p2
		d = p1

	for tri in [[a, b, c], [a, c, d]]:
		for vtx in tri:
			st.set_normal(normal)
			st.set_color(col)
			st.set_uv(Vector2.ZERO)
			st.add_vertex(vtx)


# ───────────────────────── Collisions ─────────────────────────

func _rebuild_collision() -> void:
	for child in collision_body.get_children():
		child.queue_free()

	var count := blocks.size()
	if count <= 48:
		for p in blocks.keys():
			var id: int = blocks[p]
			if not BlockTypes.is_solid(id):
				continue
			var shape := BoxShape3D.new()
			shape.size = Vector3.ONE
			var cs := CollisionShape3D.new()
			cs.shape = shape
			cs.position = Vector3(p) + Vector3(0.5, 0.5, 0.5)
			collision_body.add_child(cs)
		return

	var cols: Dictionary = {}
	for p in blocks.keys():
		var id: int = blocks[p]
		if not BlockTypes.is_solid(id):
			continue
		var key := Vector2i(p.x, p.z)
		if not cols.has(key):
			cols[key] = Vector2i(p.y, p.y)
		else:
			var mm: Vector2i = cols[key]
			mm.x = mini(mm.x, p.y)
			mm.y = maxi(mm.y, p.y)
			cols[key] = mm

	for key in cols.keys():
		var mm: Vector2i = cols[key]
		var h := float(mm.y - mm.x + 1)
		var shape := BoxShape3D.new()
		shape.size = Vector3(1.0, h, 1.0)
		var cs := CollisionShape3D.new()
		cs.shape = shape
		cs.position = Vector3(float(key.x) + 0.5, float(mm.x) + h * 0.5, float(key.y) + 0.5)
		collision_body.add_child(cs)
