class_name SBHWorld
extends Node3D
## Monde voxel par chunks 16×16.
## Perf : set_block_silent + flush_dirty_chunks pour les placements massifs (structures).

const CHUNK_SIZE := 16

var chunks: Dictionary = {}
## Chunks marqués sales (coord Vector2i) — rebuild groupé.
var _dirty: Dictionary = {}


func _ready() -> void:
	create_test_world()


func create_test_world() -> void:
	for x in range(-1, 2):
		for z in range(-1, 2):
			_ensure_chunk(Vector2i(x, z), false)
	# Un seul rebuild pour tout le terrain de base
	for c in chunks.values():
		c.rebuild()
	_dirty.clear()


func _ensure_chunk(coord: Vector2i, fill_terrain: bool = false) -> SBHChunk:
	var existing: SBHChunk = chunks.get(coord)
	if existing != null:
		return existing
	var chunk := SBHChunk.new()
	chunk.name = "Chunk_%d_%d" % [coord.x, coord.y]
	chunk.chunk_coord = coord
	chunk.world_ref = self
	chunk.position = Vector3(coord.x * CHUNK_SIZE, 0, coord.y * CHUNK_SIZE)
	add_child(chunk)
	chunks[coord] = chunk
	if fill_terrain:
		for x in range(CHUNK_SIZE):
			for z in range(CHUNK_SIZE):
				var h := 2
				for y in range(h):
					var id := BlockTypes.Type.STONE if y == 0 else BlockTypes.Type.DIRT
					if y == h - 1:
						id = BlockTypes.Type.GRASS
					chunk.set_block(Vector3i(x, y, z), id)
	return chunk


func create_chunk(coord: Vector2i) -> SBHChunk:
	return _ensure_chunk(coord, true)


func world_to_chunk(pos: Vector3i) -> Vector2i:
	return Vector2i(floori(float(pos.x) / CHUNK_SIZE), floori(float(pos.z) / CHUNK_SIZE))


func world_to_local(pos: Vector3i) -> Vector3i:
	var c := world_to_chunk(pos)
	var lx := pos.x - c.x * CHUNK_SIZE
	var lz := pos.z - c.y * CHUNK_SIZE
	# Gestion modulo négatif
	if lx < 0:
		lx += CHUNK_SIZE
	if lz < 0:
		lz += CHUNK_SIZE
	return Vector3i(lx, pos.y, lz)


func get_block(pos: Vector3i) -> int:
	var c := world_to_chunk(pos)
	var chunk: SBHChunk = chunks.get(c)
	if chunk == null:
		return BlockTypes.Type.AIR
	return chunk.get_block(world_to_local(pos))


## Placement joueur / outil : rebuild immédiat du chunk + voisins touchés.
func set_block(pos: Vector3i, id: int) -> void:
	set_block_silent(pos, id)
	flush_dirty_chunks()


## Écrit un bloc sans rebuild mesh (pour import structure / bulk).
func set_block_silent(pos: Vector3i, id: int) -> void:
	var c := world_to_chunk(pos)
	var chunk := _ensure_chunk(c, false)
	var local := world_to_local(pos)
	# Sécurité Y
	if local.y < 0 or local.y > 128:
		return
	chunk.set_block(local, id)
	_mark_dirty(c)
	# Voisins seulement si le bloc est sur le bord du chunk
	if local.x == 0:
		_mark_dirty(Vector2i(c.x - 1, c.y))
	elif local.x == CHUNK_SIZE - 1:
		_mark_dirty(Vector2i(c.x + 1, c.y))
	if local.z == 0:
		_mark_dirty(Vector2i(c.x, c.y - 1))
	elif local.z == CHUNK_SIZE - 1:
		_mark_dirty(Vector2i(c.x, c.y + 1))


func _mark_dirty(coord: Vector2i) -> void:
	if chunks.has(coord):
		_dirty[coord] = true


## Rebuild mesh/collision uniquement pour les chunks modifiés.
func flush_dirty_chunks() -> void:
	if _dirty.is_empty():
		return
	var keys := _dirty.keys()
	_dirty.clear()
	for coord in keys:
		var chunk: SBHChunk = chunks.get(coord)
		if chunk:
			chunk.rebuild()


## Placement massif (structures NBT / placements.json).
func set_blocks_bulk(entries: Array) -> int:
	var n := 0
	for e in entries:
		if typeof(e) != TYPE_DICTIONARY:
			continue
		var pos := Vector3i(int(e.get("x", 0)), int(e.get("y", 0)), int(e.get("z", 0)))
		var id := int(e.get("id", BlockTypes.Type.STONE))
		set_block_silent(pos, id)
		n += 1
	flush_dirty_chunks()
	return n


func can_place_block(pos: Vector3i, avoid_aabb: AABB) -> bool:
	if get_block(pos) != BlockTypes.Type.AIR:
		return false
	var block_aabb := AABB(Vector3(pos), Vector3.ONE)
	if avoid_aabb.intersects(block_aabb):
		return false
	return true
