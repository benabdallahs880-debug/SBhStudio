# SBh Studio V1.8.13 — Visual Workshop interactif

## Objectif
Passer d’un aperçu générique à un aperçu lié à la création réellement sélectionnée.

## Changements
- Sélection visuelle par puces dans l’Atelier.
- Le viewport suit l’élément choisi : bloc, objet, mob, entité, personnage ou carte.
- Conservation d’un aperçu de secours lorsqu’aucun modèle 3D n’est disponible.
- Préparation de la prochaine étape : viewport 3D partagé avec transformations et édition en direct.

## Cycle cible
Créer → sélectionner → voir → modifier → voir → tester → exporter.
