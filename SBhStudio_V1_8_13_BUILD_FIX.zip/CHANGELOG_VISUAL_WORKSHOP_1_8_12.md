# SBh Studio V1.8.12 — Visual Workshop

## Objectif
L’Atelier ne doit plus être une suite de formulaires sans retour visuel. Cette version ajoute une couche d’aperçu visuel commune au-dessus des zones de création.

## Ajouts
- Aperçu permanent placé directement sous la barre des zones de l’Atelier.
- Aperçu bloc avec représentation 3D stylisée.
- Aperçu objet/arme avec représentation visuelle.
- Aperçu créature avec représentation humanoïde.
- Aperçu carte avec grille et point de scène.
- Aperçu scène/jeu pour donner un retour visuel pendant la construction.
- Réutilisation du vrai viewport SceneView/Filament existant pour Character Studio.
- Réutilisation du même viewport pour les entités disposant d’un GLB/GLTF.
- Mention explicite « APERÇU EN DIRECT » afin de rendre le rôle de la zone évident.

## Principe
Créer → voir → modifier → voir → tester → exporter.

Les données existantes, les repositories et les zones de l’Atelier restent inchangés. La couche visuelle est additive et réversible.
