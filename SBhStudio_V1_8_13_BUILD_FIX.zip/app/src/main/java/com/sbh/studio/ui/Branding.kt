package com.sbh.studio.ui

import androidx.compose.foundation.layout.Arrangement

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Charge une image depuis assets/branding/
 */
@Composable
fun rememberAssetBitmap(path: String): androidx.compose.ui.graphics.ImageBitmap? {
    val context = LocalContext.current
    return remember(path) {
        runCatching {
            context.assets.open(path).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
        }.getOrNull()
    }
}

@Composable
fun BrandLogo(
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 96.dp
) {
    // Nouveau logo géométrique doré (prioritaire), fallback anciens logos
    val bmp = rememberAssetBitmap("branding/logo_owl_geometric.png")
        ?: rememberAssetBitmap("branding/logo_owl_gothic.jpg")
        ?: rememberAssetBitmap("branding/logo_owl_celtic.jpg")

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(
                        AgwColors.SilverSoft.copy(alpha = 0.2f),
                        AgwColors.DeepNight.copy(alpha = 0.55f)
                    )
                )
            )
            .border(1.5.dp, AgwColors.SilverSoft.copy(alpha = 0.85f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        // Anneau intérieur fin
        Box(
            Modifier
                .fillMaxSize()
                .padding(3.dp)
                .clip(CircleShape)
                .border(0.8.dp, AgwColors.SilverMuted.copy(alpha = 0.45f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = "SBh Studio Logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(8.dp)
                )
            } else {
                Text("🦉", fontSize = 40.sp)
            }
        }
    }
}

@Composable
fun HomeAtmosphereBackground(modifier: Modifier = Modifier) {
    val bmp = rememberAssetBitmap("branding/bg_raven_owl.png")
        ?: rememberAssetBitmap("branding/bg_owl_moon.png")

    Box(modifier = modifier) {
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                alpha = 0.82f
            )
        }
        // Voile léger et chaud (plus de brume noire) pour laisser l'image respirer
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x401A1612), // haut très léger
                            Color(0x332B2620), // milieu doux — photo plus visible
                            Color(0x591A1612)  // bas discret pour la lisibilité
                        )
                    )
                )
        )
        // Légère lueur dorée en bas pour un rendu plus élégant
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Transparent,
                            Color.Transparent,
                            Color(0x28C8D0D8)
                        )
                    )
                )
        )
    }
}

@Composable
fun StudioBrandHeader(lang: AppLang) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        AgwColors.PanelRaised.copy(alpha = 0.55f),
                        AgwColors.DeepNight.copy(alpha = 0.35f)
                    )
                )
            )
            .border(1.dp, AgwColors.SilverMuted.copy(alpha = 0.28f), RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrandLogo(size = 88.dp)
        Spacer(Modifier.height(12.dp))
        Text(
            S.t(lang, "app_name"),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = AgwColors.GoldSoft,
            letterSpacing = 0.3.sp
        )
        Text(
            "صباح · DARK FORGE",
            style = MaterialTheme.typography.labelMedium,
            color = AgwColors.SilverMuted,
            letterSpacing = 1.2.sp
        )
        Spacer(Modifier.height(8.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(AgwColors.SacredGold.copy(alpha = 0.14f))
                    .border(1.dp, AgwColors.SacredGold.copy(alpha = 0.45f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("STUDIO", color = AgwColors.GoldSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Box(
                Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(AgwColors.PersianBlue.copy(alpha = 0.25f))
                    .border(1.dp, AgwColors.Info.copy(alpha = 0.4f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("V1.8.13", color = AgwColors.Info, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Text(
            S.t(lang, "owl_motto"),
            style = MaterialTheme.typography.bodySmall,
            color = AgwColors.DesertOchre,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 10.dp, start = 12.dp, end = 12.dp)
        )
    }
}
