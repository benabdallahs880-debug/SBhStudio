# SBh Studio V1.8.31 — Practice PvP trié

Contenu extrait / organisé depuis **MCtier practice v2.2.mcworld**.

## Faction `practice_pvp`

| Section | Zone app | Contenu |
|---------|----------|---------|
| Armes | Items | 14 (épées + haches `bf:`) |
| Boucliers | Items | 8 (`bf:shield*`) |
| Armures | Items | 24 presets kits PvP (`sbh_practice:`) |
| Blocs | Blocs | 4 (DG loaders + arène) |
| Maps | Cartes | 2 templates (arène 64², duel 24²) |

## Assets
`app/src/main/assets/practice/` — weapons, defense, armor, blocks, maps, catalog.

## UI
- **Hub** : Importer Practice PvP (tout)
- **Items** : boutons Armes / Boucliers / Armures
- **Blocs** : Practice — Blocs arène & farms
- **Maps** : Practice — Templates arène PvP

## Notes
- Armes/boucliers : identifiants du pack Blurry Java PvP.
- Armures custom absentes du .mcworld → presets atelier pour kits.
- La map LevelDB n'est pas importée ; templates pour créer d'autres maps.
