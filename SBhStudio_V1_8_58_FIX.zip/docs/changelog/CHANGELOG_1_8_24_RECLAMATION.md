# SBh Studio V1.8.24 — Presets Reclamation

## Intégration
- `assets/reclamation/` : items, blocs, phases, interactions (JSON)
- `data/ReclamationPresets.kt` : chargeur + conversion SbhItem / SbhBlock
- **ItemZone** : bouton « Presets Reclamation (5 items) »
- **BlockZone** : bouton « Presets Reclamation (3 blocs) »
- **Hub** : « Importer presets Reclamation (items + blocs + phases) »

## Contenu
Items : scrap wood, 4 amalgames  
Blocs : dried earth, dead log, flimsy planks  
Phases : 5 étapes (stérile → reconquête)

## Crédit inspiration
Modpack Reclamation 2.3.2 (ACCBDD) — design dérivé, pas de redistribution des scripts/mods.
