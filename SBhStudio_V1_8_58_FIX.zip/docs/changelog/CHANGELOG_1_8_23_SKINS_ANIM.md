# SBh Studio V1.8.23 — Skins + Animation V2

## Bibliothèque de skins (FreshAnimations)

- 166 textures PNG intégrées dans `assets/skins_library/`
- Catalogue `catalog.json` (id, nom, catégorie, forme recommandée)
- `SkinLibrary.kt` — chargement, recherche, filtres par catégorie
- `SkinLibraryPicker.kt` — UI (chips catégories + grille d'aperçus + recherche)
- Intégré dans **MobZone** : bouton « Bibliothèque de skins »
- Sélection → `textureUri = asset://...` + forme de base proposée
- `PackGenerator` : support des URI `asset://` à l'export
- Source : FreshAnimations v1.10.5 (FreshLX) — crédit requis

## Studio Animation V2

### États (7)
Idle, Marche, **Course**, Attaque, Blessé, **Assis**, **Nage**

### Âmes (12)
Originaux : Garde, Marchand, Assassin, Bête, Mystique, Désert  
Inspirés FreshAnimations :
- **Loup** (forme wolf)
- **Mort-vivant** (zombie / skeleton)
- **Arachnide** (spider)
- **Volant**
- **Quadrupède lourd** (cow)
- **Agile** (chicken)

### Fonctionnalités
- Preset automatique selon `formeBase` du mob lié
- Bouton « Appliquer le preset » dans l'UI
- Keyframes d'export différenciées par âme et par état
- Controller Bedrock enrichi (run / sit / swim)
- Aperçu stickman mis à jour

## Fichiers touchés
- `data/SkinLibrary.kt` (nouveau)
- `workshop/SkinLibraryPicker.kt` (nouveau)
- `workshop/MobZone.kt`
- `animation/AnimationModels.kt`
- `animation/AnimationExport.kt`
- `animation/AnimationScreen.kt`
- `generator/PackGenerator.kt`
- `assets/skins_library/**`
