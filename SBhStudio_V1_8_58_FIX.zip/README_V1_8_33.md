# SBh Studio V1.8.33

Réparations bugs analyse Practice / export.

## Correctifs
- **Armures** : `minecraft:wearable` (slot tête/torse/jambes/pieds) + protection — plus de `hand_equipped`
- **Boucliers** : `use_modifiers` + tags shield (style Java PvP)
- **Icônes** : format objet `{ "texture": "..." }`
- **Textures** : boucliers 16×16, 24 armures + 2 blocs arène
- **Namespace** : `sbh_practice:` (plus de conflit `bf:` Blurry)
- **Maps** : `linkedItemIds` / `linkedBlockIds` vers le contenu practice
- **Architecture** : `PracticePresets` ne dépend plus de `MapBlueprint`
