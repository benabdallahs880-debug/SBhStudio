# Smoke test téléphone — 5 minutes (V1.8.55)

Objectif : valider qu’il n’y a **pas de crash / ANR** sur le parcours critique.

## Avant
- [ ] APK `assembleDebug` installé
- [ ] Android System WebView à jour
- [ ] App fermée complètement (pas en cache)

## Parcours (chronométrer ≈ 5 min)

| # | Action | OK si… | ❌ si… |
|---|--------|--------|--------|
| 1 | Lancer l’app | Hub visible < 5 s | Freeze / écran noir |
| 2 | Ouvrir **Atelier** | Zones affichées | ANR / crash |
| 3 | Hub → **Import Practice PvP** | Message succès items/blocs/maps | Crash / rien |
| 4 | Zone **Blocs** : chercher goldfarm / ironfarm | IDs `sbh_practice:…` | IDs `dg:` |
| 5 | Zone **Mobs** → ouvrir Animation | Studio Animation s’ouvre | Crash |
| 6 | **Map Studio** | Canvas 3D **ou** erreur claire + Réessayer | Crash natif |
| 7 | Retour Atelier → **Character** aperçu 3D | 3D ou fallback 2D | Crash |
| 8 | (si 3D) taper **2D** | Bascule secours | — |
| 9 | **Export .mcaddon** | Fichier généré | Crash / échec silencieux |
| 10 | Tuer l’app + relancer | Données toujours là | Perte données |

## Verdict
- **GO téléphone** : 1–10 sans crash/ANR  
- **NO-GO** : tout crash sur 1, 2, 6 ou 7 → logcat + `map_studio_last_error.txt`

```bash
adb logcat -s MapEditor:W CharacterPreview3D:W AndroidRuntime:E
```
