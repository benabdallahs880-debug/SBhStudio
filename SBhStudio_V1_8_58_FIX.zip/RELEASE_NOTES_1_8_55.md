# SBh Studio 1.8.55 — Release notes

**Date :** 2026-10-04  
**versionCode :** 90  
**Canal :** debug stabilisation téléphone (pré-release)

## Résumé
Version axée **stabilité mobile** : moins d’ANR à l’ouverture de l’Atelier, Map Studio plus tolérant aux GPU faibles, aperçu Character 3D avec secours 2D, namespace Practice unifié.

## Pour les testeurs
1. Installer l’APK debug 1.8.55  
2. Suivre `SMOKE_TEST_5MIN.md`  
3. Signaler tout crash avec modèle d’appareil + Android + WebView  

## Changements techniques (extrait)
- IO Atelier / Animation sur `Dispatchers.IO`
- Practice : `sbh_practice:` uniquement (plus de `dg:` sur les loaders)
- Map Studio : init WebGL multi-essais, messages d’erreur clairs
- Character 3D : fallback 2D + désactivation persistante si crash graphique
- Logs : plus de catch silencieux sur `CharacterRepository`

## Non inclus dans 1.8.55
- Mode PC / desktop
- Configuration OTA (`apkUrl` encore vide)
- Providers IA préremplis
- Garantie anti-SIGSEGV Filament natif (flag post-crash seulement)

## Build
```bash
./gradlew clean assembleDebug
# artefact : app/build/outputs/apk/debug/app-debug.apk
```

## Tag git suggéré
```bash
git add -A
git commit -m "release: SBh Studio 1.8.55 — stabilisation téléphone"
git tag -a v1.8.55 -m "SBh Studio 1.8.55 (versionCode 90) — mobile stability"
```
