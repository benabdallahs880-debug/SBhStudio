# SBh Studio V1.8.24

Basé sur V1.8.23 (skins FreshAnimations + Animation V2) + presets Reclamation.

## Nouveautés 1.8.24
- Bibliothèque presets **Reclamation** (monde mort → reconquête)
- Hub : import items + blocs + résumé des 5 phases
- Zones Items / Blocs : boutons presets dédiés

## Build
./gradlew assembleDebug
