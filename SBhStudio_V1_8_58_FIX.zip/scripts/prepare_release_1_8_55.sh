#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "== version.json =="
cat app/src/main/assets/version.json
echo
CODE=$(python3 -c "import json;print(json.load(open('app/src/main/assets/version.json'))['versionCode'])")
NAME=$(python3 -c "import json;print(json.load(open('app/src/main/assets/version.json'))['versionName'])")
if [[ "$CODE" != "90" || "$NAME" != "1.8.55" ]]; then
  echo "ERREUR: version attendue 1.8.55 / 90 (trouvé $NAME / $CODE)"
  exit 1
fi
echo "== checks P1 =="
echo -n "catch silencieux: "; grep -RcnE 'catch\s*\(\s*_\s*:' app/src/main/java --include='*.kt' | awk -F: '{s+=$2}END{print s+0}'
echo -n "force unwrap !! : "; grep -Rcn '!!' app/src/main/java --include='*.kt' | awk -F: '{s+=$2}END{print s+0}'
echo -n "ids dg: practice : "; grep -Rcn '"dg:' app/src/main/assets/practice --include='*.json' | awk -F: '{s+=$2}END{print s+0}'
echo
if [[ -x ./gradlew ]]; then
  echo "== assembleDebug =="
  ./gradlew assembleDebug
  find app/build/outputs/apk -name '*.apk' 2>/dev/null || true
else
  echo "gradlew absent — assembleDebug depuis IDE/CI"
fi
echo "OK — SMOKE_TEST_5MIN.md"
