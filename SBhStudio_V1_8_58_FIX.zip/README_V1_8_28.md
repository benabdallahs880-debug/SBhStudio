# SBh Studio V1.8.28

Suite des réparations 1–4 demandées.

## 1. Extraction testable
- Nouveau module `MobPackJson` (pure, sans Context)
- `PackGenerator` délègue `mobJson` / `resourceEntityJson`
- Tests : `MobPackJsonTest` (archer, mêlée, poursuite, animations)

## 2. Catch silencieux → logs
- `SkinLibrary` (catalog.json)
- `AnimationRepository` (sbh_animations.json)
- `PackGenerator.loadPng` (assets + URI)

## 3. IO skins hors thread UI
- `SkinLibraryPicker` : `produceState` + `Dispatchers.IO`
- `MobZone` aperçu : idem

## 4. Plus de tests
- Identifiers / MobShapeCatalog / SkinLibraryForme (déjà en 1.8.27)
- **MobPackJsonTest** (nouveau)

```bash
./gradlew test
./gradlew assembleDebug
```
