# Statut SBh Studio 1.8.55 — Stabilisation téléphone

**versionName** 1.8.55 · **versionCode** 90 · **2026-10-04**

## Objectif produit
1. Réparer bugs / stabiliser  
2. Maximiser le **mode téléphone**  
3. PC plus tard  

## Correctifs livrés dans cette branche patch

| ID | Zone | Détail |
|----|------|--------|
| P1-1 | CharacterRepository | Catch logué |
| P1-2 | MobZone / RecipeZone | Plus de `!!` |
| P1-3 | Practice assets + WorkshopScreen | Namespace `sbh_practice` (plus de `dg:` ids) |
| P1-4 | WorkshopScreen | Load/save sur `Dispatchers.IO` |
| P1-5 | MobZone / AnimationScreen | Load anim/mobs hors composition |
| P1-6 | MainActivity | Boot projets/items/mobs/blocs sur IO |
| P1-7 | TextureScreen / AudioStudio | Load initial sur IO |
| P0-1 | mapstudio.html | WebGL multi-essais, low-power mobile |
| P0-2 | MapEditorScreen | Messages WebGL / timeout actionnables |
| P0-3 | CharacterPreview3D | Fallback 2D + bouton 2D + GraphicsSafety |
| P0-4 | MainActivity | Handler crash graphique → désactive 3D |

## Métriques code
- `catch (_:` restants : 0 (hors logs intentionnels)
- `!!` : 0  
- ids `"dg:` dans practice JSON : 0  

## Documents
- `SMOKE_TEST_5MIN.md` — validation rapide device  
- `TEST_PLAN_TELEPHONE_1.8.54.md` — plan étendu  
- `CHANGELOG_1_8_55.md` / `RELEASE_NOTES_1_8_55.md`  
- `scripts/prepare_release_1_8_55.sh`  

## Reste hors code (nécessite device / config)
- [ ] Smoke test réel sur 2 téléphones  
- [ ] Vérifier export `.mcaddon` dans Bedrock  
- [ ] SIGSEGV Filament natif (seulement mitigation)  
- [ ] `apkUrl` OTA  
- [ ] Providers IA  
- [ ] Mode PC  

## Commandes
```bash
./gradlew assembleDebug
# puis SMOKE_TEST_5MIN.md
```
