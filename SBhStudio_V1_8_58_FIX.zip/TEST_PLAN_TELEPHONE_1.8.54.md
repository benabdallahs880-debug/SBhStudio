# Plan de tests téléphone — SBh Studio V1.8.54 (post-patch P0/P1)

**Objectif :** stabiliser le mode téléphone avant le port PC.  
**Build :** `./gradlew assembleDebug` puis installer l’APK debug.

---

## Prérequis appareil

| Item | Détail |
|------|--------|
| Android | 8.0+ (minSdk 26) → 15 |
| WebView | Android System WebView à jour (Play Store) |
| Stockage | ≥ 200 Mo libres |
| Réseau | Optionnel (IA / updates) |

Tester au minimum **1 appareil bas de gamme** + **1 milieu/haut de gamme**.

---

## P0 — Crash / blocage

| # | Scénario | Résultat attendu | Critère OK |
|---|----------|------------------|------------|
| T01 | Lancer l’app à froid | Hub affiché < 5 s | Pas de freeze > 3 s |
| T02 | Ouvrir **Atelier (Workshop)** | Zones listées, données chargées | Pas d’ANR |
| T03 | Ouvrir **Map Studio** | Canvas 3D ou message d’erreur clair + Réessayer | Pas de crash natif |
| T04 | Map Studio si GPU faible | Toast « mode compatibilité » ou écran erreur WebGL | App reste utilisable |
| T05 | Bouton **Réessayer** Map Studio | Recharge la page | loading → ready ou erreur stable |
| T06 | **Retour** depuis Map Studio | Retour atelier sans fuite WebView | Pas de second crash |
| T07 | Rotation écran (si autorisée) | Pas de crash | État acceptable |

## P1 — Données / Practice / Export

| # | Scénario | Résultat attendu |
|---|----------|------------------|
| T10 | Hub → **Importer Practice PvP** | Items + blocs + maps ajoutés |
| T11 | Vérifier blocs | IDs `sbh_practice:goldfarm_loader` / `ironfarm_loader` (plus de `dg:`) |
| T12 | Zone Items / Blocs / Maps Practice | Listes non vides, textures visibles |
| T13 | Créer un mob → **Ouvrir Animation** | Studio Animation s’ouvre sans crash |
| T14 | Zone Recettes → case grille → Vider / choisir item | Pas de crash (`!!` éliminés) |
| T15 | **Exporter .mcaddon** | Fichier généré, partageable |
| T16 | Rouvrir l’app | Données atelier toujours là |

## P2 — Secondaire

| # | Scénario | Résultat attendu |
|---|----------|------------------|
| T20 | Écran IA | Message « non configuré » si providers off |
| T21 | Import audio non-OGG | Message conversion indisponible (pas de crash) |
| T22 | Character Studio aperçu 3D | Affiche ou échoue gracieusement (Filament) |
| T23 | Mise à jour APK | apkUrl vide → pas de fausse update |

## Journal d’échec (à remplir sur device)

```
Appareil :
Android / WebView :
Scénario (Tx) :
Symptôme :
Logcat (tag MapEditor, SBh, AndroidRuntime) :
Fichier map_studio_last_error.txt (si présent) :
```

## Commandes logcat utiles

```bash
adb logcat -s MapEditor:W SBh:W AndroidRuntime:E chromium:W
adb shell run-as com.sbh.studio cat files/map_studio_last_error.txt
```

## Critères de sortie « mode téléphone stabilisé »

- [ ] T01–T07 OK sur 2 appareils
- [ ] T10–T16 OK
- [ ] Aucun ANR dans Play Vitals / logcat pendant 15 min d’usage atelier
- [ ] Export .mcaddon installable dans Minecraft Bedrock
