# Rapport de tests — SBh Studio V1.8.28

**Date :** 2026-09-29  
**Mode :** tests uniquement (aucune réparation / modification de code)

---

## 1. Gradle Android (`./gradlew test`)

| Étape | Résultat |
|-------|----------|
| Wrapper Gradle | Téléchargé (gradle-8.11.1) — le projet n’avait pas `gradle-wrapper.jar` |
| `:app:testDebugUnitTest` | **ÉCHEC (environnement)** |
| Cause | `SDK location not found` — pas de `ANDROID_HOME` / `local.properties` sur la machine d’analyse |

```
FAILURE: Build failed with an exception.
Could not determine the dependencies of task ':app:testDebugUnitTest'.
> SDK location not found. Define a valid SDK location with an ANDROID_HOME
  environment variable or by setting the sdk.dir path in local.properties
```

**Note :** ce n’est pas un échec des tests unitaires eux-mêmes, mais l’impossibilité de lancer la tâche Android Gradle sans SDK.

---

## 2. Tests unitaires JVM purs (logique isolée)

Exécution hors plugin Android, avec compilateur Kotlin 2.0.21 + JUnit 4.13.2.

### Classes exécutées

| Classe | Fichier | Tests |
|--------|---------|-------|
| `IdentifiersTest` | data | validation ids Bedrock |
| `MobShapeCatalogTest` | data | géométries / fallback |
| `SkinLibraryFormeTest` | data | `recommendedForme` |
| `MobPackJsonTest` | generator | export JSON mobs (archer, mêlée, anims) |

### Résultat brut

```
JUnit version 4.13.2
..................
Time: 0.083

OK (18 tests)
```

| Métrique | Valeur |
|----------|--------|
| Tests lancés | **18** |
| Succès | **18** |
| Échecs | **0** |
| Erreurs | **0** |
| Ignorés | **0** |
| Durée | ~0,08 s |

---

## 3. Couverture de ces 18 tests

- Identifiants valides / invalides / `namespaceOf` / `nameOf`
- Toutes les formes du catalogue → `geometryFor`
- Fallback forme inconnue
- `recommendedForme` (wolf, cow, chicken, axolotl, ghast, guardian, squid, zombie, spider, unknown)
- `MobPackJson` : archer = ranged, guerrier = mêlée, passif sans poursuite, anims humanoid / non-humanoid, `eggColor` hex

---

## 4. Non exécuté (limité par l’environnement)

- Tests instrumentés (`androidTest`) — absents du projet + pas de SDK
- Tests repos (MobRepository, etc.) — nécessitent Context / Robolectric / SDK
- `PackGenerator` complet (zip, textures Bitmap) — dépend d’Android

---

## 5. Conclusion

| Canal | Statut |
|-------|--------|
| Gradle + Android SDK | Non exécutable ici (SDK manquant) |
| Tests unitaires P0/P1 pure JVM | **18/18 OK** |

Aucun bug fonctionnel détecté par les tests unitaires existants lors de cette session.
