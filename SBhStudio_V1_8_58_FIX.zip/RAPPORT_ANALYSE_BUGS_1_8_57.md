# SBh Studio — Rapport d'analyse des bugs et correctifs · V1.8.56 → V1.8.57

**Base analysée :** `SBhStudio_V1_8_55_FULL.zip` (versionCode 90) · **Résultat :** V1.8.57 (versionCode 92) · 2026-10-05
(V1.8.56 = correctifs de l'analyse · V1.8.57 = projet actif + sauvegardes en échec, voir §2bis)

Ce document se lit seul : il dit ce qui a été analysé, ce qui a été corrigé (fichier par fichier), ce qui ne l'a pas été et ce qu'il reste à faire pour terminer.

---

## 1. Méthode et limites

- **Revue statique** du code Kotlin (96 fichiers, ~25 700 lignes), du `mapstudio.html` (3 184 lignes), du manifest, des ressources et des 27 fichiers JSON d'assets.
- Vérifications automatiques réussies : les 27 JSON sont valides ; le script JavaScript de Map Studio passe `node --check` avant et après correctifs ; l'équilibre des accolades/parenthèses des fichiers modifiés est identique aux originaux.
- **Non vérifié : la compilation Gradle.** L'environnement d'analyse n'a pas accès à Maven/Google (téléchargements bloqués). Les correctifs ont été écrits avec prudence (API déjà utilisées ailleurs dans le projet), mais **`./gradlew assembleDebug` doit être lancé avant toute diffusion.**
- Pas de test sur téléphone ni dans Minecraft : voir la section 6 (tests à faire).

---

## 2. Bugs corrigés (par gravité)

### 🔴 Critique — perte de données

| # | Bug | Cause | Correctif |
|---|-----|-------|-----------|
| C1 | **Corruption des sauvegardes puis effacement de tout le contenu** (mobs, items, blocs, maps, portails, textures, animations, scènes 3D…) | Toutes les sauvegardes utilisaient le même fichier temporaire `nom.json.tmp`. Deux sauvegardes simultanées (lancées en parallèle sur `Dispatchers.IO`) écrivaient dedans en même temps → JSON mélangé → à la lecture suivante, échec → liste vide → la sauvegarde d'après écrasait tout. | Nouveau `data/SafeStore.kt` : verrou par fichier, `.tmp` unique par écriture, `fsync`. Un fichier illisible est désormais **copié en `nom.json.corrupt-<horodatage>`** avant d'être réécrit. Utilisé par tous les dépôts JSON. |
| C2 | **Ajouter/supprimer un mob depuis l'écran Projet effaçait ce qui avait été créé dans l'Atelier** (et l'export du projet ignorait ces créations) | `MainActivity` lisait mobs/items/blocs une seule fois au démarrage et réécrivait cette vieille liste. L'Atelier, l'écran Animation, l'IA et l'import manuel modifient pourtant les mêmes fichiers. | Relecture du disque à chaque retour sur l'Accueil ou un projet ; l'export relit les données fraîches. |
| C3 | **Créer un projet pendant le démarrage effaçait tous les projets** | Avant la fin du chargement, la liste en mémoire est celle par défaut ; la sauvegarde l'écrivait sur le disque. | Les sauvegardes sont ignorées tant que le chargement initial n'est pas terminé (message « Chargement en cours… »). |
| C4 | **Même problème dans l'Atelier** : toucher un bouton (import presets, enregistrer un mob…) pendant le chargement écrasait le fichier avec une liste presque vide | Les listes de l'Atelier sont vides tant que le chargement IO n'est pas fini. | L'Atelier affiche « Chargement de l'atelier… » et bloque les zones tant que les données ne sont pas prêtes. |
| C5 | **Scène de l'Éditeur 3D perdue** si son fichier était illisible | La lecture renvoyait `null` → scène par défaut → réécrite 400 ms plus tard ; les erreurs d'écriture étaient avalées en silence. | Copie de secours + erreurs journalisées (SafeStore). |

### 🟠 Majeur — fonctionnalités cassées

| # | Bug | Correctif |
|---|-----|-----------|
| M1 | **Character Studio : Meshy et l'IA distante ne servaient à rien.** Tous les fournisseurs appelaient le générateur local, qui recopie le mannequin embarqué ; la clé Meshy était demandée mais jamais utilisée, et l'écran annonçait « Modèle généré ». | `CharacterStudioZone` appelle maintenant `MeshyImageTo3DClient` (Meshy), `RemoteCharacterGenerationClient` (IA distante) ou le générateur local selon le choix. |
| M2 | **Map Studio « ⬇ Exporter vers SBh » n'enregistrait rien** : le JSON était compté puis jeté, malgré le message « Map importée ». | Sauvegarde dans `files/map_exports/map_<horodatage>.json` + `map_last.json`, le toast indique le fichier. |
| M3 | **Map Studio : la moindre erreur JavaScript après le démarrage masquait tout l'éditeur** (écran « n'a pas pu se charger » ; « Réessayer » rechargeait la page → map en cours perdue). | Après le démarrage, une erreur non fatale devient un simple message (côté Kotlin et côté JS). Les erreurs de démarrage et WebGL gardent l'écran d'erreur. |
| M4 | **Export `.mcaddon` : blocs avec un composant inexistant.** `minecraft:destroy_time` n'existe plus depuis le format 1.19.20 ; le pack déclare `format_version 1.21.0`. | Remplacé par `minecraft:destructible_by_mining { seconds_to_destroy }` (PackGenerator + AdvancedPackEngine). |
| M5 | **Export : slot d'enchantement invalide pour les armures** (`armor.head`, `armor.chest`… n'existent pas). | Noms Bedrock : `armor_head`, `armor_torso`, `armor_legs`, `armor_feet`. |
| M6 | **Export : les tags choisis par l'utilisateur disparaissaient** sur les armes, armures et boucliers (le composant `minecraft:tags` était écrit deux fois, le second écrasait le premier). Une pioche (« pickaxe ») recevait aussi le tag hache. | Un seul composant `minecraft:tags` fusionné ; « pickaxe » exclu du tag hache. |
| M7 | **Export et génération de la Fondation sur le thread UI** → écran figé, voire « l'application ne répond pas » sur téléphone. | Exécutés en arrière-plan (Accueil → Projet → Export, Atelier → Export, Atelier → Générer la fondation) avec protection contre le double clic. |

### 🟡 Mineur

| # | Bug | Correctif |
|---|-----|-----------|
| m1 | Protection anti-crash 3D (Filament) inefficace : le drapeau était écrit en asynchrone (`apply()`) juste avant la mort du processus. | `commit()` synchrone. |
| m2 | Lecteur audio : `release()` sauté si `stop()` échouait (lecteur pas encore prêt) → fuite du lecteur natif ; aucune gestion d'erreur de lecture. | `stop()` et `release()` séparés + `setOnErrorListener`. |
| m3 | Onglet **IA** de la barre du bas : la barre disparaissait en l'ouvrant. | `Screen.Ai` ajouté aux écrans racine. |
| m4 | Paramètres affichaient **« SBh Studio 1.6.1 »**. | Version réelle (`BuildConfig.VERSION_NAME` + code). |
| m5 | Ajouts rapides Practice/Reclamation (blocs, armes, boucliers, armures, maps) : doublons vérifiés sur **tous** les projets → un 2e projet ne recevait rien. | Vérification limitée au projet courant. |
| m6 | Entités envoyées depuis Map Studio rangées dans le projet `global` → invisibles dans l'Atelier. | Rattachées au projet ouvert dans l'Atelier (1er projet). |
| m7 | Import d'un `.glb` vers Map Studio : un gros modèle (Meshy HD) passait entier en base64 → manque de mémoire de la WebView. | Limite 25 Mo avec message clair. |
| m8 | Sauvegarde automatique de l'Éditeur 3D sur le thread UI. | Passée en arrière-plan. |
| m9 | `minecraft:icon` des items au format objet ancien (`{"texture": …}`). | Forme courte (chaîne), identique au pipeline Fondation. **À confirmer en jeu** (voir §6). |

---

## 2bis. V1.8.57 — deux points de la liste « reste à faire » traités

| # | Problème | Correctif |
|---|----------|-----------|
| P1 | **L'Atelier travaillait toujours sur le 1er projet**, pas sur celui ouvert à l'Accueil (même chose pour Map Studio et l'IA). | Nouveau `data/ActiveProject.kt` : le dernier projet ouvert est mémorisé (survit au redémarrage) et partagé par tous les écrans. L'Accueil affiche « ● Projet actif » sur la carte concernée. Dans l'Atelier, le nom du projet sous le titre est cliquable (▾) pour changer de projet. Map Studio (entités) et l'IA (analyse, propositions, application) utilisent le projet actif. |
| P2 | **Une sauvegarde qui échoue faisait planter l'application** (stockage plein…). | Accueil : fenêtre d'alerte explicite. Atelier : message (mobs, items, blocs, recettes, entités, Game Builder, personnages, portails, maps, synchronisation AGW). Écrans Textures et Animation : message au lieu du plantage, et « enregistré » n'est plus affiché si l'écriture a échoué. |

Fichiers touchés en V1.8.57 : `data/ActiveProject.kt` (nouveau), `MainActivity.kt`, `workshop/WorkshopScreen.kt`, `mapeditor/MapEditorScreen.kt`, `ai/AiProposalEngine.kt`, `ai/AiProjectAnalyzer.kt`, `texture/TextureScreen.kt`, `animation/AnimationScreen.kt`, `version.json` ×2 (1.8.57 · 92).

---

## 3. Fichiers touchés (V1.8.56)

| Fichier | Modification |
|---------|--------------|
| `data/SafeStore.kt` | **Nouveau** — écriture/lecture sûres (C1, C5) |
| `data/ProjectRepository.kt` | `atomicWrite` et `readSafely` délèguent à SafeStore |
| `data/MobRepository.kt`, `data/ContentRepository.kt` | Lecture via SafeStore (copie de secours) |
| `data/AgwWorldCore.kt` | Écriture via SafeStore |
| `workshop/WorkshopRepository.kt`, `workshop/GameBuilderRepository.kt`, `workshop/Editor3DModels.kt` | Lecture/écriture via SafeStore |
| `texture/TextureRepository.kt`, `animation/AnimationRepository.kt` | Lecture/écriture via SafeStore |
| `MainActivity.kt` | C2, C3, M7 (export), m3, m4 |
| `workshop/WorkshopScreen.kt` | C4, M7 (export + fondation), m5 |
| `workshop/Editor3DScreen.kt` | m8 |
| `workshop/CharacterStudioZone.kt` | M1 |
| `generator/PackGenerator.kt` | M4, M5, M6, m9 |
| `generator/AdvancedPackEngine.kt` | M4 (bloc portail) |
| `mapeditor/MapEditorScreen.kt` | M2, M3, m6, m7 |
| `assets/mapstudio.html` | M3 (drapeau `__sbhStudioReady`) |
| `character/CharacterPreview3D.kt` | m1 |
| `ui/AudioStudioScreen.kt` | m2 |
| `version.json` + `assets/version.json` | 1.8.56 · versionCode 91 |

Le différentiel complet est fourni à part (`SBhStudio_V1_8_56.diff`).

---

## 4. Problèmes repérés mais NON corrigés (à décider / à faire)

**Build et qualité**
1. **Compilation non vérifiée** (cf. §1). Points à surveiller : Kotlin `2.2.21` alors que le commentaire de `app/build.gradle.kts` parle de « compatible Kotlin 2.0.21 » pour SceneView `4.0.1` — vérifier que cette version de SceneView existe et compile avec Kotlin 2.2.
2. **Aucun test unitaire dans l'archive** (`app/src/test` absent) alors que `STATUS`/`CHANGELOG` annoncent `./gradlew test` et que `MobPackJson` a été extrait « pour les tests ». `./gradlew test` passe donc sans rien tester.
3. `STATUS_1_8_55.md` annonce « 0 catch silencieux » : faux (ex. `Editor3DRepository.save` avalait les erreurs — corrigé ici). Les métriques de ce document ne sont pas fiables.

**Comportement**
4. ~~L'Atelier travaille toujours sur le 1er projet~~ → **corrigé en V1.8.57** (§2bis P1).
5. Map Studio et Animation ouverts depuis l'Atelier reviennent à l'**Accueil** (pas à l'Atelier).
6. ~~Les sauvegardes qui échouent font planter l'app~~ → **corrigé en V1.8.57** (§2bis P2). Reste : les sons (`SoundRepository.delete/update/assignToProject`) n'ont pas encore cette protection.
7. Le « pouvoir Résistance » d'un mob le rend **totalement invulnérable** (`damage_sensor` cause `all` sans dégâts). À confirmer comme choix de design.
8. Map Studio sauvegarde la map dans le `localStorage` de la WebView seulement (bouton 💾) : perdu si les données de l'app sont effacées. L'export (M2) est désormais le moyen fiable.
9. Meshy : jusqu'à 4 images × 20 Mo encodées en base64 en mémoire (risque de manque de mémoire) ; la boucle d'attente (`Thread.sleep`, 30 min) continue même si l'utilisateur quitte l'écran.
10. Mise à jour OTA : attente du téléchargement limitée à 3 min ; si l'autorisation « sources inconnues » manque, l'installation s'arrête sans message.
11. `SBhCommunicationCore` (journal/rapports) et `PlayableSceneBuilder` gardent leur propre écriture `.tmp` (risque faible, à migrer vers SafeStore).
12. `MapEditorScreen.syncEntities` lit/écrit les fichiers sur le thread UI.

**Architecture (déjà connu)**
13. Deux pipelines d'export indépendants (principal `PackGenerator` et `foundation/`) : tout correctif doit être fait deux fois. Décision de consolidation toujours en attente.
14. Code mort : `AdvancedPackEngine.portalBlockJson` (jamais appelé) ; `mapDocJson` écrit `theme` deux fois ; clés de langue des items différentes entre les deux pipelines (`item.<id>` / `item.<id>.name` — sans effet visible car `display_name` est utilisé).

---

## 5. Pour reprendre le travail

```bash
# 1. Compiler
./gradlew assembleDebug
# 2. Si erreur de compilation : elles ne peuvent venir que des fichiers listés au §3
#    (diff complet dans SBhStudio_V1_8_56.diff)
# 3. Installer l'APK, puis dérouler le §6
```

Priorités suivantes proposées : §4-1 (compiler), §4-5 (retour vers l'Atelier depuis Map Studio / Animation), §4-2 (vrais tests unitaires sur `MobPackJson` / `PackGenerator`), §4-9 (mémoire Meshy).

---

## 6. Tests à faire sur téléphone

1. **Anti-perte de données** : Atelier → créer un mob → Accueil → ouvrir le projet → ajouter un mob → revenir à l'Atelier : **les deux mobs sont présents**.
2. Lancer l'app et appuyer tout de suite sur « Nouveau projet » : message « Chargement en cours… », aucun projet perdu.
3. **Export** (Projet et Atelier) : l'écran ne fige plus ; le `.mcaddon` s'ouvre dans Minecraft.
4. **Dans Minecraft** (journal de contenu activé) : aucun avertissement sur `destroy_time`, `enchantable` ou `minecraft:icon` ; les blocs se cassent ; une armure s'enchante ; **les icônes d'items s'affichent** (vérifie m9) ; un item avec tags personnalisés + arme garde ses tags.
5. **Character Studio** : choisir Meshy + clé valide → la progression affiche « Meshy : … » et le modèle obtenu n'est pas le mannequin.
6. **Map Studio** : « Exporter vers SBh » → toast « Map enregistrée : map_….json ».
7. Ouvrir l'onglet IA : la barre du bas reste visible. Paramètres : affiche 1.8.56 (91).
8. Lecteur audio : lancer/arrêter rapidement plusieurs sons → pas de son bloqué.
9. **Projet actif (1.8.57)** : créer 2 projets → ouvrir le 2e à l'Accueil → Atelier : le titre affiche le 2e projet ; créer un mob ; toucher le nom ▾ → passer au 1er : le mob n'y est pas ; revenir au 2e : il y est. Fermer/rouvrir l'app : le projet actif est conservé.
10. **Sauvegarde en échec (1.8.57)** : avec un stockage presque plein, enregistrer un mob → message d'avertissement, pas de plantage.
