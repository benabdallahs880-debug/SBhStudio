# SBh Studio V1.8.23

Version basée sur V1.8.22 + ajouts session :

1. **Bibliothèque de skins** (FreshAnimations v1.10.5) — 166 textures
2. **Studio Animation V2** — 7 états, 12 âmes, export enrichi

## Build

```bash
./gradlew assembleDebug
```

## Nouveautés utilisateur

### Mobs → Bibliothèque de skins
- Bouton « Bibliothèque de skins (FreshAnimations) »
- Catégories + recherche + aperçus
- Application texture + forme recommandée

### Animation
- 7 états (Idle, Marche, Course, Attaque, Blessé, Assis, Nage)
- 12 presets d'âme (dont Loup, Mort-vivant, Arachnide, Volant, Quadrupède lourd, Agile)
- Lien mob → bouton « Appliquer le preset » selon la forme

## Crédit skins
Fresh Animations — FreshLX (CurseForge / Modrinth / Planet Minecraft)
