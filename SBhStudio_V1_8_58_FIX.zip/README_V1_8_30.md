# SBh Studio V1.8.30

Vague 2 — fin des `catch (_: Exception)` silencieux prioritaires.

## Correctifs
- **AgwData** / **AgwWorldCore** : Log.w sur échecs de chargement JSON
- **SBhCommunicationCore** : journal, séquence, rapports
- **MapEditorScreen** : fichiers map, file chooser, inject
- **StructureLoader** / **NbtStructureParser**
- **SBhValidationEngine**, **GameBuilderRepository**, **Project/Sound repos**
- **UpdateManager**, **ReclamationPresets**, **ManualUpdateImporter**
- **AppDiagnostic**, **AudioStudio**, **WorkshopScreen**, **Editor3DModels**, **SystemLog**

Résultat : **0** occurrence de `catch (_: Exception)` dans le code Kotlin.

```bash
./gradlew assembleDebug
```
