# SBh Studio V1.8.29

Réparations bugs restants (session analyse).

## Correctifs
1. **Catch silencieux** → `Log.e` / `Log.w` :
   - MobRepository, ItemRepository, BlockRepository
   - WorkshopRepository, TextureRepository
   - AudioOggConverter
2. **Animations client** selon `formeBase` (spider/creeper/zombie/chicken/quadrupède)
3. **Catalogue + recommendedForme** : piglin, illager, villager, witch, trader → forme zombie ; allay/blaze/enderman/golem explicitement humanoid
4. **Unification** : `PackGenerator.safe` / `textureKey` / `eggColor` → `MobPackJson`
5. Tests mis à jour (formes + spider walk)

```bash
./gradlew test
./gradlew assembleDebug
```
