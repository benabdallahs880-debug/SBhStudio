# SBh Studio V1.8.25

Basé sur V1.8.24 (Reclamation + skins FA + Animation V2) + **Atelier Mobs libre amélioré**.

## Nouveautés 1.8.25 — Atelier Mobs

- **Sélection MOB via menu** : bibliothèque de skins ouverte par défaut
- **Aperçu grand** : image + nom du MOB sélectionné clairement affichés
- **Bouton « Appliquer la forme »** + **« Afficher la forme »** (détails géométrie)
- Création **100 % libre** (stats, comportement, pouvoirs, collision…) — aucun forçage
- Liste de travail claire avec édition / suppression
- Pré-remplissage intelligent du nom + identifiant à partir du skin choisi
- Les presets AGW restent optionnels (bouton séparé)

## Build
./gradlew assembleDebug
