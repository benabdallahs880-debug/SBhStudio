# Changelog — SBh Studio V1.8.55

**Focus :** stabilisation mode téléphone (bugs P0/P1)

## Correctifs

### Atelier / données
- Catch silencieux `CharacterRepository` → `Log.e`
- Suppression des force-unwraps `!!` (`MobZone`, `RecipeZone`)
- Namespace Practice unifié : `dg:*` → `sbh_practice:*` (assets + filtres code)
- Chargement atelier hors thread UI (`Dispatchers.IO`)
- Sauvegardes atelier / characters sur IO

### Map Studio
- Init WebGL multi-tentatives (low-power d’abord sur Android)
- Pré-check WebGL, pixel ratio mobile 1.25, shadows off en low GPU
- Messages d’erreur actionnables (MAJ System WebView)
- Timeout 20 s clarifié

### Character / Filament
- Aperçu 3D : intensité lumière réduite
- Bouton **2D** pour désactiver le 3D manuellement
- Fallback 2D persistant (`GraphicsSafety`)
- Handler de crash : désactive le 3D Character si stack Filament/SceneView

## Fichiers principaux touchés
- `CharacterRepository.kt`, `WorkshopScreen.kt`, `MobZone.kt`, `RecipeZone.kt`
- `practice/blocks.json`, `practice/catalog.json`
- `mapstudio.html`, `MapEditorScreen.kt`
- `CharacterPreview3D.kt`, `MainActivity.kt`
- `version.json` → **1.8.55** (versionCode **90**)

## Build
```bash
./gradlew test
./gradlew assembleDebug
```

## Tests
Voir `TEST_PLAN_TELEPHONE_1.8.54.md` (valable pour 1.8.55).
