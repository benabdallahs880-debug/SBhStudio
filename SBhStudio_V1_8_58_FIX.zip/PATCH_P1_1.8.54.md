# Patch P1 — SBh Studio V1.8.54 (stabilisation téléphone)

Date : 2026-10-04  
Mode : corrections ciblées P1 (pas de changement fonctionnel majeur)

## Correctifs appliqués

### 1. Catch silencieux → log (`CharacterRepository.kt`)
- `catch (_: Exception) { emptyList() }` remplacé par `catch (e: Exception) { Log.e(...); emptyList() }`
- Aligné sur le pattern de `AnimationRepository`

### 2. Namespace Practice unifié (`blocks.json` + `WorkshopScreen.kt`)
- `dg:goldfarm_loader` → `sbh_practice:goldfarm_loader`
- `dg:ironfarm_loader` → `sbh_practice:ironfarm_loader`
- `"namespace": "dg"` → `"sbh_practice"`
- Filtres code : suppression de `|| it.identifier.startsWith("dg:")` (2 occurrences)

### 3. Force unwraps `!!` éliminés
- `MobZone.kt` : `editingId!!` → smart-cast via `val currentEditingId = editingId`
- `RecipeZone.kt` : `pickCell!!` → smart-cast via `val selectedCell = pickCell`

### 4. Catalog notes
- Note namespace mise à jour pour inclure les blocs

## Vérifications post-patch

```
catch (_: Exception)  → 0 occurrence
!! dans .kt           → 0 occurrence
dg: dans source/assets → 0 occurrence (hors docs)
```

## Non traité (nécessite plus de refacto / tests)

| Item | Raison |
|------|--------|
| IO `Dispatchers.IO` sur tous les repositories | Touche de nombreux call-sites (UI Compose) |
| WebGL Map Studio fallback | Déjà partiellement géré ; test device requis |
| Filament crash GPU | Test device + try/catch natif |
| apkUrl OTA | Config release |
| Providers IA | Config utilisateur |

## Build recommandé

```bash
./gradlew test
./gradlew assembleDebug
```

Puis installer sur téléphone et vérifier :
1. Import Practice PvP (hub)
2. Export .mcaddon (blocs goldfarm/ironfarm en sbh_practice:)
3. Édition mob + ouverture animation
4. Zone recettes (grille 3x3)

## Suite — IO thread (P1 suite)

### WorkshopScreen.kt
- Chargement initial de tous les repositories via `LaunchedEffect` + `withContext(Dispatchers.IO)`
- Sauvegardes (mobs, items, blocs, maps, portals, recipes, entities, game, characters) sur `Dispatchers.IO`
- Mise à jour d'état Compose (`agwWorld`) ramenée sur le thread Main

### MobZone.kt
- `animRepo.loadAll()` déplacé hors composition → `LaunchedEffect` + IO

### AnimationScreen.kt
- Chargement projects/mobs via `LaunchedEffect` + IO


## Suite — Map Studio WebGL (P0)

### mapstudio.html
- Pré-check WebGL avant Three.js
- Tentatives multiples (low-power d’abord sur Android)
- Pixel ratio plafonné à 1.25 sur mobile
- Shadow map désactivée en mode low GPU
- Rapport d’erreur via `sbhReportRuntimeError` (UI boot + bridge natif)

### MapEditorScreen.kt
- Interprétation dédiée `WebGLError`
- Message utilisateur actionnable (MAJ System WebView)
- Timeout 20 s avec consigne claire

### Tests
Voir `TEST_PLAN_TELEPHONE_1.8.54.md`

## Suite — Filament / Character 3D (P0)

- `CharacterPreview3D` : fallback 2D + bouton 2D + lumière GPU réduite
- `GraphicsSafety` : préférence persistante
- `MainActivity` : uncaught handler désactive le 3D si crash graphique JVM
- version → **1.8.55** / code **90**

