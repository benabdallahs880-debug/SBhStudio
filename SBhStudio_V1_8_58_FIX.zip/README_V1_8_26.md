# SBh Studio V1.8.26

Correctifs sur V1.8.25 (Atelier Mobs libre).

## Correctifs
1. **Géométries Minecraft** : identifiants réels (`geometry.humanoid.custom`, `geometry.creeper.v1.8`, etc.)
2. **Catalogue skins** : formes corrigées pour axolotl, dolphin, ghast, guardian, squid
3. **recommendedForme** : catégories manquantes ajoutées
4. **Crash possible** : suppression des `tex!!` (MobZone, BlockZone, ItemZone)
5. **Textures export** : toujours normalisées en 64×64
6. **Animations** : look_at + marche quadrupède pour les formes non-humanoïdes
7. **État UI** : `showFormeDetails` en `rememberSaveable`
8. **Fichier version.json** en double à la racine supprimé

## Build
./gradlew assembleDebug
