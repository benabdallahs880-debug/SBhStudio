package com.sbh.studio.data

import android.content.Context
import android.util.Log
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

private val contentJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

class ItemRepository(private val context: Context) {
    private val file get() = File(context.filesDir, "sbh_items.json")
    fun loadAll(): List<SbhItem> =
        SafeStore.readOrBackup(file, "ItemRepository") { contentJson.decodeFromString<List<SbhItem>>(it) } ?: emptyList()
    fun saveAll(value: List<SbhItem>) = atomicWrite(file, contentJson.encodeToString(value))
}

class BlockRepository(private val context: Context) {
    private val file get() = File(context.filesDir, "sbh_blocks.json")
    fun loadAll(): List<SbhBlock> =
        SafeStore.readOrBackup(file, "BlockRepository") { contentJson.decodeFromString<List<SbhBlock>>(it) } ?: emptyList()
    fun saveAll(value: List<SbhBlock>) = atomicWrite(file, contentJson.encodeToString(value))
}
