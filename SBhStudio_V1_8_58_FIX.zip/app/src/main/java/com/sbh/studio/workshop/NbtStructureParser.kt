package com.sbh.studio.workshop

import android.util.Log

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.GZIPInputStream

/**
 * Parseur NBT orienté structures Minecraft (V1.8.58).
 *
 * Formats acceptés :
 *  - Java Edition `.nbt` (gzip ou brut, big-endian) : `size` = liste de 3 entiers (TAG_List),
 *    `palette`, `blocks[{pos, state}]`.
 *  - Bedrock `.mcstructure` (brut, little-endian) : `size`, `structure.block_indices`,
 *    `structure.palette.default.block_palette[{name, states}]`.
 *
 * Avant : seul `size` en TAG_Int_Array était accepté → TOUS les vrais fichiers Java (qui
 * utilisent une TAG_List) étaient refusés ; les .mcstructure Bedrock (little-endian) aussi.
 * Une longueur corrompue ne peut plus provoquer d'allocation géante (contrôle de taille).
 *
 * Pas de dépendance externe. Testé dans NbtStructureParserTest.
 */
object NbtStructureParser {

    // ── Types NBT ──────────────────────────────────────────────────────────
    private const val TAG_END = 0
    private const val TAG_BYTE = 1
    private const val TAG_SHORT = 2
    private const val TAG_INT = 3
    private const val TAG_LONG = 4
    private const val TAG_FLOAT = 5
    private const val TAG_DOUBLE = 6
    private const val TAG_BYTE_ARRAY = 7
    private const val TAG_STRING = 8
    private const val TAG_LIST = 9
    private const val TAG_COMPOUND = 10
    private const val TAG_INT_ARRAY = 11
    private const val TAG_LONG_ARRAY = 12

    /** Au-delà, une structure n'est pas affichable sur téléphone (et signe d'un fichier corrompu). */
    private const val MAX_BLOCKS = 2_000_000

    sealed class NbtValue {
        data class ByteVal(val v: Byte) : NbtValue()
        data class ShortVal(val v: Short) : NbtValue()
        data class IntVal(val v: Int) : NbtValue()
        data class LongVal(val v: Long) : NbtValue()
        data class FloatVal(val v: Float) : NbtValue()
        data class DoubleVal(val v: Double) : NbtValue()
        data class ByteArrayVal(val v: ByteArray) : NbtValue()
        data class StringVal(val v: String) : NbtValue()
        data class ListVal(val elementType: Int, val v: List<NbtValue>) : NbtValue()
        data class CompoundVal(val v: Map<String, NbtValue>) : NbtValue()
        data class IntArrayVal(val v: IntArray) : NbtValue()
        data class LongArrayVal(val v: LongArray) : NbtValue()
    }

    // ── API publique ───────────────────────────────────────────────────────

    /**
     * Parse un fichier de structure Minecraft (Java gzip/brut ou Bedrock .mcstructure).
     * Retourne une StructureLoader.StructureDef prête à l'emploi, ou null si invalide.
     */
    fun parseStructure(bytes: ByteArray, fallbackName: String = "Structure importée"): StructureLoader.StructureDef? {
        val raw = try {
            if (bytes.size >= 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()) gunzip(bytes) else bytes
        } catch (e: Exception) {
            Log.w("NbtStructureParser", "Décompression gzip impossible", e)
            return null
        }
        // 1) Java (big-endian)
        val javaRoot = tryParseRoot(raw, littleEndian = false)
        if (javaRoot != null) {
            convertJavaStructure(javaRoot, fallbackName)?.let { return it }
        }
        // 2) Bedrock .mcstructure (little-endian)
        val bedrockRoot = tryParseRoot(raw, littleEndian = true)
        if (bedrockRoot != null) {
            convertBedrockStructure(bedrockRoot, fallbackName)?.let { return it }
        }
        return null
    }

    fun parseStructure(stream: InputStream, fallbackName: String = "Structure importée"): StructureLoader.StructureDef? {
        return try {
            parseStructure(stream.readBytes(), fallbackName)
        } catch (e: Exception) {
            Log.w("NbtStructureParser", "Lecture du flux impossible", e)
            null
        }
    }

    /** Racine NBT générique (exposée pour les tests). */
    internal fun parseRootForTest(bytes: ByteArray, littleEndian: Boolean): Map<String, NbtValue>? =
        tryParseRoot(bytes, littleEndian)

    // ── Lecture bas niveau ─────────────────────────────────────────────────

    private fun gunzip(bytes: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        GZIPInputStream(ByteArrayInputStream(bytes)).use { it.copyTo(out) }
        return out.toByteArray()
    }

    /** Lecteur NBT qui gère les deux boutismes et refuse les longueurs impossibles. */
    private class Reader(private val data: ByteArray, private val le: Boolean) {
        var pos = 0

        private fun need(n: Int) {
            if (n < 0 || pos + n > data.size) throw IllegalArgumentException("NBT tronqué ou corrompu")
        }

        fun u8(): Int { need(1); return data[pos++].toInt() and 0xFF }
        fun i8(): Byte { need(1); return data[pos++] }

        private fun bytesInt(n: Int): Long {
            need(n)
            var v = 0L
            if (le) {
                for (i in n - 1 downTo 0) v = (v shl 8) or (data[pos + i].toLong() and 0xFF)
            } else {
                for (i in 0 until n) v = (v shl 8) or (data[pos + i].toLong() and 0xFF)
            }
            pos += n
            return v
        }

        fun i16(): Short = bytesInt(2).toInt().toShort()
        fun u16(): Int = bytesInt(2).toInt() and 0xFFFF
        fun i32(): Int = bytesInt(4).toInt()
        fun i64(): Long = bytesInt(8)
        fun f32(): Float = java.lang.Float.intBitsToFloat(i32())
        fun f64(): Double = java.lang.Double.longBitsToDouble(i64())

        fun str(): String {
            val len = u16()
            need(len)
            val s = String(data, pos, len, Charsets.UTF_8)
            pos += len
            return s
        }

        /** Longueur de tableau/liste : jamais plus que les octets restants (anti-allocation géante). */
        fun length(minBytesPerElement: Int): Int {
            val len = i32()
            if (len < 0 || len.toLong() * minBytesPerElement > (data.size - pos)) {
                throw IllegalArgumentException("Longueur NBT invalide : $len")
            }
            return len
        }
    }

    private fun tryParseRoot(bytes: ByteArray, littleEndian: Boolean): Map<String, NbtValue>? = try {
        val r = Reader(bytes, littleEndian)
        if (r.u8() != TAG_COMPOUND) null
        else {
            r.str() // nom de la racine (souvent vide)
            readCompound(r)
        }
    } catch (e: Exception) {
        null
    }

    private fun readCompound(r: Reader): Map<String, NbtValue> {
        val map = linkedMapOf<String, NbtValue>()
        while (true) {
            val type = r.u8()
            if (type == TAG_END) break
            val name = r.str()
            map[name] = readPayload(r, type)
        }
        return map
    }

    private fun readPayload(r: Reader, type: Int): NbtValue = when (type) {
        TAG_BYTE -> NbtValue.ByteVal(r.i8())
        TAG_SHORT -> NbtValue.ShortVal(r.i16())
        TAG_INT -> NbtValue.IntVal(r.i32())
        TAG_LONG -> NbtValue.LongVal(r.i64())
        TAG_FLOAT -> NbtValue.FloatVal(r.f32())
        TAG_DOUBLE -> NbtValue.DoubleVal(r.f64())
        TAG_BYTE_ARRAY -> {
            val len = r.length(1)
            NbtValue.ByteArrayVal(ByteArray(len) { r.i8() })
        }
        TAG_STRING -> NbtValue.StringVal(r.str())
        TAG_LIST -> {
            val elemType = r.u8()
            val len = r.length(if (elemType == TAG_END) 0 else 1)
            val list = ArrayList<NbtValue>(len)
            if (elemType != TAG_END) repeat(len) { list.add(readPayload(r, elemType)) }
            NbtValue.ListVal(elemType, list)
        }
        TAG_COMPOUND -> NbtValue.CompoundVal(readCompound(r))
        TAG_INT_ARRAY -> {
            val len = r.length(4)
            NbtValue.IntArrayVal(IntArray(len) { r.i32() })
        }
        TAG_LONG_ARRAY -> {
            val len = r.length(8)
            NbtValue.LongArrayVal(LongArray(len) { r.i64() })
        }
        else -> throw IllegalArgumentException("Tag NBT inconnu: $type")
    }

    // ── Petits utilitaires ─────────────────────────────────────────────────

    /** Entiers d'un TAG_Int_Array OU d'une TAG_List d'entiers (les deux formes existent). */
    private fun ints(v: NbtValue?): IntArray? = when (v) {
        is NbtValue.IntArrayVal -> v.v
        is NbtValue.ListVal -> v.v.mapNotNull {
            when (it) {
                is NbtValue.IntVal -> it.v
                is NbtValue.ShortVal -> it.v.toInt()
                is NbtValue.ByteVal -> it.v.toInt()
                else -> null
            }
        }.toIntArray()
        else -> null
    }

    private fun scalarString(v: NbtValue): String? = when (v) {
        is NbtValue.StringVal -> v.v
        is NbtValue.ByteVal -> if (v.v.toInt() == 0) "false" else if (v.v.toInt() == 1) "true" else v.v.toString()
        is NbtValue.ShortVal -> v.v.toString()
        is NbtValue.IntVal -> v.v.toString()
        is NbtValue.LongVal -> v.v.toString()
        is NbtValue.FloatVal -> v.v.toString()
        is NbtValue.DoubleVal -> v.v.toString()
        else -> null
    }

    private fun idFrom(name: String): String = name
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .ifBlank { "structure_import" }

    private fun isAir(name: String) =
        name == "minecraft:air" || name.endsWith(":air") || name == "minecraft:structure_void"

    // ── Java Edition ──────────────────────────────────────────────────────

    private fun convertJavaStructure(root: Map<String, NbtValue>, fallbackName: String): StructureLoader.StructureDef? {
        val sizeArr = ints(root["size"]) ?: return null
        if (sizeArr.size < 3) return null
        val (sizeX, sizeY, sizeZ) = Triple(sizeArr[0], sizeArr[1], sizeArr[2])

        // "palette" (simple) ou "palettes" (variantes aléatoires : on prend la première)
        val paletteList = (root["palette"] as? NbtValue.ListVal)?.v
            ?: ((root["palettes"] as? NbtValue.ListVal)?.v?.firstOrNull() as? NbtValue.ListVal)?.v
            ?: return null
        val palette = paletteList.mapNotNull { entry ->
            val compound = (entry as? NbtValue.CompoundVal)?.v ?: return@mapNotNull null
            val name = (compound["Name"] as? NbtValue.StringVal)?.v ?: return@mapNotNull null
            val props = (compound["Properties"] as? NbtValue.CompoundVal)?.v
                ?.mapNotNull { (k, v) -> scalarString(v)?.let { k to it } }?.toMap()
            StructureLoader.StructureBlockState(Name = name, Properties = props)
        }
        if (palette.isEmpty()) return null

        val blocksList = (root["blocks"] as? NbtValue.ListVal)?.v ?: emptyList()
        val blocks = blocksList.mapNotNull { entry ->
            val compound = (entry as? NbtValue.CompoundVal)?.v ?: return@mapNotNull null
            val pos = ints(compound["pos"])
            if (pos == null || pos.size < 3) return@mapNotNull null
            val state = when (val s = compound["state"]) {
                is NbtValue.IntVal -> s.v
                is NbtValue.ByteVal -> s.v.toInt()
                is NbtValue.ShortVal -> s.v.toInt()
                else -> return@mapNotNull null
            }
            val blockName = palette.getOrNull(state)?.Name ?: ""
            if (isAir(blockName)) return@mapNotNull null
            StructureLoader.StructureBlock(x = pos[0], y = pos[1], z = pos[2], state = state)
        }

        return StructureLoader.StructureDef(
            id = idFrom(fallbackName),
            name = fallbackName,
            description = "Importée depuis un fichier NBT Java (${sizeX}×${sizeY}×${sizeZ})",
            size = StructureLoader.StructureSize(x = sizeX, y = sizeY, z = sizeZ),
            palette = palette,
            blocks = blocks
        )
    }

    // ── Bedrock Edition (.mcstructure) ────────────────────────────────────

    private fun convertBedrockStructure(root: Map<String, NbtValue>, fallbackName: String): StructureLoader.StructureDef? {
        val size = ints(root["size"]) ?: return null
        if (size.size < 3) return null
        val (sx, sy, sz) = Triple(size[0], size[1], size[2])
        if (sx <= 0 || sy <= 0 || sz <= 0) return null
        val total = sx.toLong() * sy * sz
        if (total > MAX_BLOCKS) return null

        val structure = (root["structure"] as? NbtValue.CompoundVal)?.v ?: return null
        val layers = (structure["block_indices"] as? NbtValue.ListVal)?.v ?: return null
        val primary = ints(layers.firstOrNull()) ?: return null

        val paletteRoot = (structure["palette"] as? NbtValue.CompoundVal)?.v ?: return null
        val defaultPalette = (paletteRoot["default"] as? NbtValue.CompoundVal)?.v ?: return null
        val blockPalette = (defaultPalette["block_palette"] as? NbtValue.ListVal)?.v ?: return null
        val palette = blockPalette.map { entry ->
            val c = (entry as? NbtValue.CompoundVal)?.v ?: emptyMap()
            val name = (c["name"] as? NbtValue.StringVal)?.v ?: "minecraft:air"
            val states = (c["states"] as? NbtValue.CompoundVal)?.v
                ?.mapNotNull { (k, v) -> scalarString(v)?.let { k to it } }?.toMap()
            StructureLoader.StructureBlockState(Name = name, Properties = states?.ifEmpty { null })
        }
        if (palette.isEmpty()) return null

        // Ordre Bedrock : index = (x * sy + y) * sz + z  (z varie le plus vite). -1 = vide.
        val blocks = ArrayList<StructureLoader.StructureBlock>()
        val n = minOf(primary.size.toLong(), total).toInt()
        for (i in 0 until n) {
            val state = primary[i]
            if (state < 0 || state >= palette.size) continue
            if (isAir(palette[state].Name)) continue
            val z = i % sz
            val y = (i / sz) % sy
            val x = i / (sy * sz)
            blocks += StructureLoader.StructureBlock(x = x, y = y, z = z, state = state)
        }

        return StructureLoader.StructureDef(
            id = idFrom(fallbackName),
            name = fallbackName,
            description = "Importée depuis un .mcstructure Bedrock (${sx}×${sy}×${sz})",
            size = StructureLoader.StructureSize(x = sx, y = sy, z = sz),
            palette = palette,
            blocks = blocks
        )
    }
}
