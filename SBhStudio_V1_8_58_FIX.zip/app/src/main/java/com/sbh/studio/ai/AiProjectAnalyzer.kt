package com.sbh.studio.ai

import android.content.Context
import com.sbh.studio.animation.AnimationRepository
import com.sbh.studio.data.BlockRepository
import com.sbh.studio.data.Identifiers
import com.sbh.studio.data.ItemRepository
import com.sbh.studio.data.MobEngine
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.ProjectRepository
import com.sbh.studio.workshop.WorkshopRepository

/**
 * Analyse locale du projet SBh (phase 1) — sans passerelle cloud.
 * Produit un rapport structuré + un résumé compact pour le chat (phase 2).
 */
data class AiFinding(
    val severity: String, // error | warn | info
    val zone: String,
    val message: String
)

data class AiProjectReport(
    val projectName: String,
    val projectId: String?,
    val counts: Map<String, Int>,
    val findings: List<AiFinding>,
    val generatedAtMs: Long = System.currentTimeMillis()
) {
    val errorCount get() = findings.count { it.severity == "error" }
    val warnCount get() = findings.count { it.severity == "warn" }

    fun toDisplayText(): String = buildString {
        appendLine("=== Analyse locale SBh AI ===")
        appendLine("Projet : $projectName${projectId?.let { " ($it)" } ?: ""}")
        appendLine(
            "Contenu : " + counts.entries.joinToString(" · ") { "${it.value} ${it.key}" }
        )
        appendLine("Alertes : $errorCount erreur(s), $warnCount avertissement(s)")
        appendLine()
        if (findings.isEmpty()) {
            appendLine("Aucune alerte bloquante détectée.")
        } else {
            findings.forEach { f ->
                val mark = when (f.severity) {
                    "error" -> "🔴"
                    "warn" -> "🟡"
                    else -> "🔵"
                }
                appendLine("$mark [${f.zone}] ${f.message}")
            }
        }
    }

    /** Résumé court injecté dans le prompt cloud (phase 2). */
    fun toChatContext(maxChars: Int = 2800): String {
        val body = buildString {
            appendLine("Contexte projet SBh Studio (analyse locale, ne pas inventer d'objets absents) :")
            appendLine("Projet=$projectName id=${projectId ?: "?"}")
            appendLine("Compteurs: ${counts.entries.joinToString { "${it.key}=${it.value}" }}")
            appendLine("Erreurs=$errorCount Avertissements=$warnCount")
            findings.take(40).forEach { f ->
                appendLine("- ${f.severity.uppercase()} [${f.zone}] ${f.message}")
            }
            if (findings.size > 40) appendLine("… +${findings.size - 40} autres")
        }
        return if (body.length <= maxChars) body else body.take(maxChars - 20) + "\n… (tronqué)"
    }
}

object AiProjectAnalyzer {

    fun analyze(context: Context): AiProjectReport {
        val projects = runCatching { ProjectRepository(context).load() }.getOrDefault(emptyList())
        val project = com.sbh.studio.data.ActiveProject.resolve(context, projects)
        val projectId = project?.id
        val projectName = project?.name ?: "(aucun projet ouvert — analyse globale des fichiers locaux)"

        val mobs = runCatching { MobRepository(context).loadAll() }.getOrDefault(emptyList())
            .let { list -> if (projectId != null) list.filter { it.projectId == projectId } else list }
        val items = runCatching { ItemRepository(context).loadAll() }.getOrDefault(emptyList())
            .let { list -> if (projectId != null) list.filter { it.projectId == projectId } else list }
        val blocks = runCatching { BlockRepository(context).loadAll() }.getOrDefault(emptyList())
            .let { list -> if (projectId != null) list.filter { it.projectId == projectId } else list }
        val ws = WorkshopRepository(context)
        val portals = runCatching { ws.loadPortals() }.getOrDefault(emptyList())
            .let { list -> if (projectId != null) list.filter { it.projectId == projectId } else list }
        val maps = runCatching { ws.loadMaps() }.getOrDefault(emptyList())
            .let { list -> if (projectId != null) list.filter { it.projectId == projectId } else list }
        val recipes = runCatching { ws.loadRecipes() }.getOrDefault(emptyList())
            .let { list -> if (projectId != null) list.filter { it.projectId == projectId } else list }
        val anims = runCatching { AnimationRepository(context).loadAll() }.getOrDefault(emptyList())

        val findings = mutableListOf<AiFinding>()

        if (project == null) {
            findings += AiFinding("warn", "Projet", "Aucun projet dans ProjectRepository — l'analyse porte sur toutes les données locales.")
        }

        // --- Mobs ---
        val mobIdents = mutableSetOf<String>()
        mobs.forEach { m ->
            if (!Identifiers.isValid(m.identifiant)) {
                findings += AiFinding("error", "Mobs", "« ${m.nom} » : identifiant invalide « ${m.identifiant} »")
            } else if (!mobIdents.add(m.identifiant)) {
                findings += AiFinding("error", "Mobs", "Identifiant en double : ${m.identifiant}")
            }
            MobEngine.validate(m).issues.forEach { issue ->
                val sev = when (issue.level) {
                    MobEngine.Issue.Level.ERROR -> "error"
                    MobEngine.Issue.Level.WARN -> "warn"
                    else -> "info"
                }
                findings += AiFinding(sev, "Mobs", "« ${m.nom} » : ${issue.message}")
            }
            val hasAnim = anims.any { it.linkedMobId == m.id || it.linkedMobIdentifier == m.identifiant }
            if (!hasAnim) {
                findings += AiFinding("info", "Mobs", "« ${m.nom} » : aucune animation liée")
            }
        }

        // --- Items ---
        val itemIdents = mutableSetOf<String>()
        items.forEach { i ->
            if (!Identifiers.isValid(i.identifier)) {
                findings += AiFinding("error", "Items", "« ${i.name} » : id invalide « ${i.identifier} »")
            } else if (!itemIdents.add(i.identifier)) {
                findings += AiFinding("error", "Items", "Identifiant en double : ${i.identifier}")
            }
            if (i.textureUri.isNullOrBlank()) {
                findings += AiFinding("warn", "Items", "« ${i.name} » : sans texture")
            }
            if (i.category.equals("weapon", true) && i.damage <= 0) {
                findings += AiFinding("info", "Items", "« ${i.name} » : arme avec damage=0")
            }
        }

        // --- Blocks ---
        val blockIdents = mutableSetOf<String>()
        blocks.forEach { b ->
            if (!Identifiers.isValid(b.identifier)) {
                findings += AiFinding("error", "Blocs", "« ${b.name} » : id invalide « ${b.identifier} »")
            } else if (!blockIdents.add(b.identifier)) {
                findings += AiFinding("error", "Blocs", "Identifiant en double : ${b.identifier}")
            }
            if (b.textureUri.isNullOrBlank()) {
                findings += AiFinding("warn", "Blocs", "« ${b.name} » : sans texture")
            }
        }

        // --- Portals ---
        portals.forEach { p ->
            if (p.width < 2 || p.height < 3) {
                findings += AiFinding("warn", "Portails", "« ${p.name} » : taille ${p.width}×${p.height} inhabituelle")
            }
            if (p.frameBlock.isBlank()) {
                findings += AiFinding("error", "Portails", "« ${p.name} » : bloc cadre vide")
            }
            if (p.linkedMapId != null && maps.none { it.id == p.linkedMapId }) {
                findings += AiFinding("warn", "Portails", "« ${p.name} » : map liée introuvable")
            }
        }

        // --- Maps ---
        maps.forEach { m ->
            if (m.sizeX < 8 || m.sizeZ < 8) {
                findings += AiFinding("info", "Maps", "« ${m.name} » : petite surface ${m.sizeX}×${m.sizeZ}")
            }
        }

        // --- Recipes ---
        val knownIds = itemIdents + blockIdents
        recipes.forEach { r ->
            if (!Identifiers.isValid(r.identifier)) {
                findings += AiFinding("error", "Recettes", "« ${r.name} » : id invalide « ${r.identifier} »")
            }
            if (r.resultId.isBlank()) {
                findings += AiFinding("error", "Recettes", "« ${r.name} » : résultat vide")
            } else if (knownIds.isNotEmpty() && r.resultId !in knownIds && !r.resultId.startsWith("minecraft:")) {
                findings += AiFinding("info", "Recettes", "« ${r.name} » : résultat ${r.resultId} hors items/blocs du projet")
            }
            val filled = if (r.type.contains("shapeless")) r.ingredients.size
            else r.pattern.count { it.isNotBlank() }
            if (filled == 0) {
                findings += AiFinding("warn", "Recettes", "« ${r.name} » : grille / ingrédients vides")
            }
        }

        val counts = linkedMapOf(
            "mobs" to mobs.size,
            "items" to items.size,
            "blocs" to blocks.size,
            "portails" to portals.size,
            "maps" to maps.size,
            "recettes" to recipes.size,
            "animations" to anims.size
        )

        return AiProjectReport(
            projectName = projectName,
            projectId = projectId,
            counts = counts,
            findings = findings
        )
    }
}
