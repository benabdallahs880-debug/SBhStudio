package com.sbh.studio.generator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import com.sbh.studio.data.Identifiers
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobShapeCatalog
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.workshop.PortalBlueprint
import com.sbh.studio.workshop.RecipeBlueprint
import com.sbh.studio.texture.TextureSources
import com.sbh.studio.animation.AnimationRepository
import com.sbh.studio.animation.AnimationExport
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObjectBuilder
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/**
 * Générateur de structure Bedrock BP/RP et export .mcaddon.
 *
 * Les composants générés suivent ceux que la « fondation » (foundation/) utilise déjà :
 * avant, ce générateur (celui de l'export projet) produisait des créatures sans déplacement
 * ni rendu, des items sans icône ni dégâts et des blocs sans texture reliée.
 */
class PackGenerator(private val context: Context) {

    data class ExportResult(val file: File, val warnings: List<String>)

    fun validate(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint> = emptyList()
    ): List<String> {
        val errors = mutableListOf<String>()
        if (project.name.isBlank()) errors += "Le projet doit avoir un nom."

        mobs.forEach { m -> Identifiers.explain(m.identifiant)?.let { errors += "Créature « ${m.nom} » : $it (${m.identifiant})" } }
        items.forEach { i -> Identifiers.explain(i.identifier)?.let { errors += "Item « ${i.name} » : $it (${i.identifier})" } }
        blocks.forEach { b -> Identifiers.explain(b.identifier)?.let { errors += "Bloc « ${b.name} » : $it (${b.identifier})" } }
        portals.forEach { p -> Identifiers.explain(p.identifier)?.let { errors += "Portail « ${p.name} » : $it (${p.identifier})" } }

        mobs.filter { it.vie <= 0 || it.degats < 0 || it.vitesse <= 0 }
            .forEach { errors += "Créature « ${it.nom} » : vie, dégâts ou vitesse invalides." }
        items.filter { it.damage < 0 || it.durability <= 0 }
            .forEach { errors += "Item « ${it.name} » : dégâts ou durabilité invalides." }
        blocks.filter { it.hardness < 0 }
            .forEach { errors += "Bloc « ${it.name} » : résistance négative." }

        // Deux identifiants d'espaces différents mais de même nom technique (agw:roi / sbh:roi) écriraient
        // le même fichier dans le pack ; auparavant l'export échouait avec une erreur de zip cryptique.
        fun collisions(kind: String, ids: List<String>) {
            ids.filter { Identifiers.isValid(it) }
                .groupBy { Identifiers.nameOf(it) }
                .filter { it.value.size > 1 }
                .forEach { (name, list) -> errors += "$kind : le nom technique « $name » est partagé par ${list.joinToString()}." }
            ids.filter { Identifiers.isValid(it) }
                .groupBy { textureKey(it) }
                .filter { it.value.size > 1 }
                .forEach { (key, list) -> errors += "$kind : la clé de texture « $key » est partagée par ${list.joinToString()}." }
        }
        collisions("Créatures", mobs.map { it.identifiant })
        collisions("Items", items.map { it.identifier })
        collisions("Blocs et portails", blocks.map { it.identifier } + portals.map { it.identifier })
        return errors.distinct()
    }

    fun export(project: SbhProject, mobs: List<MobEntity>, items: List<SbhItem>, blocks: List<SbhBlock>): File =
        export(project, mobs, items, blocks, emptyMap())

    fun export(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        extraFiles: Map<String, String>
    ): File = exportDetailed(project, mobs, items, blocks, emptyList(), extraFiles).file

    /**
     * Produit un vrai .mcaddon : deux .mcpack internes (BP + RP).
     * Les UUID de pack/module sont persistants par projet afin d'éviter de casser
     * les dépendances Minecraft à chaque export.
     *
     * [extraBinaryFiles] : fichiers binaires supplémentaires (chemin préfixé « BP/ » ou « RP/ »).
     */
    fun exportDetailed(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint>,
        extraFiles: Map<String, String>,
        extraBinaryFiles: Map<String, ByteArray> = emptyMap(),
        recipes: List<RecipeBlueprint> = emptyList()
    ): ExportResult {
        val errors = validate(project, mobs, items, blocks, portals)
        require(errors.isEmpty()) { errors.joinToString("\n") }

        val warnings = mutableListOf<String>()
        val content = Content(project, mobs, items, blocks, portals, recipes)
        val bpName = "SBh_${safe(project.name)}_BP"
        val rpName = "SBh_${safe(project.name)}_RP"
        val ids = loadPackIds(project.id)
        // V1.8.58 : version qui augmente à chaque export (sinon Minecraft garde l'ancien pack).
        val packVersion = PackVersioning.asString(PackVersioning.versionFor(project.version, ids.exportCount))
        val scriptModuleUuid = if (portals.isNotEmpty()) ids.bpScriptModuleUuid else null
        // V1.8.58 : le pack de COMPORTEMENT dépend du pack de RESSOURCES (convention Bedrock) :
        // activer le BP active aussi le RP. Avant c'était l'inverse : BP seul = mobs sans rendu.
        val bpPack = zipPack(bpName, "data", ids.bpUuid, ids.bpModuleUuid, content, extraFiles, extraBinaryFiles, true, ids.rpUuid, warnings, scriptModuleUuid, packVersion)
        val rpPack = zipPack(rpName, "resources", ids.rpUuid, ids.rpModuleUuid, content, extraFiles, extraBinaryFiles, false, null, warnings, null, packVersion)

        val out = File(context.cacheDir, "${safe(project.name)}-$packVersion.mcaddon")
        ZipOutputStream(out.outputStream().buffered()).use { addon ->
            val w = EntryWriter(addon)
            w.bytes("$bpName.mcpack", bpPack)
            w.bytes("$rpName.mcpack", rpPack)
            w.text("README.txt", "SBh Studio — pack $packVersion\nPack BP + RP généré pour Minecraft Bedrock.\n")
        }
        warnings += "Version du pack : $packVersion (augmente à chaque export pour que Minecraft remplace l'ancienne version)."
        return ExportResult(out, warnings.distinct())
    }

    private class Content(
        val project: SbhProject,
        val mobs: List<MobEntity>,
        val items: List<SbhItem>,
        val blocks: List<SbhBlock>,
        val portals: List<PortalBlueprint>,
        val recipes: List<RecipeBlueprint> = emptyList()
    )

    /** Écrit dans un zip en ignorant un chemin déjà écrit (un doublon ferait échouer tout l'export). */
    private class EntryWriter(private val zip: ZipOutputStream) {
        private val seen = HashSet<String>()
        fun text(path: String, content: String) = bytes(path, content.toByteArray(Charsets.UTF_8))
        fun bytes(path: String, data: ByteArray) {
            if (!seen.add(path)) return
            zip.putNextEntry(ZipEntry(path))
            zip.write(data)
            zip.closeEntry()
        }
    }

    private data class PackIds(
        val bpUuid: String,
        val bpModuleUuid: String,
        val rpUuid: String,
        val rpModuleUuid: String,
        // Module de script BP (téléportation des portails). Séparé du module "data"
        // ci-dessus ; persistant pour ne pas casser le pack à chaque export.
        val bpScriptModuleUuid: String,
        /** Numéro de cet export (1, 2, 3…) → 3e chiffre de la version du pack. */
        val exportCount: Int
    )

    private fun loadPackIds(projectId: String): PackIds {
        val file = File(context.filesDir, "sbh_pack_ids_${safe(projectId)}.json")
        val existing = runCatching {
            if (!file.exists()) null else Json.parseToJsonElement(file.readText()).jsonObject
        }.getOrNull()
        fun stored(key: String): String? = existing?.get(key)?.jsonPrimitive?.content?.takeIf { it.isNotBlank() }
        val ids = PackIds(
            stored("bp") ?: java.util.UUID.randomUUID().toString(),
            stored("bpModule") ?: java.util.UUID.randomUUID().toString(),
            stored("rp") ?: java.util.UUID.randomUUID().toString(),
            stored("rpModule") ?: java.util.UUID.randomUUID().toString(),
            stored("bpScriptModule") ?: java.util.UUID.randomUUID().toString(),
            (stored("exportCount")?.toIntOrNull() ?: 0) + 1
        )
        com.sbh.studio.data.SafeStore.write(file, buildJsonObject {
            put("bp", ids.bpUuid); put("bpModule", ids.bpModuleUuid)
            put("rp", ids.rpUuid); put("rpModule", ids.rpModuleUuid)
            put("bpScriptModule", ids.bpScriptModuleUuid)
            put("exportCount", ids.exportCount)
        }.toString())
        return ids
    }

    private fun zipPack(
        name: String, type: String, uuid: String, moduleUuid: String,
        c: Content,
        extraFiles: Map<String, String>,
        extraBinaryFiles: Map<String, ByteArray>,
        isBp: Boolean,
        dependencyUuid: String?,
        warnings: MutableList<String>,
        scriptModuleUuid: String? = null,
        packVersion: String = c.project.version
    ): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            val w = EntryWriter(zip)
            w.text("manifest.json", manifest(name, type, uuid, moduleUuid, packVersion, dependencyUuid, scriptModuleUuid))
            if (isBp && scriptModuleUuid != null && c.portals.isNotEmpty()) {
                w.text("scripts/main.js", portalScriptJs(c.portals))
            }
            if (isBp) {
                c.mobs.forEach { mob ->
                    val (ns, id) = splitId(mob.identifiant)
                    w.text("entities/$id.json", mobJson(mob, ns, id))
                }
                c.items.forEach { item ->
                    val (ns, id) = splitId(item.identifier)
                    w.text("items/$id.json", itemJson(item, ns, id))
                }
                c.blocks.forEach { block ->
                    val (ns, id) = splitId(block.identifier)
                    w.text("blocks/$id.json", blockJson(ns, id, block.hardness, block.lightLevel.takeIf { it > 0 }))
                }
                c.portals.forEach { portal ->
                    val (ns, id) = splitId(portal.identifier)
                    w.text("blocks/$id.json", blockJson(ns, id, 2.0, 8))
                }
                // V1.8.58 : les recettes de l'Atelier sont enfin écrites dans le pack.
                c.recipes.forEach { recipe ->
                    val json = RecipePackJson.json(recipe)
                    if (json == null) {
                        warnings += "Recette « ${recipe.name} » ignorée : grille ou ingrédients vides."
                    } else {
                        w.text(RecipePackJson.path(recipe), json)
                    }
                }
            } else {
                // Correctif critique : le client_entity de chaque mob référence
                // "controller.render.default" (ligne resourceEntityJson) mais ce contrôleur
                // n'était jamais défini nulle part dans le Resource Pack — sans lui, Minecraft
                // ne sait pas quel geometry/texture/material associer et le mob reste invisible
                // en jeu, quelle que soit la texture ou la géométrie choisies.
                if (c.mobs.isNotEmpty()) {
                    w.text("render_controllers/sbh_default.render_controllers.json", defaultRenderControllerJson())
                }
                if (c.items.isNotEmpty()) {
                    w.text("textures/item_texture.json", textureAtlasJson("atlas.items", "textures/items", c.items.map { textureKey(it.identifier) }))
                }
                val terrainKeys = c.blocks.map { textureKey(it.identifier) } + c.portals.map { textureKey(it.identifier) }
                if (terrainKeys.isNotEmpty()) {
                    w.text("textures/terrain_texture.json", textureAtlasJson("atlas.terrain", "textures/blocks", terrainKeys))
                }
                val animRepo = AnimationRepository(context)
                val animProjects = animRepo.loadAll()
                c.mobs.forEach { mob ->
                    val (ns, id) = splitId(mob.identifiant)
                    val key = textureKey(mob.identifiant)
                    val linkedAnim = animProjects.firstOrNull { it.linkedMobId == mob.id || it.linkedMobIdentifier == mob.identifiant }
                    w.text("entity/$id.entity.json", resourceEntityJson(mob, ns, id, key, linkedAnim != null))
                    w.bytes(
                        "textures/entity/$key.png",
                        // Toujours normaliser en 64x64 (pixel-art, centré) pour éviter les textures
                        // brutes de taille arbitraire qui cassent le rendu. Un avertissement est
                        // déjà émis par normalizeMobSkin si la taille d'origine diffère.
                        normalizeMobSkin(mob.textureUri, mob.nom, key, warnings, mob.formeBase)
                    )
                    if (linkedAnim != null) {
                        w.text("animations/${id}.animation.json", AnimationExport.animationJson(linkedAnim, mob.identifiant, mob.formeBase))
                        w.text("animation_controllers/${id}.controller.json", AnimationExport.controllerJson(mob.identifiant))
                    }
                }
                c.items.forEach { item ->
                    val key = textureKey(item.identifier)
                    w.bytes("textures/items/$key.png", textureBytes(item.textureUri, 16, item.name, key, warnings))
                }
                c.blocks.forEach { block ->
                    val key = textureKey(block.identifier)
                    w.bytes("textures/blocks/$key.png", textureBytes(block.textureUri, 16, block.name, key, warnings))
                }
                c.portals.forEach { portal ->
                    val key = textureKey(portal.identifier)
                    w.bytes("textures/blocks/$key.png", textureBytes(portal.frameTextureId, 16, portal.name, key, warnings))
                }
            }
            val prefix = if (isBp) "BP/" else "RP/"
            extraFiles.forEach { (path, content) ->
                if (path.startsWith(prefix)) w.text(path.removePrefix(prefix), content)
            }
            extraBinaryFiles.forEach { (path, data) ->
                if (path.startsWith(prefix)) w.bytes(path.removePrefix(prefix), data)
            }
            if (!isBp) w.text("README.txt", "SBh Studio $packVersion — Resource Pack")
        }
        return out.toByteArray()
    }

    /**
     * [scriptModuleUuid] : si non nul, ajoute un module "script" (téléportation des portails,
     * scripts/main.js) et sa dépendance @minecraft/server — uniquement sur le manifest BP,
     * et seulement quand le projet contient au moins un portail.
     */
    private fun manifest(
        name: String, type: String, uuid: String, moduleUuid: String, versionName: String,
        dependencyUuid: String?, scriptModuleUuid: String? = null
    ): String = buildJsonObject {
        put("format_version", 2)
        putJsonObject("header") {
            put("name", name)
            put("description", "Generated by SBh Studio")
            put("uuid", uuid)
            put("version", versionArray(versionName))
            putJsonArray("min_engine_version") { add(1); add(21); add(0) }
        }
        putJsonArray("modules") {
            add(buildJsonObject {
                put("type", type)
                put("uuid", moduleUuid)
                put("version", versionArray(versionName))
            })
            if (scriptModuleUuid != null) add(buildJsonObject {
                put("type", "script")
                put("language", "javascript")
                put("uuid", scriptModuleUuid)
                put("entry", "scripts/main.js")
                put("version", versionArray(versionName))
            })
        }
        if (dependencyUuid != null || scriptModuleUuid != null) putJsonArray("dependencies") {
            if (dependencyUuid != null) add(buildJsonObject {
                put("uuid", dependencyUuid)
                put("version", versionArray(versionName))
            })
            // Version stable de @minecraft/server compatible avec le moteur 1.21.x ciblé par SBh Studio.
            if (scriptModuleUuid != null) add(buildJsonObject {
                put("module_name", "@minecraft/server")
                put("version", "1.17.0")
            })
        }
    }.toString()

    private fun versionArray(value: String) = buildJsonArray {
        val parts = value.split('.').take(3).map { it.toIntOrNull() ?: 0 }
        parts.forEach { add(it) }
        repeat((3 - parts.size).coerceAtLeast(0)) { add(0) }
    }

    // ── Textures ──────────────────────────────────────────────────────────

    /**
     * Texture fournie par l'utilisateur (ré-encodée en vrai PNG : le sélecteur accepte aussi les JPEG,
     * qui étaient auparavant copiés tels quels sous une extension .png), sinon texture provisoire.
     * Auparavant une texture absente ou illisible était ignorée sans rien dire et le jeu affichait
     * la texture « manquante » violette et noire.
     */
    private fun textureBytes(uri: String?, size: Int, label: String, key: String, warnings: MutableList<String>): ByteArray {
        if (uri != null) {
            val png = loadPng(uri)
            if (png != null) return png
            warnings += "Texture illisible pour « $label » (fichier déplacé ou supprimé ?) — texture provisoire utilisée."
        }
        return placeholderPng(size, key)
    }

    /**
     * V1.8.58 : la texture est mise au format attendu par la géométrie de la forme choisie
     * (64×64 pour humanoïde/zombie, 64×32 pour araignée, vache, loup, poule, creeper,
     * squelette — voir MobShapeCatalog). Mise à l'échelle sur la LARGEUR, calée en haut à
     * gauche, comme la disposition des skins Minecraft (un skin 64×32 dans un 64×64 garde ses
     * UV ; un 64×64 dans un 64×32 garde sa moitié haute, qui est la disposition classique).
     * Avant : tout était forcé en 64×64 et CENTRÉ → texture décalée sur les formes en 64×32.
     */
    private fun normalizeMobSkin(
        uri: String?,
        label: String,
        key: String,
        warnings: MutableList<String>,
        formeBase: String = "humanoid"
    ): ByteArray {
        val (targetW, targetH) = MobShapeCatalog.textureSizeFor(formeBase)
        val raw = uri?.let { loadPng(it) }
        val src = raw?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size) }.getOrNull() }
        if (uri != null && src == null) {
            warnings += "Texture illisible pour « $label » (fichier déplacé ou supprimé ?) — texture provisoire utilisée."
        }
        if (src == null) return placeholderPng(targetW, key, targetH)

        if (src.width != targetW || src.height != targetH) {
            warnings += "Texture « $label » adaptée en ${targetW}x${targetH} pour la forme « $formeBase » " +
                "(taille d'origine ${src.width}x${src.height})."
        }
        val scale = targetW.toFloat() / src.width
        val w = targetW
        val h = (src.height * scale).roundToInt().coerceAtLeast(1)
        // filter=false : mise à l'échelle « pixel art », sans flou.
        val scaled = Bitmap.createScaledBitmap(src, w, h, false)
        val canvas = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        Canvas(canvas).drawBitmap(scaled, 0f, 0f, null)

        val out = ByteArrayOutputStream()
        canvas.compress(Bitmap.CompressFormat.PNG, 100, out)
        if (scaled !== src) scaled.recycle()
        src.recycle()
        canvas.recycle()
        return out.toByteArray()
    }

    private fun loadPng(uriString: String): ByteArray? {
        return try {
        val size = TextureSources.readSize(context, uriString)
        if (size == null) {
            null
        } else {
            val (w, h) = size
            var sample = 1
            while (w / sample > MAX_TEXTURE || h / sample > MAX_TEXTURE) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = TextureSources.openStream(context, uriString)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp == null) {
                null
            } else {
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                bmp.recycle()
                out.toByteArray()
            }
        }
    } catch (e: Exception) {
        android.util.Log.w("PackGenerator", "Texture URI illisible: $uriString", e)
        null
    }
    }

    private fun placeholderPng(size: Int, seed: String, height: Int = size): ByteArray {
        val hash = seed.hashCode()
        val base = Color.HSVToColor(floatArrayOf(((hash and 0x7fffffff) % 360).toFloat(), 0.35f, 0.55f))
        val rnd = Random(hash)
        val bmp = Bitmap.createBitmap(size, height, Bitmap.Config.ARGB_8888)
        for (y in 0 until height) for (x in 0 until size) {
            val v = rnd.nextInt(31) - 15
            bmp.setPixel(x, y, Color.rgb(clamp(Color.red(base) + v), clamp(Color.green(base) + v), clamp(Color.blue(base) + v)))
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return out.toByteArray()
    }

    private fun clamp(v: Int) = v.coerceIn(0, 255)

    private fun eggColor(seed: String, value: Float): String = MobPackJson.eggColor(seed, value)

    private fun textureAtlasJson(atlas: String, dir: String, keys: List<String>): String = buildJsonObject {
        put("resource_pack_name", "vanilla")
        put("texture_name", atlas)
        putJsonObject("texture_data") {
            keys.distinct().forEach { key -> putJsonObject(key) { put("textures", "$dir/$key") } }
        }
    }.toString()

    /** Échappe une chaîne pour un littéral JS/JSON double-quoté. */
    private fun jsString(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    /**
     * Script BP qui rend les portails réellement fonctionnels : avant, un portail n'était
     * qu'un bloc décoratif (lumineux) sans aucun effet — ce script téléporte le joueur qui
     * marche dessus vers les coordonnées choisies dans l'Atelier, avec un cooldown pour éviter
     * les allers-retours en boucle entre deux portails proches.
     */
    private fun portalScriptJs(portals: List<PortalBlueprint>): String {
        val entries = portals.joinToString(",\n") { p ->
            val (ns, id) = splitId(p.identifier)
            val typeId = jsString("$ns:$id")
            val dim = jsString(p.destDimension)
            "  ${typeId}: { x: ${p.destX}, y: ${p.destY}, z: ${p.destZ}, dimension: $dim }"
        }
        return """
            |import { world, system } from "@minecraft/server";
            |
            |// Portails générés par SBh Studio : bloc -> destination.
            |const PORTALS = {
            |$entries
            |};
            |
            |const COOLDOWN_TICKS = 40;
            |const lastTeleport = new Map();
            |
            |system.runInterval(() => {
            |  const now = system.currentTick;
            |  for (const player of world.getPlayers()) {
            |    const last = lastTeleport.get(player.id) ?? -Infinity;
            |    if (now - last < COOLDOWN_TICKS) continue;
            |    // Le portail est un bloc plein : le joueur se tient DESSUS. On regarde donc le bloc
            |    // aux pieds puis celui juste en dessous (avant : seulement aux pieds → jamais trouvé).
            |    const loc = player.location;
            |    let dest;
            |    try {
            |      const feet = player.dimension.getBlock(loc);
            |      dest = feet ? PORTALS[feet.typeId] : undefined;
            |      if (!dest) {
            |        const below = player.dimension.getBlock({ x: loc.x, y: loc.y - 1, z: loc.z });
            |        dest = below ? PORTALS[below.typeId] : undefined;
            |      }
            |    } catch (e) { continue; }
            |    if (!dest) continue;
            |    try {
            |      const targetDimension = world.getDimension(dest.dimension);
            |      player.teleport(
            |        { x: dest.x + 0.5, y: dest.y, z: dest.z + 0.5 },
            |        { dimension: targetDimension }
            |      );
            |      lastTeleport.set(player.id, now);
            |    } catch (e) {
            |      // Dimension ou coordonnées invalides : on ignore plutôt que de faire planter le script.
            |    }
            |  }
            |}, 5);
            |""".trimMargin()
    }

    // ── Contenu Bedrock ───────────────────────────────────────────────────

    private fun mobJson(m: MobEntity, ns: String, id: String): String =
        MobPackJson.behaviorEntityJson(m, ns, id)

    private fun resourceEntityJson(m: MobEntity, ns: String, id: String, key: String, hasAnim: Boolean = false): String =
        MobPackJson.clientEntityJson(m, ns, id, key, hasAnim)

    /**
     * Contrôleur de rendu générique, partagé par tous les mobs du projet.
     * Il relie les clés "default" (geometry/materials/textures) déclarées dans le
     * client_entity de chaque mob (resourceEntityJson) à un rendu réel — sans ce
     * fichier, "controller.render.default" ne correspond à rien et Minecraft
     * n'affiche pas l'entité, quelle que soit sa texture ou sa géométrie.
     */
    private fun defaultRenderControllerJson(): String = buildJsonObject {
        put("format_version", "1.10.0")
        putJsonObject("render_controllers") {
            putJsonObject("controller.render.default") {
                put("geometry", "Geometry.default")
                putJsonArray("materials") { add(buildJsonObject { put("*", "Material.default") }) }
                putJsonArray("textures") { add("Texture.default") }
            }
        }
    }.toString()

    private fun itemJson(i: SbhItem, ns: String, id: String): String {
        val lower = id.lowercase()
        val isShield = "shield" in lower
        val isWeapon = (!isShield) && (i.damage > 0 || "sword" in lower || "axe" in lower || "mace" in lower)
        val isArmor = anyOf(lower, "helmet", "chestplate", "leggings", "boots")
        val equipment = isWeapon || isShield || isArmor || i.durability > 1
        val slot = when {
            i.slot in listOf("head", "armor.head") || "helmet" in lower -> "slot.armor.head"
            i.slot in listOf("chest", "armor.chest") || "chestplate" in lower -> "slot.armor.chest"
            i.slot in listOf("legs", "armor.legs") || "leggings" in lower -> "slot.armor.legs"
            i.slot in listOf("feet", "armor.feet") || "boots" in lower -> "slot.armor.feet"
            else -> null
        }
        // Protection approximative selon le palier dans l'id (leather…netherite).
        val protection = when {
            "netherite" in lower -> 3
            "diamond" in lower -> 3
            "iron" in lower || "chainmail" in lower -> 2
            "gold" in lower || "leather" in lower -> 1
            else -> 2
        }
        return buildJsonObject {
            put("format_version", "1.21.0")
            putJsonObject("minecraft:item") {
                putJsonObject("description") {
                    put("identifier", "$ns:$id")
                    putJsonObject("menu_category") {
                        put("category", if (equipment) "equipment" else "items")
                        when {
                            isWeapon && "sword" in lower -> put("group", "itemGroup.name.sword")
                            isWeapon && "axe" in lower -> put("group", "itemGroup.name.axe")
                            isArmor -> put("group", "itemGroup.name.chestplate")
                        }
                    }
                }
                putJsonObject("components") {
                    // Forme courte (chaîne) acceptée par le format 1.21, identique au pipeline
                    // Fondation. L'ancien objet {"texture": …} date des formats 1.16–1.20.
                    put("minecraft:icon", textureKey("$ns:$id"))
                    putJsonObject("minecraft:display_name") {
                        put("value", if (i.description.isNotBlank()) "${i.name}\n${i.description}" else i.name)
                    }
                    put("minecraft:max_stack_size", if (equipment) 1 else i.maxStack.coerceIn(1, 64))
                    if (i.durability > 1) {
                        putJsonObject("minecraft:durability") { put("max_durability", i.durability) }
                    }
                    // Champs atelier enrichis (V1.8.37+) → composants Bedrock
                    if (i.glow) {
                        put("minecraft:foil", true)
                    }
                    if (i.enchantable || equipment) {
                        putJsonObject("minecraft:enchantable") {
                            put("value", if (isArmor) 9 else if (isWeapon) 14 else 10)
                            // Noms de slot Bedrock valides (avant : "armor.head", inexistant → erreur
                            // dans le journal de contenu et item potentiellement non chargé).
                            put("slot", when {
                                isArmor && slot == "slot.armor.head" -> "armor_head"
                                isArmor && slot == "slot.armor.chest" -> "armor_torso"
                                isArmor && slot == "slot.armor.legs" -> "armor_legs"
                                isArmor && slot == "slot.armor.feet" -> "armor_feet"
                                isShield -> "shield"
                                isWeapon -> "sword"
                                else -> "all"
                            })
                        }
                    }
                    // Un seul composant minecraft:tags : avant, les tags de l'utilisateur étaient
                    // écrasés par ceux d'armure / bouclier / arme (même clé JSON écrite deux fois).
                    val allTags = linkedSetOf<String>()
                    i.tags.forEach { tag ->
                        allTags += if (tag.startsWith("minecraft:") || tag.startsWith("sbh:")) tag else "sbh:$tag"
                    }
                    when {
                        isArmor && slot != null -> {
                            putJsonObject("minecraft:wearable") {
                                put("slot", slot)
                                put("protection", protection)
                            }
                            allTags += "minecraft:is_armor"
                        }
                        isShield -> {
                            put("minecraft:hand_equipped", true)
                            putJsonObject("minecraft:allow_off_hand") { put("value", true) }
                            // Style Blurry / Java PvP : maintien long pour parer (use_duration).
                            putJsonObject("minecraft:use_modifiers") {
                                put("use_duration", 999999)
                                put("movement_modifier", 0.8)
                            }
                            allTags += "minecraft:is_shield"
                            allTags += "sbh:shield"
                        }
                        isWeapon -> {
                            put("minecraft:hand_equipped", true)
                            if (i.damage > 0) put("minecraft:damage", i.damage)
                            putJsonObject("minecraft:allow_off_hand") { put("value", true) }
                            if ("sword" in lower) { allTags += "minecraft:is_sword"; allTags += "minecraft:is_tool" }
                            if ("axe" in lower && "pickaxe" !in lower) { allTags += "minecraft:is_axe"; allTags += "minecraft:is_tool" }
                        }
                        equipment -> {
                            put("minecraft:hand_equipped", true)
                            if (i.damage > 0) put("minecraft:damage", i.damage)
                        }
                    }
                    if (allTags.isNotEmpty()) {
                        putJsonObject("minecraft:tags") {
                            putJsonArray("tags") { allTags.forEach { add(it) } }
                        }
                    }
                }
            }
        }.toString()
    }

    private fun anyOf(value: String, vararg parts: String): Boolean = parts.any { it in value }

    /**
     * Bloc plein : material_instances relie enfin le bloc à sa texture (terrain_texture.json), et
     * menu_category le rend accessible dans l'inventaire créatif. Les anciens fichiers `les anciens fichiers JSON de blocs`
     * n'étaient pas un format valide côté ressources et ont été supprimés.
     */
    private fun blockJson(ns: String, id: String, destroyTime: Double, lightEmission: Int?): String = buildJsonObject {
        put("format_version", "1.21.0")
        putJsonObject("minecraft:block") {
            putJsonObject("description") {
                put("identifier", "$ns:$id")
                putJsonObject("menu_category") { put("category", "construction") }
            }
            putJsonObject("components") {
                // "minecraft:destroy_time" n'existe plus depuis le format 1.19.20 : avec
                // format_version 1.21.0, le composant était inconnu (erreur de contenu).
                putJsonObject("minecraft:destructible_by_mining") {
                    put("seconds_to_destroy", destroyTime.coerceAtLeast(0.0))
                }
                if (lightEmission != null) put("minecraft:light_emission", lightEmission)
                putJsonObject("minecraft:material_instances") {
                    putJsonObject("*") {
                        put("texture", textureKey("$ns:$id"))
                        put("render_method", "opaque")
                    }
                }
            }
        }
    }.toString()

    private fun splitId(value: String): Pair<String, String> = Identifiers.namespaceOf(value) to Identifiers.nameOf(value)
    private fun safe(s: String) = MobPackJson.safe(s)

    companion object {
        private const val MAX_TEXTURE = 1024

        /** Clé de texture unique dans l'atlas : `agw:sabre` → `agw_sabre` (même convention que la fondation). */
        fun textureKey(identifier: String): String = MobPackJson.textureKey(identifier)
    }
}
