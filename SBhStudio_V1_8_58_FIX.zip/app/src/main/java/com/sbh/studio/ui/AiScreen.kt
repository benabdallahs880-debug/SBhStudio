package com.sbh.studio.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.ai.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiScreen(back: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val manager = remember { AiPermissionManager(context) }
    val dispatcher = remember { AiActionDispatcher(context) }
    val client = remember { AiOpenAiClient() }
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(AiSettings()) }
    var history by remember { mutableStateOf(emptyList<AiAction>()) }
    var connected by remember { mutableStateOf(false) }
    var gatewayUrl by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val loaded = withContext(Dispatchers.IO) { manager.load() to dispatcher.history() }
        settings = loaded.first
        history = loaded.second
        connected = settings.enabled
        gatewayUrl = settings.gatewayUrl
        model = settings.model
    }
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var connectionState by remember { mutableStateOf("⚪ Passerelle non testée") }
    var busy by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<AiProjectReport?>(null) }
    var reportText by remember { mutableStateOf("") }
    var includeContext by remember { mutableStateOf(true) }
    var analyzing by remember { mutableStateOf(false) }
    var proposals by remember { mutableStateOf<List<AiProposal>>(emptyList()) }
    var pendingProposal by remember { mutableStateOf<AiProposal?>(null) }
    var pendingBatchCollision by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf("") }

    fun refresh() {
        settings = manager.load()
        history = dispatcher.history()
        connected = settings.enabled
        gatewayUrl = settings.gatewayUrl
        model = settings.model
    }

    fun saveConnection() {
        manager.save(
            settings.copy(
                provider = "OpenAI / passerelle",
                model = model.trim().ifBlank { "gpt-5-mini" },
                gatewayUrl = gatewayUrl.trim()
            )
        )
        refresh()
    }

    fun togglePermission(p: AiPermission) {
        val next = settings.permissions.toMutableSet().apply { if (!remove(p)) add(p) }
        manager.save(settings.copy(permissions = next))
        refresh()
    }

    fun runLocalAnalysis() {
        if (!settings.enabled) {
            connectionState = "🔴 Active d'abord le canal IA."
            return
        }
        if (AiPermission.ANALYZE !in settings.permissions && AiPermission.READ !in settings.permissions) {
            connectionState = "🔴 Permission READ ou ANALYZE requise."
            return
        }
        analyzing = true
        connectionState = "🟡 Analyse locale du projet…"
        scope.launch {
            val r = withContext(Dispatchers.IO) { AiProjectAnalyzer.analyze(context) }
            report = r
            reportText = r.toDisplayText()
            proposals = AiProposalEngine.proposalsFromReport(r, context)
            analyzing = false
            val perm = if (AiPermission.ANALYZE in settings.permissions) AiPermission.ANALYZE else AiPermission.READ
            dispatcher.dispatch(
                "ANALYZE_PROJECT",
                "Atelier",
                perm,
                "Analyse locale : ${r.errorCount} erreur(s), ${r.warnCount} avertissement(s), ${r.findings.size} signal(s)"
            )
            connectionState =
                "🟢 Analyse locale terminée — ${r.errorCount} erreur(s), ${r.warnCount} avertissement(s)"
            refresh()
        }
    }

    fun sendToOpenAI() {
        if (!settings.enabled || AiPermission.ANALYZE !in settings.permissions) {
            connectionState = "🔴 Action refusée : permission ANALYZE absente ou canal désactivé."
            return
        }
        saveConnection()
        if (gatewayUrl.isBlank()) {
            connectionState = "🟡 Configure d'abord la passerelle sécurisée."
            return
        }
        busy = true
        connectionState = "🟡 Communication avec la passerelle…"
        scope.launch(Dispatchers.IO) {
            val ctx = if (includeContext) {
                report?.toChatContext()
                    ?: AiProjectAnalyzer.analyze(context).also {
                        // keep last report for UI if user skipped local button
                        launch(Dispatchers.Main) {
                            report = it
                            reportText = it.toDisplayText()
                        }
                    }.toChatContext()
            } else null
            val fullPrompt = buildString {
                if (ctx != null) {
                    appendLine(ctx)
                    appendLine()
                    appendLine("---")
                    appendLine("Question utilisateur :")
                }
                append(prompt)
            }
            val session = settings.provider + ":" + gatewayUrl
            val result = client.send(gatewayUrl, model, fullPrompt, session)
            launch(Dispatchers.Main) {
                busy = false
                if (result.ok) {
                    answer = result.text
                    connectionState = if (includeContext)
                        "🟢 Réponse reçue (avec contexte projet)"
                    else
                        "🟢 OpenAI connecté via la passerelle"
                    dispatcher.dispatch("AI_CHAT", "OpenAI", AiPermission.ANALYZE)
                    refresh()
                } else connectionState = "🔴 ${result.detail}"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("🧠 SBh AI", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                        Text("INTELLIGENCE & CONTRÔLE", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                    }
                },
                navigationIcon = {
                    TextButton(onClick = back) {
                        Text("‹", fontSize = 32.sp, color = AgwColors.PaleMarble)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ForgeSectionCard(title = "Connexion IA") {
                    Text(
                        if (connected) "🟢 Canal IA activé" else "⚪ Canal IA désactivé",
                        color = if (connected) AgwColors.Success else AgwColors.Sand
                    )
                    Text("Fournisseur : ${settings.provider}", color = AgwColors.PaleMarble)
                    Text("Modèle : ${settings.model}", color = AgwColors.PaleMarble)
                    Text(connectionState, color = AgwColors.Sand)
                    Spacer(Modifier.height(8.dp))
                    GoldPrimaryButton(
                        text = if (connected) "Déconnecter l'IA" else "Activer le canal IA",
                        onClick = {
                            manager.save(settings.copy(enabled = !connected))
                            refresh()
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item {
                ForgeSectionCard(title = "📊 Analyse locale du projet") {
                    Text(
                        "Lit mobs, items, blocs, portails, maps, recettes et animations sur l'appareil. Aucune donnée n'est envoyée au cloud.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    GoldPrimaryButton(
                        text = if (analyzing) "Analyse en cours…" else "Analyser le projet",
                        onClick = { if (!analyzing) runLocalAnalysis() },
                        modifier = Modifier.fillMaxWidth()
                    )
                    report?.let { r ->
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "${r.projectName} · ${r.counts.entries.joinToString(" · ") { "${it.value} ${it.key}" }}",
                            color = AgwColors.PaleMarble,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "🔴 ${r.errorCount}  ·  🟡 ${r.warnCount}  ·  total ${r.findings.size} signal(s)",
                            color = AgwColors.DesertOchre,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (reportText.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(reportText, color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                ForgeSectionCard(title = "Connexion OpenAI") {
                    Text(
                        "Passerelle HTTPS : la clé API reste côté serveur, jamais dans l'APK.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = gatewayUrl,
                        onValueChange = { gatewayUrl = it },
                        label = { Text("URL de la passerelle HTTPS") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Modèle") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    GoldOutlineButton(
                        text = "Enregistrer la connexion",
                        onClick = {
                            saveConnection()
                            connectionState = "🟡 Configuration enregistrée"
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item {
                ForgeSectionCard(title = "Niveau d'accès") {
                    listOf(
                        AiAccessLevel.LOW to "🔵 Faible",
                        AiAccessLevel.MEDIUM to "🟡 Moyen",
                        AiAccessLevel.FULL to "🟢 Total"
                    ).forEach { (level, label) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = settings.accessLevel == level,
                                onClick = {
                                    manager.setAccessLevel(level)
                                    refresh()
                                }
                            )
                            Text(label, color = AgwColors.PaleMarble)
                        }
                    }
                    Text(
                        "Le niveau applique un jeu de permissions par défaut. Chaque permission peut ensuite être ajustée.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            item {
                ForgeSectionCard(title = "Permissions") {
                    AiPermission.entries.forEach { p ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = p in settings.permissions,
                                onCheckedChange = { togglePermission(p) }
                            )
                            Text(permissionLabel(p), color = AgwColors.PaleMarble, modifier = Modifier.weight(1f))
                            if (p == AiPermission.SENSITIVE_ACTIONS) Text("⚠", color = AgwColors.Warning)
                        }
                    }
                }
            }

            item {
                ForgeSectionCard(title = "💬 Communication avec OpenAI") {
                    Text(
                        "Option : joindre le résumé d'analyse locale pour que le modèle réponde sur ton projet réel.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = includeContext, onCheckedChange = { includeContext = it })
                        Text("Inclure le contexte projet", color = AgwColors.PaleMarble)
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        label = { Text("Message à l'IA") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    GoldPrimaryButton(
                        text = if (busy) "Envoi…" else "Envoyer",
                        onClick = { if (!busy) sendToOpenAI() },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (answer.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text("Réponse", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                        Text(answer, color = AgwColors.PaleMarble)
                    }
                }
            }

            item {
                ForgeSectionCard(title = "⚡ Actions proposées (phase 3)") {
                    Text(
                        "CREATE / MODIFY uniquement après confirmation. Rien n'est écrit sans ton accord.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    GoldOutlineButton(
                        text = "Générer des propositions depuis l'analyse",
                        onClick = {
                            val r = report ?: AiProjectAnalyzer.analyze(context).also {
                                report = it
                                reportText = it.toDisplayText()
                            }
                            proposals = AiProposalEngine.proposalsFromReport(r, context)
                            AiProposalEngine.proposalFromPrompt(prompt, context)?.let { extra ->
                                if (proposals.none { it.title == extra.title }) {
                                    proposals = listOf(extra) + proposals
                                }
                            }
                            actionMessage = "${proposals.size} proposition(s)"
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (actionMessage.isNotBlank()) {
                        Text(actionMessage, color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    }
                    val collisionProps = proposals.filter {
                        it.kind == AiProposalKind.FIX_MOB_COLLISION || it.kind == AiProposalKind.FIX_MOB_FORME
                    }
                    if (collisionProps.size >= 2) {
                        Spacer(Modifier.height(8.dp))
                        GoldPrimaryButton(
                            text = "Appliquer les ${collisionProps.size} corrections collision d'un coup",
                            onClick = { pendingBatchCollision = true },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    if (proposals.isEmpty()) {
                        Text(
                            "Lance une analyse ou écris « créer un mob … » puis génère les propositions.",
                            color = AgwColors.Sand,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        proposals.forEach { prop ->
                            Spacer(Modifier.height(8.dp))
                            Text(prop.title, color = AgwColors.SacredGold, fontWeight = FontWeight.SemiBold)
                            Text(prop.detail, color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
                            prop.previewLines.forEach { line ->
                                Text("· $line", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                            }
                            Text(
                                "Permission : ${permissionLabel(prop.permission)}",
                                color = AgwColors.Sand,
                                style = MaterialTheme.typography.labelSmall
                            )
                            Spacer(Modifier.height(4.dp))
                            GoldPrimaryButton(
                                text = "Appliquer (confirmation)…",
                                onClick = { pendingProposal = prop },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            item {
                ForgeSectionCard(title = "Test du SBh AI Bridge") {
                    Text(
                        "Les boutons ci-dessous enregistrent une entrée journal (permissions). L'analyse locale réelle est le bouton plus haut.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    GoldOutlineButton(
                        text = "Tester lecture",
                        onClick = {
                            dispatcher.dispatch("READ_PROJECT", "SBh Studio", AiPermission.READ)
                            refresh()
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    GoldOutlineButton(
                        text = "Tester modification",
                        onClick = {
                            dispatcher.dispatch("MODIFY_TEST", "Diagnostic", AiPermission.MODIFY)
                            refresh()
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    GoldOutlineButton(
                        text = "Tester suppression",
                        onClick = {
                            dispatcher.dispatch("DELETE_TEST", "Diagnostic", AiPermission.DELETE)
                            refresh()
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item {
                Text(
                    "Journal des actions IA",
                    color = AgwColors.SacredGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
            items(history.take(20)) { action ->
                ForgeSectionCard(title = if (action.allowed) "🟢 ${action.action}" else "🔴 ${action.action}") {
                    Text("Module : ${action.module}", color = AgwColors.PaleMarble)
                    Text("Permission : ${permissionLabel(action.permission)}", color = AgwColors.Sand)
                    Text(action.detail, color = AgwColors.Sand)
                    Text(
                        SimpleDateFormat("dd/MM HH:mm:ss", Locale.FRANCE).format(Date(action.timestampMs)),
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        if (pendingBatchCollision) {
            val batchList = proposals.filter {
                it.kind == AiProposalKind.FIX_MOB_COLLISION || it.kind == AiProposalKind.FIX_MOB_FORME
            }
            AlertDialog(
                onDismissRequest = { pendingBatchCollision = false },
                title = { Text("Corrections collision (${batchList.size})", color = AgwColors.SacredGold) },
                text = {
                    Column {
                        Text(
                            "Appliquer les dimensions standard de forme à tous ces mobs en une seule sauvegarde ?",
                            color = AgwColors.PaleMarble
                        )
                        Spacer(Modifier.height(8.dp))
                        batchList.take(15).forEach {
                            Text("· ${it.title}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        }
                        if (batchList.size > 15) {
                            Text("… +${batchList.size - 15} autres", color = AgwColors.Sand)
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val result = AiProposalEngine.applyAllCollisionFixes(context, proposals, manager)
                            actionMessage = result.message
                            if (result.ok) {
                                dispatcher.dispatch(
                                    "FIX_MOB_COLLISION_BATCH",
                                    "Atelier",
                                    AiPermission.MODIFY,
                                    result.message
                                )
                                proposals = proposals.filter {
                                    it.kind != AiProposalKind.FIX_MOB_COLLISION &&
                                        it.kind != AiProposalKind.FIX_MOB_FORME
                                }
                                val r = AiProjectAnalyzer.analyze(context)
                                report = r
                                reportText = r.toDisplayText()
                                refresh()
                            }
                            pendingBatchCollision = false
                        }
                    ) { Text("Tout confirmer", color = AgwColors.SacredGold) }
                },
                dismissButton = {
                    TextButton(onClick = { pendingBatchCollision = false }) {
                        Text("Annuler", color = AgwColors.Sand)
                    }
                },
                containerColor = AgwColors.NightGlass
            )
        }

        pendingProposal?.let { prop ->
            AlertDialog(
                onDismissRequest = { pendingProposal = null },
                title = { Text(prop.title, color = AgwColors.SacredGold) },
                text = {
                    Column {
                        Text(prop.detail, color = AgwColors.PaleMarble)
                        Spacer(Modifier.height(8.dp))
                        prop.previewLines.forEach {
                            Text("· $it", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Confirmer l'écriture dans le projet ?",
                            color = AgwColors.DesertOchre,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val result = AiProposalEngine.apply(context, prop, manager)
                            actionMessage = result.message
                            if (result.ok) {
                                dispatcher.dispatch(
                                    prop.kind.name,
                                    "Atelier",
                                    prop.permission,
                                    result.message
                                )
                                proposals = proposals.filter { it.id != prop.id }
                                // refresh analysis counts
                                val r = AiProjectAnalyzer.analyze(context)
                                report = r
                                reportText = r.toDisplayText()
                                refresh()
                            }
                            pendingProposal = null
                        }
                    ) { Text("Confirmer", color = AgwColors.SacredGold) }
                },
                dismissButton = {
                    TextButton(onClick = { pendingProposal = null }) {
                        Text("Annuler", color = AgwColors.Sand)
                    }
                },
                containerColor = AgwColors.NightGlass
            )
        }
    }
}

private fun permissionLabel(p: AiPermission): String = when (p) {
    AiPermission.READ -> "Lire"
    AiPermission.ANALYZE -> "Analyser"
    AiPermission.CREATE -> "Créer"
    AiPermission.MODIFY -> "Modifier"
    AiPermission.EXPORT -> "Exporter"
    AiPermission.IMPORT -> "Importer"
    AiPermission.EXECUTE -> "Exécuter"
    AiPermission.DELETE -> "Supprimer"
    AiPermission.CONFIGURE -> "Configurer"
    AiPermission.SENSITIVE_ACTIONS -> "Actions sensibles sans confirmation"
}
