package com.sbh.studio.data

import android.content.Context
import android.util.Log
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

@Serializable
data class SbhProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val version: String = "0.7.4",
    val status: String = "Brouillon",
    val versionHistory: List<String> = listOf("v1 — création du projet")
)

private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

class ProjectRepository(private val context: Context) {
    private val storageFile get() = File(context.filesDir, "sbh_projects.json")
    fun load(): List<SbhProject> = readSafely(storageFile) { json.decodeFromString(it) } ?: emptyList()
    fun save(projects: List<SbhProject>) = atomicWrite(storageFile, json.encodeToString(projects))
}

private fun <T> readSafely(file: File, decoder: (String) -> T): T? =
    SafeStore.readOrBackup(file, "ProjectRepository", decoder)

/** Écriture atomique verrouillée par fichier (voir [SafeStore]). */
internal fun atomicWrite(target: File, content: String) = SafeStore.write(target, content)
