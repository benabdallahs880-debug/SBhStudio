package com.sbh.studio.data

import android.content.Context

/**
 * Projet actif de l'application (V1.8.57).
 *
 * Avant : l'Atelier, Map Studio et l'IA travaillaient toujours sur le PREMIER projet de la
 * liste, quel que soit le projet ouvert à l'Accueil. Avec plusieurs projets, l'utilisateur
 * modifiait le mauvais projet sans le savoir.
 *
 * Maintenant : le dernier projet ouvert (Accueil → projet, ou sélecteur de l'Atelier) est
 * mémorisé ici et partagé par tous les écrans. S'il n'existe plus, on retombe sur le 1er.
 */
object ActiveProject {
    private const val PREFS = "sbh_active_project"
    private const val KEY = "project_id"

    fun storedId(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)

    fun set(context: Context, projectId: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, projectId)
            .apply()
    }

    /** Projet actif parmi [projects] : celui mémorisé s'il existe encore, sinon le premier. */
    fun resolve(context: Context, projects: List<SbhProject>): SbhProject? {
        val id = storedId(context)
        return projects.firstOrNull { it.id == id } ?: projects.firstOrNull()
    }

    /** Identifiant du projet actif, lu depuis le disque (pour les écrans hors MainActivity). */
    fun resolveId(context: Context): String? =
        resolve(context, ProjectRepository(context).load())?.id
}
