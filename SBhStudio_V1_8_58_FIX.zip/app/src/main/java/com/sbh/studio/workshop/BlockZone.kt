package com.sbh.studio.workshop

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle
import java.util.UUID

private val BLOCK_MATERIALS = listOf("dirt", "stone", "wood", "metal", "glass", "other")
private val BLOCK_TOOLS = listOf("any", "pickaxe", "axe", "shovel", "hoe", "none")

/**
 * Zone Blocs — atelier libre unifié.
 * Liste + recherche + édition / duplication / suppression.
 */
@Composable
internal fun BlockZone(
    projectId: String,
    blocks: List<SbhBlock>,
    textures: List<TextureProject> = emptyList(),
    onSave: (SbhBlock) -> Unit,
    onDelete: (SbhBlock) -> Unit,
    onAddReclamationPresets: (() -> Unit)? = null,
    onAddPracticeBlocks: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var filterMaterial by rememberSaveable { mutableStateOf("all") }
    var tab by rememberSaveable { mutableStateOf(0) }

    var name by rememberSaveable { mutableStateOf("Nouveau bloc") }
    var identifier by rememberSaveable { mutableStateOf("agw:nouveau_bloc") }
    var hardness by rememberSaveable { mutableStateOf("1.0") }
    var resistance by rememberSaveable { mutableStateOf("1.0") }
    var material by rememberSaveable { mutableStateOf("other") }
    var tool by rememberSaveable { mutableStateOf("any") }
    var description by rememberSaveable { mutableStateOf("") }
    var tagsText by rememberSaveable { mutableStateOf("") }
    var lightLevel by rememberSaveable { mutableStateOf("0") }
    var notes by rememberSaveable { mutableStateOf("") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            tex = u.toString()
        }
    }

    fun resetForm() {
        editingId = null
        name = "Nouveau bloc"
        identifier = "agw:nouveau_bloc"
        hardness = "1.0"
        resistance = "1.0"
        material = "other"
        tool = "any"
        description = ""
        tagsText = ""
        lightLevel = "0"
        notes = ""
        tex = null
        tab = 0
    }

    fun loadBlock(block: SbhBlock) {
        editingId = block.id
        name = block.name
        identifier = block.identifier
        hardness = block.hardness.toString()
        resistance = block.resistance.toString()
        material = block.material.ifBlank { "other" }
        tool = block.tool.ifBlank { "any" }
        description = block.description
        tagsText = block.tags.joinToString(", ")
        lightLevel = block.lightLevel.toString()
        notes = block.notes
        tex = block.textureUri
        tab = 0
    }

    fun buildBlock(keepId: String? = editingId): SbhBlock {
        val tags = tagsText.split(",", ";", " ")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
        return SbhBlock(
            id = keepId ?: UUID.randomUUID().toString(),
            projectId = projectId,
            name = name.trim().ifBlank { "Bloc" },
            identifier = identifier.trim().ifBlank { "agw:block" },
            hardness = com.sbh.studio.data.NumberInput.decimal(hardness)?.coerceAtLeast(0.0) ?: 1.0,
            textureUri = tex,
            resistance = com.sbh.studio.data.NumberInput.decimal(resistance)?.coerceAtLeast(0.0) ?: 1.0,
            material = material,
            tool = tool,
            description = description.trim(),
            tags = tags,
            lightLevel = lightLevel.toIntOrNull()?.coerceIn(0, 15) ?: 0,
            notes = notes.trim()
        )
    }

    val filtered = remember(blocks, search, filterMaterial) {
        blocks.filter { block ->
            val q = search.trim().lowercase()
            val matchQ = q.isEmpty() ||
                block.name.lowercase().contains(q) ||
                block.identifier.lowercase().contains(q) ||
                block.tags.any { it.lowercase().contains(q) }
            val matchMat = filterMaterial == "all" || block.material == filterMaterial
            matchQ && matchMat
        }
    }

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
    ) {
        SectionTitle("Blocs & architecture")
        Text(
            "${blocks.size} bloc(s) · atelier libre — créer, modifier, dupliquer",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        if (onAddPracticeBlocks != null) {
            GoldPrimaryButton("Practice — Blocs arène & farms", onClick = onAddPracticeBlocks, modifier = Modifier.fillMaxWidth())
        }
        if (onAddReclamationPresets != null) {
            GoldOutlineButton("Presets Reclamation", onClick = onAddReclamationPresets, modifier = Modifier.fillMaxWidth())
        }

        OutlinedTextField(
            search,
            { search = it },
            label = { Text("Rechercher (nom, id, tag)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = filterMaterial == "all", onClick = { filterMaterial = "all" }, label = { Text("Tous") })
            BLOCK_MATERIALS.take(5).forEach { mat ->
                FilterChip(
                    selected = filterMaterial == mat,
                    onClick = { filterMaterial = mat },
                    label = { Text(mat) }
                )
            }
        }

        Text("Liste (${filtered.size})", fontWeight = FontWeight.SemiBold, color = AgwColors.SacredGold)
        if (filtered.isEmpty()) {
            Text("Aucun bloc. Crée-en un ou importe un preset.", color = AgwColors.Sand)
        } else {
            filtered.forEach { block ->
                val selected = block.id == editingId
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) AgwColors.NightStone else AgwColors.DeepNight
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (selected) Modifier.border(2.dp, AgwColors.SacredGold, RoundedCornerShape(8.dp))
                            else Modifier
                        )
                        .clickable { loadBlock(block) }
                ) {
                    Row(
                        Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(block.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                            Text(
                                "${block.identifier} · ${block.material} · dureté ${block.hardness}" +
                                    if (block.lightLevel > 0) " · lumière ${block.lightLevel}" else "",
                                color = AgwColors.Sand,
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (block.tags.isNotEmpty()) {
                                Text(
                                    block.tags.joinToString(" · "),
                                    color = AgwColors.DesertOchre,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        TextButton(onClick = {
                            if (editingId == block.id) resetForm()
                            onDelete(block)
                        }) { Text("X") }
                    }
                }
            }
        }

        HorizontalDivider(color = AgwColors.Sand.copy(alpha = 0.3f))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (editingId == null) "Nouveau bloc" else "Modifier le bloc",
                    fontWeight = FontWeight.SemiBold,
                    color = AgwColors.SacredGold
                )

                TabRow(selectedTabIndex = tab, containerColor = AgwColors.DeepNight) {
                    listOf("Identité", "Physique", "Rendu", "Notes").forEachIndexed { i, label ->
                        Tab(
                            selected = tab == i,
                            onClick = { tab = i },
                            text = { Text(label, fontSize = 12.sp) }
                        )
                    }
                }

                when (tab) {
                    0 -> {
                        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text("Matériau", color = AgwColors.Sand, fontSize = 12.sp)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            BLOCK_MATERIALS.forEach { mat ->
                                FilterChip(
                                    selected = material == mat,
                                    onClick = { material = mat },
                                    label = { Text(mat, fontSize = 11.sp) }
                                )
                            }
                        }
                        OutlinedTextField(
                            description,
                            { description = it },
                            label = { Text("Description") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            tagsText,
                            { tagsText = it },
                            label = { Text("Tags (virgules)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    1 -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(hardness, { hardness = it }, label = { Text("Dureté") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(resistance, { resistance = it }, label = { Text("Résistance") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(lightLevel, { lightLevel = it }, label = { Text("Lumière 0-15") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Text("Outil recommandé", color = AgwColors.Sand, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            BLOCK_TOOLS.forEach { t ->
                                FilterChip(
                                    selected = tool == t,
                                    onClick = { tool = t },
                                    label = { Text(t, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    2 -> {
                        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
                            val currentTex = tex
                            Text(
                                when {
                                    currentTex == null -> "Fichier image externe"
                                    currentTex.startsWith("sbhtex://") -> "Texture Studio liée ✓"
                                    currentTex.startsWith("asset://") -> "Texture asset ✓"
                                    else -> "Fichier externe ✓"
                                }
                            )
                        }
                        StudioTexturePicker(
                            textures = textures,
                            selectedUri = tex,
                            onSelect = { tex = it },
                            preferredFormats = listOf("BLOCK_16", "BLOCK_32", "FILTER_MAP")
                        )
                        if (tex != null) {
                            TextButton(onClick = { tex = null }) { Text("Retirer la texture") }
                        }
                    }
                    3 -> {
                        OutlinedTextField(
                            notes,
                            { notes = it },
                            label = { Text("Notes libres (atelier)") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    GoldPrimaryButton(
                        if (editingId == null) "Créer le bloc" else "Enregistrer",
                        onClick = {
                            onSave(buildBlock())
                            if (editingId == null) resetForm()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    if (editingId != null) {
                        GoldOutlineButton(
                            "Dupliquer",
                            onClick = {
                                val copy = buildBlock(keepId = null).copy(
                                    name = "$name (copie)",
                                    identifier = workshopIdCopy(identifier.trim(), blocks.map { it.identifier }.toSet())
                                )
                                onSave(copy)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                if (editingId != null) {
                    TextButton(onClick = { resetForm() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Nouveau (quitter l'édition)")
                    }
                }
            }
        }
    }
}
