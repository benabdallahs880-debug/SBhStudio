package com.sbh.studio.animation

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject

/**
 * Génère les JSON Bedrock (animations + controller) pour le Resource Pack.
 * V2 : 7 états, 12 âmes, keyframes enrichies inspirées des comportements FreshAnimations.
 */
object AnimationExport {

    /**
     * V1.8.58 :
     *  1. La durée (animation_length) dépend de la vitesse, et les images clés sont maintenant
     *     remises à l'échelle de cette durée. Avant, la durée changeait mais les images clés
     *     restaient fixes → boucles coupées avant la fin (à-coups) ou poses figées.
     *  2. [formeBase] : les pattes des formes vanilla non bipèdes (vache, loup, creeper : leg0–3 ;
     *     poule : leg0–1 ; araignée : leg0–7) reçoivent le mouvement des jambes. Avant, seules
     *     « rightleg/leftleg » étaient animées → pattes figées sur les quadrupèdes.
     * Fonction pure, testée dans AnimationExportTest.
     */
    fun animationJson(project: AnimationProject, identifier: String, formeBase: String = "humanoid"): String {
        val animId = identifier.replace(":", ".")
        val animations = buildJsonObject {
            AnimState.entries.forEach { state ->
                val p = project.states[state.name] ?: AnimStateParams()
                val raw = Json.parseToJsonElement(boneMotion(project, state)).jsonObject
                val maxT = maxKeyTime(raw).takeIf { it > 0f } ?: 1f
                val length = AnimationMotion.animLength(maxT, p.speed)
                val bones = adaptBonesToForme(rescaleTimes(raw, length / maxT), formeBase)
                putJsonObject("animation.$animId.${state.bedKey}") {
                    put("loop", p.loop)
                    put("animation_length", round3(length))
                    put("bones", bones)
                }
            }
        }
        return buildJsonObject {
            put("format_version", "1.8.0")
            put("animations", animations)
        }.toString()
    }

    // ——— Outils de transformation (purs) ———

    private fun round3(v: Float): Double = kotlin.math.round(v * 1000.0) / 1000.0

    private fun timeKey(v: Float): String {
        val r = round3(v)
        val s = String.format(java.util.Locale.ROOT, "%.3f", r).trimEnd('0')
        return if (s.endsWith(".")) s + "0" else s
    }

    /** Plus grand instant d'image clé trouvé dans les os. */
    internal fun maxKeyTime(bones: JsonObject): Float {
        var max = 0f
        bones.values.forEach { bone ->
            (bone as? JsonObject)?.values?.forEach { channel ->
                (channel as? JsonObject)?.keys?.forEach { k -> k.toFloatOrNull()?.let { if (it > max) max = it } }
            }
        }
        return max
    }

    /** Multiplie tous les instants d'images clés par [factor]. */
    internal fun rescaleTimes(bones: JsonObject, factor: Float): JsonObject = buildJsonObject {
        bones.forEach { (boneName, bone) ->
            val b = bone as? JsonObject
            if (b == null) { put(boneName, bone); return@forEach }
            putJsonObject(boneName) {
                b.forEach { (channelName, channel) ->
                    val c = channel as? JsonObject
                    if (c == null) put(channelName, channel)
                    else putJsonObject(channelName) {
                        c.forEach { (t, value) ->
                            val f = t.toFloatOrNull()
                            put(if (f == null) t else timeKey(f * factor), value)
                        }
                    }
                }
            }
        }
    }

    /** Recopie le mouvement des jambes sur les os réels des géométries vanilla non bipèdes. */
    internal fun adaptBonesToForme(bones: JsonObject, formeBase: String): JsonObject {
        val right = bones["rightleg"] ?: return bones
        val left = bones["leftleg"] ?: right
        val mapping: Map<String, JsonElement> = when (formeBase.lowercase()) {
            // Allure diagonale vanilla : leg0 & leg3 ensemble, leg1 & leg2 en opposition.
            "cow", "wolf", "creeper" -> mapOf("leg0" to right, "leg1" to left, "leg2" to left, "leg3" to right)
            "chicken" -> mapOf("leg0" to right, "leg1" to left)
            // Pattes d'araignée horizontales : le balancement se fait autour de l'axe vertical.
            "spider" -> {
                val r = swingToYaw(right); val l = swingToYaw(left)
                (0..7).associate { i -> "leg$i" to (if (i % 2 == 0) r else l) }
            }
            else -> emptyMap()
        }
        if (mapping.isEmpty()) return bones
        return buildJsonObject {
            bones.forEach { (k, v) -> put(k, v) }
            mapping.forEach { (k, v) -> if (!bones.containsKey(k)) put(k, v) }
        }
    }

    /** [x, y, z] → [0, x/2, 0] pour chaque image clé de rotation. */
    private fun swingToYaw(bone: JsonElement): JsonElement {
        val b = bone as? JsonObject ?: return bone
        val rot = b["rotation"] as? JsonObject ?: return bone
        return buildJsonObject {
            putJsonObject("rotation") {
                rot.forEach { (t, v) ->
                    val arr = v as? JsonArray
                    val x = arr?.getOrNull(0)?.jsonPrimitive?.doubleOrNull ?: 0.0
                    put(t, buildJsonArray { add(0); add(x / 2.0); add(0) })
                }
            }
        }
    }

    fun controllerJson(identifier: String): String {
        val animId = identifier.replace(":", ".")
        return """
{
  "format_version": "1.10.0",
  "animation_controllers": {
    "controller.animation.$animId.main": {
      "initial_state": "idle",
      "states": {
        "idle": {
          "animations": ["idle"],
          "transitions": [
            { "swim": "query.is_swimming || query.is_in_water" },
            { "sit": "query.is_sitting" },
            { "run": "query.modified_move_speed > 0.55" },
            { "walk": "query.modified_move_speed > 0.1" },
            { "attack": "query.is_delayed_attacking || query.is_angry" },
            { "hurt": "query.is_hurt" }
          ]
        },
        "walk": {
          "animations": ["walk"],
          "transitions": [
            { "idle": "query.modified_move_speed <= 0.1" },
            { "run": "query.modified_move_speed > 0.55" },
            { "swim": "query.is_swimming || query.is_in_water" },
            { "attack": "query.is_delayed_attacking || query.is_angry" },
            { "hurt": "query.is_hurt" }
          ]
        },
        "run": {
          "animations": ["run"],
          "transitions": [
            { "walk": "query.modified_move_speed <= 0.55 && query.modified_move_speed > 0.1" },
            { "idle": "query.modified_move_speed <= 0.1" },
            { "attack": "query.is_delayed_attacking || query.is_angry" },
            { "hurt": "query.is_hurt" }
          ]
        },
        "attack": {
          "animations": ["attack"],
          "transitions": [
            { "hurt": "query.is_hurt" },
            { "idle": "!query.is_delayed_attacking && !query.is_angry" }
          ]
        },
        "hurt": {
          "animations": ["hurt"],
          "transitions": [
            { "idle": "!query.is_hurt" }
          ]
        },
        "sit": {
          "animations": ["sit"],
          "transitions": [
            { "idle": "!query.is_sitting" },
            { "hurt": "query.is_hurt" }
          ]
        },
        "swim": {
          "animations": ["swim"],
          "transitions": [
            { "idle": "!query.is_swimming && !query.is_in_water" },
            { "hurt": "query.is_hurt" }
          ]
        }
      }
    }
  }
}
""".trimIndent()
    }

    private fun boneMotion(project: AnimationProject, state: AnimState): String {
        val p = project.states[state.name] ?: AnimStateParams()
        val amp = p.amplitude.coerceIn(0.25f, 2f)
        val weight = p.weight.coerceIn(0.4f, 1.6f)
        val soul = runCatching { AnimSoul.valueOf(project.soul) }.getOrDefault(AnimSoul.GUARDIAN)
        // Même facteur d'âme que l'aperçu (AnimationMotion)
        val a = amp * AnimationMotion.soulMul(soul)
        val w = weight

        return when (state) {
            AnimState.IDLE -> idleBones(a, w, soul)
            AnimState.WALK -> walkBones(a, w, soul)
            AnimState.RUN -> runBones(a, w, soul)
            AnimState.ATTACK -> attackBones(a, w, soul)
            AnimState.HURT -> hurtBones(a, w, soul)
            AnimState.SIT -> sitBones(a, w, soul)
            AnimState.SWIM -> swimBones(a, w, soul)
        }
    }

    // ——— IDLE ———
    private fun idleBones(a: Float, w: Float, soul: AnimSoul): String = when (soul) {
        AnimSoul.UNDEAD -> """{
          "body": { "rotation": { "0.0": [0, 0, 0], "1.0": [${2 * a}, 0, 0], "2.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "1.0": [${4 * a}, ${3 * a}, 0], "2.0": [0, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [${-80 * a}, 0, 0], "2.0": [${-80 * a}, 0, 0] } },
          "leftarm": { "rotation": { "0.0": [${-80 * a}, 0, 0], "2.0": [${-80 * a}, 0, 0] } }
        }"""
        AnimSoul.FLYER, AnimSoul.MYSTIC -> """{
          "body": { "position": { "0.0": [0, 0, 0], "1.0": [0, ${0.08 * a}, 0], "2.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "1.0": [${2 * a}, ${6 * a}, 0], "2.0": [0, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [0, 0, ${8 * a}], "1.0": [0, 0, ${-4 * a}], "2.0": [0, 0, ${8 * a}] } },
          "leftarm": { "rotation": { "0.0": [0, 0, ${-8 * a}], "1.0": [0, 0, ${4 * a}], "2.0": [0, 0, ${-8 * a}] } }
        }"""
        AnimSoul.WOLF, AnimSoul.AGILE -> """{
          "body": { "position": { "0.0": [0, 0, 0], "1.0": [0, ${0.03 * a}, 0], "2.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.5": [${3 * a}, ${8 * a}, 0], "1.5": [${2 * a}, ${-6 * a}, 0], "2.0": [0, 0, 0] } }
        }"""
        else -> """{
          "body": { "position": { "0.0": [0, 0, 0], "1.0": [0, ${0.04 * a * w}, 0], "2.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "1.0": [${3 * a}, ${5 * a}, 0], "2.0": [0, 0, 0] } }
        }"""
    }

    // ——— WALK ———
    private fun walkBones(a: Float, w: Float, soul: AnimSoul): String = when (soul) {
        AnimSoul.UNDEAD -> """{
          "body": { "rotation": { "0.0": [0, 0, 0], "0.5": [${3 * a}, 0, ${2 * a}], "1.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.5": [${5 * a}, 0, 0], "1.0": [0, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [${-75 * a}, 0, 0], "0.5": [${-90 * a}, 0, 0], "1.0": [${-75 * a}, 0, 0] } },
          "leftarm": { "rotation": { "0.0": [${-75 * a}, 0, 0], "0.5": [${-90 * a}, 0, 0], "1.0": [${-75 * a}, 0, 0] } },
          "rightleg": { "rotation": { "0.0": [${15 * a}, 0, 0], "0.5": [${-15 * a}, 0, 0], "1.0": [${15 * a}, 0, 0] } },
          "leftleg": { "rotation": { "0.0": [${-15 * a}, 0, 0], "0.5": [${15 * a}, 0, 0], "1.0": [${-15 * a}, 0, 0] } }
        }"""
        AnimSoul.HEAVY_QUAD, AnimSoul.BEAST -> """{
          "body": { "rotation": { "0.0": [0, 0, ${3 * a * w}], "0.5": [0, 0, ${-3 * a * w}], "1.0": [0, 0, ${3 * a * w}] },
                     "position": { "0.0": [0, 0, 0], "0.25": [0, ${-0.03 * a * w}, 0], "0.75": [0, ${-0.03 * a * w}, 0], "1.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.5": [${2 * a}, 0, 0], "1.0": [0, 0, 0] } },
          "rightleg": { "rotation": { "0.0": [${25 * a}, 0, 0], "0.5": [${-25 * a}, 0, 0], "1.0": [${25 * a}, 0, 0] } },
          "leftleg": { "rotation": { "0.0": [${-25 * a}, 0, 0], "0.5": [${25 * a}, 0, 0], "1.0": [${-25 * a}, 0, 0] } }
        }"""
        AnimSoul.ARACHNID -> """{
          "body": { "rotation": { "0.0": [0, 0, ${6 * a}], "0.5": [0, 0, ${-6 * a}], "1.0": [0, 0, ${6 * a}] },
                     "position": { "0.0": [0, ${-0.02 * a}, 0], "0.5": [0, ${0.02 * a}, 0], "1.0": [0, ${-0.02 * a}, 0] } },
          "head": { "rotation": { "0.0": [0, ${4 * a}, 0], "0.5": [0, ${-4 * a}, 0], "1.0": [0, ${4 * a}, 0] } }
        }"""
        else -> """{
          "body": { "rotation": { "0.0": [0, 0, ${4 * a}], "0.5": [0, 0, ${-4 * a}], "1.0": [0, 0, ${4 * a}] },
                     "position": { "0.0": [0, 0, 0], "0.25": [0, ${-0.02 * a * w}, 0], "0.75": [0, ${-0.02 * a * w}, 0], "1.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.5": [${2 * a}, 0, 0], "1.0": [0, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [${20 * a}, 0, 0], "0.5": [${-20 * a}, 0, 0], "1.0": [${20 * a}, 0, 0] } },
          "leftarm": { "rotation": { "0.0": [${-20 * a}, 0, 0], "0.5": [${20 * a}, 0, 0], "1.0": [${-20 * a}, 0, 0] } },
          "rightleg": { "rotation": { "0.0": [${-25 * a}, 0, 0], "0.5": [${25 * a}, 0, 0], "1.0": [${-25 * a}, 0, 0] } },
          "leftleg": { "rotation": { "0.0": [${25 * a}, 0, 0], "0.5": [${-25 * a}, 0, 0], "1.0": [${25 * a}, 0, 0] } }
        }"""
    }

    // ——— RUN ———
    private fun runBones(a: Float, w: Float, soul: AnimSoul): String = when (soul) {
        AnimSoul.WOLF, AnimSoul.AGILE, AnimSoul.ASSASSIN -> """{
          "body": { "rotation": { "0.0": [${5 * a}, 0, ${5 * a}], "0.5": [${5 * a}, 0, ${-5 * a}], "1.0": [${5 * a}, 0, ${5 * a}] },
                     "position": { "0.0": [0, 0, 0], "0.25": [0, ${-0.05 * a}, 0], "0.75": [0, ${-0.05 * a}, 0], "1.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [${8 * a}, 0, 0], "1.0": [${8 * a}, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [${35 * a}, 0, 0], "0.5": [${-35 * a}, 0, 0], "1.0": [${35 * a}, 0, 0] } },
          "leftarm": { "rotation": { "0.0": [${-35 * a}, 0, 0], "0.5": [${35 * a}, 0, 0], "1.0": [${-35 * a}, 0, 0] } },
          "rightleg": { "rotation": { "0.0": [${-40 * a}, 0, 0], "0.5": [${40 * a}, 0, 0], "1.0": [${-40 * a}, 0, 0] } },
          "leftleg": { "rotation": { "0.0": [${40 * a}, 0, 0], "0.5": [${-40 * a}, 0, 0], "1.0": [${40 * a}, 0, 0] } }
        }"""
        else -> """{
          "body": { "rotation": { "0.0": [0, 0, ${6 * a}], "0.5": [0, 0, ${-6 * a}], "1.0": [0, 0, ${6 * a}] },
                     "position": { "0.0": [0, 0, 0], "0.25": [0, ${-0.04 * a * w}, 0], "0.75": [0, ${-0.04 * a * w}, 0], "1.0": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [${4 * a}, 0, 0], "1.0": [${4 * a}, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [${30 * a}, 0, 0], "0.5": [${-30 * a}, 0, 0], "1.0": [${30 * a}, 0, 0] } },
          "leftarm": { "rotation": { "0.0": [${-30 * a}, 0, 0], "0.5": [${30 * a}, 0, 0], "1.0": [${-30 * a}, 0, 0] } },
          "rightleg": { "rotation": { "0.0": [${-35 * a}, 0, 0], "0.5": [${35 * a}, 0, 0], "1.0": [${-35 * a}, 0, 0] } },
          "leftleg": { "rotation": { "0.0": [${35 * a}, 0, 0], "0.5": [${-35 * a}, 0, 0], "1.0": [${35 * a}, 0, 0] } }
        }"""
    }

    // ——— ATTACK ———
    private fun attackBones(a: Float, w: Float, soul: AnimSoul): String = when (soul) {
        AnimSoul.UNDEAD -> """{
          "body": { "rotation": { "0.0": [0, 0, 0], "0.3": [${8 * a}, ${5 * a}, 0], "0.6": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.3": [${12 * a}, 0, 0], "0.6": [0, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [${-80 * a}, 0, 0], "0.25": [${-120 * a}, ${-20 * a}, 0], "0.5": [${-60 * a}, 0, 0], "0.6": [${-80 * a}, 0, 0] } },
          "leftarm": { "rotation": { "0.0": [${-80 * a}, 0, 0], "0.25": [${-110 * a}, ${20 * a}, 0], "0.5": [${-60 * a}, 0, 0], "0.6": [${-80 * a}, 0, 0] } }
        }"""
        AnimSoul.WOLF, AnimSoul.ARACHNID, AnimSoul.BEAST -> """{
          "body": { "rotation": { "0.0": [0, 0, 0], "0.15": [${-10 * a}, 0, 0], "0.35": [${15 * a}, ${8 * a}, 0], "0.6": [0, 0, 0] },
                     "position": { "0.0": [0, 0, 0], "0.2": [0, ${0.05 * a}, ${-0.08 * a}], "0.4": [0, ${-0.02 * a}, ${0.1 * a}], "0.6": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.3": [${15 * a}, 0, 0], "0.6": [0, 0, 0] } }
        }"""
        AnimSoul.ASSASSIN, AnimSoul.AGILE -> """{
          "body": { "rotation": { "0.0": [0, 0, 0], "0.15": [0, ${15 * a}, 0], "0.35": [${8 * a}, ${-10 * a}, 0], "0.6": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.2": [0, ${10 * a}, 0], "0.5": [0, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [0, 0, 0], "0.2": [${-90 * a}, 0, ${-40 * a}], "0.4": [${-40 * a}, 0, 0], "0.6": [0, 0, 0] } }
        }"""
        else -> """{
          "body": { "rotation": { "0.0": [0, 0, 0], "0.2": [${5 * a}, ${10 * a}, 0], "0.4": [${-5 * a}, ${-5 * a}, 0], "0.6": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.3": [${10 * a}, 0, 0], "0.6": [0, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [0, 0, 0], "0.25": [${-100 * a}, 0, ${-20 * a}], "0.5": [0, 0, 0] } }
        }"""
    }

    // ——— HURT ———
    private fun hurtBones(a: Float, w: Float, soul: AnimSoul): String = """{
          "body": { "rotation": { "0.0": [0, 0, 0], "0.1": [${-8 * a * w}, 0, ${4 * a}], "0.4": [0, 0, 0] },
                     "position": { "0.0": [0, 0, 0], "0.1": [0, ${-0.03 * a}, ${0.04 * a}], "0.4": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.1": [${-12 * a}, 0, 0], "0.4": [0, 0, 0] } }
        }"""

    // ——— SIT ———
    private fun sitBones(a: Float, w: Float, soul: AnimSoul): String = when (soul) {
        AnimSoul.WOLF, AnimSoul.AGILE -> """{
          "body": { "rotation": { "0.0": [${-25 * a}, 0, 0], "1.5": [${-25 * a}, 0, 0] },
                     "position": { "0.0": [0, ${-0.15 * a * w}, 0], "1.5": [0, ${-0.15 * a * w}, 0] } },
          "head": { "rotation": { "0.0": [${10 * a}, 0, 0], "0.75": [${8 * a}, ${5 * a}, 0], "1.5": [${10 * a}, 0, 0] } },
          "rightleg": { "rotation": { "0.0": [${-70 * a}, 0, ${15 * a}], "1.5": [${-70 * a}, 0, ${15 * a}] } },
          "leftleg": { "rotation": { "0.0": [${-70 * a}, 0, ${-15 * a}], "1.5": [${-70 * a}, 0, ${-15 * a}] } }
        }"""
        else -> """{
          "body": { "rotation": { "0.0": [${-15 * a}, 0, 0], "1.5": [${-15 * a}, 0, 0] },
                     "position": { "0.0": [0, ${-0.1 * a * w}, 0], "1.5": [0, ${-0.1 * a * w}, 0] } },
          "head": { "rotation": { "0.0": [0, 0, 0], "0.75": [${3 * a}, ${4 * a}, 0], "1.5": [0, 0, 0] } }
        }"""
    }

    // ——— SWIM ———
    private fun swimBones(a: Float, w: Float, soul: AnimSoul): String = """{
          "body": { "rotation": { "0.0": [${10 * a}, 0, ${3 * a}], "0.6": [${10 * a}, 0, ${-3 * a}], "1.2": [${10 * a}, 0, ${3 * a}] },
                     "position": { "0.0": [0, 0, 0], "0.6": [0, ${0.04 * a}, 0], "1.2": [0, 0, 0] } },
          "head": { "rotation": { "0.0": [${-5 * a}, 0, 0], "1.2": [${-5 * a}, 0, 0] } },
          "rightarm": { "rotation": { "0.0": [${-20 * a}, 0, ${40 * a}], "0.6": [${-20 * a}, 0, ${-20 * a}], "1.2": [${-20 * a}, 0, ${40 * a}] } },
          "leftarm": { "rotation": { "0.0": [${-20 * a}, 0, ${-40 * a}], "0.6": [${-20 * a}, 0, ${20 * a}], "1.2": [${-20 * a}, 0, ${-40 * a}] } },
          "rightleg": { "rotation": { "0.0": [${30 * a}, 0, 0], "0.6": [${-20 * a}, 0, 0], "1.2": [${30 * a}, 0, 0] } },
          "leftleg": { "rotation": { "0.0": [${-20 * a}, 0, 0], "0.6": [${30 * a}, 0, 0], "1.2": [${-20 * a}, 0, 0] } }
        }"""
}
