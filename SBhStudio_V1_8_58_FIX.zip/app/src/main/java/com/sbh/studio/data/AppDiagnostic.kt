package com.sbh.studio.data

import android.content.Context
import android.util.Log
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import com.sbh.studio.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** État d'un point de diagnostic */
enum class DiagStatus { OK, WARN, FAIL, UNKNOWN }

data class DiagItem(
    val id: String,
    val title: String,
    val category: String, // "connexion" | "module" | "données" | "système"
    val status: DiagStatus,
    val detail: String
)

data class AppIdentity(
    val packageName: String,
    val versionName: String,
    val versionCode: Int,
    val assetVersionName: String?,
    val assetVersionCode: Int?,
    val buildType: String,
    val sdkInt: Int,
    val deviceModel: String,
    val installSource: String
)

data class DiagnosticReport(
    val identity: AppIdentity,
    val items: List<DiagItem>,
    val okCount: Int,
    val warnCount: Int,
    val failCount: Int,
    val generatedAtMs: Long = System.currentTimeMillis()
)

/**
 * Diagnostic complet SBh Studio :
 * - identité / version
 * - connexions (réseau, GitHub Releases)
 * - modules (Map Studio, Atelier, assets AGW, branding…)
 * - données locales (projets, stockage)
 */
class AppDiagnostic(private val context: Context) {

    private val updateManager = UpdateManager(context)

    fun identity(): AppIdentity {
        val pm = context.packageManager
        val pkg = context.packageName
        val pi = try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION") pm.getPackageInfo(pkg, 0)
            }
        } catch (e: Exception) {
            Log.w("AppDiagnostic", "Échec diagnostic", e)
            null
        }
        val asset = updateManager.localVersionFromAssets()
        val installSource = try {
            if (Build.VERSION.SDK_INT >= 30) {
                pm.getInstallSourceInfo(pkg).installingPackageName ?: "inconnu"
            } else {
                @Suppress("DEPRECATION") pm.getInstallerPackageName(pkg) ?: "inconnu"
            }
        } catch (e: Exception) {
            Log.w("AppDiagnostic", "Échec diagnostic", e)
            "inconnu"
        }
        val code = if (Build.VERSION.SDK_INT >= 28) {
            pi?.longVersionCode?.toInt() ?: BuildConfig.VERSION_CODE
        } else {
            @Suppress("DEPRECATION") pi?.versionCode ?: BuildConfig.VERSION_CODE
        }
        return AppIdentity(
            packageName = pkg,
            versionName = pi?.versionName ?: BuildConfig.VERSION_NAME,
            versionCode = code,
            assetVersionName = asset?.versionName,
            assetVersionCode = asset?.versionCode,
            buildType = BuildConfig.BUILD_TYPE,
            sdkInt = Build.VERSION.SDK_INT,
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
            installSource = installSource
        )
    }

    /** Diagnostic local rapide (sans réseau). */
    fun runLocal(): DiagnosticReport {
        val id = identity()
        val items = mutableListOf<DiagItem>()
        items += systemItems(id)
        items += localConnectivityItems()
        items += moduleItems()
        items += dataItems()
        return summarize(id, items)
    }

    /** Diagnostic complet (local + ping GitHub). */
    suspend fun runFull(): DiagnosticReport = withContext(Dispatchers.IO) {
        val id = identity()
        val items = mutableListOf<DiagItem>()
        items += systemItems(id)
        items += localConnectivityItems()
        items += remoteConnectivityItems()
        items += moduleItems()
        items += dataItems()
        summarize(id, items)
    }

    private fun summarize(id: AppIdentity, items: List<DiagItem>): DiagnosticReport {
        val ok = items.count { it.status == DiagStatus.OK }
        val warn = items.count { it.status == DiagStatus.WARN }
        val fail = items.count { it.status == DiagStatus.FAIL }
        return DiagnosticReport(id, items, ok, warn, fail)
    }

    private fun systemItems(id: AppIdentity): List<DiagItem> {
        val list = mutableListOf<DiagItem>()
        // Cohérence version APK vs assets
        val assetCode = id.assetVersionCode
        when {
            assetCode == null -> list += DiagItem(
                "version_assets", "version.json (assets)", "système", DiagStatus.FAIL,
                "Fichier assets/version.json manquant ou illisible."
            )
            assetCode != id.versionCode -> list += DiagItem(
                "version_assets", "version.json (assets)", "système", DiagStatus.WARN,
                "Code assets=$assetCode ≠ code APK=${id.versionCode}. Désalignement possible."
            )
            else -> list += DiagItem(
                "version_assets", "version.json (assets)", "système", DiagStatus.OK,
                "v${id.assetVersionName} · code $assetCode — aligné avec l'APK."
            )
        }
        list += DiagItem(
            "package", "Identité application", "système", DiagStatus.OK,
            "${id.packageName} · build ${id.buildType} · SDK ${id.sdkInt}"
        )
        list += DiagItem(
            "device", "Appareil", "système", DiagStatus.OK,
            id.deviceModel
        )
        // Install packages permission (Android 8+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val can = context.packageManager.canRequestPackageInstalls()
            list += DiagItem(
                "install_perm", "Installation APK inconnus", "système",
                if (can) DiagStatus.OK else DiagStatus.WARN,
                if (can) "Autorisé — les mises à jour peuvent s'installer."
                else "Non autorisé — activez « Installer des apps inconnues » pour SBh Studio."
            )
        }
        return list
    }

    private fun localConnectivityItems(): List<DiagItem> {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val network = cm?.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val hasNet = caps != null && (
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            )
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        val transport = when {
            caps == null -> "aucun"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Données mobiles"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "autre"
        }
        return listOf(
            DiagItem(
                "network", "Réseau local", "connexion",
                when {
                    !hasNet -> DiagStatus.FAIL
                    !validated -> DiagStatus.WARN
                    else -> DiagStatus.OK
                },
                when {
                    !hasNet -> "Non connecté — aucune interface active."
                    !validated -> "Connecté ($transport) mais Internet non validé."
                    else -> "Connecté · $transport · Internet OK"
                }
            )
        )
    }

    private fun remoteConnectivityItems(): List<DiagItem> {
        val list = mutableListOf<DiagItem>()
        // GitHub API releases
        try {
            val url = URL("https://api.github.com/repos/benabdallahs880-debug/SBhStudio/releases/latest")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.requestMethod = "GET"
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            val code = conn.responseCode
            when (code) {
                200 -> list += DiagItem(
                    "github_api", "Serveur mises à jour (GitHub)", "connexion", DiagStatus.OK,
                    "API Releases accessible (HTTP 200)."
                )
                404 -> list += DiagItem(
                    "github_api", "Serveur mises à jour (GitHub)", "connexion", DiagStatus.WARN,
                    "Repo accessible mais aucune release publique (HTTP 404)."
                )
                else -> list += DiagItem(
                    "github_api", "Serveur mises à jour (GitHub)", "connexion", DiagStatus.FAIL,
                    "Réponse HTTP $code — serveur injoignable ou limité."
                )
            }
            conn.disconnect()
        } catch (e: Exception) {
            Log.w("AppDiagnostic", "Échec diagnostic", e)
            list += DiagItem(
                "github_api", "Serveur mises à jour (GitHub)", "connexion", DiagStatus.FAIL,
                "Non connecté : ${e.message ?: "erreur réseau"}"
            )
        }
        return list
    }

    private fun moduleItems(): List<DiagItem> {
        val list = mutableListOf<DiagItem>()

        // Map Studio
        list += checkAssetModule(
            id = "map_studio",
            title = "Map Studio",
            required = listOf(
                "mapstudio.html",
                "js/three.module.js",
                "js/OrbitControls.js"
            )
        )
        val mapReadyFile = File(context.filesDir, "map_studio_last_ready.txt")
        val readyAt = mapReadyFile.takeIf { it.exists() }?.readText()?.trim()?.toLongOrNull()
        val age = readyAt?.let { System.currentTimeMillis() - it }
        list += DiagItem(
            "map_runtime", "Map Studio runtime", "module",
            when {
                readyAt == null -> DiagStatus.UNKNOWN
                age != null && age < 24L * 60L * 60L * 1000L -> DiagStatus.OK
                else -> DiagStatus.WARN
            },
            when {
                readyAt == null -> "Map Studio n'a pas encore confirmé un chargement complet sur cet appareil."
                age != null && age < 24L * 60L * 60L * 1000L -> "Dernier chargement complet confirmé récemment."
                else -> "Dernier chargement complet ancien : testez Map Studio avant un export."
            }
        )

        // Atelier — dépend du code + stockage fichiers
        val filesOk = try {
            context.filesDir.canWrite() && context.filesDir.exists()
        } catch (e: Exception) {
            Log.w("AppDiagnostic", "Échec diagnostic", e)
            false
        }
        list += DiagItem(
            "workshop", "Atelier (Workshop)", "module",
            if (filesOk) DiagStatus.OK else DiagStatus.FAIL,
            if (filesOk) "Stockage interne accessible — zones Mobs/Portails/Maps/Export prêtes."
            else "Stockage interne inaccessible — l'atelier ne peut pas sauvegarder."
        )

        // Branding / décor
        list += checkAssetModule(
            id = "branding",
            title = "Branding & décor",
            required = listOf(
                "branding/bg_raven_owl.png",
                "branding/logo_owl_geometric.png",
                "branding/icons/icon_workshop.png",
                "branding/icons/icon_map.png"
            )
        )

        // Monde AGW (JSON)
        list += checkAssetModule(
            id = "agw_data",
            title = "Monde AGW (données)",
            required = listOf(
                "agw/project.json",
                "agw/lore.json",
                "agw/heroes.json",
                "agw/factions.json",
                "agw/phases.json"
            )
        )

        // FileProvider paths
        val fp = try {
            context.resources.getIdentifier("file_paths", "xml", context.packageName) != 0
        } catch (e: Exception) {
            Log.w("AppDiagnostic", "Échec diagnostic", e)
            false
        }
        list += DiagItem(
            "fileprovider", "Partage fichiers (FileProvider)", "module",
            if (fp) DiagStatus.OK else DiagStatus.WARN,
            if (fp) "Configuration présente — export .mcaddon / APK possible."
            else "Ressource file_paths absente — partage de fichiers risqué."
        )

        // Override AGW / pack manuel
        val overrideDir = File(context.filesDir, "agw_override")
        val overrideCount = overrideDir.listFiles()?.count { it.isFile } ?: 0
        val meta = try {
            val f = File(context.filesDir, "manual_update_meta.json")
            if (f.exists()) f.readText().take(80) else null
        } catch (e: Exception) { android.util.Log.w("AppDiagnostic", "Échec non critique", e); null }
        list += DiagItem(
            "manual_pack", "Pack de mise à jour manuel", "données",
            when {
                overrideCount > 0 || meta != null -> DiagStatus.OK
                else -> DiagStatus.WARN
            },
            when {
                overrideCount > 0 -> "Overrides AGW actifs ($overrideCount fichier(s)) — import manuel appliqué."
                meta != null -> "Métadonnées d'import présentes."
                else -> "Aucun pack manuel importé (normal si vous n'en avez pas fourni)."
            }
        )

        return list
    }

    private fun dataItems(): List<DiagItem> {
        val list = mutableListOf<DiagItem>()
        // Projets
        val projectsFile = File(context.filesDir, "sbh_projects.json")
        when {
            !projectsFile.exists() -> list += DiagItem(
                "projects", "Projets locaux", "données", DiagStatus.WARN,
                "Aucun sbh_projects.json — normal si aucun projet créé."
            )
            projectsFile.length() == 0L -> list += DiagItem(
                "projects", "Projets locaux", "données", DiagStatus.WARN,
                "Fichier sbh_projects.json vide."
            )
            else -> list += DiagItem(
                "projects", "Projets locaux", "données", DiagStatus.OK,
                "Fichier présent (${projectsFile.length()} octets)."
            )
        }
        // Workshop data
        val workshopHints = listOf("sbh_ws_portals.json", "sbh_ws_maps.json", "sbh_mobs.json", "sbh_items.json", "sbh_blocks.json", "sbh_ws_blueprints.json")
        val present = workshopHints.count { File(context.filesDir, it).exists() }
        list += DiagItem(
            "workshop_data", "Données atelier", "données",
            when {
                present == 0 -> DiagStatus.WARN
                present < workshopHints.size -> DiagStatus.OK
                else -> DiagStatus.OK
            },
            if (present == 0) "Aucune donnée atelier encore écrite (normal au premier lancement)."
            else "$present fichier(s) atelier détecté(s) dans le stockage interne."
        )
        // Espace libre approximatif
        val free = try {
            context.filesDir.usableSpace
        } catch (e: Exception) {
            Log.w("AppDiagnostic", "Échec diagnostic", e)
            -1L
        }
        list += DiagItem(
            "storage", "Espace de stockage", "données",
            when {
                free < 0 -> DiagStatus.UNKNOWN
                free < 5L * 1024 * 1024 -> DiagStatus.FAIL
                free < 50L * 1024 * 1024 -> DiagStatus.WARN
                else -> DiagStatus.OK
            },
            when {
                free < 0 -> "Impossible de mesurer."
                else -> "Libre ≈ ${free / (1024 * 1024)} Mo sur le stockage app."
            }
        )
        // AGW World Core / monde
        val agwFiles = listOf(
            "agw/project.json", "agw/lore.json", "agw/factions.json",
            "agw/heroes.json", "agw/phases.json", "agw/world_core.schema.json"
        )
        val missingAgw = agwFiles.filterNot { assetExists(it) }
        list += DiagItem(
            "agw_core", "AGW World Core", "module",
            if (missingAgw.isEmpty()) DiagStatus.OK else DiagStatus.FAIL,
            if (missingAgw.isEmpty()) "Contrat AGW + données de référence présents."
            else "Fichiers AGW manquants : ${missingAgw.joinToString()}"
        )

        val worldProjectPresent = assetExists("../world/SBH_World/project.godot")
        list += DiagItem(
            "sbh_world_runtime", "SBH World runtime", "module",
            DiagStatus.WARN,
            if (worldProjectPresent) "Projet Godot détecté dans la source, mais non embarqué dans cet APK."
            else "Runtime Godot non embarqué dans cet APK."
        )

        val runtimeStore = RuntimeDiagnosticStore(context)
        val latestRuntime = runtimeStore.latest()
        list += DiagItem(
            "runtime_last_error", "Dernière erreur runtime", "données",
            if (latestRuntime != null) DiagStatus.FAIL else DiagStatus.UNKNOWN,
            if (latestRuntime != null) latestRuntime.humanReport().take(4000)
            else "Aucune erreur runtime capturée — aucun test runtime enregistré."
        )

        val mapErrorFile = File(context.filesDir, "map_studio_last_error.txt")
        if (mapErrorFile.exists() && latestRuntime == null) {
            list += DiagItem(
                "map_last_error", "Dernière erreur Map Studio", "données",
                DiagStatus.FAIL,
                mapErrorFile.readText().take(500)
            )
        }

        val importRoot = File(context.filesDir, "imports")
        val imported = importRoot.listFiles()?.filter { it.isDirectory }.orEmpty()
        list += DiagItem(
            "imported_folders", "Dossiers importés", "données",
            if (imported.isEmpty()) DiagStatus.UNKNOWN else DiagStatus.OK,
            if (imported.isEmpty()) "Aucun dossier importé depuis le stockage du téléphone."
            else "${imported.size} dossier(s) importé(s) dans ${importRoot.name}."
        )
        return list
    }

    private fun assetExists(path: String): Boolean = try {
        context.assets.open(path).use { true }
    } catch (e: Exception) {
            Log.w("AppDiagnostic", "Échec diagnostic", e)
        false
    }

    private fun checkAssetModule(id: String, title: String, required: List<String>): DiagItem {
        val missing = mutableListOf<String>()
        for (path in required) {
            try {
                context.assets.open(path).close()
            } catch (e: Exception) {
            Log.w("AppDiagnostic", "Échec diagnostic", e)
                missing += path
            }
        }
        return when {
            missing.isEmpty() -> DiagItem(
                id, title, "module", DiagStatus.OK,
                "Tous les fichiers requis sont présents (${required.size})."
            )
            missing.size == required.size -> DiagItem(
                id, title, "module", DiagStatus.FAIL,
                "Module cassé — fichiers manquants : ${missing.joinToString()}"
            )
            else -> DiagItem(
                id, title, "module", DiagStatus.WARN,
                "Incomplet — manquant : ${missing.joinToString()}"
            )
        }
    }
}


fun DiagnosticReport.toShareText(): String {
    val date = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", java.util.Locale.FRANCE)
        .format(java.util.Date(generatedAtMs))
    val lines = mutableListOf<String>()
    lines += "SBh STUDIO — RAPPORT DIAGNOSTIC"
    lines += "================================"
    lines += "Date : $date"
    lines += "Version : ${identity.versionName} · code ${identity.versionCode}"
    lines += "Package : ${identity.packageName}"
    lines += "Android : SDK ${identity.sdkInt}"
    lines += "Appareil : ${identity.deviceModel}"
    lines += "Build : ${identity.buildType}"
    lines += ""
    lines += "RÉSULTAT : 🟢 $okCount OK · 🟡 $warnCount avertissement(s) · 🔴 $failCount erreur(s)"
    lines += ""
    items.forEach { item ->
        val icon = when (item.status) {
            DiagStatus.OK -> "🟢"
            DiagStatus.WARN -> "🟡"
            DiagStatus.FAIL -> "🔴"
            DiagStatus.UNKNOWN -> "⚪"
        }
        lines += "$icon [${item.category}] ${item.title}"
        lines += "    ${item.detail}"
    }
    return lines.joinToString("\n")
}
