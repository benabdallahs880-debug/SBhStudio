package com.sbh.studio.data

/**
 * Lecture des nombres saisis par l'utilisateur (V1.8.58) — règle UNIQUE.
 * Accepte la virgule décimale française (« 0,35 ») et les espaces.
 * Avant : certains écrans remplaçaient la virgule, d'autres non → « 0,35 » devenait
 * silencieusement la valeur par défaut à l'enregistrement.
 */
object NumberInput {
    fun decimal(text: String): Double? = text.trim().replace(" ", "").replace(',', '.').toDoubleOrNull()
    fun integer(text: String): Int? = text.trim().replace(" ", "").toIntOrNull()
}
