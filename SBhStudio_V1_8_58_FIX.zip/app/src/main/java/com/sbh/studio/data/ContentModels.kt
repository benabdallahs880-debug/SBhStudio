package com.sbh.studio.data

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * Item atelier — modèle enrichi (rétrocompatible : champs optionnels avec défauts).
 */
@Serializable
data class SbhItem(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val identifier: String,
    val damage: Int = 0,
    val durability: Int = 100,
    val textureUri: String? = null,
    /** weapon | tool | armor | shield | material | food | other */
    val category: String = "other",
    val description: String = "",
    val tags: List<String> = emptyList(),
    val maxStack: Int = 64,
    /** mainhand | offhand | head | chest | legs | feet | none */
    val slot: String = "none",
    val enchantable: Boolean = false,
    val glow: Boolean = false,
    val notes: String = ""
)

/**
 * Bloc atelier — modèle enrichi (rétrocompatible).
 */
@Serializable
data class SbhBlock(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val identifier: String,
    val hardness: Double = 1.0,
    val textureUri: String? = null,
    val resistance: Double = 1.0,
    /** dirt | stone | wood | metal | glass | other */
    val material: String = "other",
    /** any | pickaxe | axe | shovel | hoe | none */
    val tool: String = "any",
    val description: String = "",
    val tags: List<String> = emptyList(),
    val lightLevel: Int = 0,
    val notes: String = ""
)
