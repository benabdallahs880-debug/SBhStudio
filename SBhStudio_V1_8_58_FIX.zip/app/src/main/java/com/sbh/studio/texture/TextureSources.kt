package com.sbh.studio.texture

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import java.io.ByteArrayInputStream
import java.io.InputStream

/**
 * SEUL endroit de l'application qui sait ouvrir une adresse de texture (V1.8.58).
 *
 * Trois formats existent :
 *  - `sbhtex://<id>`              → texture créée dans le Studio Texture ([TextureLink])
 *  - `asset://<chemin>`           → texture embarquée (bibliothèque de skins, Practice…)
 *  - `content://…` / `file://…`   → fichier choisi par l'utilisateur
 *
 * Avant : la validation ne connaissait que le 3e format et bloquait l'export de tout ce qui
 * utilisait les deux premiers, pendant que le générateur, lui, les lisait très bien (deux
 * copies de la même règle qui avaient divergé). Validation ET générateur passent maintenant ici.
 */
object TextureSources {
    private const val TAG = "TextureSources"
    const val ASSET_PREFIX = "asset://"

    fun isAsset(uri: String?): Boolean = uri?.startsWith(ASSET_PREFIX) == true

    /** Ouvre un flux sur l'image, quel que soit le format d'adresse. null si introuvable. */
    fun openStream(context: Context, uri: String): InputStream? = try {
        when {
            TextureLink.isStudioUri(uri) ->
                TextureLink.loadPngBytes(context, uri)?.let { ByteArrayInputStream(it) }
            isAsset(uri) ->
                context.assets.open(uri.removePrefix(ASSET_PREFIX))
            else ->
                context.contentResolver.openInputStream(Uri.parse(uri))
        }
    } catch (e: Exception) {
        Log.w(TAG, "Texture introuvable : $uri", e)
        null
    }

    /** Dimensions (largeur, hauteur) de l'image, ou null si elle est illisible. */
    fun readSize(context: Context, uri: String): Pair<Int, Int>? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openStream(context, uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth > 0 && bounds.outHeight > 0) bounds.outWidth to bounds.outHeight else null
    } catch (e: Exception) {
        Log.w(TAG, "Dimensions illisibles : $uri", e)
        null
    }

    /** true si l'image existe et peut être décodée. */
    fun isReadable(context: Context, uri: String): Boolean = readSize(context, uri) != null
}
