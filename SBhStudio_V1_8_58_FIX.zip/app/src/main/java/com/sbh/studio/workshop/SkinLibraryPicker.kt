package com.sbh.studio.workshop

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.SkinLibrary
import com.sbh.studio.ui.AgwColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Sélecteur de skins depuis la bibliothèque intégrée (FreshAnimations).
 * Affiche les catégories + une grille d'aperçus.
 *
 * @param onSelect appelé avec le chemin asset (ex: "skins_library/wolf/wolf_ashen.png")
 *                 et la forme de base recommandée.
 */
@Composable
fun SkinLibraryPicker(
    selectedAssetPath: String?,
    onSelect: (assetPath: String, formeBase: String) -> Unit,
    modifier: Modifier = Modifier,
    maxHeight: Int = 280
) {
    val context = LocalContext.current
    val allSkins = remember { SkinLibrary.all(context) }
    val categories = remember(allSkins) { SkinLibrary.categories(context) }

    var selectedCategory by remember { mutableStateOf(categories.firstOrNull() ?: "wolf") }
    var searchQuery by remember { mutableStateOf("") }

    val displayed = remember(selectedCategory, searchQuery, allSkins) {
        val base = if (searchQuery.isBlank()) {
            allSkins.filter { it.category == selectedCategory }
        } else {
            SkinLibrary.search(context, searchQuery)
        }
        base
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            "Bibliothèque de skins (${allSkins.size})",
            fontWeight = FontWeight.SemiBold,
            color = AgwColors.GoldSoft
        )
        Text(
            "Source : FreshAnimations · crédit FreshLX requis",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(6.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Rechercher…") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(6.dp))

        // Chips catégories
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.horizontalScroll(rememberScrollState())
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat && searchQuery.isBlank(),
                    onClick = {
                        selectedCategory = cat
                        searchQuery = ""
                    },
                    label = { Text(cat.replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        if (displayed.isEmpty()) {
            Text("Aucun skin trouvé.", color = AgwColors.Sand)
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 72.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = maxHeight.dp)
            ) {
                items(displayed, key = { it.id }) { skin ->
                    val isSelected = selectedAssetPath == skin.assetPath
                    SkinThumbnail(
                        skin = skin,
                        selected = isSelected,
                        onClick = { onSelect(skin.assetPath, skin.formeBase) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SkinThumbnail(
    skin: SkinLibrary.Skin,
    selected: Boolean,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    // Décodage hors thread UI pour éviter jank / ANR sur grilles de skins.
    val bitmap by produceState<ImageBitmap?>(initialValue = null, skin.assetPath) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                context.assets.open(skin.assetPath).use { stream ->
                    BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            }.onFailure {
                android.util.Log.w("SkinLibraryPicker", "Texture illisible: ${skin.assetPath}", it)
            }.getOrNull()
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(72.dp)
            .clickable(onClick = onClick)
            .then(
                if (selected) Modifier.border(2.dp, AgwColors.SacredGold, RoundedCornerShape(6.dp))
                else Modifier
            )
            .padding(2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .background(AgwColors.NightStone, RoundedCornerShape(4.dp)),
            contentAlignment = Alignment.Center
        ) {
            val previewBmp = bitmap
            if (previewBmp != null) {
                Image(
                    bitmap = previewBmp,
                    contentDescription = skin.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(2.dp)
                )
            } else {
                Text("?", color = AgwColors.Sand, fontSize = 18.sp)
            }
        }
        Text(
            skin.name,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) AgwColors.SacredGold else AgwColors.PaleMarble,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}
