package com.sbh.studio.data

import android.content.Context
import android.util.Log
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Contenu trié issu de MCtier practice v2.2 (+ presets armure atelier).
 * Sections : armes, défense (boucliers), armures, blocs, maps templates.
 * Faction atelier : practice_pvp
 */
object PracticePresets {

    private val json = Json { ignoreUnknownKeys = true }
    private const val TAG = "PracticePresets"
    const val FACTION = "practice_pvp"

    @Serializable
    data class ItemDef(
        val id: String = "",
        val name: String = "",
        val name_en: String = "",
        val category: String = "",
        val damage: Int = 0,
        val durability: Int = 100,
        val tags: List<String> = emptyList(),
        val description: String = "",
        val slot: String = "",
        val armor_piece: String = "",
        val armor_tier: String = "",
        val defense: Int = 0,
        val textureAsset: String? = null
    )

    @Serializable
    private data class ItemsFile(
        val source: String = "",
        val faction: String = "",
        val category: String = "",
        val items: List<ItemDef> = emptyList()
    )

    @Serializable
    data class BlockDef(
        val id: String = "",
        val name: String = "",
        val name_en: String = "",
        val hardness: Double = 1.0,
        val tags: List<String> = emptyList(),
        val description: String = "",
        val role: String = "",
        val textureAsset: String? = null
    )

    @Serializable
    private data class BlocksFile(
        val source: String = "",
        val faction: String = "",
        val blocks: List<BlockDef> = emptyList()
    )

    @Serializable
    data class MapDef(
        val id: String = "",
        val name: String = "",
        val theme: String = "pvp_arena",
        val terrain: String = "flat",
        val sizeX: Int = 32,
        val sizeZ: Int = 32,
        val height: Int = 64,
        val hasVillage: Boolean = false,
        val hasDungeon: Boolean = false,
        val hasOasis: Boolean = false,
        val hasMountains: Boolean = false,
        val hasRoads: Boolean = false,
        val dimension: String = "minecraft:overworld",
        val description: String = "",
        val tags: List<String> = emptyList()
    )

    @Serializable
    private data class MapsFile(
        val source: String = "",
        val faction: String = "",
        val maps: List<MapDef> = emptyList()
    )

    private fun loadItemsFile(context: Context, asset: String): List<ItemDef> = try {
        context.assets.open(asset).bufferedReader().use { it.readText() }
            .let { json.decodeFromString<ItemsFile>(it).items }
    } catch (e: Exception) {
        Log.w(TAG, "Échec lecture $asset", e)
        emptyList()
    }

    fun loadWeapons(context: Context): List<ItemDef> =
        loadItemsFile(context, "practice/weapons.json")

    fun loadDefense(context: Context): List<ItemDef> =
        loadItemsFile(context, "practice/defense.json")

    fun loadArmor(context: Context): List<ItemDef> =
        loadItemsFile(context, "practice/armor.json")

    /** Toutes les catégories d'items practice, dans l'ordre : armes → défense → armures. */
    fun loadAllItems(context: Context): List<ItemDef> =
        loadWeapons(context) + loadDefense(context) + loadArmor(context)

    fun loadBlocks(context: Context): List<BlockDef> = try {
        context.assets.open("practice/blocks.json").bufferedReader().use { it.readText() }
            .let { json.decodeFromString<BlocksFile>(it).blocks }
    } catch (e: Exception) {
        Log.w(TAG, "Échec lecture blocks.json", e)
        emptyList()
    }

    fun loadMaps(context: Context): List<MapDef> = try {
        context.assets.open("practice/maps.json").bufferedReader().use { it.readText() }
            .let { json.decodeFromString<MapsFile>(it).maps }
    } catch (e: Exception) {
        Log.w(TAG, "Échec lecture maps.json", e)
        emptyList()
    }

    fun toSbhItems(defs: List<ItemDef>, projectId: String): List<SbhItem> =
        defs.map { def ->
            val tex = def.textureAsset?.let { "asset://$it" }
            SbhItem(
                projectId = projectId,
                name = def.name.ifBlank { def.name_en },
                identifier = def.id.ifBlank { "sbh_practice:item" },
                damage = def.damage,
                durability = def.durability,
                textureUri = tex,
                category = def.category.ifBlank { "other" },
                description = def.description,
                tags = def.tags,
                maxStack = if (def.category in listOf("weapon", "weapon_sword", "weapon_axe", "shield", "armor")) 1 else 64,
                slot = def.slot.ifBlank { "none" }
            )
        }

    fun toSbhBlocks(context: Context, projectId: String): List<SbhBlock> =
        loadBlocks(context).map { def ->
            val tex = def.textureAsset?.let { "asset://$it" }
            SbhBlock(
                projectId = projectId,
                name = def.name.ifBlank { def.name_en },
                identifier = def.id.ifBlank { "sbh_practice:block" },
                hardness = def.hardness,
                textureUri = tex,
                description = def.description,
                tags = def.tags,
                material = "other"
            )
        }

    /** Définitions de maps (conversion MapBlueprint côté workshop pour éviter le couplage data→UI). */

    fun summary(context: Context): String {
        val w = loadWeapons(context).size
        val d = loadDefense(context).size
        val a = loadArmor(context).size
        val b = loadBlocks(context).size
        val m = loadMaps(context).size
        return "Practice PvP — armes: $w | boucliers: $d | armures: $a | blocs: $b | maps: $m"
    }
}
