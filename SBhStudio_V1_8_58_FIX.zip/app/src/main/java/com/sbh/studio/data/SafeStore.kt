package com.sbh.studio.data

import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Écriture / lecture sûres des fichiers JSON de l'application (V1.8.56).
 *
 * Problèmes corrigés :
 * 1. Toutes les sauvegardes utilisaient le MÊME fichier temporaire « nom.json.tmp ».
 *    Deux sauvegardes lancées en parallèle sur Dispatchers.IO (clics rapides, Accueil +
 *    Atelier, sync Map Studio…) écrivaient dans ce même .tmp en même temps → JSON mélangé
 *    → au prochain démarrage la lecture échouait → liste vide → la sauvegarde suivante
 *    écrasait TOUT le contenu (perte de données silencieuse).
 *    → Un verrou par fichier + un .tmp unique par écriture + fsync.
 * 2. Un fichier illisible était silencieusement remplacé à la sauvegarde suivante.
 *    → Une copie « nom.json.corrupt-<horodatage> » est conservée avant tout écrasement.
 */
object SafeStore {
    private const val TAG = "SafeStore"
    private val locks = ConcurrentHashMap<String, Any>()

    private fun lockFor(file: File): Any {
        val key = file.absolutePath
        locks[key]?.let { return it }
        val fresh = Any()
        return locks.putIfAbsent(key, fresh) ?: fresh
    }

    /** Écriture atomique, sérialisée par fichier. Lève une exception si l'écriture échoue. */
    fun write(target: File, content: String) {
        synchronized(lockFor(target)) {
            target.parentFile?.mkdirs()
            val tmp = File(target.parentFile, "${target.name}.${System.nanoTime()}.tmp")
            try {
                FileOutputStream(tmp).use { out ->
                    out.write(content.toByteArray(Charsets.UTF_8))
                    out.flush()
                    try { out.fd.sync() } catch (e: Exception) { Log.w(TAG, "fsync impossible ${tmp.name}", e) }
                }
                if (!tmp.renameTo(target)) {
                    target.delete()
                    if (!tmp.renameTo(target)) throw IllegalStateException("Impossible d'enregistrer ${target.name}")
                }
            } finally {
                if (tmp.exists()) tmp.delete()
            }
        }
    }

    /** Lecture texte sous le même verrou que l'écriture (évite de lire un fichier en cours de remplacement). */
    fun readText(file: File): String? = synchronized(lockFor(file)) {
        if (file.exists()) file.readText() else null
    }

    /**
     * Lit et décode un fichier. Fichier absent → null.
     * Fichier présent mais illisible → copie de secours conservée, puis null.
     */
    fun <T> readOrBackup(file: File, tag: String, decode: (String) -> T): T? {
        val text: String? = try {
            readText(file)
        } catch (e: Exception) {
            Log.e(tag, "Lecture impossible ${file.name}", e)
            null
        }
        if (text == null) return null
        return try {
            decode(text)
        } catch (e: Exception) {
            Log.e(tag, "Contenu illisible ${file.name} — copie de secours conservée", e)
            backupCorrupt(file)
            null
        }
    }

    fun backupCorrupt(file: File) {
        try {
            if (!file.exists()) return
            val bak = File(file.parentFile, "${file.name}.corrupt-${System.currentTimeMillis()}")
            file.copyTo(bak, overwrite = false)
        } catch (e: Exception) {
            Log.w(TAG, "Copie de secours impossible pour ${file.name}", e)
        }
    }
}
