package com.sbh.studio.character

import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.ui.AgwColors
import io.github.sceneview.SceneView
import io.github.sceneview.math.Position
import io.github.sceneview.node.ModelNode
import io.github.sceneview.rememberCameraManipulator
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberMainLightNode
import io.github.sceneview.rememberModelInstance
import io.github.sceneview.rememberModelLoader

private const val TAG = "CharacterPreview3D"

/**
 * Viewport 3D Character Studio (Filament / SceneView).
 *
 * - Intensité lumière réduite pour les GPU téléphone
 * - Flag persistant de désactivation si l'utilisateur active le mode secours
 * - Fallback 2D immédiat si le 3D est désactivé (évite les boucles de crash)
 *
 * Un crash natif Filament (SIGSEGV) n'est pas catchable en Kotlin : le flag
 * [GraphicsSafety] peut être positionné par un handler global (voir MainActivity).
 */
@Composable
fun CharacterPreview3D(
    modelUri: String?,
    fallbackAsset: String = "models/sbh_mannequin.glb",
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var use3d by remember {
        mutableStateOf(!GraphicsSafety.isCharacter3dDisabled(context))
    }

    if (!use3d) {
        CharacterPreviewFallback(
            message = "Aperçu 3D désactivé pour stabiliser l'application sur cet appareil.",
            onRetry = {
                GraphicsSafety.setCharacter3dDisabled(context, false)
                use3d = true
            },
            onKeepOff = { /* reste en 2D */ },
            modifier = modifier
        )
        return
    }

    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    val location = modelUri?.takeIf { it.isNotBlank() } ?: fallbackAsset
    val instance = rememberModelInstance(modelLoader, location)

    Box(
        modifier = modifier.background(AgwColors.DeepNight, RoundedCornerShape(18.dp))
    ) {
        SceneView(
            modifier = Modifier.fillMaxSize(),
            engine = engine,
            modelLoader = modelLoader,
            cameraManipulator = rememberCameraManipulator(),
            cameraNode = rememberCameraNode(engine) {
                position = Position(z = 4f)
            },
            mainLightNode = rememberMainLightNode(engine) {
                intensity = 60_000f
            }
        ) {
            instance?.let {
                ModelNode(
                    modelInstance = it,
                    scaleToUnits = 1.8f,
                    autoAnimate = false,
                    position = Position(y = -0.9f)
                )
            }
        }

        // Accès rapide au mode secours (sans attendre un crash)
        TextButton(
            onClick = {
                Log.w(TAG, "Utilisateur a désactivé l'aperçu 3D")
                GraphicsSafety.setCharacter3dDisabled(context, true)
                use3d = false
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp)
        ) {
            Text("2D", color = AgwColors.GoldSoft, fontSize = 11.sp)
        }

        if (instance == null) {
            Text(
                text = "Chargement du modèle 3D…",
                color = AgwColors.Sand,
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(10.dp)
            )
        }
    }
}

/**
 * Panneau d'aperçu d'un personnage dans Character Studio (V1.8.58 — build).
 * Appelé par CharacterStudioZone mais absent du code depuis la refonte 1.8.55 de l'aperçu 3D,
 * ce qui empêchait la compilation. Affiche le modèle du personnage (ou le mannequin par
 * défaut) avec le mode secours 2D de [CharacterPreview3D], puis son nom et son modèle.
 */
@Composable
fun CharacterPreviewPanel(
    character: CharacterProject,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        CharacterPreview3D(
            modelUri = character.modelUri,
            modifier = Modifier
                .fillMaxWidth()
                .height(320.dp)
        )
        Text(
            text = character.name,
            color = AgwColors.SacredGold,
            fontSize = 14.sp
        )
        Text(
            text = character.modelName?.let { "Modèle : $it" } ?: "Mannequin par défaut (aucun modèle généré ou importé)",
            color = AgwColors.Sand,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun CharacterPreviewFallback(
    message: String,
    onRetry: () -> Unit,
    onKeepOff: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(AgwColors.DeepNight, RoundedCornerShape(18.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Aperçu 2D (secours)", color = AgwColors.SacredGold, fontSize = 14.sp)
            Text(message, color = AgwColors.Sand, fontSize = 12.sp)
            Text(
                "Le rendu Filament est désactivé pour éviter un plantage GPU.",
                color = AgwColors.GoldSoft,
                fontSize = 11.sp
            )
            TextButton(onClick = onRetry) {
                Text("Réessayer le 3D", color = AgwColors.SacredGold)
            }
            TextButton(onClick = onKeepOff) {
                Text("Rester en 2D", color = AgwColors.Sand)
            }
        }
    }
}

/**
 * Préférences graphiques partagées (Map Studio / Character 3D).
 * Utilisé aussi par le handler de crash dans [com.sbh.studio.MainActivity].
 */
object GraphicsSafety {
    private const val PREFS = "sbh_graphics"
    private const val KEY_CHAR_3D = "character_preview_3d_disabled"

    fun isCharacter3dDisabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_CHAR_3D, false)

    fun setCharacter3dDisabled(context: Context, disabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_CHAR_3D, disabled)
            // commit() synchrone : appelé depuis le gestionnaire de crash, juste avant la mort du
            // processus — avec apply() (asynchrone) le drapeau n'était souvent jamais écrit.
            .commit()
        Log.i(TAG, "character_preview_3d_disabled=$disabled")
    }

    /** True si la stack ressemble à un crash Filament / SceneView / gltfio. */
    fun looksLikeGraphicsCrash(stack: String?): Boolean {
        if (stack.isNullOrBlank()) return false
        val s = stack.lowercase()
        return listOf("filament", "sceneview", "gltfio", "libfilament", "characterpreview3d")
            .any { it in s }
    }
}
