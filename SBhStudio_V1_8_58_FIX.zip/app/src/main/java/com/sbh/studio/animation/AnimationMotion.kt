package com.sbh.studio.animation

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Cinématique partagée aperçu ↔ export (niveaux A+B).
 * Une seule source de vérité pour bob, lean, jambes, bras selon état + âme + forme.
 */
object AnimationMotion {

    data class PoseFrame(
        val bob: Float,
        val lean: Float,
        val legSwing: Float,
        val armSwing: Float,
        val armRaise: Float,      // bras levés (zombie idle / attack)
        val bodyPitch: Float,     // inclinaison avant
        val headYaw: Float,
        val headPitch: Float,
        val crouch: Float,        // 0..1 assis / bas
        val wing: Float,          // vol / nage
        val lateral: Float        // arachnide
    )

    fun soulMul(soul: AnimSoul): Float = when (soul) {
        AnimSoul.ASSASSIN, AnimSoul.AGILE -> 1.15f
        AnimSoul.BEAST, AnimSoul.HEAVY_QUAD -> 1.25f
        AnimSoul.MYSTIC, AnimSoul.FLYER -> 0.9f
        AnimSoul.DESERT, AnimSoul.WOLF -> 1.1f
        AnimSoul.UNDEAD -> 0.95f
        AnimSoul.ARACHNID -> 1.2f
        else -> 1f
    }

    /**
     * @param t temps en secondes (tick * scale)
     * @param formeBase id MobShapeCatalog (zombie, wolf, spider…)
     */
    fun pose(
        t: Float,
        state: AnimState,
        soul: AnimSoul,
        amplitude: Float,
        weight: Float,
        formeBase: String = "humanoid"
    ): PoseFrame {
        val amp = amplitude.coerceIn(0.25f, 2f) * soulMul(soul)
        val w = weight.coerceIn(0.4f, 1.6f)
        val forme = formeBase.lowercase()
        val isQuad = forme in setOf("wolf", "cow", "pig", "sheep", "horse")
        val isSpider = forme == "spider" || soul == AnimSoul.ARACHNID
        val isCreeper = forme == "creeper"
        val isUndead = forme in setOf("zombie", "skeleton") || soul == AnimSoul.UNDEAD
        val isFlyer = soul == AnimSoul.FLYER || soul == AnimSoul.MYSTIC

        var bob = 0f
        var lean = 0f
        var leg = 0f
        var arm = 0f
        var armRaise = 0f
        var bodyPitch = 0f
        var headYaw = 0f
        var headPitch = 0f
        var crouch = 0f
        var wing = 0f
        var lateral = 0f

        when (state) {
            AnimState.IDLE -> {
                bob = sin(t * 1.2f) * 3f * amp * (if (isFlyer) 1.4f else 0.5f)
                lean = sin(t * 0.4f) * 2f
                leg = 0f
                arm = sin(t * 0.8f) * 4f * amp
                headYaw = sin(t * 0.6f) * 8f * amp
                headPitch = sin(t * 0.5f) * 3f * amp
                if (isUndead) armRaise = 70f * amp
                if (isFlyer) wing = sin(t * 1.5f) * 12f * amp
                if (isSpider) {
                    bob = sin(t * 1.0f) * 2f * amp
                    lateral = sin(t * 0.7f) * 4f * amp
                }
            }
            AnimState.WALK -> {
                bob = sin(t * 2.8f).let { if (it > 0) it else 0f } * 4f * amp * w
                lean = sin(t * 1.4f) * 6f * amp * w
                leg = sin(t * 1.4f) * 22f * amp * (if (isQuad) 1.2f else 1f)
                arm = if (isUndead) 0f else sin(t * 1.4f) * 18f * amp
                bodyPitch = if (isUndead) 8f * amp else 3f * amp
                if (isUndead) armRaise = 75f * amp
                if (isSpider) {
                    lateral = sin(t * 2f) * 10f * amp
                    leg = sin(t * 2.2f) * 16f * amp
                }
                if (isCreeper) arm = 0f
            }
            AnimState.RUN -> {
                bob = sin(t * 4.4f).let { if (it > 0) it else 0f } * 6f * amp * w
                lean = sin(t * 2.2f) * 10f * amp * w
                leg = sin(t * 2.2f) * 32f * amp
                arm = if (isUndead) 0f else sin(t * 2.2f) * 28f * amp
                bodyPitch = 12f * amp
                if (isUndead) armRaise = 85f * amp
                if (isSpider) lateral = sin(t * 3f) * 14f * amp
            }
            AnimState.ATTACK -> {
                val swing = sin(t * 2f).coerceAtLeast(0f)
                bob = swing * 5f * amp
                lean = sin(t * 2f) * 8f * amp
                leg = sin(t * 2f) * 12f * amp
                arm = swing * 40f * amp
                armRaise = if (isUndead) 90f * amp else swing * 50f * amp
                bodyPitch = swing * 15f * amp
                headPitch = -swing * 10f * amp
            }
            AnimState.HURT -> {
                val hit = sin(t * 3f).coerceAtLeast(0f)
                bob = -hit * 8f * amp
                lean = -hit * 12f * amp
                leg = hit * 6f * amp
                arm = -hit * 15f * amp
                bodyPitch = -hit * 10f * amp
                headPitch = hit * 15f * amp
            }
            AnimState.SIT -> {
                bob = sin(t * 0.8f) * 1.5f * amp
                lean = 0f
                leg = 0f
                arm = sin(t * 0.6f) * 3f * amp
                crouch = 0.85f
                headYaw = sin(t * 0.5f) * 10f * amp
            }
            AnimState.SWIM -> {
                bob = sin(t * 2.2f) * 5f * amp
                lean = sin(t * 1.1f) * 5f * amp
                leg = sin(t * 1.1f) * 16f * amp
                arm = sin(t * 1.1f) * 20f * amp
                wing = sin(t * 1.1f) * 18f * amp
                bodyPitch = 20f * amp
            }
        }

        return PoseFrame(
            bob = bob,
            lean = lean,
            legSwing = leg,
            armSwing = arm,
            armRaise = armRaise,
            bodyPitch = bodyPitch,
            headYaw = headYaw,
            headPitch = headPitch,
            crouch = crouch,
            wing = wing,
            lateral = lateral
        )
    }

    /** Facteur de longueur d'anim export (secondes de base / speed). */
    fun animLength(base: Float, speed: Float): Float =
        (base / speed.coerceAtLeast(0.25f)).coerceIn(0.2f, 4f)
}
