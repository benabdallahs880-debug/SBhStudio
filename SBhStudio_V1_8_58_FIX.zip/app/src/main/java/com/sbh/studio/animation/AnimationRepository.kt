package com.sbh.studio.animation

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

private val animJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

class AnimationRepository(private val context: Context) {
    private fun file() = File(context.filesDir, "sbh_animations.json")

    fun loadAll(): List<AnimationProject> =
        com.sbh.studio.data.SafeStore.readOrBackup(file(), "AnimationRepository") {
            animJson.decodeFromString<List<AnimationProject>>(it)
        } ?: emptyList()

    fun saveAll(list: List<AnimationProject>) {
        com.sbh.studio.data.SafeStore.write(file(), animJson.encodeToString(list))
    }

    fun findForMob(mobId: String): AnimationProject? =
        loadAll().firstOrNull { it.linkedMobId == mobId }
}
