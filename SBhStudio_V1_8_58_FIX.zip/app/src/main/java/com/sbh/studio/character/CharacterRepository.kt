package com.sbh.studio.character

import android.content.Context
import android.util.Log
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

private val characterJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

class CharacterRepository(private val context: Context) {
    private fun file() = File(context.filesDir, "sbh_character_projects.json")

    // V1.8.58 : passe par SafeStore (oublié en 1.8.56) — verrou, .tmp unique, copie de secours.
    fun loadAll(): List<CharacterProject> =
        com.sbh.studio.data.SafeStore.readOrBackup(file(), "CharacterRepository") {
            characterJson.decodeFromString<List<CharacterProject>>(it)
        } ?: emptyList()

    fun saveAll(value: List<CharacterProject>) {
        com.sbh.studio.data.SafeStore.write(file(), characterJson.encodeToString(value))
    }
}
