package com.sbh.studio.generator

/**
 * Version des packs Minecraft exportés (V1.8.58) — règle UNIQUE, utilisée par le pipeline
 * principal (PackGenerator) et par la Fondation.
 *
 * Minecraft Bedrock ne remplace un pack déjà importé que si sa version AUGMENTE (les UUID,
 * eux, restent fixes par projet). Avant, la version restait toujours 0.7.4 : réexporter un
 * projet modifié ne changeait rien en jeu.
 *
 * Règle : version de base du projet (ex. 0.7.4) + numéro d'export sur le 3e chiffre.
 * 1er export → 0.7.5, 2e → 0.7.6… (toujours supérieur aux anciens exports en 0.7.4).
 * Fonction pure, testée dans PackVersioningTest.
 */
object PackVersioning {

    fun versionFor(baseVersion: String, exportCount: Int): List<Int> {
        val parts = baseVersion.split('.').take(3).map { it.trim().toIntOrNull()?.coerceAtLeast(0) ?: 0 }
        val padded = parts + List((3 - parts.size).coerceAtLeast(0)) { 0 }
        return listOf(padded[0], padded[1], padded[2] + exportCount.coerceAtLeast(0))
    }

    fun asString(version: List<Int>): String = version.joinToString(".")

    fun asJsonArray(version: List<Int>): String = version.joinToString(prefix = "[", postfix = "]", separator = ", ")
}
