package com.sbh.studio.data

import android.content.Context
import android.util.Log
import android.net.Uri
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream

/**
 * Bibliothèque audio de SBh Studio (nasheeds / musiques de jeu).
 * Métadonnées en JSON + fichiers bruts sous filesDir/sounds/.
 * Conversion automatique vers Ogg Vorbis quand possible (Minecraft Bedrock).
 */
class SoundRepository(private val context: Context) {

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    private fun metaFile() = File(context.filesDir, "sbh_sounds.json")
    private fun soundsDir() = File(context.filesDir, "sounds").also { it.mkdirs() }
    private fun tempDir() = File(context.cacheDir, "sound_import").also { it.mkdirs() }

    fun loadAll(): List<SbhSound> =
        SafeStore.readOrBackup(metaFile(), "SoundRepository") { json.decodeFromString<List<SbhSound>>(it) } ?: emptyList()

    fun saveAll(list: List<SbhSound>) {
        atomicWrite(metaFile(), json.encodeToString(list))
    }

    fun forProject(projectId: String): List<SbhSound> =
        loadAll().filter { it.projectId == null || it.projectId == projectId }

    fun loadForExport(projectId: String): List<SbhSound> =
        loadAll().filter { it.includeInPack && (it.projectId == null || it.projectId == projectId) }

    data class ImportResult(
        val sound: SbhSound?,
        val convertedToOgg: Boolean,
        val message: String
    )

    /**
     * Importe un fichier audio depuis un Uri (SAF).
     * Tente une conversion automatique vers .ogg (format recommandé Bedrock).
     */
    fun importFromUri(
        uri: Uri,
        displayName: String?,
        projectId: String? = null,
        soundEvent: String = "custom"
    ): ImportResult {
        return try {
            val nameGuess = displayName?.substringBeforeLast('.')?.ifBlank { null }
                ?: "نشيد_${System.currentTimeMillis() % 100000}"
            val extGuess = (displayName?.substringAfterLast('.', "") ?: "").lowercase().ifBlank {
                context.contentResolver.getType(uri)?.let { mime ->
                    when {
                        mime.contains("ogg") -> "ogg"
                        mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
                        mime.contains("mp4") || mime.contains("m4a") -> "m4a"
                        mime.contains("wav") -> "wav"
                        else -> "bin"
                    }
                } ?: "bin"
            }.take(5)

            val id = java.util.UUID.randomUUID().toString()
            val fileName = SbhSound.sanitize(nameGuess)

            // 1) Copie temporaire de la source
            val tempSrc = File(tempDir(), "src_$id.$extGuess")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempSrc).use { output -> input.copyTo(output) }
            } ?: return ImportResult(null, false, "Impossible de lire le fichier")

            if (!tempSrc.exists() || tempSrc.length() < 64) {
                tempSrc.delete()
                return ImportResult(null, false, "Fichier trop petit ou vide")
            }

            // 2) Conversion Ogg
            val conv = AudioOggConverter.convertToOgg(context, tempSrc, soundsDir(), id)
            val finalFile: File
            val finalExt: String
            val converted: Boolean
            val msg: String

            if (conv.success && conv.output != null) {
                finalFile = conv.output
                finalExt = "ogg"
                converted = !AudioOggConverter.isAlreadyOgg(tempSrc)
                msg = conv.message
                tempSrc.delete()
            } else {
                // Conservé tel quel
                finalExt = extGuess.ifBlank { "ogg" }
                finalFile = File(soundsDir(), "$id.$finalExt")
                tempSrc.copyTo(finalFile, overwrite = true)
                tempSrc.delete()
                converted = false
                msg = conv.message
            }

            // V1.8.58 : nom technique unique même pour un titre en arabe (voir SbhSound.technicalName).
            val techName = SbhSound(id = id, name = nameGuess, fileName = fileName).technicalName()
            val event = if (soundEvent == "custom" || soundEvent.isBlank()) {
                "sbh.music.$techName"
            } else {
                soundEvent
            }

            val sound = SbhSound(
                id = id,
                name = nameGuess,
                fileName = fileName,
                extension = finalExt,
                storagePath = "sounds/${finalFile.name}",
                projectId = projectId,
                soundEvent = event,
                category = if (event.startsWith("music") || event.startsWith("record") || event.startsWith("sbh.music")) "music" else "ambient",
                includeInPack = true,
                // V1.8.58 : signale aussi un .ogg non Vorbis (Opus), que Minecraft ne lit pas.
                notes = if (!conv.success) "Non converti en Ogg Vorbis (fichier .$finalExt) — Minecraft risque de ne pas le lire." else ""
            )

            val all = loadAll().toMutableList()
            all.add(0, sound)
            saveAll(all)
            ImportResult(sound, converted || finalExt == "ogg", msg)
        } catch (e: Exception) {
            ImportResult(null, false, e.message ?: "Échec de l'import")
        }
    }

    /** Compatibilité avec l'ancien appelant qui attendait SbhSound? */
    fun importFromUriLegacy(
        uri: Uri,
        displayName: String?,
        projectId: String? = null,
        soundEvent: String = "custom"
    ): SbhSound? = importFromUri(uri, displayName, projectId, soundEvent).sound

    fun delete(id: String) {
        val all = loadAll()
        val target = all.find { it.id == id }
        if (target != null) {
            fileFor(target)?.delete()
            saveAll(all.filter { it.id != id })
        }
    }

    fun update(sound: SbhSound) {
        val all = loadAll().map { if (it.id == sound.id) sound else it }
        saveAll(all)
    }

    fun assignToProject(soundId: String, projectId: String?) {
        val all = loadAll().map {
            if (it.id == soundId) it.copy(projectId = projectId) else it
        }
        saveAll(all)
    }

    fun fileFor(sound: SbhSound): File? {
        if (sound.storagePath.isBlank()) return null
        val f = File(context.filesDir, sound.storagePath)
        return if (f.exists()) f else null
    }

    fun bytesFor(sound: SbhSound): ByteArray? = fileFor(sound)?.readBytes()

    /**
     * sound_definitions.json — construit avec un vrai générateur JSON (V1.8.58) : avant, la
     * chaîne était assemblée à la main et un guillemet dans un nom d'événement cassait le fichier.
     */
    fun buildSoundDefinitionsJson(sounds: List<SbhSound>): String =
        kotlinx.serialization.json.buildJsonObject {
            put("format_version", kotlinx.serialization.json.JsonPrimitive("1.14.0"))
            put("sound_definitions", kotlinx.serialization.json.buildJsonObject {
                sounds.groupBy { it.definitionKey() }.forEach { (key, list) ->
                    put(key, kotlinx.serialization.json.buildJsonObject {
                        put("category", kotlinx.serialization.json.JsonPrimitive(list.first().category))
                        put("min_distance", kotlinx.serialization.json.JsonPrimitive(0.0))
                        put("max_distance", kotlinx.serialization.json.JsonPrimitive(64.0))
                        put("sounds", kotlinx.serialization.json.buildJsonArray {
                            list.forEach { s ->
                                add(kotlinx.serialization.json.buildJsonObject {
                                    put("name", kotlinx.serialization.json.JsonPrimitive(s.packSoundPath()))
                                    put("volume", kotlinx.serialization.json.JsonPrimitive(s.volume.coerceIn(0.05f, 1f)))
                                    put("stream", kotlinx.serialization.json.JsonPrimitive(true))
                                })
                            }
                        })
                    })
                }
            })
        }.toString()
}
