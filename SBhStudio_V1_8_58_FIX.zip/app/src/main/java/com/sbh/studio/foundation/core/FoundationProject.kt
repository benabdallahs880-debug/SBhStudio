package com.sbh.studio.foundation.core

import android.content.Context
import java.io.File
import java.util.UUID
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Gestion du projet de fondation AGW.
 * Crée l'arborescence BP/RP + dossiers annexes.
 */
class FoundationProject(
    context: Context,
    val projectName: String = "SBh-AGW-Foundation"
) {
    companion object {
        const val PREFIX = "agw"
        const val VERSION = "0.7.4"
        val MIN_ENGINE = listOf(1, 21, 0)
    }

    val root: File = File(context.getExternalFilesDir(null), projectName)
    val behaviorPack: File = File(root, "behavior_pack")
    val resourcePack: File = File(root, "resource_pack")
    val exports: File = File(root, "exports")
    val factionsDir: File = File(root, "factions")
    val dialoguesDir: File = File(root, "dialogues")
    val mapDir: File = File(root, "map")

    init {
        ensureStructure()
    }

    private fun ensureStructure() {
        listOf(
            "behavior_pack/entities",
            "behavior_pack/items",
            "behavior_pack/blocks",
            "behavior_pack/loot_tables/entities",
            "behavior_pack/spawn_rules",
            "behavior_pack/scripts",
            "resource_pack/entity",
            "resource_pack/attachables",
            "resource_pack/textures/items",
            "resource_pack/textures/blocks",
            "resource_pack/textures/entity",
            "resource_pack/textures/models/armor",
            "resource_pack/render_controllers",
            "resource_pack/texts",
            "exports",
            "factions",
            "dialogues",
            "map"
        ).forEach { File(root, it).mkdirs() }

        writeManifests()
        writeLanguages()
        writeDefaultRenderController()
    }

    /**
     * Correctif critique (même bug que dans le pipeline principal PackGenerator) : chaque
     * créature générée ici référence "controller.render.default" dans son client_entity, mais
     * ce contrôleur n'était jamais défini nulle part — le dossier render_controllers/ existait,
     * vide. Sans ce fichier, Minecraft ne sait pas quoi afficher et la créature reste invisible
     * en jeu, quelle que soit sa texture.
     */
    private fun writeDefaultRenderController() {
        writeText(
            File(root, "resource_pack/render_controllers/default.render_controllers.json"),
            """
                {
                  "format_version": "1.10.0",
                  "render_controllers": {
                    "controller.render.default": {
                      "geometry": "Geometry.default",
                      "materials": [ { "*": "Material.default" } ],
                      "textures": [ "Texture.default" ]
                    }
                  }
                }
            """.trimIndent()
        )
    }

    private fun writeManifests() {
        val idsFile = File(root, ".pack-uuids.json")
        val existing = runCatching {
            if (!idsFile.exists()) null else Json.parseToJsonElement(idsFile.readText()).jsonObject
        }.getOrNull()
        val bpUuid = existing?.get("bp")?.jsonPrimitive?.content ?: UUID.randomUUID().toString()
        val bpModUuid = existing?.get("bpModule")?.jsonPrimitive?.content ?: UUID.randomUUID().toString()
        val rpUuid = existing?.get("rp")?.jsonPrimitive?.content ?: UUID.randomUUID().toString()
        val rpModUuid = existing?.get("rpModule")?.jsonPrimitive?.content ?: UUID.randomUUID().toString()
        // V1.8.58 : version qui augmente à chaque génération (règle partagée PackVersioning),
        // sinon Minecraft garde l'ancienne Fondation déjà importée.
        val exportCount = (existing?.get("exportCount")?.jsonPrimitive?.content?.toIntOrNull() ?: 0) + 1
        val version = com.sbh.studio.generator.PackVersioning.versionFor(VERSION, exportCount)
        val v = com.sbh.studio.generator.PackVersioning.asJsonArray(version)
        com.sbh.studio.data.SafeStore.write(idsFile, """{
  "bp": "$bpUuid",
  "bpModule": "$bpModUuid",
  "rp": "$rpUuid",
  "rpModule": "$rpModUuid",
  "exportCount": $exportCount
}
""")

        // Le BP dépend du RP : activer la Fondation active aussi ses textures et rendus.
        writeText(File(behaviorPack, "manifest.json"), """
            {
              "format_version": 2,
              "header": {
                "name": "SBh AGW BP",
                "description": "SBh Arabian Gothic World — Fondation ${com.sbh.studio.generator.PackVersioning.asString(version)}",
                "uuid": "$bpUuid",
                "version": $v,
                "min_engine_version": [1, 21, 0]
              },
              "modules": [{
                "type": "data",
                "uuid": "$bpModUuid",
                "version": $v
              }],
              "dependencies": [{
                "uuid": "$rpUuid",
                "version": $v
              }]
            }
        """.trimIndent())

        writeText(File(resourcePack, "manifest.json"), """
            {
              "format_version": 2,
              "header": {
                "name": "SBh AGW RP",
                "description": "SBh Arabian Gothic World — Ressources ${com.sbh.studio.generator.PackVersioning.asString(version)}",
                "uuid": "$rpUuid",
                "version": $v,
                "min_engine_version": [1, 21, 0]
              },
              "modules": [{
                "type": "resources",
                "uuid": "$rpModUuid",
                "version": $v
              }]
            }
        """.trimIndent())
    }

    private fun writeLanguages() {
        writeText(File(resourcePack, "texts/languages.json"), """["fr_FR", "en_US"]""")
        File(resourcePack, "texts/fr_FR.lang").takeIf { !it.exists() }?.writeText("")
        File(resourcePack, "texts/en_US.lang").takeIf { !it.exists() }?.writeText("")
    }

    fun appendLang(fr: String, en: String) {
        appendUnique(File(resourcePack, "texts/fr_FR.lang"), fr)
        appendUnique(File(resourcePack, "texts/en_US.lang"), en)
    }

    private fun appendUnique(file: File, line: String) {
        val normalized = line.trimEnd()
        val existing = if (file.exists()) file.readLines().toSet() else emptySet()
        if (normalized.isNotBlank() && normalized !in existing) {
            file.appendText(normalized + "\n")
        }
    }

    fun writeText(file: File, content: String) {
        file.parentFile?.mkdirs()
        file.writeText(content.trimIndent())
    }
}
