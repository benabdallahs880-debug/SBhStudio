package com.sbh.studio.generator

import com.sbh.studio.data.Identifiers
import com.sbh.studio.workshop.RecipeBlueprint
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/**
 * Recettes Bedrock (V1.8.58) — fonction pure, testée dans RecipePackJsonTest.
 *
 * Avant : les recettes de l'Atelier étaient validées mais JAMAIS écrites dans le pack.
 * Types gérés : shaped (grille 3×3), shapeless (liste d'ingrédients), furnace (four).
 */
object RecipePackJson {

    /** Chemin du fichier dans le Behavior Pack. */
    fun path(r: RecipeBlueprint): String =
        "recipes/${Identifiers.nameOf(r.identifier).replace('/', '_')}.json"

    /** Ajoute "minecraft:" si l'utilisateur a saisi un id sans namespace (ex. "stick"). */
    fun normalizeItem(id: String): String {
        val t = id.trim()
        return if (t.isEmpty() || t.contains(':')) t else "minecraft:$t"
    }

    /** JSON de la recette, ou null si elle est inutilisable (grille vide, aucun ingrédient…). */
    fun json(r: RecipeBlueprint): String? {
        val type = r.type.lowercase()
        val result = normalizeItem(r.resultId)
        if (result.isEmpty()) return null
        val obj: JsonObject? = when {
            type.contains("furnace") -> furnace(r, result)
            type.contains("shapeless") -> shapeless(r, result)
            else -> shaped(r, result)
        }
        return obj?.toString()
    }

    private fun shaped(r: RecipeBlueprint, result: String): JsonObject? {
        val cells = (r.pattern + List(9) { "" }).take(9).map { normalizeItem(it) }
        val filled = cells.indices.filter { cells[it].isNotEmpty() }
        if (filled.isEmpty()) return null
        // Boîte englobante : Bedrock n'accepte pas de lignes/colonnes entièrement vides inutiles.
        val rows = filled.map { it / 3 }
        val cols = filled.map { it % 3 }
        val r0 = rows.min(); val r1 = rows.max(); val c0 = cols.min(); val c1 = cols.max()
        val letters = linkedMapOf<String, Char>()
        val symbols = "ABCDEFGHI"
        val pattern = (r0..r1).map { row ->
            (c0..c1).map { col ->
                val id = cells[row * 3 + col]
                if (id.isEmpty()) ' ' else letters.getOrPut(id) { symbols[letters.size] }
            }.joinToString("")
        }
        return buildJsonObject {
            put("format_version", "1.20.10")
            putJsonObject("minecraft:recipe_shaped") {
                putJsonObject("description") { put("identifier", r.identifier) }
                putJsonArray("tags") { add("crafting_table") }
                putJsonArray("pattern") { pattern.forEach { add(it) } }
                putJsonObject("key") {
                    letters.forEach { (id, letter) -> putJsonObject(letter.toString()) { put("item", id) } }
                }
                putJsonObject("result") {
                    put("item", result)
                    put("count", r.resultCount.coerceIn(1, 64))
                }
            }
        }
    }

    private fun shapeless(r: RecipeBlueprint, result: String): JsonObject? {
        val ingredients = r.ingredients.map { normalizeItem(it) }.filter { it.isNotEmpty() }.take(9)
        if (ingredients.isEmpty()) return null
        return buildJsonObject {
            put("format_version", "1.20.10")
            putJsonObject("minecraft:recipe_shapeless") {
                putJsonObject("description") { put("identifier", r.identifier) }
                putJsonArray("tags") { add("crafting_table") }
                putJsonArray("ingredients") {
                    ingredients.forEach { id -> add(buildJsonObject { put("item", id) }) }
                }
                putJsonObject("result") {
                    put("item", result)
                    put("count", r.resultCount.coerceIn(1, 64))
                }
            }
        }
    }

    private fun furnace(r: RecipeBlueprint, result: String): JsonObject? {
        val input = (r.ingredients + r.pattern).map { normalizeItem(it) }.firstOrNull { it.isNotEmpty() }
            ?: return null
        return buildJsonObject {
            put("format_version", "1.20.10")
            putJsonObject("minecraft:recipe_furnace") {
                putJsonObject("description") { put("identifier", r.identifier) }
                putJsonArray("tags") { add("furnace") }
                put("input", input)
                put("output", result)
            }
        }
    }
}
