package com.sbh.studio.workshop

import android.content.Context
import android.util.Log
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

private val edJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

/** Forme de base de l'Éditeur 3D. */
enum class EditorKind(val label: String) {
    CUBE("Cube"), SPHERE("Sphère"), CYLINDER("Cylindre")
}

/**
 * Objet de la scène de l'Éditeur 3D plein écran.
 * Unité = mètre. (x, y, z) = position de la base de l'objet ; y = hauteur au-dessus du sol.
 * hue < 0 = gris neutre, sinon teinte 0..360.
 */
@Serializable
data class EditorObject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String = EditorKind.CUBE.name,
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f,
    val rotY: Float = 0f,
    val scale: Float = 1f,
    val hue: Float = -1f
)

/** Persistance locale : une scène par projet, écriture atomique. */
class Editor3DRepository(private val context: Context) {
    private fun file(projectId: String): File {
        val safe = projectId.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.ifBlank { "default" }
        return File(context.filesDir, "sbh_editor3d_$safe.json")
    }

    /** null = jamais sauvegardée (première ouverture) ; liste vide = scène vidée volontairement. */
    // Fichier illisible : une copie de secours est conservée (SafeStore) avant que la scène
    // par défaut ne soit réécrite par-dessus — avant, la scène de l'utilisateur était perdue.
    fun load(projectId: String): List<EditorObject>? =
        com.sbh.studio.data.SafeStore.readOrBackup(file(projectId), "Editor3DRepository") {
            edJson.decodeFromString<List<EditorObject>>(it)
        }

    fun save(projectId: String, list: List<EditorObject>) {
        try {
            com.sbh.studio.data.SafeStore.write(file(projectId), edJson.encodeToString(list))
        } catch (e: Exception) {
            Log.e("Editor3DRepository", "Sauvegarde scène 3D impossible", e)
        }
    }
}
