package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Bibliothèque de skins intégrée — source principale : FreshAnimations v1.10.5
 *
 * 166 textures organisées par catégorie.
 * Accessible depuis MobZone, Character Studio et tout autre écran du studio.
 *
 * Assets attendus :
 *   assets/skins_library/<categorie>/<fichier>.png
 *   assets/skins_library/catalog.json
 */
object SkinLibrary {

    @Serializable
    data class Skin(
        val id: String,
        val name: String,
        val category: String,
        val file: String,               // relatif à skins_library/
        val formeBase: String,
        val source: String = "FreshAnimations"
    ) {
        /** Chemin complet dans les assets Android */
        val assetPath: String get() = "skins_library/$file"
    }

    @Serializable
    private data class CatalogFile(
        val version: Int = 1,
        val source: String = "",
        val skins: List<Skin> = emptyList()
    )

    private val json = Json { ignoreUnknownKeys = true }

    @Volatile private var cached: List<Skin>? = null

    /** Charge (une seule fois) le catalogue depuis les assets. */
    fun ensureLoaded(context: Context): List<Skin> {
        cached?.let { return it }
        return synchronized(this) {
            cached?.let { return it }
            val list = try {
                context.assets.open("skins_library/catalog.json")
                    .bufferedReader().use { it.readText() }
                    .let { json.decodeFromString<CatalogFile>(it).skins }
            } catch (e: Exception) {
                android.util.Log.e("SkinLibrary", "Échec chargement catalog.json", e)
                emptyList()
            }
            cached = list
            list
        }
    }

    fun all(context: Context): List<Skin> = ensureLoaded(context)

    fun categories(context: Context): List<String> =
        ensureLoaded(context).map { it.category }.distinct().sorted()

    fun byCategory(context: Context, category: String): List<Skin> =
        ensureLoaded(context).filter { it.category == category }

    fun findById(context: Context, id: String): Skin? =
        ensureLoaded(context).firstOrNull { it.id == id }

    fun search(context: Context, query: String): List<Skin> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return ensureLoaded(context)
        return ensureLoaded(context).filter {
            it.name.lowercase().contains(q) ||
            it.category.lowercase().contains(q) ||
            it.id.lowercase().contains(q)
        }
    }

    /** Forme de base recommandée pour une catégorie donnée. */
    fun recommendedForme(category: String): String = when (category) {
        "wolf", "cat", "fox" -> "wolf"
        "cow", "pig", "horse", "llama", "goat", "hoglin", "strider", "turtle", "sniffer", "equipment", "dolphin" -> "cow"
        "chicken", "parrot", "bee", "frog", "bat", "axolotl", "squid" -> "chicken"
        "zombie", "zombie_villager", "piglin", "illager", "witch", "villager", "wandering_trader" -> "zombie"
        "creeper", "shulker", "slime", "ghast", "guardian" -> "creeper"
        "spider", "endermite" -> "spider"
        // Bipèdes proches de l'humanoïde / joueur
        "allay", "blaze", "enderman", "iron_golem", "snow_golem" -> "humanoid"
        else -> "humanoid"
    }
}
