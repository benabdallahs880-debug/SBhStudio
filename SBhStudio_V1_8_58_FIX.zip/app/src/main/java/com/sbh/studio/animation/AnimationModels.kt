package com.sbh.studio.animation

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * États de vie supportés en V2 (enrichis d'après les comportements FreshAnimations).
 * Les clés bedKey restent compatibles avec l'export Bedrock.
 */
enum class AnimState(val label: String, val bedKey: String) {
    IDLE("Repos", "idle"),
    WALK("Marche", "walk"),
    RUN("Course", "run"),
    ATTACK("Attaque", "attack"),
    HURT("Blessé", "hurt"),
    SIT("Assis", "sit"),
    SWIM("Nage", "swim")
}

/**
 * Personnalité / âme qui module les presets.
 * V2 : 6 originaux + 6 inspirés FreshAnimations (par type de créature).
 */
enum class AnimSoul(val label: String, val description: String, val recommendedForme: String? = null) {
    // --- Originaux ---
    GUARDIAN("Garde", "Posture droite, gestes mesurés"),
    MERCHANT("Marchand", "Souple, accueillant"),
    ASSASSIN("Assassin", "Rapide, bas, nerveux"),
    BEAST("Bête", "Lourd, agressif"),
    MYSTIC("Mystique", "Flottant, rituel"),
    DESERT("Esprit du désert", "Large, majestueux"),

    // --- Inspirés FreshAnimations ---
    WOLF("Loup", "Marche basse, idle attentif, attaque brusque", "wolf"),
    UNDEAD("Mort-vivant", "Bras tendus, marche traînante, attaque lente", "zombie"),
    ARACHNID("Arachnide", "Corps bas, mouvement latéral, attaque bondissante", "spider"),
    FLYER("Volant", "Idle flottant, déplacement ondulant", null),
    HEAVY_QUAD("Quadrupède lourd", "Marche lourde, peu d'amplitude haute", "cow"),
    AGILE("Agile", "Rapide, amplitude moyenne, idle nerveux", "chicken")
}

@Serializable
data class AnimStateParams(
    val speed: Float = 1f,       // 0.25 .. 2.5
    val amplitude: Float = 1f,   // 0.25 .. 2
    val weight: Float = 1f,      // “poids” du mouvement
    val loop: Boolean = true
)

@Serializable
data class AnimationProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Nouvelle âme",
    val soul: String = AnimSoul.GUARDIAN.name,
    /** Mob Atelier lié (id interne MobEntity). */
    val linkedMobId: String? = null,
    val linkedMobIdentifier: String? = null,
    val states: Map<String, AnimStateParams> = defaultStates(),
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        fun defaultStates(): Map<String, AnimStateParams> = mapOf(
            AnimState.IDLE.name to AnimStateParams(speed = 0.8f, amplitude = 0.6f, weight = 1f, loop = true),
            AnimState.WALK.name to AnimStateParams(speed = 1.1f, amplitude = 1f, weight = 1f, loop = true),
            AnimState.RUN.name to AnimStateParams(speed = 1.5f, amplitude = 1.15f, weight = 0.9f, loop = true),
            AnimState.ATTACK.name to AnimStateParams(speed = 1.3f, amplitude = 1.2f, weight = 1.1f, loop = false),
            AnimState.HURT.name to AnimStateParams(speed = 1.4f, amplitude = 0.9f, weight = 0.8f, loop = false),
            AnimState.SIT.name to AnimStateParams(speed = 0.6f, amplitude = 0.4f, weight = 1.1f, loop = true),
            AnimState.SWIM.name to AnimStateParams(speed = 1.0f, amplitude = 0.85f, weight = 0.7f, loop = true)
        )
    }
}

object AnimationPresets {

    /**
     * Propose l'âme la plus adaptée à une forme de base MobShapeCatalog.
     */
    fun soulForForme(formeBase: String): AnimSoul = when (formeBase) {
        "wolf" -> AnimSoul.WOLF
        "zombie", "skeleton" -> AnimSoul.UNDEAD
        "spider" -> AnimSoul.ARACHNID
        "cow" -> AnimSoul.HEAVY_QUAD
        "chicken" -> AnimSoul.AGILE
        "creeper" -> AnimSoul.BEAST
        "humanoid" -> AnimSoul.GUARDIAN
        else -> AnimSoul.GUARDIAN
    }

    fun applySoul(soul: AnimSoul): Map<String, AnimStateParams> {
        val base = AnimationProject.defaultStates().toMutableMap()
        when (soul) {
            // ——— Originaux ———
            AnimSoul.GUARDIAN -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.7f, 0.5f, 1.2f, true)
                base[AnimState.WALK.name] = AnimStateParams(0.95f, 0.85f, 1.2f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.35f, 1.0f, 1.1f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.15f, 1.1f, 1.3f, false)
            }
            AnimSoul.MERCHANT -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.9f, 0.7f, 0.8f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.0f, 0.9f, 0.8f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.3f, 1.0f, 0.75f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.1f, 0.9f, 0.7f, false)
            }
            AnimSoul.ASSASSIN -> {
                base[AnimState.IDLE.name] = AnimStateParams(1.1f, 0.55f, 0.6f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.4f, 1.0f, 0.7f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.8f, 1.2f, 0.55f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.6f, 1.35f, 0.7f, false)
            }
            AnimSoul.BEAST -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.75f, 0.9f, 1.4f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.0f, 1.2f, 1.4f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.4f, 1.35f, 1.3f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.35f, 1.5f, 1.5f, false)
            }
            AnimSoul.MYSTIC -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.65f, 0.85f, 0.5f, true)
                base[AnimState.WALK.name] = AnimStateParams(0.85f, 0.95f, 0.5f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.2f, 1.05f, 0.45f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.0f, 1.15f, 0.6f, false)
            }
            AnimSoul.DESERT -> {
                base[AnimState.IDLE.name] = AnimStateParams(0.75f, 0.75f, 1.1f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.05f, 1.1f, 1.1f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.45f, 1.2f, 1.0f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.25f, 1.3f, 1.2f, false)
            }

            // ——— Inspirés FreshAnimations ———
            AnimSoul.WOLF -> {
                // Idle attentif, marche basse, course vive, attaque brusque
                base[AnimState.IDLE.name] = AnimStateParams(0.85f, 0.55f, 0.9f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.15f, 0.95f, 0.95f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.7f, 1.25f, 0.8f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.55f, 1.4f, 0.85f, false)
                base[AnimState.SIT.name] = AnimStateParams(0.5f, 0.35f, 1.0f, true)
                base[AnimState.HURT.name] = AnimStateParams(1.5f, 1.0f, 0.75f, false)
            }
            AnimSoul.UNDEAD -> {
                // Marche traînante, bras tendus, attaque lente et lourde
                base[AnimState.IDLE.name] = AnimStateParams(0.55f, 0.4f, 1.3f, true)
                base[AnimState.WALK.name] = AnimStateParams(0.75f, 0.7f, 1.35f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.05f, 0.85f, 1.25f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(0.95f, 1.15f, 1.4f, false)
                base[AnimState.HURT.name] = AnimStateParams(1.2f, 0.85f, 1.1f, false)
            }
            AnimSoul.ARACHNID -> {
                // Corps bas, mouvement latéral marqué, attaque bondissante
                base[AnimState.IDLE.name] = AnimStateParams(0.9f, 0.65f, 0.85f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.2f, 1.05f, 0.9f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.6f, 1.2f, 0.75f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.5f, 1.45f, 0.8f, false)
                base[AnimState.HURT.name] = AnimStateParams(1.45f, 1.0f, 0.7f, false)
            }
            AnimSoul.FLYER -> {
                // Idle flottant, déplacement ondulant
                base[AnimState.IDLE.name] = AnimStateParams(0.7f, 0.9f, 0.45f, true)
                base[AnimState.WALK.name] = AnimStateParams(0.95f, 1.0f, 0.5f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.35f, 1.15f, 0.4f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.2f, 1.2f, 0.55f, false)
                base[AnimState.SWIM.name] = AnimStateParams(1.0f, 1.05f, 0.45f, true)
            }
            AnimSoul.HEAVY_QUAD -> {
                // Marche lourde, peu d'amplitude haute, poids fort
                base[AnimState.IDLE.name] = AnimStateParams(0.6f, 0.5f, 1.45f, true)
                base[AnimState.WALK.name] = AnimStateParams(0.85f, 0.9f, 1.5f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.2f, 1.05f, 1.4f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.1f, 1.25f, 1.45f, false)
                base[AnimState.HURT.name] = AnimStateParams(1.15f, 0.9f, 1.3f, false)
            }
            AnimSoul.AGILE -> {
                // Rapide, amplitude moyenne, idle nerveux
                base[AnimState.IDLE.name] = AnimStateParams(1.05f, 0.7f, 0.65f, true)
                base[AnimState.WALK.name] = AnimStateParams(1.25f, 1.0f, 0.7f, true)
                base[AnimState.RUN.name] = AnimStateParams(1.75f, 1.2f, 0.6f, true)
                base[AnimState.ATTACK.name] = AnimStateParams(1.45f, 1.25f, 0.65f, false)
                base[AnimState.SIT.name] = AnimStateParams(0.7f, 0.45f, 0.8f, true)
            }
        }
        // HURT / SIT / SWIM par défaut si non surchargés
        if (!base.containsKey(AnimState.HURT.name) || base[AnimState.HURT.name] == AnimationProject.defaultStates()[AnimState.HURT.name]) {
            base.putIfAbsent(AnimState.HURT.name, AnimStateParams(1.4f, 0.95f, 0.9f, false))
        }
        base.putIfAbsent(AnimState.SIT.name, AnimStateParams(0.6f, 0.4f, 1.1f, true))
        base.putIfAbsent(AnimState.SWIM.name, AnimStateParams(1.0f, 0.85f, 0.7f, true))
        return base
    }
}
