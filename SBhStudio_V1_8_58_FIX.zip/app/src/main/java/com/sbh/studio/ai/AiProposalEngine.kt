package com.sbh.studio.ai

import android.content.Context
import com.sbh.studio.data.BlockRepository
import com.sbh.studio.data.ItemRepository
import com.sbh.studio.data.MobEngine
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.ProjectRepository
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import java.util.UUID

/**
 * Phase 3 — propositions d'actions CREATE / MODIFY.
 * Rien n'est écrit sans confirmation UI + permission.
 */
enum class AiProposalKind { CREATE_ITEM, CREATE_MOB, CREATE_BLOCK, FIX_MOB_COLLISION, FIX_MOB_FORME }

data class AiProposal(
    val id: String = UUID.randomUUID().toString(),
    val kind: AiProposalKind,
    val title: String,
    val detail: String,
    val permission: AiPermission,
    /** Identifiant cible si modification. */
    val targetId: String? = null,
    val previewLines: List<String> = emptyList()
)

data class AiApplyResult(
    val ok: Boolean,
    val message: String
)

object AiProposalEngine {

    fun proposalsFromReport(report: AiProjectReport, context: Context): List<AiProposal> {
        val out = mutableListOf<AiProposal>()
        val projectId = report.projectId
            ?: com.sbh.studio.data.ActiveProject.resolveId(context)
            ?: return emptyList()

        val mobs = MobRepository(context).loadAll().filter { it.projectId == projectId }
        val items = ItemRepository(context).loadAll().filter { it.projectId == projectId }

        // Mobs dont la collision s'écarte du standard forme
        mobs.forEach { m ->
            val def = MobEngine.formeDefaults(m.formeBase)
            val far = kotlin.math.abs(m.collisionLargeur - def.collisionLargeur) > 0.35 ||
                kotlin.math.abs(m.collisionHauteur - def.collisionHauteur) > 0.5
            if (far) {
                out += AiProposal(
                    kind = AiProposalKind.FIX_MOB_COLLISION,
                    title = "Ajuster collision · ${m.nom}",
                    detail = "Appliquer les dimensions standard de la forme « ${m.formeBase} » " +
                        "(${def.collisionLargeur}×${def.collisionHauteur}). Ne change ni nom, ni id, ni texture.",
                    permission = AiPermission.MODIFY,
                    targetId = m.id,
                    previewLines = listOf(
                        "Avant : ${m.collisionLargeur}×${m.collisionHauteur}",
                        "Après : ${def.collisionLargeur}×${def.collisionHauteur}",
                        "Vitesse suggérée : ${def.vitesse} · détection : ${def.detectionDistance}"
                    )
                )
            }
        }

        // Items sans texture → info seule, pas d'action auto utile
        val missingTex = items.count { it.textureUri.isNullOrBlank() }
        if (missingTex > 0 && items.size < 80) {
            // proposition de brouillon item « placeholder » seulement si projet quasi vide
            if (items.isEmpty()) {
                out += draftItemProposal(projectId, "Item atelier", "agw:item_draft")
            }
        }

        if (mobs.isEmpty()) {
            out += draftMobProposal(projectId, "Créature atelier", "agw:mob_draft")
        }

        // Toujours proposer un brouillon libre (CREATE) si pas trop de propositions
        if (out.none { it.kind == AiProposalKind.CREATE_ITEM }) {
            out += draftItemProposal(projectId, "Nouvel objet", "agw:item_${(items.size + 1)}")
        }
        if (out.none { it.kind == AiProposalKind.CREATE_BLOCK }) {
            val blocks = BlockRepository(context).loadAll().count { it.projectId == projectId }
            out += draftBlockProposal(projectId, "Nouveau bloc", "agw:block_${blocks + 1}")
        }

        return out.distinctBy { it.kind.name + (it.targetId ?: it.title) }.take(12)
    }

    /** Interprétation simple d'un message utilisateur → 0..1 proposition. */
    fun proposalFromPrompt(prompt: String, context: Context): AiProposal? {
        val p = prompt.trim().lowercase()
        if (p.isBlank()) return null
        val projectId = com.sbh.studio.data.ActiveProject.resolveId(context) ?: return null
        val nameGuess = prompt.trim()
            .replace(Regex("(?i)(crée|creer|ajouter|add|new|nouveau|nouvelle)\\s*(un|une|le|la)?\\s*"), "")
            .trim()
            .ifBlank { "Objet IA" }
            .take(40)

        return when {
            p.contains("mob") || p.contains("monstre") || p.contains("créature") || p.contains("creature") ->
                draftMobProposal(projectId, nameGuess, "agw:mob_${slug(nameGuess)}")
            p.contains("bloc") || p.contains("block") ->
                draftBlockProposal(projectId, nameGuess, "agw:block_${slug(nameGuess)}")
            p.contains("item") || p.contains("arme") || p.contains("objet") || p.contains("épée") || p.contains("epee") ->
                draftItemProposal(projectId, nameGuess, "agw:item_${slug(nameGuess)}")
            else -> null
        }
    }

    private fun slug(s: String): String =
        s.lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "draft" }
            .take(24)

    private fun draftItemProposal(projectId: String, name: String, id: String) = AiProposal(
        kind = AiProposalKind.CREATE_ITEM,
        title = "Créer item « $name »",
        detail = "Brouillon item dans le projet. Tu pourras le modifier dans l'atelier Items.",
        permission = AiPermission.CREATE,
        previewLines = listOf("Nom : $name", "Id : $id", "Catégorie : other", "Stack : 64")
    ).also { /* projectId encoded in apply via current project */ }

    private fun draftMobProposal(projectId: String, name: String, id: String) = AiProposal(
        kind = AiProposalKind.CREATE_MOB,
        title = "Créer mob « $name »",
        detail = "Brouillon monstre (forme humanoid, stats de base). Atelier Mobs pour peaufiner.",
        permission = AiPermission.CREATE,
        previewLines = listOf("Nom : $name", "Id : $id", "Forme : humanoid", "PV : 20")
    )

    private fun draftBlockProposal(projectId: String, name: String, id: String) = AiProposal(
        kind = AiProposalKind.CREATE_BLOCK,
        title = "Créer bloc « $name »",
        detail = "Brouillon bloc dans le projet. Atelier Blocs pour texture et matériau.",
        permission = AiPermission.CREATE,
        previewLines = listOf("Nom : $name", "Id : $id", "Dureté : 1.0")
    )


    /**
     * Applique toutes les corrections de collision (et forme) en une passe.
     * Une seule permission MODIFY ; un seul saveAll.
     */
    fun applyAllCollisionFixes(
        context: Context,
        proposals: List<AiProposal>,
        manager: AiPermissionManager
    ): AiApplyResult {
        if (!manager.can(AiPermission.MODIFY)) {
            return AiApplyResult(false, "Permission MODIFY refusée ou canal IA désactivé.")
        }
        val targets = proposals.filter {
            it.kind == AiProposalKind.FIX_MOB_COLLISION || it.kind == AiProposalKind.FIX_MOB_FORME
        }.mapNotNull { it.targetId }.distinct()
        if (targets.isEmpty()) {
            return AiApplyResult(false, "Aucune correction de collision dans les propositions.")
        }
        return runCatching {
            val repo = MobRepository(context)
            val all = repo.loadAll().toMutableList()
            var done = 0
            val names = mutableListOf<String>()
            targets.forEach { tid ->
                val idx = all.indexOfFirst { it.id == tid }
                if (idx >= 0) {
                    all[idx] = MobEngine.applyFormeSuggestions(all[idx])
                    names += all[idx].nom
                    done++
                }
            }
            if (done == 0) return@runCatching AiApplyResult(false, "Aucun mob cible trouvé.")
            repo.saveAll(all)
            val list = names.take(8).joinToString(", ") + if (names.size > 8) "…" else ""
            AiApplyResult(true, "$done collision(s) ajustée(s) : $list")
        }.getOrElse { AiApplyResult(false, "Échec lot : ${it.message ?: it::class.simpleName}") }
    }

    fun apply(context: Context, proposal: AiProposal, manager: AiPermissionManager): AiApplyResult {

        if (!manager.can(proposal.permission)) {
            return AiApplyResult(false, "Permission ${proposal.permission} refusée ou canal IA désactivé.")
        }
        val projectId = com.sbh.studio.data.ActiveProject.resolveId(context)
            ?: return AiApplyResult(false, "Aucun projet — ouvre un projet dans SBh Studio.")

        return runCatching {
            when (proposal.kind) {
                AiProposalKind.CREATE_ITEM -> {
                    val name = proposal.previewLines.find { it.startsWith("Nom") }?.substringAfter(":")?.trim()
                        ?: "Item IA"
                    val identifier = proposal.previewLines.find { it.startsWith("Id") }?.substringAfter(":")?.trim()
                        ?: "agw:item_draft"
                    val repo = ItemRepository(context)
                    val all = repo.loadAll()
                    if (all.any { it.identifier == identifier }) {
                        return@runCatching AiApplyResult(false, "Identifiant déjà utilisé : $identifier")
                    }
                    val item = SbhItem(
                        projectId = projectId,
                        name = name,
                        identifier = identifier,
                        notes = "Créé via SBh AI (brouillon)"
                    )
                    repo.saveAll(all + item)
                    AiApplyResult(true, "Item « $name » créé. Ouvre Atelier → Items.")
                }
                AiProposalKind.CREATE_MOB -> {
                    val name = proposal.previewLines.find { it.startsWith("Nom") }?.substringAfter(":")?.trim()
                        ?: "Créature IA"
                    val identifier = proposal.previewLines.find { it.startsWith("Id") }?.substringAfter(":")?.trim()
                        ?: "agw:mob_draft"
                    val repo = MobRepository(context)
                    val all = repo.loadAll()
                    if (all.any { it.identifiant == identifier }) {
                        return@runCatching AiApplyResult(false, "Identifiant déjà utilisé : $identifier")
                    }
                    val mob = MobEngine.applyFormeSuggestions(
                        MobEntity(
                            projectId = projectId,
                            nom = name,
                            identifiant = identifier,
                            versionHistory = listOf("v1 — brouillon SBh AI")
                        )
                    )
                    val prepared = mob
                    repo.saveAll(all + prepared)
                    AiApplyResult(true, "Mob « $name » créé. Ouvre Atelier → Mobs.")
                }
                AiProposalKind.CREATE_BLOCK -> {
                    val name = proposal.previewLines.find { it.startsWith("Nom") }?.substringAfter(":")?.trim()
                        ?: "Bloc IA"
                    val identifier = proposal.previewLines.find { it.startsWith("Id") }?.substringAfter(":")?.trim()
                        ?: "agw:block_draft"
                    val repo = BlockRepository(context)
                    val all = repo.loadAll()
                    if (all.any { it.identifier == identifier }) {
                        return@runCatching AiApplyResult(false, "Identifiant déjà utilisé : $identifier")
                    }
                    val block = SbhBlock(
                        projectId = projectId,
                        name = name,
                        identifier = identifier,
                        notes = "Créé via SBh AI (brouillon)"
                    )
                    repo.saveAll(all + block)
                    AiApplyResult(true, "Bloc « $name » créé. Ouvre Atelier → Blocs.")
                }
                AiProposalKind.FIX_MOB_COLLISION, AiProposalKind.FIX_MOB_FORME -> {
                    val tid = proposal.targetId
                        ?: return@runCatching AiApplyResult(false, "Cible mob manquante.")
                    val repo = MobRepository(context)
                    val all = repo.loadAll()
                    val idx = all.indexOfFirst { it.id == tid }
                    if (idx < 0) return@runCatching AiApplyResult(false, "Mob introuvable.")
                    val fixed = MobEngine.applyFormeSuggestions(all[idx])
                    repo.saveAll(all.toMutableList().also { it[idx] = fixed })
                    AiApplyResult(true, "Collision / stats forme appliquées à « ${fixed.nom} ».")
                }
            }
        }.getOrElse { AiApplyResult(false, "Échec : ${it.message ?: it::class.simpleName}") }
    }
}
