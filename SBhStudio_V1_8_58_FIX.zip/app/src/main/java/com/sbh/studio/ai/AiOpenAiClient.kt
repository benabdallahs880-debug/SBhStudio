package com.sbh.studio.ai

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Client for an OpenAI-compatible gateway. The Android app never contains an OpenAI API key.
 * The gateway is responsible for authenticating with OpenAI and keeping the secret server-side.
 */
class AiOpenAiClient {
    private val json = Json { ignoreUnknownKeys = true }

    data class Result(val ok: Boolean, val text: String, val detail: String)

    fun send(gatewayUrl: String, model: String, message: String, sessionId: String): Result {
        val base = gatewayUrl.trim().trimEnd('/')
        if (base.isBlank()) return Result(false, "", "Passerelle IA non configurée.")
        if (!base.startsWith("https://")) return Result(false, "", "La passerelle doit utiliser HTTPS.")
        if (message.isBlank()) return Result(false, "", "Message vide.")

        val endpoint = if (base.endsWith("/v1/responses")) base else "$base/v1/responses"
        val body = buildJsonObject {
            put("model", model.ifBlank { "gpt-5-mini" })
            put("input", message)
            put("safety_identifier", sha256(sessionId))
        }.toString()

        return runCatching {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            connection.disconnect()
            if (code !in 200..299) return@runCatching Result(false, "", "HTTP $code: ${raw.take(800)}")
            val root = json.parseToJsonElement(raw)
            val text = extractOutputText(root)
            if (text.isBlank()) Result(false, "", "Réponse reçue mais aucun texte output_text n'a été trouvé.")
            else Result(true, text, "Réponse OpenAI reçue.")
        }.getOrElse { Result(false, "", "Connexion IA impossible : ${it.message ?: it::class.simpleName}") }
    }

    /**
     * V1.8.58 : dans la réponse HTTP brute de l'API Responses, le texte est dans
     * output[].content[] sous la forme {"type":"output_text","text":"…"} — « output_text » est
     * une VALEUR de "type", pas une clé (la clé `output_text` n'existe que dans les SDK).
     * Avant, seule la clé était cherchée → aucune réponse n'était jamais lue.
     * On accepte : la clé `output_text` (passerelles qui la fournissent), les blocs
     * {type:"output_text", text}, et le format chat.completions (choices[].message.content).
     */
    internal fun extractOutputText(element: kotlinx.serialization.json.JsonElement): String {
        val hits = mutableListOf<String>()
        fun walk(node: kotlinx.serialization.json.JsonElement) {
            when (node) {
                is JsonObject -> {
                    val direct = node["output_text"]
                    if (direct is JsonPrimitive && direct.isString) hits += direct.content
                    val type = (node["type"] as? JsonPrimitive)?.content
                    val text = node["text"] as? JsonPrimitive
                    if (type == "output_text" && text != null && text.isString) hits += text.content
                    val message = node["message"] as? JsonObject
                    val content = message?.get("content") as? JsonPrimitive
                    if (content != null && content.isString) hits += content.content
                    node.forEach { (key, value) -> if (key != "output_text") walk(value) }
                }
                is kotlinx.serialization.json.JsonArray -> node.forEach(::walk)
                else -> Unit
            }
        }
        walk(element)
        return hits.distinct().joinToString("\n").trim()
    }

    private fun sha256(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
