package com.sbh.studio.workshop

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Bug n° 6 : le code généré par l'éditeur de portails doit être relu sans erreur (aller-retour). */
class PortalCodeTest {
    @Test fun tokensAvecParenthesesEtGuillemets() {
        assertEquals(listOf("portal.create", "Portail de l'Oasis"), portalCodeTokens("portal.create(\"Portail de l'Oasis\")"))
        assertEquals(listOf("portal.size", "4", "5"), portalCodeTokens("portal.size(4 5)"))
    }

    @Test fun allerRetourCodeVersPortail() {
        val original = PortalBlueprint(
            projectId = "p", name = "Portail du Désert", width = 6, height = 7,
            frameBlock = "agw:night_bricks", destinationHint = "Al-Zahra · الزهراء",
            destX = 120, destY = 70, destZ = -40, destDimension = "minecraft:nether",
            linkedMapId = "map-1", mapX = 10, mapY = 65, mapZ = 12
        )
        val code = portalToCode(original)
        assertTrue("Erreurs : " + validatePortalCode(code), validatePortalCode(code).isEmpty())
        val relu = applyPortalCode(code, PortalBlueprint(projectId = "p", name = "x"))
        assertEquals(original.name, relu.name)
        assertEquals(6, relu.width); assertEquals(7, relu.height)
        assertEquals(120, relu.destX); assertEquals(-40, relu.destZ)
        assertEquals("minecraft:nether", relu.destDimension)
        assertEquals("map-1", relu.linkedMapId)
        assertEquals(original.destinationHint, relu.destinationHint)
    }

    @Test fun copieUnique() {
        assertEquals("agw:bloc_copy", workshopIdCopy("agw:bloc"))
        assertEquals("agw:bloc_copy2", workshopIdCopy("agw:bloc", setOf("agw:bloc_copy")))
        assertEquals("agw:bloc_copy3", workshopIdCopy("agw:bloc_copy", setOf("agw:bloc_copy", "agw:bloc_copy2")))
    }
}
