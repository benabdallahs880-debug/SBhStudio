package com.sbh.studio.animation

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.double
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnimationExportTest {

    private fun anims(forme: String = "humanoid"): JsonObject =
        Json.parseToJsonElement(AnimationExport.animationJson(AnimationProject(), "agw:test", forme))
            .jsonObject["animations"]!!.jsonObject

    /** Bug n° 10 : la dernière image clé tombe exactement sur la durée de l'animation. */
    @Test fun imagesClesAlignéesSurLaDuree() {
        anims().forEach { (name, a) ->
            val obj = a.jsonObject
            val length = obj["animation_length"]!!.jsonPrimitive.double
            val maxKey = AnimationExport.maxKeyTime(obj["bones"]!!.jsonObject)
            assertEquals("Animation $name", length, maxKey.toDouble(), 0.002)
        }
    }

    /** Bug n° 11 : les quadrupèdes reçoivent le mouvement sur leg0..leg3. */
    @Test fun pattesDesQuadrupedes() {
        val walk = anims("cow")["animation.agw.test.walk"]!!.jsonObject["bones"]!!.jsonObject
        assertTrue(walk.keys.containsAll(listOf("leg0", "leg1", "leg2", "leg3")))
        val spider = anims("spider")["animation.agw.test.walk"]!!.jsonObject["bones"]!!.jsonObject
        assertTrue(spider.keys.containsAll((0..7).map { "leg$it" }))
    }

    @Test fun septEtatsExportes() {
        assertEquals(7, anims().size)
    }
}
