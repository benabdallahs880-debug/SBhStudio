package com.sbh.studio.generator

import com.sbh.studio.workshop.RecipeBlueprint
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Bug n° 4 : une recette de l'Atelier doit produire un vrai fichier de recette Bedrock. */
class RecipePackJsonTest {
    private fun parse(s: String?) = Json.parseToJsonElement(s!!).jsonObject

    @Test fun shapedReduitALaBoiteEtCreeLesCles() {
        val r = RecipeBlueprint(
            projectId = "p", name = "Épée", identifier = "agw:epee_recette",
            type = "minecraft:recipe_shaped", resultId = "agw:epee", resultCount = 1,
            pattern = listOf("", "minecraft:iron_ingot", "", "", "minecraft:iron_ingot", "", "", "stick", "")
        )
        val root = parse(RecipePackJson.json(r))["minecraft:recipe_shaped"]!!.jsonObject
        val pattern = root["pattern"]!!.jsonArray.map { it.jsonPrimitive.content }
        assertEquals(listOf("A", "A", "B"), pattern)
        val key = root["key"]!!.jsonObject
        assertEquals("minecraft:iron_ingot", key["A"]!!.jsonObject["item"]!!.jsonPrimitive.content)
        assertEquals("minecraft:stick", key["B"]!!.jsonObject["item"]!!.jsonPrimitive.content)
        assertEquals("agw:epee", root["result"]!!.jsonObject["item"]!!.jsonPrimitive.content)
        assertEquals("recipes/epee_recette.json", RecipePackJson.path(r))
    }

    @Test fun shapelessEtFour() {
        val shapeless = RecipeBlueprint(projectId = "p", name = "Eau", identifier = "agw:eau",
            type = "minecraft:recipe_shapeless", resultId = "agw:eau_pure",
            ingredients = listOf("minecraft:glass_bottle", "minecraft:water_bucket"))
        assertEquals(2, parse(RecipePackJson.json(shapeless))["minecraft:recipe_shapeless"]!!
            .jsonObject["ingredients"]!!.jsonArray.size)
        val furnace = RecipeBlueprint(projectId = "p", name = "Lingot", identifier = "agw:lingot",
            type = "minecraft:recipe_furnace", resultId = "agw:lingot_fin", ingredients = listOf("agw:minerai"))
        val f = parse(RecipePackJson.json(furnace))["minecraft:recipe_furnace"]!!.jsonObject
        assertEquals("agw:minerai", f["input"]!!.jsonPrimitive.content)
    }

    @Test fun recetteVideIgnoree() {
        assertNull(RecipePackJson.json(RecipeBlueprint(projectId = "p", name = "Vide", identifier = "agw:vide")))
    }
}
