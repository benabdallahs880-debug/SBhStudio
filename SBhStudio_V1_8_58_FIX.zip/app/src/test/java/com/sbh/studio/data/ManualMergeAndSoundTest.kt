package com.sbh.studio.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ManualMergeAndSoundTest {

    /** Bug n° 2 : un import ne doit JAMAIS supprimer les éléments d'un autre projet. */
    @Test fun fusionParProjetEtIdentifiant() {
        val a = MobEntity(id = "1", projectId = "A", nom = "Scorpion A", identifiant = "agw:dune_scorpion")
        val b = MobEntity(id = "2", projectId = "B", nom = "Scorpion B", identifiant = "agw:dune_scorpion")
        val incoming = listOf(MobEntity(id = "x", projectId = "B", nom = "Scorpion B v2", identifiant = "agw:dune_scorpion", vie = 50))
        val r = mergeByProjectAndIdentifier(listOf(a, b), incoming, { it.projectId }, { it.identifiant }) { inc, old -> inc.copy(id = old.id) }
        assertEquals(2, r.list.size)
        assertEquals(a, r.list.first { it.projectId == "A" })              // projet A intact
        val nb = r.list.first { it.projectId == "B" }
        assertEquals(50, nb.vie); assertEquals("2", nb.id)               // mis à jour, id conservé
        assertEquals(0, r.added); assertEquals(1, r.updated)
    }

    /** Bug n° 13 : deux nasheeds aux titres arabes ne doivent pas partager le même fichier. */
    @Test fun nomsTechniquesUniquesPourTitresArabes() {
        val s1 = SbhSound(id = "aaaa1111-0000", name = "نشيد الفجر", fileName = SbhSound.sanitize("نشيد الفجر"))
        val s2 = SbhSound(id = "bbbb2222-0000", name = "نشيد الليل", fileName = SbhSound.sanitize("نشيد الليل"))
        assertNotEquals(s1.packSoundPath(), s2.packSoundPath())
        assertNotEquals(s1.definitionKey(), s2.definitionKey())
        assertTrue(s1.packSoundPath().startsWith("sounds/sbh/sound_"))
        val latin = SbhSound(name = "Fajr", fileName = "fajr")
        assertEquals("sounds/sbh/fajr", latin.packSoundPath())
    }

    /** Bugs n° 19-20 : la virgule française est acceptée partout. */
    @Test fun nombresAvecVirgule() {
        assertEquals(0.35, NumberInput.decimal("0,35")!!, 1e-9)
        assertEquals(2.5, NumberInput.decimal(" 2.5 ")!!, 1e-9)
        assertEquals(null, NumberInput.decimal("abc"))
    }

    /** Bug n° 12 : chaque forme annonce la taille de texture de sa géométrie. */
    @Test fun tailleTextureParForme() {
        assertEquals(64 to 64, MobShapeCatalog.textureSizeFor("humanoid"))
        assertEquals(64 to 32, MobShapeCatalog.textureSizeFor("spider"))
        assertEquals(64 to 32, MobShapeCatalog.textureSizeFor("cow"))
        assertEquals(64 to 64, MobShapeCatalog.textureSizeFor("inconnue"))
    }
}
