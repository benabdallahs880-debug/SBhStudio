package com.sbh.studio.generator

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Bug n° 3 : la version du pack doit AUGMENTER à chaque export, sinon Minecraft garde l'ancien. */
class PackVersioningTest {
    @Test fun premierExportDepasseLaVersionHistorique() {
        assertEquals(listOf(0, 7, 5), PackVersioning.versionFor("0.7.4", 1))
    }

    @Test fun chaqueExportAugmente() {
        val v1 = PackVersioning.versionFor("0.7.4", 1)
        val v2 = PackVersioning.versionFor("0.7.4", 2)
        assertTrue(v2[2] > v1[2])
    }

    @Test fun versionIncompleteOuInvalide() {
        assertEquals(listOf(1, 0, 3), PackVersioning.versionFor("1", 3))
        assertEquals(listOf(0, 0, 1), PackVersioning.versionFor("abc", 1))
    }

    @Test fun formats() {
        assertEquals("0.7.5", PackVersioning.asString(listOf(0, 7, 5)))
        assertEquals("[0, 7, 5]", PackVersioning.asJsonArray(listOf(0, 7, 5)))
    }
}
