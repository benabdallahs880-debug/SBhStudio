package com.sbh.studio.ai

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Test

/** Bug n° 16 : le texte d'une réponse HTTP brute de l'API Responses doit être lu. */
class AiOpenAiClientTest {
    private val client = AiOpenAiClient()

    @Test fun reponseBruteResponses() {
        val raw = """{"id":"resp_1","output":[{"type":"message","role":"assistant",
            "content":[{"type":"output_text","text":"Bonjour","annotations":[]}]}]}"""
        assertEquals("Bonjour", client.extractOutputText(Json.parseToJsonElement(raw)))
    }

    @Test fun passerelleAvecOutputText() {
        assertEquals("Salut", client.extractOutputText(Json.parseToJsonElement("""{"output_text":"Salut"}""")))
    }

    @Test fun formatChatCompletions() {
        val raw = """{"choices":[{"message":{"role":"assistant","content":"Hey"}}]}"""
        assertEquals("Hey", client.extractOutputText(Json.parseToJsonElement(raw)))
    }
}
