package com.sbh.studio.workshop

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.GZIPOutputStream

/**
 * Bug n° 9 : un vrai fichier de structure Java (size en TAG_List) et un .mcstructure Bedrock
 * (little-endian) doivent être lus. Les octets sont construits ici selon la spécification.
 */
class NbtStructureParserTest {

    /** Écrivain NBT minimal pour fabriquer des fichiers de test. */
    private class W(order: ByteOrder) {
        val out = ByteArrayOutputStream()
        private val o = order
        fun u8(v: Int) { out.write(v and 0xFF) }
        fun i16(v: Int) { out.write(ByteBuffer.allocate(2).order(o).putShort(v.toShort()).array()) }
        fun i32(v: Int) { out.write(ByteBuffer.allocate(4).order(o).putInt(v).array()) }
        fun str(s: String) { val b = s.toByteArray(Charsets.UTF_8); i16(b.size); out.write(b) }
        fun tag(type: Int, name: String) { u8(type); str(name) }
    }

    private fun javaStructure(): ByteArray {
        val w = W(ByteOrder.BIG_ENDIAN)
        w.tag(10, "")                       // racine
        w.tag(9, "size"); w.u8(3); w.i32(3); w.i32(3); w.i32(2); w.i32(1)   // TAG_List d'Int (forme réelle) : 3×2×1
        w.tag(9, "palette"); w.u8(10); w.i32(2)
        w.tag(8, "Name"); w.str("minecraft:stone"); w.u8(0)
        w.tag(8, "Name"); w.str("minecraft:air"); w.u8(0)
        w.tag(9, "blocks"); w.u8(10); w.i32(2)
        w.tag(9, "pos"); w.u8(3); w.i32(3); w.i32(0); w.i32(0); w.i32(0)
        w.tag(3, "state"); w.i32(0); w.u8(0)
        w.tag(9, "pos"); w.u8(3); w.i32(3); w.i32(1); w.i32(0); w.i32(0)
        w.tag(3, "state"); w.i32(1); w.u8(0)
        w.u8(0)                             // fin racine
        return w.out.toByteArray()
    }

    @Test fun structureJavaAvecSizeEnListe() {
        val def = NbtStructureParser.parseStructure(javaStructure(), "Test")!!
        assertEquals(3, def.size.x); assertEquals(2, def.size.y); assertEquals(1, def.size.z)
        assertEquals(1, def.blocks.size) // l'air est ignoré
    }

    @Test fun structureJavaGzip() {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(javaStructure()) }
        assertNotNull(NbtStructureParser.parseStructure(bos.toByteArray(), "Gz"))
    }

    @Test fun mcstructureBedrock() {
        val w = W(ByteOrder.LITTLE_ENDIAN)
        w.tag(10, "")
        w.tag(3, "format_version"); w.i32(1)
        w.tag(9, "size"); w.u8(3); w.i32(3); w.i32(2); w.i32(1); w.i32(2)   // 2×1×2
        w.tag(10, "structure")
        w.tag(9, "block_indices"); w.u8(9); w.i32(2)
        w.u8(3); w.i32(4); w.i32(0); w.i32(1); w.i32(-1); w.i32(0)           // couche 1
        w.u8(3); w.i32(4); w.i32(-1); w.i32(-1); w.i32(-1); w.i32(-1)        // couche 2 (eau)
        w.tag(10, "palette"); w.tag(10, "default")
        w.tag(9, "block_palette"); w.u8(10); w.i32(2)
        w.tag(8, "name"); w.str("minecraft:stone"); w.tag(10, "states"); w.u8(0); w.tag(3, "version"); w.i32(1); w.u8(0)
        w.tag(8, "name"); w.str("minecraft:air"); w.tag(10, "states"); w.u8(0); w.tag(3, "version"); w.i32(1); w.u8(0)
        w.u8(0) // fin default
        w.u8(0) // fin palette
        w.u8(0) // fin structure
        w.u8(0) // fin racine
        val def = NbtStructureParser.parseStructure(w.out.toByteArray(), "Bedrock")!!
        assertEquals(2, def.size.x); assertEquals(2, def.size.z)
        assertEquals(2, def.blocks.size) // 2 pierres ; air et vides (-1) ignorés
        // index 3 = (x=1, y=0, z=1) dans l'ordre Bedrock (z le plus rapide)
        assertEquals(1, def.blocks[1].x); assertEquals(1, def.blocks[1].z)
    }

    @Test fun fichierCorrompuRefuseSansPlanter() {
        val bad = byteArrayOf(10, 0, 0, 7, 0, 1, 'a'.code.toByte(), 0x7F, 0x7F, 0x7F, 0x7F)
        assertNull(NbtStructureParser.parseStructure(bad, "Bad"))
    }
}
