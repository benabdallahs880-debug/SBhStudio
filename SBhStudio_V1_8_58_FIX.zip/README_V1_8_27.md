# SBh Studio V1.8.27

Réparations + premiers tests unitaires.

## Correctifs
1. **version.json racine** restauré (le build Gradle en dépend) + fallback assets
2. **Force unwraps `!!`** supprimés :
   - MineEdit (MainActivity)
   - DebugScreen (interpretation)
   - ReportsScreen (selectedId)
3. **Tests unitaires P0** ajoutés :
   - `IdentifiersTest`
   - `MobShapeCatalogTest`
   - `SkinLibraryFormeTest`
4. Dépendance JUnit pour `./gradlew test`

## Build
```bash
./gradlew assembleDebug
./gradlew test
```
