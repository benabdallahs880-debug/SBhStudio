# SBh Studio V1.8.55 — Source complète (stabilisation téléphone)

**versionName :** 1.8.55  
**versionCode :** 90  

## Contenu
- Code source Kotlin complet (`app/src/main/java`)
- Assets (practice, skins, branding, mapstudio, AGW, …)
- Gradle wrapper + scripts
- Correctifs P0/P1 intégrés (IO, WebGL, Filament 2D, namespace practice)

## Build
```bash
./gradlew assembleDebug
# APK : app/build/outputs/apk/debug/
```

Si `gradlew` est manquant :
```bash
gradle wrapper --gradle-version 8.11.1
./gradlew assembleDebug
```

## Tests téléphone
Voir `SMOKE_TEST_5MIN.md` et `TEST_PLAN_TELEPHONE_1.8.54.md`.

## Changelog
Voir `CHANGELOG_1_8_55.md` et `STATUS_1_8_55.md`.
