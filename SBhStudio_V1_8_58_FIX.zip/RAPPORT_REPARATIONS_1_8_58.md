# SBh Studio V1.8.58 — Réparation des fonctions cassées

**Base :** V1.8.57 (versionCode 92) · **Résultat :** V1.8.58 (versionCode 93) · 2026-10-05
**Source des bugs (enquête du 05/10) :** une même règle écrite à plusieurs endroits, et des formats extérieurs jamais confrontés au réel.
**Méthode de réparation :** chaque règle partagée a maintenant **un seul propriétaire**, et chaque réparation testable hors téléphone a été **exécutée** ou couverte par un test de bout en bout.

---

## 1. Bilan

| | Nombre |
|---|---:|
| Problèmes de l'analyse profonde réparés | **33 / 37** |
| Bugs supplémentaires trouvés **pendant les tests** et réparés | 4 |
| Problèmes non réparés (décision ou test en jeu nécessaire) | 4 |
| Fichiers modifiés / créés | 38 (dont 6 nouveaux fichiers de code et 7 fichiers de tests) |

---

## 2. Ce qui a été réparé (numéros du rapport `ANALYSE_PROFONDE_BUGS_1_8_57.md`)

### 🔴 Critiques
| N° | Réparation | Règle unique créée |
|----|-----------|--------------------|
| 1 | La vérification avant export lit maintenant `asset://` (skins, Practice) et `sbhtex://` (Studio Texture) → **l'export n'est plus bloqué**. | `texture/TextureSources.kt` : seul lecteur de textures, utilisé par la validation ET le générateur |
| 2 | Mise à jour manuelle : fusion par **projet + identifiant** ; les autres projets ne sont plus jamais touchés ; sans projet précisé → projet actif. | `mergeByProjectAndIdentifier` (ManualUpdateImporter) |
| 3 | La **version du pack augmente à chaque export** (0.7.5, 0.7.6…) → Minecraft remplace l'ancien pack. Idem pour la Fondation. La version apparaît dans le rapport d'export. | `generator/PackVersioning.kt` (pipeline principal + Fondation) |
| 4 | Les **recettes sont écrites dans le pack** (`recipes/*.json` : grille, sans forme, four), y compris depuis l'export de l'Accueil. Doublons d'identifiant de recette signalés. | `generator/RecipePackJson.kt` |

### 🟠 Majeurs
| N° | Réparation |
|----|-----------|
| 5 | Portails : le script regarde le bloc aux pieds **puis le bloc dessous** → téléportation quand on marche dessus. **Simulé avec Node : téléportation déclenchée.** |
| 6 | Éditeur de code des portails : parenthèses et virgules acceptées. Génération extraite (`portalToCode`) et **aller-retour testé**. |
| 7 | Code Studio de Map Studio : même correction de l'analyseur. **Exemple fourni exécuté dans Node : 0 erreur.** |
| 8 | Exports `.schem` / `.mcfunction` / `.json` de Map Studio : passent par un nouveau pont natif `saveFile` (fichier dans `files/map_exports/` + fenêtre de partage). Le message dépend du résultat réel. |
| 9 | Import `.nbt` réécrit : `size` en liste (vrais fichiers Java), gzip, **`.mcstructure` Bedrock** (little-endian), protection contre les fichiers corrompus. |
| 10 | Animations : les images clés sont remises à l'échelle de la durée → la boucle se referme exactement. **Vérifié : marche à 1.1 → durée 0,909 s, dernière image clé à 0,909 s.** |
| 11 | Pattes animées pour vache, loup, creeper (`leg0–3`), poule (`leg0–1`), araignée (`leg0–7`). |
| 12 | Textures de mob adaptées à la forme : 64×64 (humanoïde, zombie) ou 64×32 (araignée, vache, loup, poule, creeper, squelette), calées en haut à gauche comme un skin Minecraft. Taille déclarée dans `MobShapeCatalog`. |
| 13 | Sons : nom technique unique quand le titre est en arabe (`sound_xxxxxxxx`). `sound_definitions.json` construit avec un vrai générateur JSON. |
| 14 | Supprimer un mob, un item ou un bloc retire ses liens dans les maps. Un lien cassé n'est plus qu'un avertissement (n'empêche plus l'export). |
| 15 | Studio Texture : ouvrir une texture d'un autre format n'affiche plus une toile vide. |
| 16 | IA : le texte de la réponse brute OpenAI (`output[].content[].text`) est lu, ainsi que les formats `output_text` et `choices[].message.content`. |
| 17 | Fondation : les gardes ripostent et attaquent les factions ennemies (liste unique des factions). |
| 18 | Fondation : textures de personnages en 64×32 avec visage et bandeau. |

### 🟡 Mineurs
| N° | Réparation |
|----|-----------|
| 19–20 | Une seule règle de lecture des nombres (`data/NumberInput.kt`), qui accepte « 0,35 » partout (Mobs, Blocs, éditeurs de l'Accueil). |
| 21 | Modifier un mob garde son historique de versions. |
| 22 | Impossible d'enregistrer un mob tant que le moteur signale une erreur. |
| 23 | Changer de projet dans l'Atelier réinitialise les formulaires (plus de mob « déplacé » d'un projet à l'autre). |
| 24 | « Dupliquer » génère un identifiant libre (`_copy`, `_copy2`…). |
| 25 | Code Studio : les commandes passent par l'historique (Annuler fonctionne) ; `map.create` vide l'ancien historique. **Testé : Annuler remet le monde à 0 bloc.** |
| 26 | Export `.schem` : plus d'arguments géants (plus de « Maximum call stack » sur les grandes maps). |
| 27 | Export `.mcfunction` : découpé par 9 000 commandes, coordonnées relatives `~`. |
| 28 | Rattacher une structure à une map l'enregistre vraiment (`files/structures/`) ; « village » n'est plus forcé. |
| 29 | Installation d'APK : inspection hors du thread UI, message si Android demande d'abord l'autorisation. |
| 31 | Le pack de comportement dépend du pack de ressources (et la Fondation aussi). |
| 33 | Invisibilité : durée 999999 s au lieu de la valeur entière maximale. |
| 36 | Un `.ogg` en codec Opus n'est plus considéré comme prêt ; la note du son le signale. |
| 37 | Avertissement après « Générer la fondation » : ne pas activer la Fondation et l'export du projet dans le même monde. |

### Bugs supplémentaires trouvés en testant (et réparés)
1. **Code Studio : les structures étaient enterrées.** L'exemple remplissait tout le volume de sable, et village, oasis et forteresse étaient construits à y = 1. Ils se posent maintenant sur la surface ; l'exemple utilise `terrain.height(18, "sand")`. **Testé : 2 251 blocs de structures au-dessus du sol, oasis en eau à la surface.**
2. **Sons : la valeur par défaut `sbh.music.custom` était partagée** par tous les sons → même clé dans le pack. Chaque son a maintenant sa clé.
3. `CharacterRepository`, le journal des exports, les rapports et la scène jouable écrivaient encore leurs fichiers sans SafeStore (oubli de la 1.8.56) : corrigé. **Plus aucune écriture `.tmp` maison dans le projet.**
4. Le sélecteur de texture Studio de l'atelier Mobs proposait des formats 16×16 d'item : il propose maintenant les formats de skin.

---

## 3. Ce qui n'a PAS été réparé (et pourquoi)

| N° | Point | Raison |
|----|-------|--------|
| 30 | Clé de déblocage en clair dans l'APK | Décision à prendre avec toi : la sortir du code peut bloquer l'accès aux fonctions avancées si la configuration du build n'est pas prête. |
| 32 | Animation d'attaque déclenchée par `is_angry` | À vérifier dans Minecraft avant de changer : une mauvaise condition remplacerait la marche par l'attaque. |
| 34 | Armures invisibles portées (pas d'`attachables`) | Gros chantier (modèle 3D + textures d'armure) ; à planifier après les tests. |
| 35 | Version `@minecraft/server` 1.17.0 du script des portails | Dépend de la version de Minecraft du téléphone : à vérifier en jeu. |

**Correction d'un chiffre de l'enquête :** `ENQUETE_SOURCE_DES_BUGS_1_8_57.md` disait « 5 conversions gèrent la virgule, 11 non ». C'était **l'inverse** : 11 la géraient, 5 non. Les 16 passent maintenant par `NumberInput`. La conclusion de l'enquête ne change pas (deux façons de lire un nombre = deux copies d'une même règle).

---

## 4. Vérifications faites

| Vérification | Résultat |
|--------------|----------|
| Script des portails exécuté dans Node avec un joueur simulé debout sur le bloc | Téléporté ✓ |
| Code Studio exécuté dans Node (validation, génération, Annuler, découpage `.mcfunction`) | ✓ |
| JavaScript de Map Studio (`node --check`) | Syntaxe valide ✓ |
| 18 modèles d'os d'animation analysés comme JSON | 18/18 valides ✓ |
| Analyse lexicale Kotlin (chaînes, `${…}`, chaînes brutes) des 109 fichiers `.kt` | 0 erreur ✓ (l'analyseur détecte bien les erreurs injectées volontairement) |
| JSON des assets | valides ✓ |
| **Compilation Gradle** | ❌ **impossible ici** (réseau bloqué) |
| **Tests unitaires** (écrits, non exécutés) | à lancer : `./gradlew test` |

### Les tests ajoutés (`app/src/test/…`) — tous de type « aller-retour »
| Fichier | Ce qu'il vérifie |
|---------|------------------|
| `generator/PackVersioningTest` | La version augmente à chaque export (n° 3) |
| `generator/RecipePackJsonTest` | Une recette produit un JSON Bedrock correct (grille réduite, clés, four) (n° 4) |
| `workshop/PortalCodeTest` | Code généré → relu sans erreur → même portail (n° 6) ; copies uniques (n° 24) |
| `workshop/NbtStructureParserTest` | Fichier Java réel (size en liste), gzip, `.mcstructure` Bedrock, fichier corrompu (n° 9) |
| `data/ManualMergeAndSoundTest` | Import qui ne touche pas l'autre projet (n° 2), noms de sons arabes (n° 13), virgule (n° 19), taille de texture par forme (n° 12) |
| `animation/AnimationExportTest` | Dernière image clé = durée (n° 10), pattes des quadrupèdes et de l'araignée (n° 11) |
| `ai/AiOpenAiClientTest` | Lecture d'une réponse OpenAI brute (n° 16) |

`app/build.gradle.kts` : `testOptions.unitTests.isReturnDefaultValues = true` (les `Log` Android ne font plus échouer les tests JVM).

---

## 5. Fichiers touchés

**Nouveaux :** `texture/TextureSources.kt`, `generator/PackVersioning.kt`, `generator/RecipePackJson.kt`, `data/NumberInput.kt`, `NbtStructureParser.kt` (réécrit), 7 fichiers de tests.

**Modifiés :** `PackGenerator`, `AdvancedPackEngine`, `MobPackJson`, `SBhValidationEngine`, `SBhCommunicationCore`, `ManualUpdateImporter`, `MobEntity` (MobShapeCatalog), `SoundModels`, `SoundRepository`, `AudioOggConverter`, `UpdateManager`, `CharacterRepository`, `AnimationExport`, `AiOpenAiClient`, `FoundationGenerators`, `FoundationProject`, `FoundationTextures`, `MapEditorScreen`, `mapstudio.html`, `TextureScreen`, `UpdateScreen`, `MainActivity`, `WorkshopScreen`, `MobZone`, `BlockZone`, `ItemZone`, `RecipeZone`, `MapZone`, `PortalZone`, `WorkshopEditorScaffold`, `PlayableSceneBuilder`, `app/build.gradle.kts`, `version.json` ×2.

Le différentiel ligne par ligne est dans `SBhStudio_V1_8_58_depuis_1_8_57.diff`.

---

## 6. Prochaine étape : les tests réels

### 6.1 Avant Minecraft
```bash
./gradlew test            # les 7 classes de tests ci-dessus doivent passer
./gradlew assembleDebug   # puis installer l'APK
```
Si la compilation échoue, l'erreur ne peut venir que des fichiers de la section 5.

### 6.2 Dans Minecraft (activer « Journal de contenu » dans Paramètres → Créateur)
| # | Test | Résultat attendu | Bugs vérifiés |
|---|------|------------------|---------------|
| 1 | Mob avec un **skin de la bibliothèque** → Export | Export réussi, mob texturé en jeu | 1, 12 |
| 2 | Exporter → importer → modifier le mob → réexporter → réimporter | Minecraft remplace le pack (version 0.7.x+1), la modification est visible | 3 |
| 3 | Créer une recette en grille → exporter → table de craft | La recette apparaît et fonctionne | 4 |
| 4 | Créer un portail → poser le bloc → marcher dessus | Téléportation | 5, 35 |
| 5 | Une **araignée** et une **vache** avec animation liée | Texture en place, pattes qui bougent, pas d'à-coup | 10, 11, 12, 32 |
| 6 | Un nasheed au titre arabe + un autre → `/playsound` | Les deux sons sont distincts | 13 |
| 7 | Armure custom portée | Protection OK ; noter si elle est invisible | 34 |
| 8 | Activer **seulement** le pack de comportement | Les ressources s'activent automatiquement | 31 |
| 9 | Map Studio : exporter en `.mcfunction`, lancer la fonction dans le monde | La map se construit là où on est | 8, 27 |
| 10 | Journal de contenu après chaque import | Aucun avertissement rouge | tous |

Noter pour chaque test : OK / KO + la capture du journal de contenu. Ces résultats serviront à réparer les points restants (n° 30, 32, 34, 35).

---

## 7. Correctifs de compilation (premier build GitHub, 05/10 20:41)

Le premier vrai build sur GitHub (run n° 258) a signalé **2 erreurs de compilation**, toutes deux **présentes dès la V1.8.55 d'origine**. Cette version « stabilisation téléphone » n'avait donc jamais été compilée, ce que l'enquête soupçonnait.

| Erreur | Cause | Correctif |
|--------|-------|-----------|
| `MainActivity.kt:90` — *No value passed for parameter 'message'* | `SystemLog.e` attend (module, message, erreur), l'appel ne passait qu'un texte | Appel complété : `SystemLog.e("MainActivity", "…", throwable)` |
| `CharacterStudioZone.kt:194` — *Unresolved reference 'CharacterPreviewPanel'* | Composant appelé par l'atelier mais supprimé lors de la refonte 1.8.55 de l'aperçu 3D | `CharacterPreviewPanel` recréé dans `character/CharacterPreview3D.kt` : aperçu 3D (avec secours 2D) + nom et modèle du personnage |

Aucune erreur n'a été signalée dans les fichiers modifiés par les réparations 1.8.58.
