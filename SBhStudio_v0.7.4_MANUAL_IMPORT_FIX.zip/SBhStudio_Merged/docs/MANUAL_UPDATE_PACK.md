# Document de mise à jour manuel — Phase 1

Schéma : `sbh.studio.update.v1`

## Exemple minimal (version + notes)

```json
{
  "schema": "sbh.studio.update.v1",
  "versionCode": 19,
  "versionName": "0.7.5",
  "notes": "Patch contenu Al-Zahra — nouveaux PNJ"
}
```

## Exemple avec données AGW + atelier

```json
{
  "schema": "sbh.studio.update.v1",
  "versionCode": 19,
  "versionName": "0.7.5",
  "notes": "Lore enrichi + 2 créatures atelier",
  "agw": {
    "lore": {
      "world_name": { "fr": "Al-Zahra", "en": "Al-Zahra" },
      "tagline": { "fr": "Les dunes se souviennent.", "en": "The dunes remember." },
      "setting": { "fr": "…", "en": "…" },
      "core_promise": { "fr": "…", "en": "…" },
      "atmosphere": ["Pierre sombre", "Or sacré", "Brume nocturne"]
    },
    "heroes": {
      "player_role": { "fr": "Voyageur", "en": "Wanderer" },
      "npcs": [],
      "bosses": [],
      "creatures": [
        {
          "id": "sand_wraith",
          "name": { "fr": "Spectre des sables", "en": "Sand Wraith" },
          "biome": "desert",
          "role": "ambush"
        }
      ]
    }
  },
  "workshop": {
    "projectId": "global",
    "mobs": [
      {
        "projectId": "global",
        "nom": "Spectre des sables",
        "identifiant": "agw:sand_wraith",
        "vie": 24,
        "degats": 5,
        "hostile": true
      }
    ],
    "items": [],
    "blocks": []
  }
}
```

## Comportement

1. Choisir le fichier dans **Mises à jour → Import manuel**
2. Aperçu (validation)
3. **Assimiler** → backup local + écriture overrides AGW + fusion mobs/items/blocs
4. Diagnostic relancé automatiquement

Les données AGW importées sont lues en priorité depuis `filesDir/agw_override/` (sans modifier l’APK).
