package com.sbh.studio.data

import android.content.Context
import android.net.Uri
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Format du document de mise à jour manuelle (Phase 1).
 *
 * Fichier JSON type :
 * {
 *   "schema": "sbh.studio.update.v1",
 *   "versionCode": 19,
 *   "versionName": "0.7.5",
 *   "notes": "…",
 *   "agw": { "lore": {...}, "heroes": {...}, "factions": {...}, "phases": {...}, "project": {...} },
 *   "workshop": { "projectId": "global", "mobs": [...], "items": [...], "blocks": [...] }
 * }
 */
@Serializable
data class ManualUpdateManifest(
    val schema: String = SCHEMA_V1,
    val versionCode: Int? = null,
    val versionName: String? = null,
    val notes: String = "",
    val agw: ManualAgwSection? = null,
    val workshop: ManualWorkshopSection? = null
)

@Serializable
data class ManualAgwSection(
    val project: JsonElement? = null,
    val lore: JsonElement? = null,
    val heroes: JsonElement? = null,
    val factions: JsonElement? = null,
    val phases: JsonElement? = null
)

@Serializable
data class ManualWorkshopSection(
    val projectId: String = "global",
    val mobs: List<MobEntity> = emptyList(),
    val items: List<SbhItem> = emptyList(),
    val blocks: List<SbhBlock> = emptyList()
)

@Serializable
data class ManualUpdateMeta(
    val appliedAt: Long = 0L,
    val versionCode: Int? = null,
    val versionName: String? = null,
    val notes: String = "",
    val sourceName: String = "",
    val lines: List<String> = emptyList()
)

sealed class ManualImportResult {
    data class Success(val report: List<String>, val meta: ManualUpdateMeta) : ManualImportResult()
    data class Preview(val summary: List<String>, val manifest: ManualUpdateManifest, val raw: String) : ManualImportResult()
    data class Error(val message: String) : ManualImportResult()
}

const val SCHEMA_V1 = "sbh.studio.update.v1"

class ManualUpdateImporter(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        prettyPrint = true
        encodeDefaults = true
    }

    private val overrideDir get() = File(context.filesDir, "agw_override")
    private val backupDir get() = File(context.filesDir, "update_backups")
    private val metaFile get() = File(context.filesDir, "manual_update_meta.json")

    fun lastMeta(): ManualUpdateMeta? = try {
        if (!metaFile.exists()) null else json.decodeFromString(metaFile.readText())
    } catch (_: Exception) {
        null
    }

    fun readUriText(uri: Uri): String {
        context.contentResolver.openInputStream(uri)?.use { input ->
            return input.bufferedReader().use { it.readText() }
        } ?: throw IllegalStateException("Impossible de lire le fichier.")
    }

    /** Analyse sans écrire (aperçu). */
    fun preview(text: String): ManualImportResult {
        return try {
            val manifest = parseAndValidate(text)
            val summary = buildSummary(manifest)
            ManualImportResult.Preview(summary, manifest, text)
        } catch (e: Exception) {
            ManualImportResult.Error(e.message ?: "Document invalide")
        }
    }

    /** Applique le pack après validation + backup. */
    fun apply(text: String, sourceName: String = "import.json"): ManualImportResult {
        return try {
            val manifest = parseAndValidate(text)
            backupCurrentState()
            val report = mutableListOf<String>()

            // AGW overrides
            manifest.agw?.let { agw ->
                report += applyAgwOverrides(agw)
            }

            // Workshop merge
            manifest.workshop?.let { ws ->
                report += applyWorkshopMerge(ws)
            }

            if (report.isEmpty()) {
                report += "Aucune section de données à importer (seulement métadonnées version)."
            }

            val meta = ManualUpdateMeta(
                appliedAt = System.currentTimeMillis(),
                versionCode = manifest.versionCode,
                versionName = manifest.versionName,
                notes = manifest.notes,
                sourceName = sourceName,
                lines = report
            )
            atomicWrite(metaFile, json.encodeToString(meta))

            // Optionnel : noter la version pack separement (n'ecrase pas BuildConfig)
            manifest.versionCode?.let { code ->
                val stampObj = kotlinx.serialization.json.buildJsonObject {
                    put("packVersionCode", kotlinx.serialization.json.JsonPrimitive(code))
                    put("packVersionName", kotlinx.serialization.json.JsonPrimitive(manifest.versionName ?: ""))
                    put("notes", kotlinx.serialization.json.JsonPrimitive(manifest.notes))
                    put("appliedAt", kotlinx.serialization.json.JsonPrimitive(meta.appliedAt))
                }
                atomicWrite(
                    File(context.filesDir, "manual_pack_version.json"),
                    json.encodeToString(kotlinx.serialization.json.JsonObject.serializer(), stampObj)
                )
            }

            ManualImportResult.Success(report, meta)
        } catch (e: Exception) {
            ManualImportResult.Error(e.message ?: "Échec de l'assimilation")
        }
    }

    private fun parseAndValidate(text: String): ManualUpdateManifest {
        if (text.isBlank()) throw IllegalArgumentException("Fichier vide.")
        val root = try {
            json.parseToJsonElement(text).jsonObject
        } catch (_: Exception) {
            throw IllegalArgumentException("JSON invalide — le document doit être un objet JSON.")
        }

        val schema = root["schema"]?.jsonPrimitive?.contentOrNull
        if (schema != null && schema != SCHEMA_V1) {
            throw IllegalArgumentException("Schéma non supporté : $schema (attendu $SCHEMA_V1).")
        }

        // Au moins une section utile ou version
        val hasVersion = root["versionCode"] != null || root["versionName"] != null
        val hasAgw = root["agw"] is JsonObject
        val hasWs = root["workshop"] is JsonObject
        if (!hasVersion && !hasAgw && !hasWs) {
            throw IllegalArgumentException(
                "Document incomplet. Fournissez versionCode/versionName et/ou une section agw / workshop."
            )
        }

        return json.decodeFromString(text)
    }

    private fun buildSummary(m: ManualUpdateManifest): List<String> {
        val lines = mutableListOf<String>()
        lines += "Schéma : ${m.schema.ifBlank { SCHEMA_V1 }}"
        if (m.versionName != null || m.versionCode != null) {
            lines += "Version pack : ${m.versionName ?: "?"} (code ${m.versionCode ?: "?"})"
        }
        if (m.notes.isNotBlank()) lines += "Notes : ${m.notes.take(120)}"
        m.agw?.let { a ->
            val parts = mutableListOf<String>()
            if (a.project != null) parts += "project"
            if (a.lore != null) parts += "lore"
            if (a.heroes != null) parts += "heroes"
            if (a.factions != null) parts += "factions"
            if (a.phases != null) parts += "phases"
            lines += "AGW : ${if (parts.isEmpty()) "section vide" else parts.joinToString()}"
        }
        m.workshop?.let { w ->
            lines += "Atelier (projet ${w.projectId}) : ${w.mobs.size} mobs, ${w.items.size} items, ${w.blocks.size} blocs"
        }
        lines += "Une sauvegarde locale sera créée avant application."
        return lines
    }

    private fun backupCurrentState() {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dir = File(backupDir, stamp)
        dir.mkdirs()
        // Backup AGW overrides existants
        if (overrideDir.exists()) {
            overrideDir.listFiles()?.forEach { f ->
                f.copyTo(File(dir, "agw_${f.name}"), overwrite = true)
            }
        }
        // Backup workshop data
        listOf("sbh_mobs.json", "sbh_items.json", "sbh_blocks.json", "manual_update_meta.json").forEach { name ->
            val f = File(context.filesDir, name)
            if (f.exists()) f.copyTo(File(dir, name), overwrite = true)
        }
        // Keep only last 8 backups
        backupDir.listFiles()?.sortedByDescending { it.name }?.drop(8)?.forEach { it.deleteRecursively() }
    }

    private fun applyAgwOverrides(agw: ManualAgwSection): List<String> {
        overrideDir.mkdirs()
        val report = mutableListOf<String>()
        fun write(name: String, element: JsonElement?) {
            if (element == null) return
            // Validate by attempting typed decode when possible
            val text = element.toString()
            when (name) {
                "project.json" -> json.decodeFromString<AgwProject>(text)
                "lore.json" -> json.decodeFromString<AgwLore>(text)
                "heroes.json" -> json.decodeFromString<AgwHeroes>(text)
                "factions.json" -> {
                    // Accept either {factions:[...]} or raw array wrapped
                    try {
                        json.decodeFromString<AgwFactionsFile>(text)
                    } catch (_: Exception) {
                        // try wrap
                        val wrapped = """{"factions":$text}"""
                        json.decodeFromString<AgwFactionsFile>(wrapped)
                        atomicWrite(File(overrideDir, name), json.encodeToString(json.parseToJsonElement(wrapped)))
                        report += "AGW $name importé (tableau enveloppé)."
                        return
                    }
                }
                "phases.json" -> {
                    try {
                        json.decodeFromString<AgwPhasesFile>(text)
                    } catch (_: Exception) {
                        val wrapped = """{"phases":$text}"""
                        json.decodeFromString<AgwPhasesFile>(wrapped)
                        atomicWrite(File(overrideDir, name), json.encodeToString(json.parseToJsonElement(wrapped)))
                        report += "AGW $name importé (tableau enveloppé)."
                        return
                    }
                }
            }
            atomicWrite(File(overrideDir, name), text)
            report += "AGW $name importé / mis à jour."
        }
        write("project.json", agw.project)
        write("lore.json", agw.lore)
        write("heroes.json", agw.heroes)
        write("factions.json", agw.factions)
        write("phases.json", agw.phases)
        return report
    }

    private fun applyWorkshopMerge(ws: ManualWorkshopSection): List<String> {
        val report = mutableListOf<String>()
        val pid = ws.projectId.ifBlank { "global" }
        val mobRepo = MobRepository(context)
        val itemRepo = ItemRepository(context)
        val blockRepo = BlockRepository(context)

        if (ws.mobs.isNotEmpty()) {
            val existing = mobRepo.loadAll()
            val incoming = ws.mobs.map { m ->
                if (m.projectId.isBlank()) m.copy(projectId = pid) else m
            }
            val byId = existing.associateBy { it.identifiant }.toMutableMap()
            var added = 0
            var updated = 0
            incoming.forEach { m ->
                if (byId.containsKey(m.identifiant)) updated++ else added++
                byId[m.identifiant] = m
            }
            mobRepo.saveAll(byId.values.toList())
            report += "Mobs : +$added ajoutés, $updated mis à jour (total ${byId.size})."
        }
        if (ws.items.isNotEmpty()) {
            val existing = itemRepo.loadAll()
            val incoming = ws.items.map { if (it.projectId.isBlank()) it.copy(projectId = pid) else it }
            val byId = existing.associateBy { it.identifier }.toMutableMap()
            var added = 0
            var updated = 0
            incoming.forEach { m ->
                if (byId.containsKey(m.identifier)) updated++ else added++
                byId[m.identifier] = m
            }
            itemRepo.saveAll(byId.values.toList())
            report += "Items : +$added ajoutés, $updated mis à jour (total ${byId.size})."
        }
        if (ws.blocks.isNotEmpty()) {
            val existing = blockRepo.loadAll()
            val incoming = ws.blocks.map { if (it.projectId.isBlank()) it.copy(projectId = pid) else it }
            val byId = existing.associateBy { it.identifier }.toMutableMap()
            var added = 0
            var updated = 0
            incoming.forEach { m ->
                if (byId.containsKey(m.identifier)) updated++ else added++
                byId[m.identifier] = m
            }
            blockRepo.saveAll(byId.values.toList())
            report += "Blocs : +$added ajoutés, $updated mis à jour (total ${byId.size})."
        }
        return report
    }

    /** Chemin override AGW si présent (utilisé par AgwDataRepository). */
    fun overrideFile(name: String): File? {
        val f = File(overrideDir, name)
        return if (f.exists()) f else null
    }
}
