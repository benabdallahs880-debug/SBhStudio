# SBh Studio 0.4.0

## Nouveautés 0.4.0 — Mises à jour directement depuis l'app
- Nouvelle page **"Mises à jour"** (bouton en haut à droite de l'accueil) : vérifie, télécharge et installe la dernière version sans passer par GitHub à la main.
- L'app compare sa version au fichier `version.json` publié à la racine du dépôt (lu directement, aucune connexion à un compte nécessaire puisque le dépôt est public).
- Le workflow GitHub Actions publie désormais automatiquement une **Release "latest"** contenant l'APK à un lien stable (`.../releases/download/latest/app-debug.apk`) à chaque build réussi.
- ⚠️ Le nouveau code doit quand même être poussé sur GitHub par un moyen ou un autre (édition de fichiers sur github.com, ordinateur, etc.) pour que cette page ait quelque chose de neuf à proposer — elle simplifie l'installation, pas l'envoi du code.
- ⚠️ **Important à chaque nouvelle version publiée manuellement :** mettre à jour `version.json` à la racine (versionCode/versionName) en même temps que `app/build.gradle.kts`, sinon la page "Mises à jour" ne détectera rien de neuf.

Socle Android natif de **SBh Studio**.

## Objectifs de cette base
- vraie application Android, pas une page web
- écran d'accueil
- création de projets
- stockage local persistant (JSON, stockage interne de l'app)
- historique de versions par projet
- point d'entrée pour tests normal/dégradé/catastrophe
- version applicative explicite pour préparer les mises à jour

## Nouveautés 0.2.0
- Les projets sont maintenant **sauvegardés sur l'appareil** (fichier JSON dans le stockage interne) : ils survivent à la fermeture de l'app.
- Le bouton **Sauvegarder** persiste réellement l'état du projet et ajoute une entrée d'historique.
- Le bouton **Versions** ouvre une fenêtre listant l'historique réel du projet (au lieu d'un simple message).
- Nouveau fichier `data/ProjectRepository.kt` : couche de persistance isolée, prête à être remplacée par une base Room si le volume de données grandit.
- **Mises à jour sans perte de données** : un keystore de debug fixe (`app/debug.keystore`) est maintenant versionné dans le dépôt et utilisé par tous les builds GitHub Actions. Sans ça, chaque build aurait une signature différente et Android aurait refusé d'installer une nouvelle APK par-dessus l'ancienne — ce qui aurait obligé à désinstaller d'abord, et donc à perdre tous les projets.

## Nouveautés 0.3.0 — Créateur de créatures
- Premier module de création de contenu réel, inspiré de l'`EntityEditor`/`NatureEditor` observé dans AddonStudio (analyse d'un rapport technique tiers), adapté à notre style : formulaire nom/identifiant/vie/vitesse/dégâts, cases à cocher comportement (hostile, poursuite, attaque, réaction aux dégâts) et pouvoirs (vitesse, résistance, invisibilité) — repris directement de l'exemple "Z-01" du cahier des charges.
- Vraie navigation à trois écrans : Accueil → Détail du projet ("Créatures") → Éditeur de créature.
- Persistance JSON dédiée (`data/MobEntity.kt` + `data/MobRepository.kt`), séparée des projets, avec historique de versions par créature.
- Modifier/Supprimer une créature existante fonctionne réellement (pas de placeholder).

## Comment mettre à jour l'application sur ton téléphone
Tant que tu gardes le même dépôt et le même `app/debug.keystore` :
1. Remplace les fichiers modifiés dans ton dépôt GitHub par les nouveaux
2. Relance le workflow **Build APK** (Actions → Run workflow)
3. Télécharge la nouvelle APK et installe-la **directement par-dessus l'ancienne**, sans désinstaller
4. Android la reconnaît comme une mise à jour (même `applicationId`, même signature, `versionCode` supérieur) et **garde tes projets sauvegardés**

⚠️ Si tu perds ou régénères un jour `app/debug.keystore`, la chaîne se casse : il faudra désinstaller l'ancienne app avant d'installer la nouvelle, et tu perdras les projets stockés localement. Garde ce fichier précieusement.

## Version
**0.2.0** / versionCode 2

## Comment obtenir l'APK (depuis un téléphone)

### Méthode recommandée : GitHub Actions

1. Crée un compte GitHub (si tu n’en as pas) → https://github.com
2. Crée un **nouveau dépôt** (New repository) → nomme-le par exemple `SBhStudio`
3. Uploade **tous les fichiers** de ce dossier dans le dépôt (tu peux utiliser l’interface web de GitHub depuis le téléphone)
4. Va dans l’onglet **Actions** du dépôt
5. Clique sur le workflow **Build APK** → **Run workflow**
6. Attends 2-4 minutes
7. Une fois terminé, clique sur le run → section **Artifacts** → télécharge **SBhStudio-debug**
8. Dézippe le fichier et installe l’APK sur ton téléphone (autorise les sources inconnues)

### Prochaine construction
1. ~~stockage persistant des projets~~ ✅ fait en 0.2.0
2. sauvegarde automatique + restauration (actuellement manuelle via le bouton)
3. export/import de projet
4. laboratoire de tests réel
5. moteur BP/RP Minecraft
6. Mine Edit
7. créateurs textures/items/blocs/mobs
8. système d'update signé et rollback

## Construction locale (ordinateur)
Le projet nécessite un environnement Android/Gradle avec SDK Android 35.
```bash
./gradlew assembleDebug
```
L’APK se trouve ensuite dans : `app/build/outputs/apk/debug/`
