package com.sbh.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.ProjectRepository
import com.sbh.studio.data.SbhProject
import com.sbh.studio.ui.UpdateScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SbhStudioApp() }
    }
}

private fun defaultProjects() = listOf(
    SbhProject(name = "SBh Test 01", version = "0.1.0", status = "Prêt"),
    SbhProject(name = "Laboratoire Z-01", version = "0.1.0", status = "Brouillon")
)

private sealed class Screen {
    data object Home : Screen()
    data class ProjectDetail(val projectId: String) : Screen()
    data class MobEditor(val projectId: String, val mobId: String?) : Screen()
    data object Update : Screen()
}

@OptIn(ExperimentalMaterial3Api::class)
@androidx.compose.runtime.Composable
private fun SbhStudioApp() {
    val context = LocalContext.current
    val projectRepo = remember { ProjectRepository(context.applicationContext) }
    val mobRepo = remember { MobRepository(context.applicationContext) }

    var projects by remember {
        val stored = projectRepo.load()
        mutableStateOf(if (stored.isEmpty()) defaultProjects() else stored)
    }
    var mobs by remember { mutableStateOf(mobRepo.loadAll()) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var message by remember { mutableStateOf("SBh Studio est prêt.") }
    var historyTarget by remember { mutableStateOf<SbhProject?>(null) }

    fun persistProjects(updated: List<SbhProject>) {
        projects = updated
        projectRepo.save(updated)
    }

    fun persistMobs(updated: List<MobEntity>) {
        mobs = updated
        mobRepo.saveAll(updated)
    }

    MaterialTheme {
        when (val current = screen) {
            is Screen.Home -> HomeScreen(
                projects = projects,
                message = message,
                onNewProject = {
                    val n = projects.size + 1
                    val newProject = SbhProject(name = "Nouveau projet $n", version = "0.1.0", status = "Brouillon")
                    persistProjects(projects + newProject)
                    message = "Projet créé et sauvegardé."
                },
                onTest = { message = "Contrôle : aucun défaut simulé dans cette base." },
                onSaveProject = { project ->
                    val entry = "v${project.versionHistory.size + 1} — sauvegarde manuelle"
                    val updated = project.copy(status = "Sauvegardé", versionHistory = project.versionHistory + entry)
                    persistProjects(projects.map { if (it.id == project.id) updated else it })
                    message = "${project.name} sauvegardé sur l'appareil."
                },
                onShowHistory = { historyTarget = it },
                onOpenProject = { screen = Screen.ProjectDetail(it.id) },
                onOpenUpdates = { screen = Screen.Update }
            )

            is Screen.Update -> UpdateScreen(onBack = { screen = Screen.Home })

            is Screen.ProjectDetail -> {
                val project = projects.find { it.id == current.projectId }
                if (project == null) {
                    screen = Screen.Home
                } else {
                    ProjectDetailScreen(
                        project = project,
                        mobs = mobs.filter { it.projectId == project.id },
                        onBack = { screen = Screen.Home },
                        onNewMob = { screen = Screen.MobEditor(project.id, null) },
                        onEditMob = { mob -> screen = Screen.MobEditor(project.id, mob.id) },
                        onDeleteMob = { mob -> persistMobs(mobs - mob) }
                    )
                }
            }

            is Screen.MobEditor -> {
                val existing = current.mobId?.let { id -> mobs.find { it.id == id } }
                MobEditorScreen(
                    projectId = current.projectId,
                    existing = existing,
                    onCancel = { screen = Screen.ProjectDetail(current.projectId) },
                    onSave = { mob ->
                        val updated = if (existing == null) mobs + mob
                        else mobs.map { if (it.id == mob.id) mob else it }
                        persistMobs(updated)
                        screen = Screen.ProjectDetail(current.projectId)
                    }
                )
            }
        }
    }

    historyTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { historyTarget = null },
            confirmButton = { TextButton(onClick = { historyTarget = null }) { Text("Fermer") } },
            title = { Text("Historique — ${target.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    target.versionHistory.forEach { entry -> Text(entry) }
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(
    projects: List<SbhProject>,
    message: String,
    onNewProject: () -> Unit,
    onTest: () -> Unit,
    onSaveProject: (SbhProject) -> Unit,
    onShowHistory: (SbhProject) -> Unit,
    onOpenProject: (SbhProject) -> Unit,
    onOpenUpdates: () -> Unit
) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("SBh Studio 0.4.0") },
            actions = {
                TextButton(onClick = onOpenUpdates) { Text("Mises à jour") }
            }
        )
    }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Fondation Android", style = MaterialTheme.typography.headlineSmall)
            Text("Gestion de projets, créatures et stockage local persistant.")

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onNewProject) { Text("+ Nouveau projet") }
                OutlinedButton(onClick = onTest) { Text("Tester") }
            }

            Text(message, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                items(projects, key = { it.id }) { project ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(project.name, style = MaterialTheme.typography.titleMedium)
                            Text("Version ${project.version} • ${project.status}")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { onSaveProject(project) }) { Text("Sauvegarder") }
                                OutlinedButton(onClick = { onShowHistory(project) }) { Text("Versions") }
                                Button(onClick = { onOpenProject(project) }) { Text("Créatures") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProjectDetailScreen(
    project: SbhProject,
    mobs: List<MobEntity>,
    onBack: () -> Unit,
    onNewMob: () -> Unit,
    onEditMob: (MobEntity) -> Unit,
    onDeleteMob: (MobEntity) -> Unit
) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(project.name) },
            navigationIcon = { TextButton(onClick = onBack) { Text("←") } }
        )
    }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Créatures", style = MaterialTheme.typography.headlineSmall)
            Button(onClick = onNewMob) { Text("+ Nouvelle créature") }

            if (mobs.isEmpty()) {
                Text("Aucune créature pour l'instant.", style = MaterialTheme.typography.bodyMedium)
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                items(mobs, key = { it.id }) { mob ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(mob.nom, style = MaterialTheme.typography.titleMedium)
                            Text(mob.identifiant, style = MaterialTheme.typography.bodySmall)
                            Text("Vie ${mob.vie} • Vitesse ${mob.vitesse} • Dégâts ${mob.degats}")
                            val comportements = buildList {
                                if (mob.hostile) add("hostile")
                                if (mob.poursuite) add("poursuite")
                                if (mob.attaque) add("attaque")
                                if (mob.reactionDegats) add("réaction aux dégâts")
                            }
                            if (comportements.isNotEmpty()) Text("Comportement : ${comportements.joinToString(", ")}")
                            val pouvoirs = buildList {
                                if (mob.pouvoirVitesse) add("vitesse")
                                if (mob.pouvoirResistance) add("résistance")
                                if (mob.pouvoirInvisibilite) add("invisibilité")
                            }
                            if (pouvoirs.isNotEmpty()) Text("Pouvoirs : ${pouvoirs.joinToString(", ")}")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { onEditMob(mob) }) { Text("Modifier") }
                                OutlinedButton(onClick = { onDeleteMob(mob) }) { Text("Supprimer") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MobEditorScreen(
    projectId: String,
    existing: MobEntity?,
    onCancel: () -> Unit,
    onSave: (MobEntity) -> Unit
) {
    var nom by remember { mutableStateOf(existing?.nom ?: "") }
    var identifiant by remember { mutableStateOf(existing?.identifiant ?: "sbh:nouvelle_creature") }
    var vie by remember { mutableStateOf((existing?.vie ?: 20).toString()) }
    var vitesse by remember { mutableStateOf((existing?.vitesse ?: 0.25).toString()) }
    var degats by remember { mutableStateOf((existing?.degats ?: 3).toString()) }
    var hostile by remember { mutableStateOf(existing?.hostile ?: false) }
    var poursuite by remember { mutableStateOf(existing?.poursuite ?: false) }
    var attaque by remember { mutableStateOf(existing?.attaque ?: false) }
    var reactionDegats by remember { mutableStateOf(existing?.reactionDegats ?: true) }
    var pouvoirVitesse by remember { mutableStateOf(existing?.pouvoirVitesse ?: false) }
    var pouvoirResistance by remember { mutableStateOf(existing?.pouvoirResistance ?: false) }
    var pouvoirInvisibilite by remember { mutableStateOf(existing?.pouvoirInvisibilite ?: false) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (existing == null) "Nouvelle créature" else "Modifier ${existing.nom}") },
            navigationIcon = { TextButton(onClick = onCancel) { Text("←") } }
        )
    }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(value = nom, onValueChange = { nom = it }, label = { Text("Nom") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = identifiant, onValueChange = { identifiant = it }, label = { Text("Identifiant (namespace:id)") }, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = vie, onValueChange = { vie = it }, label = { Text("Vie") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = vitesse, onValueChange = { vitesse = it }, label = { Text("Vitesse") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = degats, onValueChange = { degats = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f))
            }

            Text("Comportement", style = MaterialTheme.typography.titleSmall)
            CheckboxRow("Hostile", hostile) { hostile = it }
            CheckboxRow("Poursuite", poursuite) { poursuite = it }
            CheckboxRow("Attaque", attaque) { attaque = it }
            CheckboxRow("Réaction aux dégâts", reactionDegats) { reactionDegats = it }

            Text("Pouvoirs", style = MaterialTheme.typography.titleSmall)
            CheckboxRow("Vitesse", pouvoirVitesse) { pouvoirVitesse = it }
            CheckboxRow("Résistance", pouvoirResistance) { pouvoirResistance = it }
            CheckboxRow("Invisibilité", pouvoirInvisibilite) { pouvoirInvisibilite = it }

            Spacer(Modifier.height(8.dp))

            Button(onClick = {
                if (nom.isBlank()) return@Button
                val mob = MobEntity(
                    id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                    projectId = projectId,
                    nom = nom,
                    identifiant = identifiant,
                    vie = vie.toIntOrNull() ?: 20,
                    vitesse = vitesse.toDoubleOrNull() ?: 0.25,
                    degats = degats.toIntOrNull() ?: 3,
                    hostile = hostile,
                    poursuite = poursuite,
                    attaque = attaque,
                    reactionDegats = reactionDegats,
                    pouvoirVitesse = pouvoirVitesse,
                    pouvoirResistance = pouvoirResistance,
                    pouvoirInvisibilite = pouvoirInvisibilite,
                    versionHistory = (existing?.versionHistory ?: emptyList()) +
                        "v${(existing?.versionHistory?.size ?: 0) + 1} — ${if (existing == null) "création" else "modification"}"
                )
                onSave(mob)
            }) { Text("Enregistrer la créature") }
        }
    }
}

@Composable
private fun CheckboxRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text(label)
    }
}
