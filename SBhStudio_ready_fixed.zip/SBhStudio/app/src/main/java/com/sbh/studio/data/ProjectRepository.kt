package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

@Serializable
data class SbhProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val version: String,
    val status: String,
    val versionHistory: List<String> = listOf("v1 — création du projet")
)

private val json = Json {
    prettyPrint = true
    ignoreUnknownKeys = true
}

/**
 * Persistance simple en JSON dans le stockage interne de l'app.
 * Suffisant pour la v0.2.0 ; migrable vers une base Room plus tard
 * sans changer l'API publique (load/save).
 */
class ProjectRepository(private val context: Context) {

    private val storageFile: File
        get() = File(context.filesDir, "sbh_projects.json")

    fun load(): List<SbhProject> {
        val file = storageFile
        if (!file.exists()) return emptyList()
        return try {
            json.decodeFromString(file.readText())
        } catch (e: Exception) {
            // Fichier corrompu ou format incompatible : on repart propre
            // plutôt que de faire planter l'app au démarrage.
            emptyList()
        }
    }

    fun save(projects: List<SbhProject>) {
        storageFile.writeText(json.encodeToString(projects))
    }
}
