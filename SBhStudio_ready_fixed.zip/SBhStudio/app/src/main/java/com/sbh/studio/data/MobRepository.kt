package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

private val mobJson = Json {
    prettyPrint = true
    ignoreUnknownKeys = true
}

/**
 * Persistance JSON des créatures, toutes dans un seul fichier
 * (filtrage par projectId côté appelant). Suffisant tant que le
 * volume reste raisonnable ; migrable vers un fichier par projet
 * si un jour un projet contient des centaines de créatures.
 */
class MobRepository(private val context: Context) {

    private val storageFile: File
        get() = File(context.filesDir, "sbh_mobs.json")

    fun loadAll(): List<MobEntity> {
        val file = storageFile
        if (!file.exists()) return emptyList()
        return try {
            mobJson.decodeFromString(file.readText())
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun loadForProject(projectId: String): List<MobEntity> =
        loadAll().filter { it.projectId == projectId }

    fun saveAll(mobs: List<MobEntity>) {
        storageFile.writeText(mobJson.encodeToString(mobs))
    }
}
