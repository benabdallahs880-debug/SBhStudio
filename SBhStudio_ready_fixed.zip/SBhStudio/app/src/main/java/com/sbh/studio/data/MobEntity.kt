package com.sbh.studio.data

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class MobEntity(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val nom: String,
    val identifiant: String,
    val vie: Int = 20,
    val vitesse: Double = 0.25,
    val degats: Int = 3,
    val hostile: Boolean = false,
    val poursuite: Boolean = false,
    val attaque: Boolean = false,
    val reactionDegats: Boolean = true,
    val pouvoirVitesse: Boolean = false,
    val pouvoirResistance: Boolean = false,
    val pouvoirInvisibilite: Boolean = false,
    val versionHistory: List<String> = listOf("v1 — création de la créature")
)
