package com.sbh.studio.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * URL brute (raw.githubusercontent.com) de version.json à la racine du dépôt.
 * Un dépôt public n'a besoin d'aucune authentification pour être lu ainsi.
 */
private const val VERSION_JSON_URL =
    "https://raw.githubusercontent.com/benabdallahs880-debug/SBhStudio/main/version.json"

private val json = Json { ignoreUnknownKeys = true }

sealed class UpdateCheckResult {
    data class UpdateAvailable(val info: UpdateInfo) : UpdateCheckResult()
    data object UpToDate : UpdateCheckResult()
    data class Error(val message: String) : UpdateCheckResult()
}

sealed class DownloadState {
    data object Idle : DownloadState()
    data object Downloading : DownloadState()
    data class ReadyToInstall(val apkFile: File) : DownloadState()
    data class Failed(val message: String) : DownloadState()
}

class UpdateManager(private val context: Context) {

    /** Doit être appelé depuis une coroutine (contexte IO géré en interne). */
    suspend fun checkForUpdate(currentVersionCode: Int): UpdateCheckResult = withContext(Dispatchers.IO) {
        try {
            val connection = URL(VERSION_JSON_URL).openConnection() as HttpURLConnection
            connection.connectTimeout = 8000
            connection.readTimeout = 8000
            connection.requestMethod = "GET"
            val code = connection.responseCode
            if (code != 200) {
                return@withContext UpdateCheckResult.Error("Serveur a répondu $code")
            }
            val body = connection.inputStream.bufferedReader().readText()
            val info = json.decodeFromString<UpdateInfo>(body)
            if (info.versionCode > currentVersionCode) {
                UpdateCheckResult.UpdateAvailable(info)
            } else {
                UpdateCheckResult.UpToDate
            }
        } catch (e: Exception) {
            UpdateCheckResult.Error(e.message ?: "Erreur réseau inconnue")
        }
    }

    /**
     * Lance le téléchargement via DownloadManager (gère la barre de progression
     * système, la reprise, etc. sans code supplémentaire). Le résultat doit être
     * suivi via un BroadcastReceiver sur ACTION_DOWNLOAD_COMPLETE côté appelant,
     * ou en pollant queryDownloadStatus.
     */
    fun startDownload(apkUrl: String): Long {
        val updatesDir = File(context.getExternalFilesDir(null), "updates")
        if (!updatesDir.exists()) updatesDir.mkdirs()
        val destFile = File(updatesDir, "sbh-studio-update.apk")
        if (destFile.exists()) destFile.delete()

        val request = DownloadManager.Request(Uri.parse(apkUrl))
            .setTitle("SBh Studio — mise à jour")
            .setDestinationUri(Uri.fromFile(destFile))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)

        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return dm.enqueue(request)
    }

    fun apkFile(): File =
        File(File(context.getExternalFilesDir(null), "updates"), "sbh-studio-update.apk")

    /** À appeler une fois le téléchargement terminé pour lancer l'installation système. */
    fun installApk(apkFile: File) {
        val uri = FileProvider.getUriForFile(context, "com.sbh.studio.fileprovider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
