package com.sbh.studio.workshop

import android.util.Log

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sbh.studio.data.BlockRepository
import com.sbh.studio.data.AgwDataRepository
import com.sbh.studio.data.AgwWorldCoreState
import com.sbh.studio.data.AgwWorldCoreRepository
import com.sbh.studio.data.ItemRepository
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.ReclamationPresets
import com.sbh.studio.data.PracticePresets
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.generator.AdvancedPackEngine
import com.sbh.studio.foundation.SBhWorldFoundation
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AgwDecor
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.ModeIconChip
import com.sbh.studio.ui.ModeIconTile
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.SectionTitle
import com.sbh.studio.ui.GoldDivider
import com.sbh.studio.data.SoundRepository
import com.sbh.studio.character.CharacterProject
import com.sbh.studio.character.CharacterRepository
import com.sbh.studio.data.SbhSound
import com.sbh.studio.data.SoundEvents
import com.sbh.studio.texture.TextureRepository
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.creature.CreatureBodyMapping
import com.sbh.studio.creature.CreatureBodyStore
import com.sbh.studio.creature.CreatureEditorDialog
import com.sbh.studio.mesh.MeshEditorDialog
import com.sbh.studio.mesh.MeshInfo
import com.sbh.studio.mesh.MeshStore
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private data class WorkshopBootData(
    val portals: List<PortalBlueprint>,
    val maps: List<MapBlueprint>,
    val mobs: List<MobEntity>,
    val items: List<SbhItem>,
    val blocks: List<SbhBlock>,
    val recipes: List<RecipeBlueprint>,
    val entities: List<SceneEntity>,
    val characterProjects: List<CharacterProject>,
    val gameBlueprints: List<GameProjectBlueprint>,
    val gameTemplates: List<GameBuilderTemplate>,
    val textures: List<TextureProject>,
    val sounds: List<SbhSound>,
    val agwWorld: AgwWorldCoreState
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkshopScreen(
    project: SbhProject?,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    /** V1.8.61 : ouvre Map Studio sur une map de l'Atelier (null = dernière map) avec une action éventuelle. */
    onOpenMapEditor: (mapId: String?, action: String?) -> Unit = { _, _ -> },
    onOpenAnimation: (mobId: String?) -> Unit = {},
    /** V1.8.63 : zone ouverte en arrivant (ex. Accueil → Animation = Créatures). */
    initialZone: WorkshopZoneId? = null,
    /** Appelé une fois la zone de départ appliquée (le retour suivant dans l'Atelier repart du Hub). */
    onInitialZoneUsed: () -> Unit = {},
    allProjects: List<SbhProject> = emptyList(),
    onSelectProject: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val repo = remember { WorkshopRepository(context) }
    val characterRepo = remember { CharacterRepository(context) }
    val agwRepo = remember { AgwDataRepository(context) }
    val worldCoreRepo = remember { AgwWorldCoreRepository(context) }
    val mobRepo = remember { MobRepository(context) }
    val itemRepo = remember { ItemRepository(context) }
    val blockRepo = remember { BlockRepository(context) }
    val engine = remember { AdvancedPackEngine(context) }

    var zone by remember { mutableStateOf(initialZone ?: WorkshopZoneId.HUB) }
    LaunchedEffect(Unit) { if (initialZone != null) onInitialZoneUsed() }
    var selectedVisualId by remember { mutableStateOf<String?>(null) }
    var showEditor3D by remember { mutableStateOf(false) }
    // V1.8.62 : zone unique « Créatures » (Monstres + Entités 3D + Character Studio)
    var creatureFilter by remember { mutableStateOf(CreatureFilter.ALL) }
    var previewKind by remember { mutableStateOf(CreatureKind.MOB) }
    var bodyVersion by remember { mutableStateOf(0) }
    var bodyRequest by remember { mutableStateOf<BodyRequest?>(null) }
    // V1.8.65 : Modeleur 3D (maillages .glb) — (projet, id, nom de départ) du maillage ouvert
    var meshEditing by remember { mutableStateOf<Triple<String, String, String>?>(null) }
    var meshVersion by remember { mutableStateOf(0) }
    var meshes by remember { mutableStateOf(emptyList<MeshInfo>()) }
    var portals by remember { mutableStateOf(emptyList<PortalBlueprint>()) }
    var maps by remember { mutableStateOf(emptyList<MapBlueprint>()) }
    var mobs by remember { mutableStateOf(emptyList<MobEntity>()) }
    var items by remember { mutableStateOf(emptyList<SbhItem>()) }
    var blocks by remember { mutableStateOf(emptyList<SbhBlock>()) }
    var recipes by remember { mutableStateOf(emptyList<RecipeBlueprint>()) }
    var entities by remember { mutableStateOf(emptyList<SceneEntity>()) }
    var characterProjects by remember { mutableStateOf(emptyList<CharacterProject>()) }
    val gameBuilderRepo = remember { GameBuilderRepository(context) }
    var gameBlueprints by remember { mutableStateOf(emptyList<GameProjectBlueprint>()) }
    var gameTemplates by remember { mutableStateOf(emptyList<GameBuilderTemplate>()) }
    val texRepo = remember { TextureRepository(context) }
    var textures by remember { mutableStateOf(emptyList<TextureProject>()) }
    val soundRepo = remember { SoundRepository(context) }
    var sounds by remember { mutableStateOf(emptyList<SbhSound>()) }
    var reportText by remember { mutableStateOf("") }
    var lastExport by remember { mutableStateOf<File?>(null) }
    var agwWorld by remember { mutableStateOf(AgwWorldCoreState()) }
    var workshopDataReady by remember { mutableStateOf(false) }
    val workshopScope = rememberCoroutineScope()

    val projectId = project?.id ?: "global"

    // Charge les données atelier hors thread UI (évite ANR au démarrage téléphone)
    LaunchedEffect(Unit) {
        val loaded = withContext(Dispatchers.IO) {
            WorkshopBootData(
                portals = repo.loadPortals(),
                maps = repo.loadMaps(),
                mobs = mobRepo.loadAll(),
                items = itemRepo.loadAll(),
                blocks = blockRepo.loadAll(),
                recipes = repo.loadRecipes(),
                entities = repo.loadEntities(),
                characterProjects = characterRepo.loadAll(),
                gameBlueprints = gameBuilderRepo.loadAll(),
                gameTemplates = gameBuilderRepo.loadTemplates(),
                textures = texRepo.loadAll(),
                sounds = soundRepo.loadAll(),
                agwWorld = worldCoreRepo.load()
            )
        }
        portals = loaded.portals
        maps = loaded.maps
        mobs = loaded.mobs
        items = loaded.items
        blocks = loaded.blocks
        recipes = loaded.recipes
        entities = loaded.entities
        characterProjects = loaded.characterProjects
        gameBlueprints = loaded.gameBlueprints
        gameTemplates = loaded.gameTemplates
        textures = loaded.textures
        sounds = loaded.sounds
        agwWorld = loaded.agwWorld
        workshopDataReady = true
    }
    LaunchedEffect(projectId, maps, portals, workshopDataReady) {
        if (!workshopDataReady) return@LaunchedEffect
        try {
            withContext(Dispatchers.IO) {
                val synced = worldCoreRepo.synchronize(agwRepo, maps, portals, projectId)
                worldCoreRepo.save(synced)
                synced
            }.also { agwWorld = it }
        } catch (e: Exception) {
            Log.e("WorkshopScreen", "Synchronisation AGW World Core impossible", e)
        }
    }
    fun projectMobs() = mobs.filter { it.projectId == projectId }
    fun projectItems() = items.filter { it.projectId == projectId }
    fun projectBlocks() = blocks.filter { it.projectId == projectId }
    fun projectPortals() = portals.filter { it.projectId == projectId }
    fun projectMaps() = maps.filter { it.projectId == projectId }
    fun projectRecipes() = recipes.filter { it.projectId == projectId }
    fun projectEntities() = entities.filter { it.projectId == projectId }
    fun projectCharacters() = characterProjects.filter { it.projectId == projectId }
    fun projectGameBlueprints() = gameBlueprints.filter { it.projectId == projectId }
    fun projectSounds() = sounds.filter { it.projectId == null || it.projectId == projectId }

    // V1.8.57 : une sauvegarde qui échoue (stockage plein…) faisait planter l'application.
    // Elle est maintenant interceptée et signalée à l'utilisateur.
    fun reportSaveError(label: String, e: Exception) {
        Log.e("WorkshopScreen", "Sauvegarde $label impossible", e)
        onMessage("⚠ Sauvegarde $label impossible : ${e.message ?: "erreur inconnue"} — vérifiez l'espace de stockage.")
    }
    fun persist(label: String, block: () -> Unit) {
        workshopScope.launch {
            try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: Exception) {
                reportSaveError(label, e)
            }
        }
    }

    fun savePortals(v: List<PortalBlueprint>) {
        portals = v
        workshopScope.launch {
            try {
                val synced = withContext(Dispatchers.IO) {
                    repo.savePortals(v)
                    worldCoreRepo.synchronize(agwRepo, maps, v, projectId).also(worldCoreRepo::save)
                }
                agwWorld = synced
            } catch (e: Exception) {
                reportSaveError("des portails", e)
            }
        }
    }
    fun saveMaps(v: List<MapBlueprint>) {
        maps = v
        workshopScope.launch {
            try {
                val synced = withContext(Dispatchers.IO) {
                    repo.saveMaps(v)
                    worldCoreRepo.synchronize(agwRepo, v, portals, projectId).also(worldCoreRepo::save)
                }
                agwWorld = synced
            } catch (e: Exception) {
                reportSaveError("des maps", e)
            }
        }
    }
    fun saveMobs(v: List<MobEntity>) { mobs = v; persist("des mobs") { mobRepo.saveAll(v) } }
    fun saveItems(v: List<SbhItem>) { items = v; persist("des items") { itemRepo.saveAll(v) } }
    fun saveBlocks(v: List<SbhBlock>) { blocks = v; persist("des blocs") { blockRepo.saveAll(v) } }
    fun saveRecipes(v: List<RecipeBlueprint>) { recipes = v; persist("des recettes") { repo.saveRecipes(v) } }
    fun saveEntities(v: List<SceneEntity>) { entities = v; persist("des entités") { repo.saveEntities(v) } }
    fun saveGameBlueprints(v: List<GameProjectBlueprint>) { gameBlueprints = v; persist("du Game Builder") { gameBuilderRepo.saveAll(v) } }

    fun applyTemplate(t: WorkshopTemplate) {
        if (project == null) {
            onMessage("Ouvrez un projet avant d'appliquer un template")
            return
        }
        val pid = projectId
        val suffix = System.currentTimeMillis() % 10000
        when (t.id) {
            "desert_gothic" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Désert Gothique · $suffix",
                    sizeX = 96, sizeZ = 96, height = 72, theme = "desert_gothic", terrain = "desert",
                    hasVillage = true, hasDungeon = true, hasOasis = false, hasMountains = true, hasRoads = true
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Portail du Désert", identifier = "agw:portal_desert",
                    width = 5, height = 6, frameBlock = "agw:night_bricks",
                    destinationHint = "Al-Zahra · Désert", linkedMapId = mapId, mapX = 48, mapY = 70, mapZ = 48
                )
                val newMobs = listOf(
                    MobEntity(projectId = pid, nom = "Gardien du Désert", identifiant = "agw:gardien_desert", vie = 30, degats = 6, hostile = true, poursuite = true, attaque = true),
                    MobEntity(projectId = pid, nom = "Scorpion Noir", identifiant = "agw:scorpion_noir", vie = 16, degats = 4, hostile = true, poursuite = true, attaque = true)
                )
                val newItems = listOf(
                    SbhItem(projectId = pid, name = "Lame du Sirocco", identifier = "agw:lame_sirocco")
                )
                saveMaps(maps + map)
                savePortals(portals + portal)
                saveMobs(mobs + newMobs)
                saveItems(items + newItems)
                onMessage("Template « ${t.name} » appliqué : 1 map, 1 portail, 2 mobs, 1 item")
            }
            "oasis" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Oasis Vivante · $suffix",
                    sizeX = 64, sizeZ = 64, height = 64, theme = "oasis", terrain = "desert",
                    hasVillage = true, hasDungeon = false, hasOasis = true, hasMountains = false, hasRoads = true
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Portail de l'Oasis", identifier = "agw:portal_oasis",
                    width = 4, height = 5, frameBlock = "minecraft:sandstone",
                    destinationHint = "Oasis · Point d'eau", linkedMapId = mapId, mapX = 32, mapY = 65, mapZ = 32
                )
                val newRecipes = listOf(
                    RecipeBlueprint(projectId = pid, name = "Eau pure", identifier = "agw:eau_pure",
                        type = "minecraft:recipe_shapeless", resultId = "agw:eau_pure", resultCount = 1,
                        ingredients = listOf("minecraft:glass_bottle", "minecraft:water_bucket"))
                )
                saveMaps(maps + map)
                savePortals(portals + portal)
                saveRecipes(recipes + newRecipes)
                onMessage("Template « ${t.name} » appliqué : 1 map, 1 portail, 1 recette")
            }
            "forteresse" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Forteresse Noire · $suffix",
                    sizeX = 80, sizeZ = 80, height = 96, theme = "fortress", terrain = "mountains",
                    hasVillage = false, hasDungeon = true, hasOasis = false, hasMountains = true, hasRoads = false
                )
                val newMobs = listOf(
                    MobEntity(projectId = pid, nom = "Sentinelle Noire", identifiant = "agw:sentinelle_noire", vie = 40, degats = 8, hostile = true, poursuite = true, attaque = true, profilIA = "guerrier"),
                    MobEntity(projectId = pid, nom = "Archer de la Tour", identifiant = "agw:archer_tour", vie = 22, degats = 5, hostile = true, poursuite = true, attaque = true, profilIA = "archer")
                )
                saveMaps(maps + map)
                saveMobs(mobs + newMobs)
                onMessage("Template « ${t.name} » appliqué : 1 map, 2 mobs hostiles")
            }
            "route_caravane" -> {
                val mapA = MapBlueprint(
                    id = java.util.UUID.randomUUID().toString(), projectId = pid, name = "Caravansérail · $suffix",
                    sizeX = 48, sizeZ = 48, height = 64, theme = "caravan", terrain = "desert",
                    hasVillage = true, hasDungeon = false, hasOasis = false, hasMountains = false, hasRoads = true, worldX = 0, worldZ = 0
                )
                val mapB = MapBlueprint(
                    id = java.util.UUID.randomUUID().toString(), projectId = pid, name = "Poste avancé · $suffix",
                    sizeX = 32, sizeZ = 32, height = 64, theme = "caravan", terrain = "desert",
                    hasVillage = false, hasDungeon = false, hasOasis = true, hasMountains = false, hasRoads = true, worldX = 200, worldZ = 0
                )
                val portal = PortalBlueprint(
                    projectId = pid, name = "Relais Caravane", identifier = "agw:portal_caravane",
                    width = 3, height = 4, frameBlock = "minecraft:cut_sandstone",
                    destinationHint = "Poste avancé", linkedMapId = mapB.id, mapX = 16, mapY = 65, mapZ = 16,
                    destX = 200, destY = 65, destZ = 0
                )
                saveMaps(maps + mapA + mapB)
                savePortals(portals + portal)
                onMessage("Template « ${t.name} » appliqué : 2 maps liées + 1 portail")
            }
            "maison_forgeron" -> {
                val mapId = java.util.UUID.randomUUID().toString()
                val map = MapBlueprint(
                    id = mapId, projectId = pid, name = "Village · Maison du forgeron · $suffix",
                    sizeX = 32, sizeZ = 32, height = 64, theme = "village", terrain = "plains",
                    hasVillage = true, hasDungeon = false, hasOasis = false, hasMountains = false, hasRoads = true,
                    notes = "Structure embarquée : maison_forgeron (15x12x20, 597 blocs non-air). Fichier : assets/structures/structure_maison_forgeron.json"
                )
                val newMobs = listOf(
                    MobEntity(
                        projectId = pid,
                        nom = "Forgeron du village",
                        identifiant = "agw:forgeron_village",
                        vie = 20,
                        degats = 3,
                        hostile = false,
                        poursuite = false,
                        attaque = false,
                        profilIA = "villageois"
                    )
                )
                val newItems = listOf(
                    SbhItem(projectId = pid, name = "Marteau de forgeron", identifier = "agw:marteau_forgeron", damage = 5, durability = 250),
                    SbhItem(projectId = pid, name = "Lingot de fer raffiné", identifier = "agw:lingot_fer_raffine", damage = 0, durability = 1),
                    SbhItem(projectId = pid, name = "Kit de réparation", identifier = "agw:kit_reparation", damage = 0, durability = 1)
                )
                val newBlocks = listOf(
                    SbhBlock(projectId = pid, name = "Pierre de forge", identifier = "agw:pierre_forge", hardness = 2.5),
                    SbhBlock(projectId = pid, name = "Brique de fourneau", identifier = "agw:brique_fourneau", hardness = 2.0)
                )
                saveMaps(maps + map)
                saveMobs(mobs + newMobs)
                saveItems(items + newItems)
                saveBlocks(blocks + newBlocks)
                // Chaîne jouable : structure → placements.json pour le runtime
                val playable = PlayableSceneBuilder.buildDefaultForgeScene(
                    context = context,
                    projectId = pid,
                    projectName = project?.name ?: "Village Forge",
                    mobs = newMobs
                )
                val extra = if (playable.ok)
                    " · ▶ Scène jouable prête (${playable.blocksCount} blocs)"
                else
                    " · ⚠ Scène jouable : ${playable.message}"
                onMessage("Template « ${t.name} » appliqué : 1 map + forge + forgeron + items$extra")
            }

            else -> onMessage("Template inconnu")
        }
    }

    /** Ouvre une map dans Map Studio. Une map NOUVELLE est écrite tout de suite (Map Studio la relit). */
    fun openMapInStudio(map: MapBlueprint, action: String?, create: Boolean = false) {
        if (create) {
            val all = maps.filter { it.id != map.id } + map
            try { repo.saveMaps(all) } catch (e: Exception) { onMessage("Map non enregistrée : ${e.message}"); return }
            maps = all
        }
        onOpenMapEditor(map.id, action)
    }

    /**
     * V1.8.61 : « ▶ Tester le village forge » ouvre Map Studio sur la map « village forge » du projet
     * (celle qui porte la maison de forgeron, sinon une nouvelle), y pose la forge si besoin et lance
     * ▶ Tester sur CETTE map. Avant : la même structure était toujours chargée dans un autre éditeur
     * 3D (700 blocs max), sans lien avec les maps du projet.
     */
    fun playVillageForge() {
        if (project == null) {
            onMessage("Ouvrez un projet avant de tester")
            return
        }
        val existing = projectMaps().firstOrNull { com.sbh.studio.mapeditor.MapStudioStore.hasForgeNote(it) }
            ?: projectMaps().firstOrNull { it.name.contains("forge", ignoreCase = true) }
        val map = existing ?: MapBlueprint(
            projectId = projectId, name = "Village forge", sizeX = 64, sizeZ = 64, height = 48,
            theme = "village", terrain = "plaine", hasVillage = false, hasDungeon = false,
            notes = "Structure embarquée : maison_forgeron (15x12x20) — posée par Map Studio"
        )
        if (existing == null) openMapInStudio(map, "forge_test", create = true)
        else onOpenMapEditor(map.id, "forge_test")
    }




    fun generateFoundation() {
        onMessage("Génération de la fondation en cours…")
        reportText = "⏳ Génération de la fondation…"
        // V1.8.56 : la génération (fichiers, textures, zip) passe hors du thread UI.
        workshopScope.launch {
        try {
            val result = withContext(Dispatchers.IO) { SBhWorldFoundation.generateAndExport(context) }
            lastExport = result.addonFile

            // Import automatique dans le projet Compose (mobs + items)
            val pid = project?.id ?: "global"
            val foundationMobs = listOf(
                MobEntity(projectId = pid, nom = "Yahya ibn Harith", identifiant = "agw:yahya", vie = 32, degats = 7, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Zaynab", identifiant = "agw:zaynab", vie = 20, degats = 0, hostile = false),
                MobEntity(projectId = pid, nom = "Chef de Hibou", identifiant = "agw:chef_hibou", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Chef de Ghurab", identifiant = "agw:chef_ghurab", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Le Roi", identifiant = "agw:roi", vie = 30, degats = 5, hostile = false),
                MobEntity(projectId = pid, nom = "Garde royal", identifiant = "agw:garde_royal", vie = 24, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Combattant Hibou", identifiant = "agw:soldat_hibou", vie = 22, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Combattant Ghurab", identifiant = "agw:soldat_ghurab", vie = 22, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Templier", identifiant = "agw:templier", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Marchand bédouin", identifiant = "agw:marchand_bedouin", vie = 18, degats = 0, hostile = false),
                MobEntity(projectId = pid, nom = "Vautour", identifiant = "agw:vautour", vie = 20, degats = 4, hostile = true, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Hashashin", identifiant = "agw:hashashin", vie = 26, degats = 7, hostile = true, poursuite = true, attaque = true)
            )
            val foundationItems = listOf(
                SbhItem(projectId = pid, name = "Sabre de Hibou", identifier = "agw:sabre_hibou", damage = 7, durability = 600),
                SbhItem(projectId = pid, name = "Sabre de Ghurab", identifier = "agw:sabre_ghurab", damage = 7, durability = 600),
                SbhItem(projectId = pid, name = "Sabre royal", identifier = "agw:sabre_royal", damage = 8, durability = 650),
                SbhItem(projectId = pid, name = "Sabre templier", identifier = "agw:sabre_templier", damage = 8, durability = 650),
                SbhItem(projectId = pid, name = "Fusil royal", identifier = "agw:fusil_royal", damage = 11, durability = 400),
                SbhItem(projectId = pid, name = "Fusil de Hibou", identifier = "agw:fusil_hibou", damage = 10, durability = 380),
                SbhItem(projectId = pid, name = "Pistolet templier", identifier = "agw:pistolet_templier", damage = 8, durability = 300),
                SbhItem(projectId = pid, name = "Pistolet royal", identifier = "agw:pistolet_royal", damage = 8, durability = 300),
                SbhItem(projectId = pid, name = "Mitrailleuse lourde", identifier = "agw:mitrailleuse_lourde", damage = 14, durability = 800),
                SbhItem(projectId = pid, name = "NRJ noire", identifier = "agw:nrj_noire", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Minerai brut", identifier = "agw:minerai_brut", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Plan mécanique", identifier = "agw:plan_mecanique", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Composant rare", identifier = "agw:composant_rare", damage = 0, durability = 1)
            )
            // Les doublons ne se comparent que dans CE projet : avant, distinctBy portait sur tous les
            // projets et un 2e projet ne recevait rien alors que le message annonçait l'import.
            val mobMerge = mergeMobs(mobs, foundationMobs)
            saveMobs(mobMerge.mobs)
            val (itemList, itemsAdded) = addMissing(items, foundationItems, { it.projectId }, { it.identifier })
            saveItems(itemList)
            val alreadyThere = (foundationMobs.size - mobMerge.added) + (foundationItems.size - itemsAdded)
            val importNote = if (alreadyThere > 0) " ($alreadyThere déjà présents)" else ""

            // Régions → Map Studio. V1.8.60 : rangées dans le dossier Map Studio DU PROJET
            // (avant : un fichier unique pour toute l'app, affiché dans tous les projets).
            withContext(Dispatchers.IO) {
                try {
                    val regionsSrc = java.io.File(result.project.mapDir, "regions.json")
                    if (regionsSrc.exists()) {
                        val dest = com.sbh.studio.mapeditor.MapStudioStore.regionsFile(context, pid)
                        dest.parentFile?.mkdirs()
                        regionsSrc.copyTo(dest, overwrite = true)
                    }
                } catch (e: Exception) { android.util.Log.w("WorkshopScreen", "Échec non critique", e) }
            }

            reportText = result.message + "\n\n✅ Importé dans le projet : ${mobMerge.added} mobs, $itemsAdded items$importNote\n📍 Régions prêtes pour Map Studio" +
                // V1.8.58 : mêmes identifiants (agw:…) dans le pack Fondation et dans l'export du projet.
                "\n⚠ N'active pas le pack Fondation ET l'export de ce projet dans le même monde : les créatures agw:… y seraient définies deux fois."
            onMessage("Fondation + import projet OK")
            zone = WorkshopZoneId.EXPORT
        } catch (e: Exception) {
            onMessage("Erreur fondation : ${e.message}")
            reportText = "❌ ${e.message}"
        }
        }
    }

    fun importAgwPresets() {
        if (project == null) {
            onMessage("Ouvrez un projet d'abord")
            return
        }
        val pid = project.id
        val newMobs = engine.presetMobs(pid)
        val newItems = listOf(
            SbhItem(projectId = pid, name = "Cimeterre de fer", identifier = "agw:iron_scimitar", damage = 7, durability = 250),
            SbhItem(projectId = pid, name = "Lanterne suspendue", identifier = "agw:hanging_lantern", damage = 0, durability = 100)
        )
        val newBlocks = listOf(
            SbhBlock(projectId = pid, name = "Grès sombre", identifier = "agw:dark_sandstone", hardness = 1.5),
            SbhBlock(projectId = pid, name = "Pierre arabesque", identifier = "agw:arabesque_stone", hardness = 2.0),
            SbhBlock(projectId = pid, name = "Briques de nuit", identifier = "agw:night_bricks", hardness = 1.8),
            SbhBlock(projectId = pid, name = "Mosaïque sacrée", identifier = "agw:sacred_mosaic", hardness = 1.2)
        )
        val mobMerge = mergeMobs(mobs, newMobs)
        saveMobs(mobMerge.mobs)
        val (itemList, itemsAdded) = addMissing(items, newItems, { it.projectId }, { it.identifier })
        saveItems(itemList)
        val (blockList, blocksAdded) = addMissing(blocks, newBlocks, { it.projectId }, { it.identifier })
        saveBlocks(blockList)
        val portal = PortalBlueprint(projectId = pid, name = "Portail Al-Zahra", identifier = "agw:portal_al_zahra", destinationHint = "الزهراء")
        val map = MapBlueprint(projectId = pid, name = "Cité Al-Zahra", sizeX = 48, sizeZ = 48, hasVillage = true, hasDungeon = true, hasOasis = true)
        val (portalList, portalsAdded) = addMissing(portals, listOf(portal), { it.projectId }, { it.identifier })
        savePortals(portalList)
        val (mapList, mapsAdded) = addMissing(maps, listOf(map), { it.projectId }, { it.name })
        saveMaps(mapList)
        onMessage("Monde AGW importé dans le projet")
        val repairedNote = if (mobMerge.repaired > 0) " (+${mobMerge.repaired} réparés)" else ""
        reportText = "✅ Import AGW : ${mobMerge.added} mobs$repairedNote, $itemsAdded items, $blocksAdded blocs, $portalsAdded portail, $mapsAdded map"
        zone = WorkshopZoneId.EXPORT
    }

    fun importReclamationPresets() {
        if (project == null) {
            onMessage("Ouvrez un projet d'abord")
            return
        }
        val pid = project.id
        val newItems = ReclamationPresets.toSbhItems(context, pid)
        val newBlocks = ReclamationPresets.toSbhBlocks(context, pid)
        val (itemList, itemsAdded) = addMissing(items, newItems, { it.projectId }, { it.identifier })
        saveItems(itemList)
        val (blockList, blocksAdded) = addMissing(blocks, newBlocks, { it.projectId }, { it.identifier })
        saveBlocks(blockList)
        val phases = ReclamationPresets.phasesSummary(context)
        onMessage("Reclamation : $itemsAdded items, $blocksAdded blocs")
        reportText = "✅ Import Reclamation (monde mort → reconquête)\n" +
            "Items : $itemsAdded · Blocs : $blocksAdded\n\n" +
            "Phases :\n$phases"
    }

    fun importPracticePresets() {
        if (project == null) {
            onMessage("Ouvrez un projet d'abord")
            return
        }
        val pid = project.id
        val newItems = PracticePresets.toSbhItems(PracticePresets.loadAllItems(context), pid)
        val newBlocks = PracticePresets.toSbhBlocks(context, pid)
        val (itemList, itemsAdded) = addMissing(items, newItems, { it.projectId }, { it.identifier })
        saveItems(itemList)
        val (blockList, blocksAdded) = addMissing(blocks, newBlocks, { it.projectId }, { it.identifier })
        saveBlocks(blockList)
        val practiceItemIds = itemList.filter { it.projectId == pid && it.identifier.startsWith("sbh_practice:") }.map { it.id }
        val practiceBlockIds = blockList.filter { it.projectId == pid && (it.identifier.startsWith("sbh_practice:")) }.map { it.id }
        val newMaps = practiceMapsToBlueprints(context, pid, practiceItemIds, practiceBlockIds)
        val (mapList, mapsAdded) = addMissing(maps, newMaps, { it.projectId }, { it.name })
        saveMaps(mapList)
        onMessage("Practice PvP : $itemsAdded items, $blocksAdded blocs, $mapsAdded maps")
        reportText = "✅ Import Practice PvP (MCtier)\n" +
            "Armes/boucliers/armures : $itemsAdded · Blocs : $blocksAdded · Maps : $mapsAdded\n" +
            PracticePresets.summary(context)
    }

    fun runValidate() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet (Accueil → projet) puis revenez à l'atelier."
            return
        }
        val r = engine.validateAll(
            project,
            projectMobs(), projectItems(), projectBlocks(),
            projectPortals(), projectMaps(),
            projectRecipes(), projectEntities(), projectSounds()
        )
        reportText = buildString {
            append(if (r.ok) "✅ Validation OK\n" else "❌ Erreurs bloquantes\n")
            append("Contenu : ${projectMobs().size}m · ${projectItems().size}i · ${projectBlocks().size}b · ${projectPortals().size}p · ${projectMaps().size}maps · ${projectRecipes().size}r · ${projectEntities().size}e · ${projectSounds().size}s\n")
            append("Résultat : ${r.errors.size} erreur(s) · ${r.warnings.size} avertissement(s)\n")
            if (r.errors.isNotEmpty()) {
                append("\n── Erreurs ──\n")
                r.errors.forEach { append("· $it\n") }
            }
            if (r.warnings.isNotEmpty()) {
                append("\n── Avertissements ──\n")
                r.warnings.forEach { append("⚠ $it\n") }
            }
            if (r.ok && r.errors.isEmpty() && r.warnings.isEmpty()) {
                append("\nAucune anomalie détectée. Prêt pour l'export.\n")
            }
        }
    }

    var busy by remember { mutableStateOf(false) }

    fun showExportResult(r: AdvancedPackEngine.BuildReport) {
        lastExport = r.file
        reportText = buildString {
            append(if (r.ok) "✅ Export réussi\n" else "❌ Échec export\n")
            append("Fichier : ${r.file?.name ?: "—"}\n")
            append("Contenu : ${projectMobs().size}m · ${projectItems().size}i · ${projectBlocks().size}b · ${projectPortals().size}p · ${projectMaps().size}maps · ${projectRecipes().size}r · ${projectEntities().size}e · ${projectSounds().size}s\n")
            append("Résultat : ${r.errors.size} erreur(s) · ${r.warnings.size} avertissement(s)\n")
            if (r.errors.isNotEmpty()) {
                append("\n── Erreurs ──\n")
                r.errors.forEach { append("· $it\n") }
            }
            if (r.warnings.isNotEmpty()) {
                append("\n── Avertissements ──\n")
                r.warnings.forEach { append("⚠ $it\n") }
            }
        }
        if (r.ok && r.file != null) {
            onMessage("Pack généré : ${r.file.name}")
            try {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", r.file)
                // Même correctif que l'export du détail projet : Minecraft n'apparaît
                // jamais dans un partage générique (ACTION_SEND), seulement lors d'une
                // ouverture directe du fichier (ACTION_VIEW). Ce chemin d'export-ci avait
                // été oublié lors du premier correctif — désormais aligné.
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/mcaddon")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runCatching { context.startActivity(viewIntent) }.onFailure {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Partager le pack"))
                }
            } catch (e: Exception) { android.util.Log.w("WorkshopScreen", "Échec non critique", e) }
        }
    }


    fun runExport() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet d'abord."
            return
        }
        if (busy) return
        busy = true
        reportText = "⏳ Export en cours…"
        // V1.8.56 : génération du pack hors thread UI (avant : écran figé / ANR sur téléphone).
        val pMobs = projectMobs(); val pItems = projectItems(); val pBlocks = projectBlocks()
        val pPortals = projectPortals(); val pMaps = projectMaps(); val pRecipes = projectRecipes()
        val pEntities = projectEntities(); val pSounds = projectSounds()
        workshopScope.launch {
            try {
                val r = withContext(Dispatchers.IO) {
                    engine.exportAdvanced(project, pMobs, pItems, pBlocks, pPortals, pMaps, pRecipes, pEntities, pSounds)
                }
                showExportResult(r)
            } catch (e: Exception) {
                reportText = "❌ Échec export : ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    if (showEditor3D) {
        Editor3DScreen(
            projectId = projectId,
            // V1.8.61 : l'Éditeur 3D sert aux Entités seulement ; la maison de forgeron se pose dans Map Studio.
            loadStructureAsset = null,
            onClose = { showEditor3D = false }
        )
    }

    LaunchedEffect(projectId, meshVersion) {
        meshes = withContext(Dispatchers.IO) { runCatching { MeshStore.list(context, projectId) }.getOrDefault(emptyList()) }
    }
    meshEditing?.let { (pid, mid, name) ->
        key(mid) {
            MeshEditorDialog(projectId = pid, meshId = mid, initialName = name) { info ->
                meshEditing = null
                meshVersion++
                if (info != null) onMessage("🧊 « ${info.name} » enregistré · ${info.faces} faces")
            }
        }
    }

    // V1.8.62 : corps 3D d'un monstre dans CreatureStudio (plein écran). À la fermeture, la vie,
    // les dégâts, la vitesse, la détection et la boîte de collision du corps remontent dans la fiche.
    bodyRequest?.let { req ->
        CreatureEditorDialog(mob = req.mob, example = req.example, keepTemplateStats = req.keepTemplateStats, preview = req.preview) { body ->
            bodyRequest = null
            bodyVersion++
            val current = mobs.firstOrNull { it.id == req.mob.id }
            if (body != null && current != null) {
                val updated = CreatureBodyMapping.applyToMob(current, body)
                if (CreatureBodyMapping.differs(current, updated)) saveMobs(mobs.map { if (it.id == current.id) updated else it })
                onMessage("🧬 Corps de « ${current.nom} » enregistré" + if (body.warnings.isNotEmpty()) " · ${body.warnings.size} remarque(s) d'export" else "")
            } else if (current != null) onMessage("Corps de « ${current.nom} » : rien d'exportable pour Minecraft pour l'instant")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    // V1.8.57 : le projet travaillé est visible et modifiable ici (avant : toujours
                    // le 1er projet de la liste, sans possibilité d'en changer).
                    var projectMenu by remember { mutableStateOf(false) }
                    Column {
                        Text("Atelier · الورشة", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Box {
                            Text(
                                (project?.name ?: "Aucun projet ouvert") + if (allProjects.size > 1) "  ▾" else "",
                                style = MaterialTheme.typography.labelSmall,
                                color = AgwColors.Sand,
                                modifier = Modifier.clickable(enabled = allProjects.size > 1) { projectMenu = true }
                            )
                            DropdownMenu(expanded = projectMenu, onDismissRequest = { projectMenu = false }) {
                                allProjects.forEach { p ->
                                    DropdownMenuItem(
                                        text = { Text((if (p.id == project?.id) "● " else "") + p.name) },
                                        onClick = {
                                            projectMenu = false
                                            if (p.id != project?.id) {
                                                selectedVisualId = null
                                                onSelectProject(p.id)
                                                onMessage("Atelier : projet « ${p.name} »")
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(WorkshopZoneId.entries.filter { it != WorkshopZoneId.ENTITIES && it != WorkshopZoneId.CHARACTER_STUDIO }) { z ->
                    ModeIconChip(
                        label = zoneLabel(z),
                        iconAsset = zoneIcon(z),
                        selected = zone == z,
                        onClick = {
                            zone = z
                            selectedVisualId = null
                        }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            VisualWorkshopPreview(
                zone = if (zone == WorkshopZoneId.MOBS) when (previewKind) {
                    CreatureKind.MOB -> WorkshopZoneId.MOBS
                    CreatureKind.ENTITY -> WorkshopZoneId.ENTITIES
                    CreatureKind.CHARACTER -> WorkshopZoneId.CHARACTER_STUDIO
                } else zone,
                bodyVersion = bodyVersion,
                items = projectItems(),
                blocks = projectBlocks(),
                mobs = projectMobs(),
                entities = projectEntities(),
                characters = projectCharacters(),
                maps = projectMaps(),
                recipes = projectRecipes(),
                portals = projectPortals(),
                sounds = projectSounds(),
                games = projectGameBlueprints(),
                selectedId = selectedVisualId,
                onSelect = { selectedVisualId = it }
            )
            Spacer(Modifier.height(10.dp))
            // V1.8.61 : la carte affichée s'ouvre directement dans Map Studio (un seul endroit).
            if (zone == WorkshopZoneId.MAPS) {
                val pm = projectMaps()
                val sel = pm.firstOrNull { it.id == selectedVisualId } ?: pm.firstOrNull()
                if (sel != null) {
                    GoldPrimaryButton(
                        text = "🗺 Ouvrir « ${sel.name} » dans Map Studio",
                        onClick = { openMapInStudio(sel, null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }

            // V1.8.56 : tant que les données ne sont pas chargées, les listes sont vides ; une
            // sauvegarde à ce moment-là écrasait tout le contenu existant sur le disque.
            if (!workshopDataReady) {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = AgwColors.SacredGold)
                        Spacer(Modifier.height(8.dp))
                        Text("Chargement de l'atelier…", color = AgwColors.Sand)
                    }
                }
            } else key(projectId) {
            // V1.8.58 : changer de projet réinitialise les formulaires des zones. Avant, un mob en
            // cours d'édition dans le projet A était « déplacé » dans le projet B à l'enregistrement.
            when (zone) {
                WorkshopZoneId.HUB -> {
                    val hubValidation = computeHubValidation(
                        portals = projectPortals(),
                        maps = projectMaps(),
                        mobs = projectMobs(),
                        items = projectItems(),
                        blocks = projectBlocks(),
                        recipes = projectRecipes(),
                        entities = projectEntities(),
                        sounds = projectSounds()
                    )
                    HubZone(
                        onSelect = { z ->
                            // V1.8.62 : Entités 3D et Character Studio sont dans la zone « Créatures »
                            when (z) {
                                WorkshopZoneId.ENTITIES -> { creatureFilter = CreatureFilter.ENTITIES; previewKind = CreatureKind.ENTITY; zone = WorkshopZoneId.MOBS }
                                WorkshopZoneId.CHARACTER_STUDIO -> { creatureFilter = CreatureFilter.CHARACTERS; previewKind = CreatureKind.CHARACTER; zone = WorkshopZoneId.MOBS }
                                WorkshopZoneId.MOBS -> { creatureFilter = CreatureFilter.ALL; previewKind = CreatureKind.MOB; zone = z }
                                else -> zone = z
                            }
                            selectedVisualId = null
                        },
                        mobCount = projectMobs().size,
                        portalCount = projectPortals().size,
                        mapCount = projectMaps().size,
                        itemCount = projectItems().size,
                        blockCount = projectBlocks().size,
                        recipeCount = projectRecipes().size,
                        soundCount = projectSounds().size,
                        entityCount = projectEntities().size,
                        gameBuilderCount = projectGameBlueprints().size,
                        maps = projectMaps(),
                        portals = projectPortals(),
                        mobs = projectMobs(),
                        items = projectItems(),
                        blocks = projectBlocks(),
                        recipes = projectRecipes(),
                        textures = textures,
                        onImportAgw = { importAgwPresets() },
                        onImportReclamation = { importReclamationPresets() },
                        onImportPractice = { importPracticePresets() },
                        onGenerateFoundation = { generateFoundation() },
                        onApplyTemplate = { t -> applyTemplate(t) },
                        onPlayVillageForge = { playVillageForge() },
                        agwWorldName = agwWorld.worldName,
                        agwFactionCount = agwWorld.nodes.count { it.type == "faction" },
                        agwNodeCount = agwWorld.nodes.size,
                        validation = hubValidation,
                        onOpenExport = { zone = WorkshopZoneId.EXPORT },
                        onComingSoon = { label -> onMessage("$label : pas encore disponible, en préparation.") }
                    )
                }
                WorkshopZoneId.MOBS, WorkshopZoneId.ENTITIES, WorkshopZoneId.CHARACTER_STUDIO -> CreatureZone(
                    projectId = projectId,
                    hasProject = project != null,
                    mobs = projectMobs(),
                    entities = projectEntities(),
                    characters = projectCharacters(),
                    maps = projectMaps(),
                    textures = textures,
                    bodyVersion = bodyVersion,
                    filter = creatureFilter,
                    onFilter = { f ->
                        creatureFilter = f
                        previewKind = when (f) { CreatureFilter.ENTITIES -> CreatureKind.ENTITY; CreatureFilter.CHARACTERS -> CreatureKind.CHARACTER; else -> CreatureKind.MOB }
                        selectedVisualId = null
                    },
                    onPreview = { kind, id -> previewKind = kind; selectedVisualId = id },
                    onSaveMob = { m ->
                        if (project == null) onMessage("Ouvrez un projet")
                        else saveMobs(mobs.filter { it.id != m.id } + m)
                    },
                    onDeleteMob = { m ->
                        saveMobs(mobs - m)
                        // V1.8.58 : retire aussi les liens des maps vers ce mob (avant : lien cassé).
                        if (maps.any { m.id in it.linkedMobIds }) saveMaps(maps.map { it.copy(linkedMobIds = it.linkedMobIds - m.id) })
                        // V1.8.62 : son corps 3D est supprimé avec lui (sinon fichiers orphelins).
                        workshopScope.launch(Dispatchers.IO) { CreatureBodyStore.delete(context, m.projectId, m.id) }
                        onMessage("« ${m.nom} » supprimé")
                    },
                    onAddPresets = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val r = mergeMobs(mobs, engine.presetMobs(projectId))
                            saveMobs(r.mobs)
                            onMessage(mobMergeMessage(r))
                        }
                    },
                    onOpenBody = { m -> bodyRequest = BodyRequest(m, example = null, keepTemplateStats = false) },
                    onPreviewBody = { m, pv -> bodyRequest = BodyRequest(m, preview = pv) },
                    onCreateFromTemplate = { t ->
                        val taken = projectMobs().map { it.identifiant }.toSet()
                        val slug = java.text.Normalizer.normalize(t.name, java.text.Normalizer.Form.NFD)
                            .replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').lowercase().ifBlank { "creature" }
                        val m = MobEntity(
                            projectId = projectId,
                            nom = if (t.key.isEmpty()) "Nouvelle créature" else t.name,
                            identifiant = workshopUniqueId("agw:$slug", taken),
                            versionHistory = listOf("v1 — création depuis le modèle « ${t.name} » (CreatureStudio)")
                        )
                        saveMobs(mobs + m)
                        previewKind = CreatureKind.MOB
                        selectedVisualId = m.id
                        bodyRequest = BodyRequest(m, example = t.key.ifEmpty { null }, keepTemplateStats = t.key.isNotEmpty())
                    },
                    onSaveEntity = { e ->
                        if (project == null) onMessage("Ouvrez un projet")
                        else saveEntities(entities.filter { it.id != e.id } + e)
                    },
                    onDeleteEntity = { e -> saveEntities(entities - e); onMessage("« ${e.name} » supprimé") },
                    onOpenEditor3D = { if (project == null) onMessage("Ouvrez un projet") else showEditor3D = true },
                    onSaveCharacter = { character ->
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            characterProjects = characterProjects.filter { it.id != character.id } + character
                            val snapshot = characterProjects
                            persist("des personnages") { characterRepo.saveAll(snapshot) }
                        }
                    },
                    onDeleteCharacter = { character ->
                        characterProjects = characterProjects.filter { it.id != character.id }
                        val snapshot = characterProjects
                        persist("des personnages") { characterRepo.saveAll(snapshot) }
                    },
                    onSendToMapStudio = { filePath, displayName ->
                        com.sbh.studio.mapeditor.PendingMapImport.offer(filePath, displayName)
                        onOpenMapEditor(null, null)
                    },
                    meshes = meshes,
                    meshVersion = meshVersion,
                    onOpenMesh = { me ->
                        if (project == null) onMessage("Ouvrez un projet")
                        else meshEditing = if (me != null) Triple(projectId, me.id, me.name)
                            else Triple(projectId, MeshStore.newId(), "Maillage ${meshes.size + 1}")
                    },
                    onDeleteMesh = { me ->
                        workshopScope.launch(Dispatchers.IO) {
                            MeshStore.delete(context, me.projectId, me.id)
                            withContext(Dispatchers.Main) { meshVersion++ }
                        }
                        onMessage("« ${me.name} » supprimé")
                    },
                    onMessage = onMessage
                )
                WorkshopZoneId.PORTALS -> PortalZone(
                    projectId = projectId,
                    portals = projectPortals(),
                    maps = projectMaps(),
                    textures = textures,
                    blocks = projectBlocks(),
                    onSave = { p ->
                        savePortals(portals.filter { it.id != p.id } + p)
                    },
                    onDelete = { p -> savePortals(portals - p) }
                )
                WorkshopZoneId.MAPS -> MapZone(
                    projectId = projectId,
                    maps = projectMaps(),
                    portals = projectPortals(),
                    mobs = projectMobs(),
                    items = projectItems(),
                    blocks = projectBlocks(),
                    textures = textures,
                    onSave = { m -> saveMaps(maps.filter { it.id != m.id } + m) },
                    onLinkPortal = { portal, mapId ->
                        savePortals(portals.filter { it.id != portal.id } + portal.copy(linkedMapId = mapId))
                    },
                    onDelete = { m ->
                        saveMaps(maps - m)
                        savePortals(portals.map { if (it.linkedMapId == m.id) it.copy(linkedMapId = null) else it })
                    },
                    onPlayVillageForge = { playVillageForge() },
                    onOpenInStudio = { m, action, isNew -> openMapInStudio(m, action, create = isNew) },
                    onAddPracticeMaps = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val practiceItemIds = items.filter { it.projectId == projectId && it.identifier.startsWith("sbh_practice:") }.map { it.id }
                            val practiceBlockIds = blocks.filter { it.projectId == projectId && (it.identifier.startsWith("sbh_practice:")) }.map { it.id }
                            val presets = practiceMapsToBlueprints(context, projectId, practiceItemIds, practiceBlockIds)
                            val existing = maps.filter { it.projectId == projectId }.map { it.name }.toSet()
                            val toAdd = presets.filter { it.name !in existing }
                            if (toAdd.isEmpty()) onMessage("Templates Practice déjà présents")
                            else {
                                saveMaps(maps + toAdd)
                                onMessage("${toAdd.size} map(s) Practice importée(s)")
                            }
                        }
                    }
                )
                WorkshopZoneId.BLOCKS -> BlockZone(
                    projectId = projectId,
                    blocks = projectBlocks(),
                    textures = textures,
                    onSave = { block ->
                        saveBlocks(blocks.filter { it.id != block.id } + block)
                    },
                    onDelete = { b ->
                        saveBlocks(blocks - b)
                        if (maps.any { b.id in it.linkedBlockIds }) saveMaps(maps.map { it.copy(linkedBlockIds = it.linkedBlockIds - b.id) })
                    },
                    onAddPracticeBlocks = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val presets = PracticePresets.toSbhBlocks(context, projectId)
                            val existingIds = blocks.filter { it.projectId == projectId }.map { it.identifier }.toSet()
                            val toAdd = presets.filter { it.identifier !in existingIds }
                            if (toAdd.isEmpty()) onMessage("Blocs Practice déjà présents")
                            else {
                                saveBlocks(blocks + toAdd)
                                onMessage("${toAdd.size} bloc(s) Practice ajouté(s)")
                            }
                        }
                    },
                    onAddReclamationPresets = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val presets = ReclamationPresets.toSbhBlocks(context, projectId)
                            val existingIds = blocks.filter { it.projectId == projectId }.map { it.identifier }.toSet()
                            val toAdd = presets.filter { it.identifier !in existingIds }
                            if (toAdd.isEmpty()) onMessage("Presets Reclamation déjà présents (blocs)")
                            else {
                                saveBlocks(blocks + toAdd)
                                onMessage("${toAdd.size} bloc(s) Reclamation ajouté(s)")
                            }
                        }
                    }
                )
                WorkshopZoneId.ITEMS -> ItemZone(
                    projectId = projectId,
                    items = projectItems(),
                    textures = textures,
                    onSave = { item ->
                        saveItems(items.filter { it.id != item.id } + item)
                    },
                    onDelete = { i ->
                        saveItems(items - i)
                        if (maps.any { i.id in it.linkedItemIds }) saveMaps(maps.map { it.copy(linkedItemIds = it.linkedItemIds - i.id) })
                    },
                    onAddPracticeWeapons = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val presets = PracticePresets.toSbhItems(PracticePresets.loadWeapons(context), projectId)
                            val existingIds = items.filter { it.projectId == projectId }.map { it.identifier }.toSet()
                            val toAdd = presets.filter { it.identifier !in existingIds }
                            if (toAdd.isEmpty()) onMessage("Armes Practice déjà présentes")
                            else {
                                saveItems(items + toAdd)
                                onMessage("${toAdd.size} arme(s) Practice ajoutée(s)")
                            }
                        }
                    },
                    onAddPracticeDefense = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val presets = PracticePresets.toSbhItems(PracticePresets.loadDefense(context), projectId)
                            val existingIds = items.filter { it.projectId == projectId }.map { it.identifier }.toSet()
                            val toAdd = presets.filter { it.identifier !in existingIds }
                            if (toAdd.isEmpty()) onMessage("Boucliers Practice déjà présents")
                            else {
                                saveItems(items + toAdd)
                                onMessage("${toAdd.size} bouclier(s) Practice ajouté(s)")
                            }
                        }
                    },
                    onAddPracticeArmor = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val presets = PracticePresets.toSbhItems(PracticePresets.loadArmor(context), projectId)
                            val existingIds = items.filter { it.projectId == projectId }.map { it.identifier }.toSet()
                            val toAdd = presets.filter { it.identifier !in existingIds }
                            if (toAdd.isEmpty()) onMessage("Armures Practice déjà présentes")
                            else {
                                saveItems(items + toAdd)
                                onMessage("${toAdd.size} pièce(s) d'armure Practice ajoutée(s)")
                            }
                        }
                    },
                    onAddReclamationPresets = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val presets = ReclamationPresets.toSbhItems(context, projectId)
                            val existingIds = items.filter { it.projectId == projectId }.map { it.identifier }.toSet()
                            val toAdd = presets.filter { it.identifier !in existingIds }
                            if (toAdd.isEmpty()) onMessage("Presets Reclamation déjà présents (items)")
                            else {
                                saveItems(items + toAdd)
                                onMessage("${toAdd.size} item(s) Reclamation ajouté(s)")
                            }
                        }
                    }
                )
                WorkshopZoneId.RECIPES -> RecipeZone(
                    projectId = projectId,
                    recipes = projectRecipes(),
                    items = projectItems(),
                    blocks = projectBlocks(),
                    onSave = { r ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@RecipeZone }
                        saveRecipes(recipes.filter { it.id != r.id } + r)
                    },
                    onDelete = { r -> saveRecipes(recipes - r) }
                )
                WorkshopZoneId.SOUNDS -> SoundZone(
                    projectId = projectId,
                    projectName = project?.name,
                    sounds = projectSounds(),
                    hasProject = project != null,
                    soundRepo = soundRepo,
                    onRefresh = { sounds = soundRepo.loadAll() },
                    onMessage = onMessage
                )
                WorkshopZoneId.GAME_BUILDER -> GameBuilderZone(
                    projectId = projectId,
                    hasProject = project != null,
                    blueprints = projectGameBlueprints(),
                    templates = gameTemplates,
                    onSave = { b ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@GameBuilderZone }
                        val withProfile = b.copy(profileJson = gameBuilderRepo.profileJsonFor(b.performance))
                        saveGameBlueprints(gameBlueprints.filter { it.id != withProfile.id } + withProfile)
                    },
                    onDelete = { b -> saveGameBlueprints(gameBlueprints - b) },
                    onApplyTemplate = { assetName ->
                        val created = gameBuilderRepo.blueprintFromWorldTemplate(projectId, assetName)
                        if (created == null) onMessage("Template illisible : $assetName")
                        else {
                            val withProfile = created.copy(profileJson = gameBuilderRepo.profileJsonFor(created.performance))
                            saveGameBlueprints(gameBlueprints + withProfile)
                            onMessage("Template appliqué : ${withProfile.name}")
                        }
                    },
                    onMessage = onMessage
                )
                WorkshopZoneId.EXPORT -> ExportZone(
                    reportText = reportText,
                    hasProject = project != null,
                    counts = "${projectMobs().size}m ${projectItems().size}i ${projectBlocks().size}b ${projectPortals().size}p ${projectMaps().size}maps ${projectRecipes().size}r ${projectSounds().size}s ${projectEntities().size}e ${projectCharacters().size}ch ${projectGameBlueprints().size}gb",
                    onValidate = { runValidate() },
                    onExport = { runExport() },
                    onImportAgw = { importAgwPresets() }
                )
            }
            }
        }
    }
}

/** V1.8.62 : ouverture de l'éditeur CreatureStudio pour le corps d'un monstre. */
internal data class BodyRequest(
    val mob: MobEntity,
    /** Modèle de départ pour un corps neuf ("soldat", "chef", "hippo1"…), null = corps enregistré ou vide. */
    val example: String? = null,
    /** Vrai pour un monstre créé depuis un modèle : ses caractéristiques remontent dans la fiche. */
    val keepTemplateStats: Boolean = false,
    /** V1.8.63 : état de l'âme à jouer sur le corps (bouton « ▶ Voir sur le corps 3D »). */
    val preview: com.sbh.studio.creature.BodyPreview? = null
)
