package com.sbh.studio.mesh

import android.content.Context
import android.util.Base64
import android.util.Log
import com.sbh.studio.data.SafeStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Une carte « Maillage » de la zone Créatures (lue dans l'index, sans ouvrir le .glb). */
data class MeshInfo(
    val id: String,
    val projectId: String,
    val name: String,
    val objects: Int = 0,
    val verts: Int = 0,
    val faces: Int = 0,
    val triangles: Int = 0,
    val symmetry: Boolean = true,
    val updatedAt: Long = 0L
)

/**
 * V1.8.65 — maillages du Modeleur 3D (Atelier de personnages, phase 1).
 *
 * Fichiers : files/meshes/<projet>/<id>.glb (le maillage, glTF 2.0 : Godot l'ouvre tel quel ; les
 * polygones d'origine sont dans node.extras.sbh pour pouvoir rééditer), <id>.png (aperçu 256×256)
 * et index.json (nom, compteurs, date, pour les cartes). Un .glb n'est enregistré que s'il passe
 * [GlbCheck] ; l'écriture est atomique (fichier temporaire puis renommage).
 */
object MeshStore {
    private const val TAG = "MeshStore"
    private val indexLock = Any()

    private fun safe(raw: String): String = raw.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80).ifBlank { "global" }

    fun root(context: Context): File = File(context.filesDir, "meshes")
    fun dir(context: Context, projectId: String): File = File(root(context), safe(projectId))
    fun glbFile(context: Context, projectId: String, id: String) = File(dir(context, projectId), safe(id) + ".glb")
    fun previewFile(context: Context, projectId: String, id: String) = File(dir(context, projectId), safe(id) + ".png")
    private fun indexFile(context: Context, projectId: String) = File(dir(context, projectId), "index.json")

    fun newId(): String = "mesh_" + java.lang.Long.toString(System.currentTimeMillis(), 36) +
        java.lang.Integer.toString((Math.random() * 1296).toInt(), 36)

    private fun parse(o: JSONObject, projectId: String) = MeshInfo(
        id = o.optString("id"), projectId = projectId,
        name = o.optString("name").takeIf { it.isNotBlank() && it != "null" } ?: "Maillage",
        objects = o.optInt("objects"), verts = o.optInt("verts"), faces = o.optInt("faces"),
        triangles = o.optInt("triangles"), symmetry = o.optBoolean("symmetry", true), updatedAt = o.optLong("updatedAt")
    )

    private fun readIndex(context: Context, projectId: String): MutableList<MeshInfo> {
        val text = SafeStore.readText(indexFile(context, projectId)) ?: return mutableListOf()
        return try {
            val a = JSONArray(text)
            MutableList(a.length()) { parse(a.getJSONObject(it), projectId) }.filter { it.id.isNotBlank() }.toMutableList()
        } catch (e: Exception) {
            Log.w(TAG, "index illisible : copie de secours puis reconstruction", e)
            runCatching { SafeStore.backupCorrupt(indexFile(context, projectId)) }
            mutableListOf()
        }
    }

    private fun writeIndex(context: Context, projectId: String, list: List<MeshInfo>) {
        val a = JSONArray()
        list.forEach { m ->
            a.put(JSONObject().apply {
                put("id", m.id); put("name", m.name); put("objects", m.objects); put("verts", m.verts)
                put("faces", m.faces); put("triangles", m.triangles); put("symmetry", m.symmetry); put("updatedAt", m.updatedAt)
            })
        }
        SafeStore.write(indexFile(context, projectId), a.toString(1))
    }

    /** Maillages du projet, les plus récents d'abord. Un .glb présent mais absent de l'index y est remis. */
    fun list(context: Context, projectId: String): List<MeshInfo> = synchronized(indexLock) {
        val idx = readIndex(context, projectId).filter { glbFile(context, projectId, it.id).exists() }.toMutableList()
        val known = idx.map { safe(it.id) }.toSet()
        dir(context, projectId).listFiles { f -> f.name.endsWith(".glb") }?.forEach { f ->
            val id = f.name.removeSuffix(".glb")
            if (id !in known) idx.add(MeshInfo(id = id, projectId = projectId, name = id, updatedAt = f.lastModified()))
        }
        idx.sortedByDescending { it.updatedAt }
    }

    fun info(context: Context, projectId: String, id: String): MeshInfo? = list(context, projectId).firstOrNull { it.id == id }

    fun loadGlbBase64(context: Context, projectId: String, id: String): String? = try {
        val f = glbFile(context, projectId, id)
        if (f.exists()) Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) else null
    } catch (e: Exception) { Log.e(TAG, "lecture impossible", e); null }

    private fun writeBytesAtomic(target: File, bytes: ByteArray) {
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, "${target.name}.${System.nanoTime()}.tmp")
        try {
            FileOutputStream(tmp).use { out -> out.write(bytes); out.flush(); runCatching { out.fd.sync() } }
            if (!tmp.renameTo(target)) { target.delete(); if (!tmp.renameTo(target)) throw IllegalStateException("Impossible d'enregistrer ${target.name}") }
        } finally { if (tmp.exists()) tmp.delete() }
    }

    /** Enregistre le .glb (refusé s'il est mal formé), l'aperçu et la ligne d'index. */
    fun save(context: Context, projectId: String, id: String, glbBase64: String, previewDataUrl: String, metaJson: String): Boolean = try {
        val bytes = Base64.decode(glbBase64, Base64.DEFAULT)
        val problem = GlbCheck.problem(bytes)
        if (problem != null) { Log.e(TAG, "maillage refusé : $problem"); false }
        else {
            writeBytesAtomic(glbFile(context, projectId, id), bytes)
            val prefix = "data:image/png;base64,"
            if (previewDataUrl.startsWith(prefix)) {
                val png = Base64.decode(previewDataUrl.removePrefix(prefix), Base64.DEFAULT)
                if (png.size in 8..2_000_000) writeBytesAtomic(previewFile(context, projectId, id), png)
            }
            val meta = runCatching { JSONObject(metaJson) }.getOrDefault(JSONObject())
            synchronized(indexLock) {
                val idx = readIndex(context, projectId).filter { it.id != id }.toMutableList()
                idx.add(parse(meta.put("id", id).put("updatedAt", System.currentTimeMillis()), projectId))
                writeIndex(context, projectId, idx)
            }
            true
        }
    } catch (e: Exception) { Log.e(TAG, "maillage non enregistré", e); false }

    fun delete(context: Context, projectId: String, id: String) {
        synchronized(indexLock) {
            runCatching { glbFile(context, projectId, id).delete() }
            runCatching { previewFile(context, projectId, id).delete() }
            runCatching { writeIndex(context, projectId, readIndex(context, projectId).filter { it.id != id }) }
        }
    }
}
