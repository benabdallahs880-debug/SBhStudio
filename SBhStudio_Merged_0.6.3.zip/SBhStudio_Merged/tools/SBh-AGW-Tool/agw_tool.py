#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SBh ARABIAN GOTHIC WORLD — Outil générateur v0.5
================================================
Outil modulaire capable de générer :
  - Structure complète du pack (BP + RP)
  - Blocs, items, entités, scripts
  - Textures placeholder
  - Documentation
  - Données de lore / héros / factions

Usage :
  python agw_tool.py --help
  python agw_tool.py init
  python agw_tool.py generate foundation
  python agw_tool.py generate bestiary
  python agw_tool.py generate all
  python agw_tool.py export-data          # exporte lore/héros pour l'application future
  python agw_tool.py status

Plus tard : cet outil sera branché dans l'application fournie par l'utilisateur.
"""

from __future__ import annotations
import argparse
import json
import os
import shutil
import sys
from pathlib import Path

# Racine de l'outil
TOOL_ROOT = Path(__file__).resolve().parent
DATA_DIR = TOOL_ROOT / "data"
OUTPUT_DIR = TOOL_ROOT / "output"
GENERATORS_DIR = TOOL_ROOT / "generators"

sys.path.insert(0, str(TOOL_ROOT))

def load_json(name: str) -> dict:
    path = DATA_DIR / name
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def ensure_output():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def cmd_status(_: argparse.Namespace):
    project = load_json("project.json")
    phases = load_json("phases.json")
    print(f"\n=== {project['name']} ({project['code']}) v{project['version']} ===\n")
    print(f"Préfixe ID : {project['prefix']}:")
    print(f"API serveur : {project['server_api']}")
    print(f"Langues     : {', '.join(project['languages'])}")
    print("\nPiliers :")
    for p in project["pillars"]:
        print(f"  • {p}")
    print("\nPhases :")
    for ph in phases["phases"]:
        mark = "✅" if ph["status"] == "done" else "⏳"
        print(f"  {mark} Phase {ph['id']} — {ph['name']} ({ph['status']})")
    print()

def cmd_export_data(_: argparse.Namespace):
    """Exporte toutes les données lore/héros/factions pour l'application future."""
    ensure_output()
    export_path = OUTPUT_DIR / "agw_data_export.json"
    data = {
        "project": load_json("project.json"),
        "lore": load_json("lore.json"),
        "heroes": load_json("heroes.json"),
        "factions": load_json("factions.json"),
        "phases": load_json("phases.json"),
    }
    with open(export_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"[+] Données exportées → {export_path}")
    print("    (prêtes à être injectées dans l'application)")

def cmd_init(_: argparse.Namespace):
    """Crée l'arborescence de sortie du pack."""
    ensure_output()
    root = OUTPUT_DIR / "SBh-AGW-Generated"
    bp = root / "behavior_pack"
    rp = root / "resource_pack"

    dirs = [
        bp / "blocks", bp / "items", bp / "entities", bp / "scripts",
        bp / "loot_tables" / "entities", bp / "spawn_rules",
        rp / "textures" / "blocks", rp / "textures" / "items",
        rp / "textures" / "entity", rp / "texts", rp / "entity",
        rp / "models" / "blocks", rp / "models" / "entity",
        rp / "animations", rp / "attachables",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
    print(f"[+] Arborescence créée → {root}")
    return root

def write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  [+] {path.relative_to(OUTPUT_DIR)}")

def generate_foundation(root: Path):
    """Génère la fondation technique (Phase 0)."""
    project = load_json("project.json")
    bp = root / "behavior_pack"
    rp = root / "resource_pack"
    prefix = project["prefix"]

    # Manifests
    bp_manifest = {
        "format_version": 2,
        "header": {
            "name": f"{project['code']} — Behavior Pack",
            "description": project["description"]["fr"],
            "uuid": "5f3b8a1c-2d4e-4f6a-9b7c-1e2d3f4a5b6c",
            "version": [0, 5, 0],
            "min_engine_version": project["min_engine"],
        },
        "modules": [
            {"type": "data", "uuid": "6a4c9b2d-3e5f-4a7b-8c9d-2f3e4a5b6c7d", "version": [0, 5, 0]},
            {
                "type": "script",
                "language": "javascript",
                "uuid": "9d7f2e50-6b8c-7d0e-1f2a-5c6d7e8f9a0b",
                "entry": "scripts/main.js",
                "version": [0, 5, 0],
            },
        ],
        "dependencies": [
            {"uuid": "7b5d0c3e-4f6a-5b8c-9d0e-3a4b5c6d7e8f", "version": [0, 5, 0]},
            {"module_name": "@minecraft/server", "version": project["server_api"]},
        ],
        "metadata": {"authors": [project["studio"]], "license": "All Rights Reserved"},
    }
    write(bp / "manifest.json", json.dumps(bp_manifest, indent=2, ensure_ascii=False))

    rp_manifest = {
        "format_version": 2,
        "header": {
            "name": f"{project['code']} — Resource Pack",
            "description": project["description"]["fr"],
            "uuid": "7b5d0c3e-4f6a-5b8c-9d0e-3a4b5c6d7e8f",
            "version": [0, 5, 0],
            "min_engine_version": project["min_engine"],
        },
        "modules": [
            {"type": "resources", "uuid": "8c6e1d4f-5a7b-6c9d-0e1f-4b5c6d7e8f9a", "version": [0, 5, 0]}
        ],
        "metadata": {"authors": [project["studio"]], "license": "All Rights Reserved"},
    }
    write(rp / "manifest.json", json.dumps(rp_manifest, indent=2, ensure_ascii=False))

    # Main script
    main_js = f'''// {project["code"]} — Point d'entrée
import {{ world }} from "@minecraft/server";

const P = "§6[{project["code"]}]§r";

world.afterEvents.worldLoad.subscribe(() => {{
  console.warn(`${{P}} Pack chargé.`);
}});

world.afterEvents.playerSpawn.subscribe((e) => {{
  if (e.initialSpawn) {{
    e.player.sendMessage(`${{P}} Bienvenue dans le monde d'Al-Zahra.`);
  }}
}});
'''
    write(bp / "scripts" / "main.js", main_js)

    # Languages
    write(rp / "texts" / "languages.json", '["en_US", "fr_FR"]\n')
    write(rp / "texts" / "fr_FR.lang", f"""pack.name={project['code']} — Ressources
pack.description={project['description']['fr']}
""")
    write(rp / "texts" / "en_US.lang", f"""pack.name={project['code']} — Resources
pack.description={project['description']['en']}
""")

    print("[OK] Fondation générée")

def generate_bestiary(root: Path):
    """Génère le bestiaire (Phase 4) à partir des données heroes.json."""
    heroes = load_json("heroes.json")
    bp = root / "behavior_pack"
    print("[…] Génération bestiaire (stubs + structure)…")
    for creature in heroes["creatures"] + heroes["bosses"]:
        cid = creature["id"]
        # Stub entity file (le contenu complet peut être injecté plus tard)
        stub = {
            "format_version": "1.21.0",
            "minecraft:entity": {
                "description": {
                    "identifier": f"agw:{cid}",
                    "is_spawnable": cid != "djinn_sultan",
                    "is_summonable": True,
                },
                "components": {
                    "minecraft:type_family": {"family": ["agw_monster", "monster"]},
                    "minecraft:health": {"value": 20, "max": 20},
                    "minecraft:attack": {"damage": 4},
                },
            },
        }
        write(bp / "entities" / f"{cid}.json", json.dumps(stub, indent=2, ensure_ascii=False))
    print("[OK] Bestiaire (stubs) généré — à enrichir avec les JSON complets déjà validés")

def generate_all(root: Path):
    generate_foundation(root)
    generate_bestiary(root)
    # Placeholder pour phases futures
    print("[i] Phases 1-2-3-5 : structure prête, générateurs à brancher")

def cmd_generate(args: argparse.Namespace):
    ensure_output()
    root = OUTPUT_DIR / "SBh-AGW-Generated"
    if not root.exists():
        cmd_init(args)
        root = OUTPUT_DIR / "SBh-AGW-Generated"

    target = args.target
    if target == "foundation":
        generate_foundation(root)
    elif target == "bestiary":
        generate_bestiary(root)
    elif target == "all":
        generate_all(root)
    else:
        print(f"Cible inconnue : {target}")
        print("Cibles disponibles : foundation | bestiary | all")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(
        description="SBh-AGW Tool — Générateur modulaire du monde arabo-gothique"
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("status", help="Affiche l'état du projet et des phases")
    sub.add_parser("init", help="Crée l'arborescence de sortie")
    sub.add_parser("export-data", help="Exporte lore/héros/factions pour l'application")

    gen = sub.add_parser("generate", help="Génère une partie du pack")
    gen.add_argument("target", choices=["foundation", "bestiary", "all"], help="Cible à générer")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return

    commands = {
        "status": cmd_status,
        "init": cmd_init,
        "export-data": cmd_export_data,
        "generate": cmd_generate,
    }
    commands[args.command](args)

if __name__ == "__main__":
    main()
