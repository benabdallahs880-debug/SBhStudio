# SBh-AGW Tool — Générateur du monde arabo-gothique

Outil Python modulaire préparé pour créer **tout le contenu** du projet SBh Arabian Gothic World.

## Objectif

Cet outil est la **couche de génération** du projet.  
Plus tard, quand l’application (UI / éditeur / launcher) sera fournie, on y branchera :

1. Cet outil
2. Toutes les données (lore, héros, factions, phases)
3. L’historique complet de la mission

## Structure

```
SBh-AGW-Tool/
├── agw_tool.py          ← Point d’entrée CLI
├── data/
│   ├── project.json     ← Config projet + palette
│   ├── lore.json        ← Histoire, ambiance, promesse
│   ├── heroes.json      ← PNJ, boss, créatures, rôle joueur
│   ├── factions.json    ← Veilleurs d’Al-Zahra + futures
│   └── phases.json      ← Roadmap 0 → 5
├── generators/          ← Modules de génération (extensibles)
├── templates/           ← Modèles JSON / JS réutilisables
├── output/              ← Packs générés + export données
└── docs/
```

## Commandes

```bash
# État du projet
python agw_tool.py status

# Créer l’arborescence de sortie
python agw_tool.py init

# Générer la fondation (Phase 0)
python agw_tool.py generate foundation

# Générer le bestiaire (Phase 4 stubs)
python agw_tool.py generate bestiary

# Tout générer
python agw_tool.py generate all

# Exporter lore + héros + factions pour l’application future
python agw_tool.py export-data
```

## Données déjà intégrées

- Palette officielle (4 couleurs maîtresses + 2 extensions)
- 5 piliers non négociables
- Lore d’Al-Zahra
- 3 PNJ (Yusuf, Nadia, Rashid)
- Boss Sultan-Djinn (3 phases)
- 3 créatures (Scorpion, Spectre, Djinn Nocturne)
- Faction pilote « Les Veilleurs d’Al-Zahra »
- Roadmap Phase 0 → 5

## Prochaine étape (quand tu fournis l’application)

1. Tu me donnes l’application (code / structure / framework).
2. J’intègre :
   - Cet outil comme moteur de génération
   - Les fichiers `data/*.json` comme source de vérité
   - L’histoire, les héros, les factions, les phases
3. On connecte l’UI de l’application aux commandes `generate` / `export-data`.

## Notes techniques

- Préfixe d’ID verrouillé : `agw:`
- Version Bedrock cible : 1.21.x
- API script : `@minecraft/server` 1.14.0
- Langues : FR + EN
- Tout est conçu pour rester compatible avec les packs déjà testés (fondation + bestiaire).
