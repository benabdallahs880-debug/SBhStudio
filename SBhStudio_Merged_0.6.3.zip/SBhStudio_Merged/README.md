# SBh Studio — Fusion 0.6.3 (AGW Tool intégré)

Projet unifié :
- **SBh Studio** — application Android génératrice de packs Minecraft Bedrock
- **SBh-AGW** — Arabian Gothic World (sample + données + outil)

## Nouveautés 0.6.3 — Intégration de l'outil AGW

1. **Outil générateur** copié dans `tools/SBh-AGW-Tool/`
   - CLI Python (`agw_tool.py`)
   - Données lore / héros / factions / phases
2. **Données AGW dans l'app** (`app/src/main/assets/agw/`)
   - `project.json`, `lore.json`, `heroes.json`, `factions.json`, `phases.json`
3. **`AgwDataRepository`** (Kotlin) — charge lore, PNJ, boss, créatures, phases depuis les assets
4. **Bestiaire complet** ajouté au sample :
   - Scorpion des Dunes, Spectre des Ruines, Djinn Nocturne, Sultan-Djinn (boss 3 phases)
   - Loot tables, spawn rules, client entities, textures, script `boss_sultan.js`

## Structure

```
SBhStudio_Merged/
├── app/                         # Application Android (Kotlin)
│   └── src/main/
│       ├── assets/agw/          # Données outil (lore, héros, factions…)
│       └── java/.../data/AgwData.kt
├── tools/
│   └── SBh-AGW-Tool/            # Outil Python générateur
├── samples/
│   ├── SBh-AGW_BP/              # Behavior Pack (blocs + bestiaire + scripts)
│   └── SBh-AGW_RP/              # Resource Pack
├── version.json
└── README.md
```

## Utilisation

### App Studio
```bash
./gradlew :app:assembleDebug
# APK → app/build/outputs/apk/debug/
```

### Outil Python (hors app)
```bash
cd tools/SBh-AGW-Tool
python agw_tool.py status
python agw_tool.py export-data
python agw_tool.py generate all
```

### Pack AGW in-game
- `/scriptevent agw:kit` — kit de départ
- `/scriptevent agw:rep` — réputation Cour de Nuit
- `/summon agw:dune_scorpion`
- `/summon agw:ruin_specter`
- `/summon agw:night_djinn`
- `/summon agw:djinn_sultan` — boss 3 phases

## Lore intégré

- Monde : **Al-Zahra**
- Faction pilote : Les Veilleurs / Cour de Nuit
- PNJ : Yusuf, Nadia, Rashid
- Boss : Sultan-Djinn
- Créatures : Scorpion, Spectre, Djinn Nocturne

## Auteurs
SBh Studio — All rights reserved.
