package com.sbh.studio.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private const val LATEST_RELEASE_URL =
    "https://api.github.com/repos/benabdallahs880-debug/SBhStudio/releases/latest"

private val json = Json { ignoreUnknownKeys = true }

sealed class UpdateCheckResult {
    data class UpdateAvailable(val info: UpdateInfo) : UpdateCheckResult()
    data object UpToDate : UpdateCheckResult()
    data class Error(val message: String) : UpdateCheckResult()
}

sealed class DownloadState {
    data object Idle : DownloadState()
    data object Downloading : DownloadState()
    data class ReadyToInstall(val apkFile: File) : DownloadState()
    data class Failed(val message: String) : DownloadState()
}

class UpdateManager(private val context: Context) {

    suspend fun checkForUpdate(currentVersionCode: Int): UpdateCheckResult = withContext(Dispatchers.IO) {
        try {
            val connection = URL(LATEST_RELEASE_URL).openConnection() as HttpURLConnection
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            val code = connection.responseCode
            if (code != 200) {
                return@withContext UpdateCheckResult.Error("GitHub a répondu $code. Aucune release publique valide n'a été trouvée.")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = json.parseToJsonElement(body).jsonObject
            val tag = root["tag_name"]?.toString()?.trim('"') ?: return@withContext UpdateCheckResult.Error("Release sans numéro de version.")
            val versionName = tag.removePrefix("v")
            val versionParts = versionName.split('.').mapNotNull { it.toIntOrNull() }
            val versionCode = when {
                versionParts.size >= 3 && versionParts[0] == 0 -> versionParts[1] + versionParts[2]
                versionParts.size >= 3 -> versionParts[0] * 10000 + versionParts[1] * 100 + versionParts[2]
                else -> 0
            }
            val assets = root["assets"]?.jsonArray.orEmpty()
            val apk = assets.firstOrNull {
                it.jsonObject["name"]?.toString()?.trim('"')?.endsWith(".apk", ignoreCase = true) == true
            }?.jsonObject?.get("browser_download_url")?.toString()?.trim('"')
                ?: return@withContext UpdateCheckResult.Error("La release $tag ne contient aucun APK.")
            val notes = root["body"]?.toString()?.trim('"') ?: "Nouvelle version de SBh Studio."
            val info = UpdateInfo(versionCode = versionCode, versionName = versionName, apkUrl = apk, notes = notes)
            if (info.versionCode > currentVersionCode) UpdateCheckResult.UpdateAvailable(info) else UpdateCheckResult.UpToDate
        } catch (e: Exception) {
            UpdateCheckResult.Error(e.message ?: "Erreur réseau inconnue")
        }
    }

    fun startDownload(apkUrl: String): Long {
        val updatesDir = File(context.getExternalFilesDir(null), "updates")
        if (!updatesDir.exists()) updatesDir.mkdirs()
        val destFile = File(updatesDir, "sbh-studio-update.apk")
        if (destFile.exists()) destFile.delete()
        val request = DownloadManager.Request(Uri.parse(apkUrl))
            .setTitle("SBh Studio — mise à jour")
            .setDescription("Téléchargement de la nouvelle version")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationUri(Uri.fromFile(destFile))
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return dm.enqueue(request)
    }

    fun apkFile(): File = File(File(context.getExternalFilesDir(null), "updates"), "sbh-studio-update.apk")

    fun installApk(apkFile: File) {
        val uri = FileProvider.getUriForFile(context, "com.sbh.studio.fileprovider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
