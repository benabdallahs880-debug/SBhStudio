package com.sbh.studio.data

import kotlinx.serialization.Serializable

/**
 * Reflète le contenu de version.json publié à la racine du dépôt GitHub.
 * Le workflow GitHub Actions met ce fichier à jour à chaque build réussi.
 */
@Serializable
data class UpdateInfo(
    val versionCode: Int,
    val versionName: String,
    val apkUrl: String,
    val notes: String = ""
)
