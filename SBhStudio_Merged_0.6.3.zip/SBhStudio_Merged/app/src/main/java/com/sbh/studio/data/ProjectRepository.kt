package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

@Serializable
data class SbhProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val version: String = "0.6.0",
    val status: String = "Brouillon",
    val versionHistory: List<String> = listOf("v1 — création du projet")
)

private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

class ProjectRepository(private val context: Context) {
    private val storageFile get() = File(context.filesDir, "sbh_projects.json")
    fun load(): List<SbhProject> = readSafely(storageFile) { json.decodeFromString(it) } ?: emptyList()
    fun save(projects: List<SbhProject>) = atomicWrite(storageFile, json.encodeToString(projects))
}

private fun <T> readSafely(file: File, decoder: (String) -> T): T? = try {
    if (!file.exists()) null else decoder(file.readText())
} catch (_: Exception) { null }

internal fun atomicWrite(target: File, content: String) {
    target.parentFile?.mkdirs()
    val tmp = File(target.parentFile, "${target.name}.tmp")
    tmp.writeText(content)
    if (!tmp.renameTo(target)) {
        target.delete()
        if (!tmp.renameTo(target)) throw IllegalStateException("Impossible d'enregistrer ${target.name}")
    }
}
