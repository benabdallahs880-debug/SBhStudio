package com.sbh.studio.ui

import android.app.DownloadManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sbh.studio.BuildConfig
import com.sbh.studio.data.DownloadState
import com.sbh.studio.data.UpdateCheckResult
import com.sbh.studio.data.UpdateInfo
import com.sbh.studio.data.UpdateManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdateScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val updateManager = remember { UpdateManager(context) }
    val scope = rememberCoroutineScope()

    var checking by remember { mutableStateOf(false) }
    var checkResult by remember { mutableStateOf<UpdateCheckResult?>(null) }
    var downloadState by remember { mutableStateOf<DownloadState>(DownloadState.Idle) }
    var downloadId by remember { mutableStateOf<Long?>(null) }

    // Surveille le téléchargement en cours et passe automatiquement à "prêt à installer"
    LaunchedEffect(downloadId) {
        val id = downloadId ?: return@LaunchedEffect
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        while (true) {
            val query = DownloadManager.Query().setFilterById(id)
            val cursor = dm.query(query)
            if (cursor.moveToFirst()) {
                val statusIdx = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val status = cursor.getInt(statusIdx)
                cursor.close()
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        downloadState = DownloadState.ReadyToInstall(updateManager.apkFile())
                        break
                    }
                    DownloadManager.STATUS_FAILED -> {
                        downloadState = DownloadState.Failed("Le téléchargement a échoué.")
                        break
                    }
                }
            } else {
                cursor.close()
            }
            delay(800)
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Mises à jour") },
            navigationIcon = { TextButton(onClick = onBack) { Text("←") } }
        )
    }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Version installée : ${BuildConfig.VERSION_NAME} (code ${BuildConfig.VERSION_CODE})")

            Button(
                enabled = !checking,
                onClick = {
                    checking = true
                    checkResult = null
                    scope.launch {
                        checkResult = updateManager.checkForUpdate(BuildConfig.VERSION_CODE)
                        checking = false
                    }
                }
            ) {
                Text(if (checking) "Vérification..." else "Vérifier les mises à jour")
            }

            when (val result = checkResult) {
                is UpdateCheckResult.UpToDate -> Text("Tu as déjà la dernière version. ✅")
                is UpdateCheckResult.Error -> Text("Impossible de vérifier : ${result.message}")
                is UpdateCheckResult.UpdateAvailable -> UpdateAvailableCard(
                    info = result.info,
                    downloadState = downloadState,
                    onDownload = {
                        downloadState = DownloadState.Downloading
                        downloadId = updateManager.startDownload(result.info.apkUrl)
                    },
                    onInstall = { file -> updateManager.installApk(file) }
                )
                null -> {}
            }

            Spacer(Modifier.weight(1f))
            Text(
                "Cette page vérifie la dernière version publiée sur le dépôt GitHub du projet et permet de l'installer directement, sans repasser par GitHub à la main.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun UpdateAvailableCard(
    info: UpdateInfo,
    downloadState: DownloadState,
    onDownload: () -> Unit,
    onInstall: (java.io.File) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Nouvelle version disponible : ${info.versionName}", style = MaterialTheme.typography.titleMedium)
            if (info.notes.isNotBlank()) Text(info.notes, style = MaterialTheme.typography.bodyMedium)

            when (downloadState) {
                is DownloadState.Idle -> Button(onClick = onDownload) { Text("Télécharger") }
                is DownloadState.Downloading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Téléchargement en cours...")
                }
                is DownloadState.ReadyToInstall -> Button(onClick = { onInstall(downloadState.apkFile) }) {
                    Text("Installer maintenant")
                }
                is DownloadState.Failed -> Text("Échec : ${downloadState.message}")
            }
        }
    }
}
