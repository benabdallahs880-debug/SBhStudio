# SBh-AGW — Arabian Gothic World

Pack d'exemple complet généré / maintenu pour SBh Studio.

## Structure

| Dossier | Rôle |
|---------|------|
| SBh-AGW_BP | Behavior Pack (blocs, items, recettes, scripts, loot) |
| SBh-AGW_RP | Resource Pack (textures, models, sounds, texts) |

## Blocs inclus

- `agw:arabesque_stone` — pierre arabesque
- `agw:dark_sandstone` — grès sombre
- `agw:night_bricks` — briques de nuit
- `agw:ochre_plaster` — enduit ocre
- `agw:sacred_mosaic` — mosaïque sacrée
- `agw:blood_marble` — marbre sang
- `agw:gold_inlay_tile` — carreau doré
- `agw:dome_tile` — tuile de coupole
- `agw:ornate_frieze` — frise ornée
- `agw:ruin_stone` — pierre de ruine
- `agw:mashrabiya` — mashrabiya (claustra)
- `agw:hanging_lantern` — lanterne suspendue (bloc + modèle 3D)
- `agw:desert_glass` — **NOUVEAU** verre du désert (ajout fusion)

## Items

- `agw:iron_scimitar` — cimeterre de fer (son riptide à l'utilisation)

## Scripts

- `main.js` — bienvenue, kit, réputation, sons
- `factions.js` — système Cour de Nuit
- `ambiance.js` — messages d'ambiance crépusculaire

## Recettes

Crafts pour : scimitar, night_bricks, arabesque_stone, dark_sandstone, hanging_lantern, **desert_glass**

## Installation

Créer un fichier `.mcaddon` contenant les deux dossiers BP + RP à la racine, puis ouvrir avec Minecraft Bedrock ≥ 1.21.
