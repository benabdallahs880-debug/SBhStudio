scriptevent agw:kit
