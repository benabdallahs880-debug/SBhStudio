import { world, system } from "@minecraft/server";

/**
 * Ambiance loop — sky is still vanilla in Phase 0.
 * We seed the feeling with timed whispers, never spam.
 */
export function initAmbiance() {
  system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
      const t = world.getTimeOfDay();
      if (t > 13000 && t < 14000) {
        player.sendMessage({ rawtext: [{ translate: "agw.ambiance.dusk" }] });
      }
    }
  }, 20 * 60 * 8);
}
