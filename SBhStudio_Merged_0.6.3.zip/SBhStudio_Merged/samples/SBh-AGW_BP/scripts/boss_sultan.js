// SBh AGW — Boss Sultan-Djinn, logique 3 phases
import { world, system } from "@minecraft/server";

const BOSS_ID = "agw:djinn_sultan";
const PHASE_2_THRESHOLD = 100;
const PHASE_3_THRESHOLD = 50;
const KEY_PHASE = "agw:boss_phase";

function getPhase(entity) {
  const p = entity.getDynamicProperty(KEY_PHASE);
  return typeof p === "number" ? p : 1;
}

function setPhase(entity, phase) {
  entity.setDynamicProperty(KEY_PHASE, phase);
}

system.runInterval(() => {
  for (const dimName of ["overworld", "nether", "the_end"]) {
    const dim = world.getDimension(dimName);
    const bosses = dim.getEntities({ type: BOSS_ID });

    for (const boss of bosses) {
      const healthComp = boss.getComponent("minecraft:health");
      const hp = healthComp ? healthComp.currentValue : 0;
      const currentPhase = getPhase(boss);

      if (currentPhase === 1 && hp <= PHASE_2_THRESHOLD && hp > PHASE_3_THRESHOLD) {
        setPhase(boss, 2);
        boss.triggerEvent("agw:enter_phase_2");
        announcePhase(boss, 2);
        summonMinions(boss, 4);
      }

      if (currentPhase === 2 && hp <= PHASE_3_THRESHOLD && hp > 0) {
        setPhase(boss, 3);
        boss.triggerEvent("agw:enter_phase_3");
        announcePhase(boss, 3);
        summonMinions(boss, 6);
      }

      if (currentPhase === 3) {
        spawnParticles(boss);
      }
    }
  }
}, 20);

function announcePhase(boss, phase) {
  const messages = {
    2: "§c[Sultan-Djinn]§r §eVous osez me défier ? Ma vraie forme s'éveille...",
    3: "§4[Sultan-Djinn]§r §cASSEZ ! Le sable lui-même se lèvera contre vous !"
  };
  for (const player of world.getPlayers()) {
    if (player.dimension.id === boss.dimension.id) {
      player.sendMessage(messages[phase] || "");
      try {
        player.onScreenDisplay.setTitle(`§cPhase ${phase}`, {
          fadeInDuration: 5,
          stayDuration: 30,
          fadeOutDuration: 10
        });
      } catch (e) {}
    }
  }
}

function summonMinions(boss, count) {
  const loc = boss.location;
  const dim = boss.dimension;
  const choices = ["agw:dune_scorpion", "agw:night_djinn", "agw:ruin_specter"];

  for (let i = 0; i < count; i++) {
    const angle = (Math.PI * 2 * i) / count;
    const r = 3;
    const spawnLoc = {
      x: loc.x + Math.cos(angle) * r,
      y: loc.y,
      z: loc.z + Math.sin(angle) * r
    };
    try {
      const id = choices[Math.floor(Math.random() * choices.length)];
      dim.spawnEntity(id, spawnLoc);
    } catch (e) {}
  }
}

function spawnParticles(boss) {
  const loc = boss.location;
  try {
    boss.dimension.spawnParticle("minecraft:basic_flame_particle", {
      x: loc.x,
      y: loc.y + 1.5,
      z: loc.z
    });
  } catch (e) {}
}
