/**
 * Faction memory — Phase 0/2 foundation.
 * Reputation is stored per-player as a dynamic property.
 * The world remembers. The Night Court measures.
 */

export const FACTIONS = [
  {
    id: "night_court",
    key: "agw.faction.night_court",
    color: "#C9A227",
    territory: "qasr_al_layl",
  },
];

export function getReputation(player, factionId) {
  const v = player.getDynamicProperty(`agw:rep.${factionId}`);
  return typeof v === "number" ? v : 0;
}

export function addReputation(player, factionId, delta) {
  const next = getReputation(player, factionId) + delta;
  player.setDynamicProperty(`agw:rep.${factionId}`, next);
  return next;
}

export function standing(value) {
  if (value >= 20) return "honored";
  if (value >= 5) return "known";
  if (value <= -20) return "hunted";
  if (value <= -5) return "distrusted";
  return "stranger";
}
