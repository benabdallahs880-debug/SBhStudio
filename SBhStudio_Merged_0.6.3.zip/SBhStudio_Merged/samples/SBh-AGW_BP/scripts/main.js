import { world, system, ItemStack, EquipmentSlot } from "@minecraft/server";
import { FACTIONS, getReputation, addReputation } from "./factions.js";
import { initAmbiance } from "./ambiance.js";
import "./boss_sultan.js";

const LOG = "[SBh-AGW]";

world.afterEvents.worldLoad.subscribe(() => {
  console.warn(`${LOG} Behavior pack loaded. Pipeline OK. Factions: ${FACTIONS.map((f) => f.id).join(", ")}`);
  initAmbiance();
});

world.afterEvents.playerSpawn.subscribe((event) => {
  const player = event.player;
  if (!event.initialSpawn) return;

  if (!player.getDynamicProperty("agw:awakened")) {
    player.setDynamicProperty("agw:awakened", true);
    player.setDynamicProperty("agw:rep.night_court", 0);
    player.setDynamicProperty("agw:lang", "fr");
    player.sendMessage({ rawtext: [{ translate: "agw.welcome" }] });
    player.sendMessage({ rawtext: [{ translate: "agw.welcome.hint" }] });
  }
});

world.afterEvents.itemUse.subscribe((event) => {
  const { source, itemStack } = event;
  if (!itemStack || itemStack.typeId !== "agw:iron_scimitar") return;
  source.playSound("item.trident.riptide_1", { pitch: 1.4, volume: 0.4 });
});

world.afterEvents.playerBreakBlock.subscribe((event) => {
  const id = event.brokenBlockPermutation.type.id;
  if (!id.startsWith("agw:")) return;
  if (id === "agw:ruin_stone") {
    addReputation(event.player, "night_court", -1);
  }
});

world.afterEvents.playerPlaceBlock.subscribe((event) => {
  const id = event.permutationToPlace.type.id;
  if (id === "agw:arabesque_stone" || id === "agw:sacred_mosaic") {
    addReputation(event.player, "night_court", 1);
  }
});

system.afterEvents.scriptEventReceive.subscribe((event) => {
  const player = event.sourceEntity;
  if (!player || player.typeId !== "minecraft:player") return;

  if (event.id === "agw:kit") {
    const inv = player.getComponent("minecraft:inventory")?.container;
    if (!inv) return;
    inv.addItem(new ItemStack("agw:iron_scimitar", 1));
    inv.addItem(new ItemStack("agw:hanging_lantern", 4));
    inv.addItem(new ItemStack("agw:arabesque_stone", 16));
    inv.addItem(new ItemStack("agw:dark_sandstone", 32));
    inv.addItem(new ItemStack("agw:night_bricks", 32));
    player.sendMessage({ rawtext: [{ translate: "agw.kit.given" }] });
    return;
  }

  if (event.id === "agw:rep") {
    const v = getReputation(player, "night_court");
    player.sendMessage(`${LOG} Dīwān al-Layl: ${v}`);
  }
});
