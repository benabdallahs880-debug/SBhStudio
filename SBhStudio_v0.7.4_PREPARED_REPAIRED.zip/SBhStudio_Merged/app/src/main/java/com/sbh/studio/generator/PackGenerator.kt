package com.sbh.studio.generator

import android.content.Context
import android.net.Uri
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** Générateur minimal mais réel de structure Bedrock BP/RP et export .mcaddon. */
class PackGenerator(private val context: Context) {
    private val json = Json { prettyPrint = true }

    fun validate(project: SbhProject, mobs: List<MobEntity>, items: List<SbhItem>, blocks: List<SbhBlock>): List<String> {
        val errors = mutableListOf<String>()
        if (project.name.isBlank()) errors += "Le projet doit avoir un nom."
        val ids = (mobs.map { it.identifiant } + items.map { it.identifier } + blocks.map { it.identifier })
        ids.forEach { id ->
            if (!Regex("^[a-z0-9_]+:[a-z0-9_./-]+$").matches(id)) errors += "Identifiant invalide : $id"
        }
        if (mobs.any { it.vie <= 0 || it.degats < 0 || it.vitesse <= 0 }) errors += "Un mob contient des valeurs de vie/dégâts/vitesse invalides."
        if (items.any { it.damage < 0 || it.durability <= 0 }) errors += "Un item contient des valeurs invalides."
        return errors.distinct()
    }

    fun export(project: SbhProject, mobs: List<MobEntity>, items: List<SbhItem>, blocks: List<SbhBlock>): File =
        export(project, mobs, items, blocks, emptyMap())

    /**
     * Produit un vrai .mcaddon : deux .mcpack internes (BP + RP).
     * Les UUID de pack/module sont persistants par projet afin d'éviter de casser
     * les dépendances Minecraft à chaque export.
     */
    fun export(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        extraFiles: Map<String, String>
    ): File {
        val errors = validate(project, mobs, items, blocks)
        require(errors.isEmpty()) { errors.joinToString("\n") }

        val bpName = "SBh_${safe(project.name)}_BP"
        val rpName = "SBh_${safe(project.name)}_RP"
        val ids = loadPackIds(project.id)
        val bpPack = zipPack(bpName, "data", ids.bpUuid, ids.bpModuleUuid, project, mobs, items, blocks, extraFiles, true)
        val rpPack = zipPack(rpName, "resources", ids.rpUuid, ids.rpModuleUuid, project, mobs, items, blocks, extraFiles, false, ids.bpUuid)

        val out = File(context.cacheDir, "${safe(project.name)}-${project.version}.mcaddon")
        ZipOutputStream(out.outputStream().buffered()).use { addon ->
            writeBytes(addon, "$bpName.mcpack", bpPack)
            writeBytes(addon, "$rpName.mcpack", rpPack)
            writeText(addon, "README.txt", "SBh Studio ${project.version}\nPack BP + RP généré pour Minecraft Bedrock.\n")
        }
        return out
    }

    private data class PackIds(
        val bpUuid: String,
        val bpModuleUuid: String,
        val rpUuid: String,
        val rpModuleUuid: String
    )

    private fun loadPackIds(projectId: String): PackIds {
        val file = File(context.filesDir, "sbh_pack_ids_${safe(projectId)}.json")
        val existing = runCatching {
            if (!file.exists()) null else Json.parseToJsonElement(file.readText()).jsonObject
        }.getOrNull()
        val ids = PackIds(
            existing?.get("bp")?.toString()?.trim('"') ?: java.util.UUID.randomUUID().toString(),
            existing?.get("bpModule")?.toString()?.trim('"') ?: java.util.UUID.randomUUID().toString(),
            existing?.get("rp")?.toString()?.trim('"') ?: java.util.UUID.randomUUID().toString(),
            existing?.get("rpModule")?.toString()?.trim('"') ?: java.util.UUID.randomUUID().toString()
        )
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, "${file.name}.tmp")
        tmp.writeText(buildJsonObject {
            put("bp", ids.bpUuid); put("bpModule", ids.bpModuleUuid)
            put("rp", ids.rpUuid); put("rpModule", ids.rpModuleUuid)
        }.toString())
        if (!tmp.renameTo(file)) { file.delete(); require(tmp.renameTo(file)) { "Impossible d'enregistrer les UUID de packs" } }
        return ids
    }

    private fun zipPack(
        name: String, type: String, uuid: String, moduleUuid: String,
        project: SbhProject, mobs: List<MobEntity>, items: List<SbhItem>, blocks: List<SbhBlock>,
        extraFiles: Map<String, String>, isBp: Boolean, dependencyUuid: String? = null
    ): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            writeText(zip, "manifest.json", manifest(name, type, uuid, moduleUuid, project.version, dependencyUuid))
            if (isBp) {
                mobs.forEach { mob ->
                    val (ns, id) = splitId(mob.identifiant)
                    writeText(zip, "entities/$id.json", mobJson(mob, ns, id))
                }
                items.forEach { item ->
                    val (ns, id) = splitId(item.identifier)
                    writeText(zip, "items/$id.json", itemJson(item, ns, id))
                }
                blocks.forEach { block ->
                    val (ns, id) = splitId(block.identifier)
                    writeText(zip, "blocks/$id.json", blockJson(block, ns, id))
                }
            } else {
                if (items.isNotEmpty()) writeText(zip, "textures/item_texture.json", itemTextureJson(items))
                if (blocks.isNotEmpty()) writeText(zip, "textures/terrain_texture.json", terrainTextureJson(blocks))
                mobs.forEach { mob ->
                    val (_, id) = splitId(mob.identifiant)
                    writeText(zip, "entity/$id.entity.json", resourceEntityJson(splitId(mob.identifiant).first, id))
                    copyTexture(zip, mob.textureUri, "textures/entity/$id.png")
                }
                items.forEach { item ->
                    val (_, id) = splitId(item.identifier)
                    copyTexture(zip, item.textureUri, "textures/items/$id.png")
                }
                blocks.forEach { block ->
                    val (ns, id) = splitId(block.identifier)
                    writeText(zip, "blocks/$id.json", blockResourceJson(ns, id))
                    copyTexture(zip, block.textureUri, "textures/blocks/$id.png")
                }
            }
            val prefix = if (isBp) "BP/" else "RP/"
            extraFiles.forEach { (path, content) ->
                if (path.startsWith(prefix)) writeText(zip, path.removePrefix(prefix), content)
            }
            if (!isBp) {
                writeText(zip, "README.txt", "SBh Studio ${project.version} — Resource Pack")
            }
        }
        return out.toByteArray()
    }

    private fun manifest(name: String, type: String, uuid: String, moduleUuid: String, versionName: String, dependencyUuid: String?): String = buildJsonObject {
        put("format_version", 2)
        put("header", buildJsonObject {
            put("name", name)
            put("description", "Generated by SBh Studio")
            put("uuid", uuid)
            put("version", versionArray(versionName))
            put("min_engine_version", kotlinx.serialization.json.buildJsonArray { add(1); add(21); add(0) })
        })
        put("modules", kotlinx.serialization.json.buildJsonArray {
            add(buildJsonObject {
                put("type", type); put("uuid", moduleUuid); put("version", versionArray(versionName))
            })
        })
        if (dependencyUuid != null) put("dependencies", kotlinx.serialization.json.buildJsonArray {
            add(buildJsonObject { put("uuid", dependencyUuid); put("version", versionArray(versionName)) })
        })
    }.toString()

    private fun versionArray(value: String) = kotlinx.serialization.json.buildJsonArray {
        val parts = value.split('.').take(3).map { it.toIntOrNull() ?: 0 }
        parts.forEach { add(it) }
        repeat((3 - parts.size).coerceAtLeast(0)) { add(0) }
    }

    private fun writeBytes(zip: ZipOutputStream, path: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(path)); zip.write(bytes); zip.closeEntry()
    }

    private fun copyTexture(zip: ZipOutputStream, uriString: String?, path: String) {
        if (uriString == null) return
        runCatching {
            context.contentResolver.openInputStream(Uri.parse(uriString))?.use { input ->
                zip.putNextEntry(ZipEntry(path)); input.copyTo(zip); zip.closeEntry()
            }
        }
    }

    private fun mobJson(m: MobEntity, ns: String, id: String): String = buildJsonObject {
        put("format_version", "1.21.0")
        put("minecraft:entity", buildJsonObject {
            put("description", buildJsonObject { put("identifier", "$ns:$id"); put("is_spawnable", true); put("is_summonable", true) })
            put("components", buildJsonObject {
                put("minecraft:health", buildJsonObject { put("value", m.vie); put("max", m.vie) })
                put("minecraft:movement", buildJsonObject { put("value", m.vitesse) })
                if (m.attaque) put("minecraft:attack", buildJsonObject { put("damage", m.degats) })
                if (m.poursuite) put("minecraft:behavior.nearest_attackable_target", buildJsonObject { put("priority", 2); put("must_see", true) })
                if (m.attaque || m.poursuite) put("minecraft:behavior.melee_attack", buildJsonObject { put("priority", 3); put("track_target", true) })
                if (m.reactionDegats) put("minecraft:behavior.hurt_by_target", buildJsonObject { put("priority", 1) })
                if (m.hostile) put("minecraft:type_family", buildJsonObject { put("family", kotlinx.serialization.json.buildJsonArray { add(kotlinx.serialization.json.JsonPrimitive("monster")); add(kotlinx.serialization.json.JsonPrimitive("sbh_hostile")) }) })
                if (m.pouvoirResistance) put("minecraft:damage_sensor", buildJsonObject { put("triggers", kotlinx.serialization.json.buildJsonArray { add(buildJsonObject { put("cause", "all"); put("deals_damage", true) }) }) })
            })
        })
    }.toString()

    private fun resourceEntityJson(ns: String, id: String) = buildJsonObject { put("format_version", "1.21.0"); put("minecraft:client_entity", buildJsonObject { put("description", buildJsonObject { put("identifier", "$ns:$id"); put("materials", buildJsonObject { put("default", "entity_alphatest") }); put("textures", buildJsonObject { put("default", "textures/entity/$id") }); put("geometry", buildJsonObject { put("default", "geometry.humanoid") }) }) }) }.toString()
    private fun itemTextureJson(items: List<SbhItem>) = buildJsonObject {
        put("resource_pack_name", "vanilla")
        put("texture_name", "atlas.items")
        put("texture_data", kotlinx.serialization.json.buildJsonObject {
            items.forEach { item -> val id = splitId(item.identifier).second; put(id, buildJsonObject { put("textures", "textures/items/$id") }) }
        })
    }.toString()
    private fun terrainTextureJson(blocks: List<SbhBlock>) = buildJsonObject {
        put("resource_pack_name", "vanilla")
        put("texture_name", "atlas.terrain")
        put("texture_data", kotlinx.serialization.json.buildJsonObject {
            blocks.forEach { block -> val id = splitId(block.identifier).second; put(id, buildJsonObject { put("textures", "textures/blocks/$id") }) }
        })
    }.toString()
    private fun blockResourceJson(ns: String, id: String) = buildJsonObject {
        put("format_version", "1.21.0")
        put("minecraft:block", buildJsonObject {
            put("description", buildJsonObject { put("identifier", "$ns:$id") })
            put("components", buildJsonObject { put("minecraft:geometry", "geometry.full_block") })
        })
    }.toString()
    private fun itemJson(i: SbhItem, ns: String, id: String) = buildJsonObject { put("format_version", "1.21.0"); put("minecraft:item", buildJsonObject { put("description", buildJsonObject { put("identifier", "$ns:$id"); put("menu_category", buildJsonObject { put("category", "items") }) }); put("components", buildJsonObject { put("minecraft:max_stack_size", 1); put("minecraft:durability", buildJsonObject { put("max_durability", i.durability) }) }) }) }.toString()
    private fun blockJson(b: SbhBlock, ns: String, id: String) = buildJsonObject { put("format_version", "1.21.0"); put("minecraft:block", buildJsonObject { put("description", buildJsonObject { put("identifier", "$ns:$id") }); put("components", buildJsonObject { put("minecraft:destroy_time", b.hardness) }) }) }.toString()

    private fun splitId(value: String): Pair<String, String> { val p = value.split(":", limit = 2); return p[0] to p[1] }
    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
    private fun writeText(zip: ZipOutputStream, path: String, text: String) { zip.putNextEntry(ZipEntry(path)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry() }
}
