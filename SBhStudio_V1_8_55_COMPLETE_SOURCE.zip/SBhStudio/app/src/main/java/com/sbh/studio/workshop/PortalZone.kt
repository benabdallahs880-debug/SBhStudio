package com.sbh.studio.workshop

// PORTAL_ZONE_FILE_VERSION=1.8.53-clean

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.SectionTitle
import java.util.UUID

internal val PORTAL_DIMENSIONS = listOf(
    "minecraft:overworld",
    "minecraft:nether",
    "minecraft:the_end"
)

internal fun dimensionLabel(id: String): String = when (id) {
    "minecraft:nether" -> "Nether"
    "minecraft:the_end" -> "End"
    else -> "Overworld"
}

private fun portalCodeTokens(line: String): List<String> =
    Regex("\"[^\"]*\"|'[^']*'|\\S+")
        .findAll(line.trim())
        .map { it.value.trim('"', '\'') }
        .toList()

private fun portalCodeUnquote(value: String): String =
    value.trim().trim('"', '\'')

private fun validatePortalCode(source: String): List<String> {
    val errors = mutableListOf<String>()
    source.lines().forEachIndexed { index, raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) return@forEachIndexed
        val t = portalCodeTokens(line)
        when (t.firstOrNull()) {
            "portal.create" ->
                if (t.size < 2) errors += "Ligne ${index + 1} : portal.create(Nom)"
            "portal.size" ->
                if (t.size < 3 || t[1].toIntOrNull() == null || t[2].toIntOrNull() == null)
                    errors += "Ligne ${index + 1} : portal.size(largeur hauteur)"
            "portal.frame" ->
                if (t.size < 2) errors += "Ligne ${index + 1} : portal.frame(namespace:bloc)"
            "portal.destination" ->
                if (t.size < 5 || t[1].toIntOrNull() == null || t[2].toIntOrNull() == null || t[3].toIntOrNull() == null)
                    errors += "Ligne ${index + 1} : portal.destination(X Y Z dimension)"
            "portal.description" ->
                if (t.size < 2) errors += "Ligne ${index + 1} : portal.description(texte)"
            "portal.map" ->
                if (t.size < 5 || t[2].toIntOrNull() == null || t[3].toIntOrNull() == null || t[4].toIntOrNull() == null)
                    errors += "Ligne ${index + 1} : portal.map(mapId X Y Z)"
            else ->
                errors += "Ligne ${index + 1} : commande inconnue"
        }
    }
    return errors
}

private fun applyPortalCode(source: String, base: PortalBlueprint): PortalBlueprint {
    var result = base
    source.lines().forEach { raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) return@forEach
        val t = portalCodeTokens(line)
        when (t.firstOrNull()) {
            "portal.create" ->
                if (t.size >= 2) result = result.copy(name = portalCodeUnquote(t[1]))
            "portal.size" ->
                if (t.size >= 3) result = result.copy(
                    width = t[1].toIntOrNull() ?: result.width,
                    height = t[2].toIntOrNull() ?: result.height
                )
            "portal.frame" ->
                if (t.size >= 2) result = result.copy(frameBlock = portalCodeUnquote(t[1]))
            "portal.destination" ->
                if (t.size >= 5) result = result.copy(
                    destX = t[1].toIntOrNull() ?: result.destX,
                    destY = t[2].toIntOrNull() ?: result.destY,
                    destZ = t[3].toIntOrNull() ?: result.destZ,
                    destDimension = portalCodeUnquote(t[4])
                )
            "portal.description" ->
                if (t.size >= 2) result = result.copy(destinationHint = portalCodeUnquote(t[1]))
            "portal.map" ->
                if (t.size >= 5) result = result.copy(
                    linkedMapId = portalCodeUnquote(t[1]),
                    mapX = t[2].toIntOrNull() ?: result.mapX,
                    mapY = t[3].toIntOrNull() ?: result.mapY,
                    mapZ = t[4].toIntOrNull() ?: result.mapZ
                )
        }
    }
    return result
}

@Composable
internal fun PortalPreview(portal: PortalBlueprint) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Apercu du portail", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
            Text(
                "Vue frontale · ${portal.width}x${portal.height} · ${portal.frameBlock}",
                color = AgwColors.Sand,
                style = MaterialTheme.typography.bodySmall
            )
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(AgwColors.DeepNight)
            ) {
                val cols = portal.width.coerceIn(2, 16)
                val rows = portal.height.coerceIn(3, 16)
                val cell = minOf(size.width / (cols + 4f), size.height / (rows + 4f))
                val totalW = cols * cell
                val totalH = rows * cell
                val left = (size.width - totalW) / 2f
                val top = (size.height - totalH) / 2f
                val frameColor = AgwColors.DesertOchre
                val innerColor = Color(0xFF24163A)
                val glowColor = AgwColors.SacredGold.copy(alpha = 0.28f)
                drawRect(glowColor, Offset(left + cell, top + cell), Size(totalW - 2 * cell, totalH - 2 * cell))
                for (x in 0 until cols) {
                    for (y in 0 until rows) {
                        val isFrame = x == 0 || x == cols - 1 || y == 0 || y == rows - 1
                        drawRect(
                            if (isFrame) frameColor else innerColor,
                            Offset(left + x * cell, top + y * cell),
                            Size(cell - 1.5f, cell - 1.5f)
                        )
                    }
                }
                drawRect(frameColor, Offset(left, top), Size(totalW, totalH), style = Stroke(width = 2f))
            }
            Text(
                "Destination : ${portal.destinationHint} · (${portal.destX}, ${portal.destY}, ${portal.destZ}) · ${dimensionLabel(portal.destDimension)}",
                color = AgwColors.DesertOchre,
                style = MaterialTheme.typography.bodySmall
            )
            portal.linkedMapId?.let { mapId ->
                Text(
                    "Map liee : $mapId · (${portal.mapX}, ${portal.mapY}, ${portal.mapZ})",
                    color = AgwColors.Sand,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
internal fun PortalZone(
    projectId: String,
    portals: List<PortalBlueprint>,
    maps: List<MapBlueprint> = emptyList(),
    textures: List<TextureProject> = emptyList(),
    blocks: List<SbhBlock> = emptyList(),
    onSave: (PortalBlueprint) -> Unit,
    onDelete: (PortalBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var tab by rememberSaveable { mutableStateOf(0) }
    var code by rememberSaveable { mutableStateOf("") }

    var name by rememberSaveable { mutableStateOf("Portail Al-Zahra") }
    var identifier by rememberSaveable { mutableStateOf("agw:portal_custom") }
    var width by rememberSaveable { mutableStateOf("4") }
    var height by rememberSaveable { mutableStateOf("5") }
    var frame by rememberSaveable { mutableStateOf("agw:night_bricks") }
    var dest by rememberSaveable { mutableStateOf("Al-Zahra") }
    var destX by rememberSaveable { mutableStateOf("0") }
    var destY by rememberSaveable { mutableStateOf("64") }
    var destZ by rememberSaveable { mutableStateOf("0") }
    var destDim by rememberSaveable { mutableStateOf(PORTAL_DIMENSIONS[0]) }
    var linkedMapId by rememberSaveable { mutableStateOf<String?>(null) }
    var mapX by rememberSaveable { mutableStateOf("0") }
    var mapY by rememberSaveable { mutableStateOf("64") }
    var mapZ by rememberSaveable { mutableStateOf("0") }
    var frameTextureId by rememberSaveable { mutableStateOf<String?>(null) }
    var notes by rememberSaveable { mutableStateOf("") }

    fun currentPortal(keepId: String? = editingId): PortalBlueprint = PortalBlueprint(
        id = keepId ?: UUID.randomUUID().toString(),
        projectId = projectId,
        name = name.trim().ifBlank { "Portail" },
        identifier = identifier.trim().ifBlank { "agw:portal_custom" },
        width = width.toIntOrNull()?.coerceIn(2, 16) ?: 4,
        height = height.toIntOrNull()?.coerceIn(3, 16) ?: 5,
        frameBlock = frame.trim().ifBlank { "agw:night_bricks" },
        destinationHint = dest,
        destX = destX.toIntOrNull() ?: 0,
        destY = destY.toIntOrNull() ?: 64,
        destZ = destZ.toIntOrNull() ?: 0,
        destDimension = destDim,
        linkedMapId = linkedMapId,
        mapX = mapX.toIntOrNull() ?: 0,
        mapY = mapY.toIntOrNull() ?: 64,
        mapZ = mapZ.toIntOrNull() ?: 0,
        frameTextureId = frameTextureId,
        notes = notes
    )

    fun loadIntoForm(p: PortalBlueprint) {
        editingId = p.id
        name = p.name
        identifier = p.identifier
        width = p.width.toString()
        height = p.height.toString()
        frame = p.frameBlock
        dest = p.destinationHint
        destX = p.destX.toString()
        destY = p.destY.toString()
        destZ = p.destZ.toString()
        destDim = p.destDimension
        linkedMapId = p.linkedMapId
        mapX = p.mapX.toString()
        mapY = p.mapY.toString()
        mapZ = p.mapZ.toString()
        frameTextureId = p.frameTextureId
        notes = p.notes
        tab = 0
        code = buildString {
            appendLine("portal.create(\"${p.name}\")")
            appendLine("portal.size(${p.width} ${p.height})")
            appendLine("portal.frame(\"${p.frameBlock}\")")
            appendLine("portal.destination(${p.destX} ${p.destY} ${p.destZ} \"${p.destDimension}\")")
            append("portal.description(\"${p.destinationHint}\")")
            if (p.linkedMapId != null) {
                appendLine()
                append("portal.map(\"${p.linkedMapId}\" ${p.mapX} ${p.mapY} ${p.mapZ})")
            }
        }
    }

    fun resetForm() {
        editingId = null
        name = "Portail Al-Zahra"
        identifier = "agw:portal_custom"
        width = "4"
        height = "5"
        frame = "agw:night_bricks"
        dest = "Al-Zahra"
        destX = "0"
        destY = "64"
        destZ = "0"
        destDim = PORTAL_DIMENSIONS[0]
        linkedMapId = null
        mapX = "0"
        mapY = "64"
        mapZ = "0"
        frameTextureId = null
        notes = ""
        code = ""
        tab = 0
    }

    val filtered = remember(portals, search) {
        portals.filter { p ->
            val q = search.trim().lowercase()
            q.isEmpty() ||
                p.name.lowercase().contains(q) ||
                p.identifier.lowercase().contains(q) ||
                p.destinationHint.lowercase().contains(q)
        }
    }
    val blockIds = remember(blocks) { blocks.map { it.identifier to it.name } }

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
    ) {
        SectionTitle("Portails")
        Text(
            "${portals.size} portail(s) · atelier libre",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        WorkshopSearchField(search, { search = it }, "Rechercher")

        Text(
            "Liste (${filtered.size})",
            fontWeight = FontWeight.SemiBold,
            color = AgwColors.SacredGold
        )
        if (filtered.isEmpty()) {
            Text("Aucun portail. Cree-en un ci-dessous.", color = AgwColors.Sand)
        } else {
            filtered.forEach { p ->
                WorkshopListCard(
                    title = p.name,
                    subtitle = "${p.identifier} · ${p.width}x${p.height} · ${p.frameBlock}",
                    extra = "-> ${p.destinationHint} (${p.destX}, ${p.destY}, ${p.destZ})",
                    selected = p.id == editingId,
                    onClick = { loadIntoForm(p) },
                    onDelete = {
                        if (editingId == p.id) resetForm()
                        onDelete(p)
                    }
                )
            }
        }

        HorizontalDivider(color = AgwColors.Sand.copy(alpha = 0.3f))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    if (editingId == null) "Nouveau portail" else "Modifier le portail",
                    fontWeight = FontWeight.SemiBold,
                    color = AgwColors.SacredGold
                )
                WorkshopTabRow(
                    listOf("Identite", "Cadre", "Destination", "Liens", "Code"),
                    tab
                ) { tab = it }

                when (tab) {
                    0 -> {
                        OutlinedTextField(
                            name, { name = it },
                            label = { Text("Nom") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            identifier, { identifier = it },
                            label = { Text("Identifiant") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                width, { width = it },
                                label = { Text("Largeur") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                height, { height = it },
                                label = { Text("Hauteur") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                        OutlinedTextField(
                            notes, { notes = it },
                            label = { Text("Notes") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    1 -> {
                        OutlinedTextField(
                            frame, { frame = it },
                            label = { Text("Bloc cadre") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        WorkshopIdPickerRow("Blocs du projet", blockIds, frame) { frame = it }
                        StudioTexturePicker(
                            textures = textures,
                            selectedUri = frameTextureId,
                            onSelect = { frameTextureId = it },
                            preferredFormats = listOf("BLOCK_16", "BLOCK_32", "FILTER_MAP")
                        )
                        if (frameTextureId != null) {
                            TextButton(onClick = { frameTextureId = null }) {
                                Text("Retirer texture")
                            }
                        }
                        PortalPreview(currentPortal())
                    }
                    2 -> {
                        OutlinedTextField(
                            dest, { dest = it },
                            label = { Text("Description destination") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                destX, { destX = it },
                                label = { Text("X") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                destY, { destY = it },
                                label = { Text("Y") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                destZ, { destZ = it },
                                label = { Text("Z") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                        Text("Dimension", color = AgwColors.Sand, fontSize = 12.sp)
                        WorkshopFilterRow(
                            PORTAL_DIMENSIONS.map { it to dimensionLabel(it) },
                            destDim
                        ) { destDim = it }
                    }
                    3 -> {
                        Text("Map liee", color = AgwColors.Sand, fontSize = 12.sp)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            FilterChip(
                                selected = linkedMapId == null,
                                onClick = { linkedMapId = null },
                                label = { Text("Aucune", fontSize = 11.sp) }
                            )
                            maps.forEach { m ->
                                FilterChip(
                                    selected = linkedMapId == m.id,
                                    onClick = { linkedMapId = m.id },
                                    label = { Text(m.name.take(16), fontSize = 11.sp) }
                                )
                            }
                        }
                        if (linkedMapId != null) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(
                                    mapX, { mapX = it },
                                    label = { Text("Map X") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    mapY, { mapY = it },
                                    label = { Text("Map Y") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    mapZ, { mapZ = it },
                                    label = { Text("Map Z") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                    }
                    4 -> {
                        OutlinedTextField(
                            code, { code = it },
                            label = { Text("Script portail") },
                            minLines = 5,
                            modifier = Modifier.fillMaxWidth()
                        )
                        validatePortalCode(code).take(5).forEach { err ->
                            Text("• $err", color = AgwColors.Warning, fontSize = 11.sp)
                        }
                        GoldOutlineButton(
                            "Appliquer le code au formulaire",
                            onClick = {
                                val parsed = applyPortalCode(code, currentPortal())
                                name = parsed.name
                                width = parsed.width.toString()
                                height = parsed.height.toString()
                                frame = parsed.frameBlock
                                dest = parsed.destinationHint
                                destX = parsed.destX.toString()
                                destY = parsed.destY.toString()
                                destZ = parsed.destZ.toString()
                                destDim = parsed.destDimension
                                linkedMapId = parsed.linkedMapId
                                mapX = parsed.mapX.toString()
                                mapY = parsed.mapY.toString()
                                mapZ = parsed.mapZ.toString()
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                WorkshopEditorActions(
                    isEditing = editingId != null,
                    onSave = {
                        onSave(currentPortal())
                        if (editingId == null) resetForm()
                    },
                    onDuplicate = {
                        onSave(
                            currentPortal(null).copy(
                                name = "$name (copie)",
                                identifier = workshopIdCopy(identifier.trim())
                            )
                        )
                    },
                    onNew = { resetForm() }
                )
            }
        }
    }
}
