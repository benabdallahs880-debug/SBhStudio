package com.sbh.studio.workshop

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton

/**
 * Socle UI atelier (phase A) — motifs partagés liste / onglets / actions.
 * Les zones restent libres : pas de génération forcée.
 */

@Composable
internal fun WorkshopSearchField(
    value: String,
    onChange: (String) -> Unit,
    label: String = "Rechercher"
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
internal fun WorkshopFilterRow(
    options: List<Pair<String, String>>, // id to label
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
    ) {
        options.forEach { (id, label) ->
            FilterChip(
                selected = selected == id,
                onClick = { onSelect(id) },
                label = { Text(label, fontSize = 11.sp) }
            )
        }
    }
}

@Composable
internal fun WorkshopTabRow(
    tabs: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit
) {
    TabRow(selectedTabIndex = selected, containerColor = AgwColors.DeepNight) {
        tabs.forEachIndexed { i, label ->
            Tab(
                selected = selected == i,
                onClick = { onSelect(i) },
                text = { Text(label, fontSize = 12.sp) }
            )
        }
    }
}

@Composable
internal fun WorkshopListCard(
    title: String,
    subtitle: String,
    extra: String? = null,
    selected: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    trailing: @Composable RowScope.() -> Unit = {}
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (selected) AgwColors.NightStone else AgwColors.DeepNight
        ),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) Modifier.border(2.dp, AgwColors.SacredGold, RoundedCornerShape(8.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                Text(subtitle, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                if (!extra.isNullOrBlank()) {
                    Text(extra, color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
                }
            }
            trailing()
            TextButton(onClick = onDelete) { Text("X") }
        }
    }
}

@Composable
internal fun WorkshopEditorActions(
    isEditing: Boolean,
    onSave: () -> Unit,
    onDuplicate: (() -> Unit)? = null,
    onNew: (() -> Unit)? = null,
    saveLabel: String = if (isEditing) "Enregistrer" else "Créer"
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        GoldPrimaryButton(saveLabel, onClick = onSave, modifier = Modifier.weight(1f))
        if (isEditing && onDuplicate != null) {
            GoldOutlineButton("Dupliquer", onClick = onDuplicate, modifier = Modifier.weight(1f))
        }
    }
    if (isEditing && onNew != null) {
        TextButton(onClick = onNew, modifier = Modifier.fillMaxWidth()) {
            Text("Nouveau (quitter l'édition)")
        }
    }
}

@Composable
internal fun WorkshopIdPickerRow(
    label: String,
    options: List<Pair<String, String>>, // identifier to display name
    selectedId: String,
    onSelect: (String) -> Unit
) {
    if (options.isEmpty()) return
    Text(label, color = AgwColors.Sand, fontSize = 12.sp)
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
    ) {
        options.take(40).forEach { (id, name) ->
            FilterChip(
                selected = selectedId == id,
                onClick = { onSelect(id) },
                label = { Text(name.ifBlank { id }.take(18), fontSize = 11.sp) }
            )
        }
    }
}

internal fun workshopIdCopy(base: String): String =
    if (base.contains(":")) "${base}_copy" else "agw:${base}_copy"
