package com.sbh.studio.generator

import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobEngine
import com.sbh.studio.data.MobShapeCatalog
import kotlin.math.roundToInt
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/**
 * Génération JSON Bedrock pour les mobs — pure (sans Context).
 * Extract de PackGenerator pour permettre les tests unitaires.
 */
object MobPackJson {

    fun safe(s: String): String = s.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)

    fun textureKey(identifier: String): String = identifier.replace(':', '_')

    fun eggColor(seed: String, value: Float): String {
        val hash = seed.hashCode() and 0x7fffffff
        val h = (hash % 360) / 360.0
        val s = 0.45
        val v = value.coerceIn(0.3f, 0.9f).toDouble()
        val c = v * s
        val x = c * (1 - kotlin.math.abs((h * 6) % 2 - 1))
        val m = v - c
        val (rp, gp, bp) = when ((h * 6).toInt()) {
            0 -> Triple(c, x, 0.0)
            1 -> Triple(x, c, 0.0)
            2 -> Triple(0.0, c, x)
            3 -> Triple(0.0, x, c)
            4 -> Triple(x, 0.0, c)
            else -> Triple(c, 0.0, x)
        }
        val r = ((rp + m) * 255).toInt().coerceIn(0, 255)
        val g = ((gp + m) * 255).toInt().coerceIn(0, 255)
        val b = ((bp + m) * 255).toInt().coerceIn(0, 255)
        return String.format("#%02X%02X%02X", r, g, b)
    }

    /** Behavior pack entity JSON — passe par MobEngine (bornes + familles). */
    fun behaviorEntityJson(m: MobEntity, ns: String, id: String): String {
        val mob = MobEngine.prepareForExport(m)
        val hints = MobEngine.exportHints(mob)
        val speed = ((if (mob.pouvoirVitesse) mob.vitesse * 1.5 else mob.vitesse) * 1000).roundToInt() / 1000.0
        return buildJsonObject {
            put("format_version", "1.21.0")
            putJsonObject("minecraft:entity") {
                putJsonObject("description") {
                    put("identifier", "$ns:$id")
                    put("is_spawnable", true)
                    put("is_summonable", true)
                }
                putJsonObject("components") {
                    putJsonObject("minecraft:type_family") {
                        putJsonArray("family") {
                            hints.familyTags.forEach { add(it) }
                        }
                    }
                    putJsonObject("minecraft:health") { put("value", mob.vie); put("max", mob.vie) }
                    putJsonObject("minecraft:movement") { put("value", speed) }
                    if (mob.pouvoirResistance) putJsonObject("minecraft:damage_sensor") {
                        putJsonArray("triggers") {
                            add(buildJsonObject {
                                put("cause", "all")
                                putJsonObject("deals_damage") { put("value", false) }
                            })
                        }
                    }
                    if (mob.pouvoirInvisibilite) putJsonObject("minecraft:spell_effects") {
                        putJsonArray("add_effects") {
                            add(buildJsonObject {
                                put("effect", "invisibility")
                                put("duration", 2147483647)
                                put("amplifier", 0)
                                put("visible", false)
                            })
                        }
                    }
                    putJsonObject("minecraft:navigation.walk") { put("can_path_over_water", false) }
                    putJsonObject("minecraft:movement.basic") {}
                    putJsonObject("minecraft:jump.static") {}
                    putJsonObject("minecraft:physics") {}
                    putJsonObject("minecraft:collision_box") {
                        put("width", mob.collisionLargeur.coerceIn(0.1, 4.0))
                        put("height", mob.collisionHauteur.coerceIn(0.1, 8.0))
                    }
                    putJsonObject("minecraft:nameable") {}
                    putJsonObject("minecraft:persistent") {}
                    putJsonObject("minecraft:pushable") {
                        put("is_pushable", true)
                        put("is_pushable_by_piston", true)
                    }
                    putJsonObject("minecraft:behavior.float") { put("priority", 0) }
                    putJsonObject("minecraft:behavior.random_stroll") {
                        put("priority", 6)
                        put("speed_multiplier", 0.8)
                    }
                    putJsonObject("minecraft:behavior.look_at_player") {
                        put("priority", 7)
                        put("look_distance", 6)
                        put("probability", 0.02)
                    }
                    putJsonObject("minecraft:behavior.random_look_around") { put("priority", 8) }
                    if (mob.attaque) putJsonObject("minecraft:attack") { put("damage", mob.degats) }
                    val isArcher = mob.profilIA.lowercase() == "archer"
                    if (isArcher && mob.attaque) {
                        val interval = mob.cooldownAttaque.takeIf { it > 0 } ?: 1.0
                        putJsonObject("minecraft:behavior.ranged_attack") {
                            put("priority", 3)
                            put("attack_interval_min", interval.coerceIn(0.5, 30.0))
                            put("attack_interval_max", (interval + 2.0).coerceIn(1.0, 60.0))
                            put("attack_radius", mob.detectionDistance.coerceIn(4.0, 32.0))
                            put("speed_multiplier", mob.vitesseAttaque.coerceIn(0.1, 4.0))
                        }
                        putJsonObject("minecraft:shooter") { put("def", "minecraft:arrow") }
                    } else if (mob.attaque || mob.poursuite) {
                        putJsonObject("minecraft:behavior.melee_attack") {
                            put("priority", 3)
                            put("speed_multiplier", mob.vitesseAttaque.coerceIn(0.1, 4.0))
                            put("track_target", true)
                            if (mob.cooldownAttaque > 0) put("cooldown_time", mob.cooldownAttaque.coerceIn(0.0, 60.0))
                        }
                    }
                    if (mob.reactionDegats) {
                        putJsonObject("minecraft:behavior.hurt_by_target") { put("priority", 1) }
                    }
                    val profileAllowsPursuit = mob.profilIA.lowercase() != "passif"
                    if (mob.poursuite && mob.hostile && profileAllowsPursuit) {
                        putJsonObject("minecraft:behavior.nearest_attackable_target") {
                            put("priority", 2)
                            put("must_see", true)
                            putJsonArray("entity_types") {
                                add(buildJsonObject {
                                    putJsonObject("filters") {
                                        put("test", "is_family")
                                        put("subject", "other")
                                        put("value", "player")
                                    }
                                    put(
                                        "max_dist",
                                        (if (mob.profilIA.lowercase() == "garde") {
                                            minOf(mob.detectionDistance, 16.0)
                                        } else mob.detectionDistance).coerceIn(1.0, 128.0)
                                    )
                                })
                            }
                        }
                    }
                }
            }
        }.toString()
    }

    /** Resource pack client_entity JSON */
    fun clientEntityJson(
        m: MobEntity,
        ns: String,
        id: String,
        textureKey: String,
        hasAnim: Boolean = false
    ): String {
        val mob = MobEngine.prepareForExport(m)
        return buildJsonObject {
        put("format_version", "1.10.0")
        putJsonObject("minecraft:client_entity") {
            putJsonObject("description") {
                put("identifier", "$ns:$id")
                putJsonObject("materials") { put("default", "entity_alphatest") }
                putJsonObject("textures") { put("default", "textures/entity/$textureKey") }
                putJsonObject("geometry") {
                    put("default", MobEngine.exportHints(mob).geometryId)
                }
                putJsonArray("render_controllers") { add("controller.render.default") }
                putJsonObject("spawn_egg") {
                    put("base_color", eggColor(mob.identifiant, 0.6f))
                    put("overlay_color", "#C9A227")
                }
                if (hasAnim) {
                    val animId = mob.identifiant.replace(":", ".")
                    putJsonObject("scripts") {
                        putJsonArray("animate") { add("main") }
                    }
                    putJsonObject("animations") {
                        put("idle", "animation.$animId.idle")
                        put("walk", "animation.$animId.walk")
                        put("run", "animation.$animId.run")
                        put("attack", "animation.$animId.attack")
                        put("hurt", "animation.$animId.hurt")
                        put("sit", "animation.$animId.sit")
                        put("swim", "animation.$animId.swim")
                        put("main", "controller.animation.$animId.main")
                    }
                } else if (mob.formeBase == "humanoid") {
                    putJsonObject("scripts") {
                        putJsonArray("animate") {
                            add("move.arms")
                            add("move.legs")
                            add(buildJsonObject {
                                put("attack.rotations", "q.is_angry || q.is_delayed_attacking")
                            })
                        }
                    }
                    putJsonObject("animations") {
                        put("move.arms", "animation.player.move.arms")
                        put("move.legs", "animation.player.move.legs")
                        put("attack.rotations", "animation.player.attack.rotations")
                    }
                } else {
                    // Animations selon la forme : éviter quadruped.walk sur spider/creeper/zombie.
                    putJsonObject("scripts") {
                        putJsonArray("animate") {
                            add("look_at_target")
                            add("walk")
                        }
                    }
                    putJsonObject("animations") {
                        put("look_at_target", "animation.common.look_at_target")
                        put(
                            "walk",
                            when (mob.formeBase) {
                                "spider" -> "animation.spider.walk"
                                "creeper" -> "animation.creeper.legs"
                                "zombie", "skeleton" -> "animation.humanoid.move"
                                "chicken" -> "animation.chicken.general"
                                "wolf", "cow" -> "animation.quadruped.walk"
                                else -> "animation.quadruped.walk"
                            }
                        )
                    }
                }
            }
        }
    }.toString()
    }

}
