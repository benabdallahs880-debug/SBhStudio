class_name SBHWorld
extends Node3D

const CHUNK_SIZE := 16
var chunks: Dictionary = {}

# Edition par lots : plusieurs modifications peuvent être regroupées en un seul rebuild.
var _edit_depth := 0
var _dirty_chunks: Dictionary = {}


func _ready() -> void:
	create_test_world()


func create_test_world() -> void:
	for x in range(-1, 2):
		for z in range(-1, 2):
			create_chunk(Vector2i(x, z))
	for c in chunks.values():
		c.rebuild()


func create_chunk(coord: Vector2i) -> SBHChunk:
	var chunk := SBHChunk.new()
	chunk.name = "Chunk_%d_%d" % [coord.x, coord.y]
	chunk.chunk_coord = coord
	chunk.world_ref = self
	chunk.position = Vector3(coord.x * CHUNK_SIZE, 0, coord.y * CHUNK_SIZE)
	add_child(chunk)
	chunks[coord] = chunk
	for x in range(CHUNK_SIZE):
		for z in range(CHUNK_SIZE):
			var h := 2
			for y in range(h):
				var id := BlockTypes.Type.STONE if y == 0 else BlockTypes.Type.DIRT
				if y == h - 1:
					id = BlockTypes.Type.GRASS
				chunk.set_block(Vector3i(x, y, z), id)
	return chunk


func world_to_chunk(pos: Vector3i) -> Vector2i:
	return Vector2i(floori(float(pos.x) / CHUNK_SIZE), floori(float(pos.z) / CHUNK_SIZE))


func world_to_local(pos: Vector3i) -> Vector3i:
	var c := world_to_chunk(pos)
	return Vector3i(pos.x - c.x * CHUNK_SIZE, pos.y, pos.z - c.y * CHUNK_SIZE)


func get_block(pos: Vector3i) -> int:
	var c := world_to_chunk(pos)
	var chunk: SBHChunk = chunks.get(c)
	if chunk == null:
		return BlockTypes.Type.AIR
	return chunk.get_block(world_to_local(pos))


func set_block(pos: Vector3i, id: int) -> void:
	var c := world_to_chunk(pos)
	var chunk: SBHChunk = chunks.get(c)
	if chunk == null:
		chunk = create_chunk(c)
	chunk.set_block(world_to_local(pos), id)
	_mark_dirty(c)
	if _edit_depth == 0:
		flush_edits()


## Regroupe les modifications de monde. Toujours appeler end_edit() dans un bloc finally côté appelant.
func begin_edit() -> void:
	_edit_depth += 1


func end_edit() -> void:
	if _edit_depth <= 0:
		_edit_depth = 0
		return
	_edit_depth -= 1
	if _edit_depth == 0:
		flush_edits()


func _mark_dirty(coord: Vector2i) -> void:
	# Le chunk modifié et ses voisins peuvent changer de faces visibles.
	for ox in range(-1, 2):
		for oz in range(-1, 2):
			var c := Vector2i(coord.x + ox, coord.y + oz)
			if chunks.has(c):
				_dirty_chunks[c] = true


func flush_edits() -> void:
	if _dirty_chunks.is_empty():
		return
	var dirty := _dirty_chunks.keys()
	_dirty_chunks.clear()
	for c in dirty:
		var chunk: SBHChunk = chunks.get(c)
		if chunk != null:
			chunk.rebuild()


func _rebuild_neighbor_chunks(coord: Vector2i) -> void:
	# Compatibilité avec les anciens appelants. Les nouvelles opérations passent par _mark_dirty().
	_mark_dirty(coord)
	flush_edits()


func can_place_block(pos: Vector3i, avoid_aabb: AABB) -> bool:
	if get_block(pos) != BlockTypes.Type.AIR:
		return false
	var block_aabb := AABB(Vector3(pos), Vector3.ONE)
	if avoid_aabb.intersects(block_aabb):
		return false
	return true
