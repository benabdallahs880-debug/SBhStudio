class_name SBHPlayer
extends CharacterBody3D

@export var speed := 5.0
@export var jump_velocity := 5.0
@export var mouse_sensitivity := 0.003

var gravity := 14.0
var pitch := 0.0


func _ready() -> void:
	CollisionLayers.setup_player(self)
	floor_snap_length = 0.2
	safe_margin = 0.08
	var cs := get_node_or_null("CollisionShape3D") as CollisionShape3D
	if cs:
		cs.position = Vector3(0, 0.9, 0)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		if Input.is_action_just_pressed("jump"):
			jump()
	var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	var dir := (transform.basis * Vector3(input_vec.x, 0, input_vec.y)).normalized()
	if dir:
		velocity.x = dir.x * speed
		velocity.z = dir.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)
	move_and_slide()


func jump() -> void:
	if is_on_floor():
		velocity.y = jump_velocity


func look_delta(delta_pos: Vector2) -> void:
	rotate_y(-delta_pos.x * mouse_sensitivity)
	pitch = clamp(pitch - delta_pos.y * mouse_sensitivity, -1.4, 1.4)
	$Camera3D.rotation.x = pitch


func body_aabb() -> AABB:
	var cs := get_node_or_null("CollisionShape3D") as CollisionShape3D
	if cs and cs.shape is CapsuleShape3D:
		var cap := cs.shape as CapsuleShape3D
		var size := Vector3(cap.radius * 2.0, cap.height, cap.radius * 2.0)
		var center: Vector3 = global_position + cs.position
		return AABB(center - size * 0.5, size)
	return AABB(global_position + Vector3(-0.35, 0, -0.35), Vector3(0.7, 1.8, 0.7))
