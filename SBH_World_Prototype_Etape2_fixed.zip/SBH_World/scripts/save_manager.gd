class_name SaveManager

const SAVE_PATH := "user://sbh_world_save.json"

static func save_world(world: SBHWorld) -> bool:
	var data := {"blocks": []}
	for coord in world.chunks.keys():
		var chunk: SBHChunk = world.chunks[coord]
		for local_pos in chunk.blocks.keys():
			data.blocks.append({
				"x": coord.x * SBHWorld.CHUNK_SIZE + local_pos.x,
				"y": local_pos.y,
				"z": coord.y * SBHWorld.CHUNK_SIZE + local_pos.z,
				"id": int(chunk.blocks[local_pos])
			})
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(data))
	return true

static func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)

static func load_world(world: SBHWorld) -> bool:
	if not has_save():
		return false
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return false
	var parsed = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		return false
	world.begin_edit()
	for item in parsed.get("blocks", []):
		if not (item is Dictionary):
			continue
		if not item.has("x") or not item.has("y") or not item.has("z") or not item.has("id"):
			continue
		var pos := Vector3i(int(item.x), int(item.y), int(item.z))
		world.set_block(pos, int(item.id))
	world.end_edit()
	return true

static func delete_save() -> void:
	if has_save():
		DirAccess.remove_absolute(SAVE_PATH)
