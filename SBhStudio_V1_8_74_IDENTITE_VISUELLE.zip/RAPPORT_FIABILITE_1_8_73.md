# SBh Studio 1.8.73 — Sauvegardes coordonnées et liaisons réversibles

Cette version améliore le code source 1.8.72. Le composant de journalisation Java a été compilé et testé sur JVM 17. La compilation complète Kotlin/Compose/Android reste bloquée par le téléchargement de Gradle ; aucun APK ni rendu tactile de cette version n'est validé.

## Changements visibles prévus

La bibliothèque commune propose une recherche par nom et notes. Les fiches dont un document manque restent visibles avec un compteur ; une fiche sans document reste également conservée. Un lien manquant peut être retiré de la fiche sans supprimer de fichier.

Les nouvelles liaisons peuvent être annulées. La fiche séparée retrouve son identité, son nom, ses notes, ses références et son origine de duplication. Les liaisons imbriquées conservent leurs dépendances. Les anciennes liaisons de 1.8.72 ne stockaient pas les références d'origine : leur annulation automatique reste désactivée, plutôt que deviner quels documents transférer.

Au démarrage, le Studio termine les sauvegardes coordonnées interrompues avant de charger les listes. Une récupération impossible affiche le problème et un bouton Réessayer la récupération. Les nouvelles sauvegardes SafeStore sont bloquées tant que le conflit n'est pas résolu. L'Atelier dispose aussi de ce contrôle lorsque l'interruption survient pendant son utilisation.

## Problème corrigé dans les passerelles

En 1.8.72, Ajouter un comportement pouvait enregistrer son lien commun avant sa fiche MobEntity. Une panne intermédiaire laissait une référence manquante. La duplication pouvait publier son maillage, puis échouer avant ses autres documents. Le placement sur carte modifiait plusieurs fichiers séparément.

Les quatre opérations communes qui modifient plusieurs documents — import dans le Modeleur, ajout de comportement, préparation du placement sur carte et duplication — passent maintenant par AtomicFileTransaction. Leurs résultats ne sont publiés dans l'état de l'interface qu'après la validation des fichiers.

L'opération prépare des copies temporaires de tous ses fichiers, y compris les GLB, aperçus et index. Les lectures effectuées dans cette même opération voient ses modifications préparées ; les fichiers utilisés normalement par l'application restent inchangés jusqu'à la validation.

| État du journal | Traitement après interruption |
| --- | --- |
| PREPARING | Abandonner les fichiers préparés ; aucune écriture définitive n'a commencé. |
| READY | Vérifier les empreintes, puis terminer exactement le plan déjà préparé. |
| COMMITTED | Les fichiers sont validés ; nettoyer les fichiers du journal. |

Le journal contient les chemins relatifs, les empreintes avant/après et les copies attendues. Il vérifie toutes les cibles avant de reprendre. Un fichier modifié indépendamment ou une copie temporaire altérée bloque la récupération et conserve le journal. Il ne remplace pas automatiquement ce fichier par une version devinée.

Le mécanisme repose sur des écritures temporaires, synchronisation du contenu et déplacement atomique quand le système de fichiers le permet. La synchronisation du dossier est effectuée au mieux : sa disponibilité sur Android reste à vérifier. Les essais simulent des interruptions du code ; ils ne prouvent pas la résistance à une panne matérielle du téléphone.

## Modules touchés

- data/AtomicFileTransaction.java : moteur Java sans dépendance Android, préparation, empreintes, validation, reprise et verrou partagé.
- data/SafeStore.kt : textes et octets utilisent ce moteur pendant une opération coordonnée ; les autres écritures gardent une sauvegarde atomique par fichier.
- mesh/MeshStore.kt et creature/CreatureBody.kt : les écritures des maillages/aperçus passent par SafeStore. Les verrous sont pris dans un ordre commun pour éviter un blocage entre registre et index.
- creation/CreationCopies.kt et CreationModelFiles.kt : les copies n'écrivent plus directement leurs fichiers en contournant le mécanisme.
- creation/CommonCreation.kt : références et parenté des anciennes fiches liées, annulation d'une liaison, retrait d'une référence.
- creation/CommonCreationRepository.kt : format 2 ; lecture du format 1 conservée. Un ancien Studio 1.8.72 refusera le format 2 plutôt que perdre silencieusement ses nouvelles informations.
- MainActivity et WorkshopScreen : récupération hors du thread principal avant chargement, opérations coordonnées et publication des résultats après validation.
- CommonCreationDialog et CreatureZone : recherche, diagnostics, séparation des fiches et rapport installé.

## Validation réalisée

Le vrai moteur Java a été compilé et a passé 40 contrôles : lectures des modifications préparées, plusieurs écritures du même fichier, exception avant validation, interruption après chaque remplacement de fichier, reprise répétée, conflit avec un fichier modifié, blocage des sauvegardes suivantes, chemins externes, lien symbolique sortant du stockage, copie temporaire altérée et sérialisation de deux écrivains.

Commande reproductible depuis la racine du projet :

    mkdir -p /tmp/sbh-transaction-classes
    java com.sun.tools.javac.Main -d /tmp/sbh-transaction-classes app/src/main/java/com/sbh/studio/data/AtomicFileTransaction.java tools/creation/AtomicFileTransactionCheck.java
    java -cp /tmp/sbh-transaction-classes com.sbh.studio.data.AtomicFileTransactionCheck

Les six aperçus des modèles restent contrôlés sans aucune écriture. L'intégration JavaScript du Modeleur passe : masques, sauvegarde, historique, reconstruction refusée, coups de pinceau, formes et forge. Le rendu de ces tests est simulé ; aucune capture réelle n'est annoncée.

Les tests JUnit d'identité ont été étendus pour l'annulation simple, les liaisons imbriquées, les anciennes fiches et les documents manquants. Ils restent à exécuter avec la compilation Kotlin. La tentative de compilation complète échoue avant le compilateur, faute de téléchargement de Gradle 8.11.1.

## Limites et reprise

Le journal coordonne les quatre nouvelles passerelles. Il ne rend pas transactionnelles toutes les opérations de tous les ateliers. Les écrivains qui contournent SafeStore et les modifications provenant d'un autre processus ne partagent pas son verrou. Les listes complètes des anciens dépôts peuvent encore subir un écrasement logique par une sauvegarde provenant d'un ancien état de l'interface ; généraliser les révisions et les mises à jour par identifiant reste nécessaire.

La remise en état d'un véritable conflit de fichier reste manuelle : le système préserve le journal et refuse de trancher. Les journaux READY peuvent nécessiter de l'espace supplémentaire pour terminer leur validation. Les performances mémoire/énergie et la synchronisation des dossiers n'ont pas été mesurées sur Android.

La transmission vers Map Studio est préparée durablement, mais sa demande en mémoire PendingMapImport et la sauvegarde ultérieure de la carte restent séparées. Une interruption après validation avant ouverture de Map Studio nécessite de relancer Placer sur la carte ; elle ne perd pas les documents liés.

Les limites des outils 1.8.72 restent valables : pas de conversion automatique d'un corps CreatureStudio vers le Modeleur, pas de rig automatique d'un GLB sculpté, pas d'exécution Godot des comportements et pas encore d'export complet du jeu. Le mannequin n'est pas remodelé dans cette livraison.

Prochaine validation : compiler testDebugUnitTest et assembleDebug, puis simuler une fermeture forcée, le stockage plein, un retour vers l'Accueil et plusieurs modifications successives sur le téléphone. Mesurer ensuite les grosses duplications avant d'annoncer un gain de fluidité.
