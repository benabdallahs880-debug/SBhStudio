package com.sbh.studio.creation

import org.junit.Assert.*
import org.junit.Test

class MeshImportPolicyTest {
    private val simple = """{"nodes":[{"mesh":0}],"meshes":[{"primitives":[{"attributes":{"POSITION":0}}]}],"accessors":[{"componentType":5126}],"buffers":[{"byteLength":36}]}"""
    @Test fun simpleSurfaceIsAccepted() { assertNull(MeshImportPolicy.problem(simple)) }
    @Test fun rigsAnimationsAndTexturesAreRejected() {
        listOf("skins", "animations", "textures", "images", "extensionsUsed").forEach { key ->
            assertNotNull(key, MeshImportPolicy.problem(simple.dropLast(1) + ",\"$key\":[{}]}"))
        }
    }
    @Test fun hierarchyMatrixAndExternalBufferAreRejected() {
        assertNotNull(MeshImportPolicy.problem(simple.replace("\"mesh\":0", "\"mesh\":0,\"children\":[1]")))
        assertNotNull(MeshImportPolicy.problem(simple.replace("\"mesh\":0", "\"mesh\":0,\"matrix\":[]")))
        assertNotNull(MeshImportPolicy.problem(simple.replace("\"byteLength\":36", "\"byteLength\":36,\"uri\":\"x.bin\"")))
    }
    @Test fun vertexColorsUvAndMorphsAreRejected() {
        listOf("COLOR_0", "TEXCOORD_0").forEach { key -> assertNotNull(MeshImportPolicy.problem(simple.replace("\"POSITION\":0", "\"POSITION\":0,\"$key\":1"))) }
        assertNotNull(MeshImportPolicy.problem(simple.replace("\"attributes\":", "\"targets\":[],\"attributes\":")))
    }
    @Test fun invalidOrEmptyInputIsRejected() {
        assertNotNull(MeshImportPolicy.problem("broken"))
        assertNotNull(MeshImportPolicy.problem("{}"))
    }
}
