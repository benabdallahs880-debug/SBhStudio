package com.sbh.studio.creation

import org.junit.Assert.*
import org.junit.Test

class CreationIdentityTest {
    private val mesh = CreationRef(CreationSource.MESH, "same-id")
    private val mob = CreationRef(CreationSource.MOB, "same-id")
    @Test fun discoveryIsIdempotentAndNamespacesAreIndependent() {
        val sources = listOf(CreationDescriptor(mesh, "Corps"), CreationDescriptor(mob, "Comportement"))
        val first = CreationIdentity.reconcile("p", emptyList(), sources)
        assertEquals(2, first.size)
        assertNotEquals(first[0].id, first[1].id)
        assertNotEquals(CreationIdentity.id("p", mesh), CreationIdentity.id("q", mesh))
        assertEquals(first, CreationIdentity.reconcile("p", first, sources + sources))
    }
    @Test fun discoveryKeepsUserMetadataAndMissingSources() {
        val old = CommonCreation("id", "p", "Nom choisi", listOf(mesh), notes = "À finir")
        assertEquals(listOf(old), CreationIdentity.reconcile("p", listOf(old), listOf(CreationDescriptor(mesh, "Ancien nom"))))
        assertEquals(listOf(old), CreationIdentity.reconcile("p", listOf(old), emptyList()))
        assertTrue(CreationIdentity.resolve(old, emptySet()).isEmpty())
    }
    @Test fun attachDoesNotDuplicateOwnership() {
        val c = CommonCreation("a", "p", "Corps", listOf(mesh))
        val attached = CreationIdentity.attach(listOf(c), c.id, mob)
        assertEquals(listOf(mesh, mob), attached.single().refs)
        assertEquals(attached, CreationIdentity.attach(attached, c.id, mob))
        assertThrows(IllegalArgumentException::class.java) { CreationIdentity.attach(attached + CommonCreation("b", "p", "Autre", emptyList()), "b", mob) }
    }
    @Test fun mergePreservesFormerIdentityAndDoesNotRediscoverIt() {
        val a = CommonCreation("a", "p", "Corps", listOf(mesh))
        val b = CommonCreation("b", "p", "Âme", listOf(mob), notes = "Patrouille")
        val linked = CreationIdentity.merge(listOf(a, b), "a", "b")
        assertEquals(listOf(mesh, mob), linked.single().refs)
        assertEquals(CreationAlias("b", "Âme", "Patrouille", listOf(mob)), linked.single().aliases.single())
        assertEquals(linked, CreationIdentity.reconcile("p", linked, listOf(CreationDescriptor(mob, "Âme"))))
    }
    @Test fun duplicationNeedsIndependentDocumentsAndIdentities() {
        val a = CommonCreation("a", "p", "Corps", listOf(mesh), aliases = listOf(CreationAlias("old", "Ancien", "")))
        assertThrows(IllegalArgumentException::class.java) { CreationIdentity.duplicate(a, listOf(mesh)) }
        val copied = CreationIdentity.duplicate(a, listOf(mesh.copy(id = "new")), "copy")
        assertEquals("a", copied.originId)
        assertTrue(copied.aliases.isEmpty())
        assertNotEquals(a.refs, copied.refs)
    }
    @Test fun crossProjectAndDuplicateReferencesAreRejected() {
        val a = CommonCreation("a", "p", "A", listOf(mesh))
        assertThrows(IllegalArgumentException::class.java) { CreationIdentity.reconcile("q", listOf(a), emptyList()) }
        assertThrows(IllegalArgumentException::class.java) { CreationIdentity.reconcile("p", listOf(a, a.copy(id = "b")), emptyList()) }
        assertThrows(IllegalArgumentException::class.java) { CreationIdentity.merge(listOf(a, a.copy(id = "b", projectId = "q", refs = listOf(mob))), "a", "b") }
    }
    @Test fun unlinkRestoresIdentityNameNotesAndDocuments() {
        val a = CommonCreation("a", "p", "Corps", listOf(mesh), notes = "Forme")
        val b = CommonCreation("b", "p", "Âme", listOf(mob), notes = "Patrouille")
        val linked = CreationIdentity.merge(listOf(a, b), "a", "b")
        assertEquals(listOf(a, b), CreationIdentity.unlink(linked, "a", "b"))
    }
    @Test fun nestedLinksCanBeUndoneInEitherOrder() {
        val image = CreationRef(CreationSource.CHARACTER, "image")
        val a = CommonCreation("a", "p", "Corps", listOf(mesh))
        val b = CommonCreation("b", "p", "Âme", listOf(mob))
        val c = CommonCreation("c", "p", "Image", listOf(image))
        val nested = CreationIdentity.merge(CreationIdentity.merge(listOf(a,b,c), "b", "c"), "a", "b")
        val restoreParent = CreationIdentity.unlink(nested, "a", "b")
        assertEquals(listOf(mob,image), restoreParent.first { it.id=="b" }.refs)
        assertEquals("c", restoreParent.first { it.id=="b" }.aliases.single().id)
        val restoreChild = CreationIdentity.unlink(nested, "a", "c")
        assertEquals(listOf(image), restoreChild.first { it.id=="c" }.refs)
        assertEquals(listOf(mob), restoreChild.first { it.id=="a" }.aliases.single().refs)
        val restored = CreationIdentity.unlink(restoreChild,"a","b")
        assertEquals(setOf(a,b,c),restored.toSet())
    }
    @Test fun oldAliasesAreNotGuessedAndMissingLinksCanBeDetached() {
        val old = CommonCreation("a","p","Corps",listOf(mesh,mob),aliases=listOf(CreationAlias("b","Âme","")))
        assertThrows(IllegalArgumentException::class.java) { CreationIdentity.unlink(listOf(old),"a","b") }
        assertEquals(listOf(mesh),CreationIdentity.detach(listOf(old),"a",mob).single().refs)
        assertEquals("Corps",CreationIdentity.detach(listOf(old),"a",mob).single().name)
    }
}
