package com.sbh.studio.contract

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * SBH Data Contract v1 : le validateur du Studio doit donner EXACTEMENT les résultats attendus de
 * contract/conformance/expected.json (les mêmes que le validateur de référence et celui de Godot).
 */
class ContractConformanceTest {

    private val contractDir: File = listOf(File("../contract"), File("contract"), File("../../contract"))
        .firstOrNull { File(it, "conformance/expected.json").isFile }
        ?: error("dossier contract/ introuvable depuis ${File(".").absolutePath}")

    @Test
    fun allConformanceCasesMatch() {
        val failures = ContractConformance.run(contractDir)
        assertTrue("Cas non conformes :\n" + failures.joinToString("\n"), failures.isEmpty())
    }

    @Test
    fun exampleWorldIsValid() {
        val schemas = ContractValidator.Schemas.fromDirectory(File(contractDir, "schemas"))
        val r = ContractValidator.validatePackage(File(contractDir, "examples/al_zahra_mini"), schemas)
        assertEquals(emptyList<List<String>>(), ContractValidator.triples(r))
    }

    @Test
    fun jsonReaderHandlesUnicodeAndNumbers() {
        @Suppress("UNCHECKED_CAST")
        val m = SbhJson.parse("""{"a":"🦉 é","n":-1.5e2,"i":42,"b":[true,null]}""") as Map<String, Any?>
        assertEquals("🦉 é", m["a"])
        assertEquals(-150.0, m["n"])
        assertEquals(42.0, m["i"])
        assertEquals(listOf(true, SbhJson.Null), m["b"])
    }
}
