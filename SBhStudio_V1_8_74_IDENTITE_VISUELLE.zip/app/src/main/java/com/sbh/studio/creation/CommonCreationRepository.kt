package com.sbh.studio.creation

import android.content.Context
import com.sbh.studio.data.SafeStore
import com.sbh.studio.data.AtomicFileTransaction
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.security.MessageDigest

@Serializable
private data class CreationDocument(val version: Int = 2, val projectId: String, val items: List<CommonCreation>)

class CommonCreationRepository(context: Context) {
    private val root = File(context.filesDir, "common_creations")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private fun file(projectId: String): File {
        val key = MessageDigest.getInstance("SHA-256").digest(projectId.toByteArray()).joinToString("") { "%02x".format(it) }
        return File(root, "$key.json")
    }
    private fun read(projectId: String): List<CommonCreation> {
        val f = file(projectId)
        val text = SafeStore.readText(f) ?: return emptyList()
        val d = try { json.decodeFromString(CreationDocument.serializer(), text) }
        catch (e: Exception) { SafeStore.backupCorrupt(f); throw IllegalStateException("Fiche commune illisible ; sauvegarde conservée", e) }
        require(d.version in 1..2 && d.projectId == projectId) { "Version ou projet du registre non pris en charge" }
        return CreationIdentity.reconcile(projectId, d.items, emptyList())
    }
    fun discover(projectId: String, sources: List<CreationDescriptor>): List<CommonCreation> = update(projectId) {
        CreationIdentity.reconcile(projectId, it, sources)
    }
    fun update(projectId: String, change: (List<CommonCreation>) -> List<CommonCreation>): List<CommonCreation> = synchronized(AtomicFileTransaction.LOCK) {
        val old = read(projectId)
        val next = change(old)
        CreationIdentity.reconcile(projectId, next, emptyList())
        if (next != old) SafeStore.write(file(projectId), json.encodeToString(CreationDocument.serializer(), CreationDocument(projectId = projectId, items = next)))
        next
    }
}
