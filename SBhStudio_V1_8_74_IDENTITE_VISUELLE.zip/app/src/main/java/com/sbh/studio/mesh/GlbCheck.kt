package com.sbh.studio.mesh

/**
 * V1.8.65 — contrôle d'un fichier .glb (glTF 2.0 binaire) avant de l'enregistrer.
 * Kotlin pur (aucune dépendance Android) : testé avec kotlinc (tools/meshstudio/GlbCheckTest.kt).
 * Mêmes règles que le contrat SBH (code E_MESH) : en-tête « glTF », version 2, longueur annoncée =
 * taille réelle, 1er bloc = JSON dans les bornes, 2e bloc éventuel = BIN dans les bornes.
 */
object GlbCheck {
    const val MAX_BYTES = 32 * 1024 * 1024

    private fun u32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    /** null si le fichier est un .glb bien formé, sinon la raison (en français). */
    fun problem(bytes: ByteArray): String? {
        if (bytes.size > MAX_BYTES) return "fichier trop gros (${bytes.size / 1024 / 1024} Mo, maximum ${MAX_BYTES / 1024 / 1024} Mo)"
        if (bytes.size < 20) return "fichier trop court pour un .glb"
        if (u32(bytes, 0) != 0x46546C67L) return "ce n'est pas un fichier .glb (en-tête « glTF » absent)"
        val version = u32(bytes, 4)
        if (version != 2L) return "glTF version $version non prise en charge (2 attendue)"
        if (u32(bytes, 8) != bytes.size.toLong()) return "longueur annoncée ${u32(bytes, 8)} ≠ taille réelle ${bytes.size}"
        val jlen = u32(bytes, 12)
        if (u32(bytes, 16) != 0x4E4F534AL) return "le premier bloc n'est pas le bloc JSON"
        if (jlen == 0L || 20 + jlen > bytes.size) return "bloc JSON hors du fichier"
        val p = 20 + jlen.toInt()
        if (p < bytes.size) {
            if (p + 8 > bytes.size) return "bloc binaire tronqué"
            val blen = u32(bytes, p)
            if (u32(bytes, p + 4) != 0x004E4942L) return "le deuxième bloc n'est pas le bloc BIN"
            if (p + 8 + blen > bytes.size) return "bloc binaire hors du fichier"
        }
        return null
    }

    /** Texte du bloc JSON (UTF-8), ou null si le fichier est invalide. */
    fun jsonChunk(bytes: ByteArray): String? =
        if (problem(bytes) != null) null else String(bytes, 20, u32(bytes, 12).toInt(), Charsets.UTF_8)
}
