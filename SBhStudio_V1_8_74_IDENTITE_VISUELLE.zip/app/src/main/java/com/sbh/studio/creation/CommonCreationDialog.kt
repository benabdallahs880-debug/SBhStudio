package com.sbh.studio.creation

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.character.CharacterPreview3D
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** One document card; editors remain specialized and capability limitations are visible. */
@Composable
fun CommonCreationDialog(
    creations: List<CommonCreation>, available: Set<CreationRef>, initialId: String?, busy: Boolean,
    templates: List<Pair<String, String>>,
    thumbnail: @Composable (CreationRef) -> ImageBitmap?,
    modelUri: (CommonCreation) -> String?,
    onSave: (CommonCreation) -> Unit, onLegacy: (CreationRef) -> Unit,
    onModeler: (CommonCreation) -> Unit, onBehavior: (CommonCreation) -> Unit,
    onAnimate: (CommonCreation) -> Unit, onMap: (CommonCreation) -> Unit,
    onDuplicate: (CommonCreation) -> Unit, onTemplatePreview: (String) -> Unit,
    onLink: (CommonCreation, CommonCreation) -> Unit,
    onUnlink: (CommonCreation, String) -> Unit,
    onDetachMissing: (CommonCreation, CreationRef) -> Unit,
    onTemplateCopy: (String) -> Unit, onClose: () -> Unit
) {
    var selected by remember { mutableStateOf(initialId) }
    val creation = creations.firstOrNull { it.id == selected || it.aliases.any { a -> a.id == selected } }
    var name by remember(creation?.id, creation?.name) { mutableStateOf(creation?.name.orEmpty()) }
    var notes by remember(creation?.id, creation?.notes) { mutableStateOf(creation?.notes.orEmpty()) }
    var showModel by remember(creation?.id) { mutableStateOf(false) }
    var showLinks by remember(creation?.id) { mutableStateOf(false) }
    var showReport by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var report by remember { mutableStateOf("") }
    val context = LocalContext.current
    LaunchedEffect(showReport) {
        if (showReport && report.isEmpty()) report = withContext(Dispatchers.IO) {
            listOf("RAPPORT_VISUEL_1_8_74.md", "RAPPORT_FIABILITE_1_8_73.md").joinToString("\n\n---\n\n") { file ->
                runCatching { context.assets.open("reports/$file").bufferedReader().use { it.readText() } }.getOrDefault("Rapport indisponible : $file")
            }
        }
    }
    Dialog(onDismissRequest = { if (!busy) onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = AgwColors.DeepNight) {
            LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    TextButton(enabled = !busy, onClick = { if (selected != null) selected = null else onClose() }) { Text(if (selected != null) "← Bibliothèque commune" else "← Atelier") }
                    Text(if (creation == null) "Bibliothèque de créations" else "Fiche commune", color = AgwColors.SacredGold, style = MaterialTheme.typography.titleLarge)
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    TextButton(onClick = { showReport = !showReport }) { Text(if (showReport) "Masquer le rapport" else "Rapport et prochaines étapes") }
                    if (showReport) Text(report.ifEmpty { "Chargement…" }, color = AgwColors.Sand)
                }
                if (creation != null) {
                    val resolved = CreationIdentity.resolve(creation, available)
                    item {
                        val model = modelUri(creation)
                        if (model != null) {
                            TextButton(enabled = !busy, onClick = { showModel = !showModel }) { Text(if (showModel) "Fermer l'aperçu 3D" else "Afficher l'aperçu 3D") }
                            if (showModel) key(model) { CharacterPreview3D(modelUri = model, modifier = Modifier.fillMaxWidth().height(280.dp)) }
                        }
                        Text("Identité : ${creation.id}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(name, { name = it.take(120) }, label = { Text("Nom commun") }, enabled = !busy, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(notes, { notes = it.take(8000) }, label = { Text("Notes communes") }, enabled = !busy, modifier = Modifier.fillMaxWidth())
                        TextButton(enabled = !busy && name.isNotBlank(), onClick = { onSave(creation.copy(name = name.trim(), notes = notes)) }) { Text("Enregistrer la fiche") }
                        Text("Le nom commun n'écrase pas les noms des documents de chaque atelier.", color = AgwColors.Sand)
                        creation.aliases.forEach { a ->
                            Text("Fiche reliée : ${a.name}" + if (a.notes.isNotBlank()) " · ${a.notes}" else "", color = AgwColors.Sand)
                            TextButton(enabled = !busy && a.refs.isNotEmpty(), onClick = { onUnlink(creation, a.id) }) { Text("Annuler cette liaison") }
                            if (a.refs.isEmpty()) Text("Ancienne liaison : les documents d'origine ne sont pas identifiés pour une annulation automatique.", color = AgwColors.Sand)
                        }
                        TextButton(enabled = !busy, onClick = { showLinks = !showLinks }) { Text("Relier une création existante") }
                        if (showLinks) {
                            Text("Choisis un document du même personnage ou objet. Ses fichiers et son ancienne identité seront conservés.", color = AgwColors.Sand)
                            creations.filter { it.id != creation.id && CreationIdentity.resolve(it, available).isNotEmpty() }.forEach { other ->
                                TextButton(enabled = !busy, onClick = { showLinks = false; onLink(creation, other) }) { Text("Relier « ${other.name} »") }
                            }
                        }
                    }
                    items(creation.refs, key = { "${it.kind}:${it.id}" }) { ref ->
                        val thumb = thumbnail(ref)
                        if (thumb != null) Image(thumb, contentDescription = name, modifier = Modifier.fillMaxWidth().height(150.dp))
                        Text(sourceLabel(ref.kind) + if (ref !in available) " · document manquant" else "", color = AgwColors.Sand)
                        TextButton(enabled = !busy && ref in available, onClick = { onLegacy(ref) }) { Text("Ouvrir le document d'origine") }
                        if (ref !in available) TextButton(enabled = !busy, onClick = { onDetachMissing(creation, ref) }) { Text("Retirer ce lien manquant") }
                    }
                    item {
                        Button(enabled = !busy && modelUri(creation) != null, onClick = { onModeler(creation) }, modifier = Modifier.fillMaxWidth()) { Text("Ouvrir dans le Modeleur") }
                        if (resolved.all { it.kind == CreationSource.MOB }) Text("Le corps CreatureStudio se modifie dans son document d'origine ; sa conversion vers le Modeleur reste à développer.", color = AgwColors.Sand)
                        Button(enabled = !busy && resolved.isNotEmpty(), onClick = { onBehavior(creation) }, modifier = Modifier.fillMaxWidth()) { Text(if (resolved.any { it.kind == CreationSource.MOB }) "Modifier le comportement" else "Ajouter un comportement") }
                        Button(enabled = !busy && resolved.any { it.kind == CreationSource.MOB }, onClick = { onAnimate(creation) }, modifier = Modifier.fillMaxWidth()) { Text("Animer — profil de créature") }
                        Text("L'animation utilise actuellement CreatureStudio. Un GLB sculpté ne reçoit pas automatiquement un squelette. Le comportement lié reste une fiche ; son exécution dans un jeu Godot reste à développer.", color = AgwColors.Sand)
                        Button(enabled = !busy && modelUri(creation) != null, onClick = { onMap(creation) }, modifier = Modifier.fillMaxWidth()) { Text("Placer sur la carte") }
                        if (modelUri(creation) == null) Text("Un fichier GLB est nécessaire pour le Modeleur et le placement sur la carte.", color = AgwColors.Sand)
                        Button(enabled = !busy && resolved.size == creation.refs.size && resolved.isNotEmpty(), onClick = { onDuplicate(creation) }, modifier = Modifier.fillMaxWidth()) { Text("Dupliquer les documents liés") }
                    }
                } else {
                    item { Text("Modèles de départ", color = AgwColors.GoldSoft) }
                    items(templates, key = { "template:${it.first}" }) { (key, label) ->
                        Text(label, color = AgwColors.PaleMarble)
                        Row {
                            TextButton(enabled = !busy, onClick = { onTemplatePreview(key) }) { Text("Aperçu 3D") }
                            TextButton(enabled = !busy, onClick = { onTemplateCopy(key) }) { Text("Créer une copie") }
                        }
                    }
                    item {
                        Text("Mes créations · modèles réutilisables", color = AgwColors.GoldSoft)
                        OutlinedTextField(search, { search = it }, label = { Text("Rechercher une création") }, modifier = Modifier.fillMaxWidth())
                    }
                    items(creations.filter { search.isBlank() || it.name.contains(search, ignoreCase = true) || it.notes.contains(search, ignoreCase = true) }, key = { it.id }) { item ->
                        Card(onClick = { if (!busy) selected = item.id }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                val ref = item.refs.firstOrNull { it in available }
                                val thumb = ref?.let { thumbnail(it) }
                                if (thumb != null) Image(thumb, contentDescription = item.name, modifier = Modifier.height(90.dp))
                                Text(item.name)
                                Text(item.refs.joinToString(" · ") { sourceLabel(it.kind) }, style = MaterialTheme.typography.bodySmall)
                                val missing = item.refs.count { it !in available }
                                if (missing > 0) Text("$missing document(s) manquant(s)")
                                if (item.refs.isEmpty()) Text("Fiche conservée · aucun document lié")
                                Text("Ouvrir la fiche · dupliquer depuis la fiche", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (creations.isEmpty()) item { Text("Crée ou importe un premier objet dans l'Atelier.", color = AgwColors.Sand) }
                }
            }
        }
    }
}

private fun sourceLabel(kind: CreationSource): String = when (kind) {
    CreationSource.MOB -> "Créature et comportement"
    CreationSource.ENTITY -> "Objet de scène"
    CreationSource.CHARACTER -> "Références et modèle 3D"
    CreationSource.MESH -> "Maillage éditable"
}
