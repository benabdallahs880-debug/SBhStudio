package com.sbh.studio.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Surfaces anthracite, accents dorés et contours secondaires argentés. */
object AgwDecor {
    val CardShape = RoundedCornerShape(18.dp)
    val ChipShape = RoundedCornerShape(12.dp)
    val ButtonShape = RoundedCornerShape(12.dp)
    val TileShape = RoundedCornerShape(16.dp)
    val ViewportShape = RoundedCornerShape(20.dp)
    val PillShape = RoundedCornerShape(999.dp)

    /** Contour argent fin (bulles / cartes). */
    val SilverBorder = BorderStroke(1.dp, AgwColors.SilverGlass)
    val SilverBorderSoft = BorderStroke(0.8.dp, AgwColors.SilverMuted.copy(alpha = 0.55f))
    val SilverBorderStrong = BorderStroke(1.2.dp, AgwColors.SilverSoft.copy(alpha = 0.75f))
    val ViewportBorder = BorderStroke(1.dp, AgwColors.SilverSoft.copy(alpha = 0.28f))

    /** Contours dorés des actions et éléments mis en avant. */
    val GoldBorder = BorderStroke(1.dp, AgwColors.SacredGold.copy(alpha = 0.45f))
    val GoldBorderStrong = BorderStroke(1.2.dp, AgwColors.SacredGold.copy(alpha = 0.8f))

    val PanelBrush = Brush.verticalGradient(
        listOf(AgwColors.PanelRaised.copy(alpha = 0.94f), AgwColors.Panel.copy(alpha = 0.88f))
    )
    val GoldSheen = Brush.verticalGradient(
        listOf(
            AgwColors.GoldVeil,
            Color.Transparent,
            Color.Transparent
        )
    )
    val CrystalSheen = Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = 0.10f),
            Color.Transparent,
            AgwColors.SilverVeil
        )
    )
    val ViewportFrameBrush = Brush.verticalGradient(
        listOf(
            AgwColors.PanelRaised.copy(alpha = 0.72f),
            AgwColors.DeepNight.copy(alpha = 0.88f),
            AgwColors.NightStone.copy(alpha = 0.95f)
        )
    )
}

@Composable
fun GoldPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    iconAsset: String? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp),
        shape = AgwDecor.ButtonShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = AgwColors.SacredGold,
            contentColor = AgwColors.DeepNight,
            disabledContainerColor = AgwColors.NightStone,
            disabledContentColor = AgwColors.Sand.copy(alpha = 0.5f)
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 1.dp, pressedElevation = 1.dp)
    ) {
        if (iconAsset != null) {
            StudioGlyph(iconAsset, Modifier.size(18.dp), if (enabled) AgwColors.DeepNight else AgwColors.Sand)
            Spacer(Modifier.width(6.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
fun GoldOutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    iconAsset: String? = null
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp),
        shape = AgwDecor.ButtonShape,
        border = AgwDecor.SilverBorderStrong,
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = AgwColors.SilverSoft,
            containerColor = AgwColors.CrystalGlass
        )
    ) {
        if (iconAsset != null) {
            StudioGlyph(iconAsset, Modifier.size(18.dp), if (enabled) AgwColors.SacredGold else AgwColors.Sand)
            Spacer(Modifier.width(6.dp))
        }
        Text(text, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .border(AgwDecor.SilverBorder, AgwDecor.CardShape),
        shape = AgwDecor.CardShape,
        // Surface opaque pour garder les textes lisibles sur le décor.
        colors = CardDefaults.cardColors(containerColor = AgwColors.CrystalGlass),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box {
            Box(Modifier.matchParentSize().background(AgwDecor.CrystalSheen))
            Column(
                Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                content = content
            )
        }
    }
}

/**
 * Tuile de mode : icône (asset branding/icons) + libellé.
 * Utilisée sur l'accueil et dans l'atelier.
 */
@Composable
fun LiveBadge(text: String = "EN DIRECT", modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(AgwDecor.PillShape)
            .background(AgwColors.SacredGold.copy(alpha = 0.16f))
            .border(1.dp, AgwColors.SacredGold.copy(alpha = 0.55f), AgwDecor.PillShape)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(AgwColors.SacredGold)
        )
        Text(
            text,
            color = AgwColors.GoldSoft,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            letterSpacing = 0.6.sp
        )
    }
}

@Composable
fun ModeIconTile(
    label: String,
    iconAsset: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    selected: Boolean = false,
    enabled: Boolean = true,
    featured: Boolean = false
) {
    val border = when {
        featured || selected -> BorderStroke(1.2.dp, AgwColors.SacredGold.copy(alpha = 0.85f))
        else -> AgwDecor.SilverBorder
    }
    val bg = when {
        featured -> AgwColors.GoldMuted.copy(alpha = 0.92f)
        selected -> AgwColors.GoldMuted
        else -> AgwColors.CrystalGlassSoft
    }
    val fade = if (enabled) 1f else 0.45f

    Column(
        modifier = modifier
            .clip(AgwDecor.TileShape)
            .background(AgwDecor.PanelBrush)
            .background(bg)
            .border(border, AgwDecor.TileShape)
            .alpha(fade)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Médaillon : deux anneaux fins et icône vectorielle dorée.
        Box(
            Modifier
                .size(if (featured) 58.dp else 54.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            if (featured) AgwColors.GoldSoft.copy(alpha = 0.22f) else AgwColors.SilverSoft.copy(alpha = 0.18f),
                            AgwColors.DeepNight.copy(alpha = 0.35f)
                        )
                    )
                )
                .border(1.dp, if (featured) AgwColors.SacredGold.copy(alpha = 0.65f) else AgwColors.SacredGold.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .border(0.7.dp, AgwColors.SacredGold.copy(alpha = 0.28f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                StudioGlyph(iconAsset, Modifier.size(30.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            label,
            color = if (selected) AgwColors.SilverSoft else AgwColors.PaleMarble,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
        if (subtitle != null) {
            Text(
                subtitle,
                color = if (selected) AgwColors.SilverMuted else AgwColors.Sand,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ModeIconChip(
    label: String,
    iconAsset: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (selected) AgwColors.GoldMuted else AgwColors.NightGlass
    val fg = if (selected) AgwColors.GoldSoft else AgwColors.PaleMarble
    Row(
        modifier = modifier
            .clip(AgwDecor.ChipShape)
            .background(bg)
            .border(
                if (selected) AgwDecor.GoldBorderStrong else AgwDecor.SilverBorder,
                AgwDecor.ChipShape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        StudioGlyph(iconAsset, Modifier.size(22.dp), if (selected) AgwColors.GoldSoft else AgwColors.SacredGold)

        Text(label, color = fg, fontWeight = FontWeight.Medium, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier
                .width(3.dp)
                .height(16.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(AgwColors.GoldSoft, AgwColors.SacredGold.copy(alpha = 0.35f))
                    )
                )
        )
        Text(
            text,
            color = AgwColors.PaleMarble,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.2.sp
        )
    }
}

@Composable
fun GoldDivider(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        AgwColors.SilverSoft.copy(alpha = 0.45f),
                        Color.Transparent
                    )
                )
            )
    )
}

@Composable
fun IconBadge(
    iconAsset: String,
    size: Dp = 36.dp
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(AgwColors.CrystalGlass)
            .border(1.dp, AgwColors.SilverSoft.copy(alpha = 0.65f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        StudioGlyph(iconAsset, Modifier.size(size * 0.68f))
    }
}

@Composable
fun StatusPill(text: String, ok: Boolean = true) {
    val bg = if (ok) AgwColors.Success.copy(alpha = 0.14f) else AgwColors.Warning.copy(alpha = 0.14f)
    val fg = if (ok) AgwColors.Success else AgwColors.Warning
    val stroke = if (ok) AgwColors.Success.copy(alpha = 0.45f) else AgwColors.Warning.copy(alpha = 0.45f)
    Row(
        modifier = Modifier
            .clip(AgwDecor.PillShape)
            .background(bg)
            .border(1.dp, stroke, AgwDecor.PillShape)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(fg))
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, maxLines = 1)
    }
}


@Composable
fun ForgeStatusRow(
    label: String,
    detail: String,
    state: String,
    ok: Boolean = true,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(AgwDecor.ChipShape)
            .background(AgwColors.NightGlassSoft)
            .border(1.dp, AgwColors.Outline, AgwDecor.ChipShape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = AgwColors.PaleMarble, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(detail, color = AgwColors.Sand, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        StatusPill(state, ok)
    }
}

@Composable
fun ForgeMetric(
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(AgwDecor.ChipShape)
            .background(AgwColors.DeepNight.copy(alpha = 0.48f))
            .border(1.dp, AgwColors.Outline, AgwDecor.ChipShape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text(value, color = AgwColors.GoldSoft, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Text(label, color = AgwColors.Sand, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ForgeSectionCard(
    title: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable (() -> Unit))? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(AgwDecor.GoldBorder, AgwDecor.CardShape),
        shape = AgwDecor.CardShape,
        colors = CardDefaults.cardColors(containerColor = AgwColors.CrystalGlass),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = AgwColors.GoldSoft, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                trailing?.invoke()
            }
            content()
        }
    }
}

@Composable
fun NavAssetIcon(asset: String, selected: Boolean = false) {
    StudioGlyph(asset, Modifier.size(24.dp), if (selected) AgwColors.GoldSoft else AgwColors.Sand)
}
