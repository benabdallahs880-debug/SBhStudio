package com.sbh.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Frise discrète limitée aux marges ; elle ne capte aucun geste. */
@Composable
fun StudioEdgeOrnament(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val half = 6.dp.toPx()
        val step = 28.dp.toPx()
        val stroke = Stroke(0.7.dp.toPx())
        val color = AgwColors.SacredGold.copy(alpha = 0.18f)
        for (edge in listOf(half, size.width - half)) {
            var y = step
            while (y < size.height) {
                val p = Path().apply {
                    moveTo(edge, y - half)
                    lineTo(edge + half, y)
                    lineTo(edge, y + half)
                    lineTo(edge - half, y)
                    close()
                }
                drawPath(p, color, style = stroke)
                drawLine(color, Offset(edge, y + half), Offset(edge, y + step - half), stroke.width)
                y += step
            }
        }
    }
}
