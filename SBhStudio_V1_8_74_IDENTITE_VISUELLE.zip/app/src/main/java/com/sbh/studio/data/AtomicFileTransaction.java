package com.sbh.studio.data;

import java.io.*;
import java.nio.file.*;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.Callable;

/** Staged local writes, with a durable roll-forward journal. No Android dependency. */
public final class AtomicFileTransaction {
    public static final Object LOCK = new Object();
    private static final ThreadLocal<Session> ACTIVE = new ThreadLocal<>();
    private static final String JOURNALS = "creation_transactions";
    private static IOException recoveryFailure;
    private static final class Entry {
        String relative, before, after, stage;
    }
    private static final class Session {
        final File root, folder;
        final LinkedHashMap<String, Entry> entries = new LinkedHashMap<>();
        Session(File root, File folder) throws IOException { this.root = root.getCanonicalFile(); this.folder = folder; }
    }
    private AtomicFileTransaction() {}
    public static boolean recoveryRequired() { synchronized (LOCK) { return recoveryFailure != null; } }

    public static <T> T run(File root, Callable<T> work) throws Exception { return run(root, work, null); }
    interface CommitObserver { void applied(int count); }
    static <T> T run(File root, Callable<T> work, CommitObserver observer) throws Exception {
        synchronized (LOCK) {
            if (ACTIVE.get() != null) throw new IllegalStateException("Transaction imbriquée");
            recover(root);
            File folder = new File(new File(root, JOURNALS), UUID.randomUUID().toString());
            if (!folder.mkdirs()) throw new IOException("Impossible de préparer la sauvegarde");
            Session s = new Session(root, folder);
            persist(s, "PREPARING");
            T result;
            ACTIVE.set(s);
            try { result = work.call(); }
            catch (Exception ex) { deleteTree(folder); throw ex; }
            finally { ACTIVE.remove(); }
            // After this marker, staged bytes are authoritative; recovery finishes this exact operation.
            persist(s, "READY");
            try { commit(s, observer); }
            catch (Exception ex) {
                try { recover(root); }
                catch (Exception recovery) { recovery.addSuppressed(ex); throw recovery; }
            }
            return result;
        }
    }

    public static boolean stageIfActive(File target, byte[] bytes) throws IOException {
        synchronized (LOCK) {
            Session s = ACTIVE.get();
            if (s == null) {
                if (recoveryFailure != null) throw new IOException("Récupération nécessaire avant une nouvelle sauvegarde", recoveryFailure);
                return false;
            }
            String relative = relative(s.root, target);
            Entry e = s.entries.get(relative);
            if (e == null) {
                e = new Entry(); e.relative = relative; e.before = hash(target); e.stage = "entry_" + s.entries.size();
                s.entries.put(relative, e);
            }
            atomicWrite(new File(s.folder, e.stage), bytes);
            e.after = digest(bytes);
            persist(s, "PREPARING");
            return true;
        }
    }
    public static byte[] read(File target) throws IOException {
        synchronized (LOCK) {
            Session s = ACTIVE.get();
            if (s != null) {
                Entry e = s.entries.get(relative(s.root, target));
                if (e != null) return Files.readAllBytes(new File(s.folder, e.stage).toPath());
            }
            return target.exists() ? Files.readAllBytes(target.toPath()) : null;
        }
    }

    public static int recover(File root) throws IOException {
        synchronized (LOCK) {
            try { int result = recoverInternal(root); recoveryFailure = null; return result; }
            catch (IOException ex) { recoveryFailure = ex; throw ex; }
        }
    }
    private static int recoverInternal(File root) throws IOException {
            File parent = new File(root, JOURNALS);
            File[] folders = parent.listFiles(File::isDirectory);
            if (folders == null) return 0;
            Arrays.sort(folders, Comparator.comparing(File::getName));
            int recovered = 0;
            for (File folder : folders) {
                File manifest = new File(folder, "manifest.properties");
                if (!manifest.exists()) { deleteTree(folder); continue; } // interrupted before first staged write
                Properties p = new Properties();
                try (InputStream input = new FileInputStream(manifest)) { p.load(input); }
                if (!"1".equals(p.getProperty("version"))) throw new IOException("Version du journal inconnue");
                String state = p.getProperty("state");
                if ("PREPARING".equals(state) || "COMMITTED".equals(state)) { deleteTree(folder); continue; }
                if (!"READY".equals(state)) throw new IOException("Journal de sauvegarde illisible");
                Session s = new Session(root, folder);
                int count;
                try { count = Integer.parseInt(p.getProperty("count")); }
                catch (RuntimeException ex) { throw new IOException("Journal de sauvegarde illisible", ex); }
                if (count < 0 || count > 10000) throw new IOException("Journal de sauvegarde hors limites");
                for (int i = 0; i < count; i++) {
                    Entry e = new Entry();
                    e.relative = p.getProperty(i + ".path"); e.before = p.getProperty(i + ".before");
                    e.after = p.getProperty(i + ".after"); e.stage = "entry_" + i;
                    if (e.relative == null || e.before == null || e.after == null) throw new IOException("Journal incomplet");
                    if (!e.relative.equals(relative(s.root, new File(s.root, e.relative)))) throw new IOException("Cible du journal non canonique");
                    if (s.entries.put(e.relative, e) != null) throw new IOException("Cible dupliquée dans le journal");
                }
                commit(s, null); recovered++;
            }
            return recovered;
    }
    private static void commit(Session s, CommitObserver observer) throws IOException {
        // Validate the whole plan before replacing any file. Never overwrite an unrelated later edit.
        for (Entry e : s.entries.values()) {
            if (!e.after.equals(hash(new File(s.folder, e.stage)))) throw new IOException("Copie temporaire altérée ; récupération arrêtée");
            String current = hash(new File(s.root, e.relative));
            if (!current.equals(e.before) && !current.equals(e.after)) throw new IOException("Fichier modifié depuis la préparation : " + e.relative);
        }
        int n = 0;
        if (observer != null) observer.applied(0);
        for (Entry e : s.entries.values()) {
            File target = new File(s.root, e.relative);
            if (!e.after.equals(hash(target))) atomicWrite(target, Files.readAllBytes(new File(s.folder, e.stage).toPath()));
            if (observer != null) observer.applied(++n);
        }
        persist(s, "COMMITTED"); deleteTree(s.folder);
    }
    private static void persist(Session s, String state) throws IOException {
        Properties p = new Properties(); p.setProperty("version", "1"); p.setProperty("state", state);
        p.setProperty("count", Integer.toString(s.entries.size())); int i = 0;
        for (Entry e : s.entries.values()) {
            p.setProperty(i + ".path", e.relative); p.setProperty(i + ".before", e.before); p.setProperty(i + ".after", e.after); i++;
        }
        ByteArrayOutputStream output = new ByteArrayOutputStream(); p.store(output, "SBh creation operation");
        atomicWrite(new File(s.folder, "manifest.properties"), output.toByteArray());
    }
    private static String relative(File root, File target) throws IOException {
        Path base = root.getCanonicalFile().toPath(); Path path = target.getCanonicalFile().toPath();
        if (!path.startsWith(base) || path.equals(base)) throw new IOException("Cible hors du stockage de l'application");
        String value = base.relativize(path).toString();
        if (value.equals(JOURNALS) || value.startsWith(JOURNALS + File.separator)) throw new IOException("Cible réservée au journal");
        return value;
    }
    private static String hash(File file) throws IOException { return file.exists() ? digest(Files.readAllBytes(file.toPath())) : "ABSENT"; }
    private static String digest(byte[] bytes) {
        try { byte[] hash = MessageDigest.getInstance("SHA-256").digest(bytes); StringBuilder b = new StringBuilder();
            for (byte v : hash) b.append(String.format(Locale.ROOT, "%02x", v & 255)); return b.toString();
        } catch (Exception ex) { throw new IllegalStateException(ex); }
    }
    public static void atomicWrite(File file, byte[] bytes) throws IOException {
        File parent = file.getAbsoluteFile().getParentFile();
        if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("Dossier de sauvegarde inaccessible");
        File tmp = File.createTempFile("sbh_" + file.getName() + ".", ".tmp", parent);
        try {
            try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(bytes); out.flush(); out.getFD().sync(); }
            try { Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING); }
            // Directory fsync is best effort; some Android filesystems do not expose it through Java.
            try (FileChannel dir = FileChannel.open(parent.toPath(), StandardOpenOption.READ)) { dir.force(true); }
            catch (IOException | UnsupportedOperationException ignored) {}
        } finally { Files.deleteIfExists(tmp.toPath()); }
    }
    private static void deleteTree(File file) throws IOException {
        if (Files.isSymbolicLink(file.toPath())) throw new IOException("Lien symbolique inattendu dans le journal");
        File[] children = file.listFiles(); if (children != null) for (File child : children) deleteTree(child);
        Files.deleteIfExists(file.toPath());
    }
}
