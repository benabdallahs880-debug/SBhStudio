package com.sbh.studio.mesh

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.webkit.WebViewAssetLoader
import com.sbh.studio.ui.AgwColors
import org.json.JSONObject

/**
 * V1.8.65 — Modeleur 3D plein écran (Atelier de personnages, phase 1, livraison A).
 *
 * La page assets/meshstudio/mesh_studio.html lit start() une fois, enregistre toute seule après
 * chaque modification (save : .glb en base64 + aperçu png + compteurs) et demande la fermeture
 * (close). Retour d'Android : la page ferme d'abord un panneau ouvert, sinon enregistre puis ferme.
 * Même schéma que CreatureEditorDialog (creature/CreatureEditorScreen.kt).
 *
 * [meshId] : maillage existant à rouvrir ; un nouvel identifiant est créé par l'appelant.
 * [onClose] reçoit la carte du maillage enregistré (null si rien n'a été enregistré).
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MeshEditorDialog(
    projectId: String,
    meshId: String,
    initialName: String = "Nouveau maillage",
    onClose: (MeshInfo?) -> Unit
) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    var pageLoaded by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var closed by remember { mutableStateOf(false) }

    fun finish() {
        if (closed) return
        closed = true
        onClose(runCatching { MeshStore.info(context, projectId, meshId) }.getOrNull())
    }

    val bridge = remember {
        object {
            @JavascriptInterface
            fun start(): String = JSONObject().apply {
                put("id", meshId)
                put("name", MeshStore.info(context, projectId, meshId)?.name ?: initialName)
                put("glb", MeshStore.loadGlbBase64(context, projectId, meshId) ?: JSONObject.NULL)
            }.toString()

            @JavascriptInterface
            fun save(glbBase64: String, previewDataUrl: String, metaJson: String): Boolean =
                MeshStore.save(context, projectId, meshId, glbBase64, previewDataUrl, metaJson)

            @JavascriptInterface
            fun close() { mainHandler.post { finish() } }

            @JavascriptInterface
            fun toast(text: String) { mainHandler.post { Toast.makeText(context, text, Toast.LENGTH_LONG).show() } }
        }
    }

    val assetLoader = remember {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
    }

    val webView = remember {
        WebView(context).apply {
            setBackgroundColor(Color.parseColor("#17171C"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                    request?.url?.let { assetLoader.shouldInterceptRequest(it) }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    return uri.scheme != "https" || uri.host != "appassets.androidplatform.net"
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (url?.contains("mesh_studio.html") == true) pageLoaded = true
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                    if (request?.isForMainFrame == true) loadError = error?.description?.toString() ?: "Chargement impossible"
                }
            }
        }
    }

    DisposableEffect(Unit) {
        webView.addJavascriptInterface(bridge, "SBhMesh")
        webView.loadUrl("https://appassets.androidplatform.net/assets/meshstudio/mesh_studio.html")
        onDispose {
            try {
                webView.removeJavascriptInterface("SBhMesh")
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            } catch (e: Exception) { Log.w("MeshEditor", "Fermeture non critique", e) }
        }
    }

    /** Retour : la page ferme son panneau ouvert, sinon enregistre puis l'éditeur se ferme. */
    fun requestBack() {
        if (closed) return
        if (!pageLoaded || loadError != null) { finish(); return }
        val fallback = Runnable { finish() }
        mainHandler.postDelayed(fallback, 6_000L)   // un gros maillage : .glb + aperçu + écriture
        webView.evaluateJavascript("(window.sbhMeshBack ? window.sbhMeshBack() : 'close')") { result ->
            mainHandler.removeCallbacks(fallback)
            if (result?.contains("handled") != true) finish()
        }
    }

    Dialog(
        onDismissRequest = { requestBack() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Box(Modifier.fillMaxSize().background(AgwColors.DeepNight)) {
            AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
            if (!pageLoaded || loadError != null) {
                Box(Modifier.fillMaxSize().background(AgwColors.DeepNight), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (loadError == null) CircularProgressIndicator(color = AgwColors.SacredGold)
                        Text(
                            loadError?.let { "Le Modeleur 3D n'a pas pu se charger : $it\n(Retour pour revenir à l'Atelier)" }
                                ?: "🧊 Modeleur 3D…",
                            color = AgwColors.PaleMarble,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }
    }
}
