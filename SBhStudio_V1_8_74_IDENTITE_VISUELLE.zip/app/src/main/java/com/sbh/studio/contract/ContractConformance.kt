package com.sbh.studio.contract

import java.io.File

/** Exécute les cas de contract/conformance/ et renvoie la liste des écarts (vide = conforme). */
object ContractConformance {
    fun run(contractDir: File): List<String> {
        val schemas = ContractValidator.Schemas.fromDirectory(File(contractDir, "schemas"))
        @Suppress("UNCHECKED_CAST")
        val expected = SbhJson.parse(File(contractDir, "conformance/expected.json").readBytes()) as Map<String, List<List<String>>>
        val cases = File(contractDir, "conformance/cases").listFiles { f -> f.isDirectory }?.sortedBy { it.name } ?: emptyList()
        val failures = ArrayList<String>()
        val got = cases.associate { d ->
            val doc = File(d, "document.json")
            val r = if (doc.isFile) ContractValidator.validateDocument(doc.readBytes(), schemas, "document.json")
                    else ContractValidator.validatePackage(d, schemas)
            d.name to ContractValidator.triples(r)
        }
        for (name in (expected.keys + got.keys).toSortedSet()) {
            if (expected[name] != got[name]) failures += "$name\n  attendu : ${expected[name]}\n  obtenu  : ${got[name]}"
        }
        return failures
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val dir = File(args.firstOrNull() ?: "contract")
        val failures = run(dir)
        val total = File(dir, "conformance/cases").listFiles { f -> f.isDirectory }?.size ?: 0
        failures.forEach { println("KO $it") }
        println("Kotlin : ${total - failures.size}/$total cas conformes")
        if (failures.isNotEmpty()) kotlin.system.exitProcess(1)
    }
}
