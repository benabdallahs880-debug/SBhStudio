package com.sbh.studio.creation

import kotlinx.serialization.json.*

/** Conservative bridge to the surface editor, which cannot round-trip rigs, hierarchies or textures. */
object MeshImportPolicy {
    fun problem(text: String): String? = try {
        val j = Json.parseToJsonElement(text).jsonObject
        fun populated(key: String) = (j[key] as? JsonArray)?.isNotEmpty() == true
        when {
            populated("skins") || populated("animations") -> "Squelette ou animations : conserve ce modèle dans son atelier ; le Modeleur ne les préserve pas encore."
            populated("textures") || populated("images") || populated("extensionsUsed") -> "Textures ou extensions non préservées par le Modeleur : import bloqué pour éviter une perte."
            (j["buffers"] as? JsonArray).orEmpty().any { "uri" in it.jsonObject } -> "GLB avec ressources externes non pris en charge."
            (j["nodes"] as? JsonArray).orEmpty().any { n -> n.jsonObject.let { "matrix" in it || "children" in it || "skin" in it } } -> "Hiérarchie ou transformation matricielle non préservée par le Modeleur."
            (j["accessors"] as? JsonArray).orEmpty().any { "sparse" in it.jsonObject || it.jsonObject["componentType"]?.jsonPrimitive?.int !in listOf(5121, 5123, 5125, 5126) } -> "Type de coordonnées non pris en charge par le Modeleur."
            (j["meshes"] as? JsonArray).orEmpty().any { m ->
                val p = m.jsonObject["primitives"]?.jsonArray.orEmpty()
                p.size != 1 || p.any { q -> q.jsonObject.let { "targets" in it || (it["mode"]?.jsonPrimitive?.int ?: 4) != 4 || "COLOR_0" in it["attributes"]!!.jsonObject || "TEXCOORD_0" in it["attributes"]!!.jsonObject } }
            } -> "Primitives, UV ou couleurs de sommets non préservés par le Modeleur."
            (j["nodes"] as? JsonArray).orEmpty().none { "mesh" in it.jsonObject } -> "Aucun maillage dans ce fichier."
            else -> null
        }
    } catch (_: Exception) { "Description GLB illisible." }
}
