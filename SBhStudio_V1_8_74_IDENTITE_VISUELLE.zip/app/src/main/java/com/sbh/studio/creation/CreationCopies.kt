package com.sbh.studio.creation

import android.content.Context
import android.util.Base64
import com.sbh.studio.character.CharacterProject
import com.sbh.studio.creature.CreatureBodyMapping
import com.sbh.studio.creature.CreatureBodyStore
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SafeStore
import com.sbh.studio.mesh.MeshInfo
import com.sbh.studio.mesh.MeshStore
import com.sbh.studio.workshop.SceneEntity
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class CreationCopyResult(val creation: CommonCreation, val mobs: List<MobEntity>, val entities: List<SceneEntity>, val characters: List<CharacterProject>, val mobIds: Map<String, String>)
data class CreationPublishedCopy(val creation: CommonCreation, val common: List<CommonCreation>, val mobs: List<MobEntity>, val entities: List<SceneEntity>, val characters: List<CharacterProject>)

object CreationCopies {
    /** Prepare copies before publishing their records. No original file is modified. */
    fun prepare(context: Context, original: CommonCreation, mobs: List<MobEntity>, entities: List<SceneEntity>, characters: List<CharacterProject>, meshes: List<MeshInfo>): CreationCopyResult {
        val pid = original.projectId
        val refs = original.refs
        fun newId() = UUID.randomUUID().toString()
        val available = mobs.map { CreationRef(CreationSource.MOB, it.id) } + entities.map { CreationRef(CreationSource.ENTITY, it.id) } + characters.map { CreationRef(CreationSource.CHARACTER, it.id) } + meshes.map { CreationRef(CreationSource.MESH, it.id) }
        require(refs.all { it in available }) { "Une pièce liée manque ; duplication interrompue." }
        require(mobs.all { it.projectId == pid } && entities.all { it.projectId == pid } && characters.all { it.projectId == pid } && meshes.all { it.projectId == pid })
        val mapping = refs.associateWith { if (it.kind == CreationSource.MESH) MeshStore.newId() else newId() }
        val modelCopies = mutableMapOf<String, String>()
        val newName = original.name + " — copie"
        refs.filter { it.kind == CreationSource.MESH }.forEach { r ->
            val bytes = CreationModelFiles.read(context, MeshStore.glbFile(context, pid, r.id).absolutePath)
            val id = mapping.getValue(r)
            val info = meshes.first { it.id == r.id }
            val meta = JSONObject().put("name", newName).put("objects", info.objects).put("verts", info.verts)
                .put("faces", info.faces).put("triangles", info.triangles).put("symmetry", info.symmetry)
            require(MeshStore.save(context, pid, id, Base64.encodeToString(bytes, Base64.NO_WRAP), "", meta.toString())) { "Copie du maillage impossible" }
            val preview = MeshStore.previewFile(context, pid, r.id)
            if (preview.exists()) SafeStore.writeBytes(MeshStore.previewFile(context, pid, id), preview.readBytes())
            modelCopies[MeshStore.glbFile(context, pid, r.id).absolutePath] = MeshStore.glbFile(context, pid, id).absolutePath
        }
        fun copyModel(path: String?): String? {
            if (path == null) return null
            return modelCopies.getOrPut(path) {
                val bytes = CreationModelFiles.read(context, path)
                val folder = File(context.filesDir, "creation_copies").apply { mkdirs() }
                File(folder, "${newId()}.glb").apply { SafeStore.writeBytes(this, bytes) }.absolutePath
            }
        }
        val newMobs = refs.filter { it.kind == CreationSource.MOB }.map { r ->
            val old = mobs.first { it.id == r.id }
            val id = mapping.getValue(r)
            val identifier = "agw:copy_" + id.replace("-", "")
            val copy = old.copy(id = id, nom = newName, identifiant = identifier, versionHistory = old.versionHistory + "Copie indépendante depuis ${old.nom}")
            val project = CreatureBodyStore.loadProject(context, pid, old.id)
            if (project != null) {
                val body = CreatureBodyStore.loadBody(context, pid, old.id) ?: error("Corps lié illisible ; copie interrompue")
                val json = JSONObject(project)
                json.optJSONObject("project")?.put("id", "project_$id")?.put("name", newName)
                json.optJSONObject("creature")?.put("id", "creature_$id")?.put("name", newName)
                val oldKey = CreatureBodyMapping.bodyKey(old.id)
                val newKey = CreatureBodyMapping.bodyKey(id)
                val bodyText = CreatureBodyMapping.json.encodeToString(com.sbh.studio.creature.CreatureBody.serializer(), body.copy(name = newName))
                    .replace(oldKey, newKey)
                require(CreatureBodyStore.save(context, pid, id, json.toString(), bodyText, "")) { "Copie du corps impossible" }
                val preview = CreatureBodyStore.previewFile(context, pid, old.id)
                if (preview.exists()) SafeStore.writeBytes(CreatureBodyStore.previewFile(context, pid, id), preview.readBytes())
            }
            copy
        }
        val newEntities = refs.filter { it.kind == CreationSource.ENTITY }.map { r ->
            val old = entities.first { it.id == r.id }
            old.copy(id = mapping.getValue(r), name = newName, glbUri = copyModel(old.glbUri), linkedMapId = null)
        }
        val newCharacters = refs.filter { it.kind == CreationSource.CHARACTER }.map { r ->
            val old = characters.first { it.id == r.id }
            old.copy(id = mapping.getValue(r), name = newName, modelUri = copyModel(old.modelUri), createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis())
        }
        return CreationCopyResult(CreationIdentity.duplicate(original, refs.map { it.copy(id = mapping.getValue(it)) }), newMobs, newEntities, newCharacters,
            refs.filter { it.kind == CreationSource.MOB }.associate { it.id to mapping.getValue(it) })
    }
}
