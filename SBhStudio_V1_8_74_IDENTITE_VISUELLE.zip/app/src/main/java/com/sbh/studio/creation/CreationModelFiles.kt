package com.sbh.studio.creation

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.sbh.studio.mesh.GlbCheck
import com.sbh.studio.mesh.MeshStore
import com.sbh.studio.data.SafeStore
import org.json.JSONObject
import java.io.File

/** Bounded local imports; the source is always kept, and unsupported features cannot be silently erased. */
object CreationModelFiles {
    fun read(context: Context, path: String): ByteArray {
        val uri = Uri.parse(path)
        require(uri.scheme == null || uri.scheme == "file" || uri.scheme == "content") { "Modèle local requis" }
        val input = if (uri.scheme == "content") context.contentResolver.openInputStream(uri)
            else File(if (uri.scheme == "file") requireNotNull(uri.path) else path).inputStream()
        val bytes = requireNotNull(input) { "Modèle introuvable" }.use { it.readBytesBounded() }
        require(GlbCheck.problem(bytes) == null) { GlbCheck.problem(bytes).orEmpty() }
        return bytes
    }
    private fun java.io.InputStream.readBytesBounded(): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val chunk = ByteArray(8192)
        while (true) {
            val n = read(chunk)
            if (n < 0) break
            require(output.size() + n <= GlbCheck.MAX_BYTES) { "Modèle trop gros (32 Mo maximum)" }
            output.write(chunk, 0, n)
        }
        return output.toByteArray()
    }
    fun importForModeler(context: Context, projectId: String, name: String, bytes: ByteArray): String {
        val document = JSONObject(requireNotNull(GlbCheck.jsonChunk(bytes)))
        val problem = MeshImportPolicy.problem(document.toString())
        require(problem == null) { problem.orEmpty() }
        val id = MeshStore.newId()
        require(MeshStore.save(context, projectId, id, Base64.encodeToString(bytes, Base64.NO_WRAP), "", JSONObject().put("name", name).toString())) { "Copie du maillage non enregistrée" }
        return id
    }
    fun stageForMap(context: Context, path: String): String {
        val bytes = read(context, path)
        val uri = Uri.parse(path)
        if (uri.scheme == null) return File(path).absolutePath
        if (uri.scheme == "file") return File(requireNotNull(uri.path)).absolutePath
        val folder = File(context.filesDir, "creation_map_transfers").apply { mkdirs() }
        val target = File(folder, "${java.util.UUID.randomUUID()}.glb")
        SafeStore.writeBytes(target, bytes)
        return target.absolutePath
    }
}
