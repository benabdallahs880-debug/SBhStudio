package com.sbh.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Icônes vectorielles locales : une même épaisseur, aucune image à décoder. */
@Composable
fun StudioGlyph(asset: String, modifier: Modifier = Modifier.size(24.dp), color: Color = AgwColors.SacredGold) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val origin = Offset((size.width - 24f * u) / 2f, (size.height - 24f * u) / 2f)
        fun point(x: Float, y: Float) = origin + Offset(x * u, y * u)
        fun line(x: Float, y: Float, a: Float, b: Float) = drawLine(color, point(x, y), point(a, b), 1.5f * u, StrokeCap.Round)
        fun circle(x: Float, y: Float, r: Float) = drawCircle(color, r * u, point(x, y), style = Stroke(1.5f * u))
        fun poly(vararg xy: Float) {
            val p = Path()
            p.moveTo(point(xy[0], xy[1]).x, point(xy[0], xy[1]).y)
            for (i in 2 until xy.size step 2) p.lineTo(point(xy[i], xy[i + 1]).x, point(xy[i], xy[i + 1]).y)
            drawPath(p, color, style = Stroke(1.5f * u, cap = StrokeCap.Round))
        }
        when (asset.substringAfterLast('/').removePrefix("icon_").substringBefore('.')) {
            "hub" -> { poly(3f,11f,12f,3f,21f,11f); poly(6f,10f,6f,21f,10f,21f,10f,15f,14f,15f,14f,21f,18f,21f,18f,10f) }
            "workshop", "forge" -> { line(5f,20f,19f,6f); poly(14f,4f,18f,2f,22f,6f,20f,10f,14f,4f); line(4f,4f,20f,20f); poly(3f,3f,7f,4f,4f,7f,3f,3f) }
            "map", "portals" -> { circle(12f,12f,9f); poly(12f,4f,15f,12f,12f,20f,9f,12f,12f,4f); line(4f,12f,20f,12f) }
            "world" -> { circle(12f,12f,9f); poly(12f,3f,8f,7f,7f,12f,8f,17f,12f,21f,16f,17f,17f,12f,16f,7f,12f,3f); line(3f,12f,21f,12f) }
            "blocks", "items", "modeler" -> { poly(12f,2f,21f,7f,21f,17f,12f,22f,3f,17f,3f,7f,12f,2f); poly(3f,7f,12f,12f,21f,7f); line(12f,12f,12f,22f) }
            "audio" -> { for (i in 0..6) { val h = floatArrayOf(3f,6f,9f,7f,4f,6f,2f)[i]; line(3f+i*3f,12f-h,3f+i*3f,12f+h) } }
            "animation" -> { circle(14f,4f,2f); poly(5f,10f,10f,8f,15f,12f,20f,12f); poly(13f,9f,10f,15f,5f,21f); poly(10f,15f,16f,17f,18f,21f) }
            "ai" -> { poly(12f,2f,21f,8f,21f,17f,12f,22f,3f,17f,3f,8f,12f,2f); poly(3f,8f,12f,12f,21f,8f); poly(3f,17f,12f,12f,21f,17f); line(12f,2f,12f,22f) }
            "updates", "export" -> { line(12f,3f,12f,16f); poly(7f,11f,12f,16f,17f,11f); poly(4f,17f,4f,21f,20f,21f,20f,17f) }
            "lore" -> { poly(12f,6f,8f,4f,3f,4f,3f,19f,8f,19f,12f,21f,16f,19f,21f,19f,21f,4f,16f,4f,12f,6f,12f,21f) }
            "heroes", "factions" -> { poly(4f,4f,12f,2f,20f,4f,20f,13f,17f,18f,12f,22f,7f,18f,4f,13f,4f,4f); poly(12f,7f,14f,11f,18f,11f,15f,14f,16f,18f,12f,16f,8f,18f,9f,14f,6f,11f,10f,11f,12f,7f) }
            "mobs", "bestiary" -> { circle(12f,14f,5f); circle(4f,9f,2f); circle(9f,4f,2f); circle(15f,4f,2f); circle(20f,9f,2f) }
            "phases" -> { circle(5f,19f,3f); circle(12f,12f,3f); circle(19f,5f,3f); line(7f,17f,10f,14f); line(14f,10f,17f,7f) }
            "settings" -> { circle(12f,12f,4f); circle(12f,12f,8f); line(12f,1f,12f,4f); line(12f,20f,12f,23f); line(1f,12f,4f,12f); line(20f,12f,23f,12f) }
            else -> { poly(5f,2f,15f,2f,20f,7f,20f,22f,5f,22f,5f,2f); poly(15f,2f,15f,7f,20f,7f); line(8f,11f,17f,11f); line(8f,15f,17f,15f); line(8f,19f,14f,19f) }
        }
    }
}
