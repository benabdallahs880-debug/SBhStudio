package com.sbh.studio.ui

import androidx.compose.foundation.layout.Arrangement

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/**
 * Charge une image depuis assets/branding/
 */
@Composable
fun rememberAssetBitmap(path: String): androidx.compose.ui.graphics.ImageBitmap? {
    val context = LocalContext.current
    return remember(context, path) {
        runCatching {
            // Bornage du décodage : les fonds ne deviennent pas des bitmaps 4K en mémoire.
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.assets.open(path).use { BitmapFactory.decodeStream(it, null, bounds) }
            val limit = if (path.contains("bg_")) 1536 else 512
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > limit) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            context.assets.open(path).use { BitmapFactory.decodeStream(it, null, options)?.asImageBitmap() }
        }.getOrNull()
    }
}

@Composable
fun BrandLogo(modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 96.dp) {
    val bmp = rememberAssetBitmap("branding/logo_owl_faceted.png")
        ?: rememberAssetBitmap("branding/logo_owl_geometric.png")
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = "Logo SBh Studio", contentScale = ContentScale.Fit,
            modifier = modifier.size(size))
    } else {
        StudioGlyph("icon_ai", modifier.size(size))
    }
}

/** Décor statique : une seule image bornée en résolution et un voile de lecture. */
@Composable
fun HomeAtmosphereBackground(modifier: Modifier = Modifier) {
    val bmp = rememberAssetBitmap("branding/bg_studio_night.png")
        ?: rememberAssetBitmap("branding/bg_raven_owl.png")
    Box(modifier.background(AgwColors.DeepNight)) {
        if (bmp != null) Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(), alpha = 0.85f)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
            Color(0x99101822), Color(0x55101822), Color(0xBB0D1117)
        ))))
        StudioEdgeOrnament(Modifier.fillMaxSize())
    }
}

@Composable
fun StudioBrandHeader(lang: AppLang) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BrandLogo(size = 48.dp)
            Column(Modifier.weight(1f)) {
                Text(S.t(lang, "app_name"), style = MaterialTheme.typography.titleLarge, color = AgwColors.GoldSoft)
                Text("Atelier de création de jeux · Al-Zahra", style = MaterialTheme.typography.bodySmall,
                    color = AgwColors.Sand)
            }
        }
    }
}
