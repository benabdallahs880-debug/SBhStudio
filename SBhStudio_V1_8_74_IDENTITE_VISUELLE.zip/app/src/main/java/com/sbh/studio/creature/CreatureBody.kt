package com.sbh.studio.creature

import android.content.Context
import android.util.Log
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SafeStore
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import kotlin.math.roundToInt

/**
 * V1.8.62 — corps 3D d'un monstre fait dans CreatureStudio (éditeur intégré à l'Atelier).
 *
 * Pour chaque monstre (MobEntity) qui a un corps, trois fichiers par projet :
 *   files/creatures/<projet>/<idMonstre>.creature.json  → projet CreatureStudio (format 1.0, éditable)
 *   files/creatures/<projet>/<idMonstre>.body.json      → corps Minecraft déjà calculé par l'éditeur
 *                                                         (géométrie, animations, contrôleur, texture)
 *   files/creatures/<projet>/<idMonstre>.png            → aperçu pour l'Atelier
 *
 * Le corps Minecraft est calculé par l'éditeur (même code que l'export CreatureStudio, testé par
 * parité Python ↔ JS) à chaque enregistrement : l'export du .mcaddon n'a donc pas besoin de WebView.
 * Les identifiants (geometry.sbhc_<clé>, animation.sbhc_<clé>.*) dépendent de l'id du monstre,
 * jamais de son nom ni de son identifiant Minecraft : renommer un monstre ne casse rien.
 */
@Serializable
data class CreatureBody(
    val format: String = "sbh-creature-body",
    val version: Int = 1,
    val bodyKey: String = "",
    val geometryId: String,
    val bones: Int = 0,
    val client: Client,
    /** Chemins relatifs au Resource Pack (models/entity/…, animations/…, animation_controllers/…) → JSON. */
    val files: Map<String, String> = emptyMap(),
    val texture: Texture,
    val collision: Collision? = null,
    val stats: Stats? = null,
    val name: String = "",
    val warnings: List<String> = emptyList()
) {
    @Serializable
    data class Client(
        val geometry: String,
        val animations: Map<String, String> = emptyMap(),
        val animate: List<String> = emptyList()
    )

    @Serializable
    data class Texture(val width: Int = 16, val height: Int = 16, val base64: String = "")

    @Serializable
    data class Collision(val width: Double = 0.6, val height: Double = 1.8)

    @Serializable
    data class Stats(
        val health: Double = 20.0,
        val damage: Double = 3.0,
        val armor: Double = 0.0,
        val speed: Double = 0.5,
        val jumpHeight: Double = 1.0,
        val detectionRange: Double = 16.0,
        val intelligence: Double = 0.5
    )
}

/** V1.8.63 : aperçu d'un état de l'âme (Studio Animation) sur le corps 3D, dans l'éditeur. */
data class BodyPreview(
    val animation: String,
    val speed: Float = 1f,
    val amplitude: Float = 1f,
    val weight: Float = 1f,
    val loop: Boolean = true
)

/** Conversions pures (testées) entre la fiche du monstre et le corps CreatureStudio. */
object CreatureBodyMapping {
    /** Clé stable des identifiants Minecraft du corps : « sbh_ » + 8 premiers caractères de l'id. */
    fun bodyKey(mobId: String): String {
        val core = mobId.lowercase().replace(Regex("[^a-z0-9]"), "")
        return "sbh_" + core.take(8).ifBlank { "corps" }
    }

    /**
     * Fiche → CreatureStudio. Bornes de CreatureStudio : vie 1–1000, dégâts 0–100, vitesse 0–1,
     * détection 1–64. Vitesse : CreatureStudio exporte movement = 0,05 + 0,3 × vitesse ; la fiche
     * stocke directement la valeur Minecraft (0,25 par défaut) → vitesse = (v − 0,05) / 0,3.
     */
    fun statsFromMob(m: MobEntity): Map<String, Double> = linkedMapOf(
        "health" to m.vie.toDouble().coerceIn(1.0, 1000.0),
        "damage" to m.degats.toDouble().coerceIn(0.0, 100.0),
        "speed" to round3(((m.vitesse - 0.05) / 0.3).coerceIn(0.0, 1.0)),
        "detectionRange" to m.detectionDistance.coerceIn(1.0, 64.0)
    )

    /** CreatureStudio → fiche : vie, dégâts, vitesse, détection et boîte de collision du corps. */
    fun applyToMob(m: MobEntity, body: CreatureBody): MobEntity {
        val s = body.stats
        val c = body.collision
        return m.copy(
            vie = s?.health?.roundToInt()?.coerceIn(1, 1000) ?: m.vie,
            degats = s?.damage?.roundToInt()?.coerceIn(0, 100) ?: m.degats,
            vitesse = s?.speed?.let { round3(0.05 + 0.3 * it.coerceIn(0.0, 1.0)) } ?: m.vitesse,
            // CreatureStudio plafonne la détection à 64 ; une fiche réglée plus loin (jusqu'à 128) le reste
            detectionDistance = s?.detectionRange?.let { d ->
                if (m.detectionDistance > 64.0 && d >= 64.0) m.detectionDistance else d.coerceIn(1.0, 128.0)
            } ?: m.detectionDistance,
            collisionLargeur = c?.width?.coerceIn(0.1, 4.0)?.let(::round3) ?: m.collisionLargeur,
            collisionHauteur = c?.height?.coerceIn(0.1, 8.0)?.let(::round3) ?: m.collisionHauteur
        )
    }

    /** Un monstre a-t-il changé à cause du corps ? (évite une sauvegarde inutile) */
    fun differs(a: MobEntity, b: MobEntity): Boolean =
        a.vie != b.vie || a.degats != b.degats || a.vitesse != b.vitesse ||
            a.detectionDistance != b.detectionDistance || a.collisionLargeur != b.collisionLargeur ||
            a.collisionHauteur != b.collisionHauteur

    /** Seuls ces dossiers du Resource Pack peuvent venir d'un corps (pas de « ../ », pas de manifeste). */
    fun isSafeRpPath(path: String): Boolean =
        Regex("^(models/entity|animations|animation_controllers)/[a-z0-9_]+(\\.[a-z0-9_]+)*\\.json$").matches(path)

    /** Lecture tolérante d'un corps enregistré ; null s'il est illisible ou incomplet. */
    fun parse(text: String?): CreatureBody? {
        if (text.isNullOrBlank()) return null
        return runCatching { json.decodeFromString(CreatureBody.serializer(), text) }
            .getOrNull()
            ?.takeIf { it.format == "sbh-creature-body" && it.geometryId.isNotBlank() && it.texture.base64.isNotBlank() }
    }

    internal val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private fun round3(v: Double): Double = (v * 1000).roundToInt() / 1000.0
}

/** Fichiers des corps, rangés par projet. */
object CreatureBodyStore {
    private const val TAG = "CreatureBodyStore"

    fun root(context: Context): File = File(context.filesDir, "creatures")

    private fun safe(raw: String): String = raw.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80).ifBlank { "global" }

    fun dir(context: Context, projectId: String): File = File(root(context), safe(projectId))
    fun projectFile(context: Context, projectId: String, mobId: String) = File(dir(context, projectId), safe(mobId) + ".creature.json")
    fun bodyFile(context: Context, projectId: String, mobId: String) = File(dir(context, projectId), safe(mobId) + ".body.json")
    fun previewFile(context: Context, projectId: String, mobId: String) = File(dir(context, projectId), safe(mobId) + ".png")

    fun has(context: Context, projectId: String, mobId: String): Boolean = projectFile(context, projectId, mobId).exists()

    fun loadProject(context: Context, projectId: String, mobId: String): String? =
        SafeStore.readText(projectFile(context, projectId, mobId))

    fun loadBody(context: Context, projectId: String, mobId: String): CreatureBody? =
        CreatureBodyMapping.parse(SafeStore.readText(bodyFile(context, projectId, mobId)))

    /**
     * Enregistre le projet CreatureStudio, le corps Minecraft (s'il a pu être calculé) et l'aperçu.
     * Un corps vide (« ») garde l'ancien corps Minecraft : l'export reste possible.
     */
    fun save(context: Context, projectId: String, mobId: String, projectJson: String, bodyJson: String, previewDataUrl: String): Boolean = try {
        SafeStore.write(projectFile(context, projectId, mobId), projectJson)
        if (CreatureBodyMapping.parse(bodyJson) != null) SafeStore.write(bodyFile(context, projectId, mobId), bodyJson)
        val prefix = "data:image/png;base64,"
        if (previewDataUrl.startsWith(prefix)) {
            val bytes = android.util.Base64.decode(previewDataUrl.removePrefix(prefix), android.util.Base64.DEFAULT)
            if (bytes.size in 8..2_000_000) {
                val f = previewFile(context, projectId, mobId)
                SafeStore.writeBytes(f, bytes)
            }
        }
        true
    } catch (e: Exception) {
        Log.e(TAG, "Corps non enregistré", e); false
    }

    /** Supprime le corps d'un monstre supprimé (sinon fichiers orphelins). */
    fun delete(context: Context, projectId: String, mobId: String) {
        listOf(projectFile(context, projectId, mobId), bodyFile(context, projectId, mobId), previewFile(context, projectId, mobId))
            .forEach { runCatching { it.delete() } }
    }
}
