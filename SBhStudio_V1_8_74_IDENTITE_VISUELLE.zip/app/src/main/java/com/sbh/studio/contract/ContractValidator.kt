package com.sbh.studio.contract

import java.io.File
import java.security.MessageDigest

/**
 * SBH Data Contract v1 — validateur côté SBh Studio (Kotlin pur, sans Android).
 *
 * Copie fidèle du validateur de référence contract/reference/sbh_contract.py : mêmes règles, mêmes
 * codes, mêmes chemins. Toute différence est un bug, détecté par les cas de contract/conformance/
 * (ContractConformanceTest). Ne pas « améliorer » une règle ici sans changer la référence, le
 * validateur Godot et la SPEC en même temps.
 */
object ContractValidator {
    const val CONTRACT_MAJOR = 1
    const val CONTRACT_MINOR = 1
    val RULE_KINDS = listOf("biomes", "cultures", "settlements", "roads", "factions")
    val DOC_KINDS = RULE_KINDS + listOf("world", "test_report")
    private val SEMVER = Regex("^([0-9]+)\\.([0-9]+)\\.([0-9]+)$")
    private val SHA = Regex("^[0-9a-f]{64}$")
    private val PATH = Regex("^[a-z0-9_][a-z0-9_./-]*$")
    private const val MANIFEST = "sbh_world.json"

    data class Issue(val severity: String, val code: String, val file: String, val path: String, val message: String)

    data class Result(val issues: List<Issue>) {
        val valid: Boolean get() = issues.none { it.severity == "error" }
        val errors: Int get() = issues.count { it.severity == "error" }
        val warnings: Int get() = issues.count { it.severity == "warning" }
    }

    /** Schémas : type de document → schéma (lu par [SbhJson]). */
    class Schemas(val byKind: Map<String, Map<String, Any?>>) {
        companion object {
            /** [read] renvoie le texte de « <kind>.schema.json » (assets de l'app, fichiers, ressources de test…). */
            fun load(read: (String) -> String): Schemas = Schemas(DOC_KINDS.associateWith { k ->
                @Suppress("UNCHECKED_CAST")
                SbhJson.parse(read("$k.schema.json")) as Map<String, Any?>
            })

            fun fromDirectory(dir: File): Schemas = load { name -> File(dir, name).readText(Charsets.UTF_8) }
        }
    }

    private class Ctx {
        val issues = ArrayList<Issue>()
        val ids = HashMap<String, MutableSet<String>>()
        val refs = ArrayList<Array<String>>()   // table, valeur, fichier, chemin
        fun add(sev: String, code: String, file: String, path: String, msg: String) { issues += Issue(sev, code, file, path, msg) }
        fun err(code: String, file: String, path: String, msg: String) = add("error", code, file, path, msg)
    }

    private fun isNum(v: Any?) = v is Double
    private fun typeOk(v: Any?, t: String): Boolean = when (t) {
        "object" -> v is Map<*, *>
        "array" -> v is List<*>
        "string" -> v is String
        "boolean" -> v is Boolean
        "number" -> v is Double
        "integer" -> v is Double && !v.isInfinite() && v == Math.floor(v)
        else -> true
    }

    @Suppress("UNCHECKED_CAST")
    private fun resolve(schema: Map<String, Any?>, root: Map<String, Any?>): Map<String, Any?> {
        val ref = schema["\$ref"] as? String ?: return schema
        val defs = root["\$defs"] as Map<String, Any?>
        val out = LinkedHashMap(defs[ref.substringAfterLast('/')] as Map<String, Any?>)
        for ((k, v) in schema) if (k != "\$ref") out[k] = v
        return out
    }

    private fun same(a: Any?, b: Any?): Boolean = when {
        a is Boolean || b is Boolean -> a is Boolean && b is Boolean && a == b
        a is Double && b is Double -> a == b
        else -> a == b
    }

    private fun keyOf(v: Any?): String = when (v) {
        is Double -> "n:$v"
        is String -> "s:$v"
        else -> "o:$v"
    }

    private fun num(v: Any?): Double? = v as? Double
    private fun fmt(d: Any?): String = if (d is Double && d == Math.floor(d) && !d.isInfinite()) d.toLong().toString() else d.toString()

    @Suppress("UNCHECKED_CAST")
    private fun check(v: Any?, schema: Map<String, Any?>, root: Map<String, Any?>, path: String, file: String, ctx: Ctx) {
        val s = resolve(schema, root)
        val t = s["type"] as? String
        if (t != null && !typeOk(v, t)) { ctx.err("E_TYPE", file, path, "type attendu : $t"); return }
        if (s.containsKey("const") && !same(v, s["const"])) ctx.err("E_ENUM", file, path, "valeur attendue : ${s["const"]}")
        (s["enum"] as? List<Any?>)?.let { e -> if (e.none { same(v, it) }) ctx.err("E_ENUM", file, path, "valeur hors liste : ${e.joinToString(", ")}") }
        if (v is String) {
            val n = v.codePointCount(0, v.length)
            val minL = num(s["minLength"]); val maxL = num(s["maxLength"])
            if ((minL != null && n < minL) || (maxL != null && n > maxL)) ctx.err("E_LENGTH", file, path, "longueur $n hors limites")
            (s["pattern"] as? String)?.let { p -> if (!Regex(p).containsMatchIn(v)) ctx.err("E_PATTERN", file, path, "format invalide (attendu $p)") }
            (s["x-id"] as? String)?.let { table ->
                val set = ctx.ids.getOrPut(table) { HashSet() }
                if (!set.add(v)) ctx.err("E_UNIQUE", file, path, "identifiant « $v » déjà utilisé ($table)")
            }
            (s["x-ref"] as? String)?.let { table -> ctx.refs += arrayOf(table, v, file, path) }
        }
        if (v is Double) {
            num(s["minimum"])?.let { if (v < it) ctx.err("E_MIN", file, path, "minimum ${fmt(it)}") }
            num(s["maximum"])?.let { if (v > it) ctx.err("E_MAX", file, path, "maximum ${fmt(it)}") }
        }
        if (v is Map<*, *>) {
            val obj = v as Map<String, Any?>
            val props = s["properties"] as? Map<String, Any?>
            (s["required"] as? List<Any?>)?.forEach { r -> if (r is String && !obj.containsKey(r)) ctx.err("E_REQUIRED", file, "$path/$r", "champ obligatoire manquant") }
            for ((k, sub) in obj) {
                val ps = props?.get(k) as? Map<String, Any?>
                if (ps != null) check(sub, ps, root, "$path/$k", file, ctx)
                else if (props != null && !k.startsWith("x_")) ctx.add("warning", "W_UNKNOWN", file, "$path/$k", "champ inconnu (ignoré par le jeu)")
            }
            if (s["x-range"] == true) {
                val lo = obj["min"]; val hi = obj["max"]
                if (lo is Double && hi is Double && lo > hi) ctx.err("E_RANGE", file, path, "min > max")
            }
            (s["x-distinct"] as? List<Any?>)?.let { d ->
                val a = d[0] as String; val b = d[1] as String
                if (obj.containsKey(a) && obj.containsKey(b) && same(obj[a], obj[b])) ctx.err("E_DISTINCT", file, path, "« $a » et « $b » doivent être différents")
            }
        }
        if (v is List<*>) {
            val minI = num(s["minItems"]); val maxI = num(s["maxItems"])
            if ((minI != null && v.size < minI) || (maxI != null && v.size > maxI)) ctx.err("E_ITEMS", file, path, "${v.size} élément(s) hors limites")
            (s["items"] as? Map<String, Any?>)?.let { its -> v.forEachIndexed { i, it -> check(it, its, root, "$path/$i", file, ctx) } }
            (s["x-unique-key"] as? List<Any?>)?.let { uk ->
                val keys = uk.map { it as String }
                val seen = HashSet<List<String>>()
                v.forEachIndexed { i, it ->
                    val m = it as? Map<String, Any?>
                    if (m != null && keys.all { k -> m.containsKey(k) }) {
                        if (!seen.add(keys.map { k -> keyOf(m[k]) })) ctx.err("E_UNIQUE", file, "$path/$i", "doublon (${keys.joinToString(", ")})")
                    }
                }
            }
        }
    }

    private fun checkVersion(doc: Any?, file: String, ctx: Ctx) {
        val cv = (doc as? Map<*, *>)?.get("contract_version") as? String ?: return
        val m = SEMVER.find(cv) ?: return
        val major = m.groupValues[1].toBigInteger(); val minor = m.groupValues[2].toBigInteger()
        if (major != CONTRACT_MAJOR.toBigInteger()) ctx.err("E_VERSION", file, "/contract_version", "version majeure $major non prise en charge (attendu $CONTRACT_MAJOR)")
        else if (minor > CONTRACT_MINOR.toBigInteger()) ctx.add("warning", "W_NEWER", file, "/contract_version", "version plus récente : champs nouveaux ignorés")
    }

    private fun parseOrNull(bytes: ByteArray): Pair<Boolean, Any?> =
        try { true to SbhJson.parse(bytes) } catch (e: SbhJson.ParseError) { false to null }

    private fun resolveRefs(ctx: Ctx, onlyTables: Set<String>? = null) {
        for (r in ctx.refs) {
            val (table, value, file, path) = r
            if (onlyTables != null && table !in onlyTables) continue
            if (ctx.ids[table]?.contains(value) != true) ctx.err("E_REF", file, path, "« $value » introuvable dans $table")
        }
    }

    private fun finish(ctx: Ctx) = Result(ctx.issues.sortedWith(compareBy({ it.file }, { it.path }, { it.code }, { it.severity })))

    /** Un fichier seul (règles ou rapport de test) ; références vérifiées vers les tables qu'il définit lui-même. */
    @Suppress("UNCHECKED_CAST")
    fun validateDocument(bytes: ByteArray, schemas: Schemas, file: String = "document.json"): Result {
        val ctx = Ctx()
        val (ok, doc) = parseOrNull(bytes)
        if (!ok) { ctx.err("E_JSON", file, "", "JSON illisible"); return finish(ctx) }
        val kind = (doc as? Map<*, *>)?.get("kind") as? String
        val schema = kind?.let { schemas.byKind[it] }
        if (schema == null) { ctx.err("E_KIND", file, "/kind", "type de document inconnu"); return finish(ctx) }
        checkVersion(doc, file, ctx)
        check(doc, schema, schema, "", file, ctx)
        resolveRefs(ctx, ctx.ids.keys.toSet())
        return finish(ctx)
    }

    /** Un paquet de monde : dossier contenant sbh_world.json et les fichiers qu'il signe. */
    @Suppress("UNCHECKED_CAST")
    fun validatePackage(root: File, schemas: Schemas): Result {
        val ctx = Ctx()
        val mf = File(root, MANIFEST)
        if (!mf.isFile) { ctx.err("E_FILE", MANIFEST, "", "manifeste sbh_world.json absent"); return finish(ctx) }
        val (ok, man) = parseOrNull(mf.readBytes())
        if (!ok) { ctx.err("E_JSON", MANIFEST, "", "JSON illisible"); return finish(ctx) }
        val world = schemas.byKind.getValue("world")
        checkVersion(man, MANIFEST, ctx)
        check(man, world, world, "", MANIFEST, ctx)
        val files = (man as? Map<String, Any?>)?.get("files") as? List<Any?>
        val seenKinds = HashSet<String>()
        files?.forEachIndexed { i, any ->
            val e = any as? Map<String, Any?> ?: return@forEachIndexed
            val rel = e["path"] as? String ?: return@forEachIndexed
            val kind = e["kind"] as? String ?: return@forEachIndexed
            val base = "/files/$i"
            // chemin déjà signalé par le schéma (E_PATTERN / E_LENGTH) : on ne touche pas au disque
            if (rel.codePointCount(0, rel.length) > 200 || !PATH.containsMatchIn(rel)) return@forEachIndexed
            if (rel.startsWith("/") || ".." in rel.split("/")) { ctx.err("E_PATH", MANIFEST, "$base/path", "chemin interdit (absolu ou « .. »)"); return@forEachIndexed }
            when {
                kind in RULE_KINDS -> {
                    if (!seenKinds.add(kind)) { ctx.err("E_UNIQUE", MANIFEST, "$base/kind", "fichier « $kind » déjà déclaré"); return@forEachIndexed }
                }
                kind == "creature" -> {
                    if (!e.containsKey("id")) ctx.err("E_REQUIRED", MANIFEST, "$base/id", "une créature doit avoir un id")
                    else (e["id"] as? String)?.let { id ->
                        if (!ctx.ids.getOrPut("creatures") { HashSet() }.add(id)) ctx.err("E_UNIQUE", MANIFEST, "$base/id", "créature déjà déclarée")
                    }
                }
                kind == "structure" -> ctx.ids.getOrPut("structures") { HashSet() }.add(rel)
                kind == "mesh" -> {
                    if (!e.containsKey("id")) ctx.err("E_REQUIRED", MANIFEST, "$base/id", "un maillage doit avoir un id")
                    else (e["id"] as? String)?.let { id ->
                        if (!ctx.ids.getOrPut("meshes") { HashSet() }.add(id)) ctx.err("E_UNIQUE", MANIFEST, "$base/id", "maillage déjà déclaré")
                    }
                }
                else -> return@forEachIndexed
            }
            val f = File(root, rel)
            if (!f.isFile) { ctx.err("E_FILE", MANIFEST, "$base/path", "fichier absent : $rel"); return@forEachIndexed }
            val data = f.readBytes()
            val sha = e["sha256"] as? String
            if (sha != null && SHA.matches(sha) && sha256(data) != sha) ctx.err("E_HASH", MANIFEST, "$base/sha256", "empreinte sha256 différente (fichier modifié après signature)")
            if (kind == "mesh") {   // fichier binaire glTF 2.0 (.glb), pas du JSON
                glbProblem(data)?.let { (path, msg) -> ctx.err("E_MESH", rel, path, msg) }
                return@forEachIndexed
            }
            val (okDoc, doc) = parseOrNull(data)
            if (!okDoc) { ctx.err("E_JSON", rel, "", "JSON illisible"); return@forEachIndexed }
            if (kind in RULE_KINDS) {
                val schema = schemas.byKind.getValue(kind)
                checkVersion(doc, rel, ctx)
                check(doc, schema, schema, "", rel, ctx)
            } else if (kind == "creature") {
                val fv = (doc as? Map<*, *>)?.get("formatVersion") as? String
                if (fv == null || !fv.startsWith("1.")) ctx.err("E_CREATURE", rel, "/formatVersion", "créature CreatureStudio format 1.x attendue")
            }
        }
        if (files != null && "biomes" !in seenKinds) ctx.err("E_REQUIRED", MANIFEST, "/files", "un fichier de biomes est obligatoire")
        resolveRefs(ctx)
        return finish(ctx)
    }

    const val GLB_MAX = 32 * 1024 * 1024

    /** Contrôle d'un .glb (contrat 1.1, kind « mesh ») : (chemin, message) du 1er problème, ou null. */
    fun glbProblem(data: ByteArray): Pair<String, String>? {
        fun u32(o: Int): Long = (data[o].toLong() and 0xFF) or ((data[o + 1].toLong() and 0xFF) shl 8) or
            ((data[o + 2].toLong() and 0xFF) shl 16) or ((data[o + 3].toLong() and 0xFF) shl 24)
        val n = data.size.toLong()
        if (n > GLB_MAX) return "" to "fichier trop gros (32 Mo au plus)"
        if (n < 20) return "" to "fichier trop court pour un .glb"
        if (u32(0) != 0x46546C67L) return "" to "en-tête « glTF » absent"
        if (u32(4) != 2L) return "" to "glTF version 2 attendue"
        if (u32(8) != n) return "" to "longueur annoncée différente de la taille du fichier"
        val jlen = u32(12)
        if (u32(16) != 0x4E4F534AL || jlen == 0L || 20 + jlen > n) return "" to "bloc JSON absent ou hors du fichier"
        val p = 20 + jlen
        if (p < n) {
            if (p + 8 > n) return "" to "bloc binaire tronqué"
            if (u32(p.toInt() + 4) != 0x004E4942L || p + 8 + u32(p.toInt()) > n) return "" to "bloc binaire invalide ou hors du fichier"
        }
        val (ok, js) = parseOrNull(data.copyOfRange(20, p.toInt()))
        if (!ok) return "" to "bloc JSON du .glb illisible (JSON strict)"
        val asset = (js as? Map<*, *>)?.get("asset") as? Map<*, *>
        if (asset == null || asset["version"] != "2.0") return "/asset/version" to "glTF « asset.version » = « 2.0 » attendu"
        return null
    }

    fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 0xff) }

    /** Résultats sous forme comparable aux cas de conformité : [gravité, code, fichier, chemin]. */
    fun triples(r: Result): List<List<String>> = r.issues.map { listOf(it.severity, it.code, it.file, it.path) }
}
