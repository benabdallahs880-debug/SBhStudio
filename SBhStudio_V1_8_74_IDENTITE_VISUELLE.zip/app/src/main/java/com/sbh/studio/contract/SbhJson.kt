package com.sbh.studio.contract

/**
 * Lecteur JSON minimal (Kotlin pur, sans Android ni bibliothèque) pour le contrat SBH.
 *
 * Valeurs produites : Map<String, Any?> (ordre du fichier conservé), List<Any?>, String, Double,
 * Boolean, et [SbhJson.Null] pour null. Tous les nombres sont des Double (comme Godot), ce qui
 * garde exacts les entiers jusqu'à 2^53. Une erreur de syntaxe lève [SbhJson.ParseError].
 */
object SbhJson {
    object Null { override fun toString() = "null" }

    class ParseError(message: String) : Exception(message)

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.ws()
        val v = p.value()
        p.ws()
        if (p.i != text.length) throw ParseError("caractères en trop à la position ${p.i}")
        return v
    }

    fun parse(bytes: ByteArray): Any? {
        val text = try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                .decode(java.nio.ByteBuffer.wrap(bytes)).toString()
        } catch (e: java.nio.charset.CharacterCodingException) {
            throw ParseError("UTF-8 invalide")
        }
        return parse(text)
    }

    private class Parser(val s: String) {
        var i = 0

        fun ws() {
            while (i < s.length && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++
        }

        fun value(): Any? {
            if (i >= s.length) throw ParseError("fin inattendue")
            return when (s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> word("true", true)
                'f' -> word("false", false)
                'n' -> word("null", Null)
                else -> num()
            }
        }

        fun word(w: String, v: Any): Any {
            if (!s.startsWith(w, i)) throw ParseError("mot inattendu à la position $i")
            i += w.length
            return v
        }

        fun obj(): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>()
            i++
            ws()
            if (i < s.length && s[i] == '}') { i++; return m }
            while (true) {
                ws()
                if (i >= s.length || s[i] != '"') throw ParseError("clé attendue à la position $i")
                val k = str()
                ws()
                if (i >= s.length || s[i] != ':') throw ParseError("« : » attendu à la position $i")
                i++
                ws()
                m[k] = value()
                ws()
                if (i >= s.length) throw ParseError("objet non fermé")
                if (s[i] == ',') { i++; continue }
                if (s[i] == '}') { i++; return m }
                throw ParseError("« , » ou « } » attendu à la position $i")
            }
        }

        fun arr(): List<Any?> {
            val l = ArrayList<Any?>()
            i++
            ws()
            if (i < s.length && s[i] == ']') { i++; return l }
            while (true) {
                ws()
                l.add(value())
                ws()
                if (i >= s.length) throw ParseError("tableau non fermé")
                if (s[i] == ',') { i++; continue }
                if (s[i] == ']') { i++; return l }
                throw ParseError("« , » ou « ] » attendu à la position $i")
            }
        }

        fun str(): String {
            i++
            val b = StringBuilder()
            while (true) {
                if (i >= s.length) throw ParseError("texte non fermé")
                val c = s[i++]
                when {
                    c == '"' -> return b.toString()
                    c == '\\' -> {
                        if (i >= s.length) throw ParseError("échappement incomplet")
                        when (val e = s[i++]) {
                            '"' -> b.append('"'); '\\' -> b.append('\\'); '/' -> b.append('/')
                            'b' -> b.append('\b'); 'f' -> b.append('\u000C'); 'n' -> b.append('\n')
                            'r' -> b.append('\r'); 't' -> b.append('\t')
                            'u' -> {
                                val h = hex4()
                                if (h in 0xD800..0xDBFF) {
                                    // une paire de surrogates doit être complète (sinon : refus, comme Godot)
                                    if (!s.startsWith("\\u", i)) throw ParseError("demi-surrogate isolé")
                                    i += 2
                                    val lo = hex4()
                                    if (lo !in 0xDC00..0xDFFF) throw ParseError("demi-surrogate isolé")
                                    b.append(h.toChar()).append(lo.toChar())
                                } else if (h in 0xDC00..0xDFFF) {
                                    throw ParseError("demi-surrogate isolé")
                                } else b.append(h.toChar())
                            }
                            else -> throw ParseError("échappement inconnu \\$e")
                        }
                    }
                    c.code < 0x20 -> throw ParseError("caractère de contrôle dans un texte")
                    else -> b.append(c)
                }
            }
        }

        fun hex4(): Int {
            if (i + 4 > s.length) throw ParseError("\\u incomplet")
            val t = s.substring(i, i + 4)
            if (!t.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) throw ParseError("\\u invalide")
            i += 4
            return t.toInt(16)
        }

        fun num(): Double {
            val start = i
            if (i < s.length && s[i] == '-') i++
            if (i >= s.length || !s[i].isDigit()) throw ParseError("valeur inattendue à la position $start")
            if (s[i] == '0') i++ else while (i < s.length && s[i].isDigit()) i++
            if (i < s.length && s[i] == '.') {
                i++
                if (i >= s.length || !s[i].isDigit()) throw ParseError("nombre invalide à la position $start")
                while (i < s.length && s[i].isDigit()) i++
            }
            if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
                i++
                if (i < s.length && (s[i] == '+' || s[i] == '-')) i++
                if (i >= s.length || !s[i].isDigit()) throw ParseError("exposant invalide à la position $start")
                while (i < s.length && s[i].isDigit()) i++
            }
            return s.substring(start, i).toDouble()
        }
    }
}
