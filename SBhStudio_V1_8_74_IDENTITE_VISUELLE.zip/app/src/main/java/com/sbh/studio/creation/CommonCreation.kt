package com.sbh.studio.creation

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
enum class CreationSource { MOB, ENTITY, CHARACTER, MESH }

@Serializable
data class CreationRef(val kind: CreationSource, val id: String)

/** The identity is a sidecar: original editor documents are never migrated or flattened. */
@Serializable
data class CommonCreation(
    val id: String,
    val projectId: String,
    val name: String,
    val refs: List<CreationRef>,
    val notes: String = "",
    val aliases: List<CreationAlias> = emptyList(),
    val originId: String? = null
)

@Serializable
data class CreationAlias(val id: String, val name: String, val notes: String,
    val refs: List<CreationRef> = emptyList(), val parentId: String? = null, val originId: String? = null)

data class CreationDescriptor(val ref: CreationRef, val name: String)

object CreationIdentity {
    fun id(projectId: String, ref: CreationRef): String = UUID.nameUUIDFromBytes(
        (projectId.length.toString() + ":" + projectId + ":" + ref.kind.name + ":" + ref.id)
            .toByteArray(Charsets.UTF_8)
    ).toString()

    /** Idempotent discovery. Keep missing references for recovery, never silently transfer ownership. */
    fun reconcile(projectId: String, existing: List<CommonCreation>, sources: List<CreationDescriptor>): List<CommonCreation> {
        require(existing.all { it.projectId == projectId }) { "Registre d'un autre projet" }
        require(existing.map { it.id }.distinct().size == existing.size) { "Identités dupliquées" }
        val identities = existing.flatMap { c -> listOf(c.id) + c.aliases.map { it.id } }
        require(identities.distinct().size == identities.size) { "Anciennes identités dupliquées" }
        val owned = existing.flatMap { it.refs }
        require(owned.distinct().size == owned.size) { "Une source appartient à plusieurs fiches" }
        val seen = owned.toMutableSet()
        return existing + sources.filter { seen.add(it.ref) }.map {
            CommonCreation(id(projectId, it.ref), projectId, it.name, listOf(it.ref))
        }
    }

    fun attach(items: List<CommonCreation>, creationId: String, ref: CreationRef): List<CommonCreation> {
        require(items.any { it.id == creationId }) { "Fiche introuvable" }
        require(items.none { it.id != creationId && ref in it.refs }) { "Source déjà liée à une autre fiche" }
        return items.map { if (it.id == creationId) it.copy(refs = (it.refs + ref).distinct()) else it }
    }

    fun resolve(creation: CommonCreation, available: Set<CreationRef>): List<CreationRef> = creation.refs.filter { it in available }

    fun merge(items: List<CommonCreation>, targetId: String, sourceId: String): List<CommonCreation> {
        require(targetId != sourceId)
        val target = items.first { it.id == targetId }
        val source = items.first { it.id == sourceId }
        require(target.projectId == source.projectId) { "Impossible de relier deux projets" }
        val linked = target.copy(refs = (target.refs + source.refs).distinct(),
            aliases = target.aliases + CreationAlias(source.id, source.name, source.notes, source.refs, originId = source.originId) +
                source.aliases.map { if (it.parentId == null) it.copy(parentId = source.id) else it })
        return items.filter { it.id != sourceId }.map { if (it.id == targetId) linked else it }
    }

    fun unlink(items: List<CommonCreation>, targetId: String, aliasId: String): List<CommonCreation> {
        val target = items.first { it.id == targetId }
        val alias = target.aliases.first { it.id == aliasId }
        require(alias.refs.isNotEmpty() && alias.refs.all { it in target.refs }) { "Ancienne liaison sans références : sépare les documents manuellement" }
        val subtree = mutableSetOf(alias.id)
        while (true) {
            val next = target.aliases.filter { it.parentId?.let { parent -> parent in subtree } == true }.map { it.id }
            if (!subtree.addAll(next)) break
        }
        val restored = CommonCreation(alias.id, target.projectId, alias.name, alias.refs, alias.notes,
            target.aliases.filter { it.id in subtree && it.id != alias.id }.map { if (it.parentId == alias.id) it.copy(parentId = null) else it }, originId = alias.originId)
        val kept = target.copy(refs = target.refs.filter { it !in alias.refs }, aliases = target.aliases.filter { it.id !in subtree }.map {
            it.copy(refs = it.refs.filter { r -> r !in alias.refs })
        })
        require(kept.refs.isNotEmpty()) { "La fiche principale doit garder au moins un document" }
        return items.map { if (it.id == targetId) kept else it } + restored
    }

    /** Detach a missing reference without deleting any editor file. */
    fun detach(items: List<CommonCreation>, targetId: String, ref: CreationRef): List<CommonCreation> {
        val target = items.first { it.id == targetId }
        require(ref in target.refs)
        return items.map { if (it.id == targetId) it.copy(refs = it.refs - ref,
            aliases = it.aliases.map { a -> a.copy(refs = a.refs - ref) }) else it }
    }

    fun duplicate(original: CommonCreation, refs: List<CreationRef>, id: String = UUID.randomUUID().toString()): CommonCreation {
        require(refs.isNotEmpty() && refs.distinct().size == refs.size)
        require(refs.none { it in original.refs }) { "La copie doit avoir ses propres documents" }
        return original.copy(id = id, name = original.name + " — copie", refs = refs, aliases = emptyList(), originId = original.id)
    }
}
