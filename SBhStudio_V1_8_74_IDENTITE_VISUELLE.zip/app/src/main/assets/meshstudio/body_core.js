// SBh Studio — Atelier de personnages : générateur de corps humain (V1.8.66).
// Module ES pur (sans three.js ni DOM), testé sous Node (tools/meshstudio/test_body_core.mjs).
//
// Méthode : le corps est un CHAMP DE DISTANCE fait de volumes anatomiques (crâne, mâchoire, cou,
// trapèzes, cage thoracique, pectoraux, abdomen, bassin, fessiers, deltoïdes, biceps, triceps,
// avant-bras, mains, cuisses, quadriceps, genoux, tibias, mollets, pieds…) fondus les uns dans les
// autres (« union douce »). La peau est la surface où la distance vaut 0 : on l'extrait sur une grille
// (« surface nets ») → un maillage de quads FERMÉ et SYMÉTRIQUE (la grille est centrée sur X = 0 et le
// champ ne dépend que de |x|). Chaque volume porte le nom de son os : prêt pour le squelette (phase 5).
//
// Repère : Y vers le haut, pieds sur Y = 0, le corps regarde vers +Z, mètres. Pose en A (bras à ~40°).

// ------------------------------------------------------------------ distances élémentaires (sans allocation)
function sdEllipsoid(px, py, pz, cx, cy, cz, rx, ry, rz) {
  const x = px - cx, y = py - cy, z = pz - cz;
  const k0 = Math.sqrt((x / rx) ** 2 + (y / ry) ** 2 + (z / rz) ** 2);
  const k1 = Math.sqrt((x / (rx * rx)) ** 2 + (y / (ry * ry)) ** 2 + (z / (rz * rz)) ** 2);
  return k1 > 1e-9 ? k0 * (k0 - 1) / k1 : -Math.min(rx, ry, rz);
}
/** Cône arrondi entre a et b, de rayons r1 (en a) et r2 (en b) — distance exacte (I. Quilez). */
function sdRoundCone(px, py, pz, ax, ay, az, bx, by, bz, r1, r2) {
  const bax = bx - ax, bay = by - ay, baz = bz - az;
  const l2 = bax * bax + bay * bay + baz * baz, rr = r1 - r2, a2 = l2 - rr * rr, il2 = 1 / l2;
  const pax = px - ax, pay = py - ay, paz = pz - az;
  const y = pax * bax + pay * bay + paz * baz, z = y - l2;
  const qx = pax * l2 - bax * y, qy = pay * l2 - bay * y, qz = paz * l2 - baz * y;
  const x2 = qx * qx + qy * qy + qz * qz, y2 = y * y * l2, z2 = z * z * l2;
  const k = Math.sign(rr) * rr * rr * x2;
  if (Math.sign(z) * a2 * z2 > k) return Math.sqrt(x2 + z2) * il2 - r2;
  if (Math.sign(y) * a2 * y2 < k) return Math.sqrt(x2 + y2) * il2 - r1;
  return (Math.sqrt(x2 * a2 * il2) + y * rr) * il2 - r1;
}
const smin = (a, b, k) => { const h = Math.max(k - Math.abs(a - b), 0) / k; return Math.min(a, b) - h * h * k * 0.25; };

// ------------------------------------------------------------------ paramètres (curseurs)
export const BODY_PARAMS = {
  height: { label: 'Taille (m)', def: 1.8, min: 1.4, max: 2.2 },
  build: { label: 'Carrure', def: 1.0, min: 0.8, max: 1.3 },
  muscle: { label: 'Musculature', def: 1.0, min: 0.5, max: 1.6 },
  fat: { label: 'Corpulence', def: 1.0, min: 0.8, max: 1.5 },
  head: { label: 'Tête', def: 1.0, min: 0.85, max: 1.2 },
  sex: { label: 'Homme 0 ↔ 1 Femme', def: 0, min: 0, max: 1 },
  skin: { label: 'Carnation (1 à 6)', def: 3, min: 1, max: 6, int: true },
  outfit: { label: 'Tenue de base (0 / 1)', def: 1, min: 0, max: 1, int: true },
  hair: { label: 'Cheveux (0 / 1)', def: 1, min: 0, max: 1, int: true },
  beard: { label: 'Barbe (0 / 1)', def: 1, min: 0, max: 1, int: true },
  detail: { label: 'Finesse (cm)', def: 1.2, min: 0.8, max: 2.5 },
};
/** Carnations « SBH Arabian Gothic » (planche de l'utilisateur) : très claire → très foncée. */
export const SKIN_TONES = [
  { name: 'Très claire', color: '#E3C2A2' }, { name: 'Claire', color: '#D2A57F' }, { name: 'Moyenne', color: '#B9835C' },
  { name: 'Mate', color: '#9A6644' }, { name: 'Foncée', color: '#6F4630' }, { name: 'Très foncée', color: '#4A2E20' },
];
export function bodyParams(p = {}) {
  const out = {};
  for (const [k, d] of Object.entries(BODY_PARAMS)) {
    const v = +p[k];
    out[k] = Number.isFinite(v) ? Math.min(d.max, Math.max(d.min, v)) : d.def;
    if (d.int) out[k] = Math.round(out[k]);
  }
  return out;
}

/**
 * Liste des volumes pour un jeu de paramètres (côté droit x ≥ 0 ; le côté gauche est le reflet).
 * Chaque volume : { t: 'e' (ellipsoïde) | 'c' (cône arrondi), bone, k (douceur de fusion), … }.
 * Proportions de base : 1,80 m, ~7,5 têtes, pose en A.
 */
export function bodyParts(P) {
  const B = P.build, Mu = P.muscle, F = P.fat, Hd = P.head, Fe = P.sex;
  const L = (a, b) => a + (b - a) * Fe;                // homme → femme
  const parts = [];
  const E = (bone, k, c, r) => parts.push({ t: 'e', bone, k, c, r });
  const S = (bone, k, c, r) => parts.push({ t: 'e', bone, k, c, r, sub: true });   // creux (orbites)
  const C = (bone, k, a, b, r1, r2) => parts.push({ t: 'c', bone, k, a, b, r1, r2 });
  const m = (v) => v * (0.75 + 0.25 * Mu);          // volume musculaire
  const f = (v) => v * F;                           // volume de graisse / tronc
  const ms = (v) => v * (0.4 + 0.6 * Mu);           // muscle très sensible (pectoraux : plats si peu musclé)
  const md = (v) => v * (0.88 + 0.12 * Mu);         // muscle peu sensible (trapèzes, cou)
  // tête : crâne ovale + masse du visage + vraie ligne de mâchoire (oreille → menton), nez, lèvres, orbites
  const J = (bone, k, a, b, r1, r2) => parts.push({ t: 'c', bone, k, a, b, r1, r2, jaw: true });
  const Jc = (bone, k, c, r) => parts.push({ t: 'e', bone, k, c, r, jaw: true });
  E('head', 0.03, [0, 1.68, -0.005], [0.077 * Hd, 0.1 * Hd, 0.094 * Hd]);                       // crâne
  E('head', 0.035, [0, 1.648, 0.034 * Hd], [L(0.062, 0.057) * Hd, 0.07 * Hd, 0.068 * Hd]);     // masse du visage
  J('head', 0.035, [0.058 * Hd, 1.632, -0.008], [L(0.022, 0.018) * Hd, 1.57, 0.066 * Hd], L(0.021, 0.017) * Hd, L(0.016, 0.012) * Hd); // mâchoire
  Jc('head', 0.03, [0, 1.567, 0.07 * Hd], [L(0.021, 0.016) * Hd, L(0.017, 0.014), 0.016]);       // menton
  C('head', 0.012, [0, 1.676, 0.086 * Hd], [0, 1.634, 0.103 * Hd], 0.0075 * Hd, L(0.0105, 0.009) * Hd); // arête du nez
  E('head', 0.01, [0, 1.632, 0.099 * Hd], [L(0.013, 0.011) * Hd, 0.0105, 0.011]);               // pointe du nez
  E('head', 0.01, [0.0105 * Hd, 1.627, 0.093 * Hd], [0.008 * Hd, 0.006, 0.007]);                // narines
  E('head', 0.008, [0, 1.6125, 0.0855 * Hd], [0.0175 * Hd, 0.005, L(0.0072, 0.008)]);           // lèvre supérieure
  E('head', 0.008, [0, 1.6015, 0.0835 * Hd], [0.0155 * Hd, 0.006, L(0.0078, 0.0088)]);          // lèvre inférieure
  S('head', 0.012, [0.031 * Hd, 1.668, 0.093 * Hd], [0.0165 * Hd, 0.0115, 0.014]);             // orbites
  E('head', 0.005, [0.031 * Hd, 1.667, 0.081 * Hd], [0.0122 * Hd, 0.0092, 0.0102]);             // yeux
  E('head', 0.018, [0.031 * Hd, 1.6855, 0.083 * Hd], [0.022 * Hd, L(0.0075, 0.0055), 0.01]);   // sourcils (arcade)
  E('head', 0.03, [0.046 * Hd, 1.645, 0.06 * Hd], [0.019 * Hd, 0.016, 0.019]);                  // pommettes
  E('head', 0.012, [0.077 * Hd, 1.655, -0.006], [0.01, 0.026, 0.016]);                          // oreilles
  C('neck', 0.05, [0, 1.5, -0.012], [0, 1.6, -0.005], md(0.056) * (0.9 + 0.1 * B) * L(1, 0.84), L(0.047, 0.041));
  C('spine2', 0.07, [0.02, 1.515, -0.035], [0.17 * B * L(1, 0.88), 1.47, -0.02], md(0.058) * L(1, 0.72), md(0.04) * L(1, 0.8)); // trapèzes
  // tronc : en V (épaules larges, taille fine)
  E('spine2', 0.07, [0, 1.37, -0.01], [0.15 * B * L(1, 0.86), 0.165, f(0.1) * L(1, 0.92)]); // cage thoracique
  if (Fe < 0.95) E('spine2', 0.06, [0.07 * B, 1.39, 0.05], [0.085 * B * L(1, 0.8), 0.052, ms(0.034) * (1 - Fe)]);   // pectoraux
  if (Fe > 0.15) E('spine2', 0.05, [0.07, 1.355, 0.058], [0.058 * (0.6 + 0.4 * Fe), 0.056 * (0.6 + 0.4 * Fe), 0.05 * Fe]); // poitrine
  E('spine2', 0.07, [0.085 * B * L(1, 0.85), 1.31, -0.045], [m(0.072) * B * L(1, 0.72), 0.11, m(0.045)]); // grands dorsaux (V du dos)
  E('spine1', 0.1, [0, 1.17, 0.0], [f(0.124) * (0.94 + 0.06 * B) * L(1, 0.76), 0.15, f(0.09) * L(1, 0.88)]); // taille / abdomen
  if (Mu > 0.7 && F < 1.2) for (const [y, w] of [[1.24, 0.03], [1.18, 0.031], [1.12, 0.03]])          // abdominaux (discrets)
    E('spine1', 0.03, [0.026, y, 0.072 + 0.01 * (F - 1)], [w, 0.026, ms(0.014) * (1 - 0.6 * Fe) * (1.25 - F)]);
  E('spine1', 0.1, [0, 1.14, 0.025 + 0.05 * (F - 1)], [f(0.1), 0.1, f(0.065)]);     // ventre (plat sauf corpulence)
  E('hips', 0.09, [0, 0.995, -0.005], [f(0.13) * L(1, 1.16), 0.105, f(0.1) * L(1, 1.05)]); // bassin
  E('hips', 0.05, [0.065 * L(1, 1.12), 0.965, -0.065], [m(0.07) * F * L(1, 1.12), m(0.075) * L(1, 1.08), m(0.055) * F * L(1, 1.12)]); // fessiers
  // bras (pose en A, ~40° sous l'horizontale) : muscles alignés sur l'axe du bras (cônes arrondis)
  const sh = [0.2 * B * L(1, 0.87), 1.45, -0.01];
  const A = L(1, 0.84);                               // bras plus fins pour la femme
  const dir = [Math.sin(0.70), -Math.cos(0.70), 0.0];
  const at = (o, d, l, dz = 0, dn = 0) => [o[0] + d[0] * l - d[1] * dn, o[1] + d[1] * l + d[0] * dn, o[2] + dz];
  const el = at(sh, dir, 0.29, -0.015), wr = at(el, dir, 0.255, 0.03), hd = at(wr, dir, 0.09, 0.01);
  C('upperarm', 0.06, [sh[0] - 0.03, sh[1] + 0.035, sh[2]], at(sh, dir, 0.13, 0.0, 0.005), (m(0.065)) * A, (m(0.045)) * A);  // deltoïde (coiffe l'épaule)
  C('upperarm', 0.04, sh, el, (m(0.046) * F ** 0.5) * A, (0.036) * A);
  C('upperarm', 0.045, at(sh, dir, 0.07, 0.022), at(sh, dir, 0.22, 0.022), (m(0.032)) * A, (m(0.026)) * A);   // biceps
  C('upperarm', 0.045, at(sh, dir, 0.06, -0.024), at(sh, dir, 0.23, -0.022), (m(0.034)) * A, (m(0.024)) * A); // triceps
  C('forearm', 0.035, el, wr, (m(0.038)) * A, (0.025) * A);
  C('forearm', 0.04, at(el, dir, 0.02, 0.008), at(el, dir, 0.15, 0.012), (m(0.036)) * A, (0.026) * A);        // avant-bras charnu
  E('hand', 0.025, at(wr, dir, 0.05, 0.012), [0.03 * A, 0.045 * L(1, 0.9), 0.048 * L(1, 0.9)]);                               // paume
  C('hand', 0.02, at(wr, dir, 0.06, 0.016), at(hd, dir, 0.05, 0.022), 0.03 * A, 0.02 * A);                // doigts (moufle)
  C('hand', 0.016, at(wr, dir, 0.025, 0.04), at(wr, dir, 0.075, 0.07), 0.016 * A, 0.012 * A);             // pouce
  // jambes
  const hp = [0.092, 0.94, 0.0], kn = [0.098, 0.5, 0.012], an = [0.1, 0.085, -0.012];
  C('upperleg', 0.05, hp, kn, m(0.09) * F ** 0.5, 0.054);
  E('upperleg', 0.045, [0.098, 0.72, 0.035], [m(0.066), 0.16, m(0.058)]);            // quadriceps
  E('upperleg', 0.045, [0.12, 0.77, -0.005], [m(0.048), 0.15, m(0.052)]);            // vaste externe
  E('upperleg', 0.04, [0.072, 0.78, 0.0], [m(0.04), 0.12, m(0.045)]);                // adducteurs
  E('lowerleg', 0.025, [0.098, 0.5, 0.032], [0.043, 0.045, 0.034]);                  // genou
  C('lowerleg', 0.035, kn, an, 0.047, 0.03);
  E('lowerleg', 0.04, [0.102, 0.37, -0.028], [m(0.048), 0.1, m(0.046)]);             // mollet
  C('foot', 0.03, [0.1, 0.045, -0.035], [0.108, 0.03, 0.15], 0.042, 0.03);           // pied
  E('foot', 0.025, [0.1, 0.065, -0.01], [0.035, 0.04, 0.048]);                        // cheville
  return parts;
}

/** Distance signée au corps (négative à l'intérieur) ; symétrique en X. */
export function bodySDF(parts, s) {
  // sphère englobante de chaque volume : si le point en est plus loin que d + k, le volume ne change rien
  // à l'union douce (smin(d, v, k) = d dès que v ≥ d + k) → on ne le calcule pas (résultat identique).
  for (const q of parts) {
    if (q.bc) continue;
    if (q.t === 'e') { q.bc = q.c; q.br = Math.max(...q.r); }
    else { q.bc = [(q.a[0] + q.b[0]) / 2, (q.a[1] + q.b[1]) / 2, (q.a[2] + q.b[2]) / 2]; q.br = Math.hypot(q.a[0] - q.b[0], q.a[1] - q.b[1], q.a[2] - q.b[2]) / 2 + Math.max(q.r1, q.r2); }
  }
  return (px, py, pz) => {
    const x = Math.abs(px) / s, y = py / s, z = pz / s;
    let d = 1e9;
    for (const q of parts) {
      if (d !== 1e9) {
        const lb = Math.hypot(x - q.bc[0], y - q.bc[1], z - q.bc[2]) - q.br;
        if (q.sub ? lb >= q.k : lb >= d + q.k) continue;   // creux : sans effet si le point est hors de sa zone
      }
      const v = q.t === 'e'
        ? sdEllipsoid(x, y, z, q.c[0], q.c[1], q.c[2], q.r[0], q.r[1], q.r[2])
        : sdRoundCone(x, y, z, q.a[0], q.a[1], q.a[2], q.b[0], q.b[1], q.b[2], q.r1, q.r2);
      if (q.sub) { d = -smin(-d, v, q.k); continue; }    // creux : soustraction douce
      d = d === 1e9 ? v : smin(d, v, q.k);
    }
    d = Math.max(d, -y + 0.002);           // plante des pieds à plat
    return d * s;
  };
}

/**
 * Extraction de la surface (« surface nets ») : un sommet par cellule traversée, une face (quad) par
 * arête de grille traversée. Grille centrée sur X = 0 → maillage exactement symétrique.
 * Renvoie { verts, faces } (quads, normales sortantes).
 */
export function surfaceNets(f, min, max, h) {
  const nx = 2 * Math.ceil(Math.max(Math.abs(min[0]), Math.abs(max[0])) / h) + 1;   // impair : nœud en x = 0
  const x0 = -((nx - 1) / 2) * h;
  const ny = Math.ceil((max[1] - min[1]) / h) + 1, nz = Math.ceil((max[2] - min[2]) / h) + 1;
  const y0 = min[1], z0 = min[2];
  const idx = (i, j, k) => (k * ny + j) * nx + i;
  const val = new Float32Array(nx * ny * nz);
  // 1) passe grossière (1 nœud sur C) ; 2) nœuds fins calculés seulement dans une bande autour de la peau.
  // Loin de la peau seul le signe compte : on reprend la valeur grossière la plus proche (même signe,
  // la marge BAND couvre largement l'écart entre un nœud fin et son nœud grossier).
  const C = 4, mid = (nx - 1) / 2, BAND = 3.0 * C * h;
  const cx = (i) => Math.min(nx - 1, Math.max(mid, mid + Math.round((i - mid) / C) * C));
  const cyz = (j, n) => Math.min(n - 1, Math.round(j / C) * C);
  const coarse = new Map();
  const cval = (i, j, k) => { const key = (k * ny + j) * nx + i; let v = coarse.get(key); if (v === undefined) { v = f(x0 + i * h, y0 + j * h, z0 + k * h); coarse.set(key, v); } return v; };
  for (let k = 0; k < nz; k++) for (let j = 0; j < ny; j++) for (let i = Math.ceil(mid); i < nx; i++) {
    const vc = cval(cx(i), cyz(j, ny), cyz(k, nz));
    val[idx(i, j, k)] = Math.abs(vc) > BAND ? vc : f(x0 + i * h, y0 + j * h, z0 + k * h);
  }
  for (let k = 0; k < nz; k++) for (let j = 0; j < ny; j++) for (let i = 0; i < mid; i++) val[idx(i, j, k)] = val[idx(nx - 1 - i, j, k)];
  // sommets : un par cellule (i,j,k)-(i+1,j+1,k+1) traversée
  const cellV = new Int32Array((nx - 1) * (ny - 1) * (nz - 1)).fill(-1);
  const cid = (i, j, k) => (k * (ny - 1) + j) * (nx - 1) + i;
  const verts = [];
  const E = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]];
  const corner = (c) => [c & 1, (c >> 1) & 1, (c >> 2) & 1];
  for (let k = 0; k < nz - 1; k++) for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
    const v = []; let neg = 0;
    for (let c = 0; c < 8; c++) { const [a, b, d] = corner(c); v.push(val[idx(i + a, j + b, k + d)]); if (v[c] < 0) neg++; }
    if (neg === 0 || neg === 8) continue;
    let sx = 0, sy = 0, sz = 0, n = 0;
    for (const [p, q] of E) {
      if ((v[p] < 0) === (v[q] < 0)) continue;
      const t = v[p] / (v[p] - v[q]), A = corner(p), Bq = corner(q);
      sx += A[0] + (Bq[0] - A[0]) * t; sy += A[1] + (Bq[1] - A[1]) * t; sz += A[2] + (Bq[2] - A[2]) * t; n++;
    }
    cellV[cid(i, j, k)] = verts.length;
    verts.push([x0 + (i + sx / n) * h, y0 + (j + sy / n) * h, z0 + (k + sz / n) * h]);
  }
  // faces : une par arête de grille traversée, entre les 4 cellules qui la partagent
  const faces = [];
  const quad = (a, b, c, d, flip) => { if (a < 0 || b < 0 || c < 0 || d < 0) return; faces.push(flip ? [a, d, c, b] : [a, b, c, d]); };
  for (let k = 1; k < nz - 1; k++) for (let j = 1; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {      // arêtes en X
    const s0 = val[idx(i, j, k)] < 0, s1 = val[idx(i + 1, j, k)] < 0; if (s0 === s1) continue;
    quad(cellV[cid(i, j - 1, k - 1)], cellV[cid(i, j, k - 1)], cellV[cid(i, j, k)], cellV[cid(i, j - 1, k)], !s0);
  }
  for (let k = 1; k < nz - 1; k++) for (let j = 0; j < ny - 1; j++) for (let i = 1; i < nx - 1; i++) {      // arêtes en Y
    const s0 = val[idx(i, j, k)] < 0, s1 = val[idx(i, j + 1, k)] < 0; if (s0 === s1) continue;
    quad(cellV[cid(i - 1, j, k - 1)], cellV[cid(i - 1, j, k)], cellV[cid(i, j, k)], cellV[cid(i, j, k - 1)], !s0);
  }
  for (let k = 0; k < nz - 1; k++) for (let j = 1; j < ny - 1; j++) for (let i = 1; i < nx - 1; i++) {      // arêtes en Z
    const s0 = val[idx(i, j, k)] < 0, s1 = val[idx(i, j, k + 1)] < 0; if (s0 === s1) continue;
    quad(cellV[cid(i - 1, j - 1, k)], cellV[cid(i, j - 1, k)], cellV[cid(i, j, k)], cellV[cid(i - 1, j, k)], !s0);
  }
  return { verts, faces };
}

/**
 * Rend le maillage « variété » (manifold) : là où deux nappes de peau se touchent par une arête ou
 * un sommet (cas connu des surface nets, ex. pouce contre paume), le sommet est dédoublé pour chaque
 * nappe. Les arêtes partagées par 4 faces sont appariées par orientation (normales les plus proches).
 */
export function makeManifold(mesh) {
  const faces = mesh.faces.map((f) => [...f]), verts = mesh.verts.map((p) => [...p]);
  const nrm = (f) => { let x = 0, y = 0, z = 0; for (let i = 0; i < f.length; i++) { const a = verts[f[i]], b = verts[f[(i + 1) % f.length]]; x += (a[1] - b[1]) * (a[2] + b[2]); y += (a[2] - b[2]) * (a[0] + b[0]); z += (a[0] - b[0]) * (a[1] + b[1]); } const l = Math.hypot(x, y, z) || 1; return [x / l, y / l, z / l]; };
  // arête non orientée → faces (avec le sens a→b)
  const byEdge = new Map();
  faces.forEach((f, fi) => { for (let i = 0; i < f.length; i++) { const a = f[i], b = f[(i + 1) % f.length], k = a < b ? a + '-' + b : b + '-' + a; if (!byEdge.has(k)) byEdge.set(k, []); byEdge.get(k).push({ fi, fwd: a < b }); } });
  // appariement des faces de part et d'autre de chaque arête
  const partner = new Map();   // "fi|edgekey" → fi voisin
  for (const [k, list] of byEdge) {
    const A = list.filter((e) => e.fwd), Bl = list.filter((e) => !e.fwd);
    if (A.length === 1 && Bl.length === 1) { partner.set(A[0].fi + '|' + k, Bl[0].fi); partner.set(Bl[0].fi + '|' + k, A[0].fi); continue; }
    const used = new Set();
    for (const a of A) {
      const na = nrm(faces[a.fi]); let best = null, bd = -2;
      for (const b of Bl) { if (used.has(b.fi)) continue; const nb = nrm(faces[b.fi]); const d = na[0] * nb[0] + na[1] * nb[1] + na[2] * nb[2]; if (d > bd) { bd = d; best = b; } }
      if (best) { used.add(best.fi); partner.set(a.fi + '|' + k, best.fi); partner.set(best.fi + '|' + k, a.fi); }
    }
  }
  // éventails autour de chaque sommet : faces reliées par une arête incidente appariée
  const around = Array.from({ length: verts.length }, () => []);
  faces.forEach((f, fi) => f.forEach((v) => around[v].push(fi)));
  let split = 0;
  for (let v = 0; v < around.length; v++) {
    const fs = around[v]; if (fs.length < 2) continue;
    const par = new Map(fs.map((f) => [f, f])); const find = (x) => { while (par.get(x) !== x) x = par.get(x); return x; };
    for (const fi of fs) {
      const f = faces[fi], i = f.indexOf(v);
      for (const w of [f[(i + 1) % f.length], f[(i - 1 + f.length) % f.length]]) {
        const k = v < w ? v + '-' + w : w + '-' + v, o = partner.get(fi + '|' + k);
        if (o !== undefined && par.has(o)) par.set(find(fi), find(o));
      }
    }
    const groups = new Map(); for (const fi of fs) { const r = find(fi); if (!groups.has(r)) groups.set(r, []); groups.get(r).push(fi); }
    if (groups.size < 2) continue;
    let first = true;
    for (const g of groups.values()) {
      if (first) { first = false; continue; }
      const nv = verts.length; verts.push([...verts[v]]); split++;
      for (const fi of g) faces[fi] = faces[fi].map((x) => (x === v ? nv : x));
    }
  }
  return { verts, faces, split };
}

/** Chaque arête orientée est utilisée une fois et a son inverse : peau fermée, sans pincement. */
export function isClosedManifold(mesh) {
  const d = new Map();
  for (const fc of mesh.faces) for (let i = 0; i < fc.length; i++) { const k = fc[i] * 4194304 + fc[(i + 1) % fc.length]; if (d.has(k)) return false; d.set(k, 1); }
  for (const fc of mesh.faces) for (let i = 0; i < fc.length; i++) if (!d.has(fc[(i + 1) % fc.length] * 4194304 + fc[i])) return false;
  return true;
}

/** Lissage doux qui garde le volume (Taubin λ/μ), puis recollage sur la surface du champ. */
function relax(mesh, f, iters = 4) {
  const n = mesh.verts.length, nb = Array.from({ length: n }, () => new Set());
  for (const fc of mesh.faces) for (let i = 0; i < fc.length; i++) { const a = fc[i], b = fc[(i + 1) % fc.length]; nb[a].add(b); nb[b].add(a); }
  let V = mesh.verts.map((p) => [...p]);
  const step = (lam) => {
    V = V.map((p, i) => {
      if (!nb[i].size) return p;
      let x = 0, y = 0, z = 0; for (const j of nb[i]) { x += V[j][0]; y += V[j][1]; z += V[j][2]; }
      const c = nb[i].size; return [p[0] + lam * (x / c - p[0]), p[1] + lam * (y / c - p[1]), p[2] + lam * (z / c - p[2])];
    });
  };
  for (let t = 0; t < iters; t++) { step(0.5); step(-0.53); }
  // reprojection sur la peau (2 pas de Newton le long du gradient)
  // reprojection sur la peau : un pas de Newton (différences avant : 4 évaluations du champ par sommet)
  const e = 2e-4;
  V = V.map((p) => {
    const [x, y, z] = p, d = f(x, y, z);
    const gx = (f(x + e, y, z) - d) / e, gy = (f(x, y + e, z) - d) / e, gz = (f(x, y, z + e) - d) / e;
    const g2 = gx * gx + gy * gy + gz * gz; if (g2 < 1e-12) return p;
    return [x - d * gx / g2, y - d * gy / g2, z - d * gz / g2];
  });
  // symétrie exacte : chaque sommet du plan reste à x = 0
  return { verts: V, faces: mesh.faces };
}

/**
 * Extrait une surface fermée, d'un seul tenant et symétrique d'un champ de distance (corps ou vêtement).
 * Si la peau sort « pincée », l'extraction est refaite avec la grille décalée en Y/Z (jamais en X).
 */
export function extractSurface(f, min, max, h, relaxIters = 3) {
  let mesh = null, mf = null, tries = 0;
  for (const [oy, oz] of [[0, 0], [0.37, 0.21], [0.71, 0.53], [0.19, 0.83], [0.55, 0.11]]) {
    tries++;
    const raw = surfaceNets(f, [min[0], min[1] + oy * h, min[2] + oz * h], max, h);
    if (isClosedManifold(raw)) { mesh = raw; mf = { split: 0 }; break; }
    const rep = makeManifold(raw);
    if (isClosedManifold(rep)) { mesh = rep; mf = rep; break; }
    if (!mesh) { mesh = rep; mf = rep; }          // dernier recours : la meilleure tentative
  }
  mesh = { verts: mesh.verts, faces: mesh.faces };
  const raw = mesh.verts.map((p) => [...p]);
  mesh = relax(mesh, f, relaxIters);
  // symétrie exacte par construction : un sommet, son reflet et leurs doubles reçoivent la même position
  return { mesh: symmetrize(mesh, raw), split: mf.split, attempts: tries };
}

/**
 * Corps humain complet : { mesh (quads, fermé, symétrique), garments [{name, color, mesh}], skin (couleur),
 * params, parts }. detail = taille de cellule en cm (1,2 cm ≈ 18 000 faces).
 * Tenue de base (outfit = 1) : un short (et une brassière si sex ≥ 0,5), coques à 7 mm de la peau, posées
 * comme des vêtements séparés (premier pas des couches d'habillage).
 */
export function humanBody(p = {}) {
  const P = bodyParams(p), s = P.height / 1.8, h = P.detail / 100;
  const parts = bodyParts(P), f = bodySDF(parts, s);
  // Le corps s'arrête au milieu du cou ; la TÊTE est une pièce à part, calculée ~3 fois plus finement
  // (nez, lèvres, paupières < 1 cm), gonflée de 1,2 mm pour recouvrir le haut du cou sans scintillement.
  const NECK_CUT = 1.585, HEAD_FROM = 1.548;   // raccord juste sous la mâchoire (à l'ombre du menton)
  const fBody = (x, y, z) => Math.max(f(x, y, z), y - NECK_CUT * s);
  const body = extractSurface(fBody, [-0.85 * s, -0.02, -0.25 * s], [0.85 * s, 1.65 * s, 0.3 * s], h);
  const hh = Math.max(0.3, P.detail * 0.36) / 100;
  // bas de la tête : 2 mm SOUS la peau du cou (caché), puis 1,2 mm au-dessus dès 2 cm plus haut → les deux
  // surfaces se croisent sans rebord visible (pas d'anneau au cou)
  const off = (y) => { const t = Math.min(1, Math.max(0, (y / s - HEAD_FROM) / 0.02)); const e = t * t * (3 - 2 * t); return (-0.002 + 0.0032 * e) * s; };
  const fHead = (x, y, z) => Math.max(f(x, y, z) - off(y), HEAD_FROM * s - y,
    y < 1.575 * s ? Math.hypot(x, z + 0.012 * s) - 0.072 * s : -1);   // sous le menton : cylindre du cou
  const head = extractSurface(fHead, [-0.13 * s, (HEAD_FROM - 0.02) * s, -0.14 * s], [0.13 * s, 1.84 * s, 0.15 * s], hh, 2);
  const garments = [];
  const cone = (x, y, z, a, b, r) => sdRoundCone(Math.abs(x) / s, y / s, z / s, a[0], a[1], a[2], b[0], b[1], b[2], r, r) * s;
  const shell = (off) => (x, y, z) => f(x, y, z) - off * s;
  if (P.outfit) {
    const gh = Math.min(0.9, Math.max(0.6, P.detail * 0.85)) / 100;   // vêtements : grille ≤ 9 mm (bretelles fines)
    const band = (y0, y1, xmax) => (x, y, z) => Math.max(f(x, y, z) - 0.007 * s, y0 * s - y, y - y1 * s, Math.abs(x) - xmax * s);
    const shorts = band(0.74, 1.06, 0.3);
    garments.push({ name: 'Short', color: '#18181C', mesh: extractSurface(shorts, [-0.32 * s, 0.7 * s, -0.2 * s], [0.32 * s, 1.1 * s, 0.22 * s], gh, 2).mesh });
    if (P.sex >= 0.5) {
      // brassière de sport : bandeau sous la poitrine + bretelles qui passent sur les épaules
      const top = band(1.27, 1.43, 0.17);
      const bra = (x, y, z) => Math.min(top(x, y, z),
        cone(x, y, z, [0.075, 1.41, 0.07], [0.1, 1.5, 0.0], 0.011), cone(x, y, z, [0.1, 1.5, 0.0], [0.075, 1.4, -0.075], 0.011));
      garments.push({ name: 'Brassière', color: '#18181C', mesh: extractSurface(bra, [-0.2 * s, 1.24 * s, -0.18 * s], [0.2 * s, 1.56 * s, 0.2 * s], gh, 2).mesh });
    }
  }
  const fine = Math.min(P.detail, 1.0) * 0.55 / 100;     // cheveux et barbe : grille fine (zone petite)
  if (P.hair) {
    // cheveux : coque sur le crâne au-dessus d'une ligne front → nuque (+ chignon pour la femme)
    const Hd = P.head;
    const hairF = (x, y, z) => {
      // ligne d'implantation : haute sur le front (1,70), plus basse sur les tempes et la nuque (1,60)
      const Z = z / s, X = Math.abs(x) / s;
      const line = Z > 0.03 ? 1.702 - 0.25 * Math.max(0, X - 0.035) : 1.702 - (0.03 - Z) * 0.85 - 0.2 * Math.max(0, X - 0.05) * (Z > -0.04 ? 1 : 0);
      // épaisseur qui monte de 1,5 mm à la ligne d'implantation jusqu'à 9 mm (homme) / 14 mm (femme) en haut
      const t = Math.min(1, Math.max(0, (y / s - line) / 0.045));
      let d = Math.max(f(x, y, z) - (0.0015 + t * (P.sex >= 0.5 ? 0.0125 : 0.0075)) * s, line * s - y);
      if (P.sex >= 0.5) d = Math.min(d, sdEllipsoid(Math.abs(x) / s, y / s, z / s, 0, 1.715, -0.108 * Hd, 0.045, 0.042, 0.04) * s);
      return d;
    };
    garments.push({ name: P.sex >= 0.5 ? 'Cheveux (chignon)' : 'Cheveux courts', color: '#1C1410',
      mesh: extractSurface(hairF, [-0.16 * s, 1.52 * s, -0.2 * s], [0.16 * s, 1.85 * s, 0.17 * s], fine, 2).mesh });
  }
  if (P.beard && P.sex < 0.5) {
    // barbe courte : coque autour de la mâchoire et du menton (pas du cou) + moustache, bouche dégagée
    const jawParts = parts.filter((q) => q.jaw).concat([{ t: 'e', k: 0.01, c: [0, 1.618, 0.093 * P.head], r: [0.021 * P.head, 0.0055, 0.008] }]);
    const fj = bodySDF(jawParts, s);
    const beardF = (x, y, z) => {
      const X = Math.abs(x) / s, Y = y / s;
      const mouth = 1 - Math.hypot(X / 0.022, (Y - 1.606) / 0.0105);           // > 0 autour de la bouche
      return Math.max(fj(x, y, z) - 0.016 * s, f(x, y, z) - 0.006 * s, mouth * 0.01 * s, (Y - 1.64) * s, (1.535 - Y) * s);
    };
    garments.push({ name: 'Barbe', color: '#1C1410', mesh: extractSurface(beardF, [-0.15 * s, 1.5 * s, -0.05 * s], [0.15 * s, 1.68 * s, 0.16 * s], fine, 2).mesh });
  }
  return { mesh: body.mesh, head: head.mesh, garments, skin: SKIN_TONES[P.skin - 1].color, params: P, parts, sdf: f, splitVertices: body.split, attempts: body.attempts };
}

/**
 * Rend la symétrie exacte. Les positions AVANT lissage (raw) sont exactement symétriques (grille et champ
 * symétriques) : elles servent à grouper chaque sommet avec son reflet et ses éventuels doubles. Chaque
 * groupe reçoit la moyenne (dans le demi-espace x ≥ 0) des positions lissées, reflétée de son côté.
 */
function symmetrize(mesh, raw) {
  const key = (p) => [Math.round(Math.abs(p[0]) * 1e6), Math.round(p[1] * 1e6), Math.round(p[2] * 1e6)].join(',');
  const groups = new Map();
  raw.forEach((p, i) => { const k = key(p); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(i); });
  const V = mesh.verts.map((p) => [...p]);
  for (const ids of groups.values()) {
    let x = 0, y = 0, z = 0;
    for (const i of ids) { x += Math.abs(mesh.verts[i][0]); y += mesh.verts[i][1]; z += mesh.verts[i][2]; }
    x /= ids.length; y /= ids.length; z /= ids.length;
    for (const i of ids) {
      const onPlane = Math.abs(raw[i][0]) < 1e-9;
      V[i] = [onPlane ? 0 : (raw[i][0] < 0 ? -x : x), y, z];
    }
  }
  return { verts: V, faces: mesh.faces };
}

/** Normales douces par sommet (moyenne des faces voisines pondérée par l'aire). */
export function vertexNormals(mesh) {
  const N = mesh.verts.map(() => [0, 0, 0]);
  for (const f of mesh.faces) {
    let nx = 0, ny = 0, nz = 0;
    for (let i = 0; i < f.length; i++) {
      const a = mesh.verts[f[i]], b = mesh.verts[f[(i + 1) % f.length]];
      nx += (a[1] - b[1]) * (a[2] + b[2]); ny += (a[2] - b[2]) * (a[0] + b[0]); nz += (a[0] - b[0]) * (a[1] + b[1]);
    }
    for (const i of f) { N[i][0] += nx; N[i][1] += ny; N[i][2] += nz; }
  }
  return N.map(([x, y, z]) => { const l = Math.hypot(x, y, z) || 1; return [x / l, y / l, z / l]; });
}
