import {validMask as validSculptMask} from './mesh_sculpt_core.js';
import { validVolume } from './sculpt_core.js';
// SBh Studio — Modeleur 3D : cœur géométrique (V1.8.65).
// Module ES pur (aucune dépendance, ni three.js ni DOM) : utilisé par mesh_studio.html et testé sous
// Node (tools/meshstudio/test_mesh_core.mjs).
//
// Modèle : un maillage = { verts: [[x,y,z], …], faces: [[i, j, k, …], …] } — polygones (triangles,
// quads, n-gones) dont les sommets sont dans le sens inverse des aiguilles d'une montre vu de
// l'extérieur (normale sortante, repère Y vers le haut comme glTF / Godot). Un objet de scène =
// { id, name, color, mesh, pos:[x,y,z], rot:[deg x,y,z] (ordre XYZ), scale:[x,y,z] }.

export const EPS = 1e-6;
export function validForge(v) {
  return !!v && v.version===1 && v.kind==='plate' && v.params && ['w','h','thickness','hole','holeX','holeY','bend'].every(k=>Number.isFinite(v.params[k])) && v.params.w>0 && v.params.h>0 && v.params.thickness>0;
}


// ------------------------------------------------------------------ vecteurs
export const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
export const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
export const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
export const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
export const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
export const len = (a) => Math.hypot(a[0], a[1], a[2]);
export const norm = (a) => { const l = len(a); return l > 1e-12 ? mul(a, 1 / l) : [0, 0, 0]; };

/** Normale d'un polygone (méthode de Newell : juste aussi pour les polygones non plans). */
export function faceNormal(mesh, f) {
  const n = [0, 0, 0], V = mesh.verts;
  for (let i = 0; i < f.length; i++) {
    const a = V[f[i]], b = V[f[(i + 1) % f.length]];
    n[0] += (a[1] - b[1]) * (a[2] + b[2]);
    n[1] += (a[2] - b[2]) * (a[0] + b[0]);
    n[2] += (a[0] - b[0]) * (a[1] + b[1]);
  }
  return norm(n);
}
export function faceCenter(mesh, f) {
  let c = [0, 0, 0];
  for (const i of f) c = add(c, mesh.verts[i]);
  return mul(c, 1 / f.length);
}

// ------------------------------------------------------------------ nettoyage
/** Fusionne les sommets confondus (à eps près), retire les faces dégénérées et les sommets inutilisés. */
export function weld(mesh, eps = 1e-5) {
  const key = (p) => p.map((x) => Math.round(x / eps)).join(',');
  const map = new Map(), remap = [], verts = [];
  mesh.verts.forEach((p, i) => {
    const k = key(p);
    if (!map.has(k)) { map.set(k, verts.length); verts.push([...p]); }
    remap[i] = map.get(k);
  });
  const faces = [];
  for (const f of mesh.faces) {
    const g = [];
    for (const i of f) { const j = remap[i]; if (g[g.length - 1] !== j) g.push(j); }
    while (g.length > 1 && g[0] === g[g.length - 1]) g.pop();
    if (new Set(g).size >= 3) faces.push(g);
  }
  return compact({ verts, faces });
}

/** Retire les sommets qu'aucune face n'utilise (renumérote). */
export function compact(mesh) {
  const used = new Map(), verts = [];
  const faces = mesh.faces.map((f) => f.map((i) => {
    if (!used.has(i)) { used.set(i, verts.length); verts.push(mesh.verts[i]); }
    return used.get(i);
  }));
  return { verts, faces };
}

/** Volume signé (positif = faces orientées vers l'extérieur pour un maillage fermé). */
export function signedVolume(mesh) {
  let v = 0;
  for (const f of mesh.faces) {
    const a = mesh.verts[f[0]];
    for (let i = 1; i + 1 < f.length; i++) v += dot(a, cross(mesh.verts[f[i]], mesh.verts[f[i + 1]])) / 6;
  }
  return v;
}
const flipped = (mesh) => ({ verts: mesh.verts, faces: mesh.faces.map((f) => [...f].reverse()) });
const outward = (mesh) => (signedVolume(mesh) < 0 ? flipped(mesh) : mesh);

/** Bilan topologique : arêtes orientées en double, arêtes de bord, caractéristique d'Euler. */
export function topology(mesh) {
  const directed = new Map();
  for (const f of mesh.faces) for (let i = 0; i < f.length; i++) {
    const k = f[i] + '>' + f[(i + 1) % f.length];
    directed.set(k, (directed.get(k) || 0) + 1);
  }
  let duplicated = 0, boundary = 0;
  const undirected = new Set();
  for (const [k, n] of directed) {
    if (n > 1) duplicated++;
    const [a, b] = k.split('>');
    if (!directed.has(b + '>' + a)) boundary++;
    undirected.add(+a < +b ? a + '-' + b : b + '-' + a);
  }
  const V = new Set(mesh.faces.flat()).size;
  return { V, E: undirected.size, F: mesh.faces.length, euler: V - undirected.size + mesh.faces.length, duplicated, boundary,
           closed: boundary === 0 && duplicated === 0 };
}

// ------------------------------------------------------------------ primitives
const clampInt = (v, lo, hi, d) => { v = Math.round(+v); return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; };
const clampNum = (v, lo, hi, d) => { v = +v; return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; };

export const PRIMITIVES = {
  cube: { label: 'Cube', params: { w: 1, h: 1, d: 1, segments: 1 } },
  sphere: { label: 'Sphère', params: { radius: 0.5, segments: 16, rings: 10 } },
  cylinder: { label: 'Cylindre', params: { radius: 0.5, height: 1, segments: 16, rings: 1 } },
  cone: { label: 'Cône', params: { radius: 0.5, height: 1, segments: 16 } },
  plane: { label: 'Plan', params: { w: 1, d: 1, segments: 1 } },
  capsule: { label: 'Capsule', params: { radius: 0.35, height: 1.4, segments: 16, rings: 6 } },
  torus: { label: 'Tore', params: { radius: 0.5, tube: 0.18, segments: 24, sides: 10 } },
};

function grid(n, u, v, half, s, out) {
  const base = out.verts.length;
  for (let j = 0; j <= s; j++) for (let i = 0; i <= s; i++) {
    const a = -1 + 2 * i / s, b = -1 + 2 * j / s;
    const p = add(add(n, mul(u, a)), mul(v, b));
    out.verts.push([p[0] * half[0], p[1] * half[1], p[2] * half[2]]);
  }
  for (let j = 0; j < s; j++) for (let i = 0; i < s; i++) {
    const q = (ii, jj) => base + jj * (s + 1) + ii;
    out.faces.push([q(i, j), q(i + 1, j), q(i + 1, j + 1), q(i, j + 1)]);
  }
}

function revolve(profile, segments) {
  // profile : [[rayon, y], …] du haut vers le bas ; rayon ≈ 0 → un seul sommet (pôle)
  const verts = [], faces = [], rows = [];
  for (const [r, y] of profile) {
    if (r < EPS) { rows.push([verts.length]); verts.push([0, y, 0]); continue; }
    const row = [];
    for (let j = 0; j < segments; j++) {
      const a = 2 * Math.PI * j / segments;
      row.push(verts.length); verts.push([r * Math.sin(a), y, r * Math.cos(a)]);
    }
    rows.push(row);
  }
  for (let k = 0; k + 1 < rows.length; k++) {
    const A = rows[k], B = rows[k + 1];
    for (let j = 0; j < segments; j++) {
      const j2 = (j + 1) % segments;
      if (A.length === 1 && B.length === 1) continue;
      if (A.length === 1) faces.push([A[0], B[j], B[j2]]);
      else if (B.length === 1) faces.push([A[j], B[0], A[j2]]);
      else faces.push([A[j], B[j], B[j2], A[j2]]);
    }
  }
  return outward(weld({ verts, faces }));
}

/** Crée une primitive ; les paramètres hors bornes sont ramenés dans les bornes. */
export function primitive(type, p = {}) {
  const P = { ...(PRIMITIVES[type] || PRIMITIVES.cube).params, ...p };
  switch (type) {
    case 'sphere': {
      const r = clampNum(P.radius, 0.01, 100, 0.5), s = clampInt(P.segments, 3, 128, 16), n = clampInt(P.rings, 2, 64, 10);
      const prof = [];
      for (let k = 0; k <= n; k++) { const t = Math.PI * k / n; prof.push([k === 0 || k === n ? 0 : r * Math.sin(t), r * Math.cos(t)]); }
      return revolve(prof, s);
    }
    case 'cylinder': {
      const r = clampNum(P.radius, 0.01, 100, 0.5), h = clampNum(P.height, 0.01, 100, 1), s = clampInt(P.segments, 3, 128, 16), n = clampInt(P.rings, 1, 64, 1);
      const prof = [[0, h / 2]];
      for (let k = 0; k <= n; k++) prof.push([r, h / 2 - h * k / n]);
      prof.push([0, -h / 2]);
      return revolve(prof, s);
    }
    case 'cone': {
      const r = clampNum(P.radius, 0.01, 100, 0.5), h = clampNum(P.height, 0.01, 100, 1), s = clampInt(P.segments, 3, 128, 16);
      return revolve([[0, h / 2], [r, -h / 2], [0, -h / 2]], s);
    }
    case 'capsule': {
      const r = clampNum(P.radius, 0.01, 100, 0.35), h = Math.max(clampNum(P.height, 0.02, 100, 1.4), 2 * r + 0.001);
      const s = clampInt(P.segments, 3, 128, 16), n = clampInt(P.rings, 1, 32, 6), c = h / 2 - r;
      const prof = [];
      for (let k = 0; k <= n; k++) { const t = Math.PI / 2 * k / n; prof.push([k === 0 ? 0 : r * Math.sin(t), c + r * Math.cos(t)]); }
      for (let k = 0; k <= n; k++) { const t = Math.PI / 2 + Math.PI / 2 * k / n; prof.push([k === n ? 0 : r * Math.sin(t), -c + r * Math.cos(t)]); }
      return revolve(prof, s);
    }
    case 'torus': {
      const R = clampNum(P.radius, 0.02, 100, 0.5), r = Math.min(clampNum(P.tube, 0.005, 50, 0.18), R * 0.99);
      const s = clampInt(P.segments, 3, 128, 24), t = clampInt(P.sides, 3, 64, 10);
      const verts = [], faces = [];
      for (let i = 0; i < s; i++) for (let j = 0; j < t; j++) {
        const a = 2 * Math.PI * i / s, b = 2 * Math.PI * j / t, rr = R + r * Math.cos(b);
        verts.push([rr * Math.sin(a), r * Math.sin(b), rr * Math.cos(a)]);
      }
      const id = (i, j) => (i % s) * t + (j % t);
      for (let i = 0; i < s; i++) for (let j = 0; j < t; j++) faces.push([id(i, j), id(i + 1, j), id(i + 1, j + 1), id(i, j + 1)]);
      return outward({ verts, faces });
    }
    case 'plane': {
      const w = clampNum(P.w, 0.01, 1000, 1), d = clampNum(P.d, 0.01, 1000, 1), s = clampInt(P.segments, 1, 64, 1);
      const out = { verts: [], faces: [] };
      grid([0, 0, 0], [1, 0, 0], [0, 0, -1], [w / 2, 1, d / 2], s, out);
      return weld(out);
    }
    default: {
      const half = [clampNum(P.w, 0.01, 1000, 1) / 2, clampNum(P.h, 0.01, 1000, 1) / 2, clampNum(P.d, 0.01, 1000, 1) / 2];
      const s = clampInt(P.segments, 1, 32, 1), out = { verts: [], faces: [] };
      grid([1, 0, 0], [0, 0, -1], [0, 1, 0], half, s, out);
      grid([-1, 0, 0], [0, 0, 1], [0, 1, 0], half, s, out);
      grid([0, 1, 0], [1, 0, 0], [0, 0, -1], half, s, out);
      grid([0, -1, 0], [1, 0, 0], [0, 0, 1], half, s, out);
      grid([0, 0, 1], [1, 0, 0], [0, 1, 0], half, s, out);
      grid([0, 0, -1], [-1, 0, 0], [0, 1, 0], half, s, out);
      return weld(out);
    }
  }
}

// ------------------------------------------------------------------ symétrie
/** Pour chaque sommet, l'indice de son miroir par rapport au plan X = 0 (lui-même s'il est sur le plan, -1 s'il n'en a pas). */
export function mirrorMap(mesh, eps = 1e-4) {
  const key = (p) => [Math.round(p[0] / eps), Math.round(p[1] / eps), Math.round(p[2] / eps)].join(',');
  const idx = new Map();
  mesh.verts.forEach((p, i) => idx.set(key(p), i));
  return mesh.verts.map((p, i) => (Math.abs(p[0]) < eps ? i : (idx.has(key([-p[0], p[1], p[2]])) ? idx.get(key([-p[0], p[1], p[2]])) : -1)));
}
export function symmetrizeVerts(mesh, ids, eps = 1e-4) {
  const m = mirrorMap(mesh, eps), out = new Set(ids);
  for (const i of ids) if (m[i] >= 0) out.add(m[i]);
  return [...out].sort((a, b) => a - b);
}
export function symmetrizeFaces(mesh, faceIds, eps = 1e-4) {
  const m = mirrorMap(mesh, eps);
  const byKey = new Map(mesh.faces.map((f, i) => [[...f].sort((a, b) => a - b).join(','), i]));
  const out = new Set(faceIds);
  for (const fi of faceIds) {
    const mf = mesh.faces[fi].map((i) => m[i]);
    if (mf.every((i) => i >= 0)) { const k = [...mf].sort((a, b) => a - b).join(','); if (byKey.has(k)) out.add(byKey.get(k)); }
  }
  return [...out].sort((a, b) => a - b);
}
/** Le maillage est-il symétrique (chaque sommet a un miroir) ? */
export function isSymmetric(mesh, eps = 1e-4) { return mirrorMap(mesh, eps).every((i) => i >= 0); }

// ------------------------------------------------------------------ transformations de sommets
export function centroid(mesh, ids) {
  let c = [0, 0, 0];
  for (const i of ids) c = add(c, mesh.verts[i]);
  return ids.length ? mul(c, 1 / ids.length) : c;
}
export function rotationMatrix(axis, deg) {
  const a = deg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
  if (axis === 0) return [[1, 0, 0], [0, c, -s], [0, s, c]];
  if (axis === 1) return [[c, 0, s], [0, 1, 0], [-s, 0, c]];
  return [[c, -s, 0], [s, c, 0], [0, 0, 1]];
}
const mat = (M, p) => [dot(M[0], p), dot(M[1], p), dot(M[2], p)];

/**
 * Applique f (point → point) aux sommets ids. Avec la symétrie : f s'applique au côté du centre
 * de la sélection, son reflet exact à l'autre côté, et les sommets du plan X = 0 y restent.
 * Renvoie un NOUVEAU maillage (l'historique garde l'ancien).
 */
export function transformVerts(mesh, ids, f, symmetry = false, eps = 1e-4) {
  const verts = mesh.verts.map((p) => [...p]);
  if (!symmetry) { for (const i of ids) verts[i] = f(mesh.verts[i]); return { verts, faces: mesh.faces }; }
  const sel = symmetrizeVerts(mesh, ids, eps);
  const c = centroid(mesh, ids);
  const side = c[0] < -eps ? -1 : 1;
  const M = (p) => [-p[0], p[1], p[2]];
  for (const i of sel) {
    const p = mesh.verts[i];
    if (Math.abs(p[0]) < eps) { const q = f(p); verts[i] = [0, q[1], q[2]]; }
    else if (Math.sign(p[0]) === side) verts[i] = f(p);
    else verts[i] = M(f(M(p)));
  }
  return { verts, faces: mesh.faces };
}
export const translateFn = (d) => (p) => add(p, d);
export const rotateFn = (pivot, axis, deg) => { const R = rotationMatrix(axis, deg); return (p) => add(mat(R, sub(p, pivot)), pivot); };
export const scaleFn = (pivot, s) => (p) => add(pivot, [(p[0] - pivot[0]) * s[0], (p[1] - pivot[1]) * s[1], (p[2] - pivot[2]) * s[2]]);

// ------------------------------------------------------------------ sélection
export const faceVerts = (mesh, faceIds) => [...new Set(faceIds.flatMap((fi) => mesh.faces[fi]))].sort((a, b) => a - b);

// ------------------------------------------------------------------ extrusion
/**
 * Extrusion de régions de faces : chaque groupe de faces sélectionnées qui se touchent est
 * extrudé d'un bloc le long de sa normale moyenne, de `dist`. Les faces latérales relient
 * l'ancien bord au nouveau. Renvoie { mesh, faces } : les faces extrudées (même indices).
 */
export function extrudeFaces(mesh, faceIds, dist) {
  const sel = [...new Set(faceIds)].filter((i) => i >= 0 && i < mesh.faces.length);
  if (!sel.length) return { mesh, faces: [] };
  const verts = mesh.verts.map((p) => [...p]), faces = mesh.faces.map((f) => [...f]);
  // régions = composantes connexes par arêtes partagées entre faces sélectionnées
  const edgeFaces = new Map();
  for (const fi of sel) { const f = faces[fi]; for (let i = 0; i < f.length; i++) { const a = f[i], b = f[(i + 1) % f.length]; const k = a < b ? a + '-' + b : b + '-' + a; if (!edgeFaces.has(k)) edgeFaces.set(k, []); edgeFaces.get(k).push(fi); } }
  const parent = new Map(sel.map((f) => [f, f]));
  const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
  for (const fs of edgeFaces.values()) for (let i = 1; i < fs.length; i++) parent.set(find(fs[i]), find(fs[0]));
  const regions = new Map();
  for (const f of sel) { const r = find(f); if (!regions.has(r)) regions.set(r, []); regions.get(r).push(f); }
  const sides = [];
  for (const region of regions.values()) {
    let n = [0, 0, 0];
    for (const fi of region) n = add(n, mul(faceNormal(mesh, mesh.faces[fi]), 1));
    n = norm(n);
    const inRegion = new Set(region);
    const count = new Map();   // arête orientée de la région → présente ?
    for (const fi of region) { const f = mesh.faces[fi]; for (let i = 0; i < f.length; i++) count.set(f[i] + '>' + f[(i + 1) % f.length], true); }
    const dup = new Map();
    const newIdx = (v) => { if (!dup.has(v)) { dup.set(v, verts.length); verts.push(add(mesh.verts[v], mul(n, dist))); } return dup.get(v); };
    for (const fi of region) {
      const f = mesh.faces[fi];
      for (let i = 0; i < f.length; i++) {
        const a = f[i], b = f[(i + 1) % f.length];
        if (!count.has(b + '>' + a)) sides.push([a, b, newIdx(b), newIdx(a)]);   // arête de bord de la région
      }
    }
    for (const fi of region) faces[fi] = mesh.faces[fi].map(newIdx);
    void inRegion;
  }
  const out = compact({ verts, faces: faces.concat(sides) });
  // compact() conserve l'ordre des faces : les faces extrudées gardent leurs indices
  return { mesh: out, faces: sel };
}

// ------------------------------------------------------------------ rendu / export
/** Triangles (éventail) pour l'affichage et l'export : { positions, normals (plates), triFace (face d'origine de chaque triangle) }. */
export function triangulate(mesh) {
  const positions = [], normals = [], triFace = [];
  mesh.faces.forEach((f, fi) => {
    const n = faceNormal(mesh, f);
    for (let i = 1; i + 1 < f.length; i++) {
      for (const k of [f[0], f[i], f[i + 1]]) { positions.push(...mesh.verts[k]); normals.push(...n); }
      triFace.push(fi);
    }
  });
  return { positions: new Float32Array(positions), normals: new Float32Array(normals), triFace };
}
/** Triangles indexés à normales DOUCES (moyenne des faces voisines) : pour les objets « lisses » (corps). */
export function triangulateSmooth(mesh) {
  const N = mesh.verts.map(() => [0, 0, 0]);
  for (const f of mesh.faces) {
    let nx = 0, ny = 0, nz = 0;
    for (let i = 0; i < f.length; i++) {
      const a = mesh.verts[f[i]], b = mesh.verts[f[(i + 1) % f.length]];
      nx += (a[1] - b[1]) * (a[2] + b[2]); ny += (a[2] - b[2]) * (a[0] + b[0]); nz += (a[0] - b[0]) * (a[1] + b[1]);
    }
    for (const i of f) { N[i][0] += nx; N[i][1] += ny; N[i][2] += nz; }
  }
  const positions = new Float32Array(mesh.verts.length * 3), normals = new Float32Array(mesh.verts.length * 3);
  mesh.verts.forEach((p, i) => { positions.set(p, i * 3); const n = N[i], l = Math.hypot(n[0], n[1], n[2]) || 1; normals.set([n[0] / l, n[1] / l, n[2] / l], i * 3); });
  const index = [], triFace = [];
  mesh.faces.forEach((f, fi) => { for (let i = 1; i + 1 < f.length; i++) { index.push(f[0], f[i], f[i + 1]); triFace.push(fi); } });
  return { positions, normals, index: new Uint32Array(index), triFace };
}
export function edges(mesh) {
  const set = new Set(), out = [];
  for (const f of mesh.faces) for (let i = 0; i < f.length; i++) {
    const a = f[i], b = f[(i + 1) % f.length], k = a < b ? a + '-' + b : b + '-' + a;
    if (!set.has(k)) { set.add(k); out.push([a, b]); }
  }
  return out;
}
export function bounds(mesh) {
  const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
  for (const p of mesh.verts) for (let k = 0; k < 3; k++) { lo[k] = Math.min(lo[k], p[k]); hi[k] = Math.max(hi[k], p[k]); }
  return { min: lo, max: hi };
}

export function quatFromEulerDeg(r) {
  // ordre XYZ (comme three.js) → quaternion [x, y, z, w]
  const [x, y, z] = r.map((d) => d * Math.PI / 360);
  const c1 = Math.cos(x), c2 = Math.cos(y), c3 = Math.cos(z), s1 = Math.sin(x), s2 = Math.sin(y), s3 = Math.sin(z);
  return [s1 * c2 * c3 + c1 * s2 * s3, c1 * s2 * c3 - s1 * c2 * s3, c1 * c2 * s3 + s1 * s2 * c3, c1 * c2 * c3 - s1 * s2 * s3];
}
/** Fait tourner le vecteur v par le quaternion q = [x, y, z, w]. */
export function quatRotate(q, v) {
  const [x, y, z, w] = q, t = mul(cross([x, y, z], v), 2);
  return add(add(v, mul(t, w)), cross([x, y, z], t));
}
export function eulerDegFromQuat(q) {
  // inverse de quatFromEulerDeg (ordre XYZ), via la matrice de rotation
  const [x, y, z, w] = q;
  const m11 = 1 - 2 * (y * y + z * z), m12 = 2 * (x * y - z * w), m13 = 2 * (x * z + y * w);
  const m22 = 1 - 2 * (x * x + z * z), m23 = 2 * (y * z - x * w), m32 = 2 * (y * z + x * w), m33 = 1 - 2 * (x * x + y * y);
  const ry = Math.asin(Math.max(-1, Math.min(1, m13)));
  let rx, rz;
  if (Math.abs(m13) < 0.9999999) { rx = Math.atan2(-m23, m33); rz = Math.atan2(-m12, m11); }
  else { rx = Math.atan2(m32, m22); rz = 0; }
  return [rx, ry, rz].map((a) => Math.round(a * 180 / Math.PI * 1e6) / 1e6);
}

const enc = (s) => new TextEncoder().encode(s);
const pad4 = (n) => (4 - (n % 4)) % 4;

/**
 * Écrit la scène en .glb (glTF 2.0 binaire). Pour chaque objet : un nœud (position, rotation,
 * échelle), un maillage en triangles à normales plates, et — dans node.extras.sbh — les
 * polygones d'origine pour pouvoir rééditer le fichier. Un seul fichier : Godot l'ouvre tel quel.
 */
export function writeGLB(scene) {
  const objects = scene.objects || [];
  // Godot 4.4 refuse une scène sans nœud (generate_scene échoue) : le Modeleur garde toujours ≥ 1 objet.
  if (!objects.length) throw new Error('scène vide : au moins un objet est nécessaire');
  if (objects.some((o) => !o.mesh || !o.mesh.faces.length)) throw new Error('objet sans face');
  const json = {
    asset: { version: '2.0', generator: 'SBh Studio Modeleur 3D' },
    scene: 0, scenes: [{ name: scene.name || 'Maillage', nodes: objects.map((_, i) => i),
      extras: { sbh_mesh: { format: 'sbh-mesh', version: 1, name: scene.name || '', symmetry: !!scene.symmetry } } }],
    nodes: [], meshes: [], materials: [], accessors: [], bufferViews: [], buffers: [],
  };
  const chunks = []; let offset = 0;
  const pushView = (arr, target) => {
    const bytes = new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
    json.bufferViews.push({ buffer: 0, byteOffset: offset, byteLength: bytes.length, target });
    chunks.push(bytes); offset += bytes.length;
    const p = pad4(offset); if (p) { chunks.push(new Uint8Array(p)); offset += p; }
    return json.bufferViews.length - 1;
  };
  let acc = 0;
  objects.forEach((o, i) => {
    const t = o.smooth ? triangulateSmooth(o.mesh) : triangulate(o.mesh), count = t.positions.length / 3;
    const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
    for (let k = 0; k < t.positions.length; k++) { lo[k % 3] = Math.min(lo[k % 3], t.positions[k]); hi[k % 3] = Math.max(hi[k % 3], t.positions[k]); }
    const pv = pushView(t.positions, 34962), nv = pushView(t.normals, 34962);
    json.accessors.push({ bufferView: pv, componentType: 5126, count, type: 'VEC3', min: count ? lo : [0, 0, 0], max: count ? hi : [0, 0, 0] });
    json.accessors.push({ bufferView: nv, componentType: 5126, count, type: 'VEC3' });
    const posAcc = acc, nrmAcc = acc + 1; acc += 2;
    let idxAcc;
    if (t.index) { const iv = pushView(t.index, 34963); json.accessors.push({ bufferView: iv, componentType: 5125, count: t.index.length, type: 'SCALAR' }); idxAcc = acc++; }
    const c = /^#[0-9a-f]{6}$/i.test(o.color || '') ? o.color : '#c9a227';
    const rgb = [1, 3, 5].map((k) => Math.pow(parseInt(c.substr(k, 2), 16) / 255, 2.2));
    json.materials.push({ name: (o.name || 'Objet') + ' (matière)', pbrMetallicRoughness: { baseColorFactor: [...rgb, 1], metallicFactor: 0, roughnessFactor: 0.8 }, doubleSided: false });
    const prim = { attributes: { POSITION: posAcc, NORMAL: nrmAcc }, material: i, mode: 4 };
    if (idxAcc !== undefined) prim.indices = idxAcc;
    json.meshes.push({ name: o.name || 'Objet ' + (i + 1), primitives: [prim] });
    json.nodes.push({ name: o.name || 'Objet ' + (i + 1), mesh: i,
      translation: o.pos || [0, 0, 0], rotation: quatFromEulerDeg(o.rot || [0, 0, 0]), scale: o.scale || [1, 1, 1],
      extras: { sbh: { id: o.id || '', color: c, ...(o.smooth ? { smooth: true } : {}), ...(validVolume(o.sculpt) ? { sculpt: o.sculpt } : {}), ...(validForge(o.forge) ? { forge:o.forge } : {}), ...(validSculptMask(o.sculptMask,o.mesh.verts.length)?{sculptMask:o.sculptMask}:{}), verts: o.mesh.verts.map((p) => p.map((x) => Math.round(x * 1e6) / 1e6)), faces: o.mesh.faces } } });
  });
  json.buffers.push({ byteLength: offset });
  let jb = enc(JSON.stringify(json));
  const jp = pad4(jb.length); if (jp) { const t = new Uint8Array(jb.length + jp); t.set(jb); t.fill(0x20, jb.length); jb = t; }
  const total = 12 + 8 + jb.length + 8 + offset;
  const out = new Uint8Array(total), dv = new DataView(out.buffer);
  dv.setUint32(0, 0x46546C67, true); dv.setUint32(4, 2, true); dv.setUint32(8, total, true);
  dv.setUint32(12, jb.length, true); dv.setUint32(16, 0x4E4F534A, true); out.set(jb, 20);
  let p = 20 + jb.length;
  dv.setUint32(p, offset, true); dv.setUint32(p + 4, 0x004E4942, true); p += 8;
  for (const c of chunks) { out.set(c, p); p += c.length; }
  return out;
}

/**
 * Relit un .glb. Fichier du Modeleur : polygones d'origine (extras). Autre fichier glTF 2.0 :
 * triangles de la 1re primitive de chaque maillage (indices ou non), sommets confondus soudés.
 */
export function readGLB(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  if (u8.length < 20 || dv.getUint32(0, true) !== 0x46546C67) throw new Error('pas un fichier .glb');
  if (dv.getUint32(4, true) !== 2) throw new Error('glTF version ' + dv.getUint32(4, true) + ' non prise en charge');
  const jlen = dv.getUint32(12, true);
  if (dv.getUint32(16, true) !== 0x4E4F534A || 20 + jlen > u8.length) throw new Error('bloc JSON manquant');
  const json = JSON.parse(new TextDecoder().decode(u8.subarray(20, 20 + jlen)));
  let bin = null, p = 20 + jlen;
  if (p + 8 <= u8.length && dv.getUint32(p + 4, true) === 0x004E4942) bin = u8.subarray(p + 8, p + 8 + dv.getUint32(p, true));
  const meta = (json.scenes && json.scenes[json.scene || 0] && json.scenes[json.scene || 0].extras && json.scenes[json.scene || 0].extras.sbh_mesh) || {};
  const accessor = (i) => {
    const a = json.accessors[i], v = json.bufferViews[a.bufferView], comps = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 }[a.type];
    const size = { 5126: 4, 5125: 4, 5123: 2, 5121: 1 }[a.componentType], stride = v.byteStride || comps * size;
    const base = (v.byteOffset || 0) + (a.byteOffset || 0), bdv = new DataView(bin.buffer, bin.byteOffset, bin.byteLength), out = [];
    for (let k = 0; k < a.count; k++) for (let c = 0; c < comps; c++) {
      const o = base + k * stride + c * size;
      out.push(a.componentType === 5126 ? bdv.getFloat32(o, true) : a.componentType === 5125 ? bdv.getUint32(o, true) : a.componentType === 5123 ? bdv.getUint16(o, true) : bdv.getUint8(o));
    }
    return out;
  };
  // couleur d'un .glb venu d'ailleurs : matière (baseColorFactor, linéaire → écran) ou couleurs de sommets (moyenne)
  const hex2 = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0');
  const colorOf = (prim) => {
    const mat = prim.material !== undefined && json.materials && json.materials[prim.material];
    const f = mat && mat.pbrMetallicRoughness && mat.pbrMetallicRoughness.baseColorFactor;
    if (Array.isArray(f) && f.length >= 3) return '#' + f.slice(0, 3).map((c) => hex2(Math.pow(c, 1 / 2.2))).join('');
    const ci = prim.attributes && prim.attributes.COLOR_0;
    if (ci !== undefined && bin) {
      const a = json.accessors[ci], k = a.type === 'VEC4' ? 4 : 3, v = accessor(ci);
      const scale = a.componentType === 5121 ? 255 : a.componentType === 5123 ? 65535 : 1;
      const sum = [0, 0, 0], n = v.length / k;
      for (let i = 0; i < v.length; i += k) for (let c = 0; c < 3; c++) sum[c] += v[i + c] / scale;
      if (n > 0) return '#' + sum.map((c) => hex2(c / n)).join('');
    }
    return null;
  };
  const objects = (json.nodes || []).filter((n) => n.mesh !== undefined).map((n, i) => {
    let mesh, foreign = null;
    const x = n.extras && n.extras.sbh;
    if (x && Array.isArray(x.verts) && Array.isArray(x.faces)) mesh = { verts: x.verts.map((q) => [...q]), faces: x.faces.map((f) => [...f]) };
    else {
      const prim = json.meshes[n.mesh].primitives[0], pos = accessor(prim.attributes.POSITION), verts = [];
      for (let k = 0; k < pos.length; k += 3) verts.push([pos[k], pos[k + 1], pos[k + 2]]);
      const idx = prim.indices !== undefined ? accessor(prim.indices) : verts.map((_, k) => k), faces = [];
      for (let k = 0; k + 2 < idx.length; k += 3) faces.push([idx[k], idx[k + 1], idx[k + 2]]);
      mesh = weld({ verts, faces });
      foreign = colorOf(prim);
    }
    let pos = n.translation || [0, 0, 0];
    const q = n.rotation || [0, 0, 0, 1], sc = n.scale || [1, 1, 1];
    if (!x && mesh.verts.length) {
      // .glb venu d'ailleurs : pièces souvent « cuites » autour de l'origine du monde. On place l'origine
      // de chaque objet au centre de sa pièce (même rendu), pour qu'elle tourne et s'étire sur elle-même.
      const b = bounds(mesh), c = [0, 1, 2].map((k) => (b.min[k] + b.max[k]) / 2);
      mesh = { verts: mesh.verts.map((p) => sub(p, c)), faces: mesh.faces };
      pos = add(pos, quatRotate(q, [c[0] * sc[0], c[1] * sc[1], c[2] * sc[2]]));
    }
    return { id: (x && x.id) || 'obj_' + i, name: n.name || 'Objet ' + (i + 1), color: (x && x.color) || foreign || '#c9a227', mesh,
             ...((x && x.smooth) ? { smooth: true } : {}), ...((x && validVolume(x.sculpt)) ? { sculpt: x.sculpt } : {}), ...((x && validForge(x.forge)) ? { forge:x.forge } : {}), ...((x && validSculptMask(x.sculptMask,mesh.verts.length))?{sculptMask:x.sculptMask}:{}), pos, rot: n.rotation ? eulerDegFromQuat(n.rotation) : [0, 0, 0], scale: sc };
  });
  return { name: meta.name || '', symmetry: !!meta.symmetry, objects };
}
