import { extract, preset } from './sculpt_core.js';
self.onmessage = e => {
  try { const volume=e.data.kind==='preset'?preset(e.data.type):e.data.volume; self.postMessage({ revision:e.data.revision, mesh:extract(volume), ...(e.data.kind==='preset'?{volume}: {}) }); }
  catch(err) { self.postMessage({ revision:e.data.revision, error:String(err.message || err) }); }
};
