// Atelier de pièces rigides : vraie épaisseur, trou traversant, courbure.
import * as M from './mesh_core.js';
export const PLATE_PARAMS={w:0.7,h:0.9,thickness:0.04,hole:0.12,holeX:0,holeY:0,bend:0};
export const CAR_PARAMS={length:3.5,width:1.6,wheelRadius:0.34};
const clamp=(a,min,max,fallback)=>Math.min(max,Math.max(min,Number.isFinite(+a)?+a:fallback));
export function plateParams(raw={}) {
  const p={w:clamp(raw.w,0.1,3,0.7),h:clamp(raw.h,0.1,3,0.9),thickness:clamp(raw.thickness,0.005,0.3,0.04),bend:clamp(raw.bend,-120,120,0)};
  if(Math.abs(p.bend)>0.01)p.thickness=Math.min(p.thickness,Math.abs(p.w/(p.bend*Math.PI/180))*0.9);
  const margin=0.015;
  p.hole=clamp(raw.hole,0,Math.max(0,Math.min(p.w,p.h)/2-margin),0.12);
  // Guarantee material around every hole, including an off-center hole.
  p.holeX=clamp(raw.holeX,-p.w/2+p.hole+margin,p.w/2-p.hole-margin,0);
  p.holeY=clamp(raw.holeY,-p.h/2+p.hole+margin,p.h/2-p.hole-margin,0);
  return p;
}
export function plate(raw={}) {
  const p=plateParams(raw);let mesh;
  if(p.hole<0.002) mesh=M.primitive('cube',{w:p.w,h:p.h,d:p.thickness,segments:Math.abs(p.bend)>0.01?12:1});
  else {
    let angles=Array.from({length:32},(_,i)=>2*Math.PI*i/32);
    // Rays through rectangle corners make the outer contour exactly rectangular.
    for(const x of [-p.w/2,p.w/2])for(const y of [-p.h/2,p.h/2])angles.push((Math.atan2(y-p.holeY,x-p.holeX)+2*Math.PI)%(2*Math.PI));
    angles.sort((a,b)=>a-b);angles=angles.filter((a,i)=>!i||a-angles[i-1]>1e-8);
    const n=angles.length,verts=[],faces=[];
    for(const z of [-p.thickness/2,p.thickness/2]) {
      for(const outer of [true,false])for(const a of angles) {
        const c=Math.cos(a),s=Math.sin(a);
        const rx=Math.abs(c)<1e-9?Infinity:((c>0?p.w/2:-p.w/2)-p.holeX)/c;
        const ry=Math.abs(s)<1e-9?Infinity:((s>0?p.h/2:-p.h/2)-p.holeY)/s;
        const r=outer?Math.min(rx,ry):p.hole;
        verts.push([p.holeX+r*c,p.holeY+r*s,z]);
      }
    }
    for(let i=0;i<n;i++){
      const j=(i+1)%n,bo=i,bj=j,bi=n+i,bk=n+j,to=2*n+i,tj=2*n+j,ti=3*n+i,tk=3*n+j;
      faces.push([to,tj,tk,ti],[bo,bi,bk,bj],[bo,bj,tj,to],[ti,tk,bk,bi]);
    }
    mesh={verts,faces};
  }
  if(Math.abs(p.bend)>0.01) {
    const radius=p.w/(p.bend*Math.PI/180);
    mesh={verts:mesh.verts.map(([x,y,z])=>{const a=x/radius;return [(radius+z)*Math.sin(a),y,(radius+z)*Math.cos(a)-radius];}),faces:mesh.faces};
  }
  return {mesh,params:p};
}
export function carParams(raw={}) {return {length:clamp(raw.length,2,6,3.5),width:clamp(raw.width,1.1,2.4,1.6),wheelRadius:clamp(raw.wheelRadius,0.2,0.5,0.34)};}
export function car(raw={}) {
  const p=carParams(raw),L=p.length,W=p.width,R=p.wheelRadius,objects=[];
  const add=(name,type,params,pos,color,rot=[0,0,0])=>objects.push({name,mesh:M.primitive(type,params),pos,rot,scale:[1,1,1],color});
  const box=(name,w,h,d,pos,color)=>add(name,'cube',{w,h,d},pos,color);
  box('Châssis',W*0.86,0.14,L*0.92,[0,R+0.14,0],'#3A3A3A');
  box('Carrosserie',W,0.35,L,[0,R+0.4,0],'#2E7D6B');
  box('Habitacle',W*0.82,0.65,L*0.46,[0,R+0.9,-L*0.02],'#2E7D6B');
  box('Pare-brise',W*0.74,0.4,0.035,[0,R+0.96,L*0.215],'#2E3A59');
  box('Lunette arrière',W*0.74,0.35,0.035,[0,R+0.96,-L*0.255],'#2E3A59');
  for(const side of [-1,1]) {
    const label=side<0?'gauche':'droit';
    box('Porte '+label,0.045,0.54,L*0.22,[side*W*0.415,R+0.85,0],'#46A758');
    box('Vitre '+label,0.045,0.28,L*0.32,[side*W*0.421,R+1.04,0],'#2E3A59');
    for(const front of [-1,1]){
      const z=front*L*0.32,tag=label+' '+(front>0?'avant':'arrière');
      add('Pneu '+tag,'torus',{radius:R*0.75,tube:R*0.25,segments:24,sides:10},[side*W*0.52,R,z],'#3A3A3A',[0,0,90]);
      add('Jante '+tag,'cylinder',{radius:R*0.58,height:0.1,segments:20},[side*W*0.55,R,z],'#808080',[0,0,90]);
    }
    box('Phare '+label,0.23,0.12,0.035,[side*W*0.3,R+0.4,L/2+0.025],'#E8D8B0');
  }
  for(const front of [-1,1])add('Essieu '+(front>0?'avant':'arrière'),'cylinder',{radius:0.045,height:W,segments:12},[0,R,front*L*0.32],'#808080',[0,0,90]);
  return {objects,params:p};
}
