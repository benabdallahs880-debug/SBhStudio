// Sculpture de surface : conserve les faces et la résolution du maillage importé.
const topologyCache=new WeakMap();
const sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const unit=a=>{const n=Math.hypot(...a);return n>1e-12?a.map(v=>v/n):[0,1,0];};
const vec=a=>Array.isArray(a)&&a.length===3&&a.every(Number.isFinite);
export function validMask(mask,count){return Array.isArray(mask)&&mask.length===count&&mask.every(v=>Number.isFinite(v)&&v>=0&&v<=1);}
function topology(mesh){
 let t=topologyCache.get(mesh.faces);if(t&&t.count===mesh.verts.length)return t;
 const neighbors=Array.from({length:mesh.verts.length},()=>new Set()),incident=neighbors.map(()=>[]),edges=new Map();
 mesh.faces.forEach((f,fi)=>{for(let k=0;k<f.length;k++){const a=f[k],b=f[(k+1)%f.length];neighbors[a].add(b);neighbors[b].add(a);incident[a].push(fi);const key=a<b?a+':'+b:b+':'+a;edges.set(key,(edges.get(key)||0)+1);}});
 const boundary=new Set();for(const [key,n]of edges)if(n!==2)key.split(':').forEach(i=>boundary.add(+i));
 t={count:mesh.verts.length,neighbors,incident,boundary};topologyCache.set(mesh.faces,t);return t;
}
function faceVector(verts,f){let n=[0,0,0];for(let k=1;k<f.length-1;k++){const c=cross(sub(verts[f[k]],verts[f[0]]),sub(verts[f[k+1]],verts[f[0]]));n=n.map((v,i)=>v+c[i]);}return n;}
function vertexNormal(mesh,t,i){let n=[0,0,0];for(const fi of t.incident[i]){const v=faceVector(mesh.verts,mesh.faces[fi]);n=n.map((q,k)=>q+v[k]);}return unit(n);}
export function brush(mesh,opts={}){
 if(!mesh?.verts?.length||!mesh?.faces?.length||!vec(opts.center))throw Error('Maillage ou point de sculpture invalide');
 if(!['inflate','carve','grab','smooth','polish','flatten','pinch','protect','unprotect'].includes(opts.tool))throw Error('Pinceau de surface inconnu');
 if(opts.mask!==undefined&&!validMask(opts.mask,mesh.verts.length))throw Error('Masque invalide');
 const radius=Math.max(.005,Math.min(.6,Number(opts.radius)||.08)),strength=Math.max(.01,Math.min(1,Number(opts.strength)||.35));
 const softness=Number.isFinite(opts.softness)?Math.max(0,Math.min(1,opts.softness)):.65;
 const falloff=d=>{const a=Math.max(0,Math.min(1,(1-d)/Math.max(.02,softness)));return a*a*(3-2*a);};
 const t=topology(mesh),weights=new Map(),sides=new Map(),centers=[opts.center],normals=[unit(vec(opts.normal)?opts.normal:[0,0,1])];
 if(opts.symmetry){centers.push([-opts.center[0],opts.center[1],opts.center[2]]);normals.push([-normals[0][0],normals[0][1],normals[0][2]]);}
 // Flood only connected vertices inside the sphere. Nearby disconnected fingers or accessories stay intact.
 centers.forEach((c,side)=>{
  let seed=-1,nearest=radius;mesh.verts.forEach((p,i)=>{const d=Math.hypot(...sub(p,c));if(d<nearest){nearest=d;seed=i;}});if(seed<0)return;
  const visited=new Set([seed]),queue=[seed];
  for(let q=0;q<queue.length;q++){
   const i=queue[q],p=mesh.verts[i],d=Math.hypot(...sub(p,c));if(d>=radius)continue;
   // Protect rear-facing surfaces and open/nonmanifold boundaries.
   const mobility=1-(opts.mask?.[i]||0),w=falloff(d/radius)*mobility;
   if(w>0&&!t.boundary.has(i)&&dot(vertexNormal(mesh,t,i),normals[side])>.05&&(w>(weights.get(i)||0))){weights.set(i,w);sides.set(i,side);}
   for(const j of t.neighbors[i])if(!visited.has(j)){visited.add(j);queue.push(j);}
  }
 });
 const src=mesh.verts,out=src.map(p=>p.slice()),limit=new Map();
 const average=(verts,i)=>{const nb=t.neighbors[i];return [0,1,2].map(k=>[...nb].reduce((s,j)=>s+verts[j][k],0)/Math.max(1,nb.size));};
 for(const [i,w]of weights){
  const p=src[i],side=sides.get(i),n=vertexNormal(mesh,t,i),a=w*strength,c=centers[side],normal=normals[side];
  const minEdge=Math.min(...[...t.neighbors[i]].map(j=>Math.hypot(...sub(src[j],p))));limit.set(i,Math.min(radius*.15,minEdge*.25));
  let displacement=[0,0,0];
  if(opts.tool==='inflate'||opts.tool==='carve')displacement=n.map(v=>v*radius*.035*a*(opts.tool==='inflate'?1:-1));
  if(opts.tool==='grab')displacement=(vec(opts.delta)?opts.delta:[0,0,0]).map((v,k)=>v*a*(side&&k===0?-1:1));
  if(opts.tool==='smooth'||opts.tool==='polish')displacement=sub(average(src,i),p).map(v=>v*a*(opts.tool==='polish'?.45:1));
  if(opts.tool==='flatten'){const distance=dot(sub(p,c),normal);displacement=normal.map(v=>-v*distance*a*.4);}
  if(opts.tool==='pinch'){const d=sub(c,p),along=dot(d,normal);displacement=d.map((v,k)=>(v-along*normal[k])*a*.15);}
  out[i]=p.map((v,k)=>v+displacement[k]);
 }
 if(opts.tool==='polish'){const first=out.map(p=>p.slice());for(const [i,w]of weights){const d=sub(average(first,i),first[i]);out[i]=first[i].map((v,k)=>v-.47*strength*w*d[k]);}}
 const changed=[];
 for(const [i]of weights){const d=sub(out[i],src[i]),len=Math.hypot(...d),cap=limit.get(i);if(len>cap)out[i]=src[i].map((v,k)=>v+d[k]*cap/len);if(len>1e-12)changed.push(i);}
 // Reject a whole stamp if any touched polygon reverses or collapses. No exact self-intersection guarantee.
 const faces=new Set();changed.forEach(i=>t.incident[i].forEach(f=>faces.add(f)));
 for(const fi of faces){const f=mesh.faces[fi];for(let k=1;k<f.length-1;k++){const tri=[f[0],f[k],f[k+1]],a=faceVector(src,tri),b=faceVector(out,tri);if(Math.hypot(...a)>1e-12&&(dot(a,b)<=0||Math.hypot(...b)<Math.hypot(...a)*.1))throw Error('Coup refusé : risque de retournement de surface');}}
 return {mesh:{verts:out,faces:mesh.faces},changed,affected:[...weights.keys()]};
}
