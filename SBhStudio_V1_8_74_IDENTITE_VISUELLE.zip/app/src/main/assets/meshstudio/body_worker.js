// SBh Studio — calcule un corps humain en arrière-plan (Web Worker) : l'écran ne fige pas pendant les
// quelques secondes de calcul (plus longues sur téléphone).
import { humanBody } from './body_core.js';
self.onmessage = (e) => {
  try {
    const t0 = Date.now(), r = humanBody(e.data || {});
    self.postMessage({ ok: true, ms: Date.now() - t0, mesh: r.mesh, head: r.head, garments: r.garments, skin: r.skin, params: r.params });
  } catch (err) { self.postMessage({ ok: false, error: String(err && err.message || err) }); }
};
