// Sculpture volumétrique mobile V1. Champ signé : négatif = matière.
// Domaine fixe 2,4 m, 33³ échantillons. Aucun lien avec le DOM ou Three.js.
import { makeManifold, isClosedManifold } from './body_core.js';
export const SIZE = 33, HALF = 1.2, STEP = 2 * HALF / (SIZE - 1);
const index = (x, y, z) => (z * SIZE + y) * SIZE + x;
const point = (i) => -HALF + i * STEP;
export function validVolume(v) {
  return !!v && v.version === 1 && v.size === SIZE && Array.isArray(v.values) &&
    v.values.length === SIZE ** 3 && v.values.every((x,i) => {
      const a=i%SIZE,b=Math.floor(i/SIZE)%SIZE,c=Math.floor(i/(SIZE*SIZE));
      const edge=a===0||b===0||c===0||a===SIZE-1||b===SIZE-1||c===SIZE-1;
      return Number.isFinite(x) && Math.abs(x)<=8 && (!edge || x>0);
    });
}
export function createVolume() {
  const values = [];
  for (let z = 0; z < SIZE; z++) for (let y = 0; y < SIZE; y++) for (let x = 0; x < SIZE; x++)
    values.push(Math.round((Math.hypot(point(x), point(y), point(z)) - 0.6) * 1e6) / 1e6 || 0);
  return { version: 1, size: SIZE, values };
}
function sample(values, p) {
  const c = p.map(x => Math.max(0, Math.min(SIZE - 1, (x + HALF) / STEP)));
  const b = c.map(x => Math.min(SIZE - 2, Math.floor(x))), t = c.map((x, i) => x - b[i]);
  let value = 0;
  for (let z = 0; z < 2; z++) for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++)
    value += values[index(b[0] + x, b[1] + y, b[2] + z)] * (x ? t[0] : 1-t[0]) * (y ? t[1] : 1-t[1]) * (z ? t[2] : 1-t[2]);
  return value;
}
const vec = p => Array.isArray(p) && p.length === 3 && p.every(Number.isFinite);
export function brush(v, opts) {
  if (!validVolume(v)) throw new Error('Volume de sculpture invalide');
  if (!['inflate','carve','smooth','polish','grab','flatten'].includes(opts.tool) || !vec(opts.center)) throw new Error('Pinceau invalide');
  const radius = Math.max(2 * STEP, Math.min(0.6, Number(opts.radius) || 0.25));
  const strength = Math.max(0.01, Math.min(1, Number(opts.strength) || 0.35));
  const softness=Number.isFinite(opts.softness)?Math.max(0,Math.min(1,opts.softness)):.65;
  const falloff=d=>{if(d>=1)return 0;const t=Math.min(1,(1-d)/Math.max(.02,softness));return t*t*(3-2*t);};
  const centers = [opts.center];
  if (opts.symmetry) centers.push([-opts.center[0],opts.center[1],opts.center[2]]);
  let delta = vec(opts.delta) ? opts.delta.slice() : [0,0,0];
  const dl = Math.hypot(...delta); if (dl > STEP * 2) delta = delta.map(x => x * STEP * 2 / dl);
  let normal = vec(opts.normal) ? opts.normal.slice() : [0,1,0];
  const nl = Math.hypot(...normal) || 1; normal = normal.map(x => x / nl);
  const src = v.values, out = src.slice(), weights=new Map();
  // Update only the union of local brush boxes. Overlap uses max falloff (no double strength on X=0).
  const candidates = new Set();
  for (const c of centers) {
    const lo = c.map(x => Math.max(1, Math.floor((x-radius+HALF)/STEP)));
    const hi = c.map(x => Math.min(SIZE-2, Math.ceil((x+radius+HALF)/STEP)));
    for (let z=lo[2]; z<=hi[2]; z++) for(let y=lo[1]; y<=hi[1]; y++) for(let x=lo[0]; x<=hi[0]; x++) candidates.add(index(x,y,z));
  }
  for (const i of candidates) {
    const x=i%SIZE, y=Math.floor(i/SIZE)%SIZE, z=Math.floor(i/(SIZE*SIZE)), p=[point(x),point(y),point(z)];
    let weight=0, side=0;
    centers.forEach((c,k) => { const d=Math.hypot(...p.map((a,j)=>a-c[j]))/radius; const w=falloff(d); if(w>weight || (w===weight && k===1 && p[0]<0)){weight=w;side=k;} });
    if (!weight) continue;
    const a=weight*strength;weights.set(i,a);
    if(opts.tool==='inflate' || opts.tool==='carve') out[i]=src[i]+(opts.tool==='inflate'?-1:1)*a*STEP*0.8;
    if(opts.tool==='polish') out[i]=src[i]+.5*a*((src[i-1]+src[i+1]+src[i-SIZE]+src[i+SIZE]+src[i-SIZE*SIZE]+src[i+SIZE*SIZE])/6-src[i]);
    if(opts.tool==='smooth') out[i]=src[i]*(1-a)+(src[i-1]+src[i+1]+src[i-SIZE]+src[i+SIZE]+src[i-SIZE*SIZE]+src[i+SIZE*SIZE])/6*a;
    if(opts.tool==='grab') { const d=delta.map((q,j)=>opts.symmetry&&j===0&&Math.abs(p[0])<1e-8?0:(side&&j===0?-q:q)); out[i]=sample(src,p.map((q,j)=>q-d[j]*a)); }
    if(opts.tool==='flatten') { const n=normal.map((q,j)=>side&&j===0?-q:q); const plane=p.reduce((s,q,j)=>s+(q-centers[side][j])*n[j],0); out[i]=src[i]*(1-a)+plane*a; }
    out[i]=Math.round(Math.max(-8,Math.min(8,out[i]))*1e6)/1e6 || 0;
  }
  if(opts.tool==='polish') {
    // Deux passes de signes opposés : atténue les irrégularités en limitant le retrait.
    // Ne promet pas une conservation exacte du volume. La frontière reste inchangée.
    const first=out.slice();for(const [i,a] of weights){const avg=(first[i-1]+first[i+1]+first[i-SIZE]+first[i+SIZE]+first[i-SIZE*SIZE]+first[i+SIZE*SIZE])/6;out[i]=Math.round(Math.max(-8,Math.min(8,first[i]-.53*a*(avg-first[i])))*1e6)/1e6 || 0;}
  }
  return { version:1, size:SIZE, values:out };
}
// Surface nets générique : contrairement au générateur humain, aucune symétrie imposée.
export function extract(v) {
  if(!validVolume(v)) throw new Error('Volume de sculpture invalide');
  for(const offset of [0,.001,-.001,.005,-.005,.01,-.01]) {
    const mesh=extractAt(v.values,offset);
    if(isClosedManifold(mesh))return mesh;
  }
  throw new Error('Surface pincée : ce changement ne peut pas être reconstruit correctement');
}
function extractAt(source,offset) {
  // Ajustement borné du seuil uniquement pour les cellules intérieures. Le champ sauvegardé reste intact.
  const values=offset?source.map((v,i)=>{const x=i%SIZE,y=Math.floor(i/SIZE)%SIZE,z=Math.floor(i/(SIZE*SIZE));return x===0||y===0||z===0||x===SIZE-1||y===SIZE-1||z===SIZE-1?v:v+offset;}):source, N=SIZE-1, cells=new Int32Array(N**3).fill(-1), verts=[], faces=[];
  const cid=(x,y,z)=>(z*N+y)*N+x;
  const corners=Array.from({length:8},(_,c)=>[c&1,(c>>1)&1,(c>>2)&1]);
  const edges=[[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]];
  for(let z=0;z<N;z++) for(let y=0;y<N;y++) for(let x=0;x<N;x++) {
    const vs=corners.map(c=>values[index(x+c[0],y+c[1],z+c[2])]);
    const count=vs.filter(a=>a<0).length; if(!count || count===8) continue;
    const p=[0,0,0]; let n=0;
    for(const [a,b] of edges) {
      if((vs[a]<0)===(vs[b]<0)) continue;
      const t=vs[a]/(vs[a]-vs[b]); for(let j=0;j<3;j++) p[j]+=corners[a][j]+(corners[b][j]-corners[a][j])*t; n++;
    }
    cells[cid(x,y,z)]=verts.length; verts.push(p.map((a,j)=>point([x,y,z][j])+a/n*STEP));
  }
  const quad=(a,b,c,d,flip)=>{if(Math.min(a,b,c,d)<0)return;faces.push(flip?[a,d,c,b]:[a,b,c,d]);};
  for(let z=1;z<N;z++) for(let y=1;y<N;y++) for(let x=0;x<N;x++) {
    const s=values[index(x,y,z)]<0; if(s===(values[index(x+1,y,z)]<0))continue;
    quad(cells[cid(x,y-1,z-1)],cells[cid(x,y,z-1)],cells[cid(x,y,z)],cells[cid(x,y-1,z)],!s);
  }
  for(let z=1;z<N;z++) for(let y=0;y<N;y++) for(let x=1;x<N;x++) {
    const s=values[index(x,y,z)]<0; if(s===(values[index(x,y+1,z)]<0))continue;
    quad(cells[cid(x-1,y,z-1)],cells[cid(x-1,y,z)],cells[cid(x,y,z)],cells[cid(x,y,z-1)],!s);
  }
  for(let z=0;z<N;z++) for(let y=1;y<N;y++) for(let x=1;x<N;x++) {
    const s=values[index(x,y,z)]<0; if(s===(values[index(x,y,z+1)]<0))continue;
    quad(cells[cid(x-1,y-1,z)],cells[cid(x,y-1,z)],cells[cid(x,y,z)],cells[cid(x-1,y,z)],!s);
  }
  const result=makeManifold({verts,faces});
  return {verts:result.verts,faces:result.faces};
}

// Volumes composables. Taille en mètres, repère local de la sculpture.
export const PRESETS = {
  humanoid: { label:'Humanoïde sculptable', color:'#808080' },
  wolf: { label: 'Loup sculptable', color: '#808080' },
  horse: { label: 'Cheval sculptable', color: '#B5651D' },
};
function shapeDistance(p, shape) {
  const c=shape.center || [0,0,0], q=p.map((a,i)=>a-c[i]);
  const size=shape.size || [0.25,0.25,0.25];
  if(shape.type==='box') {
    const d=q.map((a,i)=>Math.abs(a)-size[i]);
    return Math.hypot(...d.map(a=>Math.max(0,a)))+Math.min(0,Math.max(...d));
  }
  if(shape.type==='capsule') {
    const t=Math.max(-size[1],Math.min(size[1],q[1]));
    return (Math.hypot(q[0]/size[0],(q[1]-t)/size[0],q[2]/size[2])-1)*Math.min(size[0],size[2]);
  }
  // Approximate ellipsoid distance (stable even at its center).
  const k0=Math.hypot(...q.map((a,i)=>a/size[i])), k1=Math.hypot(...q.map((a,i)=>a/(size[i]*size[i])));
  return k1>1e-9?k0*(k0-1)/k1:-Math.min(...size);
}
function validShape(s) {
  return s && ['ellipsoid','box','capsule'].includes(s.type) && vec(s.center) && vec(s.size)
    && s.center.every(a=>Math.abs(a)<=HALF) && s.size.every(a=>a>=STEP && a<=0.9);
}
const softUnion=(a,b,k)=>{if(!k)return Math.min(a,b);const h=Math.max(k-Math.abs(a-b),0)/k;return Math.min(a,b)-h*h*k/4;};
export function compose(v, shape, operation='add', symmetry=false, blend=0.08) {
  if(!validVolume(v) || !validShape(shape) || !['add','cut','intersect'].includes(operation)) throw new Error('Volume ou opération invalide');
  const k=Math.max(0,Math.min(0.2,Number(blend)||0));
  const shapes=[shape];
  if(symmetry)shapes.push({...shape,center:[-shape.center[0],shape.center[1],shape.center[2]]});
  const values=v.values.slice();
  for(let z=1;z<SIZE-1;z++)for(let y=1;y<SIZE-1;y++)for(let x=1;x<SIZE-1;x++){
    const p=[point(x),point(y),point(z)],i=index(x,y,z);
    // Mirrored shapes represent one union, also for subtraction/intersection.
    const d=Math.min(...shapes.map(s=>shapeDistance(p,s)));
    let a=operation==='add'?softUnion(values[i],d,k):operation==='cut'?Math.max(values[i],-d):Math.max(values[i],d);
    values[i]=Math.round(Math.max(-8,Math.min(8,a))*1e6)/1e6 || 0;
  }
  return {version:1,size:SIZE,values};
}
function symmetricVolume(v) {
  const values=v.values.slice();for(let z=0;z<SIZE;z++)for(let y=0;y<SIZE;y++)for(let x=0;x<SIZE/2;x++){const a=index(x,y,z),b=index(SIZE-1-x,y,z);values[a]=values[b]=Math.round((values[a]+values[b])*5e5)/1e6 || 0;}return {...v,values};
}
export function preset(type) {
  if(!PRESETS[type])throw new Error('Base animale inconnue');
  const parts=[], horse=type==='horse';
  const E=(center,size)=>parts.push({type:'ellipsoid',center,size});
  const C=(center,size)=>parts.push({type:'capsule',center,size});
  if(type==='humanoid') {
    E([0,0.25,0],[0.3,0.38,0.18]);E([0,-0.1,0],[0.25,0.17,0.17]);
    E([0,0.81,0],[0.16,0.2,0.17]);C([0,0.57,0],[0.09,0.15,0.09]);
    for(const side of [-1,1]) { C([side*0.38,0.18,0],[0.09,0.3,0.1]);E([side*0.38,-0.22,0],[0.1,0.12,0.09]);C([side*0.14,-0.52,0],[0.1,0.28,0.11]);E([side*0.14,-0.89,0.055],[0.12,0.08,0.18]); }
    let v={version:1,size:SIZE,values:Array(SIZE**3).fill(2)};for(const p of parts)v=compose(v,p,'add',false,0.085);return symmetricVolume(v);
  }
  E([0,0.18,0],[horse?0.28:0.24,0.3,0.56]);
  E([0,0.22,-0.38],[0.25,0.28,0.26]); // croupe
  E([0,horse?0.48:0.35,0.43],[0.21,horse?0.4:0.28,0.22]); // cou
  E([0,horse?0.72:0.48,0.67],[horse?0.17:0.2,0.23,0.24]); // tête
  E([0,horse?0.61:0.42,0.83],[0.14,0.13,0.22]); // museau
  for(const x of [-1,1]) {
    E([x*0.12,horse?0.93:0.72,0.62],[0.08,horse?0.16:0.17,0.09]); // oreilles
    for(const z of [-0.36,0.35]) {
      C([x*0.19,-0.14,z],[horse?0.09:0.085,horse?0.3:0.24,0.09]);
      E([x*0.19,horse?-0.46:-0.39,z+0.045],[0.11,0.09,0.17]);
    }
  }
  // Queue verticale inclinée par plusieurs volumes chevauchants.
  for(let i=0;i<4;i++)E([0,(horse?0.12:0.25)-i*0.1,-0.6-i*0.075],[0.09,0.13,0.13]);
  const empty={version:1,size:SIZE,values:Array(SIZE**3).fill(2)};
  let v=empty;for(const p of parts)v=compose(v,p,'add',false,0.085);
  return symmetricVolume(v);
}
