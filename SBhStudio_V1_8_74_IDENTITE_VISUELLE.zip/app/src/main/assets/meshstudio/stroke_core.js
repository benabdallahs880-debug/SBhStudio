// Gestes spatiaux : réglages indépendants de la cadence des événements.
const vec=p=>Array.isArray(p)&&p.length===3&&p.every(Number.isFinite);
export function constrain(target, origin, mode='free') {
  if(!vec(target)||!vec(origin))throw new Error('Point de geste invalide');
  const axes={free:[0,1,2],x:[0],y:[1],z:[2],xy:[0,1],xz:[0,2],yz:[1,2]}[mode];
  if(!axes)throw new Error('Contrainte inconnue');
  return target.map((v,i)=>axes.includes(i)?v:origin[i]);
}
// Stabilisation par une distance de traîne, sans moyenne dépendante du temps.
export function stabilize(previous, target, lag=0) {
  if(!vec(previous)||!vec(target))throw new Error('Point de geste invalide');
  lag=Number.isFinite(lag)?Math.max(0,Math.min(.15,lag)):0;
  const delta=target.map((v,i)=>v-previous[i]),d=Math.hypot(...delta);
  return d<=lag?previous.slice():target.map((v,i)=>v-delta[i]*lag/(d||1));
}
// Échantillonne un segment à distance régulière. Le reliquat est gardé via l'ancre.
export function samples(anchor,target,spacing=.04,limit=4) {
  if(!vec(anchor)||!vec(target))throw new Error('Point de geste invalide');
  spacing=Number.isFinite(spacing)?Math.max(.001,Math.min(.15,spacing)):.04;
  limit=Number.isFinite(limit)?Math.max(1,Math.min(32,Math.floor(limit))):4;
  const delta=target.map((v,i)=>v-anchor[i]),d=Math.hypot(...delta),n=Math.min(limit,Math.floor((d+1e-9)/spacing));
  const points=Array.from({length:n},(_,k)=>anchor.map((v,i)=>v+delta[i]*(k+1)*spacing/(d||1)));
  const next=points.length?points[points.length-1]:anchor.slice();
  return {points,anchor:next,reached:d-n*spacing<spacing-1e-9};
}
