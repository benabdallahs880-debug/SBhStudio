package com.sbh.studio.data;

import java.io.*;
import java.nio.file.*;
import java.util.concurrent.*;

/** Run with a JDK, no Android SDK or Gradle needed. */
public class AtomicFileTransactionCheck {
    private static int checks;
    static void check(boolean ok, String message) { checks++; if (!ok) throw new AssertionError(message); }
    static File file(File root, String name) { return new File(root, name); }
    static void write(File f, String text) throws IOException {
        synchronized (AtomicFileTransaction.LOCK) {
            byte[] bytes = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            if (!AtomicFileTransaction.stageIfActive(f, bytes)) AtomicFileTransaction.atomicWrite(f, bytes);
        }
    }
    static String read(File f) throws IOException { byte[] b = AtomicFileTransaction.read(f); return b == null ? "ABSENT" : new String(b, java.nio.charset.StandardCharsets.UTF_8); }
    static String disk(File f) throws IOException { return f.exists() ? Files.readString(f.toPath()) : "ABSENT"; }
    static class PowerCut extends Error {}
    public static void main(String[] args) throws Exception {
        File root = Files.createTempDirectory("sbh-transaction-").toFile();
        File a = file(root,"a"), b = file(root,"nested/b.json");
        write(a,"original");
        String result = AtomicFileTransaction.run(root, () -> {
            write(a,"first"); write(a,"final"); write(b,"new");
            check(read(a).equals("final"),"read sees latest staged value");
            check(disk(a).equals("original"),"disk unchanged before readiness");
            check(!b.exists(),"new file not published during preparation");
            return "success";
        });
        check(result.equals("success"),"result preserved");
        check(disk(a).equals("final") && disk(b).equals("new"),"all writes published");
        check(AtomicFileTransaction.recover(root)==0,"successful operation leaves no journal");
        try { AtomicFileTransaction.run(root, () -> { write(a,"bad"); write(file(root,"orphan.glb"),"copy"); throw new IOException("disk full"); }); }
        catch(IOException expected) {}
        check(disk(a).equals("final"),"preparation failure preserves original");
        check(!file(root,"orphan.glb").exists(),"preparation failure leaves no indexed copy");
        check(AtomicFileTransaction.recover(root)==0,"failed preparation cleaned");
        for(int stop=0;stop<=3;stop++) {
            final int crashAt=stop;
            write(a,"before"); write(b,"before"); File c=file(root,"new.glb"); Files.deleteIfExists(c.toPath());
            try { AtomicFileTransaction.run(root, () -> { write(a,"after");write(b,"after");write(c,"after"); return null; }, n -> { if(n==crashAt)throw new PowerCut(); }); }
            catch(PowerCut expected) {}
            check(AtomicFileTransaction.recover(root)==1,"one interrupted operation recovered");
            check(disk(a).equals("after") && disk(b).equals("after") && disk(c).equals("after"),"recovery completes exact staged plan at step "+stop);
            check(AtomicFileTransaction.recover(root)==0,"recovery idempotent");
        }
        try { AtomicFileTransaction.run(root, () -> { write(a,"unpublished"); throw new PowerCut(); }); }
        catch(PowerCut expected) {}
        check(AtomicFileTransaction.recover(root)==0,"unready crash discarded");
        check(disk(a).equals("after"),"unready crash preserves original");
        String recoveredResult = AtomicFileTransaction.run(root, () -> {write(a,"retried");write(b,"retried");return "kept result";}, n -> {
            if(n==1) throw new UncheckedIOException(new IOException("transient write error"));
        });
        check(recoveredResult.equals("kept result") && disk(a).equals("retried") && disk(b).equals("retried"),"transient commit error recovers without repeating operation");
        check(AtomicFileTransaction.recover(root)==0,"automatic recovery cleans journal");
        // An unrelated later change is preserved rather than overwritten during recovery.
        write(a,"old");write(b,"old");
        try { AtomicFileTransaction.run(root, () -> { write(a,"desired");write(b,"desired");return null; }, n -> { if(n==1)throw new PowerCut(); }); }
        catch(PowerCut expected) {}
        AtomicFileTransaction.atomicWrite(b,"unrelated".getBytes());
        try { AtomicFileTransaction.recover(root); throw new AssertionError("conflict must block"); } catch(IOException expected) {}
        check(disk(b).equals("unrelated"),"conflicting file preserved");
        check(AtomicFileTransaction.recoveryRequired(),"conflict marks recovery necessary");
        try { write(file(root,"blocked"),"no");throw new AssertionError("write must block"); } catch(IOException expected) {}
        check(!file(root,"blocked").exists(),"new saves blocked until recovery");
        AtomicFileTransaction.atomicWrite(b,"old".getBytes());
        check(AtomicFileTransaction.recover(root)==1,"recovery retries after conflict resolved");
        check(!AtomicFileTransaction.recoveryRequired(),"recovery unblocks saving");
        check(disk(b).equals("desired"),"desired content restored");
        File outside=Files.createTempFile("sbh-outside-", ".json").toFile();
        try { AtomicFileTransaction.run(root, () -> { write(outside,"forbidden");return null; });throw new AssertionError("outside path accepted"); } catch(IOException expected) {}
        check(outside.length()==0,"outside path untouched");
        File link=file(root,"unsafe"); Files.createSymbolicLink(link.toPath(),outside.toPath());
        try { AtomicFileTransaction.run(root, () -> { write(link,"forbidden");return null; });throw new AssertionError("symlink escaped root"); } catch(IOException expected) {}
        check(outside.length()==0,"symlink cannot escape application storage");
        write(a,"old");write(b,"old");
        try { AtomicFileTransaction.run(root, () -> {write(a,"expected");write(b,"expected");return null;}, n -> {if(n==1)throw new PowerCut();}); }
        catch(PowerCut expected) {}
        File journal=new File(root,"creation_transactions").listFiles(File::isDirectory)[0];
        File stagedFile=new File(journal,"entry_1");
        AtomicFileTransaction.atomicWrite(stagedFile,"damaged".getBytes());
        try {AtomicFileTransaction.recover(root);throw new AssertionError("damaged stage accepted");}catch(IOException expected){}
        check(disk(b).equals("old"),"damaged stage never published");
        check(journal.exists(),"failed recovery retains its journal");
        AtomicFileTransaction.atomicWrite(stagedFile,"expected".getBytes());
        check(AtomicFileTransaction.recover(root)==1,"verified staged bytes permit recovery");
        check(disk(b).equals("expected"),"recovered desired bytes");
        CountDownLatch staged=new CountDownLatch(1), release=new CountDownLatch(1), otherDone=new CountDownLatch(1);
        ExecutorService pool=Executors.newFixedThreadPool(2);
        Future<?> operation=pool.submit(() -> { try { AtomicFileTransaction.run(root, () -> {write(a,"concurrent");staged.countDown();release.await();return null;}); }catch(Exception ex){throw new RuntimeException(ex);} });
        check(staged.await(2,TimeUnit.SECONDS),"operation entered");
        Future<?> other=pool.submit(() -> { try{write(file(root,"other.json"),"external");otherDone.countDown();}catch(Exception ex){throw new RuntimeException(ex);} });
        check(!otherDone.await(50,TimeUnit.MILLISECONDS),"other SafeStore writer waits for complete operation");
        release.countDown();operation.get(2,TimeUnit.SECONDS);other.get(2,TimeUnit.SECONDS);pool.shutdown();
        check(disk(a).equals("concurrent") && disk(file(root,"other.json")).equals("external"),"serialized writers both complete");
        System.out.println("PASS: "+checks+" transaction checks (staging, interruption, retry, conflict, writer serialization).");
    }
}
