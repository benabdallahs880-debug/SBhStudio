// 30 réglages de curseurs au hasard : la peau doit toujours être fermée, d'un seul tenant et symétrique.
import * as B from '../../app/src/main/assets/meshstudio/body_core.js';
import * as M from '../../app/src/main/assets/meshstudio/mesh_core.js';
let seed = +(process.argv[3] || 12345); const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
let bad = 0; const N = +(process.argv[2] || 30);
for (let i = 0; i < N; i++) {
  const p = {}; for (const [k, d] of Object.entries(B.BODY_PARAMS)) p[k] = +(d.min + rnd() * (d.max - d.min)).toFixed(2);
  p.detail = Math.max(p.detail, 1.0); for (const k of ['skin', 'outfit', 'hair', 'beard']) p[k] = Math.round(p[k]);
  const r = B.humanBody(p), t = M.topology(r.mesh), all = [r.mesh, r.head, ...r.garments.map((g) => g.mesh)];
  const good = all.every((m) => M.topology(m).closed && M.isSymmetric(m) && M.signedVolume(m) > 0) && t.euler === 2;
  if (!good) { bad++; console.log('ÉCHEC', JSON.stringify(p), [['corps', r.mesh], ['tête', r.head], ...r.garments.map((g) => [g.name, g.mesh])].filter(([, m]) => !(M.topology(m).closed && M.isSymmetric(m))).map(([n]) => n).join(',')); }
}
console.log(`${N - bad}/${N} réglages au hasard : peau fermée, d'un seul tenant, symétrique`);
process.exit(bad ? 1 : 0);
