// Tests du cœur géométrique du Modeleur 3D :  node tools/meshstudio/test_mesh_core.mjs [dossier_sortie_glb]
import * as M from '../../app/src/main/assets/meshstudio/mesh_core.js';
import fs from 'node:fs';
import path from 'node:path';

let fails = 0, n = 0;
const ok = (c, msg) => { n++; if (!c) { fails++; console.log('ÉCHEC', msg); } };
const close = (a, b, e = 1e-6) => Math.abs(a - b) <= e;
const allNormalsOut = (mesh) => mesh.faces.every((f) => {   // primitives convexes / étoilées : normale dans le sens du centre de face
  const c = M.faceCenter(mesh, f), nn = M.faceNormal(mesh, f); return M.dot(c, nn) > -1e-9; });

// 1. primitives
const expectEuler = { cube: 2, sphere: 2, cylinder: 2, cone: 2, capsule: 2, torus: 0 };
for (const t of Object.keys(M.PRIMITIVES)) {
  for (const params of [{}, { segments: 3 }, { segments: 5, rings: 3, sides: 3 }]) {
    const m = M.primitive(t, params), topo = M.topology(m);
    ok(m.faces.every((f) => new Set(f).size === f.length && f.length >= 3), `${t} ${JSON.stringify(params)} faces valides`);
    ok(m.faces.every((f) => f.every((i) => i >= 0 && i < m.verts.length)), `${t} indices`);
    if (t === 'plane') { ok(topo.boundary > 0 && topo.duplicated === 0, 'plan ouvert'); ok(m.faces.every((f) => M.faceNormal(m, f)[1] > 0.99), 'plan vers +Y'); continue; }
    ok(topo.closed, `${t} ${JSON.stringify(params)} fermé ${JSON.stringify(topo)}`);
    ok(topo.euler === expectEuler[t], `${t} Euler ${topo.euler}`);
    ok(M.signedVolume(m) > 0, `${t} volume positif`);
    if (t !== 'torus') ok(allNormalsOut(m), `${t} normales sortantes`);
    ok(M.isSymmetric(m), `${t} symétrique en X`);
  }
}
// volumes connus
ok(close(M.signedVolume(M.primitive('cube', { w: 2, h: 3, d: 4, segments: 3 })), 24), 'volume cube 2x3x4');
const sv = M.signedVolume(M.primitive('sphere', { radius: 1, segments: 64, rings: 32 }));
ok(sv > 4.0 && sv < 4 / 3 * Math.PI, 'volume sphère ≈ 4/3π ' + sv);
const cyl = M.primitive('cylinder', { radius: 1, height: 2, segments: 128, rings: 2 });
ok(Math.abs(M.signedVolume(cyl) - 2 * Math.PI) < 0.01, 'volume cylindre');
const cb = M.primitive('cube'); ok(cb.verts.length === 8 && cb.faces.length === 6, 'cube 8 sommets 6 faces');
const cb3 = M.primitive('cube', { segments: 3 }); ok(cb3.verts.length === 56 && cb3.faces.length === 54, 'cube seg3 ' + cb3.verts.length);
ok(M.primitive('cube', { w: 'abc', segments: 9999 }).faces.length === 6 * 32 * 32, 'bornes');
const b = M.bounds(M.primitive('capsule', { radius: 0.3, height: 2 })); ok(close(b.max[1], 1) && close(b.min[1], -1), 'capsule hauteur');

// 2. extrusion
{
  const m = M.primitive('cube');
  const top = m.faces.findIndex((f) => M.faceNormal(m, f)[1] > 0.99);
  const r = M.extrudeFaces(m, [top], 0.5), t = M.topology(r.mesh);
  ok(t.closed && t.euler === 2, 'extrusion 1 face fermée');
  ok(r.mesh.verts.length === 12 && r.mesh.faces.length === 10, 'extrusion 12 v / 10 f');
  ok(close(M.signedVolume(r.mesh), 1.5), 'extrusion volume 1.5');
  ok(r.faces[0] === top && close(M.faceCenter(r.mesh, r.mesh.faces[top])[1], 1), 'face extrudée sélectionnée en haut');
  ok(allNormalsOut(r.mesh), 'extrusion normales');
  // extrusion vers l'intérieur
  const rin = M.extrudeFaces(m, [top], -0.25); ok(M.topology(rin.mesh).closed && close(M.signedVolume(rin.mesh), 0.75), 'extrusion négative');
  // région de 2 faces adjacentes (cube segmenté)
  const m3 = M.primitive('cube', { segments: 2 });
  const tops = m3.faces.map((f, i) => [i, M.faceNormal(m3, f)[1]]).filter((x) => x[1] > 0.99).map((x) => x[0]);
  const r2 = M.extrudeFaces(m3, tops.slice(0, 2), 1), t2 = M.topology(r2.mesh);
  ok(t2.closed && t2.euler === 2, 'extrusion région 2 faces fermée');
  ok(r2.mesh.verts.length === m3.verts.length + 6, 'région : 6 nouveaux sommets (pas 8)');
  ok(close(M.signedVolume(r2.mesh), 1 + 0.5), 'région : volume');
  // deux faces opposées : deux régions séparées
  const bot = m.faces.findIndex((f) => M.faceNormal(m, f)[1] < -0.99);
  const r3 = M.extrudeFaces(m, [top, bot], 1); ok(M.topology(r3.mesh).closed && close(M.signedVolume(r3.mesh), 3), 'deux régions opposées');
  // extrusions successives sur la sphère + toutes les faces
  let s = M.primitive('sphere'); const all = s.faces.map((_, i) => i);
  const r4 = M.extrudeFaces(s, all, 0.1); ok(M.topology(r4.mesh).closed, 'extrusion de toutes les faces');
  let e = { mesh: s, faces: [3] }; for (let k = 0; k < 5; k++) e = M.extrudeFaces(e.mesh, e.faces, 0.1);
  ok(M.topology(e.mesh).closed && e.mesh.faces.length === s.faces.length + 5 * 3, 'extrusions successives (triangle)');
  ok(M.extrudeFaces(m, [], 1).mesh === m && M.extrudeFaces(m, [99], 1).faces.length === 0, 'extrusion vide');
}

// 3. symétrie
{
  const m = M.primitive('cube', { segments: 2 });
  const right = m.verts.map((p, i) => [p, i]).filter(([p]) => p[0] > 0.4 && p[1] > 0.4).map(([, i]) => i);
  const moved = M.transformVerts(m, right, M.translateFn([0.3, 0.1, 0]), true);
  ok(M.isSymmetric(moved), 'déplacement symétrique : reste symétrique');
  const mm = M.mirrorMap(moved);
  ok(right.every((i) => close(moved.verts[i][0], m.verts[i][0] + 0.3) && close(moved.verts[mm[i]][0], -moved.verts[i][0])), 'reflet exact');
  const mid = m.verts.map((p, i) => [p, i]).filter(([p]) => Math.abs(p[0]) < 1e-9).map(([, i]) => i);
  const mv2 = M.transformVerts(m, mid, M.translateFn([0.2, 0, 0]), true);
  ok(mid.every((i) => mv2.verts[i][0] === 0), 'sommets du plan restent à x = 0');
  const rot = M.transformVerts(m, right, M.rotateFn(M.centroid(m, right), 2, 30), true); ok(M.isSymmetric(rot), 'rotation symétrique');
  const sc = M.transformVerts(m, right, M.scaleFn(M.centroid(m, right), [2, 2, 2]), true); ok(M.isSymmetric(sc), 'échelle symétrique');
  const asym = M.transformVerts(m, right, M.translateFn([0.3, 0, 0]), false); ok(!M.isSymmetric(asym), 'sans symétrie : asymétrique');
  ok(m.verts[right[0]][0] === M.primitive('cube', { segments: 2 }).verts[right[0]][0], 'transformVerts ne modifie pas l\'original');
  const fr = m.faces.findIndex((f) => M.faceNormal(m, f)[0] > 0.99);
  const fs2 = M.symmetrizeFaces(m, [fr]); ok(fs2.length === 2 && M.faceNormal(m, m.faces[fs2.find((x) => x !== fr)])[0] < -0.99, 'face miroir');
  // extrusion symétrique : faces + miroir → reste symétrique
  const ex = M.extrudeFaces(m, fs2, 0.4); ok(M.isSymmetric(ex.mesh) && M.topology(ex.mesh).closed, 'extrusion symétrique');
}

// 4. Euler ↔ quaternion
for (const r of [[0, 0, 0], [30, 0, 0], [0, 45, 0], [10, 20, 30], [-120, 60, 170], [0, 90, 0], [45, -89.9, 12]]) {
  const back = M.eulerDegFromQuat(M.quatFromEulerDeg(r));
  const q1 = M.quatFromEulerDeg(r), q2 = M.quatFromEulerDeg(back);
  const d = Math.abs(q1.reduce((s, x, k) => s + x * q2[k], 0));
  ok(close(d, 1, 1e-6), 'quaternion aller-retour ' + r + ' → ' + back);
}

// 5. .glb aller-retour
const outDir = process.argv[2];
{
  const sphere = M.primitive('sphere'), ext = M.extrudeFaces(M.primitive('cube'), [0], 0.3).mesh;
  const scene = { name: 'Test é', symmetry: true, objects: [
    { id: 'm1', name: 'Tête', color: '#ff8800', mesh: sphere, pos: [0, 1.5, 0], rot: [10, 20, 30], scale: [1, 1.2, 1] },
    { id: 'm2', name: 'Corps', color: '#336699', mesh: ext, pos: [0, 0, 0], rot: [0, 0, 0], scale: [1, 1, 1] },
    { id: 'm3', name: 'Tore', color: 'bad', mesh: M.primitive('torus'), pos: [1, 0, 0], rot: [90, 0, 0], scale: [1, 1, 1] }] };
  const glb = M.writeGLB(scene), dv = new DataView(glb.buffer);
  ok(dv.getUint32(0, true) === 0x46546C67 && dv.getUint32(4, true) === 2 && dv.getUint32(8, true) === glb.length, 'en-tête glb');
  ok(glb.length % 4 === 0 && dv.getUint32(12, true) % 4 === 0, 'alignement 4');
  const back = M.readGLB(glb);
  ok(back.name === 'Test é' && back.symmetry === true && back.objects.length === 3, 'scène relue');
  ok(JSON.stringify(back.objects[0].mesh.faces) === JSON.stringify(sphere.faces), 'faces identiques');
  ok(back.objects[0].mesh.verts.every((p, i) => p.every((x, k) => close(x, sphere.verts[i][k], 1e-6))), 'sommets identiques');
  ok(back.objects[0].rot.every((x, k) => close(x, [10, 20, 30][k], 1e-4)), 'rotation relue ' + back.objects[0].rot);
  ok(back.objects[2].color === '#c9a227' && back.objects[1].name === 'Corps' && back.objects[0].id === 'm1', 'métadonnées');
  // lecture sans extras (fichier glTF quelconque) : soudure des triangles
  const jl = dv.getUint32(12, true), json = JSON.parse(new TextDecoder().decode(glb.subarray(20, 20 + jl)));
  for (const nd of json.nodes) delete nd.extras;
  let jb = new TextEncoder().encode(JSON.stringify(json)); const pad = (4 - jb.length % 4) % 4;
  const jb2 = new Uint8Array(jb.length + pad).fill(0x20); jb2.set(jb);
  const binPart = glb.subarray(20 + jl), raw = new Uint8Array(20 + jb2.length + binPart.length), rdv = new DataView(raw.buffer);
  rdv.setUint32(0, 0x46546C67, true); rdv.setUint32(4, 2, true); rdv.setUint32(8, raw.length, true);
  rdv.setUint32(12, jb2.length, true); rdv.setUint32(16, 0x4E4F534A, true); raw.set(jb2, 20); raw.set(binPart, 20 + jb2.length);
  const plain = M.readGLB(raw);
  ok(plain.objects.length === 3 && M.topology(plain.objects[0].mesh).closed && plain.objects[0].mesh.verts.length === sphere.verts.length, 'glb sans extras → maillage fermé soudé');
  ok(close(M.signedVolume(plain.objects[1].mesh), M.signedVolume(ext), 1e-5), 'volume conservé sans extras');
  // vide
  let te = 0; try { M.writeGLB({ name: 'vide', objects: [] }); } catch { te = 1; } ok(te, 'scène vide refusée');
  let threw = 0; try { M.readGLB(new Uint8Array(40)); } catch { threw = 1; } ok(threw, 'refuse un faux fichier');
  if (outDir) {
    fs.mkdirSync(outDir, { recursive: true });
    fs.writeFileSync(path.join(outDir, 'modeleur_test.glb'), glb);
    fs.writeFileSync(path.join(outDir, 'modeleur_cube.glb'), M.writeGLB({ name: 'cube', objects: [{ id: 'c', name: 'Cube', color: '#808080', mesh: M.primitive('cube'), pos: [0, 0, 0], rot: [0, 0, 0], scale: [1, 1, 1] }] }));
  }
}
// 6. couleur d'un .glb venu d'ailleurs (sans extras.sbh) : matière ou couleurs de sommets
{
  const glb = M.writeGLB({ name: 'c', objects: [{ id: 'a', name: 'A', color: '#336699', mesh: M.primitive('cube'), pos: [0, 0, 0], rot: [0, 0, 0], scale: [1, 1, 1] }] });
  const dv = new DataView(glb.buffer), jl = dv.getUint32(12, true), js = JSON.parse(new TextDecoder().decode(glb.subarray(20, 20 + jl)));
  for (const nd of js.nodes) delete nd.extras;
  const rebuild = (json, bin) => {
    let jb = new TextEncoder().encode(JSON.stringify(json)); const pad = (4 - jb.length % 4) % 4;
    const j2 = new Uint8Array(jb.length + pad).fill(0x20); j2.set(jb);
    const out = new Uint8Array(20 + j2.length + bin.length), d = new DataView(out.buffer);
    d.setUint32(0, 0x46546C67, true); d.setUint32(4, 2, true); d.setUint32(8, out.length, true);
    d.setUint32(12, j2.length, true); d.setUint32(16, 0x4E4F534A, true); out.set(j2, 20); out.set(bin, 20 + j2.length); return out;
  };
  const binPart = glb.subarray(20 + jl);
  ok(M.readGLB(rebuild(js, binPart)).objects[0].color === '#336699', 'couleur de matière relue (linéaire → écran) ' + M.readGLB(rebuild(js, binPart)).objects[0].color);
  // couleurs de sommets u8 normalisées (comme trimesh) : on ajoute un bufferView de couleurs
  const js2 = JSON.parse(JSON.stringify(js)); delete js2.meshes[0].primitives[0].material;
  const cnt = js2.accessors[0].count, binLen = binPart.length - 8, extra = new Uint8Array(cnt * 4);
  for (let i = 0; i < cnt; i++) extra.set([198, 188, 173, 255], i * 4);
  const newBin = new Uint8Array(binLen + extra.length); newBin.set(binPart.subarray(8)); newBin.set(extra, binLen);
  js2.bufferViews.push({ buffer: 0, byteOffset: binLen, byteLength: extra.length });
  js2.accessors.push({ bufferView: js2.bufferViews.length - 1, componentType: 5121, normalized: true, count: cnt, type: 'VEC4' });
  js2.meshes[0].primitives[0].attributes.COLOR_0 = js2.accessors.length - 1; js2.buffers[0].byteLength = newBin.length;
  const head = new Uint8Array(8); new DataView(head.buffer).setUint32(0, newBin.length, true); new DataView(head.buffer).setUint32(4, 0x004E4942, true);
  const binChunk = new Uint8Array(8 + newBin.length); binChunk.set(head); binChunk.set(newBin, 8);
  ok(M.readGLB(rebuild(js2, binChunk)).objects[0].color === '#c6bcad', 'couleurs de sommets relues (moyenne) ' + M.readGLB(rebuild(js2, binChunk)).objects[0].color);
}
// 7. .glb étranger : origine de chaque objet au centre de sa pièce, rendu identique
{
  const cube = M.primitive('cube');
  const shifted = { verts: cube.verts.map((p) => [p[0] + 3, p[1] + 1, p[2] - 2]), faces: cube.faces };
  const glb = M.writeGLB({ name: 'x', objects: [{ id: 'a', name: 'A', color: '#808080', mesh: shifted, pos: [1, 0, 0], rot: [0, 90, 0], scale: [2, 1, 1] }] });
  const dv = new DataView(glb.buffer), jl = dv.getUint32(12, true), js = JSON.parse(new TextDecoder().decode(glb.subarray(20, 20 + jl)));
  for (const nd of js.nodes) delete nd.extras;
  let jb = new TextEncoder().encode(JSON.stringify(js)); const pad = (4 - jb.length % 4) % 4; const j2 = new Uint8Array(jb.length + pad).fill(0x20); j2.set(jb);
  const bp = glb.subarray(20 + jl), out = new Uint8Array(20 + j2.length + bp.length), d = new DataView(out.buffer);
  d.setUint32(0, 0x46546C67, true); d.setUint32(4, 2, true); d.setUint32(8, out.length, true); d.setUint32(12, j2.length, true); d.setUint32(16, 0x4E4F534A, true); out.set(j2, 20); out.set(bp, 20 + j2.length);
  const o = M.readGLB(out).objects[0], b = M.bounds(o.mesh);
  ok(b.min.every((v, k) => close(v, -b.max[k], 1e-5)), 'objet étranger recentré sur sa pièce');
  // même position monde d'un coin : T + R(S·v)
  const world = (pos, rot, sc, v) => M.add(pos, M.quatRotate(M.quatFromEulerDeg(rot), [v[0] * sc[0], v[1] * sc[1], v[2] * sc[2]]));
  const w0 = world([1, 0, 0], [0, 90, 0], [2, 1, 1], [3.5, 1.5, -1.5]);
  const near = o.mesh.verts.map((v) => world(o.pos, o.rot, o.scale, v)).some((w) => w.every((x, k) => close(x, w0[k], 1e-4)));
  ok(near, 'rendu identique après recentrage (même coin dans le monde)');
}
console.log(`${n - fails}/${n} vérifications OK`);
process.exit(fails ? 1 : 0);
