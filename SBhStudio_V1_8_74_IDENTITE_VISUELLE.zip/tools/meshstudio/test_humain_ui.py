import asyncio, base64, sys, json, time
sys.path.insert(0, '/home/claude/sbh/tools/meshstudio')
from test_mesh_studio import BRIDGE, URL, tapel, tap, touch
from playwright.async_api import async_playwright
OUT = sys.argv[1]
async def drag(cdp, x, y, dx, dy, steps=14):
    await touch(cdp, "touchStart", [(x, y)])
    for k in range(1, steps + 1):
        await touch(cdp, "touchMove", [(x + dx * k / steps, y + dy * k / steps)]); await asyncio.sleep(0.016)
    await touch(cdp, "touchEnd", []); await asyncio.sleep(0.25)
async def fill(pg, sel, v):
    await pg.evaluate("(s) => document.querySelector(s).scrollIntoView({block: 'nearest'})", sel)
    await pg.fill(sel, str(v)); await pg.dispatch_event(sel, "change"); await asyncio.sleep(0.1)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"])
        ctx = await b.new_context(viewport={"width": 412, "height": 915}, device_scale_factor=2.625, has_touch=True, is_mobile=True)
        await ctx.add_init_script(BRIDGE)
        pg = await ctx.new_page(); errs = []; pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        cdp = await ctx.new_cdp_session(pg)
        await pg.goto(URL); await pg.wait_for_function("window.__meshReady === true"); await asyncio.sleep(0.5)
        await tapel(pg, cdp, "#btnAdd"); await tapel(pg, cdp, "[data-prim=human]"); await asyncio.sleep(0.2)
        await fill(pg, "[data-param=muscle]", 1.25); await fill(pg, "[data-param=build]", 1.1)
        await pg.screenshot(path=f"{OUT}/h1_panneau.png")
        await pg.evaluate("window.__frames = 0; (function tick() { window.__frames++; requestAnimationFrame(tick); })()")
        t0 = time.time(); await tapel(pg, cdp, "#addGo")
        f0 = await pg.evaluate("window.__frames"); await asyncio.sleep(1.0); f1 = await pg.evaluate("window.__frames")
        await pg.wait_for_function("window.__mesh.S.objects.some((o) => o.smooth)", timeout=90000)
        dt = time.time() - t0
        names = await pg.evaluate("window.__mesh.S.objects.map((o) => o.name)")
        await asyncio.sleep(0.4)
        # je supprime le cube de départ (☰ Objets, 2 touches) et je renomme
        await tapel(pg, cdp, "#btnObjects"); await asyncio.sleep(0.2)
        await pg.screenshot(path=f"{OUT}/h1b_objets.png")
        await tapel(pg, cdp, "[data-del]", 0); await tapel(pg, cdp, "[data-del]", 0)
        await tapel(pg, cdp, ".objrow", 0); await fill(pg, "#sceneName", "Corps Gardien"); await tapel(pg, cdp, "#sheetClose")

        await tap(cdp, 30, 220); await tapel(pg, cdp, "#btnFrame"); await asyncio.sleep(0.3)
        await pg.screenshot(path=f"{OUT}/h2_corps.png")
        info = await pg.evaluate("(() => { const W = window.__mesh, o = W.S.objects[0], t = W.M.topology(o.mesh); return [o.name, o.smooth, o.mesh.verts.length, o.mesh.faces.length, t.closed, W.M.isSymmetric(o.mesh), W.S.objects.length]; })()")
        await drag(cdp, 60, 700, 120, 0); await pg.screenshot(path=f"{OUT}/h3_dos.png")
        # mode Face : je touche une face de la poitrine et j'extrude (montre l'édition sur le corps)
        await drag(cdp, 60, 700, -120, 0)
        await tapel(pg, cdp, "[data-mode=face]")
        await tap(cdp, 206, 380); sel = await pg.evaluate("[...window.__mesh.S.selF]")
        await pg.screenshot(path=f"{OUT}/h4_face.png")
        r = await pg.evaluate("window.sbhMeshBack()")
        last = await pg.evaluate("window.__calls.save[window.__calls.save.length - 1]")
        open(f"{OUT}/corps_gardien.glb", "wb").write(base64.b64decode(last[3]))
        ok = (f1 - f0) > 20 and {"Corps", "Tête", "Short", "Cheveux courts", "Barbe"} <= set(names) and info[4] and info[5]
        print("RÉSULTAT", "OK" if ok else "ÉCHEC", "— images pendant le calcul :", f1 - f0, "/ pièces :", names)
        print(json.dumps({"creation_s": round(dt, 2), "objet": info, "face_choisie": sel, "meta": json.loads(last[2]), "erreurs": errs}, ensure_ascii=False))
        await b.close()
asyncio.run(main())
