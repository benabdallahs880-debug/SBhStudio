// Integration logic with real Three.js geometry, mocked DOM/renderer/worker.
// Does NOT replace touch tests in a browser or an APK test on Android.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as RealThree from '../../app/src/main/assets/js/three.module.js';
import * as M from '../../app/src/main/assets/meshstudio/mesh_core.js';
import * as Body from '../../app/src/main/assets/meshstudio/body_core.js';
import * as MeshSculpt from '../../app/src/main/assets/meshstudio/mesh_sculpt_core.js';
import * as Stroke from '../../app/src/main/assets/meshstudio/stroke_core.js';
import * as Forge from '../../app/src/main/assets/meshstudio/forge_core.js';
import * as Sculpt from '../../app/src/main/assets/meshstudio/sculpt_core.js';
class Element {
 constructor(){this.style={};this.classList={add(){},remove(){},toggle(){},contains(){return false;}};this.clientWidth=412;this.clientHeight=650;this.width=412;this.height=650;this.dataset={};this.value='';}
 addEventListener(){} insertBefore(){} get firstChild(){return null;} querySelectorAll(){return [];} closest(){return null;}
 getBoundingClientRect(){return {left:0,top:0,width:412,height:650};} setPointerCapture(){} releasePointerCapture(){}
 getContext(){return {drawImage(){}};} toDataURL(){return 'data:image/png;base64,AA==';}
}
const els=new Map();globalThis.document={getElementById:id=>{if(!els.has(id))els.set(id,new Element());return els.get(id);},querySelectorAll:()=>[],createElement:()=>new Element(),addEventListener(){},activeElement:null};
let calls=0,saved=null;
globalThis.window={devicePixelRatio:1,addEventListener(){},SBhMesh:{start:()=>JSON.stringify({id:'test',name:'Sculpture'}),save:b=>{calls++;saved=Uint8Array.from(Buffer.from(b,'base64'));return true;},toast(){}}};
globalThis.ResizeObserver=class{observe(){}};
globalThis.requestAnimationFrame=()=>0;
class Controls {constructor(camera){this.camera=camera;this.target=new RealThree.Vector3();this.enabled=true;}update(){this.camera.lookAt(this.target);this.camera.updateMatrixWorld(true);}addEventListener(){}}
const THREE={...RealThree,WebGLRenderer:class{constructor(){this.domElement=new Element();}setPixelRatio(){}getPixelRatio(){return 1;}setClearColor(){}setSize(){}render(){}}};
let posted=0,forcedError=false;
globalThis.Worker=class {postMessage(job){posted++;if(forcedError){setTimeout(()=>this.onmessage({data:{error:'Test reconstruction impossible'}}),5);return;}setTimeout(()=>this.onmessage({data:{revision:job.revision,mesh:Sculpt.extract(job.kind==='preset'?Sculpt.preset(job.type):job.volume),...(job.kind==='preset'?{volume:Sculpt.preset(job.type)}:{})}}),5);}terminate(){}};
const html=fs.readFileSync(new URL('../../app/src/main/assets/meshstudio/mesh_studio.html',import.meta.url),'utf8');
let js=html.match(/<script type="module">([\s\S]*?)<\/script>/)[1];
js=js.replace(/^import .*;$/gm,'').replaceAll('import.meta.url',JSON.stringify(new URL('../../app/src/main/assets/meshstudio/mesh_studio.html',import.meta.url).href));
new Function('THREE','OrbitControls','M','Body','Sculpt','Forge','Stroke','MeshSculpt',js)(THREE,Controls,M,Body,Sculpt,Forge,Stroke,MeshSculpt);
const W=window.__mesh,wait=async()=>{for(let i=0;i<100&&(W.sculptBusy||W.sculptInputPending);i++)await new Promise(r=>setTimeout(r,10));assert.equal(W.sculptBusy,false);};
assert.equal(window.__meshReady,true);
W.addPrimitive('clay',{});assert.equal(W.S.mode,'sculpt');
const clay=W.S.objects.find(o=>o.id===W.S.active), before=JSON.stringify(clay.sculpt);
// Several pending stamps: only the most recent field is used for the final surface.
for(let i=0;i<6;i++)W.sculptStamp([.5,.1,0]);
assert.equal(W.sculptBusy,true);W.finishSculpt();assert.equal(W.saveNow(),false);
await wait();assert.notEqual(JSON.stringify(clay.sculpt),before);assert.equal(M.topology(clay.mesh).closed,true);
assert.deepEqual(clay.mesh,Sculpt.extract(clay.sculpt));
W.undo();assert.equal(JSON.stringify(W.S.objects.find(o=>o.id===clay.id).sculpt),before);
W.redo();assert.notEqual(JSON.stringify(W.S.objects.find(o=>o.id===clay.id).sculpt),before);
assert.equal(W.saveNow(),true);assert.ok(calls>0);assert.ok(M.readGLB(saved).objects.find(o=>o.id===clay.id).sculpt);
W.setMode('vertex');assert.equal(W.S.objects.find(o=>o.id===clay.id).sculpt,undefined);
W.undo();assert.ok(W.S.objects.find(o=>o.id===clay.id).sculpt);
// Undoing creation restores a usable object mode, instead of leaving a cube in sculpt mode.
W.undo();W.undo();assert.equal(W.S.objects.length,1);assert.equal(W.S.mode,'vertex');
W.addPrimitive('clay',{});W.undo();assert.equal(W.S.mode,'sculpt');
assert.ok(posted>0);
W.addPrimitive('humanoid',{});await wait();
const human=W.S.objects.find(o=>o.id===W.S.active);assert.ok(human.sculpt);assert.equal(M.topology(human.mesh).closed,true);
const preVolume=JSON.stringify(human.sculpt);
assert.equal(W.applyVolume({type:'ellipsoid',center:[0,.3,.4],size:[.2,.2,.2]},'cut'),true);await wait();
assert.notEqual(JSON.stringify(human.sculpt),preVolume);W.undo();assert.equal(JSON.stringify(W.S.objects.find(o=>o.id===human.id).sculpt),preVolume);W.redo();
W.addPrimitive('plate',{bend:80,hole:.1});const plateId=W.S.active;
assert.ok(W.S.objects.find(o=>o.id===plateId).forge);
assert.equal(W.editPlate({w:.8,h:.9,thickness:.03,hole:.15,holeX:.1,holeY:.1,bend:90}),true);
W.saveNow();assert.ok(M.readGLB(saved).objects.find(o=>o.id===plateId).forge);
W.setMode('face');assert.equal(W.S.objects.find(o=>o.id===plateId).forge,undefined);W.undo();assert.ok(W.S.objects.find(o=>o.id===plateId).forge);
const oldCount=W.S.objects.length;W.addPrimitive('car',{});assert.equal(W.S.objects.length,oldCount+21);W.saveNow();assert.equal(M.readGLB(saved).objects.length,W.S.objects.length);
// Real raycasting + scheduled path drain; one complete gesture is one undo entry.
W.addPrimitive('clay',{});W.setView('front');W.brushSettings.stabilization=0;
const gestureId=W.S.active,gestureBefore=W.snapshot();
const object=W.S.objects.find(o=>o.id===gestureId),viewMesh=W.meshCache.get(gestureId);viewMesh.updateMatrixWorld(true);
const event=(x)=>{const p=new RealThree.Vector3(x,0,.55).applyMatrix4(viewMesh.matrixWorld).project(W.camera);return {clientX:(p.x+1)*206,clientY:(1-p.y)*325,pointerId:1,stopImmediatePropagation(){},preventDefault(){}};};
W.sculptDown(event(0));assert.equal(W.sculptInputPending,true);
for(const x of [.08,.16,.24])W.sculptMove(event(x));
W.finishSculpt();assert.equal(W.saveNow(),false);await wait();
assert.notEqual(W.snapshot(),gestureBefore);assert.equal(M.topology(W.S.objects.find(o=>o.id===gestureId).mesh).closed,true);
W.undo();assert.equal(W.snapshot(),gestureBefore);W.redo();
const accepted=W.snapshot();forcedError=true;W.sculptStamp([0,0,.55]);W.finishSculpt();await wait();forcedError=false;
assert.equal(W.snapshot(),accepted);assert.equal(W.sculptInputPending,false);
// Surface sculpting on a normal mesh; no volumetric field required.
W.addPrimitive('sphere',{radius:.5,segments:24,rings:18});const surfaceId=W.S.active;W.setMode('sculpt');assert.equal(W.S.mode,'sculpt');
W.brushSettings.tool='protect';W.brushSettings.radius=.2;W.sculptStamp([0,0,.5],[0,0,0],[0,0,1]);W.finishSculpt();
let surface=W.S.objects.find(o=>o.id===surfaceId);assert.ok(surface.sculptMask.some(Boolean));
assert.ok(W.meshCache.get(surfaceId).geometry.getAttribute('color'));
const masked=JSON.stringify(surface.mesh);W.brushSettings.tool='inflate';W.sculptStamp([0,0,.5],[0,0,0],[0,0,1]);W.finishSculpt();assert.equal(JSON.stringify(surface.mesh),masked);
W.saveNow();assert.ok(M.readGLB(saved).objects.find(o=>o.id===surfaceId).sculptMask);
W.undo();assert.equal(W.S.mode,'sculpt');W.redo();
console.log('Surface import mask/display/save and history OK');
console.log('Failed reconstruction restores accepted state OK');
console.log('Precision gesture OK: ray hit, spatial queue drain, closed surface and single undo');
console.log('New forms integration OK: sculptable humanoid, volume cut/undo, plate edit/save, vehicle parts');
console.log('Integration OK: boot, queued reconstruction, history, conversion and saved editable volume (rendering mocked)');
process.exit(0);
