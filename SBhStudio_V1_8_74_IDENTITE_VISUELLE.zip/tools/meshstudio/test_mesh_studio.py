"""Tests « téléphone » du Modeleur 3D (assets/meshstudio/mesh_studio.html).

Pré-requis : serveur local sur les assets
    cd app/src/main/assets && python3 -m http.server 8765
Puis :  python3 tools/meshstudio/test_mesh_studio.py [dossier_captures]

Émulation : 412×915 CSS px, densité 2.625, écran tactile, portrait puis paysage. Les gestes sont de
vrais événements tactiles (CDP Input.dispatchTouchEvent), pas des clics souris. Le pont Android
window.SBhMesh est simulé : start() / save() / close() / toast() sont enregistrés.
"""
import asyncio, base64, json, struct, sys, pathlib
from playwright.async_api import async_playwright

URL = "http://localhost:8765/meshstudio/mesh_studio.html"
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/meshstudio_shots")
OUT.mkdir(parents=True, exist_ok=True)
results = []


def ok(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(("OK   " if cond else "ÉCHEC") + " " + name + (("  — " + str(extra)) if extra and not cond else ""))


BRIDGE = """
window.__calls = { save: [], close: 0, toast: [] };
window.SBhMesh = {
  start: () => JSON.stringify(window.__start || { id: 'm_test', name: 'Bras test', glb: null }),
  save: (b64, png, meta) => { window.__calls.save.push([b64.length, png.slice(0, 22), meta, b64]); return true; },
  close: () => { window.__calls.close++; },
  toast: (t) => { window.__calls.toast.push(t); },
};
"""


async def touch(cdp, kind, pts):
    await cdp.send("Input.dispatchTouchEvent", {"type": kind, "touchPoints": [{"x": x, "y": y, "id": i} for i, (x, y) in enumerate(pts)]})


async def tap(cdp, x, y):
    await touch(cdp, "touchStart", [(x, y)]); await asyncio.sleep(0.04); await touch(cdp, "touchEnd", [])
    await asyncio.sleep(0.12)


async def drag(cdp, x, y, dx, dy, steps=12):
    await touch(cdp, "touchStart", [(x, y)])
    for k in range(1, steps + 1):
        await touch(cdp, "touchMove", [(x + dx * k / steps, y + dy * k / steps)]); await asyncio.sleep(0.016)
    await touch(cdp, "touchEnd", []); await asyncio.sleep(0.15)


async def tapel(pg, cdp, sel, i=0):
    await pg.evaluate("([s, i]) => document.querySelectorAll(s)[i].scrollIntoView({block: 'nearest'})", [sel, i]); await asyncio.sleep(0.05)
    bx = (await boxes(pg, sel))[i]
    await tap(cdp, bx[0] + bx[2] / 2, bx[1] + bx[3] / 2)


async def ev(pg, js):
    return await pg.evaluate(js)


HANDLE_JS = """(k) => { const W = window.__mesh, f = W.gizmoFrame(); if (!f) return null;
  const p = k === 3 ? f.origin.clone() : f.origin.clone().addScaledVector(f.dirs[k], f.size * 0.92); const s = W.toScreen(p); return [s.x, s.y]; }"""
FACE_JS = """(want) => { const W = window.__mesh, M = W.M, o = W.S.objects.find((x) => x.id === W.S.active), m = W.meshCache.get(o.id);
  // centre à l'écran de la face dont la normale (monde) suit le mieux « want » et qui fait face à la caméra
  let best = null, bs = -2;
  o.mesh.faces.forEach((f, i) => { const n = new W.THREE.Vector3(...M.faceNormal(o.mesh, f)).transformDirection(m.matrixWorld);
    const c = new W.THREE.Vector3(...M.faceCenter(o.mesh, f)).applyMatrix4(m.matrixWorld);
    const sc = n.dot(new W.THREE.Vector3(...want)); if (n.dot(W.camera.position.clone().sub(c)) > 0 && sc > bs) { bs = sc; best = [i, c]; } });
  const s = W.toScreen(best[1]); return [best[0], s.x, s.y]; }"""
TOPO_JS = """() => { const W = window.__mesh, o = W.S.objects.find((x) => x.id === W.S.active); const t = W.M.topology(o.mesh);
  return { V: o.mesh.verts.length, F: o.mesh.faces.length, closed: t.closed, sym: W.M.isSymmetric(o.mesh), vol: W.M.signedVolume(o.mesh) }; }"""


def glb_ok(b64):
    raw = base64.b64decode(b64)
    magic, ver, total = struct.unpack("<III", raw[:12])
    jlen, jtype = struct.unpack("<II", raw[12:20])
    js = json.loads(raw[20:20 + jlen])
    return magic == 0x46546C67 and ver == 2 and total == len(raw) and jtype == 0x4E4F534A and js["asset"]["version"] == "2.0", js


async def boxes(pg, sel):
    return await pg.evaluate("(s) => [...document.querySelectorAll(s)].filter((e) => e.offsetParent).map((e) => { const r = e.getBoundingClientRect(); return [r.x, r.y, r.width, r.height, e.textContent.trim().slice(0, 12)]; })", sel)


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
        ctx = await b.new_context(viewport={"width": 412, "height": 915}, device_scale_factor=2.625, has_touch=True, is_mobile=True)
        await ctx.add_init_script(BRIDGE)
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        cdp = await ctx.new_cdp_session(pg)
        await pg.goto(URL); await pg.wait_for_function("window.__meshReady === true", timeout=20000); await asyncio.sleep(0.6)
        ok("P01 la page démarre sans erreur", not errs, errs)
        ok("P02 maillage neuf : un cube « Corps »", await ev(pg, "window.__mesh.S.objects.length === 1 && window.__mesh.S.objects[0].name === 'Corps'"))
        await asyncio.sleep(1.2)
        ok("P03 autosave du maillage neuf (glb + aperçu png)", await ev(pg, "window.__calls.save.length >= 1 && window.__calls.save[0][1].startsWith('data:image/png')"))

        # --- disposition portrait
        tb = await boxes(pg, "#toolbar button"); md = await boxes(pg, "#modes button"); hd = await boxes(pg, "header button")
        ok("P04 boutons ≥ 48 px (barre, onglets, en-tête)", all(w >= 48 and h >= 44 for _, _, w, h, _ in tb + md + hd), [x for x in tb + md + hd if x[2] < 48 or x[3] < 44])
        ok("P05 onglets de mode visibles en haut", all(y >= 0 and y + h <= 140 for _, y, _, h, _ in md))
        ok("P06 les 10 boutons de la barre sont entièrement à l'écran", len(tb) == 10 and all(x >= 0 and x + w <= 412 and y + h <= 915 and y > 760 for x, y, w, h, _ in tb), tb)
        vh = await ev(pg, "document.getElementById('view').getBoundingClientRect().height")
        ok("P07 la vue 3D occupe ≥ 70 % de l'écran", vh >= 0.7 * 915, vh)
        await pg.screenshot(path=str(OUT / "01_portrait_depart.png"))

        # --- mode Face : touche une face, extrusion, glissé de la flèche Y
        await tapel(pg, cdp, "#modes [data-mode=face]")
        ok("P08 onglet Face", await ev(pg, "window.__mesh.S.mode") == "face")
        fi, fx, fy = await ev(pg, f"({FACE_JS})([0,1,0])")
        await tap(cdp, fx, fy)
        ok("P09 toucher une face la choisit", await ev(pg, "[...window.__mesh.S.selF]") == [fi])
        await pg.screenshot(path=str(OUT / "02_face_choisie.png"))
        bx = (await boxes(pg, "#btnExtrude"))[0]
        await tap(cdp, bx[0] + bx[2] / 2, bx[1] + bx[3] / 2)
        t = await ev(pg, f"({TOPO_JS})()")
        ok("P10 Extruder : 12 sommets, 10 faces, fermé", t["V"] == 12 and t["F"] == 10 and t["closed"], t)
        hx, hy = await ev(pg, f"({HANDLE_JS})(1)")
        y0 = await ev(pg, "window.__mesh.M.bounds(window.__mesh.S.objects[0].mesh).max[1]")
        await drag(cdp, hx, hy, 0, -90)
        y1 = await ev(pg, "window.__mesh.M.bounds(window.__mesh.S.objects[0].mesh).max[1]")
        t = await ev(pg, f"({TOPO_JS})()")
        ok("P11 tirer la flèche verte vers le haut monte la face", y1 > y0 + 0.1 and t["closed"], (y0, y1))
        ok("P12 la vue n'a pas tourné pendant le glissé", await ev(pg, "window.__mesh.controls.enabled") is True)
        await pg.screenshot(path=str(OUT / "03_extrusion_tiree.png"))
        hist = await ev(pg, "document.getElementById('btnUndo').disabled")
        ok("P13 Annuler disponible", hist is False)
        await tapel(pg, cdp, "#btnUndo")
        y2 = await ev(pg, "window.__mesh.M.bounds(window.__mesh.S.objects[0].mesh).max[1]")
        ok("P14 Annuler : la face revient", abs(y2 - y0) < 1e-6, (y0, y2))
        await tapel(pg, cdp, "#btnRedo")
        ok("P15 Rétablir", abs(await ev(pg, "window.__mesh.M.bounds(window.__mesh.S.objects[0].mesh).max[1]") - y1) < 1e-6)
        for _ in range(3):
            await tapel(pg, cdp, "#btnUndo")
        ok("P16 annuler jusqu'au cube de départ", (await ev(pg, f"({TOPO_JS})()"))["F"] == 6)

        # --- un doigt hors poignée : la vue tourne ; deux doigts : zoom
        await tapel(pg, cdp, "#modes [data-mode=object]")
        c0 = await ev(pg, "window.__mesh.camera.position.toArray()")
        await drag(cdp, 40, 740, 80, 0)
        c1 = await ev(pg, "window.__mesh.camera.position.toArray()")
        ok("P17 un doigt sur le vide fait tourner la vue", c0 != c1)
        d0 = await ev(pg, "window.__mesh.camera.position.distanceTo(window.__mesh.controls.target)")
        await touch(cdp, "touchStart", [(150, 400), (260, 400)])
        for k in range(1, 11):
            await touch(cdp, "touchMove", [(150 - 6 * k, 400), (260 + 6 * k, 400)]); await asyncio.sleep(0.016)
        await touch(cdp, "touchEnd", []); await asyncio.sleep(0.2)
        d1 = await ev(pg, "window.__mesh.camera.position.distanceTo(window.__mesh.controls.target)")
        ok("P18 deux doigts écartés rapprochent la caméra", d1 < d0 * 0.95, (d0, d1))
        ok("P19 les gestes de vue ne changent pas l'objet actif", await ev(pg, "window.__mesh.S.active === window.__mesh.S.objects[0].id"))

        # --- sphère + symétrie : glisser une face de droite en X garde le maillage symétrique
        await ev(pg, "window.__mesh.addPrimitive('sphere', {radius: 0.6, segments: 12, rings: 8})")
        await tapel(pg, cdp, "#btnFrame"); await asyncio.sleep(0.2)
        await tapel(pg, cdp, "#modes [data-mode=face]")
        fi, fx, fy = await ev(pg, f"({FACE_JS})([1,0.2,0.3])")
        await tap(cdp, fx, fy)
        ok("P20 face de la sphère choisie (côté touché seulement)", await ev(pg, "window.__mesh.S.selF.size") == 1)
        bx = (await boxes(pg, "#btnExtrude"))[0]; await tap(cdp, bx[0] + bx[2] / 2, bx[1] + bx[3] / 2)
        t = await ev(pg, f"({TOPO_JS})()")
        ok("P21 extrusion symétrique : fermée et symétrique", t["closed"] and t["sym"], t)
        await tapel(pg, cdp, "#btnFrame"); await asyncio.sleep(0.2)
        arm = await ev(pg, "(() => { const W = window.__mesh, f = W.gizmoFrame(), o = W.toScreen(f.origin); return f.dirs.map((d) => W.toScreen(f.origin.clone().addScaledVector(d, f.size)).distanceTo(o)).sort((a, b) => a - b)[1]; })()")
        ok("P21a après ⌖ : flèches assez longues pour le doigt (≥ 60 px, sauf l'axe pointé vers la caméra)", arm >= 60, arm)
        await pg.screenshot(path=str(OUT / "04a_symetrie_cadree.png"))
        hx, hy = await ev(pg, f"({HANDLE_JS})(0)")
        sx = await ev(pg, "(() => { const W = window.__mesh, f = W.gizmoFrame(); return W.toScreen(f.origin.clone().addScaledVector(f.dirs[0], f.size)).x - W.toScreen(f.origin).x; })()")
        await drag(cdp, hx, hy, 50 if sx > 0 else -50, -10)
        t2 = await ev(pg, f"({TOPO_JS})()")
        ok("P22 glisser en X : reste symétrique et fermé", t2["sym"] and t2["closed"] and abs(t2["vol"] - t["vol"]) > 1e-4, (t, t2, hx, hy))
        await pg.screenshot(path=str(OUT / "04_symetrie.png"))

        # --- mode Sommet
        await tapel(pg, cdp, "#modes [data-mode=vertex]")
        vx = await ev(pg, """() => { const W = window.__mesh, o = W.S.objects.find((x) => x.id === W.S.active), m = W.meshCache.get(o.id);
           let best = null; o.mesh.verts.forEach((p, i) => { const w = new W.THREE.Vector3(...p).applyMatrix4(m.matrixWorld);
           const d = w.distanceTo(W.camera.position), sc = W.toScreen(w);
           if (sc.x < 30 || sc.x > 382 || sc.y < 140 || sc.y > 760) return;   // seulement ce qui est à l'écran
           if (!best || d < best[0]) best = [d, i, sc]; }); return [best[1], best[2].x, best[2].y]; }""")
        await tap(cdp, vx[1], vx[2])
        got = await ev(pg, "[...window.__mesh.S.selV]")
        dbg = await pg.evaluate("""(ids) => { const W = window.__mesh, o = W.S.objects.find((x) => x.id === W.S.active), m = W.meshCache.get(o.id);
            return ids.map((i) => { const w = new W.THREE.Vector3(...o.mesh.verts[i]).applyMatrix4(m.matrixWorld), s = W.toScreen(w); return [i, Math.round(s.x), Math.round(s.y), w.distanceTo(W.camera.position)]; }); }""", [vx[0]] + got)
        ok("P23 toucher un sommet (le plus proche de la caméra) le choisit", got == [vx[0]], dbg)
        await pg.screenshot(path=str(OUT / "05_sommet.png"))

        # --- panneau Valeurs (objet)
        await tapel(pg, cdp, "#modes [data-mode=object]")
        await tapel(pg, cdp, "#btnValues")
        await pg.fill("#vp0", "1.5"); await pg.dispatch_event("#vp0", "change")
        ok("P24 Valeurs : position X exacte", await ev(pg, "window.__mesh.S.objects.find((o) => o.id === window.__mesh.S.active).pos[0]") == 1.5)
        await pg.fill("#vr1", "45"); await pg.dispatch_event("#vr1", "change")
        ok("P25 Valeurs : rotation Y exacte", abs(await ev(pg, "window.__mesh.S.objects.find((o) => o.id === window.__mesh.S.active).rot[1]") - 45) < 1e-9)
        sh = (await boxes(pg, "#sheet"))[0]
        ok("P26 le panneau laisse voir la vue (≤ 58 % de la hauteur)", sh[3] <= 0.6 * 915, sh)
        await pg.screenshot(path=str(OUT / "06_valeurs.png"))
        ok("P27 Retour Android ferme d'abord le panneau", await ev(pg, "window.sbhMeshBack()") == "handled" and not await ev(pg, "document.getElementById('sheet').classList.contains('open')"))

        # --- panneau Objets : renommer, dupliquer, supprimer (2 touches)
        await tapel(pg, cdp, "#btnObjects")
        await pg.fill("#objName", "Tête"); await pg.dispatch_event("#objName", "change")
        ok("P28 renommer l'objet", await ev(pg, "window.__mesh.S.objects.find((o) => o.id === window.__mesh.S.active).name") == "Tête")
        n0 = await ev(pg, "window.__mesh.S.objects.length")
        dup = (await boxes(pg, "[data-dup]"))[-1]; await tap(cdp, dup[0] + dup[2] / 2, dup[1] + dup[3] / 2)
        ok("P29 dupliquer", await ev(pg, "window.__mesh.S.objects.length") == n0 + 1)
        de = (await boxes(pg, "[data-del]"))[-1]; await tap(cdp, de[0] + de[2] / 2, de[1] + de[3] / 2)
        ok("P30 supprimer : 1re touche demande confirmation", await ev(pg, "window.__mesh.S.objects.length") == n0 + 1)
        de = (await boxes(pg, "[data-del]"))[-1]; await tap(cdp, de[0] + de[2] / 2, de[1] + de[3] / 2)
        ok("P31 supprimer : 2e touche supprime", await ev(pg, "window.__mesh.S.objects.length") == n0)
        await pg.screenshot(path=str(OUT / "07_objets.png"))
        await ev(pg, "window.sbhMeshBack()")

        # --- panneau Ajouter avec paramètres
        await tapel(pg, cdp, "#btnAdd")
        tor = (await boxes(pg, "[data-prim=torus]"))[0]; await tap(cdp, tor[0] + tor[2] / 2, tor[1] + tor[3] / 2)
        await pg.fill("[data-param=segments]", "12")
        go = (await boxes(pg, "#addGo"))[0]
        ok("P32a le bouton « Ajouter » reste visible sans faire défiler", go[1] + go[3] <= 915 - 120, go)
        await tap(cdp, go[0] + go[2] / 2, go[1] + go[3] / 2)
        t = await ev(pg, f"({TOPO_JS})()")
        ok("P32 Ajouter un tore à 12 segments", t["F"] == 12 * 10 and t["closed"], t)

        # --- enregistrement à la fermeture, contenu du .glb
        await asyncio.sleep(1.2)
        r = await ev(pg, "window.sbhMeshBack()")
        last = await ev(pg, "window.__calls.save[window.__calls.save.length - 1]")
        good, js = glb_ok(last[3])
        meta = json.loads(last[2])
        ok("P33 Retour sans panneau : 'close' + enregistrement", r == "close")
        ok("P34 .glb valide (en-tête, longueur, glTF 2.0)", good)
        ok("P35 .glb : 3 objets et polygones d'origine dans extras", len(js["nodes"]) == 3 and all("sbh" in n["extras"] for n in js["nodes"]), [n["name"] for n in js["nodes"]])
        ok("P36 métadonnées pour la carte (objets, faces, triangles)", meta["objects"] == 3 and meta["triangles"] > 0 and meta["id"] == "m_test", meta)
        ok("P37 aucune erreur pendant la séance", not errs, errs)
        saved = last[3]

        # --- réouverture du fichier enregistré
        pg2 = await ctx.new_page(); errs2 = []
        pg2.on("pageerror", lambda e: errs2.append(str(e)))
        await pg2.add_init_script(f"window.__start = {{ id: 'm_test', name: 'Bras test', glb: '{saved}' }};")
        await pg2.goto(URL); await pg2.wait_for_function("window.__meshReady === true", timeout=20000)
        names = await pg2.evaluate("window.__mesh.S.objects.map((o) => o.name)")
        ok("P38 réouverture : les 3 objets reviennent, nom et symétrie", len(names) == 3 and "Tête" in names and await pg2.evaluate("window.__mesh.S.sym") is True, names)
        rot = await pg2.evaluate("window.__mesh.S.objects.find((o) => o.name === 'Tête').rot")
        ok("P39 réouverture : la rotation exacte revient", abs(rot[1] - 45) < 1e-4 and abs(rot[0]) < 1e-4, rot)
        ok("P40 réouverture sans erreur", not errs2, errs2)
        await pg2.close()

        # --- paysage
        await pg.set_viewport_size({"width": 915, "height": 412}); await asyncio.sleep(0.5)
        tb = await boxes(pg, "#toolbar button"); md = await boxes(pg, "#modes button")
        ok("P41 paysage : barre d'outils visible", all(y + h <= 412 for _, y, _, h, _ in tb), tb[:2])
        ok("P42 paysage : onglets visibles et ≥ 44 px", all(y + h <= 412 and h >= 44 for _, y, _, h, _ in md), md)
        vh = await ev(pg, "document.getElementById('view').getBoundingClientRect()")
        ok("P43 paysage : vue 3D ≥ 60 % de la hauteur", vh["height"] >= 0.6 * 412, vh)
        await pg.screenshot(path=str(OUT / "08_paysage.png"))
        await tapel(pg, cdp, "#btnValues"); await asyncio.sleep(0.2)
        sh = (await boxes(pg, "#sheet"))[0]
        ok("P44 paysage : panneau sur le côté droit", sh[0] > 400 and sh[3] > 300, sh)
        await pg.screenshot(path=str(OUT / "09_paysage_panneau.png"))
        await b.close()
    bad = [n for n, c in results if not c]
    print(f"\n{len(results) - len(bad)}/{len(results)} vérifications OK" + (f" — échecs : {bad}" if bad else ""))
    sys.exit(1 if bad else 0)


if __name__ == "__main__": asyncio.run(main())
