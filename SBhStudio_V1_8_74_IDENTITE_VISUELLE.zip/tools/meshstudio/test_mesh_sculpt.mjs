import assert from 'node:assert/strict';import fs from 'node:fs';
import * as M from '../../app/src/main/assets/meshstudio/mesh_core.js';import * as S from '../../app/src/main/assets/meshstudio/mesh_sculpt_core.js';
let checks=0;const ok=(v,msg)=>{assert.ok(v,msg);checks++;};
const sphere=M.primitive('sphere',{radius:.5,segments:32,rings:24}),opts={center:[0,0,.5],normal:[0,0,1],radius:.2,strength:.4,softness:.65};
for(const tool of ['inflate','carve','grab','smooth','polish','flatten','pinch']){
 const r=S.brush(sphere,{...opts,tool,delta:[.02,0,0]});ok(r.changed.length>0,tool+' changes vertices');ok(r.mesh.faces===sphere.faces,'topology retained');ok(r.mesh.verts.length===sphere.verts.length,'vertex count retained');ok(r.mesh.verts.flat().every(Number.isFinite),'finite');ok(M.topology(r.mesh).closed,'closed');
 for(let i=0;i<sphere.verts.length;i++)if(Math.hypot(...sphere.verts[i].map((v,k)=>v-opts.center[k]))>=opts.radius)assert.deepEqual(r.mesh.verts[i],sphere.verts[i]);checks++;
}
const mask=sphere.verts.map(()=>1);const frozen=S.brush(sphere,{...opts,tool:'inflate',mask});ok(frozen.changed.length===0,'full mask blocks deformation');assert.deepEqual(frozen.mesh,sphere);checks++;
const painted=S.brush(sphere,{...opts,tool:'protect'});ok(painted.affected.length>0,'paint region');ok(painted.changed.length===0,'mask brush no geometry');
const open={verts:[[-.1,0,0],[.1,0,0],[.1,.1,0],[-.1,.1,0]],faces:[[0,1,2,3]]};ok(S.brush(open,{...opts,center:[0,.05,0],tool:'inflate'}).changed.length===0,'open boundary protected');
// Nearby disconnected duplicate is not modified, even when inside the brush sphere.
const dup={verts:[...sphere.verts,...sphere.verts.map(p=>[p[0],p[1],p[2]+.03])],faces:[...sphere.faces,...sphere.faces.map(f=>f.map(i=>i+sphere.verts.length))]};
const result=S.brush(dup,{...opts,tool:'inflate'});ok(result.changed.every(i=>i<sphere.verts.length),'disconnected neighbor untouched');
const obj={id:'test',name:'Sphere',mesh:sphere,color:'#808080',smooth:true,sculptMask:mask};const out=M.readGLB(M.writeGLB({objects:[obj]})).objects[0];assert.deepEqual(out.sculptMask,mask);checks++;ok(out.smooth,'smooth retained');
const source=new URL('../../../upload/base_human_homme_5vues.glb',import.meta.url);
if(fs.existsSync(source)){
 const base=M.readGLB(fs.readFileSync(source)).objects[0].mesh;
 const center=[.11,1.1,.12];let closest=base.verts[0],best=Infinity;for(const p of base.verts){const d=Math.hypot(...p.map((v,k)=>v-center[k]));if(d<best){best=d;closest=p;}}
 let m=base;const start=Date.now();for(let i=0;i<8;i++)m=S.brush(m,{tool:i%2?'polish':'inflate',center:closest,normal:[0,0,1],radius:.06,strength:.25,symmetry:true}).mesh;
 ok(M.topology(m).closed,'real body remains closed');ok(m.faces===base.faces,'real body resolution preserved');ok(M.isSymmetric(m),'real body symmetry retained');console.log('Real body 8 stamps:',Date.now()-start,'ms');
}
console.log(checks,'mesh sculpture checks OK');
