import assert from 'node:assert/strict';
import * as S from '../../app/src/main/assets/meshstudio/sculpt_core.js';
import * as M from '../../app/src/main/assets/meshstudio/mesh_core.js';
let checks=0;
const ok=(test,msg)=>{assert.ok(test,msg);checks++;};
const base=S.createVolume(), mesh=S.extract(base);

ok(S.validVolume(base),'valid volume');
ok(M.signedVolume(mesh)>0,'outward');
ok(M.isSymmetric(mesh),'sphere symmetric');


const center=[0.5,0.2,0.1], opts={center,tool:'inflate',radius:0.3,strength:0.8,symmetry:false};
const added=S.brush(base,opts), carved=S.brush(base,{...opts,tool:'carve'});
ok(added.values.some((v,i)=>v<base.values[i]),'adds matter');
ok(carved.values.some((v,i)=>v>base.values[i]),'removes matter');
ok(M.signedVolume(S.extract(added))>M.signedVolume(mesh),'inflate increases volume');
ok(M.signedVolume(S.extract(carved))<M.signedVolume(mesh),'carve decreases volume');
ok(!M.isSymmetric(S.extract(added)),'asymmetry retained');
const symmetric=S.brush(base,{...opts,symmetry:true});
ok(M.isSymmetric(S.extract(symmetric)),'mirror brush');
const grab=S.brush(base,{...opts,tool:'grab',delta:[0,0.1,0]});
ok(grab.values.some((v,i)=>v!==base.values[i]),'grab changes density');
const smooth=S.brush(added,{...opts,tool:'smooth'}), flat=S.brush(added,{...opts,tool:'flatten',normal:[1,0,0]});
ok(smooth.values.some((v,i)=>v!==added.values[i]),'smooth changes field');
ok(flat.values.some((v,i)=>v!==added.values[i]),'flatten changes field');
for(const v of [base,added,carved,symmetric,grab,smooth,flat]) {
 const m=S.extract(v), t=M.topology(m);
 ok(t.closed,'closed surface');ok(m.verts.flat().every(Number.isFinite),'finite verts');
 // Protected border guarantees volume stays inside its domain.
 ok(v.values.every((a,i)=>{const x=i%33,y=Math.floor(i/33)%33,z=Math.floor(i/1089);return x&&y&&z&&x!==32&&y!==32&&z!==32 || a===base.values[i];}),'boundary intact');
}
const obj={id:'clay',name:'Matière',smooth:true,color:'#B9835C',mesh:S.extract(added),sculpt:added,pos:[0,0.65,0],rot:[0,0,0],scale:[1,1,1]};
const bytes=M.writeGLB({objects:[obj],symmetry:false});
const read=M.readGLB(bytes).objects[0];
assert.deepEqual(read.sculpt,added); checks++;
ok(M.signedVolume(S.extract(S.brush(read.sculpt,{...opts,tool:'carve'})))>0,'reloaded matter editable');
const bad={...base,values:[NaN]};ok(!S.validVolume(bad),'reject bad volume');
assert.throws(()=>S.extract(bad));checks++;
// A groove goes through the sphere: new topology must remain closed.
let cut=base;
for(let k=0;k<48;k++) cut=S.brush(cut,{tool:'carve',center:[0,0,0.5-k%12*0.09],radius:0.2,strength:1,symmetry:true});
ok(M.topology(S.extract(cut)).closed,'deep carving closed');
console.log(`${checks} sculpture checks OK · GLB ${bytes.length} bytes`);

let seed=67, volume=base;
const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};
for(let i=0;i<80;i++) {
 volume=S.brush(volume,{tool:['inflate','carve','grab','smooth','flatten'][i%5],center:[(rnd()-.5)*1.2,(rnd()-.5)*1.2,(rnd()-.5)*1.2],radius:.15+rnd()*.4,strength:rnd(),delta:[.05,.05,-.05],normal:[.3,.2,.5],symmetry:i<40});
 const m=S.extract(volume);ok(M.topology(m).closed,'random stroke closed '+i);
 if(i<40)ok(M.isSymmetric(m),'random stroke symmetric '+i);
}
for(const tool of ['grab','flatten']) {
 const m=S.extract(S.brush(base,{tool,center:[0,0,.6],delta:[.1,0,0],normal:[1,0,1],radius:.4,symmetry:true}));
 ok(M.isSymmetric(m),'mirror on center plane '+tool);
}
console.log(`${checks} total checks including randomized strokes OK`);
