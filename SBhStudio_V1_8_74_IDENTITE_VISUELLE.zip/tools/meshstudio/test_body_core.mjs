// Tests du générateur de corps humain :  node tools/meshstudio/test_body_core.mjs
import * as B from '../../app/src/main/assets/meshstudio/body_core.js';
import * as M from '../../app/src/main/assets/meshstudio/mesh_core.js';
let n = 0, fails = 0;
const ok = (c, m) => { n++; if (!c) { fails++; console.log('ÉCHEC', m); } };
const variants = {
  standard: {}, mince: { height: 1.72, build: 0.85, muscle: 0.6, fat: 0.85 }, colosse: { height: 1.95, build: 1.25, muscle: 1.5, fat: 1.05 },
  corpulent: { height: 1.75, build: 1.05, muscle: 0.8, fat: 1.45 }, petit: { height: 1.4, head: 1.2 }, grossier: { detail: 2.5 },
  femme: { sex: 1, height: 1.67, skin: 2 }, femme_sans_tenue: { sex: 1, outfit: 0, hair: 0 }, mixte: { sex: 0.5, skin: 6 },
  extremes_min: { height: 1.4, build: 0.8, muscle: 0.5, fat: 0.8, head: 0.85 }, extremes_max: { height: 2.2, build: 1.3, muscle: 1.6, fat: 1.5, head: 1.2, detail: 1.6 },
};
const vols = {};
for (const [name, p] of Object.entries(variants)) {
  const t0 = Date.now(), r = B.humanBody(p), dt = Date.now() - t0, t = M.topology(r.mesh), b = M.bounds(r.mesh), bh = M.bounds(r.head);
  vols[name] = M.signedVolume(r.mesh);
  ok(t.closed && t.euler === 2, `${name} : peau fermée d'un seul tenant ${JSON.stringify(t)}`);
  ok(M.isSymmetric(r.mesh), `${name} : symétrique`);
  ok(vols[name] > 0, `${name} : normales sortantes`);
  ok(Math.abs(bh.max[1] - r.params.height) < 0.06 * r.params.height && b.min[1] >= 0 && b.min[1] < 0.01, `${name} : hauteur ${bh.max[1].toFixed(3)} pour ${r.params.height}, pieds au sol ${b.min[1].toFixed(4)}`);
  const ht = M.topology(r.head);
  ok(ht.closed && ht.euler === 2 && M.isSymmetric(r.head), `${name} : tête fermée et symétrique ${JSON.stringify(ht)}`);
  ok(bh.min[1] < b.max[1] - 0.01, `${name} : la tête recouvre le haut du cou`);
  for (const g of r.garments) { const gt = M.topology(g.mesh); ok(gt.closed && M.isSymmetric(g.mesh), `${name} : ${g.name} fermé et symétrique ${JSON.stringify(gt)}`); }
  ok(r.mesh.faces.every((f) => f.length === 4), `${name} : uniquement des quads`);
  console.log(`${name.padEnd(13)} corps ${r.mesh.faces.length} + tête ${r.head.faces.length} faces, ${(vols[name] * 1000).toFixed(0)} L, ${dt} ms, tenue : ${r.garments.map((g) => g.name).join(', ') || '—'}`);
}
ok(vols.colosse > vols.standard && vols.standard > vols.mince, 'volumes : colosse > standard > mince');
ok(vols.corpulent > vols.mince, 'corpulent > mince');
ok(vols.standard > 0.05 && vols.standard < 0.09, 'standard ≈ 50 à 90 L (corps sans la tête, 1,80 m)');
{ const r = B.humanBody({ sex: 1 }); ok(r.garments.some((g) => g.name === 'Brassière') && !r.garments.some((g) => g.name === 'Barbe'), 'femme : brassière, pas de barbe'); }
{ const r = B.humanBody({ sex: 0 }); ok(r.garments.some((g) => g.name === 'Barbe') && r.garments.some((g) => g.name === 'Short'), 'homme : barbe et short'); }
ok(B.SKIN_TONES.length === 6 && B.humanBody({ skin: 6, outfit: 0, hair: 0, beard: 0, detail: 2.5 }).skin === B.SKIN_TONES[5].color, '6 carnations, la 6e = très foncée');
const P = B.bodyParams({ height: 9, build: 'x', muscle: -3 });
ok(P.height === 2.2 && P.build === 1 && P.muscle === 0.5, 'curseurs ramenés dans les bornes');
// export lisse : .glb indexé à normales douces, relu identique
const r = B.humanBody({});
const glb = M.writeGLB({ name: 'c', objects: [{ id: 'c', name: 'Corps', color: '#C8A98A', smooth: true, mesh: r.mesh, pos: [0, 0, 0], rot: [0, 0, 0], scale: [1, 1, 1] }] });
const dv = new DataView(glb.buffer), js = JSON.parse(new TextDecoder().decode(glb.subarray(20, 20 + dv.getUint32(12, true))));
ok(js.meshes[0].primitives[0].indices !== undefined && js.accessors[0].count === r.mesh.verts.length, '.glb lisse : triangles indexés, un sommet par sommet');
const back = M.readGLB(glb).objects[0];
ok(back.smooth === true && back.mesh.faces.length === r.mesh.faces.length, 'relu : lisse et mêmes faces');
const N = B.vertexNormals(r.mesh);
ok(N.every((v) => Math.abs(Math.hypot(...v) - 1) < 1e-6), 'normales unitaires');
console.log(`${n - fails}/${n} vérifications OK`);
process.exit(fails ? 1 : 0);
