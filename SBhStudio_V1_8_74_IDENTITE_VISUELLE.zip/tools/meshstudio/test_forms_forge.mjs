import assert from 'node:assert/strict';
import * as S from '../../app/src/main/assets/meshstudio/sculpt_core.js';
import * as F from '../../app/src/main/assets/meshstudio/forge_core.js';
import * as M from '../../app/src/main/assets/meshstudio/mesh_core.js';
let checks=0;
const ok=(c,msg)=>{assert.ok(c,msg);checks++;};
const connected=m=>{const seen=new Set(),todo=[0],links=Array.from({length:m.verts.length},()=>[]);for(const f of m.faces)for(let i=0;i<f.length;i++){const a=f[i],b=f[(i+1)%f.length];links[a].push(b);links[b].push(a);}while(todo.length){const v=todo.pop();if(seen.has(v))continue;seen.add(v);todo.push(...links[v].filter(x=>!seen.has(x)));}return seen.size===m.verts.length;};
for(const type of Object.keys(S.PRESETS)) {
 const v=S.preset(type),m=S.extract(v);ok(S.validVolume(v),type+' field');ok(M.topology(m).closed,type+' closed');ok(connected(m),type+' fused');ok(M.isSymmetric(m),type+' symmetric');ok(M.signedVolume(m)>0,type+' orientation');
 const edited=S.brush(v,{tool:'carve',center:[0,.3,.4],radius:.3,strength:.8,symmetry:true});ok(M.topology(S.extract(edited)).closed,type+' editable');
}
const base=S.createVolume(),shape={type:'box',center:[0,0,.65],size:[.25,.25,.25]};
const add=S.compose(base,shape),cut=S.compose(base,shape,'cut'),intersection=S.compose(base,shape,'intersect');
ok(M.signedVolume(S.extract(add))>M.signedVolume(S.extract(base)),'union adds material');
ok(M.signedVolume(S.extract(cut))<M.signedVolume(S.extract(base)),'cut removes material');
ok(M.signedVolume(S.extract(intersection))<M.signedVolume(S.extract(base)),'intersection reduces material');
for(const type of ['box','ellipsoid','capsule']) {
 const v=S.compose(base,{...shape,type,center:[.3,.3,.3]},'add',true);
 ok(M.topology(S.extract(v)).closed,type+' closed');ok(M.isSymmetric(S.extract(v)),type+' mirrored');
}
assert.throws(()=>S.compose(base,{...shape,size:[0,1,1]}));checks++;
let seed=69;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};
for(let i=0;i<45;i++) {
 const raw={w:.1+rnd()*2.9,h:.1+rnd()*2.9,thickness:.005+rnd()*.295,bend:rnd()*240-120,hole:i%4===0?0:rnd(),holeX:rnd()*6-3,holeY:rnd()*6-3};
 const {mesh,params}=F.plate(raw);const t=M.topology(mesh);
 ok(t.closed,'plate closed '+i);ok(M.signedVolume(mesh)>0,'plate orientation '+i);ok(t.euler===(params.hole>=.002?0:2),'actual through-hole '+i);
 ok(params.hole+Math.abs(params.holeX)<params.w/2 && params.hole+Math.abs(params.holeY)<params.h/2,'hole contained '+i);
}
const plate=F.plate({hole:.12,bend:80}),obj={id:'plate',name:'Armure',mesh:plate.mesh,forge:{version:1,kind:'plate',params:plate.params},color:'#808080',pos:[0,0,0],rot:[0,0,0],scale:[1,1,1]};
const restored=M.readGLB(M.writeGLB({objects:[obj]})).objects[0];assert.deepEqual(restored.forge,obj.forge);checks++;
ok(M.topology(F.plate(restored.forge.params).mesh).closed,'reloaded plate rebuilds');
for(const params of [{},{length:2,width:1.1,wheelRadius:.5},{length:6,width:2.4,wheelRadius:.2}]) {
 const car=F.car(params);ok(car.objects.length===21,'vehicle has 21 parts');
 for(const o of car.objects){ok(M.topology(o.mesh).closed,o.name+' closed');ok(M.signedVolume(o.mesh)>0,o.name+' orientation');}
 const read=M.readGLB(M.writeGLB({objects:car.objects}));ok(read.objects.length===21,'vehicle GLB parts preserved');
}
console.log(checks+' forms, animals, forge and vehicle checks OK');
