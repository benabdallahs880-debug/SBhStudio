// kotlinc app/src/main/java/com/sbh/studio/mesh/GlbCheck.kt tools/meshstudio/GlbCheckTest.kt -include-runtime -d /tmp/glbcheck.jar
// java -jar /tmp/glbcheck.jar <fichier.glb> …   → vérifie les vrais .glb et des fichiers abîmés
import com.sbh.studio.mesh.GlbCheck
import java.io.File

fun main(args: Array<String>) {
    var bad = 0
    fun ok(name: String, c: Boolean) { println((if (c) "OK    " else "ÉCHEC ") + name); if (!c) bad++ }
    for (path in args) {
        val b = File(path).readBytes()
        ok("$path valide", GlbCheck.problem(b) == null)
        ok("$path JSON lisible", GlbCheck.jsonChunk(b)?.contains("\"version\":\"2.0\"") == true)
        val wrongLen = b.copyOf(); wrongLen[8] = (wrongLen[8] + 1).toByte()
        ok("longueur fausse refusée", GlbCheck.problem(wrongLen) != null)
        ok("tronqué refusé", GlbCheck.problem(b.copyOf(b.size - 4)) != null)
        val v1 = b.copyOf(); v1[4] = 1
        ok("version 1 refusée", GlbCheck.problem(v1)?.contains("version") == true)
        val magic = b.copyOf(); magic[0] = 'X'.code.toByte()
        ok("en-tête faux refusé", GlbCheck.problem(magic) != null)
        val bigJson = b.copyOf(); bigJson[12] = 0xFF.toByte(); bigJson[13] = 0xFF.toByte(); bigJson[14] = 0xFF.toByte()
        ok("bloc JSON trop long refusé", GlbCheck.problem(bigJson) != null)
    }
    ok("fichier vide refusé", GlbCheck.problem(ByteArray(0)) != null)
    ok("texte refusé", GlbCheck.problem("{\"asset\":{}}".toByteArray()) != null)
    println(if (bad == 0) "tout est OK" else "$bad échec(s)")
    if (bad > 0) kotlin.system.exitProcess(1)
}
