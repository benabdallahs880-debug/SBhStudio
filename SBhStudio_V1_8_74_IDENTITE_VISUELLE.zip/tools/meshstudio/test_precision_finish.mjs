import assert from 'node:assert/strict';
import * as T from '../../app/src/main/assets/meshstudio/stroke_core.js';
import * as S from '../../app/src/main/assets/meshstudio/sculpt_core.js';
import * as M from '../../app/src/main/assets/meshstudio/mesh_core.js';
let checks=0;const ok=(b,msg)=>{assert.ok(b,msg);checks++;};
for(const mode of ['free','x','y','z','xy','xz','yz']){
 const p=T.constrain([1,2,3],[4,5,6],mode);
 ok(p.every((v,i)=>v===(mode==='free'||mode.includes('xyz'[i])?[1,2,3][i]:[4,5,6][i])),mode);
}
assert.throws(()=>T.constrain([0,0,0],[0,0,0],'bad'));checks++;
ok(T.stabilize([0,0,0],[.01,0,0],.025)[0]===0,'small tremor stays inside trailing radius');
ok(Math.abs(T.stabilize([0,0,0],[.1,0,0],.025)[0]-.075)<1e-9,'spatial lag');
function line(events){let anchor=[0,0,0],points=[];for(const x of events){let r;do{r=T.samples(anchor,[x,0,0],.04,2);points.push(...r.points);anchor=r.anchor;}while(!r.reached);}return points;}
const coarse=line([.4]),fine=line(Array.from({length:80},(_,i)=>(i+1)*.005));
ok(coarse.length===10&&fine.length===10,'ten spatial stamps at either event rate');
ok(coarse.every((p,i)=>Math.abs(p[0]-fine[i][0])<1e-9),'straight line sampling independent of event count');
const base=S.createVolume(),options={tool:'polish',center:[0,0,0],radius:.6,strength:.8,symmetry:true};
const polished=S.brush(base,options),smooth=S.brush(base,{...options,tool:'smooth'});
ok(S.validVolume(polished),'polish valid field');
ok(M.topology(S.extract(polished)).closed,'polish closed');
ok(M.isSymmetric(S.extract(polished)),'polish symmetry');
const volume=M.signedVolume(S.extract(base)),pDelta=Math.abs(M.signedVolume(S.extract(polished))-volume),sDelta=Math.abs(M.signedVolume(S.extract(smooth))-volume);
ok(pDelta<sDelta,'opposite passes reduce sphere shrink relative to smooth');
ok(polished.values.every((v,i)=>{const x=i%33,y=Math.floor(i/33)%33,z=Math.floor(i/1089);return x&&y&&z&&x!==32&&y!==32&&z!==32||v===base.values[i];}),'protected border');
const hard=S.brush(base,{tool:'inflate',center:[.5,0,0],radius:.3,strength:.5,softness:0}),soft=S.brush(base,{tool:'inflate',center:[.5,0,0],radius:.3,strength:.5,softness:1});
ok(hard.values.some((v,i)=>v<soft.values[i]),'softness changes edge action');
// Alternating perturbations test reduction of a high-frequency field error.
const noisy={...base,values:base.values.map((v,i)=>Math.abs(v)<.1?v+(i%2?.01:-.01):v)};
const clean=S.brush(noisy,{...options,center:[0,0,.55],radius:.3});
const error=v=>v.values.reduce((sum,x,i)=>{const p=[i%33,Math.floor(i/33)%33,Math.floor(i/1089)].map(n=>-1.2+n*.075);return Math.hypot(p[0],p[1],p[2]-.55)<.15?sum+(x-base.values[i])**2:sum;},0);
ok(error(clean)<error(noisy),'polish reduces alternating perturbations');
ok(M.topology(S.extract(clean)).closed,'noisy polished surface closed');
console.log(`${checks} precision / finishing checks OK`);
