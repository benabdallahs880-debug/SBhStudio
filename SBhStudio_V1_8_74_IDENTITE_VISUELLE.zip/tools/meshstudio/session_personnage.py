"""Séance de test « utilisateur » : construire un personnage UNIQUEMENT avec l'interface du Modeleur 3D,
au doigt, sur un téléphone simulé (412×915, densité 2.625, gestes tactiles réels via CDP).

Le script ne modifie JAMAIS le maillage par code : il touche des boutons, remplit des champs, tire des
flèches et fait tourner la vue. Il « regarde » l'écran (lecture seule de la scène) pour savoir où toucher,
comme un utilisateur qui voit les faces et les flèches.

    cd app/src/main/assets && python3 -m http.server 8765
    python3 tools/meshstudio/session_personnage.py <dossier_captures>
"""
import asyncio, base64, json, math, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from test_mesh_studio import BRIDGE, URL, touch, tap, tapel, boxes, ev  # mêmes gestes que les tests

OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/perso")
OUT.mkdir(parents=True, exist_ok=True)
LOG, SHOTS, PROBLEMS = [], [], []
n_shot = 0


def log(msg):
    print(msg); LOG.append(msg)


def problem(msg):
    print("⚠ " + msg); PROBLEMS.append(msg)


async def shot(pg, name, legend):
    global n_shot
    n_shot += 1
    f = OUT / f"{n_shot:02d}_{name}.png"
    await asyncio.sleep(0.25)
    await pg.screenshot(path=str(f))
    SHOTS.append((f.name, legend))


# ---------- « regarder l'écran » (lecture seule) ----------
FACES_JS = """() => { const W = window.__mesh, M = W.M, o = W.S.objects.find((x) => x.id === W.S.active); if (!o) return [];
  const m = W.meshCache.get(o.id), r = new W.THREE.Raycaster(), out = [];
  o.mesh.faces.forEach((f, i) => {
    const n = new W.THREE.Vector3(...M.faceNormal(o.mesh, f)).transformDirection(m.matrixWorld);
    const c = new W.THREE.Vector3(...M.faceCenter(o.mesh, f)).applyMatrix4(m.matrixWorld);
    const s = W.toScreen(c), dir = c.clone().sub(W.camera.position), d = dir.length();
    r.set(W.camera.position.clone(), dir.normalize());
    const h = r.intersectObject(m, false)[0];
    const visible = !!h && W.meshCache.get(o.id).userData.triFace[h.faceIndex] === i && n.dot(W.camera.position.clone().sub(c)) > 0;
    out.push({ i, n: n.toArray(), c: c.toArray(), sx: s.x, sy: s.y, visible });
  });
  return out; }"""
VIEW_RECT = (12, 130, 400, 770)   # zone de la vue 3D entre onglets et barre d'outils (portrait)


def on_screen(f):
    x0, y0, x1, y1 = VIEW_RECT
    return f["visible"] and x0 < f["sx"] < x1 and y0 < f["sy"] < y1


async def find_face(pg, pred, key, cdp, what, orbit_moves=((0, 0), (60, 0), (-120, 0), (0, -70), (0, 140), (90, -40), (-90, 60))):
    """Trouve une face qui répond à pred ; si elle n'est pas visible, fait tourner la vue au doigt."""
    for k, (dx, dy) in enumerate(orbit_moves):
        if dx or dy:
            log(f"   (je fais tourner la vue au doigt pour voir {what} : {dx:+d},{dy:+d} px)")
            await drag(cdp, 60, 700, dx, dy)
        faces = [f for f in await ev(pg, f"({FACES_JS})()") if pred(f)]
        vis = [f for f in faces if on_screen(f)]
        if not vis and faces:
            log("     candidates : " + "; ".join(f"face {f['i']} écran ({f['sx']:.0f},{f['sy']:.0f}) visible={f['visible']}" for f in faces[:4])
                + " ; caméra " + str([round(v, 2) for v in await ev(pg, "window.__mesh.camera.position.toArray()")]))
        if vis:
            return sorted(vis, key=key)[0]
    problem(f"impossible de voir {what} à l'écran malgré la rotation de la vue")
    return None


async def drag(cdp, x, y, dx, dy, steps=14):
    await touch(cdp, "touchStart", [(x, y)])
    for k in range(1, steps + 1):
        await touch(cdp, "touchMove", [(x + dx * k / steps, y + dy * k / steps)]); await asyncio.sleep(0.016)
    await touch(cdp, "touchEnd", []); await asyncio.sleep(0.2)


ARROW_JS = """(k) => { const W = window.__mesh, f = W.gizmoFrame(); if (!f) return null;
  const o = W.toScreen(f.origin), t = W.toScreen(f.origin.clone().addScaledVector(f.dirs[k], f.size * 0.92));
  // direction à l'écran du +axe (monde/objet), quelle que soit la flèche affichée
  const plus = W.toScreen(f.origin.clone().addScaledVector(f.dirs[k].clone().multiplyScalar(f.flip[k]), f.size)).sub(o);
  return { tip: [t.x, t.y], plus: [plus.x, plus.y], len: plus.length() }; }"""
BALL_JS = """() => { const W = window.__mesh, f = W.gizmoFrame(); if (!f) return null; const o = W.toScreen(f.origin); return [o.x, o.y]; }"""


async def pull_arrow(pg, cdp, axis, sign, px, what):
    """Tire la flèche (axis 0=X rouge, 1=Y vert, 2=Z bleu) de px pixels vers +axe (sign=1) ou −axe."""
    await asyncio.sleep(0.35)   # la vue suit la sélection (animation)
    a = await ev(pg, f"({ARROW_JS})({axis})")
    for dy in (60, -120, 180):
        if not a or a["len"] >= 40: break
        log(f"   (la flèche est vue de face, trop courte : je tourne la vue de {dy:+d} px pour mieux la voir)")
        await drag(cdp, 60, 700, 0, dy); a = await ev(pg, f"({ARROW_JS})({axis})")
    if not a:
        problem(f"pas de flèche visible pour {what}"); return
    ux, uy = a["plus"][0] / a["len"], a["plus"][1] / a["len"]
    x, y = a["tip"]
    log(f"   flèche {'XYZ'[axis]} : bout à ({x:.0f},{y:.0f}), longueur {a['len']:.0f} px, je tire de {px*sign:+d} px")
    if not (0 <= x <= 412 and 120 <= y <= 780):
        problem(f"la flèche pour {what} est hors de l'écran ({x:.0f},{y:.0f})")
    before = await ev(pg, "(() => { const W = window.__mesh, o = W.S.objects.find((x) => x.id === W.S.active); return [...W.S.selF].map((i) => W.M.faceCenter(o.mesh, o.mesh.faces[i])); })()")
    hit = await ev(pg, f"(() => {{ const W = window.__mesh; const r = W.gizmoFrame(); return r ? 'ok' : 'none'; }})()")
    await drag(cdp, x, y, ux * px * sign, uy * px * sign)
    after = await ev(pg, "(() => { const W = window.__mesh, o = W.S.objects.find((x) => x.id === W.S.active); return [...W.S.selF].map((i) => W.M.faceCenter(o.mesh, o.mesh.faces[i])); })()")
    log(f"   centre de la sélection : {[[round(v,3) for v in c] for c in before]} → {[[round(v,3) for v in c] for c in after]}")


async def active_info(pg):
    return await ev(pg, """(() => { const W = window.__mesh, o = W.S.objects.find((x) => x.id === W.S.active); if (!o) return null;
      const t = W.M.topology(o.mesh), b = W.M.bounds(o.mesh);
      return { name: o.name, V: o.mesh.verts.length, F: o.mesh.faces.length, closed: t.closed, sym: W.M.isSymmetric(o.mesh), min: b.min, max: b.max, pos: o.pos }; })()""")


async def fill(pg, sel, value):
    await pg.evaluate("(s) => document.querySelector(s).scrollIntoView({block: 'nearest'})", sel)
    await pg.fill(sel, str(value)); await pg.dispatch_event(sel, "change"); await asyncio.sleep(0.15)


async def extrude_and_pull(pg, cdp, axis, sign, px, what):
    await tapel(pg, cdp, "#btnExtrude")
    i1 = await active_info(pg)
    await pull_arrow(pg, cdp, axis, sign, px, what)
    i2 = await active_info(pg)
    moved = any(abs(a - b) > 1e-4 for a, b in zip(i1["min"] + i1["max"], i2["min"] + i2["max"]))
    if not moved:
        problem(f"tirer la flèche n'a rien changé ({what})")
    if not (i2["closed"] and i2["sym"]):
        problem(f"après {what} : maillage ouvert ou plus symétrique {i2}")
    log(f"   {what} : {i2['V']} sommets, {i2['F']} faces, fermé={i2['closed']}, symétrique={i2['sym']}")


async def main():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch(args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
        ctx = await b.new_context(viewport={"width": 412, "height": 915}, device_scale_factor=2.625, has_touch=True, is_mobile=True)
        await ctx.add_init_script(BRIDGE)
        await ctx.add_init_script("window.__start = { id: 'perso_test', name: 'Nouveau personnage', glb: null };")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        cdp = await ctx.new_cdp_session(pg)

        log("1. J'ouvre le Modeleur 3D (nouveau maillage).")
        await pg.goto(URL); await pg.wait_for_function("window.__meshReady === true", timeout=20000); await asyncio.sleep(0.8)
        await shot(pg, "ouverture", "Ouverture : un cube de départ « Corps »")

        log("2. ＋ Ajouter → Cube, 0,7 × 0,9 × 0,4, 3 segments (pour avoir des faces où accrocher bras et jambes).")
        await tapel(pg, cdp, "#btnAdd")
        await tapel(pg, cdp, "[data-prim=cube]")
        for k, v in (("w", 0.7), ("h", 0.9), ("d", 0.4), ("segments", 3)):
            await fill(pg, f"[data-param={k}]", v)
        await shot(pg, "ajouter_cube", "Panneau ＋ Ajouter : cube 0,7 × 0,9 × 0,4, 3 segments")
        await tapel(pg, cdp, "#addGo")
        await asyncio.sleep(0.3)
        info = await active_info(pg)
        log(f"   nouvel objet : {info['name']} {info['V']} sommets {info['F']} faces")
        if info["F"] != 54: problem(f"le cube 3 segments devrait avoir 54 faces, il en a {info['F']}")

        log("3. ☰ Objets : je supprime le cube de départ, je renomme le nouveau « Torse », couleur bleu nuit, nom du maillage.")
        await tapel(pg, cdp, "#btnObjects")
        dels = await boxes(pg, "[data-del]")
        await tapel(pg, cdp, "[data-del]", 0); await tapel(pg, cdp, "[data-del]", 0)
        n = await ev(pg, "window.__mesh.S.objects.length")
        if n != 1: problem(f"suppression du cube de départ : {n} objet(s) restant(s)")
        await tapel(pg, cdp, ".objrow", 0)
        await fill(pg, "#objName", "Torse")
        await tapel(pg, cdp, "[data-col='#2E3A59']")
        await fill(pg, "#sceneName", "Gardien Hibou")
        await shot(pg, "objets_torse", "☰ Objets : « Torse » renommé, couleur choisie, maillage « Gardien Hibou »")
        await tapel(pg, cdp, "#sheetClose")
        log("   🔢 Valeurs : je recentre le torse (position X = 0), le plan de symétrie passe au milieu du personnage.")
        await tapel(pg, cdp, "#btnValues"); await fill(pg, "#vp0", 0); await tapel(pg, cdp, "#sheetClose")
        await tapel(pg, cdp, "#btnFrame")
        await shot(pg, "torse", "Le torse recentré (X = 0) et cadré (⌖)")

        log("4. Bras : mode Face, je touche la face du haut sur le côté droit, ⇧ Extruder ×3 (épaule, avant-bras, main).")
        await tapel(pg, cdp, "#modes [data-mode=face]")
        f = await find_face(pg, lambda f: f["n"][0] > 0.95, key=lambda f: (-round(f["c"][1], 3), abs(f["c"][2])), cdp=cdp, what="le haut du flanc droit")
        if f:
            await tap(cdp, f["sx"], f["sy"])
            sel = await ev(pg, "[...window.__mesh.S.selF]")
            log(f"   face touchée : {sel} (attendu {f['i']})")
            if sel != [f["i"]]: problem("le toucher n'a pas choisi la face visée")
            await shot(pg, "bras_face", "Mode Face : face du haut du flanc droit choisie ; le reflet gauche est montré plus clair (symétrie)")
            await extrude_and_pull(pg, cdp, 0, +1, 22, "bras (épaule)")
            await shot(pg, "bras_1", "⇧ Extruder puis flèche rouge tirée : le bras sort, à droite ET à gauche")
            await extrude_and_pull(pg, cdp, 0, +1, 30, "avant-bras")
            await tapel(pg, cdp, "#btnExtrude")
            await pull_arrow(pg, cdp, 0, +1, 8, "main")
            log("   main : outil ⤡ Échelle, je tire la boule blanche pour la rétrécir")
            await tapel(pg, cdp, "[data-tool=scale]")
            await asyncio.sleep(0.35)
            ball = await ev(pg, f"({BALL_JS})()")
            hs = await ev(pg, "(() => { const W = window.__mesh, f = W.gizmoFrame(); return [0,1,2].map((k) => { const s = W.toScreen(f.origin.clone().addScaledVector(f.dirs[k], f.size*0.92)); return [Math.round(s.x), Math.round(s.y)]; }); })()")
            log(f"   boule au centre ({ball[0]:.0f},{ball[1]:.0f}) ; bouts des flèches {hs}")
            i1 = await active_info(pg)
            vb = await ev(pg, "JSON.stringify(window.__mesh.S.objects.find((x) => x.id === window.__mesh.S.active).mesh.verts)")
            dbg0 = await ev(pg, "[window.__mesh.S.tool, window.__mesh.S.mode, [...window.__mesh.S.selF]]")
            await drag(cdp, ball[0], ball[1], -40, 40)
            va = await ev(pg, "JSON.stringify(window.__mesh.S.objects.find((x) => x.id === window.__mesh.S.active).mesh.verts)")
            log(f"   état {dbg0} ; sommets changés : {vb != va}")
            i2 = await active_info(pg)
            if vb == va: problem("la boule d'échelle n'a rien changé (main)")
            else: log("   main rétrécie (les sommets de la main ont bougé, des deux côtés)")
            await tapel(pg, cdp, "[data-tool=move]")
            await tapel(pg, cdp, "#btnFrame")
            await shot(pg, "bras_finis", "Bras finis : épaule, avant-bras, main rétrécie (boule ⤡)")

        log("5. Jambes : je fais tourner la vue pour voir le dessous, je touche la face du dessous à droite, ⇧ Extruder ×2.")
        await tapel(pg, cdp, "[data-mode=object]"); await tapel(pg, cdp, "[data-mode=face]")
        await tapel(pg, cdp, "#btnFrame")   # la vue avait suivi la main : je recadre le torse
        f = await find_face(pg, lambda f: f["n"][1] < -0.95 and 0.1 < f["c"][0] < 0.34,
                            key=lambda f: (round(f["c"][1], 3), abs(f["c"][2])), cdp=cdp, what="le dessous du torse (côté droit)",
                            orbit_moves=((0, 0), (0, -110), (0, -80), (40, 0), (-80, 0), (0, -60)))
        if f:
            await tap(cdp, f["sx"], f["sy"])
            await shot(pg, "jambe_face", "Vue d'en dessous : face du bas à droite choisie")
            await extrude_and_pull(pg, cdp, 1, -1, 30, "cuisse")
            await extrude_and_pull(pg, cdp, 1, -1, 35, "jambe")
            await tapel(pg, cdp, "#btnFrame")
            await shot(pg, "jambes", "Jambes extrudées vers le bas (les deux, grâce à la symétrie)")

        log("6. Je pose le torse sur le sol avec 🔢 Valeurs (position Y).")
        await tapel(pg, cdp, "[data-mode=object]")
        info = await active_info(pg)
        await tapel(pg, cdp, "#btnValues")
        y = round(-info["min"][1], 3)
        await fill(pg, "#vp1", y)
        info2 = await active_info(pg)
        log(f"   position Y = {y} ; pieds à y = {info2['pos'][1] + info2['min'][1]:.3f}")
        await shot(pg, "valeurs_torse", f"🔢 Valeurs : position Y = {y} pour poser les pieds au sol")
        await tapel(pg, cdp, "#sheetClose")
        top = info2["pos"][1] + info2["max"][1]

        log("7. Tête : ＋ Ajouter → Sphère r 0,22, puis Valeurs : posée sur le torse, au centre ; renommée, couleur peau.")
        await tapel(pg, cdp, "#btnAdd"); await tapel(pg, cdp, "[data-prim=sphere]")
        await fill(pg, "[data-param=radius]", 0.22); await fill(pg, "[data-param=segments]", 16); await fill(pg, "[data-param=rings]", 10)
        await tapel(pg, cdp, "#addGo")
        await tapel(pg, cdp, "#btnValues")
        await fill(pg, "#vp0", 0); await fill(pg, "#vp1", round(top + 0.2, 3)); await fill(pg, "#vp2", 0)
        await tapel(pg, cdp, "#sheetClose")
        await tapel(pg, cdp, "#btnObjects")
        await fill(pg, "#objName", "Tête"); await tapel(pg, cdp, "[data-col='#E8D8B0']")
        await tapel(pg, cdp, "#sheetClose")
        await tapel(pg, cdp, "#btnFrame")
        await shot(pg, "tete", "Tête ajoutée (sphère), placée au centre sur le torse avec 🔢 Valeurs")

        log("8. Nez : mode Sommet sur la tête, je touche le sommet le plus en avant au centre et je tire la flèche bleue vers l'avant.")
        await tapel(pg, cdp, "[data-mode=vertex]")
        verts = await ev(pg, """(() => { const W = window.__mesh, o = W.S.objects.find((x) => x.id === W.S.active), m = W.meshCache.get(o.id);
           return o.mesh.verts.map((p, i) => { const w = new W.THREE.Vector3(...p).applyMatrix4(m.matrixWorld), s = W.toScreen(w); return { i, p, sx: s.x, sy: s.y }; }); })()""")
        front = [v for v in verts if abs(v["p"][0]) < 1e-6 and v["p"][2] > 0.15 and abs(v["p"][1]) < 0.08]
        if not front:
            problem("pas de sommet au centre-avant de la tête")
        else:
            v = sorted(front, key=lambda v: -v["p"][2])[0]
            await tap(cdp, v["sx"], v["sy"])
            selv = await ev(pg, "[...window.__mesh.S.selV]")
            if selv != [v["i"]]: problem(f"toucher le sommet du nez a choisi {selv} au lieu de {v['i']}")
            z0 = await ev(pg, f"window.__mesh.S.objects.find((x) => x.id === window.__mesh.S.active).mesh.verts[{v['i']}][2]")
            await pull_arrow(pg, cdp, 2, +1, 45, "nez")
            z1 = await ev(pg, f"window.__mesh.S.objects.find((x) => x.id === window.__mesh.S.active).mesh.verts[{v['i']}][2]")
            x1 = await ev(pg, f"window.__mesh.S.objects.find((x) => x.id === window.__mesh.S.active).mesh.verts[{v['i']}][0]")
            log(f"   nez : z {z0:.3f} → {z1:.3f}, x reste {x1}")
            if z1 <= z0 + 0.01: problem("le nez n'est pas sorti")
            if x1 != 0: problem("le sommet du plan de symétrie a quitté x = 0")
            await shot(pg, "nez", "Mode Sommet : le sommet du nez tiré vers l'avant (flèche bleue)")
            log("9. ↶ Annuler puis ↷ Rétablir le nez.")
            await tapel(pg, cdp, "#btnUndo")
            zu = await ev(pg, f"window.__mesh.S.objects.find((x) => x.id === window.__mesh.S.active).mesh.verts[{v['i']}][2]")
            await tapel(pg, cdp, "#btnRedo")
            zr = await ev(pg, f"window.__mesh.S.objects.find((x) => x.id === window.__mesh.S.active).mesh.verts[{v['i']}][2]")
            log(f"   annuler → z {zu:.3f} ; rétablir → z {zr:.3f}")
            if abs(zu - z0) > 1e-6 or abs(zr - z1) > 1e-6: problem("annuler / rétablir du nez incorrect")

        log("10. Vue d'ensemble : mode Objet, je touche le vide (rien de choisi), ⌖, je tourne autour du personnage.")
        await tapel(pg, cdp, "[data-mode=object]")
        await tap(cdp, 30, 200)
        await tapel(pg, cdp, "#btnFrame")
        await shot(pg, "final_face", "Personnage fini, vue de trois quarts")
        await drag(cdp, 40, 700, 150, 0)
        await shot(pg, "final_cote", "Un doigt : je tourne autour du personnage")
        await drag(cdp, 40, 700, 160, 0)
        await shot(pg, "final_dos", "Vue de dos")

        log("11. Retour Android : enregistrement.")
        r = await ev(pg, "window.sbhMeshBack()")
        last = await ev(pg, "window.__calls.save[window.__calls.save.length - 1]")
        meta = json.loads(last[2]); glb = base64.b64decode(last[3])
        (OUT / "gardien_hibou.glb").write_bytes(glb)
        log(f"   retour → '{r}', enregistrements : {await ev(pg, 'window.__calls.save.length')}, dernier .glb {len(glb)} octets, méta {meta}")
        if errs: problem("erreurs JavaScript : " + " | ".join(errs[:5]))

        log("12. Réouverture du fichier enregistré.")
        pg2 = await ctx.new_page(); errs2 = []
        pg2.on("pageerror", lambda e: errs2.append(str(e)))
        await pg2.add_init_script(f"window.__start = {{ id: 'perso_test', name: 'x', glb: '{last[3]}' }};")
        await pg2.goto(URL); await pg2.wait_for_function("window.__meshReady === true", timeout=20000); await asyncio.sleep(0.6)
        names = await pg2.evaluate("window.__mesh.S.objects.map((o) => o.name + ':' + o.mesh.faces.length)")
        log(f"   rouvert : {await pg2.evaluate('window.__mesh.S.name')} {names}")
        await shot(pg2, "reouverture", "Réouverture du fichier enregistré : tout est revenu")
        await pg2.set_viewport_size({"width": 915, "height": 412}); await asyncio.sleep(0.5)
        await pg2.evaluate("document.getElementById('btnFrame').click()")
        await shot(pg2, "paysage", "Téléphone en paysage")
        if errs2: problem("erreurs JavaScript à la réouverture : " + " | ".join(errs2[:5]))
        await b.close()

    (OUT / "journal.json").write_text(json.dumps({"log": LOG, "shots": SHOTS, "problems": PROBLEMS}, ensure_ascii=False, indent=1))
    print(f"\n{len(PROBLEMS)} problème(s)")


asyncio.run(main())
