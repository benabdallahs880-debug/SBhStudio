/* ==SBHHOST== Intégration SBh Studio (V1.8.62) — corps 3D d'un monstre de l'Atelier.
   Inséré par tools/creature_host/build_creature_asset.py juste avant « ==ENDHOSTAPI== » de
   l'éditeur CreatureStudio : ce code voit donc P, refresh, hostApi, buildBedrockPack, brPng, b64,
   SOLDIER, HIBOU… Il ne fait RIEN hors de l'app (window.SBhCreature absent : page normale).

   Pont Android attendu (window.SBhCreature, méthodes synchrones) :
     start()                          → JSON {name, project|null, example|null, stats|null, bodyKey,
                                              preview|null = {anim, speed, amplitude, weight, loop}}
     save(projectJson, bodyJson, png) → true/false (corps + aperçu enregistrés)
     close()                          → l'app ferme l'éditeur
     toast(texte)
*/
if (window.SBhCreature) (() => {
  const H = window.SBhCreature;
  document.documentElement.setAttribute('data-theme', 'dark');
  let st = {};
  try { st = JSON.parse(H.start() || '{}') || {}; } catch (e) { st = {}; }
  if (st.readOnly) {
    mode = 0;
    const style = document.createElement('style');
    style.textContent = 'body>.bar,body>.box,#tree,#msg,#hint{display:none!important}#cv{height:88vh!important}';
    document.head.appendChild(style);
  }
  const bodyKey = brSlug(st.bodyKey || 'sbh_corps');
  const clone = o => JSON.parse(typeof o === 'string' ? o : JSON.stringify(o));
  /* La fiche de l'Atelier fait foi à l'ouverture : vie, dégâts, vitesse, détection. */
  const withStats = d => {
    if (!st.stats || typeof st.stats !== 'object') return d;
    if (!d.behaviors || typeof d.behaviors !== 'object') d.behaviors = { enabled: false, stats: {}, graphs: [] };
    const s = Object.assign({}, d.behaviors.stats || {});
    for (const [k, v] of Object.entries(st.stats)) {
      const r = STAT_RANGES[k];
      if (r && typeof v === 'number' && isFinite(v)) s[k] = Math.min(r[1], Math.max(r[0], v));
    }
    d.behaviors.stats = s;
    return d;
  };
  const example = k => (k === 'soldat' ? SOLDIER : (HIBOU[k] || null));

  /* ---------- ouverture : corps enregistré, sinon modèle de départ, sinon corps vide ---------- */
  let opened = { ok: false }, how = '';
  if (st.project) {
    try { opened = hostApi.loadProject(withStats(clone(st.project))); how = 'enregistré'; }
    catch (e) { opened = { ok: false, error: e.message }; }
    if (!opened.ok) H.toast('Corps enregistré illisible (' + (opened.error || '?') + ') : un nouveau corps est créé');
  }
  if (!opened.ok && st.example && example(st.example)) {
    const d = clone(example(st.example));
    if (st.name) d.creature.name = String(st.name).slice(0, 60);
    opened = hostApi.loadProject(withStats(d)); how = 'modèle';
  }
  if (!opened.ok) {
    hostApi.newProject(st.name || 'Créature');
    opened = hostApi.loadProject(withStats(hostApi.getProject())); how = 'nouveau';
  }

  /* ---------- corps Minecraft : géométrie, animations, texture (identifiants propres au monstre) ---------- */
  function bodyBundle() {
    const d = clone(P.d);
    d.creature.name = bodyKey;                   // identifiants uniques et stables : sbhc / <bodyKey>
    const r = buildBedrockPack(d, 'sbhc'), f = r.files, c = r.cname, rp = c + '_RP';
    const client = f[`${rp}/entity/${c}.entity.json`].json['minecraft:client_entity'].description;
    const pngKey = Object.keys(f).find(k => f[k].png);
    const beh = f[`${c}_BP/entities/${c}.json`].json['minecraft:entity'].components;
    const files = {};
    for (const k of Object.keys(f)) {
      if (!k.startsWith(rp + '/') || !f[k].json) continue;
      const rel = k.slice(rp.length + 1);
      if (/^(models\/entity|animations|animation_controllers)\//.test(rel)) files[rel] = JSON.stringify(f[k].json);
    }
    return {
      format: 'sbh-creature-body', version: 1, bodyKey: c,
      geometryId: r.report.geometry, bones: r.report.bones,
      client: { geometry: client.geometry.default, animations: client.animations || {},
                animate: (client.scripts && client.scripts.animate) || [] },
      files,
      texture: { width: f[pngKey].png.W, height: f[pngKey].png.H, base64: b64(brPng(f[pngKey].png)) },
      collision: beh['minecraft:collision_box'] || null,
      stats: Object.assign({}, DEFAULT_STATS, (P.d.behaviors && P.d.behaviors.stats) || {}),
      name: P.d.creature.name,
      // les avertissements du comportement CreatureStudio ne concernent pas SBh (la fiche du
      // monstre écrit le comportement) : on ne garde que ceux du modèle, de la texture et des sons
      warnings: (r.report.warnings || []).filter(w => !/^(armure|hauteur de saut|règle )/.test(w))
    };
  }
  function preview() {
    try {
      const s = 160, c = document.createElement('canvas'); c.width = s; c.height = s;
      const g = c.getContext('2d'), w = cv.width, h = cv.height, m = Math.min(w, h);
      g.fillStyle = '#17171c'; g.fillRect(0, 0, s, s);
      if (m > 0) g.drawImage(cv, (w - m) / 2, (h - m) / 2, m, m, 0, 0, s, s);
      return c.toDataURL('image/png');
    } catch (e) { return ''; }
  }

  /* ---------- enregistrement automatique (toute modification, y compris annuler/rétablir) ---------- */
  let timer = 0, pending = false, lastError = '';
  const bar = document.createElement('div');
  bar.id = 'sbhBar';
  bar.style.cssText = 'position:sticky;top:0;z-index:20;display:flex;gap:8px;align-items:center;padding:6px 8px;background:#1A1612;border-bottom:1px solid #5A5348;color:#D8CBB0;font:13px system-ui';
  bar.innerHTML = '<button id="sbhBack" style="background:#C9A227;color:#1A1612;border:0;font-weight:600">← Atelier</button>' +
    '<b id="sbhName" style="flex:1;color:#E8C84A;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></b><span id="sbhState" style="opacity:.8"></span>';
  document.body.insertBefore(bar, document.body.firstChild);
  const setState = t => { const e = document.getElementById('sbhState'); if (e) e.textContent = t; };
  const setName = () => { const e = document.getElementById('sbhName'); if (e) e.textContent = '🧬 ' + (st.name || P.d.creature.name); };
  setName();

  function saveNow() {
    if (st.readOnly) { setState('Aperçu · aucune sauvegarde'); return true; }
    clearTimeout(timer); timer = 0;
    let body = null;
    try { body = bodyBundle(); lastError = ''; }
    catch (e) { lastError = e.message || String(e); }
    let ok = false;
    try { ok = !!H.save(JSON.stringify(P.d), body ? JSON.stringify(body) : '', preview()); } catch (e) { ok = false; }
    pending = !ok;
    setState(ok ? (body ? '✓ Enregistré' : '⚠ Enregistré, export Minecraft impossible : ' + lastError) : '⚠ Non enregistré');
    return ok;
  }
  const scheduleSave = () => { pending = true; setState('…'); clearTimeout(timer); timer = setTimeout(saveNow, 900); };
  hostApi.onChange(scheduleSave);

  /* Retour (bouton ou touche Android) : enregistre puis ferme. */
  window.sbhCreatureBack = () => {
    const io = document.getElementById('io');
    if (io && io.style.display === 'block') { io.style.display = 'none'; return 'handled'; }
    saveNow();
    return 'close';
  };
  document.getElementById('sbhBack').onclick = () => { if (window.sbhCreatureBack() === 'close') H.close(); };
  addEventListener('pagehide', () => { if (pending) saveNow(); });

  /* Dans l'app : pas de téléchargement (le .mcaddon du projet contient le corps) ; remplacer le
     corps par un modèle demande une 2e touche (avant : travail remplacé d'un seul toucher). */
  for (const id of ['bx', 'dl']) { const b = document.getElementById(id); if (b) b.style.display = 'none'; }
  const sl = document.getElementById('sl');
  if (sl) {
    const orig = sl.onclick; let armed = 0;
    sl.onclick = e => {
      if (Date.now() - armed > 3000) { armed = Date.now(); msg('Remplacer ce corps par le « Soldat standard » ? Touche encore 🎖 pour confirmer.'); return; }
      armed = 0; orig(e);
    };
  }
  const hb = document.getElementById('hb');
  if (hb) {
    const orig = hb.onchange; let armed = 0, lastHb = '';
    hb.onchange = e => {
      const k = e.target.value; if (!k) return;
      if (Date.now() - armed > 3000 || lastHb !== k) {
        armed = Date.now(); lastHb = k; e.target.value = '';
        msg('Remplacer ce corps par « ' + (HIBOU[k] ? HIBOU[k].creature.name : k) + ' » ? Choisis-le encore pour confirmer.');
        return;
      }
      armed = 0; lastHb = ''; orig(e);
    };
  }

  /* V1.8.63 — aperçu de l'âme (Studio Animation) sur le vrai corps : l'animation de l'état choisi
     joue en boucle avec la vitesse, l'amplitude et le poids réglés (affichage seulement : le projet
     n'est pas modifié, l'âme est appliquée aux animations à l'export du .mcaddon). */
  let previewOn = false;
  const pv = st.preview;
  if (pv && pv.anim) {
    const A = P.d.animations.find(a => brSlug(a.name) === pv.anim);
    if (!A) msg('Ce corps n\'a pas d\'animation « ' + pv.anim + ' » : crée-la dans la timeline (▼ Animation).');
    else {
      const clamp = (v, lo, hi, d) => { v = +v; return isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; };
      const sp = clamp(pv.speed, .25, 2.5, 1), am = clamp(pv.amplitude, .25, 2, 1), wt = clamp(pv.weight, .4, 1.6, 1);
      const origSample = samplePose, origAdvance = advance;
      samplePose = (an, t) => {
        const r = origSample(an, t);
        if (!previewOn || !an || an.id !== A.id) return r;
        const o = {};
        for (const b in r) {
          o[b] = {};
          if (r[b].rotation) o[b].rotation = r[b].rotation.map(v => v * am);
          if (r[b].position) o[b].position = r[b].position.map(v => v * am * wt);
        }
        return o;
      };
      advance = dt => {
        origAdvance(dt * (previewOn ? sp : 1));
        if (previewOn && !playing && animId === A.id) { tNow = 0; playing = true; lastTs = 0; }   // l'aperçu tourne en boucle
      };
      const pbar = document.createElement('div');
      pbar.style.cssText = 'display:flex;gap:8px;align-items:center;padding:6px 8px;background:#2B2620;color:#E8C84A;font:13px system-ui';
      pbar.innerHTML = '<span style="flex:1">▶ Âme : « ' + A.name + ' » · vitesse ×' + sp.toFixed(2) + ' · amplitude ×' + am.toFixed(2) +
        (wt !== 1 ? ' · poids ×' + wt.toFixed(2) : '') + '</span><button id="sbhPvStop">⏹ Arrêter</button>';
      bar.after(pbar);
      document.getElementById('sbhPvStop').onclick = () => { previewOn = false; playing = false; pbar.remove(); applyPose(origSample(A, 0)); refresh(); };
      previewOn = true; animId = A.id; tNow = 0; playing = true; lastTs = 0;
      refresh(); requestAnimationFrame(tick);
    }
  }

  /* Premier enregistrement : un corps neuf (modèle ou vide) existe tout de suite pour l'Atelier. */
  setState(how === 'enregistré' ? '✓ Ouvert' : '…');
  if (how !== 'enregistré') setTimeout(saveNow, 50);
  window.__sbhCreature = { bodyBundle, saveNow, get how() { return how; }, get previewOn() { return previewOn; } };
})();
