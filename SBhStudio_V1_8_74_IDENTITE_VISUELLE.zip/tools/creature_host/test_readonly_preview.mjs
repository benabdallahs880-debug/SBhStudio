import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const base = new URL('../../', import.meta.url);
const html = fs.readFileSync(new URL('app/src/main/assets/creature/creature_editor.html', base), 'utf8');
const glue = fs.readFileSync(new URL('tools/creature_host/sbh_host_glue.js', base), 'utf8');
const soldier = JSON.parse(html.match(/^const SOLDIER=(.+);$/m)[1]);
const hibou = JSON.parse(html.match(/^const HIBOU=(.+);$/m)[1]);
for (const example of ['soldat', 'chef', 'hippo1', 'hippo2', 'hippo3', '']) {
  const elements = new Map(), timers = [], writes = [], styles = [], listeners = {};
  const element = id => {
    if (!elements.has(id)) elements.set(id, {style: {}, textContent: '', onclick() {}, onchange() {}, after() {}, remove() {}});
    return elements.get(id);
  };
  const P = {d: {creature: {name: 'Vide'}, animations: []}};
  let change;
  const H = {
    start: () => JSON.stringify({readOnly: true, example, name: 'Aperçu', bodyKey: 'sbh_preview'}),
    save: (...args) => {writes.push(args); return true;}, toast() {}, close() {}
  };
  const context = {
    window: {SBhCreature: H}, document: {
      documentElement: {setAttribute() {}}, head: {appendChild: e => styles.push(e)},
      createElement: () => ({style: {}, innerHTML: '', textContent: ''}), getElementById: element,
      body: {firstChild: null, insertBefore() {}}
    }, mode: 3, P, SOLDIER: soldier, HIBOU: hibou, STAT_RANGES: {},
    hostApi: {
      loadProject(d) {P.d = d; return {ok: true};},
      newProject(name) {P.d = {creature: {name}, animations: []};},
      getProject() {return P.d;}, onChange(fn) {change = fn;}
    }, brSlug: s => s, refresh() {}, msg() {},
    setTimeout(fn) {timers.push(fn); return timers.length;}, clearTimeout() {},
    addEventListener(type, fn) {listeners[type] = fn;}, Date, console
  };
  vm.createContext(context);
  vm.runInContext(glue, context);
  timers.splice(0).forEach(fn => fn());
  change(); timers.splice(0).forEach(fn => fn());
  assert.equal(context.window.__sbhCreature.saveNow(), true);
  assert.equal(context.window.sbhCreatureBack(), 'close');
  listeners.pagehide();
  assert.equal(writes.length, 0, example + ': preview must never write');
  assert.equal(context.mode, 0);
  assert.equal(styles.length, 1);
  assert.match(styles[0].textContent, /display:none/);
  if (example) assert.ok(P.d.parts.length > 0);
  assert.equal(context.window.__sbhCreature.how, example ? 'modèle' : 'nouveau');
}
assert.ok(html.includes(glue.trim()), 'Generated asset must contain the current integration source');
console.log('PASS: six template previews; initial save, change, manual save, back and pagehide never write.');
