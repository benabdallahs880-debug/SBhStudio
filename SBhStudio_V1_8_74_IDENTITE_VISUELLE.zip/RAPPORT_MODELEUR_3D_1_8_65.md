# V1.8.65 : Modeleur 3D, Atelier de personnages phase 1 (livraison A)

Ce dossier se lit sans l'historique de la conversation.

## Le contexte

- **Le projet** : SBh Studio (app Android, Kotlin / Compose), compagnon du jeu Godot « SBH World ». But : « le Studio doit être la salle de contrôle de SBH World ».
- **Déjà livré** :
  - V1.8.64 : le format commun Studio ⇄ jeu, SBH Data Contract v1 (voir `RAPPORT_CONTRAT_SBH_1_8_64.md`).
  - Puis le plan « Character Creation Workshop » de l'utilisateur : 15 outils, 6 phases. L'utilisateur a choisi de faire l'atelier de personnages **avant** le labo de test, avec le modeleur construit **à côté** de CreatureStudio, dans la zone Créatures.
- **Phase 1** = un modeleur de maillages 3D sur téléphone, en deux livraisons :
  - **A** = ce travail ;
  - **B** = la suite (§ 4).

---

## 1. Ce qui a été fait

### 1.1 Le Modeleur 3D (page tactile, d'abord pour téléphone en portrait)
On l'ouvre par **Atelier → Créatures → « 🧊 Modeleur 3D (nouveau maillage) »**, ou par « 🧊 Modeler » sur une carte de maillage.

| Fonction | Détail |
|---|---|
| **Primitives paramétrables** | Cube (L × H × P, segments), sphère (rayon, segments, anneaux), cylindre, cône, plan, capsule, tore. Panneau « ＋ Ajouter ». Une nouvelle forme se pose sur le sol, **à droite** de ce qui existe, jamais cachée dedans. |
| **Objets multiples** | Panneau « ☰ Objets » : choisir, renommer, dupliquer, supprimer (2 touches), couleur (14 teintes), nom du maillage. Il reste toujours au moins un objet. |
| **Modes** | Onglets **Objet / Sommet / Face**, toujours visibles en haut. On choisit en touchant l'élément. « ⊕ Multiple » ajoute ou retire à la sélection, « ⬚ Tout » prend tout ou rien. |
| **Déplacer / Tourner / Échelle** | Grandes flèches à tirer au doigt, de taille fixe à l'écran. Une flèche qui sortirait de l'écran passe de l'autre côté. Elle n'est jamais réduite sous ~72 px. En mode Échelle, la boule blanche étire uniformément. |
| **Valeurs exactes** | Panneau « 🔢 Valeurs ». En mode Objet : position, rotation (°), échelle. En modes Sommet et Face : centre de la sélection, tourner de N° sur X, Y ou Z, échelle ×, distance d'extrusion. |
| **Extruder** | Mode Face, « ⇧ Extruder ». Les faces voisines sont extrudées d'un bloc le long de leur normale moyenne. Les faces extrudées restent choisies et l'outil passe en Déplacer pour ajuster en tirant. |
| **Symétrie X en direct** | « ⇋ Sym X », active par défaut. On ne touche qu'un côté ; le reflet suit exactement, montré plus clair. Les points du plan X = 0 y restent. |
| **Annuler / Rétablir** | Sans limite de nombre d'étapes. Seule la mémoire borne (80 Mo de copies, les plus anciennes partent d'abord). |
| **Gestes de vue** | 1 doigt dans le vide : tourner. 2 doigts : zoom et déplacement. « ⌖ » cadre l'objet, ou la sélection dans les modes Sommet et Face. |
| **Enregistrement auto** | 0,9 s après chaque modification, à la fermeture et quand l'app passe en arrière-plan : `.glb` (glTF 2.0) + aperçu 256 px + compteurs. |
| **Retour Android** | Il ferme d'abord un panneau ouvert ; sinon il enregistre puis ferme. |
| **Paysage** | Onglets en colonne à gauche, panneaux sur le côté droit, barre d'outils en une rangée. |

**Le format .glb.**
- Un seul fichier, que Godot ouvre tel quel :
  - triangles à normales plates ;
  - une matière PBR par objet ;
  - nœuds avec position, rotation et échelle.
- Les **polygones d'origine** (quads, n-gones) sont rangés dans `node.extras.sbh = {id, color, verts, faces}` ; la scène porte `extras.sbh_mesh = {format:'sbh-mesh', version:1, name, symmetry}`. On peut donc rééditer **sans perte**.
- Un `.glb` venu d'ailleurs, sans ces `extras`, se relit aussi : triangles soudés.

### 1.2 Dans l'app (Kotlin)
- Nouveau paquet `com.sbh.studio.mesh` :
  - `MeshStore` : fichiers `files/meshes/<projet>/<id>.glb`, `<id>.png` et `index.json`. L'écriture est atomique. **Un `.glb` mal formé est refusé.** Un index illisible est sauvegardé à part, puis reconstruit.
  - `MeshEditorDialog` : WebView plein écran, même schéma que l'éditeur CreatureStudio. Pont JavaScript `SBhMesh` : `start` / `save` / `close` / `toast`.
  - `GlbCheck` : contrôle du `.glb`, en Kotlin pur.
- **Zone Créatures** :
  - bouton « 🧊 Modeleur 3D (nouveau maillage) » ;
  - filtre **« Maillages (n) »** ;
  - cartes avec aperçu, compteurs (objets, faces, triangles) et symétrie, plus les actions « 🧊 Modeler » et 🗑 (2 touches).
- **Rien n'est exporté vers Minecraft** : Minecraft n'accepte que des cubes. Pour Minecraft, les monstres gardent leur corps CreatureStudio.

### 1.3 Contrat SBH 1.1 (format commun Studio ⇄ jeu)
- Nouveau contenu facultatif **`mesh`**, un fichier `.glb` :
  - `id` obligatoire et unique, rangé dans la table `meshes` ;
  - nouveau code **E_MESH** : en-tête, version 2, longueurs des blocs, JSON strict, `asset.version` = « 2.0 ».
- `CONTRACT_MINOR = 1` dans les **trois** validateurs (Python, Kotlin du Studio, GDScript du jeu). Un monde 1.0 reste valide.
- **17 cas de conformité de plus, 68 au total.** Le test aléatoire abîme aussi les `.glb`.
- L'exemple `al_zahra_mini` contient un vrai maillage du Modeleur, et son manifeste est en 1.1.0.
- SPEC (§ 5.7, § 7, § 8, § 10), CHANGELOG et README mis à jour.

---

## 2. Les preuves (tout a été exécuté ici)

| Test | Résultat |
|---|---|
| `node tools/meshstudio/test_mesh_core.mjs` : cœur géométrique | **182/182**. Primitives fermées (Euler 2, ou 0 pour le tore), volume positif, normales sortantes, extrusions (une face, région, faces opposées, toutes, 5 de suite), symétrie exacte, rotations aller-retour, `.glb` aller-retour avec et sans `extras` |
| Godot 4.4.1 `contract/godot/tests/load_glb.gd` | Les `.glb` du Modeleur s'ouvrent : 3 nœuds, 3 maillages, 2 364 sommets, `extras.sbh` lus |
| `python3 tools/meshstudio/test_mesh_studio.py` : **émulation de téléphone** 412 × 915, densité 2,625, vrais événements tactiles | **46/46**. Boutons ≥ 48 px, les 10 boutons à l'écran, vue 3D ≥ 70 %. Toucher une face ou un sommet, extruder, tirer les flèches, symétrie, 1 doigt pour tourner, 2 doigts pour zoomer, valeurs exactes, renommer, dupliquer, supprimer, ajouter un tore, Retour Android, `.glb` valide, réouverture identique, paysage |
| `bash contract/tools/run_all.sh` | Python **68/68**, Kotlin **68/68**, Godot **68/68**, exemple valide |
| Test aléatoire comparatif | **500/500** identiques entre Python, Kotlin et Godot, dont 180 avec un `.glb` abîmé |
| kotlinc 2.1.21 : `GlbCheck` + `tools/meshstudio/GlbCheckTest.kt` | Vrais `.glb` acceptés ; longueur fausse, fichier coupé, version 1, en-tête faux, JSON trop long, texte : tous refusés |
| `tools/checks/local_fun_order.py` | Aucune fonction locale utilisée avant sa déclaration |
| Relecture indépendante du Kotlin Android | Aucune erreur de compilation trouvée. 4 remarques appliquées : délai de fermeture porté à 6 s, sauvegarde d'un index illisible, nom vide, `key(mid)` autour de la fenêtre |

### Défauts trouvés par les tests et corrigés avant la livraison
- **Godot ne peut pas ouvrir une scène vide.** Le Modeleur refuse donc d'écrire un `.glb` sans objet et garde toujours au moins un objet.
- **Les flèches sortaient de l'écran** quand l'élément choisi était près d'un bord : elles étaient impossibles à toucher. Elles passent maintenant de l'autre côté ou rétrécissent, sans descendre sous ~72 px.
- **Trois boutons de la barre étaient cachés** hors de l'écran : il fallait faire défiler la barre. En portrait, la barre a maintenant deux rangées, tout est visible.
- **Le bouton « Ajouter »** était caché en bas du panneau ; il reste maintenant collé en bas.
- **Le cadrage ignorait l'écran étroit** du portrait : l'objet débordait.
- **Une forme ajoutée** apparaissait dans la précédente.
- **GDScript** : une fonction sans type de retour bloquait la compilation du validateur Godot.

---

## 2 bis. Séance de test « utilisateur » : un personnage construit au doigt (V1.8.65_FIX)

**Ce qu'a demandé l'utilisateur** : créer un personnage avec les seuls outils du Studio, et vérifier en captures que tout marche.

- **Le script `tools/meshstudio/session_personnage.py`** :
  - il pilote le Modeleur sur un téléphone simulé (412 × 915, gestes tactiles réels) ;
  - il ne modifie **jamais** le maillage par code : il touche des boutons, remplit des champs, tire des flèches et fait tourner la vue au doigt.
- **Le personnage obtenu, « Gardien Hibou »** :
  - un torse (cube de 3 segments) ;
  - des bras en 3 extrusions, la main rétrécie avec la boule d'échelle ;
  - des jambes en 2 extrusions vers le bas, en symétrie ;
  - le torse posé au sol avec 🔢 Valeurs ;
  - une tête (sphère) placée avec 🔢 Valeurs, avec un nez tiré en mode Sommet ;
  - puis annuler et rétablir, enregistrement, réouverture et passage en paysage.
- **Résultat** :
  - 2 objets, 254 faces, 476 triangles, maillages fermés et symétriques ;
  - `.glb` de 46 Ko, ouvert par Godot 4.4.1 et accepté par le contrat (aucun E_MESH) ;
  - planche de 17 captures : `test_personnage_planche.png`.
- **Défauts trouvés par la séance, et corrigés** :
  1. **La sélection partait hors de l'écran après une extrusion** : la face du bout du bras se retrouvait au bord, la flèche n'était plus touchable, il fallait penser à ⌖. Maintenant, la vue suit la sélection (glissement doux, même angle) quand elle approche du bord.
  2. **Le mode Sommet sur une sphère** affichait un amas de carrés de 11 px. Les points sont plus petits sur un maillage dense (8 px, puis 6 px) ; la zone de toucher reste de 28 px.
  3. **Le dos d'un personnage sombre disparaissait dans le fond.** Une lumière d'appoint arrière a été ajoutée.
- **Ce qui n'était pas un défaut** (mais bon à savoir pour l'utilisateur) :
  - Une nouvelle forme se pose **à droite** des autres. Pour un personnage symétrique, il faut la recentrer avec 🔢 Valeurs (position X = 0).
  - Pour extruder vers le bas, il faut **tourner la vue par en dessous** d'un geste franc, à un doigt.
  - La longueur d'un glissé dépend du zoom : plus on est loin, plus la pièce va loin. Les valeurs exactes sont dans 🔢 Valeurs.
- Après corrections : séance **0 problème**, tests téléphone **46/46**, cœur géométrique **182/182**.

## 2 ter. Ouverture d'un .glb venu d'ailleurs : `mannequin_base_humain.glb` (V1.8.65_FIX2)

**Le fichier**
- L'utilisateur a envoyé un mannequin de 23 pièces, fait avec trimesh : sans squelette, avec des couleurs par sommet.
- Il était accompagné d'une vidéo de référence : un mannequin articulé qui prend des poses.

**Ouverture dans le Studio**
- 23 objets, sans erreur, en 1 s.
- Godot 4.4 l'ouvre aussi.

**Défaut du fichier**
- Les 8 cylindres des membres sont couchés selon Z au lieu d'être verticaux. Exemple : `Cuisse_L` mesure 0,52 m de profondeur pour 0,14 m de haut.
- Réparé **avec les outils du Studio** : ☰ Objets → le membre, puis 🔢 Valeurs → rotation X = 90°.
- Résultat : `mannequin_base_humain_repare.glb`, accepté par le contrat et ouvert par Godot. Il pèse 3,4 Mo au lieu de 274 Ko, parce que le Modeleur écrit des triangles à normales plates et garde les polygones d'origine pour la retouche.

**Défauts du Studio révélés par ce fichier, et corrigés**
1. **Couleurs ignorées** : tout s'affichait en doré. On lit maintenant la couleur de matière (`baseColorFactor`) ou la moyenne des couleurs de sommets (`COLOR_0`).
2. **Cadrage à l'ouverture sur le seul premier objet** : la tête remplissait l'écran. On cadre maintenant tout le maillage.
3. **Pièces tournant autour du centre du monde** : les pièces « cuites » à l'origine tournaient autour du point (0, 0, 0), et un bras tourné partait au niveau des hanches. L'origine de chaque objet étranger est maintenant placée au centre de sa pièce, avec un rendu identique.

**Tests**
- 4 vérifications de plus, 186/186.
- Tests téléphone 46/46 ; séance « personnage » sans problème.

**Ce que le Studio ne sait pas encore faire** (la vidéo) : poser un mannequin articulé, où le bras entraîne l'avant-bras et la main autour de l'épaule. Il faut pour ça un **squelette** : articulations qui servent de pivots, hiérarchie et rotations par articulation. C'est la phase 5 du plan (squelette, rigging, animation).

## 3. Fichiers ajoutés ou modifiés

| Fichier | Statut |
|---|---|
| `app/src/main/assets/meshstudio/mesh_core.js` | nouveau : cœur géométrique (module ES pur, sans three.js) |
| `app/src/main/assets/meshstudio/mesh_studio.html` | nouveau : l'éditeur tactile (three.js r160 déjà présent dans `assets/js/`) |
| `app/src/main/java/com/sbh/studio/mesh/GlbCheck.kt`, `MeshStore.kt`, `MeshEditorScreen.kt` | nouveaux |
| `app/src/main/java/com/sbh/studio/workshop/CreatureZone.kt` | modifié : filtre Maillages, bouton, cartes, `rememberMeshPreview` |
| `app/src/main/java/com/sbh/studio/workshop/WorkshopScreen.kt` | modifié : état `meshEditing` / `meshVersion` / `meshes`, `MeshEditorDialog`, branchement |
| `app/src/main/java/com/sbh/studio/contract/ContractValidator.kt` | modifié : `CONTRACT_MINOR = 1`, kind `mesh`, `glbProblem` |
| `contract/reference/sbh_contract.py`, `contract/godot/addons/sbh_contract/sbh_contract.gd` | modifiés : même chose |
| `contract/tools/gen_schemas.py` (+ schémas régénérés dans 3 emplacements), `make_cases.py`, `make_example.py`, `fuzz_diff.py` | modifiés |
| `contract/conformance/` (68 cas), `contract/examples/al_zahra_mini/` (+ `content/meshes/tete_demo.glb`, manifeste 1.1.0 re-signé) | régénérés |
| `contract/godot/tests/load_glb.gd` | nouveau |
| `contract/SPEC_SBH_DATA_CONTRACT_v1.md`, `CHANGELOG.md`, `README.md` | mis à jour (1.1.0) |
| `tools/meshstudio/test_mesh_core.mjs`, `test_mesh_studio.py`, `GlbCheckTest.kt`, `session_personnage.py` | nouveaux tests (le dernier : séance « personnage » au doigt) |
| `version.json` (racine et `assets/`) | 1.8.65, code 100 |

Rien d'autre n'a changé : ni monstres, ni CreatureStudio, ni Map Studio, ni l'export Minecraft.

---

## 4. Ce qui reste à faire

### À faire par l'utilisateur
1. **Compiler sur GitHub** (assembleDebug). Le Kotlin Android n'a pas pu être compilé ici, parce que les dépôts Maven et Google sont bloqués. Il a été relu ; seul `GlbCheck` a été compilé.
2. **Essayer sur le téléphone** :
   1. Atelier → Créatures → 🧊 Modeleur 3D.
   2. Mode Face : toucher le dessus du cube, puis ⇧ Extruder.
   3. Tirer la flèche verte.
   4. Retour.
   5. Vérifier que la carte apparaît dans « Maillages ».
3. Toujours en attente depuis avant :
   - la constitution technique et l'archive du jeu Godot ;
   - la décision `hibou` ↔ `royaume` (neutre ou guerre ?) ;
   - l'accord pour corriger l'affichage de Map Studio sur téléphone ;
   - les résultats de compilation de V1.8.63_FIX et V1.8.64.

### Prochaine étape prévue : livraison B (V1.8.66)
- mode **Arête** ;
- coupe en boucle (loop cut) ;
- souder ;
- supprimer sommet, arête ou face ;
- subdiviser ;
- affichage lissé ;
- recalcul des normales.

**Points d'entrée** : ajouter les opérations dans `mesh_core.js`, avec leurs tests dans `test_mesh_core.mjs`, puis les boutons dans `mesh_studio.html`, avec les tests téléphone.

### Ensuite (plan de l'atelier, phases 2 à 6)
- Sculpt.
- Couteau, biseau, booléens, pont.
- Vêtements et armures en couches, armes.
- Matières, peinture de texture.
- Squelette libre, rigging, poids, animation.
- Points d'attache (sockets), assemblage, aperçu, export.
- Puis le **labo de test** (Godot lit un paquet du contrat et écrit un `test_report`).

### Limites connues de cette livraison
- **Une seule couleur par objet**, sans texture.
- **Le maillage n'est pas encore relié à un monstre ou à un PNJ.** Ce lien viendra avec le squelette et l'assemblage.
- **On ne peut pas importer un `.glb` venu d'ailleurs depuis l'app.** Le lecteur sait le faire, mais il n'y a pas encore de bouton.
- **Pas d'export vers un paquet de monde depuis l'app.** Le contrat sait déjà décrire `content/meshes/`, mais l'export du paquet viendra avec le labo.
