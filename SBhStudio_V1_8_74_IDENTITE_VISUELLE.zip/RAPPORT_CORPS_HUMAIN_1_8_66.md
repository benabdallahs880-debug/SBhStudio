# V1.8.66 : générateur de corps humain (Atelier de personnages)

Ce dossier se lit sans l'historique de la conversation. Il fait suite à `RAPPORT_MODELEUR_3D_1_8_65.md`, qui décrit le Modeleur 3D, le contrat 1.1 et les séances de test.

## Le contexte
- L'utilisateur voulait **un vrai modèle 3D de mannequin à forme humaine**, fait par nous, sans service extérieur.
- Les mannequins qu'il avait reçus d'ailleurs (`mannequin_base_humain.glb`, `gardien_hibou_humain.glb`) étaient des empilements de formes simples, avec les membres couchés.
- Plan accepté (« Ok ») :
  1. corps humain lissé, montré dans Godot ;
  2. curseurs ;
  3. squelette et poses ;
  4. sculpture et équipement.
- **Ce travail couvre les étapes 1 et 2.**
- **Style choisi par défaut** : « réaliste stylisé, proportions héroïques » (comme l'image de référence du Gardien Hibou). L'utilisateur n'a pas tranché, et les curseurs permettent d'en changer.

---

## 1. Ce qui a été fait

### 1.1 La méthode (fichier `app/src/main/assets/meshstudio/body_core.js`, module ES pur)
1. **Le corps est un champ de distance fait de ~40 volumes anatomiques fondus les uns dans les autres** (« union douce ») :
   - tête : crâne, mâchoire, nez, menton, oreilles, arcade, pommettes ;
   - cou et trapèzes ;
   - tronc : cage thoracique, pectoraux, grands dorsaux, abdomen, ventre, bassin, fessiers ;
   - bras : deltoïdes, bras, biceps, triceps, avant-bras, paume, doigts, pouce ;
   - jambes : cuisses, quadriceps, vaste externe, adducteurs, genoux, tibias, mollets, pieds, chevilles.
   
   Les muscles des bras sont des cônes alignés sur l'axe du bras. **Chaque volume porte le nom de son os** (`head`, `neck`, `spine2`, `spine1`, `hips`, `upperarm`, `forearm`, `hand`, `upperleg`, `lowerleg`, `foot`), ce qui prépare le squelette (étape 3).
2. **Extraction de la peau** (« surface nets ») sur une grille centrée sur X = 0. Le résultat est un maillage de **quads**, **fermé, d'un seul tenant (Euler 2) et exactement symétrique**.
3. **Sécurités** :
   - si deux nappes se touchent (pouce contre paume), l'extraction est refaite avec une grille décalée en Y/Z, jusqu'à 5 essais. La réparation qui dédouble le sommet partagé (`makeManifold`) ne sert qu'en dernier recours ;
   - lissage léger qui garde le volume (Taubin), puis recollage sur la surface ;
   - symétrie **exacte par construction** : un sommet, son reflet et ses doubles reçoivent la même position.
4. **Repère** : Y vers le haut, pieds sur Y = 0, le corps regarde vers +Z, en mètres. **Pose en A** (bras à ~40°), la pose standard pour poser un squelette.

### 1.2 Les curseurs (`BODY_PARAMS`)

| Curseur | Défaut | Bornes |
|---|---|---|
| Taille (m) | 1,80 | 1,40 à 2,20 |
| Carrure | 1 | 0,8 à 1,3 |
| Musculature | 1 | 0,5 à 1,6 |
| Corpulence | 1 | 0,8 à 1,5 |
| Tête | 1 | 0,85 à 1,2 |
| Finesse (cm, taille de la grille) | 1,2 | 0,8 à 2,5 |

- À la finesse 1,2 cm, le corps compte environ 18 500 faces et se génère en 2 à 3 s.
- Une valeur hors bornes est ramenée dans les bornes.

### 1.3 Dans le Modeleur 3D (`mesh_studio.html`)
- **＋ Ajouter → 🧍 Humain**, en première position, avec les curseurs et une courte aide. Un message « Création du corps… » s'affiche pendant le calcul.
- Le corps est un objet **lisse** (`smooth: true`) :
  - affichage à normales douces ;
  - pas de fil de fer doré en mode Objet ;
  - fil très discret en modes Sommet et Face (0,16 au lieu de 0,75 dès 3 000 faces).
- Tous les outils marchent dessus : Valeurs, Objets, Face, Sommet, Extruder, symétrie, Annuler.

### 1.4 Export (`mesh_core.js`)
- `triangulateSmooth` produit des triangles **indexés** à normales par sommet.
- `writeGLB` l'utilise pour les objets lisses et range `smooth: true` dans `extras.sbh` ; `readGLB` le relit.
- Le .glb reste un glTF 2.0 standard : Godot l'ouvre tel quel.

### 1.5 Corrections faites en route (déjà dans V1.8.65_FIX / FIX2, reprises ici)
- La vue suit la sélection.
- Points plus petits sur un maillage dense.
- Lumière arrière.
- Import d'un .glb étranger : couleurs de matière et de sommets lues, cadrage de tout le maillage, origine de chaque pièce en son centre.

---

## 2. Les preuves

| Test | Résultat |
|---|---|
| `node tools/meshstudio/test_body_core.mjs` | **47/47**. 8 morphologies (standard, mince, colosse, corpulent, petit, grossier, extrêmes min et max) : peau fermée d'un seul tenant, symétrique, quads uniquement, hauteur juste, pieds au sol, volumes cohérents (standard 75 L, mince 56 L, colosse 112 L). `.glb` lisse indexé et relu identique |
| `node tools/meshstudio/fuzz_body.mjs 40` | **40/40** réglages au hasard : peau fermée, symétrique |
| `node tools/meshstudio/test_mesh_core.mjs` | **186/186** |
| `python3 tools/meshstudio/test_mesh_studio.py` (téléphone 412 × 915) | **46/46** |
| `python3 tools/meshstudio/session_personnage.py` (le Gardien au doigt) | **0 problème** |
| `python3 tools/meshstudio/test_humain_ui.py <dossier>` | ＋ Ajouter → Humain au doigt : corps de 19 226 sommets, fermé, symétrique, lisse, créé en ~3 s, enregistré, **ouvert par Godot 4.4** |
| Rendu Godot 4.4.1 (OpenGL sur écran virtuel, hors de l'app) | `corps_humain_godot.png` : 4 vues, plus 4 morphologies à la même échelle |

### Défauts trouvés par les tests et corrigés avant la livraison
- **Peau « pincée »** au pouce : extraction refaite avec une grille décalée, réparation en dernier recours.
- **Petits défauts de symétrie** près des doubles : symétrie exacte par construction.
- **Proportions** :
  - bras bosselés : muscles réalignés sur l'axe du bras ;
  - taille en sablier, puis bosse de hanche ;
  - capuche de cobra du colosse ;
  - bourrelets du corpulent ;
  - pectoraux du mince ;
  - creux trop marqués du visage.
- **Une parenthèse avalée par un commentaire** cassait le démarrage de la page. Les tests du navigateur l'ont attrapée avant la livraison.

---

## 3. Fichiers ajoutés ou modifiés

| Fichier | Statut |
|---|---|
| `app/src/main/assets/meshstudio/body_core.js` | **nouveau** : générateur de corps |
| `app/src/main/assets/meshstudio/mesh_core.js` | modifié : `triangulateSmooth`, export lisse, `smooth` relu, `quatRotate`, import étranger (couleurs, centre des pièces) |
| `app/src/main/assets/meshstudio/mesh_studio.html` | modifié : « Humain » dans ＋ Ajouter, affichage lisse, fil discret, cadrage global à l'ouverture, la vue suit la sélection, lumière arrière |
| `tools/meshstudio/test_body_core.mjs`, `fuzz_body.mjs`, `test_humain_ui.py` | nouveaux tests |
| `tools/meshstudio/test_mesh_core.mjs` | + tests couleurs étrangères et recentrage |
| `version.json` (racine et `assets/`) | 1.8.66, code 101 |

Aucun fichier Kotlin n'a changé depuis V1.8.65_FIX : le générateur est entièrement dans les pages du Studio.

---

## 4. Ce qui reste à faire

### À faire par l'utilisateur
1. **Compiler sur GitHub** et essayer sur le téléphone :
   1. Atelier → Créatures → 🧊 Modeleur 3D ;
   2. ＋ Ajouter → 🧍 Humain → curseurs → Ajouter.
   
   Le calcul prend ~3 s sur ordinateur ; sur un téléphone, ce sera sans doute un peu plus.
2. **Dire le style voulu** (plus réaliste ou plus stylisé), et envoyer si possible une image de face et une de profil du corps voulu.
3. Toujours en attente :
   - la constitution technique et l'archive du jeu Godot ;
   - la décision `hibou` / `royaume` ;
   - l'accord pour corriger l'affichage de Map Studio sur téléphone.

### Étape suivante prévue : squelette et poses (étape 3, phase 5 du plan d'atelier)
- **Os** : placés à partir des mêmes repères que les volumes (épaule, coude, poignet, hanche, genou, cheville, colonne, cou, tête), avec les noms de la norme humanoïde de Godot (`SkeletonProfileHumanoid`), pour pouvoir reprendre des animations toutes faites.
- **Poids de peau** : calculés à partir des volumes, puisque chacun connaît son os, avec une transition douce aux articulations.
- **Poses au doigt** : choisir une articulation et la tourner, comme dans la vidéo de référence.
- **Export `.glb`** avec `skins` + `joints` + `weights`, vérifié dans Godot (pose et animation).
- **Contrat** : un maillage avec squelette reste un `.glb` (`kind: "mesh"`), rien à changer.

### Ensuite
- Sculpture : visage, mains plus fines, muscles.
- Équipement modelé à part (casque-hibou, plastron, cape) et accroché aux os.
- Livraison B du Modeleur : arêtes, coupe en boucle, subdivision.

### Limites connues
- Les mains sont des « moufles », sans doigts séparés, et le visage reste simple, du niveau d'un mannequin.
- Corps masculin seulement pour l'instant (pas de curseur homme/femme).
- Un corps fait 18 à 24 000 faces. L'édition au sommet près marche, mais elle est plus lente qu'avec une forme simple, et chaque étape d'annulation garde une copie de ~1 Mo.
