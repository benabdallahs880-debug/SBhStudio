# V1.8.67 : SBH Arabian Gothic — Base Human V1 (générateur de corps)

Ce dossier se lit sans l'historique de la conversation. Il fait suite à `RAPPORT_CORPS_HUMAIN_1_8_66.md` (générateur de corps, méthode des volumes fondus) et à `RAPPORT_MODELEUR_3D_1_8_65.md` (Modeleur 3D, contrat 1.1).

## Le contexte

L'utilisateur a fixé le style avec trois planches de référence.

1. **« SBH Arabian Gothic — Base Human V1 »**
   - Des mannequins réalistes de diversité arabe, homme et femme, montrés de face, de profil gauche, de dos, de profil droit et de trois quarts.
   - Les détails : visages, mains, pieds, yeux.
   - 6 carnations, de très claire à très foncée.
   - Les cheveux : courts, longs, bouclés, attachés, voilés, barbes.
   - Les morphologies.
2. **« HIBOU — soldats normaux »** : armure en trois niveaux (HIPPO I léger, II renforcé, III lourd) avec foulard, turban, plaques, sacoches, fusil et sabre.
3. **« Base Human Texture System »** : textures PBR à motifs islamiques et gothiques, calligraphie, palette de matières.

Ce que la méthode du Studio peut atteindre a été dit à l'utilisateur dès le départ : un mannequin crédible et stylisé. Le niveau photo (pores, cils, ongles, cheveux mèche par mèche, textures peintes) demande la sculpture et la peinture de textures (phases 2 et 4 du plan d'atelier), ou des outils extérieurs.

---

## 1. Ce qui a été fait

### 1.1 Générateur de corps (`app/src/main/assets/meshstudio/body_core.js`)

| Nouveau | Détail |
|---|---|
| **Homme ↔ Femme** (`sex`, 0 à 1, valeurs intermédiaires possibles) | Épaules, cage thoracique, trapèzes, dorsaux plus étroits ; taille plus fine ; bassin et fessiers plus larges ; pectoraux remplacés par une poitrine modeste ; bras, mains et cou plus fins ; mâchoire, menton et nez plus fins |
| **6 carnations** (`skin`, 1 à 6, `SKIN_TONES`) | Très claire `#E3C2A2`, claire `#D2A57F`, moyenne `#B9835C`, mate `#9A6644`, foncée `#6F4630`, très foncée `#4A2E20` |
| **Tête détaillée, pièce à part** | Calculée environ 3 fois plus finement (≈ 4 mm), parce que le nez, les lèvres et les paupières font moins de 1 cm. Elle comprend une vraie ligne de mâchoire (oreille → menton), une arête de nez avec pointe et narines, deux lèvres, des orbites creusées avec les yeux, l'arcade sourcilière, les pommettes et les oreilles. Le raccord avec le cou se fait juste sous la mâchoire : le bas de la tête plonge de 2 mm sous la peau du cou, puis remonte 1,2 mm au-dessus, de sorte que les surfaces se croisent sans rebord |
| **Tenue de base** (`outfit`) | Short (homme et femme), et pour la femme une brassière de sport avec bretelles. Ce sont des coques posées à 7 mm de la peau, des objets séparés : c'est le premier pas des couches d'habillage |
| **Cheveux** (`hair`) | Cheveux courts (homme) ou chignon (femme). La coque s'affine jusqu'à 1,5 mm à la ligne d'implantation, qui est haute sur le front et plus basse sur les tempes et la nuque |
| **Barbe** (`beard`, homme) | Barbe courte qui suit la mâchoire jusqu'aux oreilles, avec moustache ; la bouche reste dégagée |
| Anatomie | Abdominaux discrets, trapèzes redescendus (le cou est visible) |

Chaque pièce (corps, tête, short, brassière, cheveux, barbe) est un maillage **fermé, d'un seul tenant et exactement symétrique**.

**Vitesse : 12,8 s → 6 s par personnage complet.**
- Champ calculé d'abord sur une grille grossière, puis en fin seulement près de la peau.
- Élagage exact des volumes trop éloignés.
- Recollage sur la surface en 4 calculs par sommet au lieu de 14.

**Robustesse** : les vêtements ont une grille d'au plus 9 mm. Avant, les bretelles de la brassière cassaient quand la finesse était grossière.

### 1.2 Dans le Modeleur 3D (`mesh_studio.html`, `body_worker.js`)
- ＋ Ajouter → 🧍 Humain propose les nouveaux curseurs : Homme 0 ↔ 1 Femme, Carnation (1 à 6), Tenue de base, Cheveux, Barbe.
- **Le calcul tourne en arrière-plan** (Web Worker), donc l'écran ne fige pas. S'il échoue, il est refait sur place.
- Un humain arrive en **5 pièces** (Corps, Tête, Short, Cheveux, Barbe ; ou Brassière et chignon pour la femme), posées à droite de ce qui existe.
- ☰ Objets : nouvelle rangée **« Carnations »** avec les 6 teintes.

### 1.3 Rendu de présentation dans Godot 4.4 (hors de l'app)
- Fond sombre, lumière principale neutre, contre-jour froid, tone mapping AgX.
- Éclairage **calibré** : la couleur rendue du torse a été mesurée et comparée aux 6 carnations visées.
- Planche finale : `sbh_base_human_v1_planche.png`.

---

## 2. Les preuves

| Test | Résultat |
|---|---|
| `node tools/meshstudio/test_body_core.mjs` | **117/117**. 11 morphologies (dont femme, femme sans tenue, mixte, extrêmes) : corps, tête et chaque vêtement fermés et symétriques ; la tête recouvre le cou ; hauteur juste ; 6 carnations ; brassière pour la femme, barbe pour l'homme |
| `node tools/meshstudio/fuzz_body.mjs 20 12345`, `20 777`, `12 4242` | **52/52** réglages au hasard (sexe, carnation, tenue, cheveux, barbe compris) : toutes les pièces fermées et symétriques |
| `node tools/meshstudio/test_mesh_core.mjs` | **186/186** |
| `python3 tools/meshstudio/test_mesh_studio.py` (téléphone 412 × 915) | **46/46** |
| `python3 tools/meshstudio/session_personnage.py` | **0 problème** |
| `python3 tools/meshstudio/test_humain_ui.py <dossier>` | **OK** : 5 pièces créées en ~6 s, l'écran continue de s'animer pendant le calcul (61 images en 1 s) ; `.glb` ouvert par Godot (5 nœuds, 45 000 sommets) et accepté par le contrat |

### Défauts trouvés et corrigés en route
- **Mâchoire en « bloc »** : remplacée par une vraie ligne de mâchoire.
- **Visage flou** : la grille était trop grosse ; la tête est devenue une pièce fine.
- **Barbe en masque, puis en col sur le cou** : elle suit maintenant la mâchoire.
- **Barbe ouverte** : elle était coupée par le bord de sa zone de calcul.
- **Cheveux en casque** : la ligne d'implantation était trop basse et le bord trop épais.
- **Lèvres en « O »**.
- **Anneau, puis tache au cou** : le raccord a été déplacé sous la mâchoire.
- **Peaux claires surexposées** : l'éclairage a été mesuré puis calibré.
- **Panneau de la planche qui débordait.**

---

## 3. Fichiers ajoutés ou modifiés

| Fichier | Statut |
|---|---|
| `app/src/main/assets/meshstudio/body_core.js` | modifié : homme ↔ femme, carnations, tête fine séparée, tenue, cheveux, barbe, accélérations |
| `app/src/main/assets/meshstudio/body_worker.js` | **nouveau** : calcul en arrière-plan |
| `app/src/main/assets/meshstudio/mesh_studio.html` | modifié : `addHuman` (worker, 5 pièces), rangée Carnations |
| `tools/meshstudio/test_body_core.mjs`, `fuzz_body.mjs`, `test_humain_ui.py` | mis à jour |
| `version.json` (racine et `assets/`) | 1.8.67, code 102 |

Aucun fichier Kotlin n'a changé. Le contrat SBH reste en 1.1 : chaque pièce est un `.glb` ordinaire.

---

## 4. Ce qui reste à faire

### À faire par l'utilisateur
1. **Compiler sur GitHub** et essayer sur le téléphone : Créatures → 🧊 Modeleur 3D → ＋ Ajouter → 🧍 Humain.
2. Dire si la direction convient avant d'aller plus loin dans le détail.

### Limites connues de cette version (dites franchement)
- **Visages de mannequin** : traits simples, pas d'yeux peints. L'expression de la femme reste peu naturelle (bouche).
- **Mains en moufle**, pas d'orteils.
- **Cheveux et barbe en coques lisses**, sans mèches ni bouclés, ni cheveux longs ou voile pour l'instant.
- **Une ligne fine reste visible au raccord tête / cou.** Elle disparaîtra quand les deux pièces seront soudées (étape squelette) ou cachées par la tenue (keffieh, col d'armure).
- **Pas de textures** : une couleur par pièce.
- **Temps de calcul** : ~6 s sur ordinateur, sans doute 10 à 20 s sur un téléphone. L'écran reste utilisable pendant ce temps.

### Suite logique (dans l'ordre proposé)
1. **Squelette et poses** (phase 5) : os aux normes humanoïdes de Godot, poids de peau calculés à partir des volumes (chaque volume connaît son os), poses au doigt, export `.glb` animé. C'est aussi le moment de souder la tête au corps.
2. **Équipement HIBOU** (planche 2) : foulard et turban, plastron, épaulières, brassards, genouillères et tibias, ceinture et sacoches, en couches posées sur le corps (même technique que la tenue de base). Trois niveaux : HIPPO I, II, III.
3. **Cheveux** : longs, bouclés, voile ou hijab, et plus de styles de barbe.
4. **Textures et motifs** (planche 3) : phase 4 du plan, avec motifs géométriques islamiques et gothiques, calligraphie, matières PBR.
5. **Sculpture du visage et des mains** (phase 2).
