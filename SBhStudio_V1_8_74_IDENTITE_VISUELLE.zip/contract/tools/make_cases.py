"""Fabrique contract/conformance/ : un paquet minimal + une variante par règle du contrat, avec le
résultat ATTENDU écrit à la main (expected.json). Les trois validateurs doivent le reproduire.
    python3 contract/tools/make_cases.py
"""
import copy, hashlib, json, pathlib, shutil

CONF = pathlib.Path(__file__).resolve().parents[1] / "conformance"
CASES = CONF / "cases"
V = "1.0.0"
M = "sbh_world.json"

BASE = {
    "rules/biomes.json": {"contract_version": V, "kind": "biomes", "biomes": [
        {"id": "desert", "name": "Désert", "color": "#D8B970", "temperature_c": {"min": 20, "max": 40},
         "humidity": {"min": 0.0, "max": 0.2}, "elevation_m": {"min": 0, "max": 800}}]},
    "rules/cultures.json": {"contract_version": V, "kind": "cultures", "cultures": [
        {"id": "c1", "name": "Culture 1", "biomes": ["desert"], "building_families": [
            {"id": "f1", "name": "Famille 1", "role": "habitation", "variants": [
                {"id": "v1", "name": "Variante 1", "footprint_m": {"w": 6, "d": 6}, "floors": {"min": 1, "max": 2}, "weight": 1}]}]}]},
    "rules/settlements.json": {"contract_version": V, "kind": "settlements", "settlement_types": [
        {"id": "s1", "name": "Village", "culture": "c1", "size": "village", "population": {"min": 100, "max": 900},
         "placement": {"biomes": ["desert"], "min_distance_m": 2000}, "layout": "organique",
         "buildings": [{"family": "f1", "count": {"min": 5, "max": 50}}]}]},
    "rules/roads.json": {"contract_version": V, "kind": "roads", "road_types": [
        {"id": "r1", "name": "Piste", "width_m": 3, "surface": "sable", "connects": ["s1"]}]},
    "rules/factions.json": {"contract_version": V, "kind": "factions",
        "factions": [{"id": "a", "name": "A", "color": "#112233", "strength": {"min": 10, "max": 20}},
                     {"id": "b", "name": "B", "color": "#445566", "strength": {"min": 5, "max": 9}, "culture": "c1"}],
        "relations": [{"from": "a", "to": "b", "value": -40, "stance": "mefiant"}]},
}
KINDS = {"rules/biomes.json": "biomes", "rules/cultures.json": "cultures", "rules/settlements.json": "settlements",
         "rules/roads.json": "roads", "rules/factions.json": "factions"}
CREATURE = {"formatVersion": "1.0", "project": {"id": "p", "name": "Bête"}, "creature": {"name": "Bête"}}
REPORT = {"contract_version": V, "kind": "test_report", "report_id": "rt_0001", "created_at": "2026-10-06T17:30:00+02:00",
          "app": {"name": "SBh Studio", "version": "1.8.64"},
          "device": {"model": "Samsung A54", "os": "Android 14", "ram_mb": 8192, "screen": {"width_px": 1080, "height_px": 2340, "density": 2.625}},
          "world": {"id": "al_zahra_mini", "seed": 1337, "contract_version": V},
          "scenario": {"name": "Survol", "duration_s": 60},
          "metrics": {"fps": {"min": 24, "avg": 52.5, "p1": 27, "p50": 55, "p95": 60}, "frame_ms": {"avg": 19.1, "p95": 31, "p99": 40},
                      "memory_mb": {"start": 310, "peak": 512, "end": 480},
                      "systems": [{"id": "terrain", "name": "Terrain", "avg_ms": 3.2, "max_ms": 11, "calls": 3600},
                                  {"id": "lod", "name": "LOD", "avg_ms": 0.8, "max_ms": 2.5, "calls": 3600}],
                      "chunks": {"loaded": 420, "detailed": 49, "abstract": 371, "lod": [{"level": 0, "count": 49}, {"level": 1, "count": 120}]}},
          "events": [{"t_s": 12.5, "level": "warning", "message": "Pic de génération (11 ms)"}]}


def glb(js, bin_=b"\x00\x00\x80\x3f" * 9, *, version=2, magic=0x46546C67, length_delta=0, json_raw=None):
    """Petit .glb fait main (contrat 1.1, kind « mesh ») : un triangle, ou une variante abîmée."""
    j = json_raw if json_raw is not None else json.dumps(js, separators=(",", ":")).encode("utf-8")
    j += b" " * (-len(j) % 4)
    body = len(j).to_bytes(4, "little") + (0x4E4F534A).to_bytes(4, "little") + j
    if bin_ is not None:
        b = bin_ + b"\x00" * (-len(bin_) % 4)
        body += len(b).to_bytes(4, "little") + (0x004E4942).to_bytes(4, "little") + b
    total = 12 + len(body)
    return magic.to_bytes(4, "little") + version.to_bytes(4, "little") + (total + length_delta).to_bytes(4, "little") + body


TRI = {"asset": {"version": "2.0", "generator": "make_cases"}, "scene": 0, "scenes": [{"nodes": [0]}],
       "nodes": [{"mesh": 0}], "meshes": [{"primitives": [{"attributes": {"POSITION": 0}}]}],
       "accessors": [{"bufferView": 0, "componentType": 5126, "count": 3, "type": "VEC3", "min": [1, 1, 1], "max": [1, 1, 1]}],
       "bufferViews": [{"buffer": 0, "byteLength": 36}], "buffers": [{"byteLength": 36}]}


def dump(o):
    return (json.dumps(o, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def package(name, mutate=None, files_hook=None, raw=None, extra=None, sign=True):
    files = copy.deepcopy(BASE)
    if mutate:
        mutate(files)
    blobs = {p: dump(o) for p, o in files.items()}
    if raw:
        blobs.update(raw)
    if extra:
        blobs.update({p: dump(o) for p, o in extra.items()})
    entries = [{"path": p, "kind": KINDS[p], "sha256": hashlib.sha256(blobs[p]).hexdigest()} for p in KINDS if p in blobs]
    man = {"contract_version": V, "kind": "world",
           "world": {"id": "monde_test", "name": "Monde de test", "seed": 42, "size_chunks": {"x": 8, "z": 8}, "chunk_size_m": 32},
           "generator": {"name": "test", "version": "0.0.1"}, "created_by": {"tool": "make_cases", "version": "1.0.0"},
           "files": entries}
    if files_hook:
        files_hook(man, blobs)
    d = CASES / name
    d.mkdir(parents=True)
    for p, b in blobs.items():
        (d / p).parent.mkdir(parents=True, exist_ok=True)
        (d / p).write_bytes(b)
    (d / M).write_bytes(dump(man))


def document(name, doc):
    d = CASES / name
    d.mkdir(parents=True)
    (d / "document.json").write_bytes(dump(doc) if not isinstance(doc, bytes) else doc)


def E(code, file, path): return ["error", code, file, path]
def W(code, file, path): return ["warning", code, file, path]


B, C, S, R, F = "rules/biomes.json", "rules/cultures.json", "rules/settlements.json", "rules/roads.json", "rules/factions.json"
EXPECTED = {}


def case(name, expected, **kw):
    if "doc" in kw:
        document(name, kw["doc"])
    else:
        package(name, **kw)
    EXPECTED[name] = sorted(expected, key=lambda t: (t[2], t[3], t[1], t[0]))


def main():
    if CASES.exists():
        shutil.rmtree(CASES)
    CASES.mkdir(parents=True)

    case("ok_minimal", [])
    case("ok_unknown_field", [W("W_UNKNOWN", B, "/biomes/0/foo")],
         mutate=lambda f: f[B]["biomes"][0].update({"foo": 1, "x_perso": 2}))
    case("ok_newer_minor", [W("W_NEWER", B, "/contract_version")],
         mutate=lambda f: f[B].update({"contract_version": "1.3.0"}))
    case("err_version_major", [E("E_VERSION", F, "/contract_version")],
         mutate=lambda f: f[F].update({"contract_version": "2.0.0"}))
    case("err_json", [E("E_JSON", R, "")], raw={R: b'{"contract_version": "1.0.0", "kind": "roads", '})
    case("err_type", [E("E_TYPE", B, "/biomes/0/temperature_c/min")],
         mutate=lambda f: f[B]["biomes"][0]["temperature_c"].update({"min": "chaud"}))
    case("err_integer", [E("E_TYPE", F, "/factions/0/strength/min")],
         mutate=lambda f: f[F]["factions"][0]["strength"].update({"min": 10.5}))
    case("ok_integer_as_float", [],
         mutate=lambda f: f[F]["factions"][0]["strength"].update({"min": 10.0}))
    case("err_required", [E("E_REQUIRED", B, "/biomes/0/color")],
         mutate=lambda f: f[B]["biomes"][0].pop("color"))
    case("err_enum", [E("E_ENUM", S, "/settlement_types/0/layout")],
         mutate=lambda f: f[S]["settlement_types"][0].update({"layout": "spirale"}))
    case("err_min_max", [E("E_MAX", B, "/biomes/0/humidity/max"), E("E_MIN", B, "/biomes/0/temperature_c/min")],
         mutate=lambda f: (f[B]["biomes"][0]["humidity"].update({"max": 1.5}), f[B]["biomes"][0]["temperature_c"].update({"min": -100})))
    case("err_pattern", [E("E_PATTERN", B, "/biomes/0/color")],
         mutate=lambda f: f[B]["biomes"][0].update({"color": "#GGG"}))
    case("err_length", [E("E_LENGTH", F, "/factions/0/name")],
         mutate=lambda f: f[F]["factions"][0].update({"name": ""}))
    case("ok_length_unicode", [],
         mutate=lambda f: f[F]["factions"][0].update({"name": "🦉" * 80}))
    case("err_length_unicode", [E("E_LENGTH", F, "/factions/0/name")],
         mutate=lambda f: f[F]["factions"][0].update({"name": "🦉" * 81}))
    case("err_items", [E("E_ITEMS", C, "/cultures/0/biomes")],
         mutate=lambda f: f[C]["cultures"][0].update({"biomes": []}))
    case("err_range", [E("E_RANGE", S, "/settlement_types/0/population")],
         mutate=lambda f: f[S]["settlement_types"][0].update({"population": {"min": 900, "max": 100}}))
    case("err_duplicate_id", [E("E_UNIQUE", B, "/biomes/1/id")],
         mutate=lambda f: f[B]["biomes"].append(copy.deepcopy(f[B]["biomes"][0])))
    case("err_ref", [E("E_REF", R, "/road_types/0/connects/1")],
         mutate=lambda f: f[R]["road_types"][0]["connects"].append("s_inconnu"))
    case("err_ref_cross_file", [E("E_REF", F, "/factions/1/culture")],
         mutate=lambda f: f[F]["factions"][1].update({"culture": "c_inconnue"}))
    case("err_relation_self", [E("E_DISTINCT", F, "/relations/1")],
         mutate=lambda f: f[F]["relations"].append({"from": "a", "to": "a", "value": 0, "stance": "neutre"}))
    case("err_relation_dup", [E("E_UNIQUE", F, "/relations/1")],
         mutate=lambda f: f[F]["relations"].append({"from": "a", "to": "b", "value": 10, "stance": "neutre"}))

    def bad_hash(man, blobs):
        man["files"][0]["sha256"] = "0" * 64
    case("err_hash", [E("E_HASH", M, "/files/0/sha256")], files_hook=bad_hash)

    def missing_file(man, blobs):
        del blobs[R]
    case("err_missing_file", [E("E_FILE", M, "/files/3/path")], files_hook=missing_file)

    def bad_path(man, blobs):
        man["files"][3]["path"] = "rules/../rules/roads.json"
    case("err_path", [E("E_PATH", M, "/files/3/path")], files_hook=bad_path)

    def bad_path_pattern(man, blobs):
        man["files"][3]["path"] = "Rules/Roads.json"
    case("err_path_pattern", [E("E_PATTERN", M, "/files/3/path")], files_hook=bad_path_pattern)

    def only_factions(man, blobs):
        for p in [B, C, S, R]:
            blobs.pop(p, None)
        man["files"] = [e for e in man["files"] if e["path"] == F]
    case("err_missing_biomes", [E("E_REQUIRED", M, "/files")],
         mutate=lambda f: f[F]["factions"][1].pop("culture"), files_hook=only_factions)

    def dup_kind(man, blobs):
        blobs["rules/factions2.json"] = blobs[F]
        man["files"].append({"path": "rules/factions2.json", "kind": "factions", "sha256": hashlib.sha256(blobs[F]).hexdigest()})
    case("err_duplicate_kind", [E("E_UNIQUE", M, "/files/5/kind")], files_hook=dup_kind)

    def creature_hook(version, with_id):
        def hook(man, blobs):
            c = dict(CREATURE, formatVersion=version)
            blobs["content/creatures/bete.creature.json"] = dump(c)
            e = {"path": "content/creatures/bete.creature.json", "kind": "creature",
                 "sha256": hashlib.sha256(blobs["content/creatures/bete.creature.json"]).hexdigest()}
            if with_id:
                e["id"] = "bete"
            man["files"].append(e)
        return hook

    def fauna(f):
        f[B]["biomes"][0]["fauna"] = [{"creature": "bete", "weight": 2, "group_size": {"min": 1, "max": 3}}]
    case("ok_creature", [], mutate=fauna, files_hook=creature_hook("1.0", True))
    case("err_creature_without_id", [E("E_REQUIRED", M, "/files/5/id"), E("E_REF", B, "/biomes/0/fauna/0/creature")],
         mutate=fauna, files_hook=creature_hook("1.0", False))
    case("err_creature_version", [E("E_CREATURE", "content/creatures/bete.creature.json", "/formatVersion")],
         mutate=fauna, files_hook=creature_hook("2.0", True))
    case("err_kind_mismatch", [E("E_ENUM", R, "/kind")],
         mutate=lambda f: f[R].update({"kind": "route"}))

    def big_seed(man, blobs):
        man["world"]["seed"] = 2 ** 60
        man["world"]["chunk_size_m"] = 1.5
    case("err_world_numbers", [E("E_MAX", M, "/world/seed"), E("E_TYPE", M, "/world/chunk_size_m")], files_hook=big_seed)

    case("doc_report_ok", [], doc=REPORT)
    bad = copy.deepcopy(REPORT)
    bad["metrics"]["fps"]["avg"] = -1
    del bad["device"]
    bad["metrics"]["systems"].append({"id": "terrain", "avg_ms": 1})
    bad["metrics"]["chunks"]["lod"][1]["level"] = 99
    case("doc_report_bad", [E("E_MIN", "document.json", "/metrics/fps/avg"), E("E_REQUIRED", "document.json", "/device"),
                            E("E_UNIQUE", "document.json", "/metrics/systems/2"),
                            E("E_MAX", "document.json", "/metrics/chunks/lod/1/level")], doc=bad)
    case("doc_unknown_kind", [E("E_KIND", "document.json", "/kind")], doc={"contract_version": V, "kind": "planetes"})
    case("doc_factions_alone", [E("E_REF", "document.json", "/relations/0/to")],
         doc={"contract_version": V, "kind": "factions", "factions": [{"id": "a", "name": "A", "color": "#000000",
              "strength": {"min": 1, "max": 2}, "culture": "hors_fichier"}],
              "relations": [{"from": "a", "to": "zz", "value": 0, "stance": "neutre"}]})
    case("doc_bad_json", [E("E_JSON", "document.json", "")], doc=b"{ pas du json")
    case("doc_types_strict", [E("E_TYPE", "document.json", "/factions/0/strength/max"), E("E_TYPE", "document.json", "/relations/0/value")],
         doc={"contract_version": V, "kind": "factions", "factions": [{"id": "a", "name": "A", "color": "#000000",
              "strength": {"min": 1, "max": True}}, {"id": "b", "name": "B", "color": "#000000", "strength": {"min": 1, "max": 2}}],
              "relations": [{"from": "a", "to": "b", "value": "10", "stance": "neutre"}]})

    # JSON STRICT (SPEC §3) : ce que le JSON de Godot accepterait mais que le contrat refuse
    fac = json.dumps({"contract_version": V, "kind": "factions", "factions": [
        {"id": "a", "name": "A", "color": "#000000", "strength": {"min": 1, "max": 2}}]})
    J = "document.json"
    for name, raw, exp in [
        ("json_trailing_comma", fac[:-2] + ",]}", [E("E_JSON", J, "")]),
        ("json_nan", fac.replace('"max": 2', '"max": NaN'), [E("E_JSON", J, "")]),
        ("json_bom", "\ufeff" + fac, [E("E_JSON", J, "")]),
        ("json_leading_zero", fac.replace('"max": 2', '"max": 02'), [E("E_JSON", J, "")]),
        ("json_dot_number", fac.replace('"max": 2', '"max": 2.'), [E("E_JSON", J, "")]),
        ("json_control_char", fac.replace('"A"', '"A\tB"'), [E("E_JSON", J, "")]),
        ("json_comment", "// note\n" + fac, [E("E_JSON", J, "")]),
        ("json_lone_surrogate", fac.replace('"A"', '"\\ud83e"'), [E("E_JSON", J, "")]),
        ("json_surrogate_pair_ok", fac.replace('"A"', '"\\ud83e\\udd89"'), []),
        ("json_duplicate_key_last_wins", fac.replace('"name": "A"', '"name": "A", "name": ""'), [E("E_LENGTH", J, "/factions/0/name")]),
        ("json_huge_exponent", fac.replace('"max": 2', '"max": 1e400'), [E("E_TYPE", J, "/factions/0/strength/max")]),
    ]:
        case(name, exp, doc=raw.encode("utf-8"))
    case("json_bad_utf8", [E("E_JSON", J, "")], doc=fac.encode()[:-5] + b'\xff\xfe"}]}')

    # ---- contrat 1.1 : maillages .glb (kind « mesh », Modeleur 3D de SBh Studio)
    MP = "content/meshes/tete.glb"

    def mesh_hook(data, with_id=True, twice=False, mesh_id="tete", sign=True, write=True, version=None):
        def hook(man, blobs):
            if version:
                man["contract_version"] = version
            if write:
                blobs[MP] = data
            e = {"path": MP, "kind": "mesh", "sha256": hashlib.sha256(data).hexdigest() if sign else "0" * 64}
            if with_id:
                e["id"] = mesh_id
            man["files"].append(e)
            if twice:
                blobs["content/meshes/tete2.glb"] = data
                man["files"].append({"path": "content/meshes/tete2.glb", "kind": "mesh", "id": mesh_id,
                                     "sha256": hashlib.sha256(data).hexdigest()})
        return hook

    good = glb(TRI)
    case("ok_mesh", [], files_hook=mesh_hook(good))
    case("ok_mesh_contract_1_1", [], files_hook=mesh_hook(good, version="1.1.0"))
    case("ok_mesh_json_only", [], files_hook=mesh_hook(glb({"asset": {"version": "2.0"}}, None)))
    case("err_mesh_without_id", [E("E_REQUIRED", M, "/files/5/id")], files_hook=mesh_hook(good, with_id=False))
    case("err_mesh_duplicate_id", [E("E_UNIQUE", M, "/files/6/id")], files_hook=mesh_hook(good, twice=True))
    case("err_mesh_hash", [E("E_HASH", M, "/files/5/sha256")], files_hook=mesh_hook(good, sign=False))
    case("err_mesh_missing", [E("E_FILE", M, "/files/5/path")], files_hook=mesh_hook(good, write=False))
    for name, data, path in [
        ("err_mesh_magic", glb(TRI, magic=0x12345678), ""),
        ("err_mesh_version1", glb(TRI, version=1), ""),
        ("err_mesh_length", glb(TRI, length_delta=4), ""),
        ("err_mesh_short", b"glTF\x02\x00\x00\x00", ""),
        ("err_mesh_json_bounds", glb(TRI)[:12] + (2 ** 20).to_bytes(4, "little") + glb(TRI)[16:], ""),
        ("err_mesh_bin_bounds", glb(TRI)[:-40] + (999).to_bytes(4, "little") + glb(TRI)[-36:], ""),
        ("err_mesh_json_strict", glb(None, json_raw=b'{"asset":{"version":"2.0"},}'), ""),
        ("err_mesh_json_text", b'{"asset":{"version":"2.0"}}', ""),
        ("err_mesh_asset_version", glb({"asset": {"version": "1.0"}}), "/asset/version"),
        ("err_mesh_no_asset", glb({"scene": 0}), "/asset/version"),
    ]:
        case(name, [E("E_MESH", MP, path)], files_hook=mesh_hook(data))

    (CONF / "expected.json").write_text(json.dumps(EXPECTED, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(f"{len(EXPECTED)} cas écrits")


if __name__ == "__main__":
    main()
