"""Convertit app/src/main/assets/agw/factions.json (ancien format : listes allies / enemies /
neutrals) en fichier de règles du contrat v1 (matrice de relations orientée, valeurs -100..100).

    python3 contract/tools/import_agw_factions.py [sortie.json]

Les valeurs produites sont un POINT DE DÉPART à nuancer : allié → alliance (+60), ennemi →
hostile (−70), neutre → neutre (0). Le texte « culture » de l'ancien format (description libre)
devient la description ; les effectifs n'existent pas dans l'ancien format.
"""
import hashlib, json, pathlib, sys

REPO = pathlib.Path(__file__).resolve().parents[2]
SRC = REPO / "app/src/main/assets/agw/factions.json"


def color(fid):
    h = hashlib.sha256(fid.encode()).hexdigest()
    return "#" + h[:6].upper()


def convert(src=SRC):
    old = json.loads(pathlib.Path(src).read_text(encoding="utf-8"))["factions"]
    factions, relations = [], []
    for f in old:
        name = f.get("name", {})
        d = {"id": f["id"], "name": (name.get("fr") if isinstance(name, dict) else str(name)) or f["id"], "color": color(f["id"])}
        desc = " · ".join(x for x in [f.get("type", ""), f.get("culture", ""), f.get("territory", "")] if x)
        if desc:
            d["description"] = desc[:2000]
        factions.append(d)
        for key, stance, value in [("allies", "alliance", 60), ("enemies", "hostile", -70), ("neutrals", "neutre", 0)]:
            for other in f.get(key, []):
                relations.append({"from": f["id"], "to": other, "value": value, "stance": stance,
                                  "note": f"importé de agw/factions.json ({key}) — à nuancer"})
    return {"contract_version": "1.0.0", "kind": "factions", "factions": factions, "relations": relations}


if __name__ == "__main__":
    out = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else REPO / "contract/examples/import_agw/factions.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(convert(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("écrit :", out)
