#!/usr/bin/env bash
# Vérifie le contrat SBH avec les TROIS validateurs (référence Python, Studio Kotlin, jeu Godot).
# Usage (depuis la racine du dépôt) : bash contract/tools/run_all.sh
#   KOTLINC=/chemin/kotlinc  GODOT=/chemin/godot  pour indiquer les outils s'ils ne sont pas dans le PATH.
set -euo pipefail
cd "$(dirname "$0")/../.."
python3 contract/tools/gen_schemas.py
python3 contract/reference/sbh_contract.py validate contract/examples/al_zahra_mini
python3 contract/reference/sbh_contract.py conformance | tail -1
KOTLINC="${KOTLINC:-$(command -v kotlinc || true)}"
if [ -n "$KOTLINC" ]; then
  out="$(mktemp -d)"
  "$KOTLINC" app/src/main/java/com/sbh/studio/contract/*.kt -d "$out/contract.jar" 2>/dev/null
  (cd app && "$(dirname "$KOTLINC")/kotlin" -cp "$out/contract.jar" com.sbh.studio.contract.ContractConformance ../contract | tail -1)
else echo "kotlinc absent : validateur Kotlin non testé ici (il l'est par ./gradlew testDebugUnitTest)"; fi
GODOT="${GODOT:-$(command -v godot || true)}"
if [ -n "$GODOT" ]; then
  (cd contract/godot && "$GODOT" --headless --path . -s tests/run_conformance.gd -- "$(cd .. && pwd)" 2>/dev/null | grep -E "cas conformes|KO")
else echo "godot absent : validateur Godot non testé ici"; fi
