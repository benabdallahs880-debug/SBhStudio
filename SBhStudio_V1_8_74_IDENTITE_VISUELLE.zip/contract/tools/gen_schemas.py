"""Génère contract/schemas/*.schema.json (SBH Data Contract v1).

Les schémas sont écrits ici, en un seul endroit, puis écrits en JSON Schema (2020-12) limité au
« sous-ensemble SBH » que les trois validateurs (Python, Kotlin, GDScript) savent lire :
type, required, properties, items, enum, const, minimum, maximum, minLength, maxLength, pattern,
minItems, maxItems, $ref "#/$defs/…", et les mots-clés SBH x-id, x-ref, x-range, x-unique-key,
x-distinct (voir SPEC §4). Relancer après toute modification :
    python3 contract/tools/gen_schemas.py
"""
import json, pathlib

OUT = pathlib.Path(__file__).resolve().parents[1] / "schemas"
VERSION = "1.0.0"
MAX_SAFE = 9007199254740991

DEFS = {
    "id": {"type": "string", "pattern": "^[a-z][a-z0-9_]{0,47}$", "description": "Identifiant : minuscules, chiffres, _ ; 1 à 48 caractères ; commence par une lettre."},
    "name": {"type": "string", "minLength": 1, "maxLength": 80},
    "text": {"type": "string", "maxLength": 2000},
    "color": {"type": "string", "pattern": "^#[0-9a-fA-F]{6}$"},
    "version": {"type": "string", "pattern": "^[0-9]+\\.[0-9]+\\.[0-9]+$"},
    "path": {"type": "string", "minLength": 1, "maxLength": 200, "pattern": "^[a-z0-9_][a-z0-9_./-]*$"},
}

def ref(n): return {"$ref": f"#/$defs/{n}"}
def num(lo, hi, integer=False): return {"type": "integer" if integer else "number", "minimum": lo, "maximum": hi}
def rng(lo, hi, integer=False, desc=None):
    o = {"type": "object", "x-range": True, "required": ["min", "max"],
         "properties": {"min": num(lo, hi, integer), "max": num(lo, hi, integer)}}
    if desc: o["description"] = desc
    return o
def obj(props, required=None, **extra):
    o = {"type": "object", "properties": props}
    if required: o["required"] = required
    o.update(extra); return o
def arr(items, **extra):
    o = {"type": "array", "items": items}; o.update(extra); return o
def id_def(table): return {"$ref": "#/$defs/id", "x-id": table}
def id_ref(table): return {"$ref": "#/$defs/id", "x-ref": table}

def doc(kind, title, desc, props, required):
    base = {"contract_version": ref("version"), "kind": {"type": "string", "const": kind}}
    base.update(props)
    return {"$schema": "https://json-schema.org/draft/2020-12/schema",
            "$id": f"https://sbh-world/contract/v1/{kind}.schema.json",
            "title": title, "description": desc, "x-contract": VERSION,
            "type": "object", "required": ["contract_version", "kind"] + required,
            "properties": base, "$defs": DEFS}

FILE_KINDS = ["biomes", "cultures", "settlements", "roads", "factions", "creature", "structure", "mesh"]   # mesh : contrat 1.1

SCHEMAS = {
 "world": doc("world", "Manifeste d'un monde SBH (sbh_world.json)",
  "Point d'entrée d'un paquet de monde : identité, graine, taille et liste signée des fichiers.",
  {"world": obj({
      "id": ref("id"), "name": ref("name"),
      "seed": num(0, MAX_SAFE, True),
      "size_chunks": obj({"x": num(1, 4096, True), "z": num(1, 4096, True)}, ["x", "z"]),
      "chunk_size_m": num(8, 256, True),
      "sea_level_m": num(-1000, 1000),
      "description": ref("text")},
      ["id", "name", "seed", "size_chunks", "chunk_size_m"]),
   "generator": obj({"name": ref("name"), "version": ref("version")}, ["name", "version"]),
   "created_by": obj({"tool": ref("name"), "version": ref("version")}, ["tool", "version"]),
   "files": arr(obj({"path": ref("path"), "kind": {"type": "string", "enum": FILE_KINDS},
                      "id": ref("id"), "sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"}},
                     ["path", "kind", "sha256"]),
                minItems=1, maxItems=4096, **{"x-unique-key": ["path"]})},
  ["world", "generator", "created_by", "files"]),

 "biomes": doc("biomes", "Biomes", "Climat, relief, faune, ressources et végétation de chaque biome.",
  {"biomes": arr(obj({
      "id": id_def("biomes"), "name": ref("name"), "color": ref("color"),
      "temperature_c": rng(-60, 60, desc="Température moyenne annuelle (°C)."),
      "humidity": rng(0, 1, desc="Humidité relative (0 = sec, 1 = saturé)."),
      "elevation_m": rng(-1000, 9000, desc="Altitude (m) où le biome peut apparaître."),
      "fauna": arr(obj({"creature": id_ref("creatures"), "weight": num(0, 1000),
                        "group_size": rng(1, 100, True)}, ["creature", "weight"]), maxItems=64),
      "resources": arr(obj({"id": ref("id"), "abundance": num(0, 1)}, ["id", "abundance"]), maxItems=64),
      "vegetation": arr(obj({"id": ref("id"), "density": num(0, 1)}, ["id", "density"]), maxItems=64),
      "notes": ref("text")},
      ["id", "name", "color", "temperature_c", "humidity", "elevation_m"]), minItems=1, maxItems=256)},
  ["biomes"]),

 "cultures": doc("cultures", "Cultures architecturales",
  "Chaque culture : biomes où elle vit, matériaux, familles de bâtiments et leurs variantes.",
  {"cultures": arr(obj({
      "id": id_def("cultures"), "name": ref("name"),
      "biomes": arr(id_ref("biomes"), minItems=1, maxItems=64),
      "materials": arr(ref("id"), maxItems=64),
      "building_families": arr(obj({
          "id": id_def("building_families"), "name": ref("name"),
          "role": {"type": "string", "enum": ["habitation", "religieux", "commerce", "defense", "artisanat", "agriculture", "pouvoir", "autre"]},
          "variants": arr(obj({
              "id": id_def("building_variants"), "name": ref("name"),
              "footprint_m": obj({"w": num(2, 200), "d": num(2, 200)}, ["w", "d"]),
              "floors": rng(1, 20, True), "weight": num(0, 1000),
              "structure": {"$ref": "#/$defs/path", "x-ref": "structures"}}, ["id", "name", "footprint_m", "floors", "weight"]),
              minItems=1, maxItems=64)},
          ["id", "name", "role", "variants"]), minItems=1, maxItems=128),
      "notes": ref("text")},
      ["id", "name", "biomes", "building_families"]), minItems=1, maxItems=64)},
  ["cultures"]),

 "settlements": doc("settlements", "Établissements (règles d'installation et d'organisation)",
  "Types d'établissements : où ils s'installent, comment ils s'organisent, de quoi ils sont faits, comment ils grandissent.",
  {"settlement_types": arr(obj({
      "id": id_def("settlement_types"), "name": ref("name"),
      "culture": id_ref("cultures"),
      "size": {"type": "string", "enum": ["hameau", "village", "bourg", "ville", "capitale"]},
      "population": rng(1, 1000000, True),
      "placement": obj({
          "biomes": arr(id_ref("biomes"), minItems=1, maxItems=64),
          "near_water": {"type": "boolean"},
          "max_slope_deg": num(0, 60),
          "min_distance_m": num(0, 100000),
          "elevation_m": rng(-1000, 9000)}, ["biomes", "min_distance_m"]),
      "layout": {"type": "string", "enum": ["organique", "grille", "radial", "lineaire", "fortifie"]},
      "buildings": arr(obj({"family": id_ref("building_families"), "count": rng(0, 10000, True)},
                           ["family", "count"]), minItems=1, maxItems=128, **{"x-unique-key": ["family"]}),
      "walls": {"type": "boolean"},
      "growth": obj({"per_year": num(0, 1), "max_population": num(1, 10000000, True)}, ["per_year"])},
      ["id", "name", "culture", "size", "population", "placement", "layout", "buildings"]), minItems=1, maxItems=128)},
  ["settlement_types"]),

 "roads": doc("roads", "Routes", "Types de routes et règles du réseau.",
  {"road_types": arr(obj({
      "id": id_def("road_types"), "name": ref("name"),
      "width_m": num(0.5, 50),
      "surface": {"type": "string", "enum": ["terre", "pierre", "pavee", "sable", "rail"]},
      "max_slope_deg": num(0, 60),
      "connects": arr(id_ref("settlement_types"), minItems=1, maxItems=32)},
      ["id", "name", "width_m", "surface", "connects"]), minItems=1, maxItems=64),
   "network": obj({"max_length_km": num(0, 10000), "follow_rivers": {"type": "boolean"},
                   "avoid_biomes": arr(id_ref("biomes"), maxItems=64)})},
  ["road_types"]),

 "factions": doc("factions", "Factions et matrice de relations",
  "Factions du monde et relations orientées (ce que « from » pense de « to »), plus nuancées qu'ami / ennemi.",
  {"factions": arr(obj({
      "id": id_def("factions"), "name": ref("name"), "color": ref("color"),
      "culture": id_ref("cultures"),
      "strength": rng(0, 100000000, True, "Effectifs (combattants)."),
      "home_biomes": arr(id_ref("biomes"), maxItems=64),
      "description": ref("text")},
      ["id", "name", "color"]), minItems=1, maxItems=128),
   "relations": arr(obj({
      "from": id_ref("factions"), "to": id_ref("factions"),
      "value": num(-100, 100, True),
      "stance": {"type": "string", "enum": ["alliance", "amical", "neutre", "mefiant", "hostile", "guerre"]},
      "note": ref("text")}, ["from", "to", "value", "stance"], **{"x-distinct": ["from", "to"]}),
      maxItems=16384, **{"x-unique-key": ["from", "to"]})},
  ["factions"]),

 "test_report": doc("test_report", "Rapport de test (labo)",
  "Mesures d'une session de test du monde sur un appareil réel, à envoyer pour analyse.",
  {"report_id": {"type": "string", "pattern": "^[A-Za-z0-9_-]{1,64}$"},
   "created_at": {"type": "string", "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\\.[0-9]+)?(Z|[+-][0-9]{2}:[0-9]{2})$"},
   "app": obj({"name": ref("name"), "version": ref("version")}, ["name", "version"]),
   "device": obj({"model": ref("name"), "os": ref("name"), "gpu": ref("name"),
                  "ram_mb": num(0, 1000000, True),
                  "screen": obj({"width_px": num(1, 20000, True), "height_px": num(1, 20000, True),
                                 "density": num(0.5, 10)}, ["width_px", "height_px"])},
                 ["model", "os"]),
   "world": obj({"id": ref("id"), "seed": num(0, MAX_SAFE, True), "contract_version": ref("version")},
                ["id", "seed", "contract_version"]),
   "scenario": obj({"name": ref("name"), "duration_s": num(0, 86400)}, ["name", "duration_s"]),
   "metrics": obj({
      "fps": obj({k: num(0, 1000) for k in ["min", "avg", "p1", "p50", "p95"]}, ["min", "avg"]),
      "frame_ms": obj({k: num(0, 100000) for k in ["avg", "p95", "p99"]}, ["avg"]),
      "memory_mb": obj({k: num(0, 1000000) for k in ["start", "peak", "end"]}, ["peak"]),
      "systems": arr(obj({"id": ref("id"), "name": ref("name"), "avg_ms": num(0, 1000000),
                          "max_ms": num(0, 1000000), "calls": num(0, MAX_SAFE, True)}, ["id", "avg_ms"]),
                     maxItems=256, **{"x-unique-key": ["id"]}),
      "chunks": obj({"loaded": num(0, 10000000, True), "detailed": num(0, 10000000, True),
                     "abstract": num(0, 10000000, True),
                     "lod": arr(obj({"level": num(0, 16, True), "count": num(0, 10000000, True)}, ["level", "count"]),
                                maxItems=17, **{"x-unique-key": ["level"]})})},
      ["fps", "memory_mb"]),
   "events": arr(obj({"t_s": num(0, 86400), "level": {"type": "string", "enum": ["info", "warning", "error"]},
                      "message": ref("text")}, ["t_s", "level", "message"]), maxItems=10000)},
  ["report_id", "created_at", "app", "device", "world", "scenario", "metrics"]),
}

# Copies identiques pour le Studio (assets Android) et le jeu (addon Godot) : un seul contrat.
REPO = OUT.parents[1]
COPIES = [REPO / "app/src/main/assets/contract/schemas", OUT.parent / "godot/addons/sbh_contract/schemas"]

if __name__ == "__main__":
    for d in [OUT] + COPIES:
        d.mkdir(parents=True, exist_ok=True)
        for k, s in SCHEMAS.items():
            (d / f"{k}.schema.json").write_text(json.dumps(s, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("schémas écrits :", ", ".join(sorted(SCHEMAS)), "→", len(COPIES) + 1, "emplacements")
