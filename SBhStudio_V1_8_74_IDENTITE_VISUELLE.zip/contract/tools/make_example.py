"""Écrit les fichiers de règles du monde d'exemple contract/examples/al_zahra_mini/ (SBH Data Contract v1).

Valeurs d'EXEMPLE (à ajuster) reprises de la bible SBH World quand elle les donne (factions,
effectifs, QG des Hiboux en montagne, bases des Templiers accordées par le roi). Ensuite :
    python3 contract/reference/sbh_contract.py manifest contract/examples/al_zahra_mini
"""
import json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1] / "examples" / "al_zahra_mini"
V = "1.0.0"


def w(rel, o):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(o, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def rng(a, b):
    return {"min": a, "max": b}


w("rules/biomes.json", {"contract_version": V, "kind": "biomes", "biomes": [
    {"id": "desert_sable", "name": "Désert de sable", "color": "#D8B970", "temperature_c": rng(18, 42),
     "humidity": rng(0.02, 0.2), "elevation_m": rng(0, 900),
     "fauna": [{"creature": "quadrupede_demo", "weight": 3, "group_size": rng(1, 4)}],
     "resources": [{"id": "sel", "abundance": 0.4}, {"id": "nrj_noire", "abundance": 0.05}],
     "vegetation": [{"id": "palmier_dattier", "density": 0.02}],
     "notes": "Exemple : valeurs à ajuster."},
    {"id": "oasis", "name": "Oasis", "color": "#5FA35A", "temperature_c": rng(16, 36), "humidity": rng(0.35, 0.7),
     "elevation_m": rng(0, 600), "resources": [{"id": "eau_douce", "abundance": 0.9}],
     "vegetation": [{"id": "palmier_dattier", "density": 0.6}]},
    {"id": "montagnes", "name": "Montagnes", "color": "#8A7F72", "temperature_c": rng(-10, 22), "humidity": rng(0.2, 0.6),
     "elevation_m": rng(900, 3200), "resources": [{"id": "fer", "abundance": 0.5}, {"id": "pierre", "abundance": 0.9}],
     "notes": "Le QG des Hiboux est en montagne."}]})

w("rules/cultures.json", {"contract_version": V, "kind": "cultures", "cultures": [
    {"id": "bedouine", "name": "Bédouine", "biomes": ["desert_sable", "oasis"], "materials": ["tissu", "bois_palmier"],
     "building_families": [{"id": "tente_bedouine", "name": "Tente bédouine", "role": "habitation", "variants": [
         {"id": "tente_petite", "name": "Petite tente", "footprint_m": {"w": 4, "d": 5}, "floors": rng(1, 1), "weight": 3},
         {"id": "tente_chef", "name": "Tente du chef", "footprint_m": {"w": 8, "d": 10}, "floors": rng(1, 1), "weight": 1}]}]},
    {"id": "citadine_royale", "name": "Citadine royale", "biomes": ["oasis", "desert_sable", "montagnes"],
     "materials": ["pierre", "brique_crue"],
     "building_families": [
         {"id": "maison_pise", "name": "Maison en pisé", "role": "habitation", "variants": [
             {"id": "maison_pise_simple", "name": "Maison simple", "footprint_m": {"w": 7, "d": 8}, "floors": rng(1, 2), "weight": 5},
             {"id": "maison_pise_cour", "name": "Maison à cour", "footprint_m": {"w": 12, "d": 12}, "floors": rng(2, 3), "weight": 2}]},
         {"id": "mosquee", "name": "Mosquée", "role": "religieux", "variants": [
             {"id": "mosquee_quartier", "name": "Mosquée de quartier", "footprint_m": {"w": 16, "d": 20}, "floors": rng(1, 2), "weight": 1}]},
         {"id": "forge", "name": "Forge", "role": "artisanat", "variants": [
             {"id": "maison_forgeron", "name": "Maison de forgeron", "footprint_m": {"w": 15, "d": 20}, "floors": rng(1, 2),
              "weight": 1, "structure": "content/structures/structure_maison_forgeron.json"}]},
         {"id": "caserne", "name": "Caserne royale", "role": "defense", "variants": [
             {"id": "caserne_petite", "name": "Petite caserne", "footprint_m": {"w": 20, "d": 30}, "floors": rng(1, 2), "weight": 1}]}]}]})

w("rules/settlements.json", {"contract_version": V, "kind": "settlements", "settlement_types": [
    {"id": "campement_bedouin", "name": "Campement bédouin", "culture": "bedouine", "size": "hameau", "population": rng(15, 80),
     "placement": {"biomes": ["desert_sable", "oasis"], "near_water": False, "max_slope_deg": 8, "min_distance_m": 1500},
     "layout": "organique", "buildings": [{"family": "tente_bedouine", "count": rng(4, 20)}], "walls": False,
     "growth": {"per_year": 0.0}},
    {"id": "village_oasis", "name": "Village d'oasis", "culture": "citadine_royale", "size": "village", "population": rng(120, 900),
     "placement": {"biomes": ["oasis"], "near_water": True, "max_slope_deg": 10, "min_distance_m": 3000, "elevation_m": rng(0, 600)},
     "layout": "organique", "buildings": [{"family": "maison_pise", "count": rng(15, 90)}, {"family": "mosquee", "count": rng(1, 1)},
                                          {"family": "forge", "count": rng(0, 2)}],
     "walls": False, "growth": {"per_year": 0.012, "max_population": 2500}},
    {"id": "ville_royale", "name": "Ville royale", "culture": "citadine_royale", "size": "ville", "population": rng(3000, 40000),
     "placement": {"biomes": ["oasis", "desert_sable"], "near_water": True, "max_slope_deg": 6, "min_distance_m": 20000},
     "layout": "fortifie", "buildings": [{"family": "maison_pise", "count": rng(300, 4000)}, {"family": "mosquee", "count": rng(3, 40)},
                                         {"family": "forge", "count": rng(2, 30)}, {"family": "caserne", "count": rng(1, 6)}],
     "walls": True, "growth": {"per_year": 0.008, "max_population": 120000}}]})

w("rules/roads.json", {"contract_version": V, "kind": "roads", "road_types": [
    {"id": "piste", "name": "Piste", "width_m": 3, "surface": "sable", "max_slope_deg": 20, "connects": ["campement_bedouin", "village_oasis"]},
    {"id": "route_royale", "name": "Route royale", "width_m": 8, "surface": "pavee", "max_slope_deg": 10, "connects": ["village_oasis", "ville_royale"]}],
    "network": {"max_length_km": 400, "follow_rivers": True, "avoid_biomes": ["montagnes"]}})

w("rules/factions.json", {"contract_version": V, "kind": "factions", "factions": [
    {"id": "hibou", "name": "Hiboux", "color": "#2E3A59", "strength": rng(4000, 6000), "home_biomes": ["montagnes"],
     "description": "Résistance, légère et rapide. QG en montagne."},
    {"id": "royaume", "name": "Royaume", "color": "#B8892B", "culture": "citadine_royale", "strength": rng(20000, 30000),
     "home_biomes": ["oasis", "desert_sable"]},
    {"id": "templiers", "name": "Templiers", "color": "#8C1C13", "strength": rng(1000, 5000), "description": "Bases accordées par le roi."},
    {"id": "ghurab", "name": "Ghurab (Corbeaux)", "color": "#1B1B1B", "strength": rng(1500, 2500)},
    {"id": "vautours", "name": "Vautours", "color": "#5A3E2B", "strength": rng(800, 2000),
     "description": "Criminels ; certains travaillent pour l'État."},
    {"id": "bedouins", "name": "Bédouins", "color": "#C9A227", "culture": "bedouine", "strength": rng(500, 3000),
     "home_biomes": ["desert_sable", "oasis"]}],
    "relations": [
        {"from": "hibou", "to": "royaume", "value": -100, "stance": "guerre", "note": "Guerre frontale directe."},
        {"from": "royaume", "to": "hibou", "value": -100, "stance": "guerre"},
        {"from": "hibou", "to": "templiers", "value": -100, "stance": "guerre"},
        {"from": "royaume", "to": "templiers", "value": 70, "stance": "alliance", "note": "Exemple : le roi leur accorde des bases."},
        {"from": "templiers", "to": "royaume", "value": 40, "stance": "amical", "note": "Exemple : intérêt plus que loyauté (à ajuster)."},
        {"from": "royaume", "to": "vautours", "value": -10, "stance": "mefiant", "note": "Exemple : certains Vautours travaillent pour l'État."},
        {"from": "hibou", "to": "vautours", "value": -30, "stance": "mefiant", "note": "Les Hiboux n'attaquent pas en premier une autre faction."},
        {"from": "hibou", "to": "bedouins", "value": 30, "stance": "amical"}]})

w("sbh_world.json", {"contract_version": "1.1.0", "kind": "world",
    "world": {"id": "al_zahra_mini", "name": "Al-Zahra (mini)", "seed": 1337, "size_chunks": {"x": 64, "z": 64},
              "chunk_size_m": 32, "sea_level_m": 0, "description": "Petit monde d'exemple du contrat v1."},
    "generator": {"name": "SBH World generator", "version": "0.1.0"},
    "created_by": {"tool": "SBh Studio", "version": "1.8.65"},
    "files": [{"path": p, "kind": k, "sha256": "0" * 64} for p, k in [
        ("rules/biomes.json", "biomes"), ("rules/cultures.json", "cultures"), ("rules/settlements.json", "settlements"),
        ("rules/roads.json", "roads"), ("rules/factions.json", "factions")]] +
             [{"path": "content/creatures/quadrupede_demo.creature.json", "kind": "creature", "id": "quadrupede_demo", "sha256": "0" * 64},
              {"path": "content/structures/structure_maison_forgeron.json", "kind": "structure", "sha256": "0" * 64},
              # contrat 1.1 : maillage .glb du Modeleur 3D (écrit par tools/meshstudio/test_mesh_core.mjs)
              {"path": "content/meshes/tete_demo.glb", "kind": "mesh", "id": "tete_demo", "sha256": "0" * 64}]})
print("exemple écrit :", ROOT)
