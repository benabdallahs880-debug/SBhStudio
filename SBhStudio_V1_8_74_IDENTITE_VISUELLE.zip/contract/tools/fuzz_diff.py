"""Test différentiel : N variantes aléatoires de l'exemple, résultats attendus = référence Python.
Ensuite les validateurs Kotlin et Godot doivent donner exactement les mêmes résultats :
    python3 contract/tools/fuzz_diff.py <dossier_sortie> 500
    (cd app && kotlin -cp contract.jar com.sbh.studio.contract.ContractConformance <dossier_sortie>)
    godot --headless --path contract/godot -s tests/run_conformance.gd -- <dossier_sortie>
Le dossier de sortie doit contenir des liens schemas/ et examples/ vers contract/ (créés automatiquement)."""
import json, random, copy, shutil, pathlib, hashlib, sys, os
HERE = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / 'reference')); import sbh_contract as sc
FZ = pathlib.Path(sys.argv[1]); N = int(sys.argv[2]); rnd = random.Random(7)
SRC = HERE / 'examples' / 'al_zahra_mini'
(FZ / 'conformance' / 'cases').mkdir(parents=True, exist_ok=True)
for n in ('schemas', 'examples'):
    if not (FZ / n).exists(): os.symlink(HERE / n, FZ / n)
VALS = [None, True, False, 0, -1, 1.5, 2**60, 1e308, "", "x", "Désert", "🦉"*90, "#ZZZZZZ", "a"*49, "desert\nx", "é"*200, "rules/../x.json", "/abs.json", 9007199254740992, -0.0, 1e-9, "1.0.0", "9.9.9", [], {}, [1, 2], {"min": 5, "max": 1}, "desert_sable", "hibou", "inconnu"]
def nodes(o, path=()):
    yield path, o
    if isinstance(o, dict):
        for k, v in o.items(): yield from nodes(v, path + (k,))
    elif isinstance(o, list):
        for i, v in enumerate(o): yield from nodes(v, path + (i,))
def setp(o, path, v):
    for p in path[:-1]: o = o[p]
    o[path[-1]] = v
def delp(o, path):
    for p in path[:-1]: o = o[p]
    del o[path[-1]]
for n in range(N):
    d = FZ / 'conformance/cases' / f'f{n:04d}'; shutil.copytree(SRC, d)
    files = sorted(d.glob('rules/*.json')) + [d / 'sbh_world.json']
    for _ in range(rnd.randint(1, 4)):
        f = rnd.choice(files); doc = json.loads(f.read_text())
        ps = [p for p, _ in nodes(doc) if p]
        p = rnd.choice(ps); op = rnd.random()
        try:
            if op < 0.55: setp(doc, p, copy.deepcopy(rnd.choice(VALS)))
            elif op < 0.8: delp(doc, p)
            else:
                parent = doc
                for q in p[:-1]: parent = parent[q]
                if isinstance(parent, list): parent.append(copy.deepcopy(parent[p[-1]]))
                elif isinstance(parent, dict): parent['champ_' + str(rnd.randint(0, 9))] = 1
        except Exception: pass
        f.write_text(json.dumps(doc, ensure_ascii=False, indent=1))
    g = d / 'content/meshes/tete_demo.glb'   # contrat 1.1 : abîmer aussi le maillage .glb
    if g.is_file() and rnd.random() < 0.35:
        b = bytearray(g.read_bytes()); r = rnd.random()
        if r < 0.4:
            for _ in range(rnd.randint(1, 3)): b[rnd.choice([0, 4, 8, 12, 16, 20, 21, 30, len(b) - 1, rnd.randrange(len(b))])] ^= 1 << rnd.randrange(8)
        elif r < 0.7: b = b[:rnd.randrange(len(b))]
        else: b += bytes(rnd.randint(1, 8))
        g.write_bytes(bytes(b))
    if rnd.random() < 0.7:
        try:   # re-signer seulement si tous les chemins du manifeste sont des fichiers lisibles
            if (d/'sbh_world.json').exists() and isinstance(json.loads((d/'sbh_world.json').read_text()).get('files'), list) and all(isinstance(e, dict) and isinstance(e.get('path'), str) and (d / e['path']).is_file() and '..' not in e['path'] for e in json.loads((d/'sbh_world.json').read_text())['files']): sc.write_manifest_hashes(d)
        except OSError: pass
schemas = sc.load_schemas()
exp = {c.name: sc.triples(sc.validate_package(c, schemas)) for c in sorted((FZ / 'conformance/cases').iterdir())}
(FZ / 'conformance/expected.json').write_text(json.dumps(exp, ensure_ascii=False))
print(N, 'variantes ; erreurs moyennes', sum(len(v) for v in exp.values()) / N)
