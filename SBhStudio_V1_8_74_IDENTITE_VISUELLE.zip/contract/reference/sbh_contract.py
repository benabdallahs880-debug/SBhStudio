#!/usr/bin/env python3
"""SBH Data Contract v1 — validateur de RÉFÉRENCE (Python 3, sans dépendance).

C'est la définition exécutable du contrat : les validateurs Kotlin (SBh Studio) et GDScript
(jeu Godot) doivent donner EXACTEMENT les mêmes résultats sur contract/conformance/ (voir SPEC §8).

Usage :
    python3 contract/reference/sbh_contract.py validate <dossier_monde | fichier.json>
    python3 contract/reference/sbh_contract.py manifest <dossier_monde>      # recalcule les sha256
    python3 contract/reference/sbh_contract.py conformance [--write]         # cas de conformité
Code de sortie : 0 = valide (avertissements possibles), 1 = erreurs, 2 = usage.
"""
import hashlib
import json
import pathlib
import re
import sys

CONTRACT_MAJOR, CONTRACT_MINOR = 1, 1
HERE = pathlib.Path(__file__).resolve().parent
SCHEMA_DIR = HERE.parent / "schemas"
RULE_KINDS = ["biomes", "cultures", "settlements", "roads", "factions"]
DOC_KINDS = RULE_KINDS + ["world", "test_report"]
SEMVER = re.compile(r"^([0-9]+)\.([0-9]+)\.([0-9]+)$")
SHA = re.compile(r"^[0-9a-f]{64}$")
PATH = re.compile(r"^[a-z0-9_][a-z0-9_./-]*$")


def load_schemas(directory=SCHEMA_DIR):
    return {k: json.loads((pathlib.Path(directory) / f"{k}.schema.json").read_text(encoding="utf-8")) for k in DOC_KINDS}


class Ctx:
    def __init__(self):
        self.issues = []
        self.ids = {}      # table -> set
        self.refs = []     # (table, value, file, path)

    def add(self, sev, code, file, path, msg):
        self.issues.append({"severity": sev, "code": code, "file": file, "path": path, "message": msg})

    def err(self, code, file, path, msg):
        self.add("error", code, file, path, msg)


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _type_ok(v, t):
    if t == "object": return isinstance(v, dict)
    if t == "array": return isinstance(v, list)
    if t == "string": return isinstance(v, str)
    if t == "boolean": return isinstance(v, bool)
    if t == "number": return _is_num(v)
    if t == "integer": return _is_num(v) and float(v).is_integer()
    return True


def _resolve(schema, root):
    if "$ref" not in schema:
        return schema
    name = schema["$ref"].split("/")[-1]
    out = dict(root["$defs"][name])
    out.update({k: v for k, v in schema.items() if k != "$ref"})
    return out


def _same(a, b):
    """Égalité JSON (1 == 1.0, mais True != 1)."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if _is_num(a) and _is_num(b):
        return float(a) == float(b)
    return type(a) == type(b) and a == b


def _key(v):
    return json.dumps(v, sort_keys=True, ensure_ascii=False) if not _is_num(v) else repr(float(v))


def check(v, schema, root, path, file, ctx):
    s = _resolve(schema, root)
    t = s.get("type")
    if t is not None and not _type_ok(v, t):
        ctx.err("E_TYPE", file, path, f"type attendu : {t}")
        return
    if "const" in s and not _same(v, s["const"]):
        ctx.err("E_ENUM", file, path, f"valeur attendue : {s['const']!r}")
    if "enum" in s and not any(_same(v, e) for e in s["enum"]):
        ctx.err("E_ENUM", file, path, "valeur hors liste : " + ", ".join(map(str, s["enum"])))
    if isinstance(v, str):
        n = len(v)  # points de code Unicode
        if ("minLength" in s and n < s["minLength"]) or ("maxLength" in s and n > s["maxLength"]):
            ctx.err("E_LENGTH", file, path, f"longueur {n} hors limites")
        if "pattern" in s and re.search(s["pattern"], v) is None:
            ctx.err("E_PATTERN", file, path, f"format invalide (attendu {s['pattern']})")
        if "x-id" in s:
            table = ctx.ids.setdefault(s["x-id"], set())
            if v in table:
                ctx.err("E_UNIQUE", file, path, f"identifiant « {v} » déjà utilisé ({s['x-id']})")
            else:
                table.add(v)
        if "x-ref" in s:
            ctx.refs.append((s["x-ref"], v, file, path))
    if _is_num(v):
        if "minimum" in s and v < s["minimum"]:
            ctx.err("E_MIN", file, path, f"minimum {s['minimum']}")
        if "maximum" in s and v > s["maximum"]:
            ctx.err("E_MAX", file, path, f"maximum {s['maximum']}")
    if isinstance(v, dict):
        props = s.get("properties", {})
        for r in s.get("required", []):
            if r not in v:
                ctx.err("E_REQUIRED", file, f"{path}/{r}", "champ obligatoire manquant")
        for k, sub in v.items():
            if k in props:
                check(sub, props[k], root, f"{path}/{k}", file, ctx)
            elif "properties" in s and not k.startswith("x_"):
                ctx.add("warning", "W_UNKNOWN", file, f"{path}/{k}", "champ inconnu (ignoré par le jeu)")
        if s.get("x-range") and _is_num(v.get("min")) and _is_num(v.get("max")) and v["min"] > v["max"]:
            ctx.err("E_RANGE", file, path, "min > max")
        d = s.get("x-distinct")
        if d and d[0] in v and d[1] in v and _same(v[d[0]], v[d[1]]):
            ctx.err("E_DISTINCT", file, path, f"« {d[0]} » et « {d[1]} » doivent être différents")
    if isinstance(v, list):
        if ("minItems" in s and len(v) < s["minItems"]) or ("maxItems" in s and len(v) > s["maxItems"]):
            ctx.err("E_ITEMS", file, path, f"{len(v)} élément(s) hors limites")
        if "items" in s:
            for i, it in enumerate(v):
                check(it, s["items"], root, f"{path}/{i}", file, ctx)
        uk = s.get("x-unique-key")
        if uk:
            seen = set()
            for i, it in enumerate(v):
                if isinstance(it, dict) and all(k in it for k in uk):
                    key = tuple(_key(it[k]) for k in uk)
                    if key in seen:
                        ctx.err("E_UNIQUE", file, f"{path}/{i}", "doublon (" + ", ".join(uk) + ")")
                    seen.add(key)


def check_version(doc, file, ctx):
    cv = doc.get("contract_version") if isinstance(doc, dict) else None
    m = SEMVER.match(cv) if isinstance(cv, str) else None
    if not m:
        return
    major, minor = int(m.group(1)), int(m.group(2))
    if major != CONTRACT_MAJOR:
        ctx.err("E_VERSION", file, "/contract_version", f"version majeure {major} non prise en charge (attendu {CONTRACT_MAJOR})")
    elif minor > CONTRACT_MINOR:
        ctx.add("warning", "W_NEWER", file, "/contract_version", "version plus récente : champs nouveaux ignorés")


def _reject_constant(name):
    raise ValueError(f"{name} interdit (JSON strict)")


def _no_lone_surrogate(v):
    if isinstance(v, str):
        v.encode("utf-8")  # lève UnicodeEncodeError sur un « \\ud83e » isolé
    elif isinstance(v, dict):
        for k, x in v.items():
            _no_lone_surrogate(k)
            _no_lone_surrogate(x)
    elif isinstance(v, list):
        for x in v:
            _no_lone_surrogate(x)


def _parse(data):
    """JSON STRICT (RFC 8259) : UTF-8 sans BOM, pas de NaN/Infinity, pas de virgule finale, pas de
    commentaire, pas de zéro en tête, pas de caractère de contrôle brut, pas de demi-surrogate."""
    try:
        doc = json.loads(data.decode("utf-8"), parse_constant=_reject_constant)
        _no_lone_surrogate(doc)
        return True, doc
    except Exception:
        return False, None


def resolve_refs(ctx, only_tables=None):
    for table, value, file, path in ctx.refs:
        if only_tables is not None and table not in only_tables:
            continue
        if value not in ctx.ids.get(table, set()):
            ctx.err("E_REF", file, path, f"« {value} » introuvable dans {table}")


def finish(ctx):
    issues = sorted(ctx.issues, key=lambda i: (i["file"], i["path"], i["code"], i["severity"]))
    return {"valid": not any(i["severity"] == "error" for i in issues), "issues": issues}


def validate_document(data, schemas, file="document.json"):
    """Un fichier seul (règles ou rapport de test). Références vérifiées seulement vers les tables
    que ce fichier définit lui-même (ex. relations → factions)."""
    ctx = Ctx()
    ok, doc = _parse(data)
    if not ok:
        ctx.err("E_JSON", file, "", "JSON illisible")
        return finish(ctx)
    kind = doc.get("kind") if isinstance(doc, dict) else None
    if kind not in schemas:
        ctx.err("E_KIND", file, "/kind", "type de document inconnu")
        return finish(ctx)
    check_version(doc, file, ctx)
    check(doc, schemas[kind], schemas[kind], "", file, ctx)
    resolve_refs(ctx, only_tables=set(ctx.ids))
    return finish(ctx)


GLB_MAX = 32 * 1024 * 1024


def glb_problem(data):
    """Contrôle d'un .glb (contrat 1.1, kind « mesh ») : (chemin, message) du 1er problème, ou None."""
    u32 = lambda o: int.from_bytes(data[o:o + 4], "little")
    n = len(data)
    if n > GLB_MAX:
        return "", "fichier trop gros (32 Mo au plus)"
    if n < 20:
        return "", "fichier trop court pour un .glb"
    if u32(0) != 0x46546C67:
        return "", "en-tête « glTF » absent"
    if u32(4) != 2:
        return "", "glTF version 2 attendue"
    if u32(8) != n:
        return "", "longueur annoncée différente de la taille du fichier"
    jlen = u32(12)
    if u32(16) != 0x4E4F534A or jlen == 0 or 20 + jlen > n:
        return "", "bloc JSON absent ou hors du fichier"
    p = 20 + jlen
    if p < n:
        if p + 8 > n:
            return "", "bloc binaire tronqué"
        if u32(p + 4) != 0x004E4942 or p + 8 + u32(p) > n:
            return "", "bloc binaire invalide ou hors du fichier"
    ok, js = _parse(data[20:p])
    if not ok:
        return "", "bloc JSON du .glb illisible (JSON strict)"
    asset = js.get("asset") if isinstance(js, dict) else None
    if not isinstance(asset, dict) or asset.get("version") != "2.0":
        return "/asset/version", "glTF « asset.version » = « 2.0 » attendu"
    return None


def validate_package(root, schemas):
    root = pathlib.Path(root)
    ctx = Ctx()
    mf = "sbh_world.json"
    p = root / mf
    if not p.is_file():
        ctx.err("E_FILE", mf, "", "manifeste sbh_world.json absent")
        return finish(ctx)
    ok, man = _parse(p.read_bytes())
    if not ok:
        ctx.err("E_JSON", mf, "", "JSON illisible")
        return finish(ctx)
    check_version(man, mf, ctx)
    check(man, schemas["world"], schemas["world"], "", mf, ctx)
    files = man.get("files") if isinstance(man, dict) else None
    seen_kinds = set()
    for i, e in enumerate(files if isinstance(files, list) else []):
        if not isinstance(e, dict) or not isinstance(e.get("path"), str) or not isinstance(e.get("kind"), str):
            continue
        rel, kind, base = e["path"], e["kind"], f"/files/{i}"
        if len(rel) > 200 or not PATH.search(rel):
            continue  # chemin déjà signalé par le schéma (E_PATTERN / E_LENGTH) : on ne touche pas au disque
        if rel.startswith("/") or ".." in rel.split("/"):
            ctx.err("E_PATH", mf, base + "/path", "chemin interdit (absolu ou « .. »)")
            continue
        if kind in RULE_KINDS:
            if kind in seen_kinds:
                ctx.err("E_UNIQUE", mf, base + "/kind", f"fichier « {kind} » déjà déclaré")
                continue
            seen_kinds.add(kind)
        elif kind == "creature":
            if "id" not in e:
                ctx.err("E_REQUIRED", mf, base + "/id", "une créature doit avoir un id")
            elif isinstance(e["id"], str):
                t = ctx.ids.setdefault("creatures", set())
                if e["id"] in t:
                    ctx.err("E_UNIQUE", mf, base + "/id", "créature déjà déclarée")
                t.add(e["id"])
        elif kind == "structure":
            ctx.ids.setdefault("structures", set()).add(rel)
        elif kind == "mesh":
            if "id" not in e:
                ctx.err("E_REQUIRED", mf, base + "/id", "un maillage doit avoir un id")
            elif isinstance(e["id"], str):
                t = ctx.ids.setdefault("meshes", set())
                if e["id"] in t:
                    ctx.err("E_UNIQUE", mf, base + "/id", "maillage déjà déclaré")
                t.add(e["id"])
        else:
            continue
        fp = root / rel
        if not fp.is_file():
            ctx.err("E_FILE", mf, base + "/path", f"fichier absent : {rel}")
            continue
        data = fp.read_bytes()
        sha = e.get("sha256")
        if isinstance(sha, str) and SHA.match(sha) and hashlib.sha256(data).hexdigest() != sha:
            ctx.err("E_HASH", mf, base + "/sha256", "empreinte sha256 différente (fichier modifié après signature)")
        if kind == "mesh":   # fichier binaire glTF 2.0 (.glb), pas du JSON
            pb = glb_problem(data)
            if pb:
                ctx.err("E_MESH", rel, pb[0], pb[1])
            continue
        ok, doc = _parse(data)
        if not ok:
            ctx.err("E_JSON", rel, "", "JSON illisible")
            continue
        if kind in RULE_KINDS:
            check_version(doc, rel, ctx)
            check(doc, schemas[kind], schemas[kind], "", rel, ctx)
        elif kind == "creature":
            fv = doc.get("formatVersion") if isinstance(doc, dict) else None
            if not (isinstance(fv, str) and fv.startswith("1.")):
                ctx.err("E_CREATURE", rel, "/formatVersion", "créature CreatureStudio format 1.x attendue")
    if isinstance(files, list) and "biomes" not in seen_kinds:
        ctx.err("E_REQUIRED", mf, "/files", "un fichier de biomes est obligatoire")
    resolve_refs(ctx)
    return finish(ctx)


def validate_path(target, schemas=None):
    schemas = schemas or load_schemas()
    t = pathlib.Path(target)
    if t.is_dir():
        return validate_package(t, schemas)
    return validate_document(t.read_bytes(), schemas, t.name)


def write_manifest_hashes(root):
    root = pathlib.Path(root)
    p = root / "sbh_world.json"
    man = json.loads(p.read_text(encoding="utf-8"))
    for e in man["files"]:
        e["sha256"] = hashlib.sha256((root / e["path"]).read_bytes()).hexdigest()
    p.write_text(json.dumps(man, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


# ---------------------------------------------------------------- conformité
CONF = HERE.parent / "conformance"


def triples(result):
    return [[i["severity"], i["code"], i["file"], i["path"]] for i in result["issues"]]


def run_conformance(write=False):
    schemas = load_schemas()
    cases = sorted(d for d in (CONF / "cases").iterdir() if d.is_dir())
    got = {}
    for d in cases:
        doc = d / "document.json"
        got[d.name] = triples(validate_document(doc.read_bytes(), schemas, "document.json") if doc.is_file() else validate_package(d, schemas))
    exp_file = CONF / "expected.json"
    if write:
        exp_file.write_text(json.dumps(got, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        print(f"{len(got)} cas écrits dans expected.json")
        return 0
    expected = json.loads(exp_file.read_text(encoding="utf-8"))
    bad = 0
    for name in sorted(set(expected) | set(got)):
        if expected.get(name) != got.get(name):
            bad += 1
            print(f"KO {name}\n   attendu : {expected.get(name)}\n   obtenu  : {got.get(name)}")
        else:
            print(f"OK {name}")
    print(f"{len(got) - bad}/{len(got)} cas conformes")
    return 1 if bad else 0


def main(argv):
    if len(argv) >= 2 and argv[1] == "conformance":
        return run_conformance("--write" in argv)
    if len(argv) == 3 and argv[1] == "manifest":
        write_manifest_hashes(argv[2])
        print("sha256 recalculés")
        return 0
    if len(argv) == 3 and argv[1] == "validate":
        r = validate_path(argv[2])
        for i in r["issues"]:
            print(f"{i['severity'][0].upper()} {i['code']:<11} {i['file']}{i['path'] and ' ' + i['path']} — {i['message']}")
        print("VALIDE" if r["valid"] else "INVALIDE", f"({len(r['issues'])} remarque(s))")
        return 0 if r["valid"] else 1
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
