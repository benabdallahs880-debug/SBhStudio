# SBH Data Contract — version 1.1.0

> **1.1.0 (2026-10-06)** : ajoute les maillages 3D `.glb` (`kind: "mesh"`, § 5.7), produits par le Modeleur 3D de SBh Studio. Rien d'autre ne change : un monde 1.0 reste valide.

**Le contrat entre SBh Studio et le jeu SBH World (Godot).**
Le Studio vérifie, versionne et exporte. Le jeu charge. Les deux lisent exactement les mêmes fichiers, avec les mêmes règles. Il n'y a pas de second pipeline : c'est ce qui avait produit les doublons Mobs / Foundation.

> **Sources de vérité, par ordre de priorité**
> 1. Les schémas `contract/schemas/*.schema.json`. Ils sont générés par `contract/tools/gen_schemas.py` : c'est ce fichier qu'on modifie.
> 2. Le validateur de référence `contract/reference/sbh_contract.py`.
> 3. Ce document, qui les explique.
>
> En cas de désaccord entre ce texte et le code, le code de référence fait foi, et ce texte doit être corrigé.

---

## 1. La règle d'or

1. **Un seul format.** Tout ce que le jeu lit sur le monde (règles, contenu, mesures) est décrit ici. Un nouveau besoin se traite en ajoutant un champ ou un fichier au contrat, jamais en créant un format à côté.
2. **Trois validateurs identiques.**
   - Référence : Python.
   - Studio : Kotlin, `app/src/main/java/com/sbh/studio/contract/`.
   - Jeu : GDScript, `contract/godot/addons/sbh_contract/`.

   Ils doivent produire les mêmes résultats sur tous les cas de `contract/conformance/` (§ 8).
3. **Le Studio refuse ce que le jeu refuserait, et inversement.** Un paquet de monde valide pour l'un l'est pour l'autre.

## 2. Le paquet de monde

Un monde est un **dossier**. Le Studio l'exporte en entier ; le jeu le lit, par exemple dans `user://worlds/<id>/`.

```
<monde>/
  sbh_world.json              manifeste : identité, graine, taille, liste SIGNÉE des fichiers
  rules/
    biomes.json               obligatoire
    cultures.json             facultatif
    settlements.json          facultatif
    roads.json                facultatif
    factions.json             facultatif
  content/
    creatures/*.creature.json corps CreatureStudio (format 1.x existant)
    structures/*.json         structures (format StructureLoader existant)
    meshes/*.glb              maillages 3D glTF 2.0 binaires (contrat 1.1, Modeleur 3D)
```

- Seuls les fichiers **listés dans le manifeste** font partie du monde. Chacun y porte son type (`kind`) et son empreinte `sha256` (64 caractères hexadécimaux, en minuscules).
- Un fichier modifié après la signature est refusé avec **E_HASH**. Le Studio signe les fichiers à l'export ; la commande `sbh_contract.py manifest` le fait aussi.
- Un même type de règles ne peut être déclaré qu'**une fois** par monde.
- Les chemins sont relatifs au dossier, en minuscules (`a-z 0-9 _ . / -`), sans `..` et sans `/` au début.
- `content/` est prévu pour s'agrandir : bâtiments, végétation, PNJ (voir § 11).

L'exemple complet, valide et signé se trouve dans `contract/examples/al_zahra_mini/` : 3 biomes, 2 cultures, 3 types d'établissements, 2 routes, 6 factions, 1 créature, 1 structure et, depuis 1.1, 1 maillage `.glb` du Modeleur 3D (`content/meshes/tete_demo.glb`).

## 3. Règles communes à tous les fichiers

**JSON strict (RFC 8259) et UTF-8 sans BOM.** Sont refusés (**E_JSON**) :
- les virgules finales ;
- les commentaires ;
- `NaN` et `Infinity` ;
- les zéros en tête (`02`) et les nombres comme `2.` ;
- les caractères de contrôle bruts dans un texte ;
- les demi-surrogates isolés (`"\ud83e"`) ;
- l'UTF-8 invalide.

Le JSON de Godot accepte plusieurs de ces fautes. Le validateur Godot a donc son propre lecteur strict.

**Doublons et ordre**
- Si une clé apparaît deux fois, **la dernière l'emporte**.
- L'ordre des clés et des listes est conservé.

**Nombres**
- Tous les nombres sont lus comme des flottants 64 bits.
- Un **entier** est un nombre sans partie décimale : `10` et `10.0` sont des entiers, `10.5` n'en est pas un.
- Les entiers sont exacts jusqu'à 2^53 − 1. C'est pourquoi la graine est limitée à 9 007 199 254 740 991.

**Identifiants (`id`)**
- Format `^[a-z][a-z0-9_]{0,47}$` : une lettre minuscule, puis des minuscules, chiffres ou `_`, 48 caractères au plus.
- Un identifiant est unique dans sa table : `biomes`, `cultures`, `building_families`, `building_variants`, `settlement_types`, `road_types`, `factions`, `creatures`.
- On ne change jamais l'identifiant d'un élément publié : les autres fichiers y font référence.

**Textes**
- `name` : 1 à 80 caractères. `notes`, `description` : 2 000 caractères au plus.
- Les longueurs sont comptées en **caractères Unicode** : 🦉 compte pour 1.

**Unités et couleurs**
- Mètres (`_m`), degrés Celsius (`_c`), degrés d'angle (`_deg`), kilomètres (`_km`), secondes (`_s`), millisecondes (`_ms`), mégaoctets (`_mb`).
- Les humidités, densités et abondances vont de 0 à 1.
- Couleurs au format `#RRGGBB`.

**Intervalles**
- Notés `{"min": a, "max": b}`, avec `min ≤ max` (sinon **E_RANGE**).

**Version**
- Chaque fichier JSON du contrat (manifeste, règles, rapport) porte `"contract_version"` (« 1.0.0 » ou « 1.1.0 ») et son `"kind"`. Un manifeste qui déclare des maillages devrait porter « 1.1.0 ».
- Une version majeure différente de 1 est refusée (**E_VERSION**).
- Une version mineure plus récente (1.3.0, par exemple) est acceptée avec l'avertissement **W_NEWER** : les nouveaux champs sont ignorés.

**Champs inconnus**
- Un champ inconnu est **accepté et signalé** (**W_UNKNOWN**), puis ignoré par le jeu.
- Un champ qui commence par `x_` est une **extension privée** (outil, notes de travail) : il est accepté sans avertissement et toujours ignoré par le jeu.

## 4. Le langage des schémas

Les schémas sont du JSON Schema 2020-12, limité à ce que les trois validateurs savent lire.
- **Mots-clés standard :** `type`, `required`, `properties`, `items`, `enum`, `const`, `minimum`, `maximum`, `minLength`, `maxLength`, `pattern` (recherche), `minItems`, `maxItems`, `$ref` vers `#/$defs/…`.
- **Mots-clés propres au contrat SBH :**

| Mot-clé | Sur | Effet |
|---|---|---|
| `x-id: "table"` | texte | Déclare un identifiant dans la table. Un doublon donne **E_UNIQUE**. |
| `x-ref: "table"` | texte | Doit exister dans la table, dans tout le paquet. Sinon **E_REF**, vérifié en fin de validation. |
| `x-range: true` | objet `{min, max}` | `min ≤ max`, sinon **E_RANGE**. |
| `x-unique-key: [champs]` | liste d'objets | Pas deux éléments avec les mêmes valeurs pour ces champs, sinon **E_UNIQUE**. |
| `x-distinct: [a, b]` | objet | `a ≠ b` (une faction n'a pas de relation avec elle-même), sinon **E_DISTINCT**. |

Ajouter un mot-clé demande de modifier les **trois** validateurs, avec de nouveaux cas de conformité (§ 9).

## 5. Les fichiers de règles

Les tableaux ci-dessous résument les fichiers. Le détail exact (bornes, champs obligatoires) est dans les schémas.

### 5.1 `sbh_world.json` — le manifeste (`kind: "world"`)

| Champ | Contenu |
|---|---|
| `world.id`, `world.name` | Identité du monde. |
| `world.seed` | Entier de 0 à 2^53 − 1. **Même graine + mêmes règles = même monde.** |
| `world.size_chunks.x / z` | Taille en chunks (1 à 4 096). |
| `world.chunk_size_m` | Côté d'un chunk en mètres (entier de 8 à 256). |
| `world.sea_level_m` | Niveau de la mer (facultatif). |
| `generator {name, version}` | Générateur du jeu qui a produit ou doit produire le monde. |
| `created_by {tool, version}` | Outil qui a écrit le paquet (SBh Studio x.y.z). |
| `files[]` | Une entrée `{path, kind, sha256}` par fichier. `kind` vaut `biomes`, `cultures`, `settlements`, `roads`, `factions`, `creature` (avec un `id`, obligatoire), `structure` ou, depuis 1.1, `mesh` (avec un `id`, obligatoire). |

### 5.2 `biomes.json`

Chaque biome contient :
- `id`, `name`, `color` ;
- `temperature_c`, `humidity` et `elevation_m`, sous forme d'intervalles ;
- `fauna[]` : `creature` (référence à `creatures`), `weight` (poids de tirage), `group_size` (intervalle) ;
- `resources[]` : `{id, abundance}` ;
- `vegetation[]` : `{id, density}` ;
- `notes`.

Les identifiants de ressources et de végétation sont libres en v1. Ils deviendront des références quand les ateliers Végétation et Ressources existeront.

### 5.3 `cultures.json` — cultures architecturales

Chaque culture contient :
- `id`, `name` ;
- `biomes[]`, les biomes où elle vit (références) ;
- `materials[]` ;
- `building_families[]` : `id` unique dans tout le monde, `name`, `role` (habitation, religieux, commerce, défense, artisanat, agriculture, pouvoir, autre) et `variants[]`.

Chaque variante a un `id`, un `name`, une emprise `footprint_m {w, d}`, un nombre d'étages `floors` (intervalle), un poids de tirage `weight`, et une `structure` facultative. Cette structure est le chemin d'un fichier `structure` déclaré dans le manifeste.

### 5.4 `settlements.json` — établissements

Chaque type d'établissement contient :
- `id`, `name` ;
- `culture` (référence) ;
- `size` : hameau, village, bourg, ville ou capitale ;
- `population` (intervalle) ;
- `placement` :
  - `biomes[]` (références) ;
  - `near_water` ;
  - `max_slope_deg` ;
  - `min_distance_m`, la distance minimale avec un autre établissement ;
  - `elevation_m` ;
- `layout` : organique, grille, radial, linéaire ou fortifié ;
- `buildings[]` : `{family, count}`, où `family` est une référence à une famille de bâtiments et `count` un intervalle (chaque famille une seule fois) ;
- `walls` ;
- `growth {per_year, max_population}`, utilisé par le simulateur accéléré.

### 5.5 `roads.json`

- `road_types[]` : `id`, `name`, `width_m`, `surface` (terre, pierre, pavée, sable, rail), `max_slope_deg`, `connects[]` (types d'établissements qu'elle relie).
- `network` : `max_length_km`, `follow_rivers`, `avoid_biomes[]`.

### 5.6 `factions.json` — factions et matrice de relations

- `factions[]` : `id`, `name`, `color`, `culture` (facultatif), `strength` (effectifs, sous forme d'intervalle, facultatif), `home_biomes[]`, `description`.
- `relations[]` : **orientées**. `from` → `to` dit ce que `from` pense de `to`, et le sens inverse peut être différent.
  - `value` : entier de −100 à +100.
  - `stance` : alliance, amical, neutre, méfiant, hostile ou guerre.
  - `note`.
  - Chaque couple `from` / `to` n'apparaît qu'une fois, et `from ≠ to`.

`contract/tools/import_agw_factions.py` convertit l'ancien `assets/agw/factions.json` (listes alliés / ennemis / neutres) vers ce format. Les valeurs obtenues sont à nuancer (§ 10).

### 5.7 Maillages 3D (`kind: "mesh"`, contrat 1.1)

Un maillage est un fichier **glTF 2.0 binaire** (`.glb`) : Godot 4 l'ouvre tel quel (`GLTFDocument`, ou import d'une scène). Le Modeleur 3D de SBh Studio les produit (Atelier → Créatures → 🧊 Modeleur 3D).

- Entrée du manifeste : `{"path": "content/meshes/<id>.glb", "kind": "mesh", "id": "<id>", "sha256": "…"}`. L'`id` est obligatoire et unique (table `meshes`) : les versions 1.x suivantes pourront y faire référence (corps de PNJ, bâtiments, accessoires).
- Ce n'est **pas** du JSON : le contrat vérifie le conteneur, pas la géométrie (**E_MESH**, premier problème trouvé, dans cet ordre) :
  1. 32 Mo au plus, 20 octets au moins ;
  2. en-tête `glTF`, version **2**, longueur annoncée = taille réelle ;
  3. premier bloc = JSON, non vide, dans le fichier ; deuxième bloc éventuel = BIN, dans le fichier ;
  4. le bloc JSON est du **JSON strict** (§ 3) ;
  5. `asset.version` vaut `"2.0"` (chemin `/asset/version`).
- **Ce que le Studio y ajoute (facultatif, ignoré par le jeu)** : `scenes[0].extras.sbh_mesh = {format: "sbh-mesh", version: 1, name, symmetry}` et, pour chaque nœud, `extras.sbh = {id, color, verts, faces}`. Ce sont les polygones d'origine (quads, n-gones), pour rééditer le maillage sans perte. Godot les range dans la métadonnée `extras` des nœuds importés.
- Le rendu utilise les triangles du maillage glTF (normales plates, une matière PBR par objet, repère Y vers le haut, mètres).

## 6. Le rapport de test (`kind: "test_report"`)

C'est le document que le labo exporte depuis le téléphone et qu'on envoie pour analyse. C'est le seul moyen de « voir » le jeu tourner sur l'appareil.

| Bloc | Contenu |
|---|---|
| `report_id`, `created_at` | Identifiant et horodatage ISO 8601 avec fuseau (`2026-10-06T17:30:00+02:00`). |
| `app` | Nom et version (SBh Studio ou SBH World). |
| `device` | `model`, `os`, `gpu`, `ram_mb`, `screen {width_px, height_px, density}`. |
| `world` | `id`, `seed`, `contract_version` du monde testé : on rejoue exactement la même chose. |
| `scenario` | `name` (« Survol », par exemple) et `duration_s`. |
| `metrics.fps` | `min`, `avg`, `p1`, `p50`, `p95` (images par seconde). |
| `metrics.frame_ms` | `avg`, `p95`, `p99` (durée d'une image). |
| `metrics.memory_mb` | `start`, `peak`, `end`. |
| `metrics.systems[]` | Temps par système : `id`, `name`, `avg_ms`, `max_ms`, `calls`. Par exemple terrain, chunks, LOD, simulation. |
| `metrics.chunks` | `loaded`, `detailed` (zone détaillée), `abstract` (zone abstraite), `lod[] {level, count}`. |
| `events[]` | `{t_s, level, message}` : pics, avertissements, erreurs. |

Un exemple valide se trouve dans `contract/conformance/cases/doc_report_ok/document.json`.

## 7. La validation

### 7.1 Ordre exact des vérifications

C'est ce qui garantit que les trois validateurs donnent les mêmes résultats.

1. Le manifeste `sbh_world.json` doit exister (**E_FILE**) et être du JSON strict (**E_JSON**). Sinon, on s'arrête.
2. On vérifie la version du manifeste (§ 3), puis son schéma `world`.
3. On parcourt `files[]` **dans l'ordre**. On ignore les entrées mal formées, que le schéma a déjà signalées.
   1. **Chemin.**
      - Un chemin hors format est déjà signalé : on ne touche pas au disque.
      - Un chemin absolu ou qui contient `..` donne **E_PATH**.
   2. **Type de fichier.**
      - Type de règles déjà vu : **E_UNIQUE** sur `/files/i/kind`.
      - `creature` : l'`id` est obligatoire (**E_REQUIRED**) et il est enregistré dans la table `creatures`.
      - `structure` : le chemin est enregistré dans la table `structures`.
      - `mesh` (1.1) : l'`id` est obligatoire (**E_REQUIRED**), unique (**E_UNIQUE**), enregistré dans la table `meshes`.
   3. **Contenu.**
      - Fichier absent : **E_FILE**.
      - Empreinte `sha256` différente : **E_HASH**.
      - `mesh` : contrôle du conteneur `.glb` (§ 5.7, **E_MESH**), et on passe au fichier suivant (pas de lecture JSON).
      - JSON invalide : **E_JSON**.
      - Fichier de règles : version, puis schéma de son type.
      - Créature : `formatVersion` doit être « 1.x » (**E_CREATURE**).
4. Aucun fichier `biomes` déclaré : **E_REQUIRED** sur `/files`.
5. On vérifie enfin **toutes** les références `x-ref` (**E_REF**).
6. Les remarques sont triées par fichier, chemin, code, puis gravité.

Le paquet est **valide** s'il n'a **aucune erreur**. Les avertissements n'empêchent rien.

**Validation d'un fichier seul** (règles ou rapport de test) : `kind` inconnu donne **E_KIND**. Les références ne sont vérifiées que vers les tables que ce fichier définit lui-même : par exemple, `relations` → `factions` dans `factions.json`.

### 7.2 Codes

Les codes et les chemins sont **stables**. Le texte des messages peut changer et n'est pas comparé.

| Code | Gravité | Sens |
|---|---|---|
| E_JSON | erreur | Le fichier n'est pas du JSON strict ou pas de l'UTF-8 valide. |
| E_KIND | erreur | Type de document inconnu (fichier seul). |
| E_VERSION | erreur | Version majeure du contrat non prise en charge. |
| W_NEWER | avertissement | Version mineure plus récente : nouveaux champs ignorés. |
| E_TYPE | erreur | Mauvais type (texte au lieu de nombre, décimal au lieu d'entier…). |
| E_REQUIRED | erreur | Champ obligatoire absent. Le chemin désigne le champ manquant. |
| E_ENUM | erreur | Valeur hors de la liste autorisée, ou `kind` inattendu. |
| E_MIN, E_MAX | erreur | Nombre hors bornes. |
| E_LENGTH | erreur | Texte trop court ou trop long. |
| E_PATTERN | erreur | Format invalide (identifiant, couleur, version, chemin, empreinte…). |
| E_ITEMS | erreur | Trop ou pas assez d'éléments dans une liste. |
| E_RANGE | erreur | Intervalle avec min > max. |
| E_UNIQUE | erreur | Identifiant, couple ou type de fichier en double. Le chemin désigne le 2e. |
| E_DISTINCT | erreur | Deux champs qui doivent différer sont égaux. |
| E_REF | erreur | Référence vers un identifiant introuvable. |
| E_FILE | erreur | Fichier déclaré mais absent, ou manifeste absent. |
| E_HASH | erreur | Fichier modifié après signature. |
| E_PATH | erreur | Chemin interdit (`..`). |
| E_CREATURE | erreur | Fichier créature qui n'est pas au format CreatureStudio 1.x. |
| E_MESH | erreur | (1.1) Fichier `mesh` qui n'est pas un `.glb` glTF 2.0 bien formé (§ 5.7). |
| W_UNKNOWN | avertissement | Champ inconnu : il est ignoré. |

## 8. La conformité : comment on garantit « un seul format »

- `contract/conformance/cases/` contient 68 cas (51 en 1.0, plus 17 pour les maillages en 1.1) : paquets complets ou fichiers seuls. Chacun cible une règle :
  - chaque code d'erreur ;
  - JSON strict ;
  - Unicode ;
  - entiers ;
  - références entre fichiers.
- `contract/tools/fuzz_diff.py` produit N variantes aléatoires pour le test différentiel.
- `contract/conformance/expected.json` contient le résultat attendu, **écrit à la main** dans `contract/tools/make_cases.py`.
- `bash contract/tools/run_all.sh` lance les trois validateurs. Le jeu de cas doit être 100 % conforme partout.
  - Python : `sbh_contract.py conformance`.
  - Kotlin : `ContractConformance`, également exécuté par `./gradlew testDebugUnitTest` (`ContractConformanceTest`).
  - Godot : `godot --headless --path contract/godot -s tests/run_conformance.gd -- <contract>`.
- **État au 2026-10-06 :**
  - 68/68 cas conformes pour Python, Kotlin 2.1 et Godot 4.4.1 ;
  - 500 variantes aléatoires de l'exemple (dont 180 avec un `.glb` abîmé : bits inversés, fichier coupé ou rallongé), plus 19 cas de JSON « limite », donnent des résultats identiques dans les trois validateurs ;
  - les `.glb` du Modeleur 3D s'ouvrent dans Godot 4.4.1 (`contract/godot/tests/load_glb.gd`).

## 9. Faire évoluer le contrat

Pour **ajouter** quelque chose (version mineure 1.x) :
1. Ajouter le champ dans `gen_schemas.py`, **toujours facultatif**.
2. Lancer `python3 contract/tools/gen_schemas.py`. Le script recopie les schémas dans les assets du Studio et dans l'addon Godot.
3. Ajouter les cas de conformité dans `make_cases.py`.
4. Passer `contract_version` à 1.(x+1).0 dans les exemples.
5. Lancer `run_all.sh` : les trois validateurs doivent être à 100 %.
6. Mettre à jour ce document et le CHANGELOG.

Un fichier écrit en 1.0 reste valide en 1.x : on ne retire rien, on ne rend rien obligatoire.

Toute **rupture** (champ retiré ou renommé, sens d'une valeur changé) fait passer à **2.0.0**. Les anciens validateurs refusent alors les nouveaux fichiers (E_VERSION) au lieu de mal les lire. Prévoir dans ce cas un convertisseur 1 → 2.

Le validateur Godot lit les fichiers avec un lecteur strict écrit en GDScript : environ 30 ms pour 139 Ko sur un ordinateur, sans doute quelques dixièmes de seconde sur un téléphone. Une fois un paquet validé, le jeu peut charger ses fichiers avec le `JSON` natif de Godot, qui est plus rapide.

## 10. Correspondance avec l'existant

| Existant (SBh Studio V1.8.63) | Dans le contrat v1 | Décision |
|---|---|---|
| `assets/agw/factions.json` (allies / enemies / neutrals) | `rules/factions.json` (matrice orientée −100..100) | **À migrer.** Convertisseur fourni. ⚠ L'ancien fichier met `hibou` **neutre** envers `royaume`, alors que la bible dit « guerre frontale directe ». À trancher, puis à corriger dans la matrice. |
| `assets/agw/world_core.schema.json`, AgwWorldCore (nœuds faction / région / map…) | Manifeste + règles | **À remplacer.** Les régions deviendront un fichier du contrat (v1.1, voir § 11). |
| `placements.json`, `protocol.json`, `structure_ref.json` (▶ Tester → `studio_import/`) | Paquet de monde + scène de test (labo) | **À retirer** quand le jeu lira le contrat. C'est un second pipeline vers Godot. |
| Corps CreatureStudio (`files/creatures/…creature.json`) | `content/creatures/*.creature.json` | **Repris tel quel** (format 1.x). |
| Structures (`structure_maison_forgeron.json`, StructureLoader) | `content/structures/*.json` | **Repris tel quel.** Référencées par les variantes de bâtiments. |
| Maillages du Modeleur 3D (`files/meshes/<projet>/<id>.glb`, V1.8.65) | `content/meshes/<id>.glb` (kind `mesh`, 1.1) | **Repris tel quel.** |
| Maps Map Studio (voxels, `sbh-map-studio` v4) | — | Hors v1. Ce sont des lieux faits main, à intégrer en v1.1 comme contenu « lieu ». |
| `game_builder/game_project.schema.json` | — | Hors v1. À aligner ou à retirer à l'étape suivante. |
| Mobs Minecraft (`MobEntity`, PackGenerator) et pipeline Fondation | — | **Hors contrat** : c'est l'export Minecraft Bedrock, une cible à part du jeu SBH World. |

## 11. Ce qui reste ouvert, et les hypothèses de cette version

Ce contrat a été écrit **sans** la constitution technique ni le code actuel du jeu Godot, que je n'avais pas. Hypothèses à confirmer :

1. **Godot 4.x.** Le validateur est testé avec 4.4.1.
2. **Monde découpé en chunks carrés** (`chunk_size_m`), avec une zone détaillée et une zone abstraite gérées par LOD. Seul le rapport de test les mesure en v1 : le contrat ne fixe pas encore leur format interne.
3. **Unités :** mètres et degrés Celsius.
4. **Identifiants en minuscules ASCII.** Les noms affichés restent libres (arabe, français…).

Prévu pour la suite (v1.x, tous les ajouts facultatifs) :
- `regions.json` (régions nommées, frontières, factions qui les tiennent) ;
- `vegetation.json` et `resources.json`, qui feront de `resources[].id` et `vegetation[].id` des références ;
- `npcs.json` ;
- les lieux faits main (maps Map Studio) ;
- un fichier `simulation.json` (paramètres du simulateur accéléré) ;
- le format des sorties générées (carte 2D vue du ciel, état de simulation), rangées dans `generated/` et non signées comme règles.
