# contract/ — SBH Data Contract (le format commun Studio ⇄ jeu)

Lire d'abord **`SPEC_SBH_DATA_CONTRACT_v1.md`**.

| Dossier | Contenu |
|---|---|
| `schemas/` | Schémas JSON du contrat (générés par `tools/gen_schemas.py` — modifier le générateur, pas les fichiers) |
| `reference/sbh_contract.py` | Validateur de RÉFÉRENCE (Python 3, sans dépendance) : `validate`, `manifest`, `conformance` |
| `godot/addons/sbh_contract/` | Validateur du JEU (GDScript, Godot 4) + copie des schémas — à copier tel quel dans le projet SBH World |
| `godot/tests/run_conformance.gd` | Conformité côté Godot (`godot --headless --path contract/godot -s tests/run_conformance.gd -- <chemin de contract>`) |
| `godot/tests/load_glb.gd` | (1.1) Ouvre des `.glb` du Modeleur 3D avec GLTFDocument et compte nœuds, maillages, sommets et `extras.sbh` (`godot --headless --path contract/godot -s tests/load_glb.gd -- <fichier.glb>`) |
| `../app/src/main/java/com/sbh/studio/contract/` | Validateur du STUDIO (Kotlin pur) ; schémas copiés dans `app/src/main/assets/contract/schemas/` |
| `conformance/` | 68 cas (dont 17 pour les maillages .glb, contrat 1.1) + résultats attendus (écrits à la main dans `tools/make_cases.py`) |
| `examples/al_zahra_mini/` | Petit monde complet, valide et signé |
| `examples/import_agw/factions.json` | Factions de l'ancien `assets/agw/factions.json` converties (à nuancer) |
| `tools/` | `gen_schemas.py`, `make_example.py`, `make_cases.py`, `import_agw_factions.py`, `fuzz_diff.py` (test différentiel), `run_all.sh` |

Tout vérifier (les trois validateurs) : `bash contract/tools/run_all.sh` (avec `KOTLINC=…` et `GODOT=…` si besoin).
