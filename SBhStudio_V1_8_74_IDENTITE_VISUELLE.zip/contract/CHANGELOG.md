# CHANGELOG — SBH Data Contract

## 1.1.0 — 2026-10-06
Ajout facultatif (rien ne casse, un monde 1.0 reste valide) : contenu `mesh` = maillage glTF 2.0 binaire (.glb),
avec `id` obligatoire et unique (table `meshes`), contrôle du conteneur (code E_MESH : en-tête, version 2,
longueurs des blocs, JSON strict, asset.version « 2.0 »). Produit par le Modeleur 3D de SBh Studio (V1.8.65).
CONTRACT_MINOR = 1 dans les trois validateurs. 17 cas de conformité en plus (68 au total), test aléatoire étendu
aux .glb abîmés, exemple al_zahra_mini avec un maillage (manifeste en 1.1.0), test Godot load_glb.gd.

## 1.0.0 — 2026-10-06
Première version : paquet de monde signé (manifeste + sha256), règles biomes / cultures / établissements /
routes / factions (matrice orientée), rapport de test du labo, JSON strict, mots-clés x-id / x-ref / x-range /
x-unique-key / x-distinct, 20 codes stables, validateurs Python (référence) + Kotlin (Studio) + GDScript (Godot)
conformes à 100 % sur 51 cas, exemple al_zahra_mini, convertisseur des anciennes factions AGW.
