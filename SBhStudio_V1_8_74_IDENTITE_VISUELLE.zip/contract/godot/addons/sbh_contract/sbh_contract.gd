## SBH Data Contract v1 — validateur côté jeu (Godot 4, GDScript).
##
## Copie fidèle du validateur de référence contract/reference/sbh_contract.py : mêmes règles, mêmes
## codes, mêmes chemins. Toute différence est un bug, détectée par tests/run_conformance.gd.
## Utilisation dans le jeu :
##   var schemas := SbhContract.load_schemas("res://addons/sbh_contract/schemas")
##   var r := SbhContract.validate_package("user://worlds/al_zahra_mini", schemas)
##   if not r.valid: for i in r.issues: push_error("%s %s %s" % [i.code, i.file, i.path])
class_name SbhContract
extends RefCounted

const CONTRACT_MAJOR := 1
const CONTRACT_MINOR := 1
const RULE_KINDS := ["biomes", "cultures", "settlements", "roads", "factions"]
const DOC_KINDS := ["biomes", "cultures", "settlements", "roads", "factions", "world", "test_report"]
const MANIFEST := "sbh_world.json"

static var _regex_cache := {}


static func load_schemas(dir: String) -> Dictionary:
	var out := {}
	for k in DOC_KINDS:
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(dir.path_join(k + ".schema.json")))
		out[k] = parsed
	return out


static func _regex(p: String) -> RegEx:
	if not _regex_cache.has(p):
		_regex_cache[p] = RegEx.create_from_string(p)
	return _regex_cache[p]


class Ctx:
	var issues: Array = []
	var ids := {}
	var refs: Array = []

	func add(sev: String, code: String, file: String, path: String, msg: String) -> void:
		issues.append({"severity": sev, "code": code, "file": file, "path": path, "message": msg})

	func err(code: String, file: String, path: String, msg: String) -> void:
		add("error", code, file, path, msg)

	func table(name: String) -> Dictionary:
		if not ids.has(name):
			ids[name] = {}
		return ids[name]


static func _is_num(v) -> bool:
	return typeof(v) == TYPE_FLOAT or typeof(v) == TYPE_INT


static func _type_ok(v, t: String) -> bool:
	match t:
		"object": return typeof(v) == TYPE_DICTIONARY
		"array": return typeof(v) == TYPE_ARRAY
		"string": return typeof(v) == TYPE_STRING
		"boolean": return typeof(v) == TYPE_BOOL
		"number": return _is_num(v)
		"integer": return _is_num(v) and not is_inf(float(v)) and float(v) == floor(float(v))
	return true


static func _resolve(schema: Dictionary, root: Dictionary) -> Dictionary:
	if not schema.has("$ref"):
		return schema
	var name: String = String(schema["$ref"]).get_slice("/", String(schema["$ref"]).get_slice_count("/") - 1)
	var out: Dictionary = root["$defs"][name].duplicate()
	for k in schema:
		if k != "$ref":
			out[k] = schema[k]
	return out


static func _same(a, b) -> bool:
	if typeof(a) == TYPE_BOOL or typeof(b) == TYPE_BOOL:
		return typeof(a) == TYPE_BOOL and typeof(b) == TYPE_BOOL and a == b
	if _is_num(a) and _is_num(b):
		return float(a) == float(b)
	if typeof(a) != typeof(b):
		return false
	return a == b


static func _key_of(v) -> String:
	if _is_num(v):
		return "n:" + str(float(v))
	if typeof(v) == TYPE_STRING:
		return "s:" + v
	return "o:" + str(v)


static func _check(v, schema: Dictionary, root: Dictionary, path: String, file: String, ctx: Ctx) -> void:
	var s := _resolve(schema, root)
	if s.has("type") and not _type_ok(v, s["type"]):
		ctx.err("E_TYPE", file, path, "type attendu : %s" % s["type"])
		return
	if s.has("const") and not _same(v, s["const"]):
		ctx.err("E_ENUM", file, path, "valeur attendue : %s" % str(s["const"]))
	if s.has("enum"):
		var found := false
		for e in s["enum"]:
			if _same(v, e):
				found = true
				break
		if not found:
			ctx.err("E_ENUM", file, path, "valeur hors liste")
	if typeof(v) == TYPE_STRING:
		var n: int = v.length()
		if (s.has("minLength") and n < s["minLength"]) or (s.has("maxLength") and n > s["maxLength"]):
			ctx.err("E_LENGTH", file, path, "longueur %d hors limites" % n)
		if s.has("pattern") and _regex(s["pattern"]).search(v) == null:
			ctx.err("E_PATTERN", file, path, "format invalide (attendu %s)" % s["pattern"])
		if s.has("x-id"):
			var t := ctx.table(s["x-id"])
			if t.has(v):
				ctx.err("E_UNIQUE", file, path, "identifiant « %s » déjà utilisé (%s)" % [v, s["x-id"]])
			else:
				t[v] = true
		if s.has("x-ref"):
			ctx.refs.append([s["x-ref"], v, file, path])
	if _is_num(v):
		if s.has("minimum") and v < s["minimum"]:
			ctx.err("E_MIN", file, path, "minimum %s" % str(s["minimum"]))
		if s.has("maximum") and v > s["maximum"]:
			ctx.err("E_MAX", file, path, "maximum %s" % str(s["maximum"]))
	if typeof(v) == TYPE_DICTIONARY:
		var props: Dictionary = s.get("properties", {})
		for r in s.get("required", []):
			if not v.has(r):
				ctx.err("E_REQUIRED", file, path + "/" + r, "champ obligatoire manquant")
		for k in v:
			if props.has(k):
				_check(v[k], props[k], root, path + "/" + k, file, ctx)
			elif s.has("properties") and not String(k).begins_with("x_"):
				ctx.add("warning", "W_UNKNOWN", file, path + "/" + k, "champ inconnu (ignoré par le jeu)")
		if s.get("x-range", false) == true and _is_num(v.get("min")) and _is_num(v.get("max")) and v["min"] > v["max"]:
			ctx.err("E_RANGE", file, path, "min > max")
		if s.has("x-distinct"):
			var a: String = s["x-distinct"][0]
			var b: String = s["x-distinct"][1]
			if v.has(a) and v.has(b) and _same(v[a], v[b]):
				ctx.err("E_DISTINCT", file, path, "« %s » et « %s » doivent être différents" % [a, b])
	if typeof(v) == TYPE_ARRAY:
		var size: int = v.size()
		if (s.has("minItems") and size < s["minItems"]) or (s.has("maxItems") and size > s["maxItems"]):
			ctx.err("E_ITEMS", file, path, "%d élément(s) hors limites" % size)
		if s.has("items"):
			for i in size:
				_check(v[i], s["items"], root, path + "/" + str(i), file, ctx)
		if s.has("x-unique-key"):
			var keys: Array = s["x-unique-key"]
			var seen := {}
			for i in size:
				var it = v[i]
				if typeof(it) != TYPE_DICTIONARY:
					continue
				var all := true
				for k in keys:
					if not it.has(k):
						all = false
				if not all:
					continue
				var parts := PackedStringArray()
				for k in keys:
					parts.append(_key_of(it[k]))
				var key := "\u0001".join(parts)
				if seen.has(key):
					ctx.err("E_UNIQUE", file, path + "/" + str(i), "doublon")
				seen[key] = true


static func _strip_zeros(s: String) -> String:
	var i := 0
	while i < s.length() and s[i] == "0":
		i += 1
	return s.substr(i)


static func _check_version(doc, file: String, ctx: Ctx) -> void:
	if typeof(doc) != TYPE_DICTIONARY or typeof(doc.get("contract_version")) != TYPE_STRING:
		return
	var m := _regex("^([0-9]+)\\.([0-9]+)\\.([0-9]+)$").search(doc["contract_version"])
	if m == null:
		return
	if _strip_zeros(m.get_string(1)) != str(CONTRACT_MAJOR):
		ctx.err("E_VERSION", file, "/contract_version", "version majeure non prise en charge (attendu %d)" % CONTRACT_MAJOR)
	elif _strip_zeros(m.get_string(2)) != "" and (_strip_zeros(m.get_string(2)).length() > 9 or int(m.get_string(2)) > CONTRACT_MINOR):
		ctx.add("warning", "W_NEWER", file, "/contract_version", "version plus récente : champs nouveaux ignorés")


## Lecture JSON STRICTE (RFC 8259) : [true, valeur] ou [false, null].
## Le JSON de Godot est trop permissif pour le contrat (virgule finale, BOM, zéro en tête, « 2. »,
## caractère de contrôle brut…) : ces fichiers seraient acceptés par le jeu mais refusés par le
## Studio. Ce lecteur fait exactement comme le Studio et la référence. Nombres → float.
static func _parse(bytes: PackedByteArray) -> Array:
	var text := bytes.get_string_from_utf8()
	if text.to_utf8_buffer() != bytes:
		return [false, null]  # UTF-8 invalide
	var p := _StrictJson.new(text)
	p.ws()
	var v = p.value()
	if p.failed:
		return [false, null]
	p.ws()
	if p.i != p.n:
		return [false, null]
	return [true, v]


class _StrictJson:
	var s: String
	var n: int
	var i := 0
	var failed := false

	func _init(text: String) -> void:
		s = text
		n = text.length()

	func fail():
		failed = true
		return null

	func ws() -> void:
		while i < n:
			var c := s.unicode_at(i)
			if c == 32 or c == 10 or c == 13 or c == 9:
				i += 1
			else:
				break

	func value():
		if failed or i >= n:
			return fail()
		var c := s.unicode_at(i)
		if c == 123: return obj()        # {
		if c == 91: return arr()         # [
		if c == 34: return string()      # "
		if s.substr(i, 4) == "true":
			i += 4
			return true
		if s.substr(i, 5) == "false":
			i += 5
			return false
		if s.substr(i, 4) == "null":
			i += 4
			return null
		return number()

	func obj():
		var d := {}
		i += 1
		ws()
		if i < n and s.unicode_at(i) == 125:
			i += 1
			return d
		while true:
			ws()
			if i >= n or s.unicode_at(i) != 34:
				return fail()
			var k = string()
			if failed:
				return null
			ws()
			if i >= n or s.unicode_at(i) != 58:
				return fail()
			i += 1
			ws()
			var v = value()
			if failed:
				return null
			d[k] = v
			ws()
			if i >= n:
				return fail()
			var c := s.unicode_at(i)
			if c == 44:
				i += 1
				continue
			if c == 125:
				i += 1
				return d
			return fail()
		return fail()

	func arr():
		var a := []
		i += 1
		ws()
		if i < n and s.unicode_at(i) == 93:
			i += 1
			return a
		while true:
			ws()
			var v = value()
			if failed:
				return null
			a.append(v)
			ws()
			if i >= n:
				return fail()
			var c := s.unicode_at(i)
			if c == 44:
				i += 1
				continue
			if c == 93:
				i += 1
				return a
			return fail()
		return fail()

	func hex4() -> int:
		if i + 4 > n:
			failed = true
			return -1
		var t := s.substr(i, 4)
		for ch in t:
			if not ("0123456789abcdefABCDEF".contains(ch)):
				failed = true
				return -1
		i += 4
		return t.hex_to_int()

	func string():
		i += 1
		var out := PackedStringArray()
		var start := i
		while true:
			if i >= n:
				return fail()
			var c := s.unicode_at(i)
			if c == 34:
				out.append(s.substr(start, i - start))
				i += 1
				return "".join(out)
			if c < 32:
				return fail()
			if c == 92:
				out.append(s.substr(start, i - start))
				i += 1
				if i >= n:
					return fail()
				var e := s.unicode_at(i)
				i += 1
				match e:
					34: out.append("\"")
					92: out.append("\\")
					47: out.append("/")
					98: out.append(char(8))
					102: out.append(char(12))
					110: out.append("\n")
					114: out.append("\r")
					116: out.append("\t")
					117:
						var h := hex4()
						if failed:
							return null
						if h >= 0xD800 and h <= 0xDBFF:
							if s.substr(i, 2) != "\\u":
								return fail()
							i += 2
							var lo := hex4()
							if failed or lo < 0xDC00 or lo > 0xDFFF:
								return fail()
							out.append(char(0x10000 + ((h - 0xD800) << 10) + (lo - 0xDC00)))
						elif h >= 0xDC00 and h <= 0xDFFF:
							return fail()
						else:
							out.append(char(h))
					_:
						return fail()
				start = i
				continue
			i += 1
		return fail()

	func _digit(k: int) -> bool:
		return k < n and s.unicode_at(k) >= 48 and s.unicode_at(k) <= 57

	func number():
		var start := i
		if i < n and s.unicode_at(i) == 45:
			i += 1
		if not _digit(i):
			return fail()
		if s.unicode_at(i) == 48:
			i += 1
		else:
			while _digit(i):
				i += 1
		if i < n and s.unicode_at(i) == 46:
			i += 1
			if not _digit(i):
				return fail()
			while _digit(i):
				i += 1
		if i < n and (s.unicode_at(i) == 101 or s.unicode_at(i) == 69):
			i += 1
			if i < n and (s.unicode_at(i) == 43 or s.unicode_at(i) == 45):
				i += 1
			if not _digit(i):
				return fail()
			while _digit(i):
				i += 1
		return s.substr(start, i - start).to_float()


static func _resolve_refs(ctx: Ctx, only_tables = null) -> void:
	for r in ctx.refs:
		if only_tables != null and not only_tables.has(r[0]):
			continue
		if not ctx.table(r[0]).has(r[1]):
			ctx.err("E_REF", r[2], r[3], "« %s » introuvable dans %s" % [r[1], r[0]])


static func _less(a: Dictionary, b: Dictionary) -> bool:
	for k in ["file", "path", "code", "severity"]:
		if a[k] != b[k]:
			return a[k] < b[k]
	return false


static func _finish(ctx: Ctx) -> Dictionary:
	var issues := ctx.issues.duplicate()
	issues.sort_custom(_less)
	var valid := true
	for i in issues:
		if i["severity"] == "error":
			valid = false
	return {"valid": valid, "issues": issues}


## Un fichier seul (règles ou rapport de test) ; références vérifiées vers ses propres tables.
static func validate_document(bytes: PackedByteArray, schemas: Dictionary, file := "document.json") -> Dictionary:
	var ctx := Ctx.new()
	var p := _parse(bytes)
	if not p[0]:
		ctx.err("E_JSON", file, "", "JSON illisible")
		return _finish(ctx)
	var doc = p[1]
	var kind = doc.get("kind") if typeof(doc) == TYPE_DICTIONARY else null
	if typeof(kind) != TYPE_STRING or not schemas.has(kind):
		ctx.err("E_KIND", file, "/kind", "type de document inconnu")
		return _finish(ctx)
	_check_version(doc, file, ctx)
	_check(doc, schemas[kind], schemas[kind], "", file, ctx)
	_resolve_refs(ctx, ctx.ids.keys())
	return _finish(ctx)


static func sha256(bytes: PackedByteArray) -> String:
	var h := HashingContext.new()
	h.start(HashingContext.HASH_SHA256)
	h.update(bytes)
	return h.finish().hex_encode()


## Un paquet de monde : dossier contenant sbh_world.json et les fichiers qu'il signe.
const GLB_MAX := 32 * 1024 * 1024

## Contrôle d'un .glb (contrat 1.1, kind « mesh ») : [chemin, message] du 1er problème, ou [] si le fichier est bon.
static func glb_problem(data: PackedByteArray) -> Array:
	var n := data.size()
	if n > GLB_MAX:
		return ["", "fichier trop gros (32 Mo au plus)"]
	if n < 20:
		return ["", "fichier trop court pour un .glb"]
	if data.decode_u32(0) != 0x46546C67:
		return ["", "en-tête « glTF » absent"]
	if data.decode_u32(4) != 2:
		return ["", "glTF version 2 attendue"]
	if data.decode_u32(8) != n:
		return ["", "longueur annoncée différente de la taille du fichier"]
	var jlen := data.decode_u32(12)
	if data.decode_u32(16) != 0x4E4F534A or jlen == 0 or 20 + jlen > n:
		return ["", "bloc JSON absent ou hors du fichier"]
	var p := 20 + jlen
	if p < n:
		if p + 8 > n:
			return ["", "bloc binaire tronqué"]
		if data.decode_u32(p + 4) != 0x004E4942 or p + 8 + data.decode_u32(p) > n:
			return ["", "bloc binaire invalide ou hors du fichier"]
	var pj := _parse(data.slice(20, p))
	if not pj[0]:
		return ["", "bloc JSON du .glb illisible (JSON strict)"]
	var js = pj[1]
	var asset = js.get("asset") if typeof(js) == TYPE_DICTIONARY else null
	if typeof(asset) != TYPE_DICTIONARY or typeof(asset.get("version")) != TYPE_STRING or asset.get("version") != "2.0":
		return ["/asset/version", "glTF « asset.version » = « 2.0 » attendu"]
	return []


static func validate_package(root: String, schemas: Dictionary) -> Dictionary:
	var ctx := Ctx.new()
	var mf := root.path_join(MANIFEST)
	if not FileAccess.file_exists(mf):
		ctx.err("E_FILE", MANIFEST, "", "manifeste sbh_world.json absent")
		return _finish(ctx)
	var p := _parse(FileAccess.get_file_as_bytes(mf))
	if not p[0]:
		ctx.err("E_JSON", MANIFEST, "", "JSON illisible")
		return _finish(ctx)
	var man = p[1]
	_check_version(man, MANIFEST, ctx)
	_check(man, schemas["world"], schemas["world"], "", MANIFEST, ctx)
	var files = man.get("files") if typeof(man) == TYPE_DICTIONARY else null
	var seen_kinds := {}
	if typeof(files) == TYPE_ARRAY:
		for i in files.size():
			var e = files[i]
			if typeof(e) != TYPE_DICTIONARY or typeof(e.get("path")) != TYPE_STRING or typeof(e.get("kind")) != TYPE_STRING:
				continue
			var rel: String = e["path"]
			var kind: String = e["kind"]
			var base := "/files/" + str(i)
			# chemin déjà signalé par le schéma (E_PATTERN / E_LENGTH) : on ne touche pas au disque
			if rel.length() > 200 or _regex("^[a-z0-9_][a-z0-9_./-]*$").search(rel) == null:
				continue
			if rel.begins_with("/") or rel.split("/").has(".."):
				ctx.err("E_PATH", MANIFEST, base + "/path", "chemin interdit (absolu ou « .. »)")
				continue
			if RULE_KINDS.has(kind):
				if seen_kinds.has(kind):
					ctx.err("E_UNIQUE", MANIFEST, base + "/kind", "fichier « %s » déjà déclaré" % kind)
					continue
				seen_kinds[kind] = true
			elif kind == "creature":
				if not e.has("id"):
					ctx.err("E_REQUIRED", MANIFEST, base + "/id", "une créature doit avoir un id")
				elif typeof(e["id"]) == TYPE_STRING:
					var t := ctx.table("creatures")
					if t.has(e["id"]):
						ctx.err("E_UNIQUE", MANIFEST, base + "/id", "créature déjà déclarée")
					t[e["id"]] = true
			elif kind == "structure":
				ctx.table("structures")[rel] = true
			elif kind == "mesh":
				if not e.has("id"):
					ctx.err("E_REQUIRED", MANIFEST, base + "/id", "un maillage doit avoir un id")
				elif typeof(e["id"]) == TYPE_STRING:
					var tm := ctx.table("meshes")
					if tm.has(e["id"]):
						ctx.err("E_UNIQUE", MANIFEST, base + "/id", "maillage déjà déclaré")
					tm[e["id"]] = true
			else:
				continue
			var fp := root.path_join(rel)
			if not FileAccess.file_exists(fp):
				ctx.err("E_FILE", MANIFEST, base + "/path", "fichier absent : " + rel)
				continue
			var data := FileAccess.get_file_as_bytes(fp)
			var sha = e.get("sha256")
			if typeof(sha) == TYPE_STRING and _regex("^[0-9a-f]{64}$").search(sha) != null and sha256(data) != sha:
				ctx.err("E_HASH", MANIFEST, base + "/sha256", "empreinte sha256 différente (fichier modifié après signature)")
			if kind == "mesh":  # fichier binaire glTF 2.0 (.glb), pas du JSON
				var pb := glb_problem(data)
				if not pb.is_empty():
					ctx.err("E_MESH", rel, pb[0], pb[1])
				continue
			var pd := _parse(data)
			if not pd[0]:
				ctx.err("E_JSON", rel, "", "JSON illisible")
				continue
			var doc = pd[1]
			if RULE_KINDS.has(kind):
				_check_version(doc, rel, ctx)
				_check(doc, schemas[kind], schemas[kind], "", rel, ctx)
			elif kind == "creature":
				var fv = doc.get("formatVersion") if typeof(doc) == TYPE_DICTIONARY else null
				if typeof(fv) != TYPE_STRING or not String(fv).begins_with("1."):
					ctx.err("E_CREATURE", rel, "/formatVersion", "créature CreatureStudio format 1.x attendue")
		if not seen_kinds.has("biomes"):
			ctx.err("E_REQUIRED", MANIFEST, "/files", "un fichier de biomes est obligatoire")
	_resolve_refs(ctx)
	return _finish(ctx)


## Résultat comparable aux cas de conformité : [[gravité, code, fichier, chemin], …]
static func triples(result: Dictionary) -> Array:
	var out := []
	for i in result["issues"]:
		out.append([i["severity"], i["code"], i["file"], i["path"]])
	return out
