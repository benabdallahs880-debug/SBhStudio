## Cas de conformité du contrat SBH avec le validateur Godot.
##   godot --headless --path contract/godot -s tests/run_conformance.gd -- <chemin absolu de contract/>
extends SceneTree

## preload : fonctionne même sans import préalable du projet (cache des class_name absent).
const C = preload("res://addons/sbh_contract/sbh_contract.gd")

func _init() -> void:
	var args := OS.get_cmdline_user_args()
	var contract: String = args[0] if args.size() > 0 else ProjectSettings.globalize_path("res://").path_join("..")
	var schemas := C.load_schemas(contract.path_join("schemas"))
	var expected = JSON.parse_string(FileAccess.get_file_as_string(contract.path_join("conformance/expected.json")))
	var cases_dir := contract.path_join("conformance/cases")
	var names := Array(DirAccess.get_directories_at(cases_dir))
	names.sort()
	var bad := 0
	for name in names:
		var d: String = cases_dir.path_join(name)
		var doc := d.path_join("document.json")
		var r: Dictionary
		if FileAccess.file_exists(doc):
			r = C.validate_document(FileAccess.get_file_as_bytes(doc), schemas, "document.json")
		else:
			r = C.validate_package(d, schemas)
		var got := C.triples(r)
		if not expected.has(name) or expected[name] != got:
			bad += 1
			print("KO %s\n  attendu : %s\n  obtenu  : %s" % [name, str(expected.get(name)), str(got)])
	var ex := C.validate_package(contract.path_join("examples/al_zahra_mini"), schemas)
	if not ex["issues"].is_empty():
		bad += 1
		print("KO exemple al_zahra_mini : ", C.triples(ex))
	print("Godot : %d/%d cas conformes (+ exemple %s)" % [names.size() - (bad if ex["issues"].is_empty() else bad - 1), names.size(), "OK" if ex["issues"].is_empty() else "KO"])
	quit(1 if bad > 0 else 0)
