## Vérifie que Godot 4 ouvre les .glb du Modeleur 3D de SBh Studio (nœuds, maillages, surfaces, extras).
##   godot --headless --path contract/godot -s tests/load_glb.gd -- <fichier.glb> [<fichier.glb> …]
extends SceneTree

func _count(n: Node, acc: Dictionary) -> void:
	if n is MeshInstance3D and n.mesh != null:
		acc["meshes"] += 1
		for s in n.mesh.get_surface_count():
			var arr: Array = n.mesh.surface_get_arrays(s)
			acc["verts"] += (arr[Mesh.ARRAY_VERTEX] as PackedVector3Array).size()
	for c in n.get_children():
		_count(c, acc)

func _init() -> void:
	var bad := 0
	for path in OS.get_cmdline_user_args():
		var doc := GLTFDocument.new()
		var state := GLTFState.new()
		var err := doc.append_from_buffer(FileAccess.get_file_as_bytes(path), "", state)
		if err != OK:
			print("KO %s : erreur %d" % [path, err]); bad += 1; continue
		var root := doc.generate_scene(state)
		if root == null:
			print("KO %s : pas de scène" % path); bad += 1; continue
		var acc := {"meshes": 0, "verts": 0}
		_count(root, acc)
		# Godot 4.4 range node.extras dans la métadonnée "extras" : les polygones d'origine sont là.
		var extras := 0
		for c in root.find_children("*", "", true, false):
			if c.has_meta("extras") and (c.get_meta("extras") as Dictionary).has("sbh"):
				extras += 1
		print("OK %s : %d nœuds, %d maillages, %d sommets, %d avec extras.sbh" % [path.get_file(), state.get_nodes().size(), acc["meshes"], acc["verts"], extras])
		root.free()
	quit(1 if bad else 0)
