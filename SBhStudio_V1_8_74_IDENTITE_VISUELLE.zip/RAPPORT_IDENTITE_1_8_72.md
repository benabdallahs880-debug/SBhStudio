# SBh Studio 1.8.72 — Identité commune et passerelles

Cette livraison ajoute du code Android/Kotlin à la 1.8.71. Elle n'est pas un APK compilé ou testé sur téléphone. Le code des éditeurs spécialisés et les créations existantes sont conservés.

## Utilisation prévue

Créatures → Bibliothèque commune. La bibliothèque rassemble les six modèles CreatureStudio et les créations du projet actif. Un modèle intégré propose Aperçu 3D (lecture seule, aucune sauvegarde) et Créer une copie. Une création personnelle propose sa fiche commune, ses aperçus déjà enregistrés et la duplication de ses documents liés. Les cartes de l'ancien atelier ont aussi un bouton Fiche commune.

La fiche contient une identité stable, un nom commun, des notes et les liens vers les documents d'origine. Elle permet de relier explicitement deux créations existantes du même projet, par exemple le maillage d'un soldat et sa fiche de comportement. Leurs fichiers ne sont pas fusionnés ; l'ancienne identité, le nom et les notes de la fiche reliée sont conservés comme alias. Le nom commun n'écrase pas les noms des ateliers.

## Implémentation

Le package creation contient le modèle CommonCreation, la découverte idempotente, l'association des références, la liaison des fiches, la duplication, le registre persistant et le dialogue Compose. L'identité initiale dépend du projet, du type de document et de son identifiant ; deux ateliers peuvent employer le même identifiant sans devenir le même objet. Les références manquantes restent conservées pour diagnostiquer une suppression ou une sauvegarde interrompue. Une référence ne peut appartenir à deux fiches.

Le registre est un fichier annexe par projet dans common_creations, avec format versionné et écritures SafeStore. Il ne migre pas les anciens formats. Les versions inconnues et les registres illisibles bloquent l'écriture ; une copie de secours est conservée pour un JSON illisible. Les lectures/modifications du registre sont sérialisées. Les anciens dépôts gardent leurs propres règles de sauvegarde.

## Passerelles présentes dans le code

Ouvrir dans le Modeleur : rouvre le maillage lié, ou prépare une copie d'un GLB de Character Studio/Entités et associe cette copie à la même identité. La source initiale est conservée. Le maillage lié devient le modèle préféré pour le prochain placement sur carte. Le Modeleur ne préserve pas tous les formats : la passerelle refuse les squelettes, animations, textures, extensions, hiérarchies, matrices, morphs, UV, couleurs par sommet et primitives non prises en charge. Les GLB statiques simples sont acceptés. Cela ne constitue pas un validateur glTF complet ni une conservation générale des matériaux.

Ajouter un comportement : crée une fiche MobEntity liée, puis ouvre l'éditeur existant ; si elle existe déjà, la même fiche est rouverte. Les réglages restent actuellement ceux de l'atelier créature/Minecraft. Ils ne sont pas encore exécutés par un moteur de jeu Godot, ni injectés automatiquement dans la géométrie GLB.

Animer : ouvre AnimationEditor pour la fiche de créature liée. Les corps CreatureStudio peuvent bénéficier de leurs animations existantes. Cette action ne crée pas un rig pour un maillage sculpté et ne convertit pas ses animations en GLB.

Placer sur la carte : vérifie et prépare le GLB local, lie une SceneEntity à la fiche et transmet le modèle au véritable importeur Map Studio. Les URI content:// sont copiées dans un fichier privé compatible avec ce pont. Le placement et la sauvegarde de la carte restent dans Map Studio. Il ne s'agit pas d'une synchronisation automatique de toutes les instances déjà placées.

Les actions nécessitant un GLB ou une fiche de créature sont désactivées lorsqu'ils manquent. Un modèle sans GLB ne bénéficie pas d'une conversion automatique depuis son corps CreatureStudio.

## Bibliothèque et duplication

Les modèles Soldat, Chef HIBOU, HIPPO I/II/III et Corps vide utilisent le vrai éditeur CreatureStudio en lecture seule pour leur aperçu. Le pont Android refuse toute écriture dans ce mode et le pont JavaScript évite même de calculer/enregistrer le bundle. Les commandes de modification sont masquées ; la caméra reste disponible.

Pour les créations personnelles, les aperçus enregistrés sont réutilisés. L'aperçu GLB natif est chargé uniquement à la demande pour la fiche sélectionnée ; son dispositif de secours existant est conservé. Aucune série de moteurs 3D n'est lancée pour afficher toute la bibliothèque.

La duplication prépare de nouveaux identifiants et des copies des maillages/modèles/corps. Les clés du corps Minecraft et les profils AnimationProject liés sont adaptés au nouveau monstre. Les nouvelles entités ne sont pas déjà placées sur une carte. Les références aux images et textures sources peuvent être partagées : leur contenu n'est pas modifié par cette opération. Une référence manquante interrompt la duplication.

Les écritures des différents dépôts ne forment pas encore une transaction globale. Une panne pendant une copie peut laisser des copies partielles ou des fichiers orphelins, même si les originaux sont conservés. Avant une publication, ajouter un journal de transaction et un nettoyage des copies interrompues, puis tester la fermeture forcée et le stockage plein sur Android.

## Validation effectuée

- Six aperçus intégrés contrôlés avec le vrai pont JavaScript et un DOM simulé : ouverture, modification signalée, sauvegarde manuelle, retour et pagehide ne provoquent aucune écriture.
- Le fichier HTML généré contient le pont actuel ; il a été reconstruit depuis ses sources.
- Modèles HIBOU : 8 tests Python réussis.
- Parité export Bedrock Python/JavaScript : 3 tests réussis.
- Maillage/import-export : 186 contrôles Node réussis ; sculpture : 53 contrôles réussis.
- Deux suites JUnit ajoutées pour les identités, la découverte, les projets, les associations, les aliases, les duplications et la politique d'import. Elles n'ont pas pu être exécutées ici.

La commande bash gradlew :app:compileDebugKotlin --no-daemon échoue avant compilation : le téléchargement de Gradle 8.11.1 est inaccessible dans cet environnement. Cela ne prouve pas que le code Kotlin compile. Aucun APK, test tactile, rendu natif ni capture d'écran de cette nouvelle interface n'a été validé.

À lancer avec Java 17, le SDK Android et les dépendances disponibles : bash gradlew :app:testDebugUnitTest :app:assembleDebug. Puis tester sur le téléphone : première découverte et réouverture du projet, liaison de deux fiches, aperçu sans création, copie indépendante, refus d'un GLB animé/texturé, import dans le Modeleur, création d'un comportement, placement et sauvegarde de carte.

## Suite du projet

1. Compiler et corriger les éventuelles erreurs Kotlin/Compose ; vérifier les parcours Android.
2. Journal de transactions entre dépôts, annulation d'une liaison et suppression coordonnée des références.
3. Conversion contrôlée CreatureStudio → maillage avec conservation explicite des données compatibles ; rig et animation GLB.
4. Profils de comportement indépendants de Minecraft et exécution dans le futur jeu Godot.
5. Export compact pour le jeu et propagation des modifications aux instances de carte.
6. Mesures de mémoire, fluidité, énergie et pauses tactiles sur appareil ; optimisation basée sur ces mesures.

La tête fusionnée, les cinq doigts du mannequin et les futurs outils anatomiques ne sont pas modifiés dans cette version. Cette étape relie les ateliers ; elle ne termine pas les outils spécialisés ni le moteur de jeu.
