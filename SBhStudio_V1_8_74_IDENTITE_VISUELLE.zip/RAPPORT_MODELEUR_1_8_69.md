# SBh Studio V1.8.69 — Volumes, formes et premières pièces de forge

## Point de reprise
Suite de la V1.8.68 (noyau de sculpture). Cette livraison ajoute des outils de construction manuelle et des formes de départ modifiables. Elle ne termine pas l'ensemble du plan : squelettes, animation, UV, textures, vêtements ajustés et physique des véhicules restent à développer.

## Accès utilisateur
Créatures → Modeleur 3D → Ajouter :
- Humanoïde sculptable : mannequin volumétrique simple, tête/torse/bras/jambes fusionnés. Aucun détail anatomique ou facial fin.
- Loup sculptable et Cheval sculptable : masses fusionnées, pattes, tête, museau, oreilles et queue ; couleurs unies, modèles stylisés.
- Plaque / armure : largeur, hauteur, épaisseur, trou et courbure.
- Voiture modifiable : 21 objets séparés (châssis, carrosserie, habitacle, portes, vitrages, pneus, jantes, phares, essieux).

Sculpture → Volumes : choisir ellipsoïde, bloc ou capsule, le centre et les demi-tailles, puis ajouter/fusionner, soustraire ou garder l'intersection. Les cinq pinceaux de la V1.8.68 restent disponibles.

Objets → choisir la plaque → Dimensions, courbure et trou : modifier la pièce sans repartir de zéro.

## Ce qui est réellement implémenté
### Matière composable
Champ signé stocké dans le GLB, grille 33³ et domaine de 2,4 m. Les unions sont adoucies sur une largeur réglable ; soustraction/intersection sont exactes sur les échantillons. Les opérations respectent la symétrie locale X. Les bords restent positifs (vides). Une opération qui supprimerait toute la surface est annulée par le gestionnaire de reconstruction.

Les bases humain/animales sont constituées de volumes fusionnés, pas d'objets simplement juxtaposés. Leur génération et la reconstruction sont envoyées dans un Web Worker ; repli local différé si le Worker n'est pas disponible. Le corps humain détaillé de la V1.8.67 est également conservé comme choix « Humain » ; le mannequin sculptable est un autre choix, à résolution plus grossière.

### Forge de plaques
Géométrie fermée avec épaisseur réelle. Le trou traverse l'épaisseur et possède ses propres parois : c'est un changement de topologie, pas une zone peinte transparente. Le contour extérieur reste rectangulaire ; le trou circulaire est polygonalisé. Son rayon/centre sont bornés pour conserver au moins 1,5 cm de matière au bord.

Une courbure autour de l'axe vertical est appliquée à toutes les couches. L'épaisseur est bornée en fonction du rayon de courbure pour éviter le retournement de la face intérieure. Une plaque sans trou est également subdivisée lorsqu'elle est courbée.

Paramètres conservés dans node.extras.sbh.forge. La pièce se rouvre et reste paramétrique dans le Studio. Le passage en mode Face/Sommet retire cette liaison pour autoriser l'édition libre ; l'annulation la rétablit. Un logiciel externe peut supprimer les extras : conserver le GLB original pour reprendre la pièce paramétrique.

### Base de véhicule
21 maillages indépendants, couleurs modifiables, édition des faces/sommets possible. Longueur, largeur et rayon des roues réglables à la création. Export GLB multi-objets.

Pas encore de parent d'assemblage, de charnières ou d'animation des roues, pas de moteur de déplacement ni de collisions. Déplacer la carrosserie ne déplace pas automatiquement les autres pièces. C'est une base de modélisation de véhicule, pas une voiture jouable.

## Fichiers de travail
- app/src/main/assets/meshstudio/sculpt_core.js : composition et trois bases sculptables ; symétrisation des champs des bases.
- sculpt_worker.js : génération des bases et extraction en arrière-plan.
- forge_core.js : plaques percées/courbées et pièces du véhicule.
- mesh_core.js : aller-retour de la matière et des paramètres de forge dans les extras GLB.
- mesh_studio.html : menus, opérations manuelles, paramètres et rapport.
- tools/meshstudio/test_forms_forge.mjs : modèles, fusion/découpe, topologie des plaques, paramètres aléatoires et export véhicule.
- test_sculpt_integration.mjs : logique d'interface avec rendu/DOM/Worker simulés.
- version.json (racine et assets) : 1.8.69, versionCode 104.

Aucun code Kotlin modifié. Le rapport de la V1.8.68 est conservé dans le projet et les assets ; ce rapport est maintenant celui affiché dans l'atelier.

## Preuves et limites des vérifications
- 342 vérifications de formes, forge et véhicule réussies. Trois bases fermées, d'un seul tenant et symétriques ; 45 plaques aux paramètres pseudo-aléatoires ; le trou change bien la caractéristique d'Euler (0 avec trou, 2 sans trou) ; maillages du véhicule fermés et conservés dans le GLB.
- 160 vérifications de sculpture réussies.
- 186/186 vérifications du cœur géométrique réussies.
- 117/117 vérifications du générateur humain détaillé réussies.
- Logique d'intégration réussie : démarrage, tâches regroupées, sauvegarde différée, annulation/rétablissement, création d'un humanoïde sculptable, découpe de volume, plaque rééditée/sauvegardée, 21 pièces du véhicule.
- Syntaxe du module d'interface vérifiée.

Le test d'intégration simule le DOM, le rendu et le Worker : il ne prouve ni les gestes réels ni le fonctionnement d'une WebView Android. Chromium n'a pas pu être téléchargé correctement dans cet environnement. APK et Godot non exécutés. Les performances du téléphone, la consommation et le rendu restent à mesurer.

## Limites géométriques
La sculpture reste à 7,5 cm par cellule. Les animaux et le mannequin sont des ébauches stylisées, pas des modèles réalistes. Les traits fins, doigts, yeux, fourrure et textures ne sont pas représentés. Le domaine ne s'agrandit pas. La surface entière est reconstruite ; il n'y a pas encore d'extraction partielle par régions ou de résolution adaptative. La capsule utilise une approximation de distance lorsque ses rayons X/Z diffèrent.

La forge propose une plaque avec un seul trou circulaire. Les découpes arbitraires, chanfreins, trous multiples et attaches ne sont pas encore disponibles. La forme courbée est polygonalisée : elle n'est pas une simulation de rigidité ou de fabrication physique.

## Pack SF4
Non fusionné dans cette livraison. Compatibilité précédente conservée : trois projets Khalifah validés ; sept factions sans doublons avec l'AGW actuel ; 22 dossiers de skins. Intégration du catalogue, des exemples embarqués et des données de production encore nécessaire. Aucun sprite n'est présenté comme une texture UV du nouveau modeleur.

## Suite priorisée
1. Compiler l'APK avec le workflow GitHub existant. Tester sur téléphone création, pinceaux, volumes, perçage, sauvegarde/réouverture et ancien corps humain.
2. Mesurer la mémoire et le temps par opération ; introduire reconstruction par régions et résolution adaptative avant de raffiner visage/mains.
3. Parent d'assemblage, pivots et attaches ; plaques adaptées aux corps et premières couches de vêtements.
4. Squelettes séparés (humain/quadrupède), poids de peau, poses, animation et export GLB animé.
5. UV et peinture de textures, matériaux SBH et bibliothèques d'équipement.
6. Intégration complète du pack SF4 et branchement au catalogue/projet actif.
7. Comportements et physique des animaux/véhicules dans le jeu exporté.
