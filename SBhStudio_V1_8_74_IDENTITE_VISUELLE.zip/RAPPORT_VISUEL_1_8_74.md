# SBh Studio 1.8.74 — Identité visuelle

Date : 7 octobre 2026. Base : sources 1.8.73, versionCode 108. Nouvelle version : 1.8.74, versionCode 109.

## Direction validée

L'utilisateur a approuvé le hibou facetté doré et bleu nuit, le corbeau face au hibou blanc, les surfaces anthracite, les accents dorés et les cartes arrondies. Les trois références sont conservées dans docs/visual. Ce sont des maquettes générées, pas des captures d'une application compilée. Le personnage équipé, le camion et la ville de l'image de présentation sont des illustrations de concept et ne constituent pas des modèles livrés dans cette version.

## Changements intégrés

- Branding.kt : nouveau logo détouré ; fond statique nocturne avec oiseaux ; voile sombre ; logo dans l'en-tête de l'accueil et de l'Atelier. Le grand ancien panneau de marque devient une carte compacte, sans numéro de version périmé.
- AgwTheme.kt et Decor.kt : or chaud, texte secondaire plus neutre, panneaux plus opaques, cartes prioritaires dorées, onglet sélectionné sombre/doré plutôt que blanc, contours et médaillons cohérents. Les signatures publiques existantes restent compatibles ; les boutons peuvent recevoir une icône facultative et un libellé sur deux lignes.
- StudioGlyph.kt : icônes dessinées localement, une épaisseur commune, sans décodage PNG pour les cartes, onglets et destinations de navigation. Audio et IA reçoivent des icônes cohérentes ; le cerveau rose de la navigation est remplacé.
- StudioEdgeOrnament.kt : petite frise géométrique de bord, sans interaction ni animation.
- WorkshopScreen.kt : décor partagé derrière le Scaffold transparent. Le viewport reste sobre et utilise ses données et ses états vides existants.
- CreatureZone.kt : icônes de boutons cohérentes, libellés plus compacts ; Bibliothèque demeure la bibliothèque commune de 1.8.72/73, même si certaines références visuelles plus anciennes disent « Depuis un modèle ».
- Icône Android adaptative : nouveau hibou transparent sur fond bleu nuit, marges de sécurité. minSdk 26 : les ressources adaptatives sont utilisées ; les anciennes images de compatibilité restent dans les sources.
- Rapport accessible dans Créatures → Bibliothèque → Rapport et prochaines étapes, suivi du rapport de fiabilité 1.8.73.

Les opérations de création, d'ouverture, de liaison, de sauvegarde et d'export conservent leurs gestionnaires. Les formats de données n'ont pas été modifiés. Les contrôles JavaScript des éditeurs et les moteurs de sculpture, forge, volumes et sauvegarde coordonnée ne changent pas.

## Ressources et téléphone

Logo : PNG RGBA 1254 × 1254, canal transparent vérifié. Fond : PNG RGB 941 × 1672. Ils sont inclus localement, sans téléchargement au lancement. Le décodage des images branding est borné par inSampleSize (fond ≤ 1536 px, autres images ≤ 512 px). Pour ces ressources, dimensions décodées approximatives 470 × 836 et 313 × 313, soit 1,50 MiB et 0,37 MiB en RGBA. Ces chiffres sont des estimations du tampon pixel, pas une mesure complète de RAM Android. L'icône du lanceur est gérée séparément par Android. Pas d'animation décorative ni de boucle graphique ajoutée ; le viewport conserve son fonctionnement actuel.

Les PNG de production font environ 3,5 MiB ensemble, plus une copie du logo pour le lanceur. Une optimisation WebP et des variantes par densité pourront être faites après validation du rendu Android. Les références dans docs/visual ne sont pas embarquées comme assets Android.

## Vérifications réalisées et limite de livraison

- Toutes les ressources XML ont été analysées sans erreur.
- PNG vérifiés ; transparence du logo présente.
- Versions racine/assets identiques.
- Délimiteurs des neuf fichiers Kotlin modifiés/ajoutés contrôlés ; recherche des fonctions locales déclarées trop tard sans signalement. Ces vérifications ne constituent pas une compilation Kotlin.
- Comparaison avec l'archive 1.8.73 : modifications limitées à l'habillage, ses ressources, la consultation du rapport et la version/documentation. Les gestionnaires Atelier et Créatures sont conservés.
- Tentative `bash gradlew :app:compileDebugKotlin --no-daemon` : bloquée avant compilation, téléchargement Gradle 8.11.1 impossible (`Network is unreachable`). Aucun APK nouveau ni capture Android réelle n'est fourni.

## Validation suivante

Sur une machine ou CI avec Java 17, SDK Android et accès aux dépendances : `bash gradlew :app:testDebugUnitTest :app:assembleDebug`. Puis vérifier accueil, Atelier/Hub/Créatures, défilement des onglets, choix du projet, création et réouverture d'un modèle, navigation des six destinations, portrait/paysage, petit écran et texte agrandi. Contrôler le masque de l'icône Android, le contraste et la mémoire au changement d'écran. Prendre des captures réelles de la version compilée.

La refonte concerne les composants natifs partagés, l'accueil et l'Atelier. Les interfaces internes HTML du Modeleur, Map Studio et CreatureStudio conservent leur habillage spécialisé actuel. Le mode clair n'a pas fait l'objet d'une nouvelle maquette ni d'un test. La présentation finale ne sera pas identique au pixel près aux images générées.
