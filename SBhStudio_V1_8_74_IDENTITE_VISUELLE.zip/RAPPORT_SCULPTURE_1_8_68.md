# SBh Studio V1.8.68 — Sculpture volumétrique V1

## Résultat livré
Premier noyau de sculpture intégré au Modeleur 3D existant. Il permet de partir d'une boule, d'ajouter/enlever de la matière et de déformer sa surface. Ce jalon ne constitue pas encore un atelier complet de voitures ou d'animaux.

Accès : Créatures → Modeleur 3D → Ajouter → Matière sculptable. L'onglet Sculpture ouvre les pinceaux, leurs réglages et ce rapport.

## Outils utilisables
- Gonfler : diminution locale du champ signé, ajout de matière.
- Creuser : augmentation du champ signé, retrait de matière (cavités possibles).
- Lisser : moyenne des six voisins, avec influence locale. Peut réduire le volume.
- Tirer : transport local du champ par rééchantillonnage trilinéaire.
- Aplatir : rapprochement vers le plan tangent touché.
- Rayon 0,15–0,60 m et force 0,05–1.
- Symétrie X optionnelle dans le repère local de la pièce. La désactiver autorise une sculpture asymétrique.
- Navigation explicite : Sculpture → Tourner / zoomer la vue. Séparer la navigation du sculptage évite les conflits de gestes.
- Annulation / rétablissement par geste terminé, dans une limite de mémoire de 24 Mo pour l'historique de l'ensemble du modeleur.

## Architecture
sculpt_core.js : champ signé (négatif = matière), grille 33 × 33 × 33, domaine fixe de 2,4 m. Pas de Three.js ni de DOM. Pas de symétrie imposée lors de l'extraction.

Mises à jour des valeurs limitées aux boîtes locales des pinceaux. Extraction Surface Nets générique et réparation manifold réutilisée depuis body_core.js. La surface complète est reconstruite à chaque travail : il n'y a pas encore de découpage en régions avec reconstruction partielle.

sculpt_worker.js : extraction en Web Worker. Une tâche active au maximum, les demandes intermédiaires sont regroupées en conservant le champ le plus récent. Repli synchrone différé si le Web Worker est indisponible : dans ce cas le calcul peut suspendre brièvement l'interface.

mesh_studio.html : gestes, historique, état de reconstruction, réglages et rapport. Une erreur ou suppression complète de la matière restaure le dernier état validé.

mesh_core.js : stockage du champ dans node.extras.sbh.sculpt, en plus du maillage glTF. Un moteur de jeu utilise la surface ; le Studio retrouve la matière après réouverture. Les logiciels externes peuvent supprimer ces extras : conserver le GLB original du Studio pour poursuivre la sculpture.

Le passage en mode Sommet ou Face convertit la pièce en maillage : son champ est retiré afin d'éviter de reconstruire depuis un volume devenu incohérent. L'annulation restaure le champ. Déplacement, rotation et échelle de l'objet restent possibles sans conversion.

## Validation exécutée
- node tools/meshstudio/test_sculpt_core.mjs : 160 vérifications réussies, dont 80 coups pseudo-aléatoires. Géométrie finie, surfaces fermées, symétrie, ajout/retrait, déformation, sculpture après aller-retour GLB.
- node tools/meshstudio/test_mesh_core.mjs : 186/186 vérifications réussies.
- node tools/meshstudio/test_body_core.mjs : 117/117 vérifications réussies (générateur humain conservé).
- node tools/meshstudio/test_sculpt_integration.mjs : démarrage, reconstruction regroupée, sauvegarde différée, annulation, rétablissement et conversion réussis. DOM, rendu et Worker simulés ; géométrie Three.js réelle. Ce test ne vérifie pas les gestes ou le rendu d'un navigateur.
- Syntaxe du module d'interface vérifiée sous Node.

Non exécuté : APK Android, gestes sur écran physique, test visuel WebGL, mesure de mémoire/batterie, export ouvert dans Godot. L'installation de Chromium/Headless Shell a échoué dans cet environnement (archives téléchargées inutilisables).

## Limites du jalon
Résolution de 7,5 cm : silhouette et gros volumes, pas de doigts, visage fin ou gravures. Les bords du domaine restent vides pour éviter les surfaces ouvertes ; aucune extension du domaine pour l'instant. Pas de conversion du corps humain existant en matière, pas de pinceau de peinture, UV, matériaux PBR, squelette, animation, pièces mécaniques, perçage industriel ou physique de véhicule. Surface reconstruite entièrement, pas de garantie de fluidité sur téléphone.

## Pack SF4
Compatibilité étudiée avant ce jalon : les trois Khalifah passent le validateur Creature Studio ; sept factions sans conflit d'identifiants ; 22 dossiers de sprites. Le pack SF4 n'est pas fusionné dans cette version. Il demande notamment une adaptation du catalogue de skins, l'enregistrement des exemples dans l'éditeur embarqué et le branchement des données de production. Les créatures paramétriques du pack ne sont pas automatiquement des sculptures volumétriques.

## Étapes suivantes
1. Compiler via le workflow GitHub existant et tester les cinq pinceaux sur Android, sauvegarde et réouverture comprises.
2. Mesurer les temps et la mémoire sur téléphone ; découper le volume en régions avant de proposer une résolution plus fine.
3. Ajout de volumes fusionnables et bases de quadrupèdes. Conversion contrôlée d'un maillage vers le champ.
4. Atelier de pièces rigides : plaques, épaisseur, extrusion, découpes, trous, attaches ; puis roues, essieux et assemblages de véhicules.
5. Squelettes distincts, poids de peau, textures et export animé.

La V1.8.67 reste la référence précédente ; seuls le modeleur, son format d'extras et les métadonnées de version ont changé. Le code Kotlin et les autres ateliers n'ont pas été modifiés.
