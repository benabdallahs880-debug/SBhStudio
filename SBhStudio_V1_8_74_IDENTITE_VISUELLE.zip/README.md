# SBh Studio V1.8.74 — Source complète Android

versionName : 1.8.74 · versionCode : 109

Le modeleur conserve ses ateliers et ajoute un noyau de sculpture, des volumes composables, des bases humain/loup/cheval, une forge de plaques percées/courbées et une voiture en pièces modifiables.

La V1.8.73 renforce les fiches communes : journal de sauvegarde avec reprise, annulation des liaisons, recherche et diagnostics des documents manquants. Lire RAPPORT_FIABILITE_1_8_73.md. Le moteur Java est compilé/testé ; la compilation Kotlin/Android reste à vérifier.

La V1.8.74 intègre la nouvelle identité visuelle dans les composants natifs : logo facetté, fond corbeau/hibou, icônes vectorielles, accents dorés et surfaces plus lisibles. Lire RAPPORT_VISUEL_1_8_74.md. Les références approuvées sont dans docs/visual ; elles sont des maquettes, pas des captures Android.

## Compiler

Avec Java 17 et le SDK Android installés :

```bash
bash gradlew :app:testDebugUnitTest :app:assembleDebug
```

APK produit : app/build/outputs/apk/debug/app-debug.apk.

## Essayer

Créatures → Bibliothèque commune → une création → Fiche commune. Les modèles intégrés offrent un aperçu 3D sans sauvegarde et une copie modifiable. Pour les formes : Créatures → Modeleur 3D → Ajouter. Sculpture ouvre les pinceaux et les opérations de fusion/découpe. Objets permet de choisir une pièce, changer sa couleur ou rééditer une plaque paramétrique.

## État réel et reprise

Lire RAPPORT_MODELEUR_1_8_69.md. Il est aussi consultable dans l'atelier Sculpture → Rapport et prochaines étapes. RAPPORT_SCULPTURE_1_8_68.md documente la première étape.

La version est un prototype source à compiler et vérifier sur Android. Le véhicule n'a pas encore de physique, les bases sculptables n'ont pas de squelette/animation et les textures UV restent à développer. Le pack SF4 n'est pas fusionné.

## Tests exécutables sans Android

```bash
node tools/meshstudio/test_mesh_core.mjs
node tools/meshstudio/test_body_core.mjs
node tools/meshstudio/test_sculpt_core.mjs
node tools/meshstudio/test_forms_forge.mjs
node tools/meshstudio/test_sculpt_integration.mjs
node tools/meshstudio/test_precision_finish.mjs
```

Le dernier test utilise un DOM, un rendu et un Worker simulés. Les tests tactiles navigateur existants nécessitent Playwright/Chromium et un serveur HTTP local ; ils ne remplacent pas un essai sur téléphone.

La 1.8.71 ajoute la sculpture de surface des maillages importés, les masques, le réglage du lissage et la conservation de la précision des axes non modifiés. Tests : `node tools/meshstudio/test_mesh_sculpt.mjs`.
