# SBh Studio 1.8.70 — Précision et finition

## Ajouts utilisables

- Six pinceaux : ajouter, creuser, déplacer, lisser, aplatir, polir.
- Contour de portée et contour du cœur du pinceau, avec aperçu miroir suivant le repère de l’objet.
- Douceur du bord réglable : plateau central puis transition progressive.
- Stabilisation par distance de traîne réglable de 0 à 15 cm.
- Contraintes dans le repère local : libre, X, Y, Z, XY, XZ, YZ.
- Vues rapides de face, dos, profils gauche/droit et dessus, avec cadrage de l’objet.
- Empreintes espacées régulièrement selon le rayon. Une file traite deux empreintes à la fois ; le relâchement attend sa fin et la reconstruction avant de valider un seul état d’annulation.
- Polissage par deux passes de signes opposés : atténue les irrégularités et limite le retrait par rapport au lissage simple dans le cas sphérique testé. Aucune garantie de conservation exacte du volume.

## Reconstruction et protection

Un cas de surface pincée a été détecté dans la séquence aléatoire de sculpture. Chaque extraction vérifie maintenant la fermeture des arêtes orientées après réparation. En cas de pincement, elle essaie les seuils 0, ±0,001, ±0,005 puis ±0,01 dans le champ signé. Cet ajustement est borné dans le champ, mais ne garantit pas un déplacement géométrique identique, car le champ sculpté n’est plus toujours une distance exacte. Le champ sauvegardé et sa frontière restent inchangés. La première surface fermée est retenue.

Si toutes les tentatives échouent ou si toute la matière disparaît, l’application annule le changement en cours et restaure le dernier état validé avec un message. Elle ne valide pas de surface ouverte. Les gestes courts ou espacés restent limités par la résolution ; les coins très fins ne sont pas garantis. L’échantillonnage réduit la dépendance au nombre d’événements sur un trajet droit ; un trajet courbe dépend encore des positions reçues. Au-delà de 128 segments en attente, la dernière cible est remplacée pour borner la file.

## Validation

Tests Node avec la géométrie Three.js réelle ; DOM, rendu et worker simulés pour le test d’intégration.

- Maillage/export : 186 contrôles.
- Corps : 117 contrôles.
- Sculpture : 160 contrôles, dont une séquence déterministe de 80 coups.
- Formes et forge : 342 contrôles, dont 45 plaques aléatoires.
- Précision/finition : 20 contrôles sur contraintes, traîne, espacement, douceur, polissage, symétrie et frontière.
- Intégration : création, reconstruction asynchrone, sauvegarde, conversion, annuler/rétablir ; geste avec raycasting, vidage de la file et annulation unique ; restauration après échec de reconstruction.

Aucun test visuel dans un vrai navigateur ni test tactile/APK Android n’a été effectué. L’aperçu dans le chat utilise le même noyau mais reconstruit localement sans Web Worker.

## Limites et suite

Le domaine reste une grille 33³ sur 2,4 m, soit 7,5 cm entre échantillons. Les réglages améliorent le geste et la finition à cette résolution ; ils n’ajoutent pas encore de microdétails. Le raffinement local, les chanfreins paramétriques des plaques, les masques, les UV et la peinture seront des étapes distinctes. Le polissage concerne la matière sculptable ; les plaques gardent leurs outils d’épaisseur, perçage et courbure.

Les formes fusionnables, humanoïde/loup/cheval, voiture en 21 pièces et forge de la 1.8.69 sont conservés. Pas de rigging, animation ou physique véhicule. Le pack SF4 reste à intégrer, comme documenté dans RAPPORT_MODELEUR_1_8_69.md. Les rapports des versions précédentes sont conservés.
