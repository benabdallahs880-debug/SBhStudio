# V1.8.64 : SBH Data Contract v1, le format commun entre SBh Studio et le jeu SBH World

Ce dossier se lit sans l'historique de la conversation. C'est la **première brique** de la « salle de contrôle » demandée par l'utilisateur :
1. **le format commun** (ce travail) ;
2. puis le labo de test ;
3. puis l'éditeur des règles, l'explorateur de seeds, le simulateur accéléré et les ateliers de contenu.

Le document de référence est **`contract/SPEC_SBH_DATA_CONTRACT_v1.md`**.

---

## 1. Ce qui a été fait

1. **Le contrat, version 1.0.0.**
   - Un monde est un **dossier**. Son manifeste `sbh_world.json` donne l'identité, la graine, la taille en chunks et la liste **signée** (sha256) des fichiers.
   - Cinq fichiers de règles :
     - **biomes** : température, humidité, altitude, faune, ressources, végétation ;
     - **cultures architecturales** : familles de bâtiments et variantes ;
     - **établissements** : installation, organisation, bâtiments, croissance ;
     - **routes** ;
     - **factions**, avec une **matrice de relations orientée** de −100 à +100 et 6 attitudes, plus nuancée qu'ami / ennemi.
   - Le contenu reprend les formats existants : corps CreatureStudio et structures.
   - Le **rapport de test** du labo est déjà défini : appareil, graine, FPS (min, moyenne, p1, p50, p95), durée des images, mémoire, temps par système, chunks détaillés, abstraits et par LOD, événements.
2. **Règles communes.**
   - JSON strict, identifiants stables, unités fixées (m, °C, 0..1), intervalles `{min, max}`.
   - Compatibilité : un champ ajouté est toujours facultatif, un champ inconnu est signalé puis ignoré, `x_…` sert aux extensions privées, et la version majeure change seulement en cas de rupture.
   - 20 codes d'erreur et d'avertissement stables.
3. **Trois validateurs qui donnent exactement les mêmes résultats.**
   - **Référence Python** : `contract/reference/sbh_contract.py`, sans dépendance. Commandes : `validate`, `manifest` (signature) et `conformance`.
   - **Studio Kotlin** : `app/src/main/java/com/sbh/studio/contract/`, Kotlin pur avec un lecteur JSON maison. Les schémas sont copiés dans `assets/contract/schemas/`.
   - **Jeu Godot 4 (GDScript)** : `contract/godot/addons/sbh_contract/`, à copier tel quel dans le projet SBH World. Il a son propre lecteur **JSON strict**, car le JSON de Godot accepte des fautes que le Studio refuse.
4. **La preuve qu'il n'y a qu'un seul format.**
   - 51 cas de conformité écrits à la main, un par règle.
   - Un test différentiel : 500 variantes aléatoires de l'exemple, plus 19 cas de JSON limite.
   - Les trois validateurs ont été **exécutés réellement**, avec Kotlin 2.1.21 et Godot 4.4.1 sans écran installés pour l'occasion. Résultat : **100 % identiques**.
5. **Un exemple complet** : `contract/examples/al_zahra_mini/`, valide et signé.
   - 3 biomes, 2 cultures (bédouine, citadine royale) et 3 types d'établissements.
   - 2 routes, 6 factions et 8 relations, avec les identifiants déjà utilisés par l'app (`hibou`, `ghurab`…).
   - 1 créature et la maison de forgeron.
6. **Un convertisseur** de l'ancien `assets/agw/factions.json` vers la matrice du contrat. Résultat dans `contract/examples/import_agw/factions.json`.

### Défauts trouvés et corrigés pendant le travail
- Le test aléatoire a trouvé un **plantage** : un chemin de fichier invalide dans le manifeste faisait planter la lecture du disque. Corrigé dans les trois validateurs : on ne touche plus au disque quand le chemin est déjà refusé par le schéma.
- Le test « JSON limite » a montré que **le JSON de Godot accepte** des fichiers que le Studio refusait : virgule finale, BOM, `02`, `2.`, tabulation brute. À l'inverse, Python acceptait `NaN`. On aurait eu deux formats qui divergent en silence. Les trois validateurs lisent maintenant le **même JSON strict**, et 12 cas le vérifient.

### Incohérence de données relevée (à trancher par l'utilisateur)
- `assets/agw/factions.json` met **`hibou` neutre envers `royaume`**. La bible SBH World dit au contraire : « les Hiboux attaquent directement le royaume et les Templiers (guerre frontale directe) ».
- L'exemple du contrat suit la bible, et la conversion automatique garde l'ancienne valeur.
- Il faut décider laquelle est juste, puis corriger dans la matrice.

## 2. Fichiers ajoutés ou modifiés

| Fichier / dossier | Statut |
|---|---|
| `contract/SPEC_SBH_DATA_CONTRACT_v1.md`, `contract/README.md`, `contract/CHANGELOG.md` | nouveaux |
| `contract/schemas/*.schema.json` (7) | nouveaux, **générés** par `contract/tools/gen_schemas.py` |
| `contract/reference/sbh_contract.py` | nouveau (référence) |
| `contract/godot/` : `project.godot`, `addons/sbh_contract/sbh_contract.gd` + `schemas/`, `tests/run_conformance.gd`, `.gitignore` | nouveaux |
| `contract/conformance/` (51 cas + `expected.json`) | nouveaux, générés par `contract/tools/make_cases.py` |
| `contract/examples/al_zahra_mini/`, `contract/examples/import_agw/` | nouveaux |
| `contract/tools/` : `gen_schemas.py`, `make_example.py`, `make_cases.py`, `import_agw_factions.py`, `fuzz_diff.py`, `run_all.sh` | nouveaux |
| `app/src/main/java/com/sbh/studio/contract/SbhJson.kt`, `ContractValidator.kt`, `ContractConformance.kt` | nouveaux |
| `app/src/test/java/com/sbh/studio/contract/ContractConformanceTest.kt` | nouveau (3 tests) |
| `app/src/main/assets/contract/schemas/` | nouveaux (copie des schémas) |
| `version.json` (racine et `assets/`) | 1.8.64, code 99 |

Rien d'autre n'a changé dans l'app : aucun écran, aucun format de sauvegarde.

## 3. Comment vérifier

```bash
bash contract/tools/run_all.sh            # référence + Kotlin (si kotlinc) + Godot (si godot)
./gradlew testDebugUnitTest               # inclut ContractConformanceTest (51 cas + exemple)
python3 contract/reference/sbh_contract.py validate <dossier_monde>
```

## 4. Ce qui reste à faire

### À faire par l'utilisateur
1. **Envoyer la constitution technique et l'archive actuelle du jeu Godot.** Le contrat a été écrit sans elles : les hypothèses sont au § 11 de la SPEC. Ensuite, je l'ajuste (en version 1.x, sans rien casser).
2. **Trancher l'incohérence `hibou` / `royaume`** (§ 1).
3. **Compiler sur GitHub.** Le Kotlin du contrat a été compilé et exécuté ici avec kotlinc 2.1.21, mais pas encore dans la compilation Android complète.

### Prochaine étape prévue : le labo de test
- Le jeu Godot : lire un paquet (addon `sbh_contract`), lancer une seed, survoler le monde, afficher par-dessus les chunks, les LOD et les zones détaillée et abstraite, mesurer, puis **écrire un `test_report`** conforme.
- Le Studio : exporter un paquet de monde signé (avec `ContractValidator` avant l'export), recevoir et lire les rapports de test, comparer deux rapports.
- Retirer ensuite `placements.json`, `protocol.json` et `structure_ref.json` : c'est l'ancien second pipeline vers Godot (voir SPEC § 10).

### Contrat v1.x prévu (ajouts facultatifs)
- Régions.
- Végétation et ressources sous forme de références.
- PNJ.
- Lieux faits main (maps Map Studio).
- Paramètres du simulateur accéléré.
- Format des sorties générées (carte vue du ciel, état de simulation).

### Pas encore fait (en attente de ton accord)
- La correction de l'affichage de Map Studio sur téléphone (analyse du 2026-10-06 : barre d'actions cachée, panneaux trop petits, cibles tactiles trop petites). Elle peut être faite à tout moment, indépendamment du contrat.
