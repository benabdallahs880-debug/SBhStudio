# SBh Studio 1.8.71 — Sculpture de surface sur la base humaine

## Première phase livrée

Le mode Sculpture accepte maintenant les maillages importés, sans conversion dans la grille volumétrique 33³. Le nouveau noyau conserve les faces et le nombre de sommets ; il déplace localement les sommets existants.

Pinceaux : Gonfler, Creuser, Tirer, Lisser, Polir, Aplatir et Pincer. Le rayon peut descendre à 5 mm pour la surface ; il ne crée toutefois pas de détail plus fin que les sommets existants. Le rayon est exprimé dans le repère local de l’objet, avant son échelle.

Protéger et Déprotéger peignent un masque binaire. Les sommets protégés restent immobiles ; une teinte violette indique le masque dans le rendu. Effacer le masque le retire. Il est sauvegardé dans les extras SBH du GLB et restauré à l’import. La teinte de visualisation ne remplace pas la couleur de l’objet dans l’export.

Les masques fonctionnent uniquement sur la surface, pas sur la matière volumétrique. Le mode volumétrique et ses opérations de fusion/découpe sont conservés séparément. Une plaque paramétrique est convertie en maillage lors de son passage à la sculpture ; annuler permet de retrouver ses paramètres.

Le panneau Objets ajoute un réglage de lissage. Le panneau Valeurs conserve désormais la précision complète des axes qui ne sont pas modifiés.

## Protections et limites géométriques

La région du pinceau est parcourue par voisinage connecté à partir du point le plus proche. Les surfaces arrière et les bords ouverts/non-manifold sont protégés. Le déplacement est borné à un quart de la plus courte arête voisine et 15 % du rayon. Un coup qui inverse ou écrase un triangle touché est refusé.

Ces contrôles ne garantissent pas l’absence d’auto-intersection ou de contact entre objets. Le pinceau ne perce pas de trou, ne fusionne pas les objets et ne crée pas de doigts. Une symétrie reste approximative si le maillage de départ n’a pas de correspondances symétriques.

Le travail de surface s’exécute sur le thread principal, par petits lots espacés. Les 8 coups testés sur le corps prennent environ 180 ms au total dans Node sur cet environnement ; ce n’est pas une mesure Android. L’indexation spatiale et un worker dédié restent à étudier si les essais tactiles révèlent des pauses.

## Session réelle des commandes du Studio

Entrée : base_human_homme_5vues.glb, 25 pièces, cinq copies du même homme.

La page originale du modeleur a été exécutée avec DOM, contrôle caméra et rendu simulés. Les gestionnaires Objets, Sculpture, réglages des pinceaux, rayon/force, masque, annulation et sauvegarde sont ceux de l’application. Les points écran ont été projetés sur le corps, puis frappés par le raycasting Three.js réel. Ce sont des tests d’entrée programmatiques, pas une session tactile filmée ni un rendu navigateur vérifié.

Sur chaque corps : 12 coups Gonfler au niveau de trois bandes abdominales avec symétrie, puis deux coups Creuser sur la ligne centrale. Un masque de protection au haut du torse a été peint et effacé par les commandes de l’atelier. Les changements sont prudents : déplacement maximal ≈ 1,225 mm. Le modèle n’est pas annoncé comme conforme à la photographie de référence, dont les détails ne sont pas visibles dans les captures transmises.

Les cinq copies sont conservées dans base_human_homme_5vues_sculpte.glb. Têtes, shorts, cheveux et barbes n’ont pas été sculptés. Les faces et sommets ont été conservés ; tous les corps restent fermés et symétriques dans les contrôles. Un export de travail à cinq pièces centré est également fourni ; les autres copies ont été retirées par les commandes Objets dans cette copie de travail.

Aucun outil extérieur n’a modélisé le corps de la session.

## Validation

- Maillage/export : 186 contrôles.
- Corps : 117 contrôles (exécutés dans la phase précédente, code corps inchangé).
- Volume : 160 contrôles.
- Formes/forge : 342 contrôles.
- Précision/finition : 20 contrôles.
- Nouvelle sculpture de maillage : 53 contrôles incluant la base fournie, les sept pinceaux, frontière, voisin déconnecté, masque et sauvegarde.
- Intégration : masque visible dans les attributs de géométrie, sauvegarde/restauration, conservation du mode Sculpture dans l’historique, gestes volumétriques et export.
- Session base humaine : 70 coups par raycasting répartis sur cinq corps, annuler/rétablir et réimport.

Le navigateur distant ne peut pas accéder au serveur local du Studio. Aucun navigateur local fonctionnel ni Godot n’est installé dans cet environnement. Aucune vraie capture d’écran n’a donc été produite. L’aperçu interactif ne remplace pas les captures et essais APK demandés. Il montre un seul mannequin pour réduire la charge ; son transport arrondit les coordonnées à 0,1 mm et retire les métadonnées de maillage redondantes. Les fichiers GLB livrés conservent la précision de la sauvegarde SBH.

## Suite et erreurs suivies

HIBOU-001 : sculpture importée débloquée pour les maillages de surface.
HIBOU-002 : réglage de lissage ajouté ; conservation des normales importées générales toujours à améliorer.
HIBOU-003 : correction de la précision des coordonnées réalisée.
HIBOU-004 : export compact pour le jeu toujours à développer ; la sauvegarde éditable reste redondante.

Phase suivante du générateur : tête sans visage réellement fusionnée au cou, mains avec cinq doigts séparés, pieds simples, proportions et reliefs anatomiques. Elle n’a pas été intégrée dans cette livraison. Les captures d’une autre session ne contiennent pas son code ; aucun état non récupéré n’est présenté comme repris à l’identique.
