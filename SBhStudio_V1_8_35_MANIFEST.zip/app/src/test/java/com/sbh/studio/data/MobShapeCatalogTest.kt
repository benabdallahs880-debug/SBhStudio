package com.sbh.studio.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MobShapeCatalogTest {

    @Test
    fun allShapes_resolveToOwnGeometry() {
        MobShapeCatalog.shapes.forEach { shape ->
            assertEquals(shape.geometryId, MobShapeCatalog.geometryFor(shape.id))
        }
    }

    @Test
    fun unknownForme_hasFallback() {
        val fallback = MobShapeCatalog.geometryFor("forme_inconnue_xyz")
        assertTrue(fallback.isNotBlank())
        assertTrue(fallback.startsWith("geometry."))
    }

    @Test
    fun shapeIds_areUnique() {
        val ids = MobShapeCatalog.shapes.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test
    fun humanoid_usesCustomGeometry() {
        assertTrue(MobShapeCatalog.geometryFor("humanoid").contains("humanoid"))
    }
}
