package com.sbh.studio.data

import org.junit.Assert.assertEquals
import org.junit.Test

class SkinLibraryFormeTest {

    @Test
    fun recommendedForme_knownCategories() {
        assertEquals("wolf", SkinLibrary.recommendedForme("wolf"))
        assertEquals("wolf", SkinLibrary.recommendedForme("cat"))
        assertEquals("cow", SkinLibrary.recommendedForme("cow"))
        assertEquals("cow", SkinLibrary.recommendedForme("dolphin"))
        assertEquals("chicken", SkinLibrary.recommendedForme("chicken"))
        assertEquals("chicken", SkinLibrary.recommendedForme("axolotl"))
        assertEquals("chicken", SkinLibrary.recommendedForme("squid"))
        assertEquals("zombie", SkinLibrary.recommendedForme("zombie"))
        assertEquals("creeper", SkinLibrary.recommendedForme("creeper"))
        assertEquals("creeper", SkinLibrary.recommendedForme("ghast"))
        assertEquals("creeper", SkinLibrary.recommendedForme("guardian"))
        assertEquals("spider", SkinLibrary.recommendedForme("spider"))
        assertEquals("zombie", SkinLibrary.recommendedForme("piglin"))
        assertEquals("zombie", SkinLibrary.recommendedForme("villager"))
        assertEquals("humanoid", SkinLibrary.recommendedForme("enderman"))
        assertEquals("humanoid", SkinLibrary.recommendedForme("blaze"))
    }

    @Test
    fun recommendedForme_unknown_isHumanoid() {
        assertEquals("humanoid", SkinLibrary.recommendedForme("dragon_custom"))
        assertEquals("humanoid", SkinLibrary.recommendedForme(""))
    }
}
