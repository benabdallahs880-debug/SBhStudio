package com.sbh.studio.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Tests unitaires P0 — Identifiers (logique pure, sans Android).
 */
class IdentifiersTest {

    @Test
    fun validId_passes() {
        assertTrue(Identifiers.isValid("agw:zombie_elite"))
        assertTrue(Identifiers.isValid("minecraft:stone"))
        assertTrue(Identifiers.isValid("ns:path/to_item"))
    }

    @Test
    fun invalidId_fails() {
        assertFalse(Identifiers.isValid("zombie"))
        assertFalse(Identifiers.isValid(""))
        assertFalse(Identifiers.isValid("AGW:Zombie"))
        assertFalse(Identifiers.isValid("agw:mon item"))
        assertFalse(Identifiers.isValid("agw:"))
        assertFalse(Identifiers.isValid(":name"))
    }

    @Test
    fun explain_messages() {
        assertEquals("identifiant vide", Identifiers.explain(""))
        assertEquals("identifiant vide", Identifiers.explain("   "))
        assertNotNull(Identifiers.explain("zombie"))
        assertNull(Identifiers.explain("agw:ok_name"))
        assertNotNull(Identifiers.explain("agw:.hidden"))
        assertNotNull(Identifiers.explain("agw:trail."))
    }

    @Test
    fun namespaceOf_and_nameOf() {
        assertEquals("agw", Identifiers.namespaceOf("agw:zombie"))
        assertEquals("zombie", Identifiers.nameOf("agw:zombie"))
        assertEquals("agw", Identifiers.namespaceOf("zombie"))
        assertEquals("zombie", Identifiers.nameOf("zombie"))
        assertEquals("ns", Identifiers.namespaceOf("ns:a/b"))
        assertEquals("a/b", Identifiers.nameOf("ns:a/b"))
    }
}
