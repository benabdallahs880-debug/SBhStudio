package com.sbh.studio.generator

import com.sbh.studio.data.MobEntity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MobPackJsonTest {

    private fun sampleMob(
        profilIA: String = "guerrier",
        hostile: Boolean = true,
        attaque: Boolean = true,
        poursuite: Boolean = true,
        formeBase: String = "humanoid"
    ) = MobEntity(
        projectId = "p1",
        nom = "Test",
        identifiant = "agw:test_mob",
        hostile = hostile,
        poursuite = poursuite,
        attaque = attaque,
        profilIA = profilIA,
        formeBase = formeBase
    )

    @Test
    fun textureKey_replacesColon() {
        assertTrue(MobPackJson.textureKey("agw:zombie") == "agw_zombie")
    }

    @Test
    fun archer_usesRangedNotMelee() {
        val json = MobPackJson.behaviorEntityJson(sampleMob(profilIA = "archer"), "agw", "test_mob")
        assertTrue(json.contains("minecraft:behavior.ranged_attack"))
        assertFalse(json.contains("minecraft:behavior.melee_attack"))
        assertTrue(json.contains("minecraft:shooter"))
    }

    @Test
    fun warrior_usesMelee() {
        val json = MobPackJson.behaviorEntityJson(sampleMob(profilIA = "guerrier"), "agw", "test_mob")
        assertTrue(json.contains("minecraft:behavior.melee_attack"))
        assertFalse(json.contains("minecraft:behavior.ranged_attack"))
    }

    @Test
    fun passive_noPursuitTarget() {
        val json = MobPackJson.behaviorEntityJson(
            sampleMob(profilIA = "passif", hostile = true, poursuite = true),
            "agw", "test_mob"
        )
        assertFalse(json.contains("minecraft:behavior.nearest_attackable_target"))
    }

    @Test
    fun hostilePursuit_hasTarget() {
        val json = MobPackJson.behaviorEntityJson(
            sampleMob(profilIA = "guerrier", hostile = true, poursuite = true),
            "agw", "test_mob"
        )
        assertTrue(json.contains("minecraft:behavior.nearest_attackable_target"))
    }

    @Test
    fun clientEntity_humanoidHasPlayerAnims() {
        val json = MobPackJson.clientEntityJson(sampleMob(formeBase = "humanoid"), "agw", "test_mob", "agw_test_mob")
        assertTrue(json.contains("animation.player.move.arms"))
        assertTrue(json.contains("geometry."))
    }

    @Test
    fun clientEntity_nonHumanoidHasLookAndWalk() {
        val json = MobPackJson.clientEntityJson(sampleMob(formeBase = "cow"), "agw", "test_mob", "agw_test_mob")
        assertTrue(json.contains("animation.common.look_at_target"))
        assertTrue(json.contains("animation.quadruped.walk"))
        assertFalse(json.contains("animation.player.move.arms"))
    }

    @Test
    fun clientEntity_spiderUsesSpiderWalk() {
        val json = MobPackJson.clientEntityJson(sampleMob(formeBase = "spider"), "agw", "test_mob", "agw_test_mob")
        assertTrue(json.contains("animation.spider.walk"))
        assertFalse(json.contains("animation.quadruped.walk"))
    }

    @Test
    fun eggColor_isHex() {
        val c = MobPackJson.eggColor("agw:test", 0.6f)
        assertTrue(c.matches(Regex("#[0-9A-Fa-f]{6}")))
    }
}
