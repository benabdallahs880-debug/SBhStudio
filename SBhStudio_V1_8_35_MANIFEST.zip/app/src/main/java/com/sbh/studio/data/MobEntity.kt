package com.sbh.studio.data

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class MobEntity(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val nom: String,
    val identifiant: String,
    val vie: Int = 20,
    val vitesse: Double = 0.25,
    val degats: Int = 3,
    val hostile: Boolean = false,
    val poursuite: Boolean = false,
    val attaque: Boolean = false,
    val reactionDegats: Boolean = true,
    val pouvoirVitesse: Boolean = false,
    val pouvoirResistance: Boolean = false,
    val pouvoirInvisibilite: Boolean = false,
    // Atelier Mobs V0.8 : réglages avancés, tous rétrocompatibles grâce aux valeurs par défaut.
    val profilIA: String = "guerrier",
    val faction: String = "neutre",
    val detectionDistance: Double = 24.0,
    val vitesseAttaque: Double = 1.0,
    val cooldownAttaque: Double = 0.0,
    val collisionLargeur: Double = 0.6,
    val collisionHauteur: Double = 1.8,
    val textureUri: String? = null,
    // Forme de base du corps (voir MobShapeCatalog) : "humanoid" par défaut pour rester
    // rétrocompatible avec toutes les créatures déjà créées avant cette option.
    val formeBase: String = "humanoid",
    val versionHistory: List<String> = listOf("v1 — création de la créature")
)

/**
 * Catalogue des squelettes 3D déjà intégrés à Minecraft qu'un mob peut utiliser comme base,
 * en attendant un vrai pipeline de géométrie sur-mesure (Character Studio utilise du GLB, un
 * format 3D libre, incompatible avec le format de Minecraft fait de cubes articulés).
 * Chaque forme référencée ici est un identifiant vanilla existant, gratuit en performance et
 * en poids de pack puisqu'aucun fichier de géométrie n'a besoin d'être fourni.
 */
object MobShapeCatalog {
    data class Shape(val id: String, val label: String, val geometryId: String)

    /**
     * Identifiants de géométrie vanilla Bedrock (réels, issus des samples Mojang).
     * humanoid → geometry.humanoid.custom (utilisé par le joueur)
     * les autres utilisent la forme .v1.8 quand elle existe.
     */
    val shapes: List<Shape> = listOf(
        Shape("humanoid", "Humanoïde (bipède)", "geometry.humanoid.custom"),
        Shape("zombie", "Zombie (bipède, bras tendus)", "geometry.zombie.v1.8"),
        Shape("skeleton", "Squelette (bipède fin)", "geometry.skeleton.v1.8"),
        Shape("spider", "Araignée (4 pattes)", "geometry.spider.v1.8"),
        Shape("wolf", "Loup (quadrupède, museau)", "geometry.wolf.v1.8"),
        Shape("cow", "Vache (quadrupède massif)", "geometry.cow.v1.8"),
        Shape("chicken", "Poule (petit, ailes)", "geometry.chicken.v1.8"),
        Shape("creeper", "Creeper (bipède trapu)", "geometry.creeper.v1.8"),
    )

    fun geometryFor(formeBase: String): String =
        shapes.firstOrNull { it.id == formeBase }?.geometryId ?: "geometry.humanoid.custom"
}
