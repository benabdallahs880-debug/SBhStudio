package com.sbh.studio.workshop

import android.content.Context
import android.util.Log
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

private val wsJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

class WorkshopRepository(private val context: Context) {
    private fun file(name: String) = File(context.filesDir, name)

    fun loadBlueprints(): List<WorkshopBlueprint> = read("sbh_ws_blueprints.json")
    fun saveBlueprints(v: List<WorkshopBlueprint>) = write("sbh_ws_blueprints.json", v)

    fun loadPortals(): List<PortalBlueprint> = read("sbh_ws_portals.json")
    fun savePortals(v: List<PortalBlueprint>) = write("sbh_ws_portals.json", v)

    fun loadMaps(): List<MapBlueprint> = read("sbh_ws_maps.json")
    fun saveMaps(v: List<MapBlueprint>) = write("sbh_ws_maps.json", v)

    fun loadRecipes(): List<RecipeBlueprint> = read("sbh_ws_recipes.json")
    fun saveRecipes(v: List<RecipeBlueprint>) = write("sbh_ws_recipes.json", v)

    fun loadEntities(): List<SceneEntity> = read("sbh_ws_entities.json")
    fun saveEntities(v: List<SceneEntity>) = write("sbh_ws_entities.json", v)

    private inline fun <reified T> read(name: String): List<T> = try {
        val f = file(name)
        if (!f.exists()) emptyList() else wsJson.decodeFromString(f.readText())
    } catch (e: Exception) {
        Log.e("WorkshopRepository", "Échec lecture $name", e)
        emptyList()
    }

    private inline fun <reified T> write(name: String, value: List<T>) {
        val f = file(name)
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, "${f.name}.tmp")
        tmp.writeText(wsJson.encodeToString(value))
        if (!tmp.renameTo(f)) {
            f.delete()
            tmp.renameTo(f)
        }
    }
}
