package com.sbh.studio.data

import android.content.Context
import android.util.Log
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Presets inspirés de Reclamation 2.3.2 (thème monde mort → reconquête).
 * Chargés depuis assets/reclamation/ — utilisés par ItemZone, BlockZone, Hub.
 */
object ReclamationPresets {

    private val json = Json { ignoreUnknownKeys = true }

    @Serializable
    data class ItemDef(
        val id: String = "",
        val name: String = "",
        val name_en: String = "",
        val category: String = "",
        val burnTime: Int? = null,
        val description: String = "",
        val tags: List<String> = emptyList(),
        val glow: Boolean = false,
        val progressionTier: Int = 1,
        val craftHint: String = ""
    )

    @Serializable
    private data class ItemsFile(
        val source: String = "",
        val theme: String = "",
        val namespace: String = "reclamation",
        val items: List<ItemDef> = emptyList()
    )

    @Serializable
    data class BlockDef(
        val id: String = "",
        val name: String = "",
        val name_en: String = "",
        val material: String = "",
        val sound: String = "",
        val hardness: Double = 1.0,
        val resistance: Double = 1.0,
        val tool: String = "",
        val tags: List<String> = emptyList(),
        val description: String = "",
        val role: String = "",
        val axis: Boolean = false
    )

    @Serializable
    private data class BlocksFile(
        val source: String = "",
        val theme: String = "",
        val namespace: String = "reclamation",
        val blocks: List<BlockDef> = emptyList()
    )

    @Serializable
    data class PhaseDef(
        val id: String = "",
        val name: String = "",
        val order: Int = 0,
        val goal: String = "",
        val unlocks: List<String> = emptyList(),
        val milestones: List<String> = emptyList(),
        val gameplayHints: List<String> = emptyList()
    )

    @Serializable
    private data class PhasesFile(
        val source: String = "",
        val theme: String = "",
        val description: String = "",
        val phases: List<PhaseDef> = emptyList()
    )

    fun loadItems(context: Context): List<ItemDef> = try {
        context.assets.open("reclamation/reclamation_items.json")
            .bufferedReader().use { it.readText() }
            .let { json.decodeFromString<ItemsFile>(it).items }
    } catch (e: Exception) {
        Log.w("ReclamationPresets", "Échec opération", e)

        emptyList()
    }

    fun loadBlocks(context: Context): List<BlockDef> = try {
        context.assets.open("reclamation/reclamation_blocks.json")
            .bufferedReader().use { it.readText() }
            .let { json.decodeFromString<BlocksFile>(it).blocks }
    } catch (e: Exception) {
        Log.w("ReclamationPresets", "Échec opération", e)

        emptyList()
    }

    fun loadPhases(context: Context): List<PhaseDef> = try {
        context.assets.open("reclamation/world_phases.json")
            .bufferedReader().use { it.readText() }
            .let { json.decodeFromString<PhasesFile>(it).phases }
    } catch (e: Exception) {
        Log.w("ReclamationPresets", "Échec opération", e)

        emptyList()
    }

    /** Convertit les définitions en SbhItem pour le projet courant. */
    fun toSbhItems(context: Context, projectId: String): List<SbhItem> =
        loadItems(context).map { def ->
            SbhItem(
                projectId = projectId,
                name = def.name.ifBlank { def.name_en },
                identifier = def.id.ifBlank { "reclamation:item" },
                damage = 0,
                durability = if (def.category == "material") 64 else 100,
                textureUri = null
            )
        }

    /** Convertit les définitions en SbhBlock pour le projet courant. */
    fun toSbhBlocks(context: Context, projectId: String): List<SbhBlock> =
        loadBlocks(context).map { def ->
            SbhBlock(
                projectId = projectId,
                name = def.name.ifBlank { def.name_en },
                identifier = def.id.ifBlank { "reclamation:block" },
                hardness = def.hardness,
                textureUri = null
            )
        }

    /** Résumé textuel des phases (message / notes projet). */
    fun phasesSummary(context: Context): String {
        val phases = loadPhases(context).sortedBy { it.order }
        if (phases.isEmpty()) return "Aucune phase Reclamation chargée."
        return phases.joinToString("\n") { p ->
            "${p.order}. ${p.name} — ${p.goal}"
        }
    }
}
