# SBh Studio — Améliorations نشيد (Audio)

## Contenu de cette version

### Écran نشيد (onglet ♫)
- Lecteur audio intégré (play / pause / stop + barre de progression)
- Import de fichiers (ogg, mp3, m4a, wav…)
- Bibliothèque locale avec suppression
- Choix d’événement Minecraft (music.game, music.menu, disques, ambiance, custom)
- Toggle « Pack » pour inclusion à l’export
- Rappel coranique et accès app Coran conservés

### Zone Sons dans le Workshop (par projet)
- Nouvelle zone **Sons / نشيد** dans l’atelier
- Import lié au projet ouvert
- Gestion Pack / Événement / Suppression
- Compteurs sur le Hub et l’Export

### Export Resource Pack Minecraft
- Génération de `sounds/sound_definitions.json`
- Fichiers audio sous `sounds/sbh/`
- Remplacement possible de la musique de jeu (music.game, etc.)
- Avertissement si un son n’est pas en Ogg

### Conversion automatique → Ogg
- `AudioOggConverter` : Ogg natif, FFmpegKit, ou ffmpeg système
- Dépendance : `com.arthenica:ffmpeg-kit-audio:6.0-2`
  (à commenter dans `app/build.gradle.kts` si résolution Maven impossible)

## Fichiers principaux
- `data/SoundModels.kt`
- `data/SoundRepository.kt`
- `data/AudioOggConverter.kt`
- `ui/AudioStudioScreen.kt`
- `workshop/WorkshopModels.kt` (zone SOUNDS)
- `workshop/WorkshopScreen.kt` (SoundZone)
- `generator/AdvancedPackEngine.kt`
- `app/build.gradle.kts`

## Build
```bash
./gradlew assembleDebug
```
