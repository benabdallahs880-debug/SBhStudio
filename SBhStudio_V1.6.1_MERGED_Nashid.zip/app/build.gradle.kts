plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

val sbhVersionFile = rootProject.file("version.json")
val sbhVersionText = sbhVersionFile.readText()
val sbhVersionCode = Regex("\"versionCode\"\\s*:\s*(\\d+)").find(sbhVersionText)?.groupValues?.get(1)?.toInt()
    ?: error("version.json: versionCode manquant")
val sbhVersionName = Regex("\"versionName\"\\s*:\s*\"([^\\"]+)\"").find(sbhVersionText)?.groupValues?.get(1)
    ?: error("version.json: versionName manquant")

android {
    namespace = "com.sbh.studio"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.sbh.studio"
        minSdk = 26
        targetSdk = 35
        versionCode = sbhVersionCode
        versionName = sbhVersionName
    }

    signingConfigs {
        // La clé de signature de publication ne doit jamais être stockée dans Git.
        // Les valeurs sont fournies par l'environnement CI via des secrets GitHub.
        create("release") {
            val keystorePath = providers.environmentVariable("SBH_KEYSTORE_PATH").orNull
            val storePassword = providers.environmentVariable("SBH_KEYSTORE_PASSWORD").orNull
            val keyAlias = providers.environmentVariable("SBH_KEY_ALIAS").orNull
            val keyPassword = providers.environmentVariable("SBH_KEY_PASSWORD").orNull
            if (keystorePath != null && storePassword != null && keyAlias != null && keyPassword != null) {
                storeFile = file(keystorePath)
                this.storePassword = storePassword
                this.keyAlias = keyAlias
                this.keyPassword = keyPassword
            }
        }
    }

    buildTypes {
        getByName("debug") {
            // Debug Android utilise la clé debug locale générée par Gradle.
            // Elle n'est jamais versionnée dans le dépôt.
        }
        getByName("release") {
            val hasReleaseSigning = providers.environmentVariable("SBH_KEYSTORE_PATH").isPresent &&
                providers.environmentVariable("SBH_KEYSTORE_PASSWORD").isPresent &&
                providers.environmentVariable("SBH_KEY_ALIAS").isPresent &&
                providers.environmentVariable("SBH_KEY_PASSWORD").isPresent
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            } else if (gradle.startParameter.taskNames.any { it.contains("Release", ignoreCase = true) }) {
                throw GradleException("Signature release absente : configurez SBH_KEYSTORE_PATH, SBH_KEYSTORE_PASSWORD, SBH_KEY_ALIAS et SBH_KEY_PASSWORD.")
            }
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

kotlin {
    jvmToolchain(17)
}


dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.01.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    // ffmpeg-kit retiré : le paquet n'est plus publié sur Maven Central (projet discontinué).
    // AudioOggConverter fonctionne sans dépendance (conserve le fichier, ou ffmpeg système si présent).
    debugImplementation("androidx.compose.ui:ui-tooling")
}
