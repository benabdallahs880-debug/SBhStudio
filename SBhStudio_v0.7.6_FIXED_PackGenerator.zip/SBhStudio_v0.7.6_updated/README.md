# SBh Studio

SBh Studio 0.7.6 — Android studio for SBh / Minecraft Bedrock projects.

## Nouveautés 0.7.6 — Atelier : tout reconnecté

- Blocs et Items ont enfin un vrai formulaire de création dans l'Atelier (nom, identifiant, stats, texture), exactement comme Créatures — avant, c'était une liste en lecture seule qui renvoyait vers un autre écran
- Créatures a maintenant un sélecteur de texture, comme Items et Blocs — les trois formulaires sont désormais cohérents entre eux
- Bug corrigé : l'export depuis l'Atelier n'ouvrait jamais Minecraft (deux chemins d'export différents existaient dans l'app ; seul celui du détail de projet avait reçu le correctif ACTION_VIEW, celui de l'Atelier utilisait encore l'ancien partage générique ACTION_SEND) — les deux sont maintenant alignés
- Nettoyage : le composant `ContentListZone`, devenu inutilisé après ce changement, a été retiré

## Build

Debug local : `./gradlew assembleDebug`

Release CI requires these GitHub Actions secrets:
- `SBH_KEYSTORE_B64`
- `SBH_KEYSTORE_PASSWORD`
- `SBH_KEY_ALIAS`
- `SBH_KEY_PASSWORD`

The release keystore is never stored in the repository. The update manager verifies that a downloaded APK has the same application ID and signing certificate as the installed application before offering installation.

## Version

The source of truth is `version.json`.
