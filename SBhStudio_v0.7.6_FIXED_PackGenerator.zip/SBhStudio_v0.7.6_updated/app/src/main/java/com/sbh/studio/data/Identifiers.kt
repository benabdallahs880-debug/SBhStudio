package com.sbh.studio.data

/**
 * Utilitaires d'identifiants Bedrock `namespace:name`.
 * Même convention que la fondation et PackGenerator (textureKey = namespace_name).
 */
object Identifiers {

    private val ID_REGEX = Regex("^[a-z0-9_]+:[a-z0-9_./-]+$")

    fun isValid(id: String): Boolean = ID_REGEX.matches(id)

    /** Message d'erreur lisible, ou null si valide. */
    fun explain(id: String): String? {
        if (id.isBlank()) return "identifiant vide"
        if (!id.contains(':')) return "manque le namespace (ex. agw:mon_item)"
        val parts = id.split(':', limit = 2)
        if (parts.size != 2) return "format invalide"
        val (ns, name) = parts
        if (ns.isBlank()) return "namespace vide"
        if (name.isBlank()) return "nom technique vide"
        if (!ns.matches(Regex("^[a-z0-9_]+$"))) return "namespace invalide (a-z, 0-9, _ uniquement)"
        if (!name.matches(Regex("^[a-z0-9_./-]+$"))) return "nom technique invalide (a-z, 0-9, _, ., /, -)"
        if (name.startsWith('.') || name.startsWith('/') || name.endsWith('.') || name.endsWith('/')) {
            return "nom technique ne doit pas commencer/finir par . ou /"
        }
        return null
    }

    fun namespaceOf(id: String): String {
        val i = id.indexOf(':')
        return if (i > 0) id.substring(0, i) else "agw"
    }

    fun nameOf(id: String): String {
        val i = id.indexOf(':')
        return if (i >= 0 && i < id.length - 1) id.substring(i + 1) else id
    }
}
