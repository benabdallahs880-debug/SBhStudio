package com.sbh.studio.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Système de mise à jour SBh Studio.
 *
 * Source de vérité : version.json (release body GitHub + assets/version.json local).
 * Le CI publie version.json comme body de la release → versionCode comparable
 * directement à BuildConfig.VERSION_CODE (plus de parse fragile du tag 0.6.x).
 */
private const val LATEST_RELEASE_URL =
    "https://api.github.com/repos/benabdallahs880-debug/SBhStudio/releases/latest"

private val json = Json { ignoreUnknownKeys = true; isLenient = true }

sealed class UpdateCheckResult {
    data class UpdateAvailable(val info: UpdateInfo) : UpdateCheckResult()
    data object UpToDate : UpdateCheckResult()
    data class Error(val message: String) : UpdateCheckResult()
}

sealed class DownloadState {
    data object Idle : DownloadState()
    data object Downloading : DownloadState()
    data class ReadyToInstall(val apkFile: File) : DownloadState()
    data class Failed(val message: String) : DownloadState()
}

/** Résultat d'inspection d'un APK local (Phase 2). */
data class LocalApkInspection(
    val file: File,
    val packageName: String,
    val versionName: String?,
    val versionCode: Long,
    val signatureMatches: Boolean,
    val isNewer: Boolean,
    val canInstall: Boolean,
    val reason: String
)

class UpdateManager(private val context: Context) {

    /** Version embarquée dans l'APK (assets/version.json), fallback BuildConfig via caller. */
    fun localVersionFromAssets(): UpdateInfo? = try {
        val text = context.assets.open("version.json").bufferedReader().use { it.readText() }
        parseVersionJson(text)
    } catch (_: Exception) {
        null
    }

    fun parseVersionJson(text: String): UpdateInfo? = try {
        val root = json.parseToJsonElement(text).jsonObject
        val code = root["versionCode"]?.jsonPrimitive?.intOrNull ?: return null
        val name = root["versionName"]?.jsonPrimitive?.content ?: return null
        val notes = root["notes"]?.jsonPrimitive?.content ?: ""
        val apkUrl = root["apkUrl"]?.jsonPrimitive?.content ?: ""
        val sha256 = root["sha256"]?.jsonPrimitive?.content?.lowercase()?.trim() ?: ""
        UpdateInfo(versionCode = code, versionName = name, apkUrl = apkUrl, notes = notes, sha256 = sha256)
    } catch (_: Exception) {
        null
    }

    /**
     * 1) GET releases/latest
     * 2) Lire body comme version.json (versionCode officiel)
     * 3) Trouver l'URL de l'APK dans les assets
     * 4) Comparer versionCode distant vs currentVersionCode
     */
    suspend fun checkForUpdate(currentVersionCode: Int): UpdateCheckResult = withContext(Dispatchers.IO) {
        try {
            val connection = URL(LATEST_RELEASE_URL).openConnection() as HttpURLConnection
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            connection.instanceFollowRedirects = true
            val httpCode = connection.responseCode
            if (httpCode == 404) {
                return@withContext UpdateCheckResult.Error(
                    "Aucune release publique. Publiez une release GitHub avec version.json + APK."
                )
            }
            if (httpCode != 200) {
                return@withContext UpdateCheckResult.Error("GitHub a répondu $httpCode.")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = json.parseToJsonElement(body).jsonObject

            val tag = root["tag_name"]?.jsonPrimitive?.content?.removePrefix("v") ?: "?"
            val releaseBody = root["body"]?.jsonPrimitive?.content.orEmpty()
                .replace("\\n", "\n")
                .replace("\\\"", "\"")

            // Priorité : body = contenu de version.json publié par le CI
            val fromBody = parseVersionJson(releaseBody.trim())
            val remoteCode = fromBody?.versionCode
                ?: tag.toIntOrNull()
                ?: return@withContext UpdateCheckResult.Error(
                    "Release sans versionCode. Le body doit être un version.json valide (versionCode, versionName, notes)."
                )
            val remoteName = fromBody?.versionName ?: tag
            val notes = fromBody?.notes?.ifBlank { null } ?: "SBh Studio $remoteName"

            val assets = root["assets"]?.jsonArray.orEmpty()
            fun assetUrl(predicate: (String) -> Boolean): String? =
                assets.firstOrNull {
                    predicate(it.jsonObject["name"]?.jsonPrimitive?.content.orEmpty())
                }?.jsonObject?.get("browser_download_url")?.jsonPrimitive?.content

            val apkUrl = assetUrl { it.endsWith(".apk", ignoreCase = true) }
                ?: fromBody?.apkUrl?.takeIf { it.startsWith("http") }
                ?: return@withContext UpdateCheckResult.Error(
                    "Aucun APK dans la release $remoteName. Joignez SBhStudio-$remoteName.apk."
                )

            val info = UpdateInfo(
                versionCode = remoteCode,
                versionName = remoteName,
                apkUrl = apkUrl,
                notes = notes,
                sha256 = fromBody?.sha256.orEmpty()
            )

            when {
                remoteCode > currentVersionCode -> UpdateCheckResult.UpdateAvailable(info)
                remoteCode == currentVersionCode -> UpdateCheckResult.UpToDate
                else -> UpdateCheckResult.UpToDate // local plus récent (build debug)
            }
        } catch (e: Exception) {
            UpdateCheckResult.Error(e.message ?: "Erreur réseau")
        }
    }

    fun startDownload(apkUrl: String): Long {
        val updatesDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "sbh_updates")
        if (!updatesDir.exists()) updatesDir.mkdirs()
        val destFile = File(updatesDir, "sbh-studio-update.apk")
        if (destFile.exists()) destFile.delete()

        val request = DownloadManager.Request(Uri.parse(apkUrl))
            .setTitle("SBh Studio — mise à jour")
            .setDescription("Téléchargement v. à jour")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(
                context,
                Environment.DIRECTORY_DOWNLOADS,
                "sbh_updates/sbh-studio-update.apk"
            )
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return dm.enqueue(request)
    }

    fun apkFile(): File = File(
        File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "sbh_updates"),
        "sbh-studio-update.apk"
    )

    suspend fun awaitDownload(downloadId: Long, expectedSha256: String = ""): DownloadState = withContext(Dispatchers.IO) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        repeat(90) {
            val q = DownloadManager.Query().setFilterById(downloadId)
            dm.query(q)?.use { c: Cursor ->
                if (c.moveToFirst()) {
                    when (c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                        DownloadManager.STATUS_SUCCESSFUL -> {
                            val file = apkFile()
                            if (!file.exists() || file.length() <= 1024) {
                                return@withContext DownloadState.Failed("APK vide ou introuvable après téléchargement.")
                            }
                            if (expectedSha256.isNotBlank()) {
                                val actual = file.inputStream().use { sha256(it) }
                                if (!actual.equals(expectedSha256.trim(), ignoreCase = true)) {
                                    file.delete()
                                    return@withContext DownloadState.Failed("Empreinte SHA-256 de l'APK incorrecte.")
                                }
                            }
                            return@withContext DownloadState.ReadyToInstall(file)
                        }
                        DownloadManager.STATUS_FAILED -> {
                            val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                            return@withContext DownloadState.Failed("Échec téléchargement (raison $reason)")
                        }
                    }
                }
            }
            delay(2000)
        }
        DownloadState.Failed("Délai dépassé (téléchargement trop long).")
    }

    fun installApk(apkFile: File) {
        require(isTrustedUpdate(apkFile)) { "APK de mise à jour non fiable, incompatible ou inférieur à la version installée." }
        launchInstall(apkFile)
    }

    /**
     * Phase 2 — copie un APK depuis un Uri (fichier choisi par l'utilisateur)
     * vers le stockage app, puis l'inspecte.
     */
    fun copyApkFromUri(uri: Uri): File {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "sbh_updates")
        if (!dir.exists()) dir.mkdirs()
        val dest = File(dir, "sbh-studio-local.apk")
        if (dest.exists()) dest.delete()
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("Impossible de lire le fichier APK.")
        if (!dest.exists() || dest.length() < 1024) {
            dest.delete()
            throw IllegalStateException("APK vide ou illisible.")
        }
        return dest
    }

    /** Inspecte un APK local sans l'installer. */
    fun inspectLocalApk(apkFile: File): LocalApkInspection {
        val flags = signingFlags()
        val archiveInfo = context.packageManager.getPackageArchiveInfo(apkFile.absolutePath, flags)
            ?: return LocalApkInspection(
                file = apkFile,
                packageName = "?",
                versionName = null,
                versionCode = -1,
                signatureMatches = false,
                isNewer = false,
                canInstall = false,
                reason = "APK illisible ou corrompu."
            )
        val pkg = archiveInfo.packageName ?: "?"
        val vCode = if (Build.VERSION.SDK_INT >= 28) {
            archiveInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION") archiveInfo.versionCode.toLong()
        }
        val vName = archiveInfo.versionName
        if (pkg != context.packageName) {
            return LocalApkInspection(
                file = apkFile, packageName = pkg, versionName = vName, versionCode = vCode,
                signatureMatches = false, isNewer = false, canInstall = false,
                reason = "Package différent ($pkg). Seules les mises à jour SBh Studio sont acceptées."
            )
        }
        val archiveDigests = signerDigests(archiveInfo)
        val currentPackage = context.packageManager.getPackageInfo(context.packageName, flags)
        val currentDigests = signerDigests(currentPackage)
        val sigOk = archiveDigests.isNotEmpty() && currentDigests.isNotEmpty() && archiveDigests == currentDigests
        val currentCode = if (Build.VERSION.SDK_INT >= 28) {
            currentPackage.longVersionCode
        } else {
            @Suppress("DEPRECATION") currentPackage.versionCode.toLong()
        }
        val newer = vCode > currentCode
        val reason = when {
            !sigOk -> "Signature différente de l'app installée — installation refusée."
            !newer -> "Version code $vCode ≤ version installée $currentCode — pas une mise à jour."
            else -> "APK fiable · $vName (code $vCode) · prêt à installer."
        }
        return LocalApkInspection(
            file = apkFile,
            packageName = pkg,
            versionName = vName,
            versionCode = vCode,
            signatureMatches = sigOk,
            isNewer = newer,
            canInstall = sigOk && newer,
            reason = reason
        )
    }

    /** Installe un APK local uniquement s'il passe les contrôles. */
    fun installLocalApk(apkFile: File) {
        val inspection = inspectLocalApk(apkFile)
        require(inspection.canInstall) { inspection.reason }
        launchInstall(apkFile)
    }

    private fun launchInstall(apkFile: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
            val settingsIntent = Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                .setData(Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(settingsIntent)
            return
        }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /** Vérifie le paquet et son certificat de signature avant toute installation (téléchargement). */
    private fun isTrustedUpdate(apkFile: File): Boolean = inspectLocalApk(apkFile).canInstall

    private fun signingFlags(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        PackageManager.GET_SIGNING_CERTIFICATES
    } else {
        @Suppress("DEPRECATION") PackageManager.GET_SIGNATURES
    }

    private fun signerDigests(info: android.content.pm.PackageInfo): Set<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.signingInfo?.apkContentsSigners?.map { sha256(it.toByteArray()) }?.toSet().orEmpty()
        } else {
            @Suppress("DEPRECATION") info.signatures?.map { sha256(it.toByteArray()) }?.toSet().orEmpty()
        }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }

    private fun sha256(input: java.io.InputStream): String =
        MessageDigest.getInstance("SHA-256").let { digest ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        }

}
