# SBH World — protocole + adaptateurs + placement

## Flux

```
Studio files (protocol.json, blocks/items/mobs.json, placements.json)
        ↓
StudioBridge.bootstrap()
  ProtocolAdapter + DefinitionAdapter  →  StudioCatalog
        ✕ aucun chunk

SBHWorld (terrain de jeu)
        ↓
StudioBridge.place_into_world(world)
  PlacementAdapter  ← SEUL autorisé à appeler set_block / marqueurs
```

## PlacementAdapter

- Lit `placements.json` (user ou exemple)
- Blocs : mapping identifier Studio → `BlockTypes` local (placeholder)
- Mobs : sphères marqueurs sous `World/StudioPlacements` (pas encore d’IA)
- Ne fait **pas** partie de `bootstrap()`

## Fichiers clés

| Fichier | Rôle |
|---------|------|
| `adapters/placement_adapter.gd` | Écriture monde |
| `adapters/studio_bridge.gd` | `bootstrap` + `place_into_world` |
| `content/studio_example/sbh/placements.json` | Plan de démo |

## Import utilisateur

`user://studio_import/sbh/` :
- `protocol.json` (requis pour lier)
- `blocks.json` / `items.json` / `mobs.json` (optionnel)
- `placements.json` (optionnel)

## Documents (import / lecture / modification / adaptation)

Bouton **DOCS** (en haut à gauche) → panneau :

| Bouton | Effet |
|--------|-------|
| Importer… | Sélecteur de fichiers du système (Android : Godot 4.6+, sans permission). Accepte `.json`, `.zip`, `.mcaddon`, `.mcpack`, `.txt`. Chaque document est copié tel quel dans `user://studio_import/originals/` puis, s'il est reconnu, adapté et écrit dans `user://studio_import/sbh/` |
| Liste | `jeu` = ce que le jeu lit, `exemple` = contenu embarqué (l'enregistrer crée une copie perso), `source` = copie brute importée |
| Zone de texte | Lecture et modification du document ouvert |
| Type + Adapter | Convertit le texte affiché au format SBH et l'écrit côté jeu (type imposé si la détection automatique échoue) |
| Enregistrer | Écrit le texte ; les fichiers lus par le jeu doivent être du JSON strict |
| Appliquer au monde | Relance `StudioBridge.bootstrap()` puis `place_into_world()` (le `PlacementAdapter` reste le seul à toucher aux blocs) |

Adaptation (`scripts/documents/document_adapter.gd`) :
- détection par contenu (protocole SBH, Bedrock, placements), puis par nom, puis par forme des entrées ;
- Bedrock `minecraft:entity` / `minecraft:block` / `minecraft:item` → entrée `mobs` / `blocks` / `items` (santé, dégâts, dureté… lus dans `components`) ;
- commentaires `//` et `/* */` tolérés à l'import ;
- protocole : ajoute `sbh_world` à `compatibleTargets` si absent ;
- blocs / objets / mobs : fusion par `identifier` avec ce qui existe déjà ; protocole et placements : remplacés.

Un mob ou un bloc importé rejoint le catalogue ; il n'apparaît dans le monde que s'il figure dans `placements.json`.
Fichier d'essai : `content/samples/exemple_entite_bedrock.json`.


## AGW World Core — intégration V1.4

SBH World peut maintenant consommer le même contrat `sbh.agw.worldcore.v1` que SBh Studio V1.3.

Flux :

```
SBh Studio / Map Atelier
        ↓ export World Core JSON
content/agw_world_core/agw_world_core.json
        ↓
AGWWorldCore
        ↓
AGWWorldAdapter
        ↓
SBHWorld
```

Le runtime cherche d'abord un override utilisateur :
`user://agw_world_core/agw_world_core.json`

puis utilise le fichier embarqué :
`res://content/agw_world_core/agw_world_core.json`

L'adaptateur projette les nœuds `map`, `portal`, `building`, `location` et `npc` en marqueurs 3D. Les factions et régions restent dans le modèle AGW sans être converties en blocs. Le `PlacementAdapter` reste l'unique chemin d'écriture des voxels.

Cela prépare la prochaine étape : import/export direct du World Core depuis SBh Studio vers le runtime Godot, sans dupliquer le modèle du monde.
