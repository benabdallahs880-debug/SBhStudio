# SBh Studio

SBh Studio **1.0.0** — Android studio for SBh / Minecraft Bedrock projects.

## V1.0 — Communication Core

- **SBh Communication Core** : identifiants d'export (`SBH-YYYY-NNNNNN`), journal persistant, statuts de cycle de vie
- **SBh Validation Engine** : validations structurées → `ReportEntry` / codes `SBH-ERR-XXX`
- **Rapports** : historique, détail, copier, télécharger TXT/JSON/HTML, partager (Sharesheet)
- **Protocole SBH** : `sbh/protocol.json` embarqué dans BP et RP (ignoré par Minecraft)
- **Transmission** : `Intent ACTION_VIEW` + MIME `application/mcaddon` ; statut final **IMPORT_UNKNOWN** (import Minecraft non observable)
- Modules existants conservés : Factions, Mobs, Map Studio, Atelier (Workshop), génération de packs

## Build

Debug local : `./gradlew assembleDebug`

Release CI requires these GitHub Actions secrets:
- `SBH_KEYSTORE_B64`
- `SBH_KEYSTORE_PASSWORD`
- `SBH_KEY_ALIAS`
- `SBH_KEY_PASSWORD`

The release keystore is never stored in the repository. The update manager verifies that a downloaded APK has the same application ID and signing certificate as the installed application before offering installation.

## Version

The source of truth is `version.json` (synced into `app/build.gradle.kts` by CI).


## Map Studio v1.1 — mini-jeu + livre de rapport
- Entrée dans Map Studio avec écran de chargement par étapes.
- Signal de disponibilité réel via `SBhBridge.ready()` après initialisation de l'éditeur 3D.
- Ajout du bouton **📖 Rapport** dans Map Studio.
- Le livre recense automatiquement dimensions, blocs utilisés, bâtiments/structures générés par Map Code et PNG/textures externes connus.
