# SBh Studio — Atelier de Monde + lien Map Studio

## Nouveautés

### Atelier de Monde (`settlement/`)
- Création de villages, villes, châteaux, citadelles, ports, camps, ruines
- 9 templates (village arabe, médina, château, citadelle Hibou, Ghurab, port, camp bédouin, etc.)
- Éditeur tactile : infos, plan grille, défenses / remparts
- i18n FR / EN / AR
- Sync World Core (`source = settlement`)

### Lien Map Studio
- `linkedMapId`, `mapLocalX`, `mapLocalZ` sur chaque peuplement
- Liaison depuis l’onglet Infos → maps de l’Atelier
- Injection `__SBH_SETTLEMENTS__` dans Map Studio (marqueurs 3D colorés)
- Fichier `map_studio_settlements.json` généré à l’ouverture de Map Studio
- Map Code : `village X Z` / `fortress X Z` (`insertSettlementMapCode()`)

### Fichiers touchés
- `app/.../settlement/*` (nouveau)
- `data/AgwWorldCore.kt`
- `mapeditor/MapEditorScreen.kt`
- `assets/mapstudio.html`
- `MainActivity.kt`, `ui/Strings.kt`

## Build
```bash
cd studio
./gradlew assembleDebug
```
