package com.sbh.studio.ui

/**
 * Trilangue FR / EN / AR pour SBh Studio.
 * Noms arabes intégrés (عالم الزهراء، إلخ).
 */
enum class AppLang { FR, EN, AR }

object S {
    fun t(lang: AppLang, key: String): String = table[key]?.get(lang) ?: key

    private val table: Map<String, Map<AppLang, String>> = mapOf(
        "app_name" to mapOf(
            AppLang.FR to "SBh Studio",
            AppLang.EN to "SBh Studio",
            AppLang.AR to "استوديو صباح"
        ),
        "app_subtitle" to mapOf(
            AppLang.FR to "Atelier arabo-gothique · Al-Zahra",
            AppLang.EN to "Arabian Gothic Workshop · Al-Zahra",
            AppLang.AR to "ورشة عربية قوطية · الزهراء"
        ),
        "world_name" to mapOf(
            AppLang.FR to "Al-Zahra",
            AppLang.EN to "Al-Zahra",
            AppLang.AR to "الزهراء"
        ),
        "owl_motto" to mapOf(
            AppLang.FR to "La Chouette veille sur les dunes d'Al-Zahra",
            AppLang.EN to "The Owl watches over the dunes of Al-Zahra",
            AppLang.AR to "البومة تسهر على كثبان الزهراء"
        ),
        "home" to mapOf(AppLang.FR to "Accueil", AppLang.EN to "Home", AppLang.AR to "الرئيسية"),
        "projects" to mapOf(AppLang.FR to "Projets", AppLang.EN to "Projects", AppLang.AR to "المشاريع"),
        "new_project" to mapOf(AppLang.FR to "Nouveau projet", AppLang.EN to "New project", AppLang.AR to "مشروع جديد"),
        "world_agw" to mapOf(AppLang.FR to "Monde AGW", AppLang.EN to "AGW World", AppLang.AR to "عالم الزهراء"),
        "lore" to mapOf(AppLang.FR to "Lore & Histoire", AppLang.EN to "Lore & Story", AppLang.AR to "القصة والتاريخ"),
        "heroes" to mapOf(AppLang.FR to "Héros & PNJ", AppLang.EN to "Heroes & NPCs", AppLang.AR to "الأبطال والشخصيات"),
        "bestiary" to mapOf(AppLang.FR to "Bestiaire", AppLang.EN to "Bestiary", AppLang.AR to "الوحوش"),
        "factions" to mapOf(AppLang.FR to "Factions", AppLang.EN to "Factions", AppLang.AR to "الفصائل"),
        "phases" to mapOf(AppLang.FR to "Phases", AppLang.EN to "Phases", AppLang.AR to "المراحل"),
        "mine_edit" to mapOf(AppLang.FR to "Mine Edit", AppLang.EN to "Mine Edit", AppLang.AR to "تحرير المنجم"),
        "updates" to mapOf(AppLang.FR to "Mises à jour", AppLang.EN to "Updates", AppLang.AR to "التحديثات"),
        "workshop" to mapOf(AppLang.FR to "Atelier", AppLang.EN to "Workshop", AppLang.AR to "الورشة"),
        "settings" to mapOf(AppLang.FR to "Paramètres", AppLang.EN to "Settings", AppLang.AR to "الإعدادات"),
        "language" to mapOf(AppLang.FR to "Langue", AppLang.EN to "Language", AppLang.AR to "اللغة"),
        "export" to mapOf(AppLang.FR to "Exporter .mcaddon", AppLang.EN to "Export .mcaddon", AppLang.AR to "تصدير الحزمة"),
        "mobs" to mapOf(AppLang.FR to "Créatures", AppLang.EN to "Mobs", AppLang.AR to "المخلوقات"),
        "items" to mapOf(AppLang.FR to "Objets", AppLang.EN to "Items", AppLang.AR to "العناصر"),
        "blocks" to mapOf(AppLang.FR to "Blocs", AppLang.EN to "Blocks", AppLang.AR to "الكتل"),
        "back" to mapOf(AppLang.FR to "Retour", AppLang.EN to "Back", AppLang.AR to "رجوع"),
        "save" to mapOf(AppLang.FR to "Enregistrer", AppLang.EN to "Save", AppLang.AR to "حفظ"),
        "open" to mapOf(AppLang.FR to "Ouvrir", AppLang.EN to "Open", AppLang.AR to "فتح"),
        "ready" to mapOf(
            AppLang.FR to "Le studio est prêt. La Chouette veille.",
            AppLang.EN to "The studio is ready. The Owl watches.",
            AppLang.AR to "الاستوديو جاهز. البومة تسهر."
        ),
        "tagline" to mapOf(
            AppLang.FR to "Là où la pierre sombre rencontre les coupoles dorées.",
            AppLang.EN to "Where dark stone meets golden domes.",
            AppLang.AR to "حيث تلتقي الحجارة الداكنة بالقباب الذهبية."
        ),
        "quick_actions" to mapOf(AppLang.FR to "Explorer le monde", AppLang.EN to "Explore the world", AppLang.AR to "استكشف العالم"),
        "explore_world" to mapOf(AppLang.FR to "Explorer le monde", AppLang.EN to "Explore the world", AppLang.AR to "استكشف العالم"),
        "create_pack" to mapOf(AppLang.FR to "Créer un pack", AppLang.EN to "Create a pack", AppLang.AR to "إنشاء حزمة"),
        "night_court" to mapOf(
            AppLang.FR to "Cour de Nuit",
            AppLang.EN to "Night Court",
            AppLang.AR to "ديوان الليل"
        ),
        "watchers" to mapOf(
            AppLang.FR to "Les Veilleurs d'Al-Zahra",
            AppLang.EN to "Watchers of Al-Zahra",
            AppLang.AR to "حرّاس الزهراء"
        ),
        "scimitar" to mapOf(AppLang.FR to "Cimeterre", AppLang.EN to "Scimitar", AppLang.AR to "سيف منحني"),
        "lantern" to mapOf(AppLang.FR to "Lanterne", AppLang.EN to "Lantern", AppLang.AR to "فانوس"),
        "sultan_djinn" to mapOf(AppLang.FR to "Sultan-Djinn", AppLang.EN to "Djinn Sultan", AppLang.AR to "سلطان الجن"),
        "dune_scorpion" to mapOf(AppLang.FR to "Scorpion des Dunes", AppLang.EN to "Dune Scorpion", AppLang.AR to "عقرب الكثبان"),
        "ruin_specter" to mapOf(AppLang.FR to "Spectre des Ruines", AppLang.EN to "Ruin Specter", AppLang.AR to "شبح الآثار"),
        "night_djinn" to mapOf(AppLang.FR to "Djinn Nocturne", AppLang.EN to "Night Djinn", AppLang.AR to "جني الليل"),
        "yusuf" to mapOf(AppLang.FR to "Yusuf", AppLang.EN to "Yusuf", AppLang.AR to "يوسف"),
        "nadia" to mapOf(AppLang.FR to "Nadia", AppLang.EN to "Nadia", AppLang.AR to "نادية"),
        "rashid" to mapOf(AppLang.FR to "Rashid", AppLang.EN to "Rashid", AppLang.AR to "رشيد"),
        "phase_done" to mapOf(AppLang.FR to "Terminé", AppLang.EN to "Done", AppLang.AR to "مكتمل"),
        "phase_planned" to mapOf(AppLang.FR to "Prévu", AppLang.EN to "Planned", AppLang.AR to "مخطط"),
        "no_projects" to mapOf(
            AppLang.FR to "Aucun projet — créez le premier.",
            AppLang.EN to "No projects — create the first one.",
            AppLang.AR to "لا مشاريع — أنشئ الأول."
        ),
        // ── Atelier de Monde (settlements) ──────────────────────────────────
        "settlement_studio" to mapOf(
            AppLang.FR to "Atelier de Monde",
            AppLang.EN to "World Workshop",
            AppLang.AR to "ورشة العالم"
        ),
        "settlement_subtitle" to mapOf(
            AppLang.FR to "Villages · Villes · Châteaux · Factions",
            AppLang.EN to "Villages · Towns · Castles · Factions",
            AppLang.AR to "قرى · مدن · قلاع · فصائل"
        ),
        "settlement_new_from_template" to mapOf(
            AppLang.FR to "Nouveau (modèle)",
            AppLang.EN to "New (template)",
            AppLang.AR to "جديد (نموذج)"
        ),
        "settlement_sync_world" to mapOf(
            AppLang.FR to "Sync World Core",
            AppLang.EN to "Sync World Core",
            AppLang.AR to "مزامنة العالم"
        ),
        "settlement_empty" to mapOf(
            AppLang.FR to "Aucun peuplement. Créez un village, une médina ou un château depuis un modèle.",
            AppLang.EN to "No settlements yet. Create a village, medina or castle from a template.",
            AppLang.AR to "لا مستوطنات بعد. أنشئ قرية أو مدينة أو قلعة من نموذج."
        ),
        "settlement_choose_template" to mapOf(
            AppLang.FR to "Choisir un modèle",
            AppLang.EN to "Choose a template",
            AppLang.AR to "اختر نموذجاً"
        ),
        "settlement_template_hint" to mapOf(
            AppLang.FR to "Templates inspirés de l'échelle Steel & Flesh, adaptés à Al-Zahra.",
            AppLang.EN to "Templates inspired by Steel & Flesh scale, adapted to Al-Zahra.",
            AppLang.AR to "نماذج مستوحاة من مقياس Steel & Flesh ومتكيفة مع الزهراء."
        ),
        "settlement_created" to mapOf(
            AppLang.FR to "Peuplement créé.",
            AppLang.EN to "Settlement created.",
            AppLang.AR to "تم إنشاء المستوطنة."
        ),
        "settlement_deleted" to mapOf(
            AppLang.FR to "Peuplement supprimé.",
            AppLang.EN to "Settlement deleted.",
            AppLang.AR to "تم حذف المستوطنة."
        ),
        "settlement_synced" to mapOf(
            AppLang.FR to "Synchronisé avec World Core.",
            AppLang.EN to "Synced to World Core.",
            AppLang.AR to "تمت المزامنة مع نواة العالم."
        ),
        "settlement_copied" to mapOf(
            AppLang.FR to "Résumé copié.",
            AppLang.EN to "Summary copied.",
            AppLang.AR to "تم نسخ الملخص."
        ),
        "settlement_tab_info" to mapOf(
            AppLang.FR to "Infos",
            AppLang.EN to "Info",
            AppLang.AR to "معلومات"
        ),
        "settlement_tab_grid" to mapOf(
            AppLang.FR to "Plan",
            AppLang.EN to "Plan",
            AppLang.AR to "مخطط"
        ),
        "settlement_tab_defense" to mapOf(
            AppLang.FR to "Défense",
            AppLang.EN to "Defense",
            AppLang.AR to "دفاع"
        ),
        "settlement_faction" to mapOf(
            AppLang.FR to "Faction (id)",
            AppLang.EN to "Faction (id)",
            AppLang.AR to "الفصيل"
        ),
        "settlement_region" to mapOf(
            AppLang.FR to "Région (id)",
            AppLang.EN to "Region (id)",
            AppLang.AR to "المنطقة"
        ),
        "settlement_type" to mapOf(
            AppLang.FR to "Type",
            AppLang.EN to "Type",
            AppLang.AR to "النوع"
        ),
        "settlement_style" to mapOf(
            AppLang.FR to "Style architectural",
            AppLang.EN to "Architectural style",
            AppLang.AR to "الطراز المعماري"
        ),
        "settlement_size" to mapOf(
            AppLang.FR to "Taille",
            AppLang.EN to "Size",
            AppLang.AR to "الحجم"
        ),
        "settlement_economy" to mapOf(
            AppLang.FR to "Économie",
            AppLang.EN to "Economy",
            AppLang.AR to "الاقتصاد"
        ),
        "settlement_place_hint" to mapOf(
            AppLang.FR to "Touchez une case pour placer / retirer. Choisissez le type ci-dessus.",
            AppLang.EN to "Tap a cell to place / remove. Choose type above.",
            AppLang.AR to "المس خلية للوضع أو الإزالة. اختر النوع أعلاه."
        ),
        "settlement_walls" to mapOf(
            AppLang.FR to "Remparts",
            AppLang.EN to "Walls",
            AppLang.AR to "الأسوار"
        ),
        "settlement_add_defense" to mapOf(
            AppLang.FR to "Ajouter une défense",
            AppLang.EN to "Add defense",
            AppLang.AR to "إضافة دفاع"
        ),
        "settlement_place_defense_center" to mapOf(
            AppLang.FR to "Placer au centre (avant-mur)",
            AppLang.EN to "Place at front center",
            AppLang.AR to "وضع في الوسط الأمامي"
        ),
        "settlement_no_defenses" to mapOf(
            AppLang.FR to "Aucune défense placée.",
            AppLang.EN to "No defenses placed.",
            AppLang.AR to "لا دفاعات موضوعة."
        ),
        "settlement_copy" to mapOf(
            AppLang.FR to "Copier résumé",
            AppLang.EN to "Copy summary",
            AppLang.AR to "نسخ الملخص"
        ),
        "cancel" to mapOf(
            AppLang.FR to "Annuler",
            AppLang.EN to "Cancel",
            AppLang.AR to "إلغاء"
        ),
        "notes" to mapOf(
            AppLang.FR to "Notes",
            AppLang.EN to "Notes",
            AppLang.AR to "ملاحظات"
        ),
        "settlement_linked_map" to mapOf(
            AppLang.FR to "Map liée (Map Studio)",
            AppLang.EN to "Linked map (Map Studio)",
            AppLang.AR to "خريطة مرتبطة"
        ),
        "settlement_unlink_map" to mapOf(
            AppLang.FR to "Délier la map",
            AppLang.EN to "Unlink map",
            AppLang.AR to "فك ارتباط الخريطة"
        ),
        "settlement_no_maps" to mapOf(
            AppLang.FR to "Aucune map dans l'Atelier — créez-en une d'abord.",
            AppLang.EN to "No maps in Workshop — create one first.",
            AppLang.AR to "لا خرائط في الورشة — أنشئ واحدة أولاً."
        ),
        "settlement_link_hint" to mapOf(
            AppLang.FR to "Touchez une map pour y placer ce peuplement (centre par défaut).",
            AppLang.EN to "Tap a map to place this settlement (default: center).",
            AppLang.AR to "المس خريطة لوضع هذه المستوطنة (الوسط افتراضياً)."
        )
    )
}
