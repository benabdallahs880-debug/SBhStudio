package com.sbh.studio.settlement

import android.content.Context
import com.sbh.studio.data.AgwWorldCoreRepository
import com.sbh.studio.data.AgwWorldNode
import com.sbh.studio.data.AgwWorldCoreState
import com.sbh.studio.data.atomicWrite
import com.sbh.studio.workshop.MapBlueprint
import com.sbh.studio.workshop.WorkshopRepository
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Persistance des peuplements + lien Map Studio + synchronisation World Core.
 */
class SettlementRepository(private val context: Context) {

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val storageFile get() = File(context.filesDir, "sbh_settlements.json")
    private val mapStudioSettlementsFile get() = File(context.filesDir, "map_studio_settlements.json")

    fun loadAll(): List<SettlementBlueprint> = try {
        if (!storageFile.exists()) emptyList()
        else json.decodeFromString(storageFile.readText())
    } catch (_: Exception) {
        emptyList()
    }

    fun saveAll(list: List<SettlementBlueprint>) {
        atomicWrite(storageFile, json.encodeToString(list))
    }

    fun upsert(s: SettlementBlueprint): List<SettlementBlueprint> {
        val now = System.currentTimeMillis()
        val updated = s.copy(updatedAt = now)
        val current = loadAll().toMutableList()
        val idx = current.indexOfFirst { it.id == updated.id }
        if (idx >= 0) current[idx] = updated else current.add(updated)
        saveAll(current)
        return current
    }

    fun delete(id: String): List<SettlementBlueprint> {
        val next = loadAll().filter { it.id != id }
        saveAll(next)
        return next
    }

    fun byProject(projectId: String): List<SettlementBlueprint> =
        loadAll().filter { it.projectId == projectId || projectId.isBlank() }

    fun byLinkedMap(mapId: String): List<SettlementBlueprint> =
        loadAll().filter { it.linkedMapId == mapId }

    /**
     * Crée un peuplement depuis un template et le sauvegarde.
     */
    fun createFromTemplate(
        templateId: String,
        projectId: String = "",
        factionId: String? = null
    ): SettlementBlueprint {
        val bp = SettlementTemplates.instantiate(templateId, projectId, factionId)
        upsert(bp)
        return bp
    }

    /**
     * Lie un peuplement à une map : copie worldX/Z depuis la map + offset local,
     * et positionne le marqueur au centre de la map par défaut.
     */
    fun linkToMap(
        settlement: SettlementBlueprint,
        map: MapBlueprint,
        localX: Int? = null,
        localZ: Int? = null
    ): SettlementBlueprint {
        val mx = localX ?: (map.sizeX / 2)
        val mz = localZ ?: (map.sizeZ / 2)
        val linked = settlement.copy(
            linkedMapId = map.id,
            projectId = settlement.projectId.ifBlank { map.projectId },
            mapLocalX = mx.coerceIn(0, (map.sizeX - 1).coerceAtLeast(0)),
            mapLocalZ = mz.coerceIn(0, (map.sizeZ - 1).coerceAtLeast(0)),
            worldX = map.worldX + mx,
            worldY = map.height.coerceIn(1, 320),
            worldZ = map.worldZ + mz,
            dimension = map.dimension
        )
        upsert(linked)
        writeMapStudioPayload()
        return linked
    }

    fun unlinkFromMap(settlement: SettlementBlueprint): SettlementBlueprint {
        val unlinked = settlement.copy(linkedMapId = null)
        upsert(unlinked)
        writeMapStudioPayload()
        return unlinked
    }

    /**
     * Alignement coords monde depuis la map liée (après déplacement du marqueur local).
     */
    fun applyLocalPosition(
        settlement: SettlementBlueprint,
        map: MapBlueprint?,
        localX: Int,
        localZ: Int
    ): SettlementBlueprint {
        val next = if (map != null) {
            settlement.copy(
                mapLocalX = localX.coerceIn(0, (map.sizeX - 1).coerceAtLeast(0)),
                mapLocalZ = localZ.coerceIn(0, (map.sizeZ - 1).coerceAtLeast(0)),
                worldX = map.worldX + localX,
                worldZ = map.worldZ + localZ,
                worldY = map.height.coerceIn(1, 320),
                dimension = map.dimension
            )
        } else {
            settlement.copy(mapLocalX = localX, mapLocalZ = localZ)
        }
        upsert(next)
        writeMapStudioPayload()
        return next
    }

    /**
     * Génère une ligne Map Code Studio (village / fortress) pour ce peuplement.
     */
    fun toMapCodeLine(s: SettlementBlueprint): String {
        val x = if (s.linkedMapId != null) s.mapLocalX else s.worldX
        val z = if (s.linkedMapId != null) s.mapLocalZ else s.worldZ
        return when (s.typeEnum()) {
            SettlementType.CASTLE, SettlementType.CITADEL -> "fortress $x $z"
            SettlementType.CAMP, SettlementType.RUIN -> "village $x $z"
            else -> "village $x $z"
        }
    }

    /**
     * Payload injecté dans Map Studio (marqueurs 3D).
     */
    @Serializable
    data class MapStudioSettlementMarker(
        val id: String,
        val name: String,
        val type: String,
        val style: String,
        val faction: String = "",
        val x: Int,
        val y: Int = 64,
        val z: Int,
        val mapLocalX: Int = 0,
        val mapLocalZ: Int = 0,
        val linkedMapId: String? = null,
        val siegeDifficulty: Int = 3,
        val populationHint: Int = 0,
        val color: String = "#C9A227"
    )

    @Serializable
    data class MapStudioSettlementsPayload(
        val schema: String = "sbh.settlements.mapstudio.v1",
        val settlements: List<MapStudioSettlementMarker> = emptyList()
    )

    private fun markerColor(s: SettlementBlueprint): String = when (s.typeEnum()) {
        SettlementType.VILLAGE -> "#C9A227"
        SettlementType.TOWN, SettlementType.CITY -> "#8C6A3F"
        SettlementType.CASTLE, SettlementType.CITADEL -> "#6B1E1E"
        SettlementType.PORT -> "#1F3A5F"
        SettlementType.CAMP -> "#E8D5A3"
        SettlementType.RUIN -> "#5A5A5A"
    }

    fun toMapStudioMarker(s: SettlementBlueprint): MapStudioSettlementMarker {
        // Si lié à une map : coordonnées locales pour positionnement dans la scène Map Studio
        val useLocal = s.linkedMapId != null
        return MapStudioSettlementMarker(
            id = s.id,
            name = s.nameFr,
            type = s.type,
            style = s.style,
            faction = s.factionId,
            x = if (useLocal) s.mapLocalX else s.worldX,
            y = s.worldY,
            z = if (useLocal) s.mapLocalZ else s.worldZ,
            mapLocalX = s.mapLocalX,
            mapLocalZ = s.mapLocalZ,
            linkedMapId = s.linkedMapId,
            siegeDifficulty = s.siegeDifficulty,
            populationHint = s.populationHint,
            color = markerColor(s)
        )
    }

    /** Écrit le fichier lu par MapEditorScreen à l'ouverture. */
    fun writeMapStudioPayload(filterMapId: String? = null) {
        val list = loadAll()
            .filter { filterMapId == null || it.linkedMapId == filterMapId || it.linkedMapId == null }
            .map { toMapStudioMarker(it) }
        val payload = MapStudioSettlementsPayload(settlements = list)
        atomicWrite(mapStudioSettlementsFile, json.encodeToString(payload))
    }

    /**
     * Projette les peuplements en nœuds World Core (type building / location).
     * N'écrase pas les nœuds d'autres sources.
     */
    fun syncToWorldCore(worldRepo: AgwWorldCoreRepository = AgwWorldCoreRepository(context)) {
        val settlements = loadAll()
        val previous = worldRepo.load()
        val kept = previous.nodes.filter { it.source != "settlement" }
        val nodes = settlements.map { s ->
            AgwWorldNode(
                id = "settlement:${s.id}",
                type = when (s.typeEnum()) {
                    SettlementType.CASTLE, SettlementType.CITADEL -> "building"
                    SettlementType.PORT -> "location"
                    SettlementType.VILLAGE, SettlementType.TOWN, SettlementType.CITY -> "building"
                    else -> "location"
                },
                name = s.nameFr,
                region = s.regionId.ifBlank { s.linkedMapId ?: "" },
                faction = s.factionId,
                x = s.worldX,
                y = s.worldY,
                z = s.worldZ,
                source = "settlement"
            )
        }
        worldRepo.save(
            AgwWorldCoreState(
                schema = previous.schema,
                worldId = previous.worldId,
                worldName = previous.worldName,
                nodes = kept + nodes
            )
        )
        writeMapStudioPayload()
    }

    /**
     * Sync complète : maps atelier + portails + peuplements + factions AGW.
     */
    fun fullWorldSync(
        projectId: String,
        agw: com.sbh.studio.data.AgwDataRepository,
        workshop: WorkshopRepository = WorkshopRepository(context),
        worldRepo: AgwWorldCoreRepository = AgwWorldCoreRepository(context)
    ): AgwWorldCoreState {
        val merged = worldRepo.synchronize(
            agw = agw,
            maps = workshop.loadMaps(),
            portals = workshop.loadPortals(),
            projectId = projectId,
            settlements = loadAll()
        )
        worldRepo.save(merged)
        writeMapStudioPayload()
        return merged
    }

    /** Export JSON d'un peuplement (pour partage / rapport). */
    fun exportJson(s: SettlementBlueprint): String = json.encodeToString(s)

    /** Résumé texte pour rapport / partage mobile. */
    fun exportSummary(s: SettlementBlueprint): String = buildString {
        appendLine("══ ${s.nameFr} ══")
        appendLine("Type : ${s.type} · Style : ${s.style} · Taille : ${s.size}")
        if (s.factionId.isNotBlank()) appendLine("Faction : ${s.factionId}")
        if (s.linkedMapId != null) {
            appendLine("Map liée : ${s.linkedMapId} @ local (${s.mapLocalX}, ${s.mapLocalZ})")
            appendLine("Map Code : ${toMapCodeLine(s)}")
        }
        appendLine("Monde : (${s.worldX}, ${s.worldY}, ${s.worldZ}) · ${s.dimension}")
        appendLine("Population ~ ${s.populationHint} · Siège : ${s.siegeDifficulty}/10")
        appendLine("Grille ${s.gridW}×${s.gridH} · Bâtiments : ${s.buildings.size} · Défenses : ${s.defenses.size}")
        if (s.walls.hasWalls) appendLine("Murs : ${s.walls.material} h=${s.walls.height}")
        val eco = buildList {
            if (s.economy.market) add("marché")
            if (s.economy.caravanserai) add("caravanserail")
            if (s.economy.forge) add("forge")
            if (s.economy.farm) add("ferme")
            if (s.economy.port) add("port")
            if (s.economy.mine) add("mine")
        }
        if (eco.isNotEmpty()) appendLine("Économie : ${eco.joinToString(", ")}")
        if (s.notes.isNotBlank()) appendLine("Notes : ${s.notes}")
        appendLine()
        appendLine("— Bâtiments —")
        s.buildings.forEach { b ->
            appendLine("  • ${b.kind} @ (${b.gx},${b.gz})${if (b.label.isNotBlank()) " — ${b.label}" else ""}")
        }
        if (s.defenses.isNotEmpty()) {
            appendLine("— Défenses —")
            s.defenses.forEach { d ->
                appendLine("  • ${d.kind} @ (${d.gx},${d.gz})${if (d.label.isNotBlank()) " — ${d.label}" else ""}")
            }
        }
    }
}
