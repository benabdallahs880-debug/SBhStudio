package com.sbh.studio.settlement

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * Atelier de Monde — modèles de peuplements (villages, villes, châteaux)
 * inspirés de l'échelle Steel & Flesh 2, adaptés à AGW / Al-Zahra et au mobile.
 */

enum class SettlementType {
    VILLAGE,
    TOWN,
    CITY,
    CASTLE,
    CITADEL,
    PORT,
    CAMP,
    RUIN
}

enum class ArchStyle {
    ARABIAN_DESERT,   // dômes, riads, minarets, adobe
    GOTHIC_ARABIAN,   // fusion AGW (hibou / pierre de nuit)
    FORTRESS_STONE,   // donjon, courtines
    WOODEN_OUTPOST,
    PORT_MEDINA,
    BEDOUIN_CAMP
}

enum class SettlementSize {
    SMALL,    // hameau / tour isolée
    MEDIUM,   // village / petit château
    LARGE,    // ville / forteresse
    CAPITAL   // capitale / citadelle majeure
}

/** Catégorie d'un bâtiment placé dans le plan. */
enum class BuildingKind {
    HOUSE,
    MOSQUE,
    MARKET,
    WELL,
    CARAVANSERAI,
    FORGE,
    TOWER,
    GATE,
    WALL,
    KEEP,
    BARRACKS,
    STABLES,
    PORTAL_MARKER,
    FARM,
    OASIS,
    DOCK,
    WATCHPOST,
    CUSTOM
}

@Serializable
data class BuildingSlot(
    val id: String = UUID.randomUUID().toString(),
    val kind: String = BuildingKind.HOUSE.name,
    /** Position relative sur la grille logique (0..gridW-1, 0..gridH-1). */
    val gx: Int = 0,
    val gz: Int = 0,
    val label: String = "",
    val blockHint: String = "agw:night_bricks",
    val notes: String = ""
)

@Serializable
data class WallConfig(
    val hasWalls: Boolean = false,
    val material: String = "stone",
    val height: Int = 4,
    val hasGate: Boolean = true,
    val towersAtCorners: Boolean = true
)

@Serializable
data class DefenseElement(
    val id: String = UUID.randomUUID().toString(),
    val kind: String = "tower", // tower | catapult | ballista | ram | arrow_slit
    val gx: Int = 0,
    val gz: Int = 0,
    val label: String = ""
)

@Serializable
data class EconomyTags(
    val market: Boolean = false,
    val caravanserai: Boolean = false,
    val forge: Boolean = false,
    val farm: Boolean = false,
    val port: Boolean = false,
    val mine: Boolean = false
)

/**
 * Blueprint principal d'un peuplement.
 * Pensé pour édition tactile (grille) et export World Core / Minecraft.
 */
@Serializable
data class SettlementBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String = "",
    val nameFr: String = "Nouveau peuplement",
    val nameEn: String = "New settlement",
    val nameAr: String = "مستوطنة جديدة",
    val type: String = SettlementType.VILLAGE.name,
    val style: String = ArchStyle.ARABIAN_DESERT.name,
    val size: String = SettlementSize.MEDIUM.name,
    val factionId: String = "",
    val regionId: String = "",
    /** Coordonnées monde (Minecraft / Godot). */
    val worldX: Int = 0,
    val worldY: Int = 64,
    val worldZ: Int = 0,
    val dimension: String = "minecraft:overworld",
    /** Lien vers une MapBlueprint de l'atelier / Map Studio. */
    val linkedMapId: String? = null,
    /** Position locale sur la map liée (grille Map Studio, 0..sizeX / 0..sizeZ). */
    val mapLocalX: Int = 0,
    val mapLocalZ: Int = 0,
    /** Grille logique de l'éditeur (largeur × profondeur). */
    val gridW: Int = 16,
    val gridH: Int = 16,
    val walls: WallConfig = WallConfig(),
    val buildings: List<BuildingSlot> = emptyList(),
    val defenses: List<DefenseElement> = emptyList(),
    val economy: EconomyTags = EconomyTags(),
    val populationHint: Int = 50,
    /** Difficulté de siège 1–10 (esprit Steel & Flesh). */
    val siegeDifficulty: Int = 3,
    val notes: String = "",
    val templateId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun displayName(langCode: String): String = when (langCode) {
        "ar" -> nameAr.ifBlank { nameFr }
        "en" -> nameEn.ifBlank { nameFr }
        else -> nameFr
    }

    fun typeEnum(): SettlementType =
        runCatching { SettlementType.valueOf(type) }.getOrDefault(SettlementType.VILLAGE)

    fun styleEnum(): ArchStyle =
        runCatching { ArchStyle.valueOf(style) }.getOrDefault(ArchStyle.ARABIAN_DESERT)

    fun sizeEnum(): SettlementSize =
        runCatching { SettlementSize.valueOf(size) }.getOrDefault(SettlementSize.MEDIUM)
}

/** Catalogue d'un template prêt à l'emploi. */
@Serializable
data class SettlementTemplateInfo(
    val id: String,
    val nameFr: String,
    val nameEn: String,
    val nameAr: String,
    val type: String,
    val style: String,
    val size: String,
    val descriptionFr: String,
    val descriptionEn: String = "",
    val descriptionAr: String = "",
    val suggestedFaction: String = ""
)
