package com.sbh.studio.settlement

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AppLang
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.S
import com.sbh.studio.ui.SectionTitle
import com.sbh.studio.workshop.WorkshopRepository
import com.sbh.studio.workshop.MapBlueprint

/**
 * Atelier de Monde — création de villages, villes, châteaux (style Steel & Flesh + AGW).
 * Pensé tactile / téléphone : listes, templates, grille compacte, formulaires.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettlementScreen(
    lang: AppLang,
    projectId: String = "",
    onBack: () -> Unit,
    onMessage: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val repo = remember { SettlementRepository(context) }
    var settlements by remember { mutableStateOf(repo.loadAll()) }
    var view by remember { mutableStateOf(SettlementView.List) }
    var selected by remember { mutableStateOf<SettlementBlueprint?>(null) }
    var placeKind by remember { mutableStateOf(BuildingKind.HOUSE) }

    fun refresh() {
        settlements = repo.loadAll()
    }

    fun openEditor(s: SettlementBlueprint) {
        selected = s
        view = SettlementView.Editor
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AgwColors.DeepNight)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = {
                when (view) {
                    SettlementView.List -> onBack()
                    else -> {
                        view = SettlementView.List
                        selected = null
                    }
                }
            }) {
                Text("←", color = AgwColors.SacredGold, fontSize = 20.sp)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    S.t(lang, "settlement_studio"),
                    color = AgwColors.SacredGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    S.t(lang, "settlement_subtitle"),
                    color = AgwColors.Sand,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        when (view) {
            SettlementView.List -> SettlementListPane(
                lang = lang,
                settlements = settlements,
                onOpen = { openEditor(it) },
                onDelete = {
                    settlements = repo.delete(it.id)
                    onMessage(S.t(lang, "settlement_deleted"))
                },
                onTemplates = { view = SettlementView.Templates },
                onSync = {
                    repo.syncToWorldCore()
                    onMessage(S.t(lang, "settlement_synced"))
                }
            )
            SettlementView.Templates -> TemplatePickerPane(
                lang = lang,
                projectId = projectId,
                onCreated = { s ->
                    settlements = repo.upsert(s)
                    openEditor(s)
                    onMessage(S.t(lang, "settlement_created"))
                },
                onCancel = { view = SettlementView.List }
            )
            SettlementView.Editor -> selected?.let { s ->
                SettlementEditorPane(
                    lang = lang,
                    settlement = s,
                    placeKind = placeKind,
                    onPlaceKind = { placeKind = it },
                    onChange = { next ->
                        selected = next
                        settlements = repo.upsert(next)
                    },
                    onCopySummary = {
                        val text = repo.exportSummary(s)
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("settlement", text))
                        onMessage(S.t(lang, "settlement_copied"))
                    },
                    onSync = {
                        repo.syncToWorldCore()
                        onMessage(S.t(lang, "settlement_synced"))
                    }
                )
            }
        }
    }
}

private enum class SettlementView { List, Templates, Editor }

// ─── Liste ───────────────────────────────────────────────────────────────────

@Composable
private fun SettlementListPane(
    lang: AppLang,
    settlements: List<SettlementBlueprint>,
    onOpen: (SettlementBlueprint) -> Unit,
    onDelete: (SettlementBlueprint) -> Unit,
    onTemplates: () -> Unit,
    onSync: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GoldPrimaryButton(
                text = S.t(lang, "settlement_new_from_template"),
                onClick = onTemplates,
                modifier = Modifier.weight(1f)
            )
            GoldOutlineButton(
                text = S.t(lang, "settlement_sync_world"),
                onClick = onSync,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(10.dp))

        if (settlements.isEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    S.t(lang, "settlement_empty"),
                    color = AgwColors.PaleMarble,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(settlements, key = { it.id }) { s ->
                    SettlementCard(lang, s, onOpen = { onOpen(s) }, onDelete = { onDelete(s) })
                }
            }
        }
    }
}

@Composable
private fun SettlementCard(
    lang: AppLang,
    s: SettlementBlueprint,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val name = when (lang) {
        AppLang.AR -> s.nameAr.ifBlank { s.nameFr }
        AppLang.EN -> s.nameEn.ifBlank { s.nameFr }
        else -> s.nameFr
    }
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(typeEmoji(s.type), fontSize = 22.sp)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = AgwColors.SacredGold, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${s.type} · ${s.style} · ${s.size}",
                        color = AgwColors.Sand,
                        fontSize = 11.sp
                    )
                }
                TextButton(onClick = onDelete) {
                    Text("✕", color = AgwColors.DriedBlood)
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "⚔ ${s.siegeDifficulty}/10  ·  👥 ${s.populationHint}  ·  🏛 ${s.buildings.size}",
                color = AgwColors.PaleMarble,
                fontSize = 12.sp
            )
            if (s.factionId.isNotBlank()) {
                Text(
                    "Faction : ${s.factionId}",
                    color = AgwColors.DesertOchre,
                    fontSize = 11.sp
                )
            }
            if (s.linkedMapId != null) {
                Text(
                    "🗺 Map liée · local (${s.mapLocalX}, ${s.mapLocalZ})",
                    color = AgwColors.PersianBlue,
                    fontSize = 11.sp
                )
            }
        }
    }
}

// ─── Templates ───────────────────────────────────────────────────────────────

@Composable
private fun TemplatePickerPane(
    lang: AppLang,
    projectId: String,
    onCreated: (SettlementBlueprint) -> Unit,
    onCancel: () -> Unit
) {
    val repo = remember { SettlementRepository(LocalContext.current) }

    Column(Modifier.fillMaxSize()) {
        SectionTitle(S.t(lang, "settlement_choose_template"))
        Spacer(Modifier.height(6.dp))
        Text(
            S.t(lang, "settlement_template_hint"),
            color = AgwColors.Sand,
            fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(SettlementTemplates.catalog, key = { it.id }) { tpl ->
                val title = when (lang) {
                    AppLang.AR -> tpl.nameAr
                    AppLang.EN -> tpl.nameEn
                    else -> tpl.nameFr
                }
                val desc = when (lang) {
                    AppLang.AR -> tpl.descriptionAr.ifBlank { tpl.descriptionFr }
                    AppLang.EN -> tpl.descriptionEn.ifBlank { tpl.descriptionFr }
                    else -> tpl.descriptionFr
                }
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val s = repo.createFromTemplate(tpl.id, projectId)
                            onCreated(s)
                        }
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(typeEmoji(tpl.type), fontSize = 20.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(title, color = AgwColors.SacredGold, fontWeight = FontWeight.SemiBold)
                        }
                        Text(desc, color = AgwColors.PaleMarble, fontSize = 12.sp)
                        Text(
                            "${tpl.size} · ${tpl.style}" +
                                if (tpl.suggestedFaction.isNotBlank()) " · ${tpl.suggestedFaction}" else "",
                            color = AgwColors.DesertOchre,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        GoldOutlineButton(
            text = S.t(lang, "cancel"),
            onClick = onCancel,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// ─── Éditeur ─────────────────────────────────────────────────────────────────

@Composable
private fun SettlementEditorPane(
    lang: AppLang,
    settlement: SettlementBlueprint,
    placeKind: BuildingKind,
    onPlaceKind: (BuildingKind) -> Unit,
    onChange: (SettlementBlueprint) -> Unit,
    onCopySummary: () -> Unit,
    onSync: () -> Unit
) {
    var tab by remember { mutableStateOf(0) } // 0 info · 1 grille · 2 défenses

    Column(Modifier.fillMaxSize()) {
        // Tabs
        ScrollableTabRow(
            selectedTabIndex = tab,
            containerColor = AgwColors.NightStone,
            contentColor = AgwColors.SacredGold,
            edgePadding = 0.dp
        ) {
            Tab(selected = tab == 0, onClick = { tab = 0 },
                text = { Text(S.t(lang, "settlement_tab_info"), fontSize = 13.sp) })
            Tab(selected = tab == 1, onClick = { tab = 1 },
                text = { Text(S.t(lang, "settlement_tab_grid"), fontSize = 13.sp) })
            Tab(selected = tab == 2, onClick = { tab = 2 },
                text = { Text(S.t(lang, "settlement_tab_defense"), fontSize = 13.sp) })
        }

        Spacer(Modifier.height(8.dp))

        when (tab) {
            0 -> {
                val ctx = LocalContext.current
                val maps = remember { WorkshopRepository(ctx).loadMaps() }
                val repo = remember { SettlementRepository(ctx) }
                InfoTab(
                    lang = lang,
                    s = settlement,
                    maps = maps,
                    onChange = onChange,
                    onLinkMap = { map ->
                        val linked = repo.linkToMap(settlement, map)
                        onChange(linked)
                    },
                    onUnlinkMap = {
                        val u = repo.unlinkFromMap(settlement)
                        onChange(u)
                    }
                )
            }
            1 -> GridTab(lang, settlement, placeKind, onPlaceKind, onChange)
            2 -> DefenseTab(lang, settlement, onChange)
        }

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            GoldOutlineButton(
                text = S.t(lang, "settlement_copy"),
                onClick = onCopySummary,
                modifier = Modifier.weight(1f)
            )
            GoldPrimaryButton(
                text = S.t(lang, "settlement_sync_world"),
                onClick = onSync,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun InfoTab(
    lang: AppLang,
    s: SettlementBlueprint,
    maps: List<MapBlueprint>,
    onChange: (SettlementBlueprint) -> Unit,
    onLinkMap: (MapBlueprint) -> Unit,
    onUnlinkMap: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = s.nameFr,
            onValueChange = { onChange(s.copy(nameFr = it)) },
            label = { Text("Nom (FR)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )
        OutlinedTextField(
            value = s.nameEn,
            onValueChange = { onChange(s.copy(nameEn = it)) },
            label = { Text("Name (EN)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )
        OutlinedTextField(
            value = s.nameAr,
            onValueChange = { onChange(s.copy(nameAr = it)) },
            label = { Text("الاسم (AR)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )
        OutlinedTextField(
            value = s.factionId,
            onValueChange = { onChange(s.copy(factionId = it)) },
            label = { Text(S.t(lang, "settlement_faction")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )
        OutlinedTextField(
            value = s.regionId,
            onValueChange = { onChange(s.copy(regionId = it)) },
            label = { Text(S.t(lang, "settlement_region")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )

        Text(S.t(lang, "settlement_type"), color = AgwColors.Sand, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(SettlementType.entries) { t ->
                FilterChip(
                    selected = s.type == t.name,
                    onClick = { onChange(s.copy(type = t.name)) },
                    label = { Text(t.name, fontSize = 11.sp) },
                    colors = chipColors()
                )
            }
        }

        Text(S.t(lang, "settlement_style"), color = AgwColors.Sand, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(ArchStyle.entries) { st ->
                FilterChip(
                    selected = s.style == st.name,
                    onClick = { onChange(s.copy(style = st.name)) },
                    label = { Text(st.name.replace('_', ' '), fontSize = 11.sp) },
                    colors = chipColors()
                )
            }
        }

        Text(S.t(lang, "settlement_size"), color = AgwColors.Sand, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(SettlementSize.entries) { sz ->
                FilterChip(
                    selected = s.size == sz.name,
                    onClick = { onChange(s.copy(size = sz.name)) },
                    label = { Text(sz.name, fontSize = 11.sp) },
                    colors = chipColors()
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = s.populationHint.toString(),
                onValueChange = { v ->
                    v.toIntOrNull()?.let { onChange(s.copy(populationHint = it.coerceIn(0, 50000))) }
                },
                label = { Text("👥") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = fieldColors()
            )
            OutlinedTextField(
                value = s.siegeDifficulty.toString(),
                onValueChange = { v ->
                    v.toIntOrNull()?.let { onChange(s.copy(siegeDifficulty = it.coerceIn(1, 10))) }
                },
                label = { Text("⚔ 1-10") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = fieldColors()
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = s.worldX.toString(),
                onValueChange = { v -> v.toIntOrNull()?.let { onChange(s.copy(worldX = it)) } },
                label = { Text("X") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = fieldColors()
            )
            OutlinedTextField(
                value = s.worldY.toString(),
                onValueChange = { v -> v.toIntOrNull()?.let { onChange(s.copy(worldY = it)) } },
                label = { Text("Y") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = fieldColors()
            )
            OutlinedTextField(
                value = s.worldZ.toString(),
                onValueChange = { v -> v.toIntOrNull()?.let { onChange(s.copy(worldZ = it)) } },
                label = { Text("Z") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = fieldColors()
            )
        }

        // Economy toggles
        Text(S.t(lang, "settlement_economy"), color = AgwColors.Sand, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            EcoChip("marché", s.economy.market) {
                onChange(s.copy(economy = s.economy.copy(market = !s.economy.market)))
            }
            EcoChip("caravanserail", s.economy.caravanserai) {
                onChange(s.copy(economy = s.economy.copy(caravanserai = !s.economy.caravanserai)))
            }
            EcoChip("forge", s.economy.forge) {
                onChange(s.copy(economy = s.economy.copy(forge = !s.economy.forge)))
            }
            EcoChip("ferme", s.economy.farm) {
                onChange(s.copy(economy = s.economy.copy(farm = !s.economy.farm)))
            }
            EcoChip("port", s.economy.port) {
                onChange(s.copy(economy = s.economy.copy(port = !s.economy.port)))
            }
        }

        // ── Lien Map Studio ──────────────────────────────────────────────
        Text(S.t(lang, "settlement_linked_map"), color = AgwColors.Sand, fontSize = 12.sp)
        if (s.linkedMapId != null) {
            val mapName = maps.find { it.id == s.linkedMapId }?.name ?: s.linkedMapId
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text(mapName ?: "", color = AgwColors.SacredGold, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Local (${s.mapLocalX}, ${s.mapLocalZ}) · Monde (${s.worldX}, ${s.worldZ})",
                        color = AgwColors.PaleMarble,
                        fontSize = 11.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = s.mapLocalX.toString(),
                            onValueChange = { v ->
                                v.toIntOrNull()?.let { x ->
                                    onChange(s.copy(mapLocalX = x, worldX = (maps.find { it.id == s.linkedMapId }?.worldX ?: 0) + x))
                                }
                            },
                            label = { Text("map X") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = fieldColors()
                        )
                        OutlinedTextField(
                            value = s.mapLocalZ.toString(),
                            onValueChange = { v ->
                                v.toIntOrNull()?.let { z ->
                                    onChange(s.copy(mapLocalZ = z, worldZ = (maps.find { it.id == s.linkedMapId }?.worldZ ?: 0) + z))
                                }
                            },
                            label = { Text("map Z") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = fieldColors()
                        )
                    }
                    GoldOutlineButton(
                        text = S.t(lang, "settlement_unlink_map"),
                        onClick = onUnlinkMap,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        } else if (maps.isEmpty()) {
            Text(S.t(lang, "settlement_no_maps"), color = AgwColors.Sand, fontSize = 12.sp)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(maps, key = { it.id }) { m ->
                    FilterChip(
                        selected = false,
                        onClick = { onLinkMap(m) },
                        label = { Text(m.name, fontSize = 11.sp) },
                        colors = chipColors()
                    )
                }
            }
            Text(S.t(lang, "settlement_link_hint"), color = AgwColors.DesertOchre, fontSize = 11.sp)
        }

        OutlinedTextField(
            value = s.notes,
            onValueChange = { onChange(s.copy(notes = it)) },
            label = { Text(S.t(lang, "notes")) },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            colors = fieldColors()
        )
    }
}

@Composable
private fun EcoChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 11.sp) },
        colors = chipColors()
    )
}

@Composable
private fun GridTab(
    lang: AppLang,
    s: SettlementBlueprint,
    placeKind: BuildingKind,
    onPlaceKind: (BuildingKind) -> Unit,
    onChange: (SettlementBlueprint) -> Unit
) {
    val cellSize = 28.dp
    val occupied = remember(s.buildings) {
        s.buildings.associateBy { it.gx to it.gz }
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            S.t(lang, "settlement_place_hint"),
            color = AgwColors.Sand,
            fontSize = 11.sp
        )
        Spacer(Modifier.height(4.dp))

        // Palette de bâtiments
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(BuildingKind.entries.filter {
                it != BuildingKind.WALL // murs gérés via WallConfig
            }) { kind ->
                FilterChip(
                    selected = placeKind == kind,
                    onClick = { onPlaceKind(kind) },
                    label = {
                        Text(
                            "${buildingEmoji(kind)} ${kind.name.take(6)}",
                            fontSize = 10.sp
                        )
                    },
                    colors = chipColors()
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        // Grille scrollable
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, AgwColors.GoldGlass, RoundedCornerShape(8.dp))
                .background(AgwColors.NightStone)
        ) {
            Column(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .verticalScroll(rememberScrollState())
                    .padding(4.dp)
            ) {
                for (z in 0 until s.gridH) {
                    Row {
                        for (x in 0 until s.gridW) {
                            val slot = occupied[x to z]
                            val isEdge = s.walls.hasWalls &&
                                (x == 0 || z == 0 || x == s.gridW - 1 || z == s.gridH - 1)
                            Box(
                                modifier = Modifier
                                    .size(cellSize)
                                    .padding(1.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(
                                        when {
                                            slot != null -> AgwColors.SacredGold.copy(alpha = 0.35f)
                                            isEdge -> AgwColors.DesertOchre.copy(alpha = 0.25f)
                                            else -> AgwColors.DeepNight
                                        }
                                    )
                                    .border(
                                        0.5.dp,
                                        if (slot != null) AgwColors.SacredGold else AgwColors.GoldGlass,
                                        RoundedCornerShape(3.dp)
                                    )
                                    .clickable {
                                        val existing = s.buildings.find { it.gx == x && it.gz == z }
                                        val nextBuildings = if (existing != null) {
                                            // Retirer
                                            s.buildings.filter { it.id != existing.id }
                                        } else {
                                            // Placer
                                            s.buildings + BuildingSlot(
                                                kind = placeKind.name,
                                                gx = x,
                                                gz = z,
                                                label = placeKind.name.lowercase()
                                                    .replaceFirstChar { it.uppercase() }
                                            )
                                        }
                                        onChange(s.copy(buildings = nextBuildings))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (slot != null) {
                                    Text(
                                        buildingEmoji(
                                            runCatching { BuildingKind.valueOf(slot.kind) }
                                                .getOrDefault(BuildingKind.CUSTOM)
                                        ),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Text(
            "${s.buildings.size} bâtiments · grille ${s.gridW}×${s.gridH}",
            color = AgwColors.PaleMarble,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun DefenseTab(
    lang: AppLang,
    s: SettlementBlueprint,
    onChange: (SettlementBlueprint) -> Unit
) {
    var defKind by remember { mutableStateOf("tower") }
    val kinds = listOf("tower", "catapult", "ballista", "ram", "arrow_slit", "watchpost")

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Murs
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(S.t(lang, "settlement_walls"), color = AgwColors.SacredGold, modifier = Modifier.weight(1f))
                    Switch(
                        checked = s.walls.hasWalls,
                        onCheckedChange = {
                            onChange(s.copy(walls = s.walls.copy(hasWalls = it)))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AgwColors.SacredGold,
                            checkedTrackColor = AgwColors.DesertOchre
                        )
                    )
                }
                if (s.walls.hasWalls) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = s.walls.material,
                            onValueChange = {
                                onChange(s.copy(walls = s.walls.copy(material = it)))
                            },
                            label = { Text("Matériau") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = fieldColors()
                        )
                        OutlinedTextField(
                            value = s.walls.height.toString(),
                            onValueChange = { v ->
                                v.toIntOrNull()?.let {
                                    onChange(s.copy(walls = s.walls.copy(height = it.coerceIn(1, 20))))
                                }
                            },
                            label = { Text("H") },
                            singleLine = true,
                            modifier = Modifier.width(72.dp),
                            colors = fieldColors()
                        )
                    }
                    Row {
                        FilterChip(
                            selected = s.walls.hasGate,
                            onClick = {
                                onChange(s.copy(walls = s.walls.copy(hasGate = !s.walls.hasGate)))
                            },
                            label = { Text("Porte") },
                            colors = chipColors()
                        )
                        Spacer(Modifier.width(6.dp))
                        FilterChip(
                            selected = s.walls.towersAtCorners,
                            onClick = {
                                onChange(
                                    s.copy(walls = s.walls.copy(towersAtCorners = !s.walls.towersAtCorners))
                                )
                            },
                            label = { Text("Tours d'angle") },
                            colors = chipColors()
                        )
                    }
                }
            }
        }

        Text(S.t(lang, "settlement_add_defense"), color = AgwColors.Sand, fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(kinds) { k ->
                FilterChip(
                    selected = defKind == k,
                    onClick = { defKind = k },
                    label = { Text(k, fontSize = 11.sp) },
                    colors = chipColors()
                )
            }
        }
        GoldOutlineButton(
            text = S.t(lang, "settlement_place_defense_center"),
            onClick = {
                val cx = s.gridW / 2
                val cz = 2
                onChange(
                    s.copy(
                        defenses = s.defenses + DefenseElement(
                            kind = defKind,
                            gx = cx,
                            gz = cz,
                            label = defKind
                        )
                    )
                )
            },
            modifier = Modifier.fillMaxWidth()
        )

        if (s.defenses.isEmpty()) {
            Text(S.t(lang, "settlement_no_defenses"), color = AgwColors.Sand, fontSize = 12.sp)
        } else {
            s.defenses.forEach { d ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚔", fontSize = 16.sp)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.label.ifBlank { d.kind }, color = AgwColors.PaleMarble)
                            Text("(${d.gx}, ${d.gz})", color = AgwColors.Sand, fontSize = 11.sp)
                        }
                        TextButton(onClick = {
                            onChange(s.copy(defenses = s.defenses.filter { it.id != d.id }))
                        }) {
                            Text("✕", color = AgwColors.DriedBlood)
                        }
                    }
                }
            }
        }
    }
}

// ─── Helpers UI ──────────────────────────────────────────────────────────────

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AgwColors.SacredGold,
    unfocusedBorderColor = AgwColors.GoldGlass,
    focusedLabelColor = AgwColors.SacredGold,
    unfocusedLabelColor = AgwColors.Sand,
    focusedTextColor = AgwColors.PaleMarble,
    unfocusedTextColor = AgwColors.PaleMarble,
    cursorColor = AgwColors.SacredGold
)

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = AgwColors.SacredGold.copy(alpha = 0.25f),
    selectedLabelColor = AgwColors.SacredGold,
    containerColor = AgwColors.NightStone,
    labelColor = AgwColors.Sand
)

private fun typeEmoji(type: String): String = when (type) {
    SettlementType.VILLAGE.name -> "🏘"
    SettlementType.TOWN.name -> "🏛"
    SettlementType.CITY.name -> "🌆"
    SettlementType.CASTLE.name -> "🏰"
    SettlementType.CITADEL.name -> "🏯"
    SettlementType.PORT.name -> "⚓"
    SettlementType.CAMP.name -> "⛺"
    SettlementType.RUIN.name -> "🏚"
    else -> "📍"
}

private fun buildingEmoji(kind: BuildingKind): String = when (kind) {
    BuildingKind.HOUSE -> "🏠"
    BuildingKind.MOSQUE -> "🕌"
    BuildingKind.MARKET -> "🏪"
    BuildingKind.WELL -> "💧"
    BuildingKind.CARAVANSERAI -> "🐪"
    BuildingKind.FORGE -> "⚒"
    BuildingKind.TOWER -> "🗼"
    BuildingKind.GATE -> "🚪"
    BuildingKind.WALL -> "🧱"
    BuildingKind.KEEP -> "🏰"
    BuildingKind.BARRACKS -> "🛡"
    BuildingKind.STABLES -> "🐴"
    BuildingKind.PORTAL_MARKER -> "🌀"
    BuildingKind.FARM -> "🌾"
    BuildingKind.OASIS -> "🌴"
    BuildingKind.DOCK -> "🚢"
    BuildingKind.WATCHPOST -> "👁"
    BuildingKind.CUSTOM -> "📦"
}
