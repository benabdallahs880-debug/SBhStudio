package com.sbh.studio.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import com.sbh.studio.settlement.SettlementBlueprint
import com.sbh.studio.settlement.SettlementType
import com.sbh.studio.settlement.SettlementBlueprint
import com.sbh.studio.settlement.SettlementType
import com.sbh.studio.workshop.MapBlueprint
import com.sbh.studio.workshop.PortalBlueprint
import java.io.File

/**
 * État persistant du monde AGW utilisé comme couche commune entre l'Atelier et Map Studio.
 * Les assets AGW fournissent le lore/factions de référence ; les éléments créés dans
 * l'Atelier sont synchronisés ici par identifiant stable.
 */
@Serializable
data class AgwWorldNode(
    val id: String,
    val type: String,
    val name: String,
    val region: String = "",
    val faction: String = "",
    val x: Int = 0,
    val y: Int = 64,
    val z: Int = 0,
    val source: String = "atelier"
)

@Serializable
data class AgwWorldCoreState(
    val schema: String = "sbh.agw.worldcore.v1",
    val worldId: String = "agw:al_zahra",
    val worldName: String = "Al-Zahra",
    val nodes: List<AgwWorldNode> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

class AgwWorldCoreRepository(private val context: Context) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val file get() = File(context.filesDir, "agw_world_core.json")

    fun load(): AgwWorldCoreState = try {
        if (!file.exists()) AgwWorldCoreState() else json.decodeFromString(file.readText())
    } catch (_: Exception) { AgwWorldCoreState() }

    fun save(state: AgwWorldCoreState) {
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, "${file.name}.tmp")
        tmp.writeText(json.encodeToString(state.copy(updatedAt = System.currentTimeMillis())))
        if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
    }

    /** Construit une vue AGW à partir des données de référence + contenu Atelier + peuplements. */
    fun synchronize(
        agw: AgwDataRepository,
        maps: List<MapBlueprint>,
        portals: List<PortalBlueprint>,
        projectId: String,
        settlements: List<SettlementBlueprint> = emptyList()
    ): AgwWorldCoreState {
        val factions = agw.loadFactions()
        val factionNodes = factions.map { f ->
            AgwWorldNode(
                id = f.id.ifBlank { "agw:faction_${factions.indexOf(f)}" },
                type = "faction",
                name = f.name["fr"] ?: f.id,
                region = f.territory,
                faction = f.id,
                source = "agw"
            )
        }
        val mapNodes = maps.filter { it.projectId == projectId || projectId.isBlank() }.map { m ->
            AgwWorldNode(
                id = "map:${m.id}", type = "map", name = m.name,
                x = m.worldX, y = m.height, z = m.worldZ, source = "atelier"
            )
        }
        val portalNodes = portals.filter { it.projectId == projectId || projectId.isBlank() }.map { p ->
            AgwWorldNode(
                id = "portal:${p.id}", type = "portal", name = p.name,
                x = p.mapX, y = p.mapY, z = p.mapZ, source = "atelier"
            )
        }
        val settlementNodes = settlements
            .filter { it.projectId == projectId || projectId.isBlank() || it.projectId.isBlank() }
            .map { s ->
                val nodeType = when (runCatching { SettlementType.valueOf(s.type) }.getOrNull()) {
                    SettlementType.CASTLE, SettlementType.CITADEL -> "building"
                    SettlementType.PORT -> "location"
                    else -> "building"
                }
                AgwWorldNode(
                    id = "settlement:${s.id}",
                    type = nodeType,
                    name = s.nameFr,
                    region = s.regionId.ifBlank { s.linkedMapId ?: "" },
                    faction = s.factionId,
                    x = s.worldX,
                    y = s.worldY,
                    z = s.worldZ,
                    source = "settlement"
                )
            }
        val previous = load().nodes.filter { it.source == "studio" }
        return AgwWorldCoreState(
            nodes = factionNodes + mapNodes + portalNodes + settlementNodes + previous,
            worldName = agw.loadLore().world_name["fr"] ?: "Al-Zahra"
        )
    }
}
