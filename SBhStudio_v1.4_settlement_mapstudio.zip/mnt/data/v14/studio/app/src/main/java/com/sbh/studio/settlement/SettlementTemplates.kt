package com.sbh.studio.settlement

/**
 * Templates prêts à l'emploi — villages arabes, médinas, châteaux, citadelles AGW.
 * Inspirés de l'échelle Steel & Flesh 2 (village / ville / château / siège),
 * adaptés à Al-Zahra et au mobile.
 */
object SettlementTemplates {

    val catalog: List<SettlementTemplateInfo> = listOf(
        SettlementTemplateInfo(
            id = "tpl_arab_village",
            nameFr = "Village arabe",
            nameEn = "Arabian village",
            nameAr = "قرية عربية",
            type = SettlementType.VILLAGE.name,
            style = ArchStyle.ARABIAN_DESERT.name,
            size = SettlementSize.MEDIUM.name,
            descriptionFr = "Maisons adobe, puits, petite mosquée, mur bas. Idéal oasis ou piste caravanière.",
            descriptionEn = "Adobe houses, well, small mosque, low wall. Ideal for oasis or caravan trail.",
            descriptionAr = "بيوت طينية وبئر ومسجد صغير وسور منخفض.",
            suggestedFaction = "bedouins"
        ),
        SettlementTemplateInfo(
            id = "tpl_desert_hamlet",
            nameFr = "Hameau du désert",
            nameEn = "Desert hamlet",
            nameAr = "مزرعة صحراوية",
            type = SettlementType.VILLAGE.name,
            style = ArchStyle.ARABIAN_DESERT.name,
            size = SettlementSize.SMALL.name,
            descriptionFr = "Quelques maisons autour d'un puits et d'une oasis. Peu de défenses.",
            descriptionEn = "A few houses around a well and oasis. Light defenses.",
            descriptionAr = "بيوت قليلة حول بئر وواحة.",
            suggestedFaction = "bedouins"
        ),
        SettlementTemplateInfo(
            id = "tpl_medina",
            nameFr = "Médina",
            nameEn = "Medina",
            nameAr = "مدينة",
            type = SettlementType.TOWN.name,
            style = ArchStyle.PORT_MEDINA.name,
            size = SettlementSize.LARGE.name,
            descriptionFr = "Ruelles, souk, minaret, caravanserail, portes fortifiées.",
            descriptionEn = "Alleys, souk, minaret, caravanserai, fortified gates.",
            descriptionAr = "أزقة وسوق ومئذنة وخان وأبواب محصنة.",
            suggestedFaction = "royaume"
        ),
        SettlementTemplateInfo(
            id = "tpl_stone_castle",
            nameFr = "Château de pierre",
            nameEn = "Stone castle",
            nameAr = "قلعة حجرية",
            type = SettlementType.CASTLE.name,
            style = ArchStyle.FORTRESS_STONE.name,
            size = SettlementSize.LARGE.name,
            descriptionFr = "Donjon, courtines, tours d'angle, porte barbacane. Siège difficile.",
            descriptionEn = "Keep, curtain walls, corner towers, barbican gate. Hard siege.",
            descriptionAr = "حصن وأسوار وأبراج وبوابة.",
            suggestedFaction = "templiers"
        ),
        SettlementTemplateInfo(
            id = "tpl_hibou_citadel",
            nameFr = "Citadelle du Hibou",
            nameEn = "Owl Citadel",
            nameAr = "قلعة البوم",
            type = SettlementType.CITADEL.name,
            style = ArchStyle.GOTHIC_ARABIAN.name,
            size = SettlementSize.LARGE.name,
            descriptionFr = "Refuge de montagne des Hiboux : pierre de nuit, tours gothiques, portail sacré.",
            descriptionEn = "Mountain refuge of the Owls: night stone, gothic towers, sacred portal.",
            descriptionAr = "ملاذ جبلي للبوم: حجر ليلي وأبراج قوطية.",
            suggestedFaction = "hibou"
        ),
        SettlementTemplateInfo(
            id = "tpl_ghurab_fort",
            nameFr = "Forteresse Ghurab",
            nameEn = "Ghurab Fortress",
            nameAr = "حصن الغراب",
            type = SettlementType.CASTLE.name,
            style = ArchStyle.GOTHIC_ARABIAN.name,
            size = SettlementSize.MEDIUM.name,
            descriptionFr = "Forteresse disciplinée sur crête rocheuse. Casernes et tour de guet.",
            descriptionEn = "Disciplined fortress on a rocky ridge. Barracks and watchtower.",
            descriptionAr = "حصن منضبط على قمة صخرية.",
            suggestedFaction = "ghurab"
        ),
        SettlementTemplateInfo(
            id = "tpl_caravan_port",
            nameFr = "Port / caravanserail",
            nameEn = "Port / caravanserai",
            nameAr = "ميناء / خان",
            type = SettlementType.PORT.name,
            style = ArchStyle.PORT_MEDINA.name,
            size = SettlementSize.MEDIUM.name,
            descriptionFr = "Quais, entrepôts, caravanserail, marché. Point d'échange commercial.",
            descriptionEn = "Docks, warehouses, caravanserai, market. Trade hub.",
            descriptionAr = "أرصفة ومخازن وخان وسوق.",
            suggestedFaction = "royaume"
        ),
        SettlementTemplateInfo(
            id = "tpl_bedouin_camp",
            nameFr = "Camp bédouin",
            nameEn = "Bedouin camp",
            nameAr = "مخيم بدوي",
            type = SettlementType.CAMP.name,
            style = ArchStyle.BEDOUIN_CAMP.name,
            size = SettlementSize.SMALL.name,
            descriptionFr = "Tentes, enclos, feu central. Mobile, peu de murs.",
            descriptionEn = "Tents, pens, central fire. Mobile, few walls.",
            descriptionAr = "خيام وحظائر ونار مركزية.",
            suggestedFaction = "bedouins"
        ),
        SettlementTemplateInfo(
            id = "tpl_ruin_outpost",
            nameFr = "Avant-poste en ruine",
            nameEn = "Ruined outpost",
            nameAr = "موقع أثري",
            type = SettlementType.RUIN.name,
            style = ArchStyle.FORTRESS_STONE.name,
            size = SettlementSize.SMALL.name,
            descriptionFr = "Tours effondrées, spectres, trésors cachés. Ambiance gothique.",
            descriptionEn = "Collapsed towers, specters, hidden treasures. Gothic mood.",
            descriptionAr = "أبراج منهارة وأشباح وكنوز مخفية.",
            suggestedFaction = ""
        )
    )

    fun byId(id: String): SettlementTemplateInfo? = catalog.find { it.id == id }

    /**
     * Construit un SettlementBlueprint complet à partir d'un template.
     * Les positions sont sur une grille logique adaptée au tactile.
     */
    fun instantiate(
        templateId: String,
        projectId: String = "",
        factionOverride: String? = null
    ): SettlementBlueprint {
        val info = byId(templateId) ?: byId("tpl_arab_village")!!
        val faction = factionOverride?.takeIf { it.isNotBlank() } ?: info.suggestedFaction

        return when (info.id) {
            "tpl_arab_village" -> arabVillage(projectId, faction)
            "tpl_desert_hamlet" -> desertHamlet(projectId, faction)
            "tpl_medina" -> medina(projectId, faction)
            "tpl_stone_castle" -> stoneCastle(projectId, faction)
            "tpl_hibou_citadel" -> hibouCitadel(projectId, faction)
            "tpl_ghurab_fort" -> ghurabFort(projectId, faction)
            "tpl_caravan_port" -> caravanPort(projectId, faction)
            "tpl_bedouin_camp" -> bedouinCamp(projectId, faction)
            "tpl_ruin_outpost" -> ruinOutpost(projectId, faction)
            else -> arabVillage(projectId, faction)
        }.copy(
            templateId = info.id,
            nameFr = info.nameFr,
            nameEn = info.nameEn,
            nameAr = info.nameAr
        )
    }

    // -------------------------------------------------------------------------
    // Templates concrets (grilles compactes pour mobile)
    // -------------------------------------------------------------------------

    private fun arabVillage(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.VILLAGE.name,
        style = ArchStyle.ARABIAN_DESERT.name,
        size = SettlementSize.MEDIUM.name,
        factionId = faction,
        gridW = 14,
        gridH = 14,
        walls = WallConfig(hasWalls = true, material = "adobe", height = 3, hasGate = true, towersAtCorners = false),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.WELL.name, gx = 6, gz = 6, label = "Puits", blockHint = "agw:sandstone"),
            BuildingSlot(kind = BuildingKind.MOSQUE.name, gx = 9, gz = 4, label = "Mosquée", blockHint = "agw:pale_marble"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 3, gz = 3, label = "Maison", blockHint = "agw:desert_bricks"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 4, gz = 8, label = "Maison", blockHint = "agw:desert_bricks"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 8, gz = 9, label = "Maison", blockHint = "agw:desert_bricks"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 10, gz = 7, label = "Maison", blockHint = "agw:desert_bricks"),
            BuildingSlot(kind = BuildingKind.MARKET.name, gx = 5, gz = 5, label = "Souk", blockHint = "agw:wood_planks"),
            BuildingSlot(kind = BuildingKind.FARM.name, gx = 2, gz = 11, label = "Champ", blockHint = "minecraft:farmland"),
            BuildingSlot(kind = BuildingKind.GATE.name, gx = 6, gz = 0, label = "Porte sud", blockHint = "agw:night_bricks")
        ),
        defenses = listOf(
            DefenseElement(kind = "watchpost", gx = 1, gz = 1, label = "Guet"),
            DefenseElement(kind = "watchpost", gx = 12, gz = 12, label = "Guet")
        ),
        economy = EconomyTags(market = true, farm = true),
        populationHint = 80,
        siegeDifficulty = 2,
        notes = "Village arabe classique — oasis / piste."
    )

    private fun desertHamlet(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.VILLAGE.name,
        style = ArchStyle.ARABIAN_DESERT.name,
        size = SettlementSize.SMALL.name,
        factionId = faction,
        gridW = 10,
        gridH = 10,
        walls = WallConfig(hasWalls = false),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.WELL.name, gx = 4, gz = 4, label = "Puits"),
            BuildingSlot(kind = BuildingKind.OASIS.name, gx = 5, gz = 5, label = "Oasis", blockHint = "minecraft:water"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 2, gz = 3, label = "Maison"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 6, gz = 2, label = "Maison"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 3, gz = 7, label = "Maison")
        ),
        economy = EconomyTags(farm = true),
        populationHint = 25,
        siegeDifficulty = 1
    )

    private fun medina(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.TOWN.name,
        style = ArchStyle.PORT_MEDINA.name,
        size = SettlementSize.LARGE.name,
        factionId = faction,
        gridW = 20,
        gridH = 20,
        walls = WallConfig(hasWalls = true, material = "stone", height = 5, hasGate = true, towersAtCorners = true),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.MOSQUE.name, gx = 10, gz = 8, label = "Grande mosquée", blockHint = "agw:pale_marble"),
            BuildingSlot(kind = BuildingKind.MARKET.name, gx = 8, gz = 10, label = "Souk", blockHint = "agw:wood_planks"),
            BuildingSlot(kind = BuildingKind.CARAVANSERAI.name, gx = 14, gz = 12, label = "Caravanserail", blockHint = "agw:desert_bricks"),
            BuildingSlot(kind = BuildingKind.WELL.name, gx = 9, gz = 9, label = "Puits central"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 4, gz = 4, label = "Riad"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 5, gz = 14, label = "Riad"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 15, gz = 5, label = "Riad"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 16, gz = 15, label = "Riad"),
            BuildingSlot(kind = BuildingKind.FORGE.name, gx = 3, gz = 12, label = "Forge"),
            BuildingSlot(kind = BuildingKind.GATE.name, gx = 10, gz = 0, label = "Bab al-Janub"),
            BuildingSlot(kind = BuildingKind.GATE.name, gx = 0, gz = 10, label = "Bab al-Gharb"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 0, gz = 0, label = "Tour NO"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 19, gz = 0, label = "Tour NE"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 0, gz = 19, label = "Tour SO"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 19, gz = 19, label = "Tour SE")
        ),
        defenses = listOf(
            DefenseElement(kind = "arrow_slit", gx = 10, gz = 1, label = "Meurtrières"),
            DefenseElement(kind = "tower", gx = 5, gz = 0, label = "Tour de mur")
        ),
        economy = EconomyTags(market = true, caravanserai = true, forge = true),
        populationHint = 400,
        siegeDifficulty = 6,
        notes = "Médina fortifiée — cœur commercial."
    )

    private fun stoneCastle(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.CASTLE.name,
        style = ArchStyle.FORTRESS_STONE.name,
        size = SettlementSize.LARGE.name,
        factionId = faction,
        gridW = 16,
        gridH = 16,
        walls = WallConfig(hasWalls = true, material = "stone", height = 8, hasGate = true, towersAtCorners = true),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.KEEP.name, gx = 7, gz = 7, label = "Donjon", blockHint = "agw:night_bricks"),
            BuildingSlot(kind = BuildingKind.BARRACKS.name, gx = 4, gz = 9, label = "Caserne"),
            BuildingSlot(kind = BuildingKind.STABLES.name, gx = 10, gz = 9, label = "Écuries"),
            BuildingSlot(kind = BuildingKind.FORGE.name, gx = 3, gz = 5, label = "Forge de siège"),
            BuildingSlot(kind = BuildingKind.GATE.name, gx = 7, gz = 0, label = "Barbacane"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 0, gz = 0, label = "Tour NO"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 15, gz = 0, label = "Tour NE"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 0, gz = 15, label = "Tour SO"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 15, gz = 15, label = "Tour SE"),
            BuildingSlot(kind = BuildingKind.WELL.name, gx = 8, gz = 6, label = "Puits du château")
        ),
        defenses = listOf(
            DefenseElement(kind = "catapult", gx = 7, gz = 2, label = "Catapulte"),
            DefenseElement(kind = "ballista", gx = 2, gz = 7, label = "Baliste"),
            DefenseElement(kind = "arrow_slit", gx = 7, gz = 1, label = "Meurtrières")
        ),
        economy = EconomyTags(forge = true),
        populationHint = 120,
        siegeDifficulty = 8,
        notes = "Château de pierre — siège type Steel & Flesh."
    )

    private fun hibouCitadel(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.CITADEL.name,
        style = ArchStyle.GOTHIC_ARABIAN.name,
        size = SettlementSize.LARGE.name,
        factionId = faction.ifBlank { "hibou" },
        gridW = 18,
        gridH = 18,
        walls = WallConfig(hasWalls = true, material = "night_stone", height = 10, hasGate = true, towersAtCorners = true),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.KEEP.name, gx = 8, gz = 8, label = "Tour du Hibou", blockHint = "agw:night_bricks"),
            BuildingSlot(kind = BuildingKind.MOSQUE.name, gx = 11, gz = 6, label = "Sanctuaire", blockHint = "agw:pale_marble"),
            BuildingSlot(kind = BuildingKind.PORTAL_MARKER.name, gx = 8, gz = 5, label = "Portail sacré", blockHint = "agw:portal_frame"),
            BuildingSlot(kind = BuildingKind.BARRACKS.name, gx = 4, gz = 10, label = "Veilleurs"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 12, gz = 12, label = "Refuge"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 5, gz = 4, label = "Refuge"),
            BuildingSlot(kind = BuildingKind.GATE.name, gx = 8, gz = 0, label = "Porte de la Nuit"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 0, gz = 0, label = "Tour gothique"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 17, gz = 0, label = "Tour gothique"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 0, gz = 17, label = "Tour gothique"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 17, gz = 17, label = "Tour gothique"),
            BuildingSlot(kind = BuildingKind.WELL.name, gx = 9, gz = 9, label = "Source")
        ),
        defenses = listOf(
            DefenseElement(kind = "tower", gx = 8, gz = 2, label = "Tour de guet"),
            DefenseElement(kind = "arrow_slit", gx = 8, gz = 1, label = "Meurtrières")
        ),
        economy = EconomyTags(),
        populationHint = 90,
        siegeDifficulty = 9,
        notes = "Citadelle du Hibou — refuge AGW de montagne."
    )

    private fun ghurabFort(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.CASTLE.name,
        style = ArchStyle.GOTHIC_ARABIAN.name,
        size = SettlementSize.MEDIUM.name,
        factionId = faction.ifBlank { "ghurab" },
        gridW = 12,
        gridH = 12,
        walls = WallConfig(hasWalls = true, material = "night_stone", height = 7, hasGate = true, towersAtCorners = true),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.KEEP.name, gx = 5, gz = 5, label = "Donjon Ghurab"),
            BuildingSlot(kind = BuildingKind.BARRACKS.name, gx = 3, gz = 7, label = "Caserne"),
            BuildingSlot(kind = BuildingKind.WATCHPOST.name, gx = 5, gz = 1, label = "Guet"),
            BuildingSlot(kind = BuildingKind.GATE.name, gx = 5, gz = 0, label = "Porte"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 0, gz = 0, label = "Tour"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 11, gz = 0, label = "Tour"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 0, gz = 11, label = "Tour"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 11, gz = 11, label = "Tour")
        ),
        defenses = listOf(
            DefenseElement(kind = "ballista", gx = 5, gz = 2, label = "Baliste")
        ),
        economy = EconomyTags(forge = true),
        populationHint = 60,
        siegeDifficulty = 7
    )

    private fun caravanPort(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.PORT.name,
        style = ArchStyle.PORT_MEDINA.name,
        size = SettlementSize.MEDIUM.name,
        factionId = faction,
        gridW = 16,
        gridH = 14,
        walls = WallConfig(hasWalls = true, material = "stone", height = 4, hasGate = true, towersAtCorners = false),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.DOCK.name, gx = 7, gz = 12, label = "Quai", blockHint = "agw:wood_planks"),
            BuildingSlot(kind = BuildingKind.CARAVANSERAI.name, gx = 8, gz = 6, label = "Caravanserail"),
            BuildingSlot(kind = BuildingKind.MARKET.name, gx = 5, gz = 5, label = "Marché"),
            BuildingSlot(kind = BuildingKind.CUSTOM.name, gx = 11, gz = 5, label = "Entrepôt", blockHint = "agw:desert_bricks"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 3, gz = 3, label = "Maison"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 12, gz = 3, label = "Maison"),
            BuildingSlot(kind = BuildingKind.GATE.name, gx = 7, gz = 0, label = "Porte terre"),
            BuildingSlot(kind = BuildingKind.WELL.name, gx = 6, gz = 7, label = "Puits")
        ),
        economy = EconomyTags(market = true, caravanserai = true, port = true),
        populationHint = 150,
        siegeDifficulty = 4,
        notes = "Port / caravanserail — hub commercial."
    )

    private fun bedouinCamp(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.CAMP.name,
        style = ArchStyle.BEDOUIN_CAMP.name,
        size = SettlementSize.SMALL.name,
        factionId = faction.ifBlank { "bedouins" },
        gridW = 10,
        gridH = 10,
        walls = WallConfig(hasWalls = false),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 4, gz = 4, label = "Tente chef", blockHint = "agw:cloth"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 2, gz = 5, label = "Tente"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 6, gz = 5, label = "Tente"),
            BuildingSlot(kind = BuildingKind.HOUSE.name, gx = 3, gz = 7, label = "Tente"),
            BuildingSlot(kind = BuildingKind.WELL.name, gx = 5, gz = 3, label = "Feu / puits")
        ),
        economy = EconomyTags(),
        populationHint = 30,
        siegeDifficulty = 1
    )

    private fun ruinOutpost(projectId: String, faction: String) = SettlementBlueprint(
        projectId = projectId,
        type = SettlementType.RUIN.name,
        style = ArchStyle.FORTRESS_STONE.name,
        size = SettlementSize.SMALL.name,
        factionId = faction,
        gridW = 12,
        gridH = 12,
        walls = WallConfig(hasWalls = true, material = "ruined_stone", height = 3, hasGate = false, towersAtCorners = false),
        buildings = listOf(
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 2, gz = 2, label = "Tour effondrée"),
            BuildingSlot(kind = BuildingKind.TOWER.name, gx = 9, gz = 9, label = "Tour brisée"),
            BuildingSlot(kind = BuildingKind.KEEP.name, gx = 5, gz = 5, label = "Donjon en ruine"),
            BuildingSlot(kind = BuildingKind.WELL.name, gx = 6, gz = 6, label = "Puits asséché")
        ),
        defenses = emptyList(),
        economy = EconomyTags(),
        populationHint = 0,
        siegeDifficulty = 2,
        notes = "Ruines — ambiance gothique, trésors possibles."
    )
}
