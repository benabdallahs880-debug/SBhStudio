# Analyse profonde — Map Studio V1.8.60 (moteur et code source)

**Date :** 05/10/2026
**Périmètre :** Map Studio uniquement, dans sa version réparée V1.8.60 :
- `app/src/main/assets/mapstudio.html` (≈ 3 900 lignes) ;
- `mapeditor/MapEditorScreen.kt` ;
- `mapeditor/MapStudioStore.kt` ;
- la partie « maps » de `generator/AdvancedPackEngine.kt` ;
- la page publiée dans Claude.

**Nature :** analyse seule. **Aucune ligne du projet n'a été modifiée.**

**Méthode :**
- Relecture complète du code.
- Sondes dans un vrai Chromium (WebGL) sur une **copie** de la page qui expose en lecture le moteur 3D, la scène et la caméra.
- Pont Android simulé.
- Mesures de temps et de mémoire.

Les scripts de reproduction sont dans `tools/mapstudio_tests/analyse_1_8_60/`.

> Niveaux :
> - 🔴 **critique** : perte de données ou risque de sécurité ;
> - 🟠 **majeur** : résultat faux, perte de travail ciblée, risque de plantage ;
> - 🟡 **mineur** : confort, performance, code mort.
>
> Preuve :
> - **Prouvé** : reproduit par une sonde ;
> - **Code** : constaté à la lecture, sans ambiguïté ;
> - **Probable** : dépend du téléphone ou de Minecraft, à confirmer.

---

## 1. Résumé

| Niveau | Nombre |
|--------|--------|
| 🔴 Critique | 3 |
| 🟠 Majeur | 12 |
| 🟡 Mineur | 15 |
| **Total** | **30** |

**Ce qui tient :** les 62 contrôles de la réparation restent valables. Le doigt, l'historique, la Ligne, le sol de construction, les imports et l'export Bedrock fonctionnent dans les cas testés. Aucune erreur de syntaxe JavaScript. La relecture du Kotlin ne montre pas d'erreur de compilation évidente (non compilé ici).

**Ce qui ne tient pas :**
- Les **sauvegardes** dépendent de l'ordre interne des blocs (n° 1).
- Un fichier importé peut **exécuter du code** dans l'app (n° 2).
- L'**unique sauvegarde automatique** est écrasée quand on ouvre une autre map (n° 3).

Les trois sont nés dans la V1.8.60 elle-même.

---

## 2. 🔴 Critiques

### 1 — Les maps sauvegardées dépendent de l'ordre des blocs dans le code
**Où :** `serializeWorld` / `deserializeWorldInto` (≈ l. 3102-3130). Le monde est enregistré avec les **numéros internes** des blocs (leur position dans la liste `BLOCKS`), sans table de noms.

**Concerne :** la sauvegarde automatique, la sauvegarde manuelle 💾, les maps envoyées à l'Atelier (`map_studio/<projet>/maps/*.json`) et l'import d'un export « sbh-map-studio ».

**Preuve (prouvé, `probe2.py`) :** une sauvegarde relue par une version qui a **un seul bloc de plus** en tête de liste ressort avec **toute la pierre (8 307 blocs) changée en « marbre »**. Chaque bloc glisse d'un rang.

**Effet :** la prochaine mise à jour qui ajoute un bloc au milieu de la palette, comme la V1.8.60 l'a fait avec `deepslate_bricks`, transformera toutes les maps déjà sauvegardées. Rien ne le signale.

*Les fonctions Bedrock déjà calculées (texte) ne sont pas touchées. La map rouverte dans Map Studio, elle, l'est.*

### 2 — Un fichier importé peut exécuter du code dans l'app
**Où :** `renderReport()` (≈ l. 1152-1194) insère `name`, `type` et `extra` des structures **sans échappement** (`innerHTML`). Ces structures sont reprises telles quelles d'un fichier importé (`importFile` → `restoreState`) ou d'une map de l'Atelier.

**Preuve (prouvé, `probe1.py`) :** un `.json` piégé, importé puis le Livre de rapport ouvert, exécute son script (`window.__xss = 1`).

**Effet dans l'app Android :** le script a accès à tout le pont `SBhBridge` :
- lecture des données du projet (`atelierData`, `loadState`, `loadAtelierMap`) ;
- écriture de fichiers (`saveFile`, `saveObjectGlb`, `exportMap`, `syncEntities`) ;
- la WebView ne bloque pas les requêtes réseau sortantes, donc les données peuvent partir sur internet.

Il suffit de recevoir et d'importer un fichier « map » piégé.

### 3 — La seule sauvegarde automatique est écrasée en 1,5 s par « Ouvrir », « Nouvelle map » ou « Charger »
**Où :**
- `restoreState` / `btnNew` / `btnLoad` passent par `snapshotEdit` → `pushHistory` → `onWorldChanged` → `scheduleAutosave` ;
- il n'y a **qu'un emplacement automatique par projet** (`state_autosave`).

**Preuve (prouvé, `probe3.py`) :** une map B non envoyée, puis « Ouvrir » une map A de l'Atelier → 1,5 s plus tard, la sauvegarde automatique contient **A**. B n'existe plus que dans l'historique Annuler de la session, perdu à la fermeture.

**Aggravant :** la fenêtre de confirmation affiche « La map actuelle reste dans la sauvegarde automatique jusqu'à la prochaine modification », ce qui est **faux**.

---

## 3. 🟠 Majeurs

### 4 — Déplacer un objet au doigt n'est pas sauvegardé
- **Où :** `endPointer` pour l'outil Objets appelle `scheduleEntitySync()` mais **pas** `scheduleAutosave()`. Au Retour, `sbhBeforeClose()` ne sauve rien, car aucune sauvegarde n'est en attente.
- **Preuve (prouvé, `probe4.py`) :** objet déplacé de (32,32) à (52,5 ; 18,5), puis Retour → la sauvegarde garde **(32, 30, 32)**.
- **Dans le navigateur :** il n'y a pas non plus de synchronisation avec l'Atelier, donc le déplacement est totalement perdu.

### 5 — Annuler « Nouvelle map » ne rétablit que les blocs
- **Où :** `btnNew` remet à zéro le lien avec l'Atelier, le nom, l'UUID et le compteur du pack, et retire les objets, **en dehors** de l'instantané.
- **Preuve (prouvé, `probe2.py`) :** après Annuler, les blocs sont revenus (101 212), mais le lien vaut `None` et le nom « Nouvelle map ».
- **Effet :** le prochain « Envoyer à l'Atelier » crée une **deuxième map en double**. Le prochain export 🎮 crée un **nouveau pack** (nouvel UUID), et Minecraft garde les deux.
- **Même défaut, plus léger :** Annuler un « Import » ou une « Map chargée » ne rend ni les objets ni la liste des structures (n° 16).

### 6 — Boîte, Sphère et Ligne ne construisent pas en hauteur sur un sol plat
- **Où :** `shapeCell(hit)` prend **le bloc touché lui-même**, pas la case au-dessus. Le seul moyen de donner de la hauteur est de toucher des blocs déjà plus hauts. Aucun réglage de hauteur n'existe.
- **Preuve (prouvé, `probe2.py`) :** une Boîte tracée sur un sol plat laisse le nombre de blocs **inchangé** (61 440 → 61 440). Elle remplace la couche de surface au lieu de monter un volume.
- *Comportement hérité de l'origine, mais c'est l'outil principal pour construire au doigt.*

### 7 — Code Studio : `line` sans limite de coordonnées
- **Où :** `codeLine` calcule **tous** les points (`linePoints`) avant de borner. Les autres commandes sont bornées (MS-26).
- **Preuve (prouvé, `probe1.py`) :** `line 0 0 0 30000000 0 0 stone` prend **3,4 s sur PC** et alloue 30 millions de points. Avec `1e9`, la validation l'accepte, et c'est un plantage par manque de mémoire.

### 8 — Fuite de textures 3D à chaque reconstruction
- **Où :** `refreshMarkers()` libère les géométries mais **jamais** les textures des étiquettes (`CanvasTexture`) ni les matériaux. Elle est appelée à chaque `rebuildHelpers`, c'est-à-dire à chaque Annuler/Rétablir global, génération, import, redimensionnement ou envoi.
- **Preuve (prouvé, `probe1.py`) :** avec 3 régions, après 20 rafraîchissements, on passe de **1 à 61 textures** en mémoire graphique.

### 9 — Grands mondes : mémoire et temps sur téléphone
- **Mesuré sur PC (`probe5.py`) :**
  - 256×256×256 : redimensionnement **9,2 s** ;
  - mémoire JS **283 Mo** avec seulement 2 actions dans l'historique (chaque instantané = 2 × 33 Mo).
- **Code :**
  - `exportSchem` construit un tableau JS **par case** (16,7 millions), recopié deux fois (`NBYTES`, `NCOMP`) ;
  - `exportJson` construit un tableau par bloc.
- **Probable :** la WebView du téléphone manque de mémoire au-delà d'environ 128×128×128, sans message clair.

### 10 — Gros modèles .glb : passage en base64 et fichiers jamais supprimés
- **Où :**
  - un `.glb` choisi dans les fichiers passe par `saveObjectGlb(key, base64)`. Un modèle de 60 Mo devient une chaîne d'environ 80 Mo dans le pont (risque de manque de mémoire). L'import depuis Character Studio, lui, évite ce passage ;
  - `objects/*.glb` et `maps/*.json` ne sont **jamais nettoyés**, même quand l'objet ou la map est supprimé. Le stockage grossit sans fin.
- **Preuve :** code.

### 11 — Dans Minecraft : effets probables des fonctions Bedrock
**Où :** `bedrockCommandLines`. Effets probables (à confirmer en jeu) :
- **Eau et lave au bord de la map** : elles coulent hors de la zone et inondent le monde. Même chose pour l'eau « flottante » de l'oasis sur terrain en pente (n° 30).
- **Sable et gravier au-dessus du vide** (grottes, surplombs) : ils tombent.
- **Feuilles posées par commande** : sans bûche à 4 blocs, elles se décomposent.
- **Hauteur** : position du joueur + hauteur de la map > limite de construction (y = 320) → lignes refusées.
- **Grandes maps (au-delà d'environ 128 blocs)** : les commandes visant des chunks non chargés autour du joueur échouent.

### 12 — Map Studio « s'approprie » les entités de l'Atelier
- **Où :** au démarrage, `init()` ajoute à la scène **toutes** les entités du projet sans map liée (cubes dorés si elles n'ont pas de `.glb`). Au premier envoi, `flushEntitySync()` les renvoie **toutes** avec `linkedMapId` = la map courante.
- **Preuve :** pont simulé (`bridge.py`) : l'entité « Garde » créée dans l'Atelier est rattachée à la map Map Studio après l'envoi.

### 13 — Régions AGW : positions sans rapport avec la géographie
- **Où :** `refreshMarkers()` étire le rectangle des régions (≈ 1 700 blocs de large) **sur toute la map**, quelle que soit sa taille ou sa position (`MapBlueprint.worldX/worldZ` ne sont pas utilisés).
- **Effet :** les repères sont visibles (correctif MS-36), mais leur position ne veut rien dire. Un village de 64 blocs « contient » la capitale et les montagnes à 1 700 blocs de distance.
- **Preuve :** code.

### 14 — Le bouton Retour d'Android ferme tout Map Studio, même avec une fenêtre ouverte
- **Où :** `BackHandler` dans `MapEditorScreen.kt`. Il ne regarde pas si la fenêtre de confirmation, le Code Studio ou le Livre de rapport sont ouverts.
- **Effet :** le geste « retour » attendu (fermer la fenêtre) quitte l'éditeur.
- **Preuve :** code.

### 15 — Sauvegarde automatique illisible : remplacée sans copie de secours
- **Où :** `init()` → toast « illisible : nouvelle map », puis la première modification écrase le fichier. Côté Kotlin, `loadState` utilise `readText`, pas `SafeStore.readOrBackup` (qui garde une copie `.corrupt-…`, comme partout ailleurs dans l'app).
- **Preuve :** code.

---

## 4. 🟡 Mineurs

| N° | Où | Défaut |
|----|----|--------|
| 16 | `restoreState`, `importFile` | Annuler un import ou une map chargée ne rend ni les objets ni les structures du rapport (voir n° 5) |
| 17 | `importGlbBuffer` (clé ≠ id), Dupliquer | Pour un modèle venu de Character Studio, ou une copie, la clé du `.glb` ≠ l'id de l'entité. `atelierData` ne le retrouve pas (`hasObject(e.id)`) → cube doré si la sauvegarde automatique est perdue |
| 18 | `renderPalette` | 100 cases portent chacune une image d'atlas de **315 Ko** (data URL), et toute la palette est recréée à chaque toucher |
| 19 | boucle de rendu | Tout mouvement de doigt ou de souris **n'importe où** (panneaux compris) relance une image 3D : le rendu à la demande ne joue plus pendant qu'on fait défiler les réglages |
| 20 | outil Ligne | L'aperçu montre une **boîte** (`showPreview`), pas la ligne |
| 21 | Pinceau | Pas d'interpolation entre deux mouvements : trous dans un trait rapide |
| 22 | Pinceau, Gomme, Remplacer (rayon > 0) | Modifient aussi les blocs **cachés** par l'écrêtage Y |
| 23 | chargeur glTF | `KHR_texture_transform` accepté mais ignoré ; répétition de texture ignorée ; bandes et éventails ignorés ; couleurs de sommets ignorées |
| 24 | divers | Code mort : `mapPalette`, `countUnknown`, `world.set`, `getPickables`, `objIdCounter`, `reportPngs` (toujours vide) |
| 25 | page publiée / navigateur | Le bouton doré « Exporter vers SBh » de l'en-tête n'y fait qu'afficher un message. Le 1er téléchargement peut attendre jusqu'à 10 s la capacité `downloads`. `.mcaddon` et `.schem` arrivent dans un `.zip` |
| 26 | `#modeHint` | Le bandeau de mode est cliquable dans la vue : un toucher dans ce coin change de mode au lieu d'agir sur la map |
| 27 | `MapEditorScreen` (`projectId = "global"`) | Sans projet, le travail va dans `map_studio/global/`. Il devient invisible dès qu'un projet existe |
| 28 | Atelier, zone Maps | Renommer ou redimensionner une map Map Studio dans l'Atelier la désaccorde de son contenu réel. « Dupliquer » une telle map ne copie pas ses fonctions Bedrock |
| 29 | `pick` (DDA) | Caméra **à l'intérieur** d'un bloc : la face de départ est devinée (`nz = 1`), donc pose possiblement du mauvais côté |
| 30 | Code Studio | `oasis` sur relief : eau posée au niveau du centre, donc flottante sur les bords plus bas. `village` / `fortress` : hauteur lue au centre d'une maison, donc maison posée sur la cime d'un arbre si le centre en a un |

---

## 5. Points vérifiés et sans défaut trouvé

**Côté éditeur (JavaScript) :**
- découpage `.mcfunction` (≤ 9 000 commandes) et volume des `fill` (≤ 32 768) ;
- archive ZIP (CRC, UTF-8) ;
- lecture NBT gros et petit-boutiste (contrôles de longueur) ;
- tracé de ligne ;
- historique fin (Map) ;
- annulation du trait au 2ᵉ doigt ;
- écrêtage pendant le clic ;
- import `.schem` v2/v3, `.nbt`, `.mcstructure`, taille plafonnée.

**Côté Android (Kotlin) :**
- le `FileProvider` couvre `files/` (les `.mcaddon` de `map_exports` sont partageables) ;
- `exportMap` refuse un `mapId` d'un autre projet ;
- `functionFolder` est unique dans un même export.

---

## 6. Pour la suite (aucune réparation faite)

**Ordre suggéré :**
1. **N° 1** : écrire les blocs **par nom** (palette dans la sauvegarde) et relire les anciennes sauvegardes. À faire **avant** toute nouvelle modification de la palette.
2. **N° 2** : échapper le texte du Livre de rapport (`textContent`). Ne jamais insérer de HTML venant d'un fichier.
3. **N° 3** : plusieurs emplacements, ou une sauvegarde par map (clé = map de l'Atelier), et corriger le texte de la fenêtre.
4. **N° 4 et 5** : sauvegarder après un déplacement d'objet. Mettre nom, lien et objets dans l'instantané.
5. **N° 6 à 15**, puis les mineurs.

**Reproduire :** `tools/mapstudio_tests/analyse_1_8_60/`. `make_probe.py` fabrique la copie de sonde, puis `probe1.py` … `probe5.py`. Les tests de la réparation (`../full.py`, `../imp.py`, `../bridge.py`) restent valables.
