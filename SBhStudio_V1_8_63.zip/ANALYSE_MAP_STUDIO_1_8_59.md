# Analyse profonde — Map Studio (SBh Studio V1.8.59)

**Date :** 05/10/2026
**Périmètre :** uniquement Map Studio.
**Nature :** analyse seule. **Aucune ligne de code n'a été modifiée.**

**Fichiers analysés (lus en entier) :**

| Fichier | Rôle | Lignes |
|---------|------|--------|
| `app/src/main/assets/mapstudio.html` | Éditeur 3D complet (three.js r160) : blocs, outils, terrain, exports et imports, objets .glb, Code Studio, rapport | 3 253 |
| `app/src/main/java/com/sbh/studio/mapeditor/MapEditorScreen.kt` | Écran Android : WebView, pont JavaScript `SBhBridge`, chargement, injection des données de l'Atelier | 695 |
| `app/src/main/java/com/sbh/studio/mapeditor/PendingMapImport.kt` | Transfert d'un .glb depuis Character Studio | 25 |

**Fichiers lus en partie :**
- les appels de Map Studio dans `MainActivity.kt` et `WorkshopScreen.kt` ;
- le générateur `regions.json` dans `FoundationGenerators.kt` ;
- `js/OrbitControls.js`.

**Méthode :**
- Lecture ligne par ligne.
- Reproduction en Node.js de la logique Annuler/Rétablir, du tracé de ligne et du coût de reconstruction d'un chunk. Les scripts sont copiés depuis le fichier d'origine.
- Recherche des appelants et des lecteurs de chaque fichier et de chaque fonction du pont.

> Légende des niveaux
> - 🔴 **Critique** : la fonction ne marche pas ou bloque l'usage sur téléphone.
> - 🟠 **Majeur** : résultat faux, perte de travail ou fonction trompeuse.
> - 🟡 **Mineur** : défaut limité, confort, performance ou diagnostic.
>
> Preuve
> - **Prouvé** : reproduit en Node.js ou constaté dans le code sans ambiguïté.
> - **Probable** : dépend du comportement de la WebView ou de Minecraft, à confirmer sur le téléphone.

---

## 1. Résumé

| Niveau | Nombre |
|--------|--------|
| 🔴 Critique | 9 |
| 🟠 Majeur | 14 |
| 🟡 Mineur | 15 |
| **Total** | **38** |

**En une phrase.** Le moteur de rendu se charge correctement (confirmé sur ton Xiaomi), mais :
- **l'édition au doigt est inutilisable** : un seul doigt fait à la fois tourner la caméra et peindre ;
- **les grands outils figent l'éditeur** : chaque bloc posé reconstruit tout son chunk ;
- **deux outils de base sont faux** : Rétablir ne rétablit rien, la Ligne part de travers ;
- **la map n'arrive nulle part** : rien ne relie Map Studio à l'Atelier ni au `.mcaddon`, et aucun des 3 formats d'export n'est utilisable tel quel dans Minecraft Bedrock.

**Ce qui marche (vérifié dans le code) :**
- chargement WebGL avec trois tentatives de secours ;
- atlas de textures procédurales (100 blocs) ;
- maillage par chunks avec occlusion ambiante ;
- génération de terrain (6 types) ;
- Pinceau, Gomme, Remplacer, Boîte, Sphère et Pipette en petit ;
- export `.schem` Sponge v2 (format Java/WorldEdit) ;
- découpage `.mcfunction` à 9 000 commandes ;
- sauvegarde locale, avec une seule sauvegarde possible ;
- chargeur `.glb` simple ;
- Code Studio : analyse des commandes, aperçu vu du dessus, structures posées sur le terrain (correctifs 1.8.58).

---

## 2. 🔴 Critiques

### MS-01 — Un doigt fait tourner la caméra ET peint en même temps
**Où :**
- `mapstudio.html` l. 1291-1296 : `OrbitControls` est réglé seulement pour la souris (`mouseButtons.LEFT = null`) ;
- `OrbitControls.js` l. 102 : `touches = { ONE: ROTATE, TWO: DOLLY_PAN }` reste par défaut ;
- l. 2115-2150 : `pointerdown` agit dès que `ev.button === 0`, ce qui est vrai pour tout doigt.

**Effet :**
- **Un doigt** : la caméra tourne pendant que le Pinceau ou la Gomme tracent une traînée de blocs.
- **Deux doigts** (zoom) : chaque doigt pose ou efface aussi des blocs.
- **Outil Objets** : faire glisser un objet fait aussi tourner la vue.
- **Aucun mode** ne permet de seulement regarder ou de seulement construire. Les indications à l'écran parlent de « clic droit » et de « molette », qui n'existent pas sur téléphone.

**Preuve :** Prouvé (lecture du code et de la configuration d'OrbitControls r160).

### MS-02 — Chaque bloc posé reconstruit tout son chunk : les grands outils figent l'éditeur
**Où :** `setBlock` (l. 1515-1533) appelle `touchBlock` → `rebuildChunk` **pour chaque bloc**. Concerne :
- Boîte (l. 2213) ;
- Sphère (l. 2227) ;
- Ligne et Pinceau avec rayon (l. 2033) ;
- Remplacer (l. 2054) ;
- Inonder (l. 2074, jusqu'à 200 000 blocs).

**Mesure (Node.js, sur PC) :**
- une reconstruction de chunk de surface coûte **1,28 ms**, avant même la création de la géométrie WebGL ;
- une Boîte 10×10×10 (1 000 blocs) prend **environ 1,3 s** ;
- un seul mouvement de Pinceau en rayon 12 (environ 7 240 blocs) prend **environ 9 s** ;
- sur téléphone, il faut compter 3 à 10 fois plus.

**Conséquences :**
- Une Boîte qui couvre la map (196 000 blocs) ou « Inonder » sur de la pierre bloque la WebView plusieurs minutes, au risque qu'Android affiche « l'application ne répond pas ».
- Pendant ce temps, le diagnostic ne voit aucune erreur.

**Preuve :** Prouvé (mesure).

### MS-03 — « Rétablir » ne rétablit rien
**Où :** `applyUndo(stack, other)` (l. 1535-1565) remet toujours `e.from` (l'état **d'avant**), y compris quand on l'appelle pour Rétablir (l. 2816, et Ctrl+Y l. 2345).

**Reproduction Node.js :** poser un bloc → 7 ; Annuler → 0 ; **Rétablir → 0** (attendu : 7).

**Effet :** le bouton ↷ ne fait jamais rien. Il déplace seulement l'action d'une pile à l'autre.

**Preuve :** Prouvé.

### MS-04 — L'outil Ligne part de travers dès qu'elle n'est pas horizontale sur X
**Où :** `linePoints` (l. 2094-2110). Ce n'est pas un vrai tracé de Bresenham 3D : l'erreur est calculée seulement par rapport à `dx`.

**Reproduction Node.js :**

| Ligne demandée | Résultat obtenu |
|----------------|-----------------|
| (0,0,0) → (10,0,0) | ✅ correct |
| (0,0,0) → (0,10,0), verticale | ❌ arrive en **(0,10,−10)** : diagonale vers l'arrière |
| (0,5,0) → (0,5,10), le long de Z | ❌ arrive en **(0,−5,10)** : plonge sous le sol |

**Effet :** colonnes, poteaux et murs dans l'axe Z sont impossibles à tracer avec cet outil.

**Preuve :** Prouvé.

### MS-05 — Monde vide : impossible de poser le premier bloc
**Où :**
- `pick()` (l. 2016-2027) ne touche que les maillages de blocs (`getPickables`, l. 2000) ;
- il n'y a ni sol invisible ni plan de construction ;
- `pointerdown` s'arrête si rien n'est touché (l. 2127).

**Effet :** après « Nouveau » ou « Vider », Pinceau, Boîte, Ligne et Sphère ne peuvent rien poser. Il ne reste que « Tout remplir », la génération de terrain ou le Code Studio.

**Preuve :** Prouvé.

### MS-06 — « Exporter vers SBh » enregistre un fichier que rien ne relit
**Où :**
- `MapEditorScreen.exportMap` (l. 98-120) écrit `files/map_exports/map_<date>.json` et `map_last.json` ;
- **aucun fichier de l'app ne lit ce dossier** (vérifié par recherche dans tout le code) ;
- `MainActivity` (l. 465-467) affiche seulement « Map reçue (N car.) — prête pour l'atelier ».

**Effet :**
- La map n'apparaît pas dans l'Atelier (zone Maps) et n'entre jamais dans le `.mcaddon`.
- Le message « prête pour l'atelier » est faux.
- Le fichier est dans le stockage privé : le sélecteur de fichiers ne le voit pas, donc on ne peut même pas le réimporter.

**Preuve :** Prouvé.

### MS-07 — Les objets de Map Studio ne remontent jamais à l'Atelier
**Où :**
- la fonction JavaScript `syncEntitiesToAtelier()` (l. 3048) **n'est appelée nulle part** ;
- le pont Kotlin `syncEntities` (l. 255-320), corrigé en 1.8.57 pour viser le projet actif, n'est donc jamais déclenché.

**Effet :** les objets .glb placés dans Map Studio ne deviennent jamais des entités de l'Atelier.

**Preuve :** Prouvé.

### MS-08 — Les maps, portails et textures de l'Atelier sont injectés mais jamais utilisés
**Où :**
- `MapEditorScreen.onPageFinished` (l. 434-521) envoie maps, portails, textures et entités ;
- côté JavaScript, `onSbhAtelier` (l. 3024) **n'utilise que les entités** ;
- `maps`, `portals` et `textures` ne servent qu'au message « Atelier relié : N maps ».

**Effet :**
- on ne peut pas ouvrir une map de l'Atelier dans Map Studio ;
- on ne voit pas les portails ;
- on ne peut pas utiliser une texture du Studio Texture.

Le message « Atelier relié » laisse croire à un lien qui n'existe pas. Avec MS-06 et MS-07, **Map Studio est en pratique un îlot isolé.**

**Preuve :** Prouvé.

### MS-09 — Aucun des 3 formats d'export n'est utilisable tel quel dans Minecraft Bedrock sur téléphone
**Où :** l. 2431-2534.

| Format | Problème |
|--------|----------|
| `.schem` | Format **Java** (WorldEdit, Sponge v2). Bedrock ne le lit pas sans outil de conversion sur PC. |
| `.mcfunction` | Bedrock n'exécute une fonction que si elle est **dans un pack de comportement** (dossier `functions/` + manifest). Le fichier est livré seul, sans pack et sans mode d'emploi. Les identifiants de blocs sont ceux de **Java** (voir MS-21). |
| `.json` | Format interne de Map Studio, inconnu de Minecraft. |

**Effet :** la boucle « je construis → je joue » n'est jamais fermée. C'est le même schéma que la source commune trouvée dans l'enquête 1.8.57.

**Preuve :** Prouvé pour le code. La règle des fonctions Bedrock est une règle du jeu, à vérifier par le test n° 9 du plan.

---

## 3. 🟠 Majeurs

### MS-10 — Annuler après « Redimensionner » abîme la map
- **Où :** `btnResize` (l. 2749-2764) ne vide pas l'historique. Les actions enregistrées gardent des positions calculées avec les **anciennes** dimensions.
- **Effet :** Annuler écrit des blocs aux mauvais endroits.
- **Preuve :** Prouvé. Le Code Studio, lui, vide bien l'historique sur `map.create` ; le redimensionnement ne le fait pas.

### MS-11 — « Vider », « Tout remplir » et « Générer le terrain » ne s'annulent pas et ne demandent aucune confirmation
- **Où :**
  - `btnClear` (l. 2766-2775) efface aussi tout l'historique ;
  - `btnFill` (l. 2777-2783) et `generateTerrain` (l. 1605-1739) écrivent directement dans `world.data` sans passer par `setBlock`, donc l'action enregistrée est vide.
- **Effet :**
  - un appui malheureux détruit la map, sans retour possible ;
  - après une génération, Annuler revient sur l'action **précédente**, alors que l'utilisateur pense annuler la génération.
- **Preuve :** Prouvé.

### MS-12 — Générer le terrain laisse l'ancien contenu en l'air
- **Où :** `generateTerrain` remplit chaque colonne de 0 à la hauteur `h` (plus l'eau et les arbres) **sans vider ce qui est au-dessus**.
- **Effet :** une nouvelle génération plus basse laisse flotter les anciennes collines, arbres et constructions.
- **Preuve :** Prouvé.

### MS-13 — Quitter Map Studio perd la map sans prévenir
- **Où :**
  - `BackHandler { onBack() }` (Kotlin l. 595) et le bouton « ← Retour » (l. 2847) ferment tout de suite ;
  - la WebView est détruite (l. 571-580) ;
  - il n'y a pas de sauvegarde automatique : la sauvegarde ne se fait qu'avec 💾, dans un seul emplacement `mcms_save` commun à tous les projets (l. 2820-2833).
- **Effet :** un retour arrière fait perdre tout le travail non sauvegardé. Deux projets se partagent la même sauvegarde et s'écrasent.
- **Preuve :** Prouvé.

### MS-14 — Retour depuis Map Studio : on revient toujours à l'Accueil
- **Où :** `MainActivity` l. 464 : `onBack = { screen = Screen.Home }`, même quand Map Studio a été ouvert depuis l'Atelier ou Character Studio (« Envoyer vers Map Studio »).
- **Effet :** l'utilisateur perd sa place dans l'Atelier.
- **Preuve :** Prouvé.

### MS-15 — Les objets .glb disparaissent à la sauvegarde
- **Où :** `restoreSceneObjects` (l. 2680-2697) recrée chaque objet sous forme de **cube doré**, car le fichier .glb n'est pas sauvegardé. Les entités venant de l'Atelier arrivent aussi en cubes dorés.
- **Effet :** après Charger, ou à la réouverture, les personnages envoyés depuis Character Studio sont devenus des cubes.
- **Preuve :** Prouvé. L'indication de la l. 308 le reconnaît : « session uniquement ».

### MS-16 — Import `.schem` : la plupart des blocs deviennent de l'air
- **Où :** `importSchem` (l. 2605-2608) cherche le nom exact du bloc. Les vrais fichiers WorldEdit écrivent les noms **avec leurs états**, par exemple `minecraft:oak_log[axis=y]` ou `minecraft:grass_block[snowy=false]`.
- **Effet :**
  - tous les blocs à état (bûches, herbe, feuilles, escaliers, dalles…) deviennent de l'air, sans avertissement, puis « Import réussi ✓ » s'affiche ;
  - les blocs inconnus (hors des 100 de la palette) deviennent aussi de l'air, sans être signalés.
- **Preuve :** Prouvé pour le code. Le format des noms est celui de Sponge.

### MS-17 — Import : schémas récents refusés, `.nbt` annoncé mais non géré, aucune limite de taille
- **Où :** l. 2290 (`accept=".schem,.json,.nbt"`) et l. 2595-2616.
- **Effets :**
  - **Schémas Sponge v3** (WorldEdit récent) : les blocs sont rangés sous `Blocks.Data`, pas sous `BlockData`. L'import échoue avec un message incompréhensible (`Cannot read properties of undefined`).
  - **Fichiers `.nbt`** (structures Java) : proposés dans le sélecteur, mais envoyés au lecteur `.schem` → même erreur.
  - **Taille** : `Width × Height × Length` n'est pas limité, contrairement à Redimensionner (256 max). Un gros schéma demande une allocation énorme, au risque de faire planter la WebView.
- **Preuve :** v3 = probable (dépend de la version de WorldEdit qui a créé le fichier). `.nbt` et taille = prouvés.

### MS-18 — L'écrêtage en hauteur (Y min/max) ne s'applique pas aux clics
- **Où :** `updateClip` (l. 2728) cache les blocs à l'affichage seulement. `pick` (l. 2016) touche aussi les blocs cachés.
- **Effet :** quand on baisse « Y max » pour travailler à l'intérieur d'un bâtiment, les clics touchent le toit invisible.
- **Preuve :** Prouvé.

### MS-19 — En paysage, les outils et la palette disparaissent
- **Où :** CSS l. 184-195 : en paysage, `#left{display:none}`.
- **Effet :** en tournant le téléphone, on ne peut plus changer d'outil ni de bloc. Les touches 1 à 9 n'existent pas sur un téléphone.
- **Preuve :** Prouvé.

### MS-20 — Code Studio : blocs inconnus remplacés en silence par de la pierre, maisons pleines, forteresse sans entrée
- **Où :** l. 3120-3123 et 3166-3179.
- **Effets :**
  - **Bloc inconnu** : `codeBlockId` renvoie de la pierre sans erreur. Une faute de frappe (`sandd`) donne de la pierre.
  - **Village** : utilise `oak_door`, et **la forteresse** utilise `deepslate_bricks`. Aucun des deux n'existe dans la palette, donc portes et tours deviennent de la pierre.
  - **Maisons** : `codeFill` les remplit en blocs pleins, sans intérieur. La « porte » est un bloc de pierre posé dans le mur.
  - **Entrée de la forteresse** (l. 3178) : remplie de pierre au lieu d'être creusée.
  - **Forteresse sur relief** : la hauteur du sol n'est lue qu'au centre (l. 3175), donc les murs flottent ou s'enterrent sur un terrain en pente.
- **Preuve :** Prouvé.

### MS-21 — Identifiants Java dans `.mcfunction`, et un identifiant qui n'existe nulle part
- **Où :** registre des blocs (l. 882-1001), utilisé tel quel par `.mcfunction` (l. 2490) et `.schem` (l. 2441).
- **Effets :**
  - `minecraft:obsidian_p` (« Obsidienne pleureuse », l. 989) **n'existe ni en Java ni en Bedrock** (le vrai nom est `crying_obsidian`). Ce bloc rend invalide la commande dans les deux formats.
  - Plusieurs noms diffèrent en Bedrock, par exemple :

    | Java (utilisé) | Bedrock |
    |----------------|---------|
    | `snow_block` | `snow` |
    | `terracotta` | `hardened_clay` |
    | `slime_block` | `slime` |
    | `end_stone_bricks` | `end_bricks` |
    | `nether_bricks` | `nether_brick` |
    | `red_nether_bricks` | `red_nether_brick` |

  - D'autres noms restent à vérifier dans le jeu, selon la version de Bedrock.
- **Effet :** la fonction s'arrête ou ignore ces lignes dans Bedrock.
- **Preuve :** Prouvé pour `obsidian_p`. Probable pour la table : les noms Bedrock changent d'une version à l'autre.

### MS-22 — `.mcfunction` en plusieurs parties : une fenêtre de partage par fichier
- **Où :** `exportMcFunction` (l. 2503-2511) appelle `download` pour chaque partie. Côté Kotlin, `saveFile` (l. 213-246) ouvre **un sélecteur de partage à chaque fichier**.
- **Effet :** une map de 30 000 commandes ouvre 4 fenêtres de partage les unes sur les autres.
- **Preuve :** Prouvé.

### MS-23 — Code Studio : « terrain.fill » puis « terrain.height » fige l'éditeur
- **Où :** dans `setBlock` (l. 1527), quand un même bloc est réécrit dans la même action, sa position est cherchée avec `curEdit.idx.indexOf(i)`, qui parcourt toute la liste. Le coût augmente donc beaucoup avec la taille.
- **Mesure (Node.js, sur PC) :** sur une map 64×48×64, `terrain.fill stone` puis `terrain.height 18 sand` réécrit 77 824 blocs en **3,1 s sur PC**, soit environ 15 à 30 s sur téléphone, sans indicateur de progression.
- **Preuve :** Prouvé (mesure).

---

## 4. 🟡 Mineurs

| N° | Où | Défaut | Effet |
|----|----|--------|-------|
| MS-24 | l. 1664-1676 | Les filons de minerai écrits en x+1 et y+1 sont **réécrits juste après** par la boucle (pierre). | Les minerais sont toujours des blocs isolés, jamais des filons. |
| MS-25 | l. 1042, 1045 | `reportStructures` n'est jamais vidé (Nouveau, Vider, `map.create`). | Le Livre de rapport liste des structures qui n'existent plus. |
| MS-26 | l. 3133-3138 | `codeFill` ne limite pas X et Z (Y oui). | `fill 0 0 0 100000 …` parcourt 100 000 colonnes hors du monde, donc gel. |
| MS-27 | l. 1228, 1264 | `preferLowGpu` est vrai sur **tous** les Android. | Le message « mode compatibilité GPU » s'affiche toujours, même sans problème. C'est ce que tu as vu. |
| MS-28 | l. 1278 / 1469 | Le plafond de densité de pixels (1,25 sur mobile) est remplacé par 1,75 au premier redimensionnement. | Charge graphique plus forte que prévu sur téléphone. |
| MS-29 | l. 3057-3065 + Kotlin l. 128-131 | `ready()` est envoyé **avant** la génération du terrain, et l'écran de chargement Android se ferme à ce moment. | Écran noir quelques instants avant que le monde apparaisse. C'est probablement le noir de tes captures. |
| MS-30 | Kotlin l. 541-569 | `DisposableEffect` met l'étape à 4, puis `LaunchedEffect` la remet à 1. | La barre de chargement recule (cosmétique). |
| MS-31 | l. 2738-2742 | Le rendu tourne en continu, même quand rien ne bouge. | Batterie et chauffe du téléphone. |
| MS-32 | l. 2875-2876 | « Map exportée vers SBh Studio ✓ » s'affiche sans attendre le résultat de l'enregistrement, en plus du message Kotlin. | Succès annoncé avant vérification (même schéma que la source commune 1.8.57). |
| MS-33 | Kotlin l. 134-156 | Le .glb envoyé par Character Studio (jusqu'à 25 Mo) est lu et converti en base64 **sur le thread principal**, puis passé comme une seule chaîne JavaScript d'environ 33 Mo. | Risque de blocage ou de manque de mémoire avec les gros modèles. |
| MS-34 | l. 1916-1933, 1829 | `extensionsRequired` n'est pas vérifié (Draco, meshopt). L'objet est toujours ramené à 2 blocs de haut. Les adresses blob des textures ne sont jamais libérées. | Erreur incompréhensible sur un .glb compressé. Un bâtiment importé est miniaturisé. Petite fuite de mémoire. |
| MS-35 | Kotlin l. 438-441, 484-497 | Les maps, portails et entités injectés sont ceux de **tous les projets**, sans filtre sur le projet actif. | Des entités d'un autre projet apparaissent en cubes dorés. |
| MS-36 | `WorkshopScreen` l. 463-467 + l. 3080-3084 | Le fichier des régions AGW est **unique pour toute l'app**, et les régions sont placées par une échelle fixe (÷20, y÷4). | Certains repères tombent hors de la map 64×64 (« Montagnes Vertes », « Territoire Ghurab »), d'autres flottent ou sont enterrés. Une sonde vérifie toutes les 1,5 s, sans jamais s'arrêter. |
| MS-37 | l. 2340-2349 | Les raccourcis clavier ne sont pas ignorés dans l'éditeur de code (`TEXTAREA`). | Avec un clavier physique, taper un chiffre dans le code change aussi d'outil, et Ctrl+Z annule la map au lieu du texte. |
| MS-38 | Kotlin l. 103-106 + l. 398 | `map_exports/` grossit à chaque export, sans jamais être nettoyé. L'écoute des erreurs JavaScript reçoit l'événement au lieu de l'erreur, donc la pile d'appels est perdue (le nom devient toujours `Error`). | Stockage qui grossit, rapports d'erreur moins précis. |

---

## 5. Points à confirmer sur le téléphone

Ce qui relève du comportement de la WebView, à vérifier sur ton Xiaomi avant toute réparation :

| Test | Ce qu'on vérifie | Lié à |
|------|------------------|-------|
| Ouvrir Map Studio, glisser un doigt sur le terrain avec le Pinceau | La caméra tourne-t-elle **et** des blocs apparaissent-ils ? | MS-01 |
| Outil Boîte : un grand rectangle (≈ 20×10×20) | Durée du gel | MS-02 |
| Poser un bloc → ↶ → ↷ | Le bloc revient-il ? (attendu d'après l'analyse : non) | MS-03 |
| Outil Ligne : tracer une colonne verticale | Où arrive la ligne ? | MS-04 |
| Nouveau → essayer de poser un bloc | Rien ne se pose ? | MS-05 |
| Exporter vers SBh → ouvrir l'Atelier, zone Maps | La map n'y est pas ? | MS-06 |
| Bouton « ← Retour » de la page | Revient-il bien à l'app ? (Le code attache une propriété `isAndroid` à l'objet du pont Android. Si la WebView refuse, le bouton appelle `history.back()` et ne fait rien.) | à vérifier |
| Tourner le téléphone en paysage | Outils et palette absents ? | MS-19 |

---

## 6. Lien avec la source commune (enquête 1.8.57)

Les 38 points se rangent sous les mêmes causes que l'enquête :

1. **La boucle n'est jamais fermée.** Map Studio exporte vers des fichiers que personne ne relit (MS-06), vers des formats que Bedrock n'accepte pas tels quels (MS-09), ou ne synchronise pas du tout (MS-07). Les données de l'Atelier arrivent mais ne servent à rien (MS-08).
2. **« Réussi » annoncé avant vérification.** C'est le cas de « Import réussi ✓ » avec des blocs perdus (MS-16), de « Map exportée ✓ » (MS-32) et de « prête pour l'atelier » (MS-06).
3. **Plusieurs façons d'écrire la même règle.** Il en existe trois pour écrire un bloc :
   - `setBlock` : reconstruit le chunk à chaque bloc et enregistre l'action dans l'historique ;
   - écriture directe dans `world.data` : n'enregistre rien dans l'historique ;
   - `codeWrite` : enregistre dans l'historique sans reconstruire le chunk.

   C'est la cause de MS-02, MS-11 et MS-23.
4. **Les entrées externes ne sont jamais confrontées au réel.** C'est le cas des noms de blocs avec état (MS-16), des formats v3 et `.nbt` (MS-17), des identifiants Bedrock (MS-21) et des extensions glTF (MS-34).
5. **Pensé pour PC, pas pour le doigt.** C'est la cause de MS-01, MS-05, MS-19 et des indications « clic droit / molette ».

---

## 7. Ce qui reste à faire (pour la personne qui reprendra)

Aucune réparation n'a été faite. Ordre suggéré, du plus bloquant au moins bloquant :

1. **Rendre Map Studio utilisable au doigt** : MS-01, MS-05, MS-19.
2. **Une seule façon d'écrire un bloc**, avec reconstruction groupée des chunks à la fin de l'action et historique indexé : MS-02, MS-11, MS-23.
3. **Corriger Rétablir et la Ligne** : MS-03, MS-04. Ce sont deux corrections courtes, testables en Node.js avec les scripts de cette analyse.
4. **Brancher Map Studio sur l'Atelier et l'export** : MS-06, MS-07, MS-08, MS-35. Il faut d'abord décider de la forme : la map devient une `MapBlueprint` du projet et/ou une `.mcstructure` dans le pack.
5. **Rendre l'export jouable dans Bedrock** : MS-09, MS-21, MS-22. Il faut produire un pack de comportement complet, avec `functions/` et des identifiants Bedrock, ou une `.mcstructure`. L'app sait déjà écrire ce format pour l'Atelier.
6. **Protéger le travail** : MS-10, MS-12, MS-13, MS-14, MS-15. Sauvegarde par projet, confirmation avant de quitter ou de détruire.
7. **Les autres points** : imports, Code Studio, mineurs.

**Scripts de reproduction utilisés** (copiés tels quels depuis `mapstudio.html`) :
- `line.js` : tracé de ligne ;
- `undo.js` : Annuler/Rétablir ;
- `perf.js` : coût de `indexOf` ;
- `mesh.js` : coût de `buildChunkGeom`.

Ils se trouvent dans le dossier de travail de cette session et peuvent être recréés à partir des extraits cités.
