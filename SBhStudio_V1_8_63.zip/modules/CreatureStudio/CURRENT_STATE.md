# CURRENT STATE — CreatureStudio

**Dernière mise à jour : 2026-10-06**
**Étapes 1 à 11 TERMINÉES** (+ 3 bis tactile, 4 bis symétrie/Z, Soldat standard, HIBOU). **Dossier de reprise : `HANDOVER.md`.**
**Prochaine étape : aucune dans le plan.** À faire : validation de l'export dans Minecraft, essai de l'éditeur sur téléphone / WebView hôte, `pip install .` réel (voir HANDOVER §7).

## Dernier travail (Étape 11 — package d'intégration)
Exporteur Bedrock porté en JS dans l'éditeur (bouton ⬇ Bedrock, parité Python↔JS testée), API hôte `window.CreatureStudio` + messages `creaturestudio:*` + pont Android/React Native/iframe, paquet Python `creaturestudio` (`python -m creaturestudio`), `pyproject.toml`, `docs/INTEGRATION.md`, `HANDOVER.md`. Rapport : `reports/11_STEP_11.md`. 159 tests OK.

## Dernier travail (Étape 10 — export Minecraft Bedrock)
`core/bedrock_export.py` + CLI `tools/export_bedrock.py` : génère RP (géométrie 1.12.0, texture atlas PNG, entité client, render controller, animations, contrôleur d'animation), BP (entité avec caractéristiques et objectifs approchés), manifests, `.mcaddon` et `EXPORT_REPORT.json`. `tools/render_bedrock_preview.py` redessine l'export depuis ses fichiers (contrôle visuel). Doc complète, conventions, hypothèses et checklist de test en jeu : **`docs/BEDROCK_EXPORT.md`**. Nouveaux diagnostics D050 (forme → boîte), D051 (cisaillement : position fausse), D052 (lueur/transparence). Exemple : `docs/exports_demo/le_chef.mcaddon`. Rapport : `reports/10_STEP_10.md`. 152 tests OK.
**À SAVOIR : jamais testé dans Minecraft.** Le premier travail de la personne qui reprend est la checklist de `docs/BEDROCK_EXPORT.md`.

## Travail précédent (Étape 9 — diagnostics)
`core/diagnostics.py` (`diagnose`, 23 codes D001–D041, 3 gravités), miroir JS dans l'éditeur, panneau **🩺 Diagnostic** cliquable (sélectionne la partie / règle / animation concernée), CLI `tools/diagnose_creature.py [--strict]`. Spéc : `core/format.md` §14. Les diagnostics ont révélé des défauts réels dans les personnages HIBOU, corrigés : noms en double (Emblème ×3, Poche de ceinture), matières orphelines. Rapport : `reports/09_STEP_9.md`. Tests : `tests/test_diagnostics.py` (7), total 134.

## Travail précédent (Étape 8 — sons, effets, capacités spéciales)
Nouvelles listes racine `sounds[]` et `effects[]`, nouvelles actions `playSound`, `effect`, `ability` (9 capacités : feu, glace, foudre, poison, explosion, téléportation, bouclier, invisibilité, soin, avec force/durée/recharge/portée). Spéc : `core/format.md` §13 ; ops : `core/operations.md`. Éditeur : sections 🔊 Sons / ✨ Effets sous les règles, blocs ALORS correspondants, le simulateur montre ondes d'effet, bouclier, poison, ralentissement, invisibilité et dernier son. Démo : le Chef (Bouclier, Se soigner, Cri, Aura, Étincelles) et HIPPO III (Lancer une grenade). Rapport : `reports/08_STEP_8.md`. 127 tests OK (`tests/test_step8.py`).
Modifiés : `tools/validate_creature.py`, `schema/creature-project.schema.json`, `core/creature_model.py`, `editor/creature_editor.html`, `examples/hibou_kit.py`, `examples/hibou_*.creature.json`, `core/format.md`, `core/operations.md`, `MASTER_PLAN.md`, `CHANGELOG.md`, `README.md`.

## Travail précédent (Personnages HIBOU — Chef + HIPPO I/II/III)
4 personnages intégrés (menu **🦉 HIBOU…** dans l'éditeur), kit de mouvement commun, accords de noms étendus, 116 tests OK. Fiche : `docs/CHARACTER_hibou.md` ; rapport : `reports/08_HIBOU.md`. Régénérer : `python examples/build_hibou.py && python tools/embed_example.py`.

## Travail précédent (Étape 7 — comportements ; + Soldat standard)
Caractéristiques (vie, dégâts, armure, vitesse, saut, détection, intelligence) et règles SI/ALORS par priorité de liste, panneau et simulateur d'aperçu dans l'éditeur (l'animation de la règle active se joue en 3D).
Personnage complet **Soldat standard** (38 parties, 17 os, texture de keffieh, 6 animations, 2 poses, 5 règles) : `examples/build_soldier.py`, bouton **🎖 Soldat**, fiche `docs/CHARACTER_soldat_standard.md`, aperçu `docs/preview_soldat_standard.png`.
Rapport complet : `reports/07_STEP_7.md`.
Créés : `tests/test_behavior.py`, `tests/test_soldier.py`, `examples/build_soldier.py`, `examples/soldat_standard.creature.json`, `tools/render_preview.py`, `tools/embed_example.py`, `docs/CHARACTER_soldat_standard.md`, `docs/preview_soldat_standard.png`, `reports/07_STEP_7.md`.
Modifiés : `core/creature_model.py`, `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`, `tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`, `tests/test_symmetry.py`, `core/format.md`, `core/operations.md`, `CHANGELOG.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`, `CURRENT_STATE.md`.

## Travail précédent (Étape 6 — animation, poses, timeline)
Poses nommées, animations à images clés (interpolation linéaire, boucle), timeline dans l'éditeur (lecture, ＋/− image clé, durée, boucle),
et 9 animations de base générées d'après les noms des os (Repos, Marche, Course, Saut, Attaque, Dégâts, Mort, Nage, Vol). Rapport complet : `reports/06_STEP_6.md`.
Créés : `tests/test_animation.py`, `examples/build_animation_demo.py`, `examples/demo_animated.creature.json`, `reports/06_STEP_6.md`.
Modifiés : `core/creature_model.py`, `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`, `tests/test_editor_core.py`,
`tests/test_editor_ui_smoke.py`, `core/format.md`, `core/operations.md`, `CHANGELOG.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`, `CURRENT_STATE.md`.

## Travail précédent (Étape 5 — matériaux, textures, apparence)
Matières (couleur, opacité, lueur, rugosité stockée), textures pixel-art à palette, **peinture directe sur le modèle** (mode 🖌 Peindre : pinceau, gomme, remplissage),
UV définies pour les 8 formes. Rapport complet : `reports/05_STEP_5.md`.
Créés : `tests/test_appearance.py`, `examples/build_appearance_demo.py`, `examples/demo_appearance.creature.json`, `reports/05_STEP_5.md`.
Modifiés : `core/creature_model.py`, `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`, `tests/test_editor_core.py`,
`tests/test_editor_ui_smoke.py`, `core/format.md`, `core/operations.md`, `CHANGELOG.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`, `CURRENT_STATE.md`.

## Travail précédent (Étape 4 bis — symétrie et rotation Z à deux doigts)
Symétrie (bouton Sym X/Y/Z, ⇋ Miroir, jumelle automatique à l'ajout, glisser et pose en miroir) et axe Z de la pose à deux doigts. Rapport : `reports/04b_STEP_4_symmetry_z.md`.
Créés : `tests/test_symmetry.py`, `examples/build_symmetric_demo.py`, `examples/demo_symmetric.creature.json`, `reports/04b_STEP_4_symmetry_z.md`.
Modifiés : `core/creature_model.py`, `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`, `tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`, `core/format.md`, `core/operations.md`, `CHANGELOG.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`.

## Travail précédent (Étape 4 — squelette et rig)
Pivots (point d'articulation par partie), os (un par partie, avec limites de pose), squelette affiché dans l'éditeur, mode
**🦴 Pose** pour tester les articulations (pose temporaire, non enregistrée). Rapport complet : `reports/04_STEP_4.md`.

## Fichiers ajoutés/modifiés à l'Étape 4
Créés : `tests/test_rig.py`, `examples/build_rigged_demo.py`, `examples/demo_rigged_quadruped.creature.json`, `reports/04_STEP_4.md`.
Modifiés : `core/creature_model.py`, `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`,
`tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`, `core/format.md`, `core/operations.md`, `MASTER_PLAN.md`, `CHANGELOG.md`,
`README.md`, `docs/VISION.md`, `CURRENT_STATE.md`. Le reste est inchangé.

## Vérification
    python -m unittest discover -s tests -v              # 108 tests OK (11 nécessitent Node)
    python tools/validate_creature.py examples/soldat_standard.creature.json
    python examples/build_soldier.py && python tools/embed_example.py     # régénère le soldat puis le bouton 🎖
    python tools/render_preview.py examples/soldat_standard.creature.json docs/preview_soldat_standard.png     # (Node + Pillow + numpy)
    # puis ouvrir editor/creature_editor.html : 🎖 Soldat, timeline, Peindre, ▶ Tester — NON testé sur téléphone

## À faire en priorité
1. Tester l'éditeur sur téléphone (toutes les modes, timeline, panneau Comportement, simulateur, 🎖 Soldat) et corriger.
2. Étape 8 : capacités spéciales, sons, particules (voir `reports/07_STEP_7.md` §9).
3. Décisions ouvertes : armes/accessoires et variantes du soldat, séquences d'actions avec attente, conteneur `.sbhcreature`, import de textures Minecraft, disposition UV Bedrock, courbes d'animation, rôles d'os explicites.

## Dettes connues
Générateur d'animations de base mal adapté aux os imbriqués (soldat : animations écrites à la main) ; actions simultanées seulement ; simulation 2D sans obstacles ni saut, vue 3D qui ne déplace pas la créature ;
interpolation linéaire seulement ; décalage de position des poses non éditable au doigt ; animations de base reconnues par les noms (JS seulement) ; pas de copier/coller d'images clés ni de vitesse de lecture ;
rugosité non rendue ; pas d'import PNG ni de motifs ; matière partagée = texture partagée (non retournée sur les jumelles) ; pas de symétrie du pinceau ; symétrie à un seul axe ;
pivot réglable par nombres et présets Y ; limites d'os appliquées seulement dans le mode Pose, les presets et les animations du soldat (vérifiées par test) ; pas de poignées 3D ni de sculpture ; paramètres de forme non éditables dans l'interface ;
rendu par tri de faces ; logique dupliquée Python/JS (tests de parité) ; `parameters` non validés par forme ; `reparent` garde la transformation locale ; échelle 0 interdite par le modèle mais pas par le validateur.

---
---
# Historique — état à la fin de l'Étape 2 (conservé pour référence)

**Dernière mise à jour : 2026-09-29**
**Étape active : Étape 2 — TERMINÉE (côté modèle et logique, sans interface)**
**Prochaine étape : Étape 3 — Éditeur 3D et prévisualisation interactive**

## Dernier travail effectué (Étape 2)

Le modèle est maintenant manipulable par code : créer, supprimer, dupliquer, déplacer, tourner, redimensionner,
renommer, changer de forme, changer de parent et réordonner des parties, plus la gestion des sockets. Chaque
opération est transactionnelle (revalidée, annulée si invalide). 22 tests automatiques passent.
Détails complets : `reports/02_STEP_2.md`.

## Fichiers (état exact)

| Fichier | Statut Étape 2 |
|---|---|
| `core/creature_model.py` | CRÉÉ — classe `CreatureProject` |
| `core/operations.md` | CRÉÉ — règles et API des opérations |
| `tests/test_creature_model.py` | CRÉÉ — 22 tests |
| `examples/build_demo.py` | CRÉÉ — construit un dragon depuis zéro |
| `examples/demo_dragon.creature.json` | CRÉÉ — généré par la démo (valide) |
| `docs/VISION.md` | CRÉÉ — vision produit de l'utilisateur, avec correspondance aux étapes |
| `reports/02_STEP_2.md` | CRÉÉ — rapport complet |
| `tools/validate_creature.py` | MODIFIÉ — logique extraite dans `check(d)` ; sortie CLI inchangée ; formes `pyramid`, `plane` ajoutées |
| `schema/creature-project.schema.json` | MODIFIÉ — enum des formes : + `pyramid`, `plane` |
| `core/format.md` | MODIFIÉ — formes ajoutées, renvoi vers operations.md |
| `MASTER_PLAN.md`, `CHANGELOG.md`, `README.md`, `CURRENT_STATE.md` | MIS À JOUR |
| `examples/test_creature.creature.json` | INCHANGÉ |
| `validation_result.txt` | INCHANGÉ (résultat de l'Étape 1, non régénéré) |
| `reports/01_STEP_1.md` | INCHANGÉ |

## Vérification (à refaire pour reprendre)

    python -m unittest discover -s tests -v          # 22 tests OK
    python tools/validate_creature.py examples/test_creature.creature.json
    python tools/validate_creature.py examples/demo_dragon.creature.json
    python examples/build_demo.py

## Ce qui reste à faire

Étapes 3 à 11 du MASTER_PLAN, plus les dettes de l'Étape 2 :

- pas d'annuler/rétablir ; pas de symétrie automatique (voir `docs/VISION.md`) ;
- `parameters` non validés par forme (ex. `sphere` sans `radius` est accepté) ;
- `reparent` conserve la transformation locale (pas de conservation de la position monde) ;
- le validateur n'interdit pas l'échelle 0 (seul le modèle le fait) ;
- le schéma JSON n'est pas exécuté par une bibliothèque (le validateur Python reste la référence) ;
- décisions ouvertes avec l'utilisateur : voir `docs/VISION.md` § « Décisions à trancher ».

## Point exact de reprise

**Prochaine tâche : Étape 3 — Éditeur 3D et prévisualisation interactive.** Partir de `core/creature_model.py`
(toute modification du modèle passe par ses opérations). Ne pas supprimer `id`, `parentId` ni le système de
transformation. Le choix de la plateforme de rendu (Android/Kotlin, Godot, WebGL…) n'est PAS encore fait :
à demander à l'utilisateur avant de commencer. Si le rendu est hors Python, porter la logique de
`core/operations.md` en respectant les mêmes règles.
