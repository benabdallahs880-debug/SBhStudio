# CreatureStudio — Opérations d'édition (Étape 2)

Code : `core/creature_model.py` (classe `CreatureProject`, Python 3, aucune dépendance).
Tests : `tests/test_creature_model.py`. Démo : `examples/build_demo.py`.

## Règles générales

1. **Transactionnel** : chaque opération est appliquée puis revalidée avec `tools/validate_creature.py`
   (`check`). Si le résultat est invalide, le projet est restauré à l'identique et `CreatureError` est levée.
2. **Ids stables** : un id existant n'est jamais modifié. Les nouveaux ids sont générés (`part_<nom>`,
   `socket_<nom>`, suffixe `_2`, `_3`… si déjà pris). Les références utilisent les ids, jamais l'index.
3. **Transformations locales** (relatives au parent), rotation en **degrés**. Échelle à 0 interdite
   (règle du modèle, pas encore du validateur).
4. **La racine** ne peut être ni supprimée, ni dupliquée, ni re-parentée.
5. `project.updatedAt` est mis à jour à chaque opération réussie.

## API

| Opération | Effet |
|---|---|
| `CreatureProject.new(nom, root_name, root_shape)` | crée une créature avec une seule racine |
| `load(path)` / `save(path)` | lecture / écriture JSON (revalidées) |
| `add_part(name, shape, parent_id=None, position, rotation, scale, parameters, material_id)` | ajoute une partie (sous la racine par défaut), retourne l'id |
| `remove_part(id, children="delete"\|"reparent")` | supprime ; `delete` retire le sous-arbre, `reparent` remonte les enfants au parent. Supprime aussi les sockets des parties retirées. Retourne les ids retirés |
| `duplicate_part(id, with_children=True, offset)` | clone le sous-arbre sous le même parent, avec nouveaux ids, sockets copiés, nom « X (copie) » |
| `set_transform(id, position, rotation, scale)` | remplace tout ou partie de la transformation |
| `translate(id, delta)` / `rotate(id, delta_degrees)` / `scale_by(id, facteur)` | modifications relatives |
| `rename_part(id, name)` | renomme (l'id ne change pas) |
| `set_shape(id, shape, parameters=None)` | change la primitive (paramètres par défaut si omis) |
| `reparent(id, new_parent_id)` | change le parent ; cycles refusés |
| `reorder(id, index)` | change l'ordre parmi les frères ; n'affecte pas la hiérarchie |
| `add_socket(part_id, name, …)` / `remove_socket(id)` | gestion des points d'attache |
| `get_part`, `children`, `descendants`, `tree_text` | requêtes |

## Pivots et os (Étape 4)

| Opération | Effet |
|---|---|
| `set_pivot(id, pivot, keep_in_place=True)` | point d'articulation ; `keep_in_place` corrige `position` pour que la forme ne bouge pas |
| `pivot_preset(id, 'top'\|'center'\|'bottom')` | pivot en haut / centre / bas de la primitive (axe Y) : hanche, épaule, cou… |
| `local_point(id, point)` | position d'un point du maillage dans l'espace du parent (convention du pivot) |
| `add_bone(part_id, name=None, limits=None)` / `remove_bone(bone_id)` | un os par partie |
| `auto_rig()` | crée un os pour chaque partie qui n'en a pas |
| `set_bone_limits(bone_id, limits)` | limites de pose en degrés ; `None` efface |
| `bone_of_part`, `get_bone`, `bone_parent` | requêtes (`bone_parent` est déduit de la hiérarchie) |

`remove_part` supprime aussi les os des parties retirées (résultat : clé `removed_bones`) ; `duplicate_part` copie les os
(nouveaux ids, limites conservées) et le pivot. `skeleton.enabled` est recalculé à chaque opération.

## Symétrie (Étape 4 bis)

| Opération | Effet |
|---|---|
| `mirror_part(id, axis='x')` | crée la copie miroir du sous-arbre (enfants, sockets, os) et lie chaque paire ; noms gauche↔droite / left↔right échangés, sinon « (miroir) » |
| `add_part(..., symmetric_axis='x')` | ajoute la partie ET sa jumelle dans la même opération ; sous une partie elle-même liée, la jumelle va sous la jumelle du parent |
| `set_transform / translate / rotate / scale_by / set_pivot / set_shape (..., symmetric=True)` | applique aussi le changement à la jumelle (en miroir) ; sans `symmetric`, la jumelle ne bouge pas |
| `remove_part(id, symmetric=True)` | supprime aussi la jumelle (sans `symmetric`, le lien de la jumelle est supprimé) |
| `unlink_mirror(id)` | rend les deux parties indépendantes |
| `twin(id)` | partie jumelle ou `None` |

`duplicate_part` recopie les liens internes au sous-arbre et supprime les liens vers l'extérieur. Un seul axe à la fois (pas de symétrie X+Y simultanée).

## Matières et textures (Étape 5)

| Opération | Effet |
|---|---|
| `add_material(name, color, opacity, emissive, roughness, texture_id)` / `update_material(id, **champs)` / `remove_material(id)` | matières (couleur `#rrggbb` ; valeurs 0 à 1) ; supprimer une matière vide `materialId` des parties concernées |
| `assign_material(part_id, material_id\|None, with_children=False, symmetric=False)` | applique la matière à la partie, ses descendants et/ou les jumelles ; retourne les ids modifiés |
| `add_texture(name, width, height)` / `remove_texture(id)` | texture vide (transparente) 1 à 256 ; supprimer une texture vide `textureId` des matières |
| `paint(texture_id, [(x, y), …], color\|None)` | peint (ou efface avec `None`) ; hors limites ignoré ; retourne le nombre de texels changés ; la palette s'agrandit (256 max) |
| `fill(texture_id, x, y, color\|None)` | remplissage par diffusion, 4 voisins |
| `clear_texture(id)` | remet la texture à vide |
| `get_material`, `get_texture` | requêtes |

Dans l'éditeur, `ensureTexture(partId)` (sans historique, entre `begin()` et `commit()`) crée matière + texture au premier coup de pinceau ; un trait entier = une entrée d'annulation.

## Poses et animations (Étape 6)

| Opération | Effet |
|---|---|
| `add_pose(name, bones)` / `remove_pose(id)` / `get_pose(id)` | bibliothèque de poses nommées |
| `add_animation(name, duration=1.0, loop=True, keyframes=None)` / `update_animation(id, name, duration, loop)` / `remove_animation(id)` / `get_animation(id)` | animations ; réduire la durée sous une image clé est refusé |
| `set_keyframe(anim_id, time, pose)` / `remove_keyframe(anim_id, time)` | insère ou remplace / supprime une image clé (temps arrondi à 1e-6, liste toujours triée) |
| `sample(anim_id, t)` ou `sample_pose(animation, t)` | pose à l'instant t (voir `core/format.md` §11) |

`remove_bone` et `remove_part` retirent l'os des poses nommées et des images clés. Le générateur d'animations de base n'existe que dans l'éditeur (JS).

## Caractéristiques et comportements (Étape 7)

| Opération | Effet |
|---|---|
| `get_stats()` / `set_stats(**champs)` | caractéristiques (valeurs par défaut pour les clés absentes) ; plages dans `core/format.md` §12 |
| `add_behavior(name, conditions=None, actions=None, enabled=True)` / `update_behavior(id, name, enabled)` / `remove_behavior(id)` / `get_behavior(id)` | règles ; une nouvelle règle est ajoutée en dernier (priorité la plus basse) |
| `move_behavior(id, index)` | place la règle à la position `index` (0 = priorité maximale) |
| `add_condition` / `set_condition` / `remove_condition` ; `add_action` / `set_action` / `remove_action` | blocs SI / ALORS d'une règle (par index) ; toute valeur invalide annule l'opération |
| `select_behavior(ctx)` ou `select_behavior(behaviors, ctx)` | règle active pour un contexte `{playerDistance, time, healthPercent, attacked, inWater, random}` |

`remove_animation` retire `animationId` des actions qui la jouaient. `behaviors.enabled` est recalculé à chaque opération.
La **simulation d'aperçu** (`simNew` / `simStep`, monde plat de ±12 blocs) n'existe que dans l'éditeur : elle ne fait pas partie du format.

**Noms miroir** : `mirror_name` accorde « gauche → droit » pour les mots masculins connus (bras, gant, œil, pied, genou, coude, poignet, doigt, pouce) et « gauche → droite » sinon ; « Genouillère » est féminin (mots entiers).

## Sons, effets et capacités (Étape 8)
`add_sound(name, sound, volume=1, pitch=1)` · `update_sound(id, name|sound|volume|pitch)` · `remove_sound(id)` (retire aussi les blocs `playSound` qui l'utilisaient et le `soundId` des capacités) ·
`add_effect(name, kind='spark', color='#ffffff', count=20, part_id=None)` · `update_effect(id, name|kind|color|count|partId)` (`partId=None` détache) · `remove_effect(id)` (même nettoyage) · `get_sound` · `get_effect`.
Les capacités s'ajoutent avec `add_action(rule, {"type": "ability", "ability": "heal", ...})`. JS : `addSound/updateSound/removeSound/addEffect/updateEffect/removeEffect`.

## Primitives et paramètres par défaut

`cube {size:[1,1,1]}`, `sphere {radius:0.5}`, `cylinder {radius:0.5,height:1}`, `cone {radius:0.5,height:1}`,
`capsule {radius:0.5,height:1}`, `pyramid {base:[1,1],height:1}`, `plane {size:[1,1]}`, `custom {}`.
`pyramid` et `plane` ont été ajoutées à l'Étape 2 (ajout compatible, `formatVersion` reste `1.0`).
Les paramètres ne sont pas encore validés par forme (à faire, voir CURRENT_STATE.md).

## Limites connues (volontaires)

- `reparent` et `remove_part(children="reparent")` **conservent la transformation locale** : la partie peut
  donc bouger visuellement. Conserver la position monde demande des matrices 4×4 (à traiter avec l'éditeur 3D).
- Pas de symétrie automatique, pas de sculpture, pas d'annuler/rétablir, pas d'interface : voir MASTER_PLAN.md.
