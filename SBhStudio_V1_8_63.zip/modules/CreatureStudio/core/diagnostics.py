"""Étape 9 — diagnostics : problèmes qui n'empêchent pas d'enregistrer le projet (le validateur s'en charge) mais qui le rendront
faux, fragile ou inexportable. Fonction pure ; miroir JS : `diagnose` dans editor/creature_editor.html (parité testée).

    diagnose(data) -> [ {"severity": "error"|"warning"|"info", "code": "D0xx", "message": str, "ref": {"kind": str, "id": str}} ]

Gravité : error = l'export donnera un résultat cassé ; warning = comportement probablement non voulu ; info = amélioration possible.
Le message est en français et s'adresse à l'utilisateur. Liste triée : gravité (error, warning, info) puis code puis id.
"""
import re

MOVES = ("chase", "flee", "wander", "idle")
CODES = {
    "D001": ("warning", "partie sans matière"),
    "D002": ("error", "dimension nulle ou négative"),
    "D003": ("warning", "noms de parties en double"),
    "D004": ("warning", "angle d'animation/pose hors des limites de l'os"),
    "D005": ("info", "animation sans image clé"),
    "D006": ("info", "jumelle miroir désynchronisée"),
    "D010": ("warning", "aucune règle de repli"),
    "D011": ("warning", "règle inatteignable"),
    "D012": ("warning", "capacité sans mouvement : le personnage se figera pendant la recharge"),
    "D013": ("warning", "règle sans action"),
    "D014": ("info", "mouvement sans animation"),
    "D015": ("warning", "poursuite avec vitesse nulle"),
    "D016": ("info", "dégâts sans action d'attaque"),
    "D017": ("info", "condition de distance au-delà de la portée de détection"),
    "D020": ("warning", "identifiant de son douteux (attendu : minuscules, chiffres, « . » et « _ »)"),
    "D021": ("info", "son non utilisé"),
    "D022": ("info", "effet non utilisé"),
    "D030": ("info", "matière non utilisée"),
    "D031": ("info", "texture non utilisée"),
    "D032": ("info", "texture vide"),
    "D033": ("info", "dimensions de texture qui ne sont pas des puissances de 2"),
    "D040": ("warning", "squelette sans os alors que des animations existent"),
    "D041": ("info", "os sans limites"),
    "D050": ("info", "forme qui sera exportée en boîte englobante (Bedrock ne dessine que des boîtes)"),
    "D051": ("warning", "partie tournée sous un parent à échelle non uniforme : position fausse dans Bedrock"),
    "D052": ("info", "matière avec lueur ou transparence : non exportée"),
}
_ORDER = {"error": 0, "warning": 1, "info": 2}
_SOUND = re.compile(r"^[a-z0-9_.]+$")


def skewed_parts(data):
    """Parties dont la position exportée sera FAUSSE : Bedrock imbrique rotation et échelle dans l'autre ordre que le format ; dès qu'une partie
    tournée (au repos ou animée) a un ancêtre à échelle non uniforme, le format produit un cisaillement que Bedrock ne sait pas représenter.
    Retourne les parties concernées et leurs descendants (l'erreur se propage). Contournement : mettre l'échelle sur la forme (taille), pas sur la partie parente."""
    parts = data["parts"]
    by = {p["id"]: p for p in parts}
    bone_part = {b["id"]: b["partId"] for b in data["skeleton"]["bones"]}
    animated = set()
    for a in data["animations"]:
        for k in a["keyframes"]:
            for bid, e in k["pose"].items():
                if any(e.get("rotation", [0, 0, 0])):
                    animated.add(bone_part[bid])
    uniform = lambda s: max(s) - min(s) < 1e-9
    flagged = set()

    def bad(pid):
        if pid in flagged:
            return True
        p = by[pid]
        up, hit = p["parentId"], False
        while up is not None:
            if not uniform(by[up]["transform"]["scale"]):
                hit = True
                break
            up = by[up]["parentId"]
        if (hit and (any(p["transform"]["rotation"]) or pid in animated)) or (p["parentId"] is not None and bad(p["parentId"])):
            flagged.add(pid)
            return True
        return False
    for p in parts:
        bad(p["id"])
    return flagged


def _pow2(n):
    return n > 0 and n & (n - 1) == 0


def diagnose(d):
    out = []

    def add(code, ref_kind, ref_id, msg):
        out.append({"severity": CODES[code][0], "code": code, "message": msg, "ref": {"kind": ref_kind, "id": ref_id}})

    parts = d.get("parts", [])
    # --- modèle
    for p in parts:
        if not p.get("materialId"):
            add("D001", "part", p["id"], f"« {p['name']} » n'a pas de matière (elle sera exportée sans couleur).")
        q = p.get("parameters") or {}
        bad = [k for k, v in q.items() if (isinstance(v, (int, float)) and v <= 0) or (isinstance(v, list) and any(isinstance(x, (int, float)) and x <= 0 for x in v))]
        if bad and p["shape"] != "plane":
            add("D002", "part", p["id"], f"« {p['name']} » a une dimension nulle ou négative ({', '.join(bad)}).")
        elif bad:
            add("D002", "part", p["id"], f"« {p['name']} » a une dimension nulle ou négative ({', '.join(bad)}).")
    seen = {}
    for p in parts:
        seen.setdefault(p["name"], []).append(p["id"])
    for name, ids in seen.items():
        if len(ids) > 1:
            for i in ids:
                add("D003", "part", i, f"Le nom « {name} » est utilisé par {len(ids)} parties ; l'export a besoin de noms uniques.")
    by_id = {p["id"]: p for p in parts}
    for p in parts:
        m = p.get("mirror")
        if m and p["name"] < by_id[m["partId"]]["name"]:     # un seul message par paire
            q, a = by_id[m["partId"]], m["axis"]
            ax = "xyz".index(a)
            tp, tq = p["transform"], q["transform"]
            exp_pos = [-v if i == ax else v for i, v in enumerate(tp["position"])]
            exp_rot = [v if i == ax else -v for i, v in enumerate(tp["rotation"])]
            if any(abs(x - y) > 1e-6 for x, y in zip(exp_pos + exp_rot, tq["position"] + tq["rotation"])) or p["shape"] != q["shape"] or (p.get("parameters") or {}) != (q.get("parameters") or {}):
                add("D006", "part", p["id"], f"« {p['name']} » et sa jumelle « {q['name']} » ne sont plus symétriques (lien miroir conservé).")
    # --- squelette et animations
    sk = d.get("skeleton", {})
    bones = {b["id"]: b for b in sk.get("bones", [])}
    anims = d.get("animations", [])
    if anims and not bones:
        add("D040", "skeleton", "skeleton", "Des animations existent mais aucun os n'est défini (utilise « Tout rigger »).")
    for b in bones.values():
        if not b.get("limits"):
            add("D041", "bone", b["id"], f"L'os « {b['name']} » n'a pas de limites d'angle.")

    def check_pose(pose, where, ref_kind, ref_id):
        for bid, e in pose.items():
            lim = bones[bid].get("limits", {})
            for i, v in enumerate(e.get("rotation", [])):
                r = lim.get("xyz"[i])
                if r and not (r[0] - 1e-6 <= v <= r[1] + 1e-6):
                    add("D004", ref_kind, ref_id, f"{where} : « {bones[bid]['name']} » {'xyz'[i]} = {v}° hors de [{r[0]}, {r[1]}].")
    for a in anims:
        if not a.get("keyframes"):
            add("D005", "animation", a["id"], f"L'animation « {a['name']} » n'a aucune image clé.")
        for k in a.get("keyframes", []):
            check_pose(k["pose"], f"Animation « {a['name']} » à {k['time']} s", "animation", a["id"])
    for q in sk.get("poses", []):
        check_pose(q["bones"], f"Pose « {q['name']} »", "pose", q["id"])
    # --- export Bedrock (Étape 10)
    for p in parts:
        if p["shape"] not in ("cube", "plane"):
            add("D050", "part", p["id"], f"« {p['name']} » ({p['shape']}) sera exportée vers Minecraft en boîte englobante.")
    for pid in sorted(skewed_parts(d)):
        add("D051", "part", pid, f"« {by_id[pid]['name']} » est tournée sous un parent à échelle non uniforme : sa position sera fausse dans Minecraft (mets l'échelle sur la forme, pas sur le parent).")
    for m in d.get("materials", []):
        if m.get("emissive", 0) > 0 or m.get("opacity", 1) < 1:
            add("D052", "material", m["id"], f"La matière « {m['name']} » a une lueur ou une transparence : non exportée vers Minecraft.")
    # --- comportements
    bh = d.get("behaviors", {})
    stats = bh.get("stats", {})
    graphs = bh.get("graphs", [])
    active = [g for g in graphs if g.get("enabled", True)]
    if graphs and not any(not g.get("conditions") for g in active):
        add("D010", "behaviors", "behaviors", "Aucune règle sans condition : quand rien ne s'applique, la créature ne fait rien. Ajoute une règle « Se promener » en dernier.")
    blocked = None
    for g in active:
        if blocked:
            add("D011", "behavior", g["id"], f"La règle « {g['name']} » ne sera jamais active : « {blocked} » (sans condition) passe avant.")
        elif not g.get("conditions"):
            blocked = g["name"]
    detect = stats.get("detectionRange", 16)
    for g in graphs:
        acts, conds = g.get("actions", []), g.get("conditions", [])
        if not acts:
            add("D013", "behavior", g["id"], f"La règle « {g['name']} » n'a aucune action.")
        if any(a["type"] == "ability" for a in acts) and not any(a["type"] in MOVES for a in acts):
            add("D012", "behavior", g["id"], f"« {g['name']} » a une capacité mais aucun mouvement : le personnage restera figé pendant toute la recharge.")
        for a in acts:
            if a["type"] in ("chase", "flee", "wander") and "animationId" not in a:
                add("D014", "behavior", g["id"], f"« {g['name']} » : le mouvement n'a pas d'animation.")
            if a["type"] == "chase" and stats.get("speed", 0.5) * a.get("speed", 1) == 0:
                add("D015", "behavior", g["id"], f"« {g['name']} » poursuit le joueur avec une vitesse nulle.")
        for c in conds:
            if c["type"] == "distance" and c["op"] in ("<", "<=") and c["value"] > detect and not c.get("not"):
                add("D017", "behavior", g["id"], f"« {g['name']} » : distance < {c['value']} dépasse la portée de détection ({detect}).")
    if stats.get("damage", 3) > 0 and graphs and not any(a["type"] in ("attack",) or (a["type"] == "ability") for g in graphs for a in g.get("actions", [])):
        add("D016", "behaviors", "behaviors", "Des dégâts sont définis mais aucune règle n'attaque.")
    # --- sons et effets
    used_s = {a.get("soundId") for g in graphs for a in g.get("actions", [])}
    used_e = {a.get("effectId") for g in graphs for a in g.get("actions", [])}
    for s in d.get("sounds", []):
        if not _SOUND.match(s["sound"]):
            add("D020", "sound", s["id"], f"Le son « {s['name']} » a un identifiant douteux : « {s['sound']} ».")
        if s["id"] not in used_s:
            add("D021", "sound", s["id"], f"Le son « {s['name']} » n'est utilisé par aucune règle.")
    for e in d.get("effects", []):
        if e["id"] not in used_e:
            add("D022", "effect", e["id"], f"L'effet « {e['name']} » n'est utilisé par aucune règle.")
    # --- matières et textures
    used_m = {p.get("materialId") for p in parts}
    used_t = {m.get("textureId") for m in d.get("materials", [])}
    for m in d.get("materials", []):
        if m["id"] not in used_m:
            add("D030", "material", m["id"], f"La matière « {m['name']} » n'est utilisée par aucune partie.")
    for t in d.get("textures", []):
        if t["id"] not in used_t:
            add("D031", "texture", t["id"], f"La texture « {t['name']} » n'est utilisée par aucune matière.")
        if not any(t["pixels"]):
            add("D032", "texture", t["id"], f"La texture « {t['name']} » est vide (aucun pixel peint).")
        if not (_pow2(t["width"]) and _pow2(t["height"])):
            add("D033", "texture", t["id"], f"La texture « {t['name']} » fait {t['width']}×{t['height']} : des puissances de 2 sont recommandées (plus sûr pour l'export).")
    out.sort(key=lambda x: (_ORDER[x["severity"]], x["code"], x["ref"]["id"]))
    return out


def summary(items):
    n = {"error": 0, "warning": 0, "info": 0}
    for i in items:
        n[i["severity"]] += 1
    return n
