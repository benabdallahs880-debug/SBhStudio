"""Étape 10 — export Minecraft Bedrock : .creature.json -> pack de ressources (RP) + pack de comportement (BP) + .mcaddon.

    from bedrock_export import export_bedrock
    report = export_bedrock(data, "sortie/", namespace="sbh")

Formats utilisés (vérifiés dans la documentation Microsoft / Bedrock Wiki, voir docs/BEDROCK_EXPORT.md) :
géométrie 1.12.0, entité client 1.10.0, render controller 1.10.0, animations 1.8.0, animation controller 1.10.0,
entité comportement 1.20.0, manifest format_version 2.

CONVENTIONS ET HYPOTHÈSES (non vérifiées dans le jeu — voir docs/BEDROCK_EXPORT.md) :
 * 1 bloc = 16 unités de modèle ; le modèle est posé sur le sol (y min = 0) ; l'avant regarde −z ; +x = côté gauche : c'est déjà la convention du format.
 * Chaque partie devient un os Bedrock (nom ASCII unique), rangé sous l'os de son parent, pivot = point d'articulation en repère « repos » absolu.
 * Les angles Bedrock sont (−x, +y, −z) des angles du format (écart de convention observé entre Blockbench et Bedrock : rotations X et Y inversées,
   déduit en tenant compte du miroir de l'axe X). Les translations d'animation sont reprises telles quelles, en unités de 1/16 de bloc.
 * Bedrock ne sait dessiner que des boîtes : sphère, cylindre, cône, capsule, pyramide et forme libre sont exportées en BOÎTE ENGLOBANTE.
"""
import copy
import json
import math
import re
import struct
import unicodedata
import uuid
import zipfile
import zlib
from pathlib import Path

from creature_model import CreatureProject, rotation_matrix, shape_y_bounds, DEFAULT_PARAMETERS
from diagnostics import skewed_parts

U = 16.0                                     # unités de modèle par bloc
FACE_NAMES = ["north", "south", "west", "east", "up", "down"]   # ordre du format : −z, +z, −x, +x, +y, −y
DEFAULT_NAMESPACE = "sbh"
MIN_ENGINE = [1, 20, 0]


# ------------------------------------------------------------------------------------------------ utilitaires
def slug(text):
    t = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "_", t).strip("_") or "item"


def _r(x, n=4):
    v = round(float(x), n)
    return 0.0 if v == 0 else v          # pas de « -0.0 »


def bedrock_rotation(rot):
    """Angles du format -> angles Bedrock."""
    return [_r(-rot[0]), _r(rot[1]), _r(-rot[2])]


def _mat_mul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def euler_from_matrix(R):
    """Inverse de rotation_matrix (R = Rz·Ry·Rx), en degrés."""
    sy = max(-1.0, min(1.0, -R[2][0]))
    y = math.asin(sy)
    if abs(math.cos(y)) > 1e-6:
        x, z = math.atan2(R[2][1], R[2][2]), math.atan2(R[1][0], R[0][0])
    else:
        z, x = 0.0, math.atan2(sy * R[0][1], R[1][1])
    return [math.degrees(x), math.degrees(y), math.degrees(z)]


def make_uuid(namespace, key):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"sbh-creature-studio/{namespace}/{key}"))


def write_png(path, width, height, rgba_rows):
    """PNG RGBA 8 bits, sans dépendance. rgba_rows = liste de lignes, chaque ligne = liste de (r,g,b,a)."""
    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rgba_rows)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    Path(path).write_bytes(png)


def _hex(c):
    return tuple(int(c[i:i + 2], 16) for i in (1, 3, 5))


def _pow2_ceil(n):
    p = 1
    while p < n:
        p *= 2
    return p


# ------------------------------------------------------------------------------------------------ atlas de texture
def build_atlas(data):
    """Une seule image pour tout le modèle : rangée 0 = pastilles de couleur unie (1 texel par matière), puis les textures empilées.
    Une texture est dessinée sur la couleur de la matière (un texel transparent laisse voir la couleur), comme dans l'éditeur.
    Retourne (largeur, hauteur, pixels[y][x] RGBA, régions) ; régions[materialId] = {"swatch": (x, y), "texture": (x, y, w, h) | None}."""
    mats = data["materials"]
    texs = {t["id"]: t for t in data.get("textures", [])}
    used_tex = [m for m in mats if m.get("textureId")]
    width = _pow2_ceil(max([len(mats), 4] + [texs[m["textureId"]]["width"] for m in used_tex]))
    y, regions = 1, {}
    for i, m in enumerate(mats):
        regions[m["id"]] = {"swatch": (i, 0), "texture": None}
    for m in used_tex:
        t = texs[m["textureId"]]
        regions[m["id"]]["texture"] = (0, y, t["width"], t["height"])
        y += t["height"]
    height = _pow2_ceil(y)
    px = [[(0, 0, 0, 0)] * width for _ in range(height)]
    for i, m in enumerate(mats):
        px[0][i] = _hex(m["color"]) + (255,)
    for m in used_tex:
        t, (ox, oy, w, h) = texs[m["textureId"]], regions[m["id"]]["texture"]
        base = _hex(m["color"]) + (255,)
        for j in range(h):
            for i in range(w):
                c = t["palette"][t["pixels"][j * w + i]]
                px[oy + j][ox + i] = (_hex(c) + (255,)) if c else base
    return width, height, px, regions


# ------------------------------------------------------------------------------------------------ géométrie
def _rest_layout(parts):
    """Pour chaque partie : (échelle cumulée, translation cumulée) de A0(x) = t + s∘x, rotations ignorées (repos « à plat »),
    et `pivot_world` = image par A0 du parent du point de position de la partie (= pivot d'articulation en repère absolu)."""
    by = {p["id"]: p for p in parts}
    cache = {}

    def A0(pid):                      # x -> s*x + t  (composante par composante)
        if pid in cache:
            return cache[pid]
        p = by[pid]
        T = p["transform"]
        pv = p.get("pivot", [0, 0, 0])
        s_loc = list(T["scale"])
        t_loc = [T["position"][i] - s_loc[i] * pv[i] for i in range(3)]
        if p["parentId"] is None:
            res = (s_loc, t_loc)
        else:
            sp, tp = A0(p["parentId"])
            res = ([sp[i] * s_loc[i] for i in range(3)], [sp[i] * t_loc[i] + tp[i] for i in range(3)])
        cache[pid] = res
        return res

    out = {}
    for p in parts:
        s, t = A0(p["id"])
        pos = p["transform"]["position"]
        if p["parentId"] is None:
            pivot = list(pos)
        else:
            sp, tp = A0(p["parentId"])
            pivot = [sp[i] * pos[i] + tp[i] for i in range(3)]
        out[p["id"]] = {"s": s, "t": t, "pivot": pivot}
    return out


def _local_box(p):
    """Boîte (min, max) de la forme dans l'espace local de la partie, avant échelle ; la forme est centrée sur l'origine locale."""
    q = {**DEFAULT_PARAMETERS[p["shape"]], **(p.get("parameters") or {})}
    sh = p["shape"]
    if sh == "cube":
        h = [v / 2 for v in q["size"]]
        return [-h[0], -h[1], -h[2]], h
    if sh in ("sphere",):
        r = q["radius"]
        return [-r] * 3, [r] * 3
    if sh in ("cylinder", "cone", "capsule"):
        lo, hi = shape_y_bounds(sh, q)
        r = q["radius"]
        return [-r, lo, -r], [r, hi, r]
    if sh == "pyramid":
        bx, bz = q["base"][0] / 2, q["base"][1] / 2
        return [-bx, -q["height"] / 2, -bz], [bx, q["height"] / 2, bz]
    if sh == "plane":
        sx, sz = q["size"][0] / 2, q["size"][1] / 2
        return [-sx, 0, -sz], [sx, 0, sz]
    return [-0.5] * 3, [0.5] * 3        # custom : cube unité


def build_geometry(data, namespace=DEFAULT_NAMESPACE, atlas=None):
    """Retourne (document géométrie, correspondance {partId: nom d'os}, décalage vertical en blocs, liste d'approximations)."""
    parts = data["parts"]
    by = {p["id"]: p for p in parts}
    layout = _rest_layout(parts)
    approx = []
    # boîtes en repère « repos » absolu (blocs)
    boxes = {}
    for p in parts:
        lo, hi = _local_box(p)
        L = layout[p["id"]]
        a = [L["s"][i] * lo[i] + L["t"][i] for i in range(3)]
        b = [L["s"][i] * hi[i] + L["t"][i] for i in range(3)]
        boxes[p["id"]] = ([min(a[i], b[i]) for i in range(3)], [max(a[i], b[i]) for i in range(3)])
        if p["shape"] not in ("cube", "plane"):
            approx.append(f"« {p['name']} » ({p['shape']}) exportée en boîte englobante")
    miny = min(b[0][1] for b in boxes.values())
    dy = -miny
    names, used = {}, set()
    for p in parts:
        base, n = slug(p["name"]), 2
        nm = base
        while nm in used:
            nm, n = f"{base}_{n}", n + 1
        used.add(nm)
        names[p["id"]] = nm
    W, H, _, regions = atlas if atlas else (16, 16, None, {})
    mats = {m["id"]: m for m in data["materials"]}
    texs = {t["id"]: t for t in data.get("textures", [])}
    bones = []
    for p in parts:
        L = layout[p["id"]]
        lo, hi = boxes[p["id"]]
        size = [hi[i] - lo[i] for i in range(3)]
        bone = {"name": names[p["id"]]}
        if p["parentId"] is not None:
            bone["parent"] = names[p["parentId"]]
        bone["pivot"] = [_r(L["pivot"][0] * U), _r((L["pivot"][1] + dy) * U), _r(L["pivot"][2] * U)]
        rot = p["transform"]["rotation"]
        if any(rot):
            bone["rotation"] = bedrock_rotation(rot)
        cube = {"origin": [_r(lo[0] * U), _r((lo[1] + dy) * U), _r(lo[2] * U)], "size": [_r(s * U) for s in size]}
        cube["uv"] = _face_uv(p, mats.get(p.get("materialId")), texs, regions, W, H)
        bone["cubes"] = [cube]
        bones.append(bone)
    top = max(b[1][1] for b in boxes.values()) + dy
    xs = [v for b in boxes.values() for v in (b[0][0], b[1][0])]
    zs = [v for b in boxes.values() for v in (b[0][2], b[1][2])]
    width = max(max(abs(v) for v in xs), max(abs(v) for v in zs)) * 2
    ident = f"geometry.{namespace}_{slug(data['creature']['name'])}"
    doc = {"format_version": "1.12.0", "minecraft:geometry": [{
        "description": {"identifier": ident, "texture_width": W, "texture_height": H,
                        "visible_bounds_width": _r(max(2, math.ceil(width * 1.5))), "visible_bounds_height": _r(max(2, math.ceil(top * 1.5))),
                        "visible_bounds_offset": [0, _r(top / 2), 0]},
        "bones": bones}]}
    return doc, names, dy, approx, {"width": width, "height": top}


def _face_uv(p, mat, texs, regions, W, H):
    """UV par face (texels entiers). Cube : 6 cases de la grille 3×2 de la texture ; matière sans texture : un texel de couleur unie."""
    reg = regions.get(mat["id"]) if mat else None
    if not reg:
        return {f: {"uv": [0, 0], "uv_size": [0, 0]} for f in FACE_NAMES}      # aucune matière : sans effet (D001 prévient)
    n = 1 if p["shape"] == "plane" else 5 if p["shape"] == "pyramid" else 6
    out = {}
    if reg["texture"]:
        ox, oy, w, h = reg["texture"]
        cw, ch = max(1, w // 3), max(1, h // 2)
        for c, face in enumerate(FACE_NAMES):
            if p["shape"] == "plane":
                out[face] = {"uv": [ox, oy], "uv_size": [w, h]}
            else:
                cell = c if c < n else 0
                out[face] = {"uv": [ox + (cell % 3) * cw, oy + (cell // 3) * ch], "uv_size": [cw, ch]}
    else:
        sx, sy = reg["swatch"]
        out = {f: {"uv": [sx, sy], "uv_size": [1, 1]} for f in FACE_NAMES}
    return out


# ------------------------------------------------------------------------------------------------ animations
def build_animations(data, names, namespace=DEFAULT_NAMESPACE):
    """Retourne (document animations, {nom court: identifiant}, liste d'avertissements)."""
    project = CreatureProject(copy.deepcopy(data))
    bone_part = {b["id"]: b["partId"] for b in data["skeleton"]["bones"]}
    parts = {p["id"]: p for p in data["parts"]}
    cname = slug(data["creature"]["name"])
    anims, ids, warn = {}, {}, []
    for a in data["animations"]:
        times = sorted({0.0, *[k["time"] for k in a["keyframes"]], *([a["duration"]] if a.get("loop") else [])})
        bones = {}
        for t in times:
            sample = project.sample(a["id"], t)
            for bid, entry in sample.items():
                pid = bone_part[bid]
                rest = parts[pid]["transform"]["rotation"]
                slot = bones.setdefault(names[pid], {})
                if "rotation" in entry:
                    rot = entry["rotation"]
                    if any(rest):                   # Bedrock additionne des angles ; le format compose des matrices : on convertit
                        comb = euler_from_matrix(_mat_mul(rotation_matrix(rot), rotation_matrix(rest)))
                        rot = [comb[i] - rest[i] for i in range(3)]
                    slot.setdefault("rotation", {})[_key(t)] = bedrock_rotation(rot)
                if "position" in entry:
                    slot.setdefault("position", {})[_key(t)] = [_r(v * U) for v in entry["position"]]
        # un os qui n'apparaît qu'à certains instants : on complète par 0 (repos) pour que l'interpolation soit la même
        for nm, slot in bones.items():
            for ch in ("rotation", "position"):
                if ch in slot:
                    for t in times:
                        slot[ch].setdefault(_key(t), [0.0, 0.0, 0.0])
                    slot[ch] = dict(sorted(slot[ch].items(), key=lambda kv: float(kv[0])))
        short = slug(a["name"])
        full = f"animation.{namespace}_{cname}.{short}"
        anims[full] = {"loop": bool(a.get("loop")), "animation_length": _r(a["duration"]), "bones": bones}
        ids[short] = full
    return {"format_version": "1.8.0", "animations": anims}, ids, warn


def _key(t):
    return f"{_r(t):.4f}".rstrip("0").rstrip(".") if t else "0.0"


# ------------------------------------------------------------------------------------------------ entité client + contrôleurs
def build_client(data, geo_id, anim_ids, namespace, tex_path):
    cname = slug(data["creature"]["name"])
    ident = f"{namespace}:{cname}"
    ctrl_id = f"controller.animation.{namespace}_{cname}.main"
    mat_colors = [m["color"] for m in data["materials"]] or ["#808080", "#404040"]
    desc = {
        "identifier": ident,
        "materials": {"default": "entity_alphatest"},
        "textures": {"default": tex_path},
        "geometry": {"default": geo_id},
        "render_controllers": [f"controller.render.{namespace}_{cname}"],
        "animations": {**{k: v for k, v in anim_ids.items()}},
        "scripts": {"animate": []},
        "spawn_egg": {"base_color": mat_colors[0], "overlay_color": mat_colors[-1]},
    }
    controller = None
    if anim_ids:
        desc["animations"]["main"] = ctrl_id
        desc["scripts"]["animate"] = ["main"]
        controller = _animation_controller(ctrl_id, anim_ids)
    doc = {"format_version": "1.10.0", "minecraft:client_entity": {"description": desc}}
    rc = {"format_version": "1.10.0", "render_controllers": {f"controller.render.{namespace}_{cname}": {
        "geometry": "Geometry.default", "materials": [{"*": "Material.default"}], "textures": ["Texture.default"]}}}
    return doc, rc, controller, ident


def _animation_controller(ctrl_id, anim_ids):
    """Repos / marche / course selon la vitesse au sol ; attaque via variable.attack_time. Les animations Dégâts et Mort sont exportées mais non déclenchées."""
    idle = anim_ids.get("repos") or next(iter(anim_ids.values()))
    walk, run, attack = anim_ids.get("marche"), anim_ids.get("course"), anim_ids.get("attaque")
    states = {"default": {"animations": [_short(anim_ids, idle)], "transitions": []},
              "walking": {"animations": [_short(anim_ids, walk)] if walk else [], "transitions": [{"default": "query.ground_speed < 0.1"}]},
              "running": {"animations": [_short(anim_ids, run)] if run else [], "transitions": [{"default": "query.ground_speed < 0.1"}]}}
    states["default"]["transitions"] = [{"running": "query.ground_speed > 0.5"} if run else {}, {"walking": "query.ground_speed > 0.1"} if walk else {}]
    states["default"]["transitions"] = [t for t in states["default"]["transitions"] if t]
    if run:
        states["walking"]["transitions"].insert(0, {"running": "query.ground_speed > 0.5"})
        states["running"]["transitions"].append({"walking": "query.ground_speed < 0.5"})
    if attack:
        states["attacking"] = {"animations": [_short(anim_ids, attack)], "transitions": [{"default": "variable.attack_time <= 0.0"}]}
        for s in ("default", "walking", "running"):
            states[s]["transitions"].insert(0, {"attacking": "variable.attack_time > 0.0"})
    return {"format_version": "1.10.0", "animation_controllers": {ctrl_id: {"initial_state": "default", "states": states}}}


def _short(anim_ids, full):
    return next(k for k, v in anim_ids.items() if v == full)


# ------------------------------------------------------------------------------------------------ entité comportement
def build_behavior_entity(data, ident, size):
    """Caractéristiques + objectifs Bedrock approchés depuis les règles. Retourne (document, avertissements)."""
    bh = data["behaviors"]
    st = {"health": 20, "damage": 3, "armor": 0, "speed": 0.5, "jumpHeight": 1, "detectionRange": 16, **bh.get("stats", {})}
    warn = []
    comp = {
        "minecraft:type_family": {"family": ["mob", slug(data["creature"]["name"])]},
        "minecraft:health": {"value": st["health"], "max": st["health"]},
        "minecraft:collision_box": {"width": _r(max(0.2, min(size["width"], 3.0)), 2), "height": _r(max(0.2, size["height"]), 2)},
        "minecraft:physics": {},
        "minecraft:movement": {"value": _r(0.05 + 0.3 * st["speed"], 3)},
        "minecraft:movement.basic": {},
        "minecraft:navigation.walk": {"can_pass_doors": True, "can_walk": True, "avoid_water": True},
        "minecraft:jump.static": {},
        "minecraft:follow_range": {"value": st["detectionRange"], "max": st["detectionRange"]},
    }
    if st["damage"] > 0:
        comp["minecraft:attack"] = {"damage": st["damage"]}
    if st["armor"]:
        warn.append(f"armure = {st['armor']} non exportée (pas d'équivalent direct vérifié)")
    if st["jumpHeight"] != 1:
        warn.append("hauteur de saut non exportée (minecraft:jump.static a sa valeur par défaut)")
    player = {"test": "is_family", "subject": "other", "value": "player"}
    for prio, g in enumerate([g for g in bh.get("graphs", []) if g.get("enabled", True)], 1):
        for c in g.get("conditions", []):
            if c["type"] == "playerDetected" or (c["type"] == "distance" and c["op"] in ("<", "<=")):
                continue                                   # impliqués par la portée de détection / l'attaque au contact
            warn.append(f"règle « {g['name']} » : condition « {c['type']} » non exportée (les objectifs Bedrock n'ont pas de conditions arbitraires)")
        for a in g.get("actions", []):
            t, sp = a["type"], _r(a.get("speed", 1) if a.get("speed", 1) else 1, 2)
            if t == "chase":
                comp.setdefault("minecraft:behavior.nearest_attackable_target", {"priority": prio, "must_see": False, "entity_types": [{"filters": player, "max_dist": st["detectionRange"]}]})
                comp.setdefault("minecraft:behavior.melee_attack", {"priority": prio, "speed_multiplier": sp, "track_target": True})
            elif t == "attack":
                comp.setdefault("minecraft:behavior.melee_attack", {"priority": prio, "speed_multiplier": 1, "track_target": True})
            elif t == "flee":
                comp.setdefault("minecraft:behavior.avoid_mob_type", {"priority": prio, "entity_types": [{"filters": player, "max_dist": st["detectionRange"], "walk_speed_multiplier": sp, "sprint_speed_multiplier": sp}]})
            elif t == "wander":
                comp.setdefault("minecraft:behavior.random_stroll", {"priority": prio, "speed_multiplier": sp})
            elif t == "idle":
                comp.setdefault("minecraft:behavior.random_look_around", {"priority": prio})
            elif t == "ability":
                warn.append(f"règle « {g['name']} » : capacité « {a['ability']} » non exportée (nécessite des événements / composants à définir)")
            elif t in ("playSound", "effect"):
                warn.append(f"règle « {g['name']} » : action « {t} » non exportée (sons et particules non déclenchés)")
    doc = {"format_version": "1.20.0", "minecraft:entity": {
        "description": {"identifier": ident, "is_spawnable": True, "is_summonable": True, "is_experimental": False},
        "components": comp}}
    return doc, warn


# ------------------------------------------------------------------------------------------------ manifests, emballage
def _manifest(kind, name, desc, namespace, key, dep=None):
    m = {"format_version": 2,
         "header": {"name": name, "description": desc, "uuid": make_uuid(namespace, key + "/header"), "version": [1, 0, 0], "min_engine_version": MIN_ENGINE},
         "modules": [{"description": desc, "type": "resources" if kind == "rp" else "data", "uuid": make_uuid(namespace, key + "/module"), "version": [1, 0, 0]}]}
    if dep:
        m["dependencies"] = [{"uuid": dep, "version": [1, 0, 0]}]
    return m


def _dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def build_pack(data, namespace=DEFAULT_NAMESPACE):
    """Fonction PURE (aucune écriture) : construit tout l'add-on en mémoire. Miroir JS : `buildBedrockPack` dans l'éditeur (parité testée).
    Retourne (files, report) ; files = {chemin relatif: ("json", objet) | ("png", largeur, hauteur, lignes RGBA)}."""
    import validate_creature
    err, _ = validate_creature.check(data)
    if err:
        raise ValueError(f"projet invalide, export impossible : {err}")
    namespace = slug(namespace)
    cname = slug(data["creature"]["name"])
    rp, bp = f"{cname}_RP", f"{cname}_BP"
    atlas = build_atlas(data)
    geo, names, dy, approx, size = build_geometry(data, namespace, atlas)
    geo_id = geo["minecraft:geometry"][0]["description"]["identifier"]
    anim_doc, anim_ids, awarn = build_animations(data, names, namespace)
    tex_rel = f"textures/entity/{namespace}/{cname}"
    client, rc, ctrl, ident = build_client(data, geo_id, anim_ids, namespace, tex_rel)
    entity, bwarn = build_behavior_entity(data, ident, size)
    rp_uuid = make_uuid(namespace, cname + "/rp/header")
    files = {}
    nm = data["creature"]["name"]
    files[f"{rp}/manifest.json"] = ("json", _manifest("rp", f"{nm} (ressources)", f"Modèle, texture et animations de {nm} — CreatureStudio", namespace, cname + "/rp"))
    files[f"{rp}/models/entity/{cname}.geo.json"] = ("json", geo)
    files[f"{rp}/entity/{cname}.entity.json"] = ("json", client)
    files[f"{rp}/render_controllers/{cname}.rc.json"] = ("json", rc)
    if anim_ids:
        files[f"{rp}/animations/{cname}.animation.json"] = ("json", anim_doc)
        files[f"{rp}/animation_controllers/{cname}.ac.json"] = ("json", ctrl)
    files[f"{rp}/{tex_rel}.png"] = ("png", atlas[0], atlas[1], atlas[2])
    files[f"{bp}/manifest.json"] = ("json", _manifest("bp", f"{nm} (comportement)", f"Comportement de {nm} — CreatureStudio", namespace, cname + "/bp", dep=rp_uuid))
    files[f"{bp}/entities/{cname}.json"] = ("json", entity)
    warnings = list(bwarn) + list(awarn)
    skew = skewed_parts(data)
    if skew:
        names_s = ", ".join(f"« {p['name']} »" for p in data["parts"] if p["id"] in skew)
        warnings.append(f"POSITION FAUSSE : {len(skew)} partie(s) tournée(s) sous un parent à échelle non uniforme ({names_s}) — Bedrock ne représente pas ce cisaillement")
    for m in data["materials"]:
        if m.get("emissive", 0) > 0:
            warnings.append(f"matière « {m['name']} » : lueur non exportée")
        if m.get("opacity", 1) < 1:
            warnings.append(f"matière « {m['name']} » : transparence non exportée")
    if data.get("sounds"):
        warnings.append(f"{len(data['sounds'])} son(s) et {len(data.get('effects', []))} effet(s) définis mais non déclenchés dans le jeu")
    report = {"identifier": ident, "geometry": geo_id, "bones": len(geo["minecraft:geometry"][0]["bones"]), "texture": [atlas[0], atlas[1]],
              "animations": sorted(anim_ids), "approximations": approx, "warnings": warnings, "files": list(files), "verticalShiftBlocks": _r(dy)}
    return files, report


def export_bedrock(data, out_dir, namespace=DEFAULT_NAMESPACE, make_mcaddon=True):
    """Exporte le projet sur disque. Retourne le rapport {identifier, files, approximations, warnings, ...}. `data` doit être valide."""
    files, report = build_pack(data, namespace)
    out = Path(out_dir)
    cname = slug(data["creature"]["name"])
    for rel, item in files.items():
        path = out / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if item[0] == "json":
            _dump(path, item[1])
        else:
            write_png(path, item[1], item[2], item[3])
    if make_mcaddon:
        addon = out / f"{cname}.mcaddon"
        with zipfile.ZipFile(addon, "w", zipfile.ZIP_DEFLATED) as z:
            for rel in files:
                z.write(out / rel, rel)
        report["files"].append(addon.name)
    (out / "EXPORT_REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report
