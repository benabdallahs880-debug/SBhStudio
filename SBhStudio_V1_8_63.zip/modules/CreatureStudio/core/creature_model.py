"""CreatureStudio — modèle manipulable (Étape 2).

Opérations pour créer, supprimer, dupliquer, déplacer, tourner, redimensionner
et réorganiser les parties d'une créature, sans dépendance externe.

Règles de fonctionnement (voir core/operations.md) :
- chaque opération est TRANSACTIONNELLE : si le projet devient invalide, il est
  restauré à l'identique et une `CreatureError` est levée ;
- les `id` existants ne changent jamais ; les nouveaux ids sont générés ;
- les transformations sont LOCALES (relatives au parent), rotation en degrés ;
- le format `formatVersion 1.0` n'est pas modifié (Étape 4 : champs optionnels `pivot` et `skeleton.bones`).

Convention de transformation (identique dans l'éditeur JS) : un point `v` du maillage de la partie va à
`position + R · (S ∘ (v − pivot))` dans l'espace du parent, avec R = Rz·Ry·Rx (degrés). `pivot` vaut [0,0,0] par
défaut : la partie tourne alors autour de son centre, comme aux étapes 1 à 3.
"""
import copy
import json
import math
import re
import sys
import unicodedata
from contextlib import contextmanager
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))
import validate_creature as _validator  # noqa: E402

SHAPES = tuple(sorted(_validator.ALLOWED_SHAPES))

DEFAULT_PARAMETERS = {
    "cube": {"size": [1, 1, 1]},
    "sphere": {"radius": 0.5},
    "cylinder": {"radius": 0.5, "height": 1},
    "cone": {"radius": 0.5, "height": 1},
    "capsule": {"radius": 0.5, "height": 1},
    "pyramid": {"base": [1, 1], "height": 1},
    "plane": {"size": [1, 1]},
    "custom": {},
}


def rotation_matrix(rotation):
    """Matrice 3×3 (liste de lignes) R = Rz·Ry·Rx, angles en degrés."""
    rx, ry, rz = (math.radians(a) for a in rotation)
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    return [[cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx],
            [sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx],
            [-sy, cy * sx, cy * cx]]


def shape_y_bounds(shape, parameters=None):
    """(y_min, y_max) de la primitive dans son espace local, avant échelle."""
    q = {**DEFAULT_PARAMETERS[shape], **(parameters or {})}
    if shape == "cube":
        return -q["size"][1] / 2, q["size"][1] / 2
    if shape == "sphere":
        return -q["radius"], q["radius"]
    if shape in ("cylinder", "cone", "pyramid"):
        return -q["height"] / 2, q["height"] / 2
    if shape == "capsule":
        return -q["height"] / 2 - q["radius"], q["height"] / 2 + q["radius"]
    if shape == "plane":
        return 0, 0
    return -0.5, 0.5  # custom : cube unité


def _axis_index(axis):
    if axis not in ("x", "y", "z"):
        raise CreatureError("axe de symétrie: 'x', 'y' ou 'z'")
    return "xyz".index(axis)


def mirror_vector(v, axis):
    """Reflexion d'un vecteur par rapport au plan perpendiculaire à `axis` (coordonnée `axis` inversée)."""
    i = _axis_index(axis)
    return [-x if j == i else x for j, x in enumerate(v)]


def mirror_rotation(rotation, axis):
    """Rotation Euler (degrés, R = Rz·Ry·Rx) conjuguée par la réflexion : l'angle autour de `axis` est conservé, les deux autres s'inversent."""
    i = _axis_index(axis)
    return [a if j == i else -a for j, a in enumerate(rotation)]


def mirror_limits(limits, axis):
    _axis_index(axis)
    return {ax: list(r) if ax == axis else [-r[1], -r[0]] for ax, r in limits.items()}


_MASCULINE = ("bras", "gant", "oeil", "œil", "pied", "genou", "coude", "poignet", "doigt", "pouce", "brassard", "bracelet", "sabre", "casque", "anneau", "liseré", "liséré", "pommeau")


def mirror_name(name):
    """Échange gauche/droite (ou left/right) dans un nom, en conservant la casse de la première lettre.

    « gauche » devient « droit » si le nom contient un mot masculin connu (bras, gant, œil, pied, genou, coude, poignet, doigt, pouce),
    sinon « droite » ; « droit » et « droite » deviennent « gauche »."""
    masculine = any(w in _MASCULINE for w in re.split(r"[\s\-'’]+", name.lower()))   # mots entiers : « Genouillère » est féminin

    def sub(m):
        w = m.group(0).lower()
        r = {"gauche": "droit" if masculine else "droite", "droite": "gauche", "droit": "gauche", "left": "right", "right": "left"}[w]
        return r.capitalize() if m.group(0)[0].isupper() else r
    return re.sub("gauche|droite|droit|left|right", sub, name, flags=re.IGNORECASE)


def _lerp_pose(pa, pb, u):
    out = {}
    for bid in list(dict.fromkeys([*pa, *pb])):
        ea, eb, entry = pa.get(bid, {}), pb.get(bid, {}), {}
        for field in ("rotation", "position"):
            if field in ea or field in eb:
                va, vb = ea.get(field, [0, 0, 0]), eb.get(field, [0, 0, 0])
                entry[field] = [x + (y - x) * u for x, y in zip(va, vb)]
        out[bid] = entry
    return out


def sample_pose(animation, t):
    """Pose (décalages par os) d'une animation à l'instant t (secondes).

    Interpolation linéaire des angles Euler et des positions entre images clés ; un os absent d'une image clé vaut 0 (repos).
    Animation en boucle : t est ramené dans [0, durée[ et la dernière image clé rejoint la première à la fin de la durée.
    Sans boucle : avant la première image clé on garde la première pose, après la dernière on garde la dernière."""
    keys = animation.get("keyframes", [])
    if not keys:
        return {}
    dur, loop = animation["duration"], animation.get("loop", False)
    t = (t % dur) if loop else min(max(t, 0), dur)
    first, last = keys[0], keys[-1]
    if len(keys) == 1:
        return _lerp_pose(first["pose"], first["pose"], 0)
    if not loop and t <= first["time"]:
        return _lerp_pose(first["pose"], first["pose"], 0)
    if not loop and t >= last["time"]:
        return _lerp_pose(last["pose"], last["pose"], 0)
    if loop and (t < first["time"] or t >= last["time"]):
        ta = last["time"] if t >= last["time"] else last["time"] - dur
        tb = first["time"] + dur if t >= last["time"] else first["time"]
        a, b = last, first
    else:
        a, b = next((k0, k1) for k0, k1 in zip(keys, keys[1:]) if k0["time"] <= t < k1["time"])
        ta, tb = a["time"], b["time"]
    return _lerp_pose(a["pose"], b["pose"], 0 if tb == ta else (t - ta) / (tb - ta))


DEFAULT_STATS = {"health": 20, "damage": 3, "armor": 0, "speed": 0.5, "jumpHeight": 1, "detectionRange": 16, "intelligence": 0.5}
_OPS = {"<": lambda a, b: a < b, "<=": lambda a, b: a <= b, ">": lambda a, b: a > b, ">=": lambda a, b: a >= b}


def evaluate_condition(cond, ctx, stats):
    """Valeur d'une condition de comportement. ctx : playerDistance (None = pas de joueur), time ('day'|'night'),
    healthPercent, attacked, inWater, random (dans [0,1[). `not: true` inverse le résultat."""
    t, d = cond["type"], ctx.get("playerDistance")
    if t == "playerDetected":
        r = d is not None and d <= stats["detectionRange"]
    elif t == "distance":
        r = d is not None and _OPS[cond["op"]](d, cond["value"])
    elif t == "time":
        r = ctx.get("time") == cond["is"]
    elif t == "healthBelow":
        r = ctx.get("healthPercent", 100) < cond["percent"]
    elif t == "attacked":
        r = bool(ctx.get("attacked"))
    elif t == "inWater":
        r = bool(ctx.get("inWater"))
    elif t == "random":
        r = ctx.get("random", 1.0) < cond["chance"]
    else:
        raise CreatureError(f"condition inconnue: {t}")
    return (not r) if cond.get("not") else r


def select_behavior(behaviors, ctx):
    """Règle active : la première règle activée (liste = priorités décroissantes) dont toutes les conditions sont vraies, ou None.
    Une règle sans condition est toujours vraie (règle de repli, à placer en dernier)."""
    stats = {**DEFAULT_STATS, **behaviors.get("stats", {})}
    for g in behaviors.get("graphs", []):
        if g.get("enabled", True) and all(evaluate_condition(c, ctx, stats) for c in g.get("conditions", [])):
            return g
    return None


class CreatureError(ValueError):
    """Opération refusée. Le projet est resté inchangé."""


def _slug(text):
    text = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_") or "item"


def _vec(value, label, allow_zero=True):
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise CreatureError(f"{label}: 3 nombres attendus [x, y, z]")
    out = []
    for x in value:
        if isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x):
            raise CreatureError(f"{label}: nombres finis uniquement")
        out.append(x)
    if not allow_zero and any(x == 0 for x in out):
        raise CreatureError(f"{label}: une échelle à 0 est interdite (forme dégénérée)")
    return out


class CreatureProject:
    """Projet de créature en mémoire. `self.data` est le dict JSON du format."""

    def __init__(self, data):
        error, _ = _validator.check(data)
        if error:
            raise CreatureError(f"projet invalide: {error}")
        data["skeleton"].setdefault("bones", [])
        data.setdefault("textures", [])
        data.setdefault("sounds", [])
        data.setdefault("effects", [])
        self.data = data

    # ------------------------------------------------------------ création / E-S
    @classmethod
    def new(cls, name, root_name="Body", root_shape="cube"):
        """Nouvelle créature avec une seule partie racine."""
        if root_shape not in SHAPES:
            raise CreatureError(f"forme inconnue: {root_shape}")
        today = date.today().isoformat()
        root_id = f"part_{_slug(root_name)}"
        data = {
            "formatVersion": "1.0",
            "project": {"id": f"project_{_slug(name)}", "name": name, "createdAt": today, "updatedAt": today},
            "creature": {"id": f"creature_{_slug(name)}", "name": name, "rootPartId": root_id},
            "parts": [{
                "id": root_id, "name": root_name, "parentId": None, "shape": root_shape,
                "transform": {"position": [0, 0, 0], "rotation": [0, 0, 0], "scale": [1, 1, 1]},
                "parameters": copy.deepcopy(DEFAULT_PARAMETERS[root_shape]), "materialId": None,
            }],
            "sockets": [], "materials": [], "textures": [], "sounds": [], "effects": [],
            "skeleton": {"enabled": False, "bones": []}, "animations": [],
            "behaviors": {"enabled": False, "stats": dict(DEFAULT_STATS), "graphs": []}, "export": {"targets": []},
        }
        return cls(data)

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as f:
            return cls(json.load(f))

    def save(self, path):
        error, _ = _validator.check(self.data)
        if error:
            raise CreatureError(f"sauvegarde refusée, projet invalide: {error}")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
            f.write("\n")

    # ------------------------------------------------------------------ requêtes
    @property
    def root_id(self):
        return self.data["creature"]["rootPartId"]

    def get_part(self, part_id):
        for p in self.data["parts"]:
            if p["id"] == part_id:
                return p
        raise CreatureError(f"partie introuvable: {part_id}")

    def children(self, part_id):
        return [p for p in self.data["parts"] if p["parentId"] == part_id]

    def descendants(self, part_id):
        """Ids de tous les descendants (sans la partie elle-même)."""
        out, stack = [], [part_id]
        while stack:
            for c in self.children(stack.pop()):
                out.append(c["id"])
                stack.append(c["id"])
        return out

    def tree_text(self):
        lines = []

        def walk(pid, prefix, last, top):
            p = self.get_part(pid)
            label = f"{p['name']} [{p['shape']}]"
            lines.append(label if top else prefix + ("└── " if last else "├── ") + label)
            kids = self.children(pid)
            for i, c in enumerate(kids):
                walk(c["id"], "" if top else prefix + ("    " if last else "│   "), i == len(kids) - 1, False)

        walk(self.root_id, "", True, True)
        return "\n".join(lines)

    # -------------------------------------------------------------- transaction
    @contextmanager
    def _transaction(self):
        snapshot = copy.deepcopy(self.data)
        try:
            yield
            sk = self.data["skeleton"]
            sk.setdefault("bones", [])
            sk["enabled"] = bool(sk["bones"])  # `enabled` est toujours déduit des os
            bh = self.data["behaviors"]
            bh.setdefault("graphs", [])
            bh["enabled"] = bool(bh["graphs"])  # idem pour les comportements
            live = {p["id"] for p in self.data["parts"]}
            for ef in self.data.get("effects", []):
                if "partId" in ef and ef["partId"] not in live:
                    del ef["partId"]  # la partie a été supprimée : l'effet part du centre de la créature
            error, _ = _validator.check(self.data)
            if error:
                raise CreatureError(f"opération refusée, projet invalide: {error}")
            self.data["project"]["updatedAt"] = date.today().isoformat()
        except BaseException:
            self.data.clear()
            self.data.update(snapshot)
            raise

    def _new_id(self, prefix, name):
        used = ({p["id"] for p in self.data["parts"]} | {s["id"] for s in self.data["sockets"]}
                | {b["id"] for b in self.data["skeleton"]["bones"]}
                | {m["id"] for m in self.data["materials"]} | {t["id"] for t in self.data["textures"]}
                | {a["id"] for a in self.data["animations"]} | {q["id"] for q in self.data["skeleton"].get("poses", [])}
                | {g["id"] for g in self.data["behaviors"].get("graphs", [])}
                | {x["id"] for x in self.data.get("sounds", [])} | {x["id"] for x in self.data.get("effects", [])})
        base = f"{prefix}_{_slug(name)}"
        candidate, n = base, 2
        while candidate in used:
            candidate, n = f"{base}_{n}", n + 1
        return candidate

    @staticmethod
    def _check_name(name):
        if not isinstance(name, str) or not name.strip():
            raise CreatureError("le nom ne peut pas être vide")
        return name.strip()

    def _not_root(self, part_id, action):
        self.get_part(part_id)
        if part_id == self.root_id:
            raise CreatureError(f"impossible de {action} la partie racine")

    # --------------------------------------------------------------- opérations
    def add_part(self, name, shape="cube", parent_id=None, position=(0, 0, 0), rotation=(0, 0, 0),
                 scale=(1, 1, 1), parameters=None, material_id=None, symmetric_axis=None):
        """Ajoute une partie (par défaut sous la racine). Retourne son id.

        symmetric_axis='x'|'y'|'z' crée aussi, dans la même opération, la partie miroir liée (voir mirror_part)."""
        name = self._check_name(name)
        if shape not in SHAPES:
            raise CreatureError(f"forme inconnue: {shape} (autorisées: {', '.join(SHAPES)})")
        with self._transaction():
            parent_id = self.root_id if parent_id is None else parent_id
            self.get_part(parent_id)
            part = {
                "id": self._new_id("part", name), "name": name, "parentId": parent_id, "shape": shape,
                "transform": {"position": _vec(position, "position"), "rotation": _vec(rotation, "rotation"),
                              "scale": _vec(scale, "scale", allow_zero=False)},
                "parameters": copy.deepcopy(DEFAULT_PARAMETERS[shape] if parameters is None else parameters),
                "materialId": material_id,
            }
            self.data["parts"].append(part)
            if symmetric_axis:
                self._mirror_subtree(part["id"], symmetric_axis)
        return part["id"]

    def remove_part(self, part_id, children="delete", symmetric=False):
        """Supprime une partie. children='delete' (sous-arbre) ou 'reparent' (enfants remontent au parent).

        Les sockets et les os des parties supprimées sont supprimés. Retourne un dict
        {'removed_parts': [...], 'removed_sockets': [...], 'removed_bones': [...]}.
        """
        if children not in ("delete", "reparent"):
            raise CreatureError("children doit valoir 'delete' ou 'reparent'")
        self._not_root(part_id, "supprimer")
        with self._transaction():
            part = self.get_part(part_id)
            if children == "delete":
                gone = {part_id, *self.descendants(part_id)}
            else:
                gone = {part_id}
                for c in self.children(part_id):
                    c["parentId"] = part["parentId"]
            if symmetric and part.get("mirror") and part["mirror"]["partId"] not in gone:
                tw = part["mirror"]["partId"]
                if children == "delete":
                    gone |= {tw, *self.descendants(tw)}
                else:
                    gone.add(tw)
                    for c in self.children(tw):
                        c["parentId"] = self.get_part(tw)["parentId"]
            removed_sockets = [s["id"] for s in self.data["sockets"] if s["partId"] in gone]
            removed_bones = [b["id"] for b in self.data["skeleton"]["bones"] if b["partId"] in gone]
            self.data["skeleton"]["bones"] = [b for b in self.data["skeleton"]["bones"] if b["partId"] not in gone]
            self._purge_bone_refs(set(removed_bones))
            self.data["parts"] = [p for p in self.data["parts"] if p["id"] not in gone]
            self.data["sockets"] = [s for s in self.data["sockets"] if s["partId"] not in gone]
            for q in self.data["parts"]:  # liens miroir orphelins
                if q.get("mirror") and q["mirror"]["partId"] in gone:
                    del q["mirror"]
        return {"removed_parts": sorted(gone), "removed_sockets": removed_sockets, "removed_bones": removed_bones}

    def duplicate_part(self, part_id, with_children=True, offset=(0, 0, 0)):
        """Duplique une partie (et son sous-arbre par défaut) sous le même parent. Retourne l'id du clone."""
        self._not_root(part_id, "dupliquer")
        offset = _vec(offset, "offset")
        with self._transaction():
            source = self.get_part(part_id)
            ids = [part_id] + (self.descendants(part_id) if with_children else [])
            mapping = {}
            clones = []
            for old_id in ids:  # parents avant enfants (ordre de descendants)
                old = self.get_part(old_id)
                clone = copy.deepcopy(old)
                clone["id"] = self._new_id("part", old["name"])
                self.data["parts"].append(clone)  # réserve l'id pour le suivant
                mapping[old_id] = clone["id"]
                clones.append(clone)
            for clone, old_id in zip(clones, ids):
                if old_id == part_id:
                    clone["parentId"] = source["parentId"]
                    clone["name"] = f"{source['name']} (copie)"
                    clone["transform"]["position"] = [a + b for a, b in zip(clone["transform"]["position"], offset)]
                else:
                    clone["parentId"] = mapping[self.get_part(old_id)["parentId"]]
            for clone in clones:  # un lien miroir interne au sous-arbre est recopié ; un lien vers l'extérieur est supprimé
                m = clone.get("mirror")
                if m:
                    if m["partId"] in mapping:
                        m["partId"] = mapping[m["partId"]]
                    else:
                        del clone["mirror"]
            for s in [s for s in self.data["sockets"] if s["partId"] in mapping]:
                sc = copy.deepcopy(s)
                sc["id"] = self._new_id("socket", s["name"])
                sc["partId"] = mapping[s["partId"]]
                self.data["sockets"].append(sc)
            for b in [b for b in self.data["skeleton"]["bones"] if b["partId"] in mapping]:
                bc = copy.deepcopy(b)
                bc["id"] = self._new_id("bone", b["name"])
                bc["partId"] = mapping[b["partId"]]
                self.data["skeleton"]["bones"].append(bc)
        return mapping[part_id]

    def set_transform(self, part_id, position=None, rotation=None, scale=None, symmetric=False):
        """Remplace tout ou partie de la transformation locale (rotation en degrés).

        symmetric=True synchronise aussi la partie miroir liée (si elle existe)."""
        with self._transaction():
            t = self.get_part(part_id)["transform"]
            if position is not None:
                t["position"] = _vec(position, "position")
            if rotation is not None:
                t["rotation"] = _vec(rotation, "rotation")
            if scale is not None:
                t["scale"] = _vec(scale, "scale", allow_zero=False)
            if symmetric:
                self._sync_twin(part_id)

    def translate(self, part_id, delta, symmetric=False):
        d = _vec(delta, "delta")
        self.set_transform(part_id, position=[a + b for a, b in zip(self.get_part(part_id)["transform"]["position"], d)], symmetric=symmetric)

    def rotate(self, part_id, delta_degrees, symmetric=False):
        d = _vec(delta_degrees, "delta_degrees")
        self.set_transform(part_id, rotation=[a + b for a, b in zip(self.get_part(part_id)["transform"]["rotation"], d)], symmetric=symmetric)

    def scale_by(self, part_id, factor, symmetric=False):
        """Multiplie l'échelle par un nombre ou par [fx, fy, fz]."""
        f = [factor] * 3 if isinstance(factor, (int, float)) and not isinstance(factor, bool) else factor
        f = _vec(f, "factor", allow_zero=False)
        self.set_transform(part_id, scale=[a * b for a, b in zip(self.get_part(part_id)["transform"]["scale"], f)], symmetric=symmetric)

    def rename_part(self, part_id, name):
        name = self._check_name(name)
        with self._transaction():
            self.get_part(part_id)["name"] = name

    def set_shape(self, part_id, shape, parameters=None, symmetric=False):
        """Change la primitive d'une partie ; sans `parameters`, valeurs par défaut de la nouvelle forme."""
        if shape not in SHAPES:
            raise CreatureError(f"forme inconnue: {shape}")
        with self._transaction():
            p = self.get_part(part_id)
            p["shape"] = shape
            p["parameters"] = copy.deepcopy(DEFAULT_PARAMETERS[shape] if parameters is None else parameters)
            if symmetric:
                self._sync_twin(part_id)

    def reparent(self, part_id, new_parent_id):
        """Change le parent d'une partie. La transformation LOCALE est conservée (voir operations.md)."""
        self._not_root(part_id, "re-parenter")
        self.get_part(new_parent_id)
        if new_parent_id == part_id or new_parent_id in self.descendants(part_id):
            raise CreatureError("cycle interdit: une partie ne peut pas devenir enfant d'elle-même ou de son descendant")
        with self._transaction():
            self.get_part(part_id)["parentId"] = new_parent_id

    def reorder(self, part_id, index):
        """Place la partie à `index` parmi ses frères (0 = premier). N'affecte pas la hiérarchie."""
        part = self.get_part(part_id)
        parts = self.data["parts"]
        slots = [i for i, p in enumerate(parts) if p["parentId"] == part["parentId"]]
        if not 0 <= index < len(slots):
            raise CreatureError(f"index hors limites (0 à {len(slots) - 1})")
        with self._transaction():
            siblings = [parts[i] for i in slots]
            siblings.remove(part)
            siblings.insert(index, part)
            for slot, p in zip(slots, siblings):
                parts[slot] = p

    # ------------------------------------------------------------------- sockets
    def add_socket(self, part_id, name, position=(0, 0, 0), rotation=(0, 0, 0), scale=(1, 1, 1)):
        name = self._check_name(name)
        with self._transaction():
            self.get_part(part_id)
            socket = {"id": self._new_id("socket", name), "name": name, "partId": part_id,
                      "transform": {"position": _vec(position, "position"), "rotation": _vec(rotation, "rotation"),
                                    "scale": _vec(scale, "scale", allow_zero=False)}}
            self.data["sockets"].append(socket)
        return socket["id"]

    def remove_socket(self, socket_id):
        with self._transaction():
            before = len(self.data["sockets"])
            self.data["sockets"] = [s for s in self.data["sockets"] if s["id"] != socket_id]
            if len(self.data["sockets"]) == before:
                raise CreatureError(f"socket introuvable: {socket_id}")

    # ------------------------------------------------- pivots (Étape 4)
    def local_point(self, part_id, point):
        """Position, dans l'espace du parent, d'un point du maillage de la partie (voir convention en tête de fichier)."""
        p = self.get_part(part_id)
        t, pv = p["transform"], p.get("pivot", [0, 0, 0])
        r = rotation_matrix(t["rotation"])
        d = [(point[i] - pv[i]) * t["scale"][i] for i in range(3)]
        return [t["position"][i] + sum(r[i][j] * d[j] for j in range(3)) for i in range(3)]

    def set_pivot(self, part_id, pivot, keep_in_place=True, symmetric=False):
        """Définit le point d'articulation (espace local de la partie, avant échelle).

        keep_in_place=True (défaut) corrige `position` pour que la forme ne bouge pas à l'écran.
        keep_in_place=False conserve `position` : la forme se déplace (position = emplacement du pivot).
        """
        new = _vec(pivot, "pivot")
        with self._transaction():
            p = self.get_part(part_id)
            old = p.get("pivot", [0, 0, 0])
            if keep_in_place:
                t = p["transform"]
                r = rotation_matrix(t["rotation"])
                d = [(new[i] - old[i]) * t["scale"][i] for i in range(3)]
                t["position"] = [t["position"][i] + sum(r[i][j] * d[j] for j in range(3)) for i in range(3)]
            p["pivot"] = new
            if symmetric:
                self._sync_twin(part_id)

    def pivot_preset(self, part_id, where):
        """Pivot au 'top', 'center' ou 'bottom' de la primitive (axe Y). Utile pour hanches, épaules, cous."""
        if where not in ("top", "center", "bottom"):
            raise CreatureError("where doit valoir 'top', 'center' ou 'bottom'")
        lo, hi = shape_y_bounds(self.get_part(part_id)["shape"], self.get_part(part_id).get("parameters"))
        self.set_pivot(part_id, [0, {"top": hi, "bottom": lo, "center": 0}[where], 0])

    # ---------------------------------------------------- squelette (Étape 4)
    def bone_of_part(self, part_id):
        self.get_part(part_id)
        return next((b for b in self.data["skeleton"]["bones"] if b["partId"] == part_id), None)

    def get_bone(self, bone_id):
        for b in self.data["skeleton"]["bones"]:
            if b["id"] == bone_id:
                return b
        raise CreatureError(f"os introuvable: {bone_id}")

    def bone_parent(self, bone_id):
        """Os parent = os de l'ancêtre le plus proche qui en possède un (déduit de la hiérarchie, jamais stocké)."""
        pid = self.get_part(self.get_bone(bone_id)["partId"])["parentId"]
        while pid is not None:
            b = self.bone_of_part(pid)
            if b:
                return b["id"]
            pid = self.get_part(pid)["parentId"]
        return None

    def add_bone(self, part_id, name=None, limits=None):
        """Crée l'os d'une partie (un seul par partie). Retourne l'id de l'os."""
        part = self.get_part(part_id)
        if self.bone_of_part(part_id):
            raise CreatureError(f"la partie {part_id} a déjà un os")
        name = self._check_name(name if name is not None else part["name"])
        with self._transaction():
            bone = {"id": self._new_id("bone", name), "name": name, "partId": part_id}
            if limits:
                bone["limits"] = copy.deepcopy(limits)
            self.data["skeleton"]["bones"].append(bone)
        return bone["id"]

    def remove_bone(self, bone_id):
        self.get_bone(bone_id)
        with self._transaction():
            self.data["skeleton"]["bones"] = [b for b in self.data["skeleton"]["bones"] if b["id"] != bone_id]
            self._purge_bone_refs({bone_id})

    def set_bone_limits(self, bone_id, limits):
        """Limites de pose en degrés : {'x': [min, max], ...} ; axe absent = libre ; None ou {} efface."""
        with self._transaction():
            b = self.get_bone(bone_id)
            if limits:
                b["limits"] = copy.deepcopy(limits)
            else:
                b.pop("limits", None)

    def auto_rig(self):
        """Crée un os pour chaque partie qui n'en a pas. Retourne les ids créés."""
        created = []
        with self._transaction():
            for p in self.data["parts"]:
                if not any(b["partId"] == p["id"] for b in self.data["skeleton"]["bones"]):
                    bone = {"id": self._new_id("bone", p["name"]), "name": p["name"], "partId": p["id"]}
                    self.data["skeleton"]["bones"].append(bone)
                    created.append(bone["id"])
        return created

    # ------------------------------------------------ symétrie (Étape 4 bis)
    def twin(self, part_id):
        """Partie miroir liée, ou None."""
        m = self.get_part(part_id).get("mirror")
        return self.get_part(m["partId"]) if m else None

    def _sync_twin(self, part_id):
        """Recopie (en miroir) transformation, pivot, forme et paramètres de la partie vers sa jumelle."""
        p = self.get_part(part_id)
        m = p.get("mirror")
        if not m:
            return
        q, a, t = self.get_part(m["partId"]), m["axis"], p["transform"]
        q["transform"] = {"position": mirror_vector(t["position"], a), "rotation": mirror_rotation(t["rotation"], a), "scale": list(t["scale"])}
        if "pivot" in p:
            q["pivot"] = mirror_vector(p["pivot"], a)
        else:
            q.pop("pivot", None)
        q["shape"] = p["shape"]
        q["parameters"] = copy.deepcopy(p.get("parameters", {}))

    def _mirror_subtree(self, part_id, axis):
        """Crée la copie miroir du sous-arbre (dans la transaction courante). Retourne l'id de la copie de `part_id`."""
        _axis_index(axis)
        self._not_root(part_id, "mettre en miroir")
        ids = [part_id] + self.descendants(part_id)
        if any(self.get_part(i).get("mirror") for i in ids):
            raise CreatureError("une des parties est déjà liée à un miroir (utilise unlink_mirror)")
        mapping, pairs = {}, []
        for old_id in ids:
            clone = copy.deepcopy(self.get_part(old_id))
            clone["id"] = self._new_id("part", clone["name"])
            self.data["parts"].append(clone)
            mapping[old_id] = clone["id"]
            pairs.append((self.get_part(old_id), clone))
        for src, clone in pairs:
            if src["id"] == part_id:  # sous un parent lui-même en miroir selon le même axe, la copie va sous la jumelle du parent
                pm = self.get_part(src["parentId"]).get("mirror")
                clone["parentId"] = pm["partId"] if pm and pm["axis"] == axis else src["parentId"]
            else:
                clone["parentId"] = mapping[src["parentId"]]
            clone["name"] = mirror_name(src["name"])
            if src["id"] == part_id and clone["name"] == src["name"]:
                clone["name"] += " (miroir)"
            t = clone["transform"]
            t["position"], t["rotation"] = mirror_vector(t["position"], axis), mirror_rotation(t["rotation"], axis)
            if "pivot" in clone:
                clone["pivot"] = mirror_vector(clone["pivot"], axis)
            clone["mirror"] = {"axis": axis, "partId": src["id"]}
            src["mirror"] = {"axis": axis, "partId": clone["id"]}
        for s in [s for s in self.data["sockets"] if s["partId"] in mapping]:
            sc = copy.deepcopy(s)
            sc["id"] = self._new_id("socket", s["name"])
            sc["partId"] = mapping[s["partId"]]
            sc["transform"]["position"] = mirror_vector(sc["transform"]["position"], axis)
            sc["transform"]["rotation"] = mirror_rotation(sc["transform"]["rotation"], axis)
            self.data["sockets"].append(sc)
        for b in [b for b in self.data["skeleton"]["bones"] if b["partId"] in mapping]:
            bc = copy.deepcopy(b)
            bc["id"] = self._new_id("bone", b["name"])
            bc["partId"] = mapping[b["partId"]]
            bc["name"] = mirror_name(b["name"])
            if "limits" in bc:
                bc["limits"] = mirror_limits(bc["limits"], axis)
            self.data["skeleton"]["bones"].append(bc)
        return mapping[part_id]

    def mirror_part(self, part_id, axis="x"):
        """Crée la copie miroir d'une partie (et de ses enfants, sockets et os) et lie chaque paire.

        Plan de symétrie : plan perpendiculaire à `axis` passant par l'origine du PARENT (repère local du parent).
        Noms : gauche↔droite / left↔right échangés, sinon suffixe « (miroir) ». Retourne l'id de la copie."""
        with self._transaction():
            return self._mirror_subtree(part_id, axis)

    def unlink_mirror(self, part_id):
        """Rend la partie et sa jumelle indépendantes (les deux restent en place)."""
        with self._transaction():
            p = self.get_part(part_id)
            m = p.pop("mirror", None)
            if m:
                self.get_part(m["partId"]).pop("mirror", None)

    # ------------------------------------------ matériaux et textures (Étape 5)
    @staticmethod
    def _color(value):
        if not isinstance(value, str) or not re.match(r"^#[0-9a-fA-F]{6}$", value):
            raise CreatureError("couleur attendue au format '#rrggbb'")
        return value.lower()

    def get_material(self, material_id):
        for m in self.data["materials"]:
            if m["id"] == material_id:
                return m
        raise CreatureError(f"matière introuvable: {material_id}")

    def get_texture(self, texture_id):
        for t in self.data["textures"]:
            if t["id"] == texture_id:
                return t
        raise CreatureError(f"texture introuvable: {texture_id}")

    def add_material(self, name="Matière", color="#cccccc", opacity=1.0, emissive=0.0, roughness=0.8, texture_id=None):
        """Crée une matière (partagée entre parties). opacity/emissive/roughness dans [0, 1]. Retourne l'id."""
        name, color = self._check_name(name), self._color(color)
        with self._transaction():
            if texture_id is not None:
                self.get_texture(texture_id)
            m = {"id": self._new_id("mat", name), "name": name, "color": color, "opacity": opacity,
                 "emissive": emissive, "roughness": roughness, "textureId": texture_id}
            self.data["materials"].append(m)
        return m["id"]

    def update_material(self, material_id, **fields):
        """Modifie name, color, opacity, emissive, roughness ou textureId d'une matière."""
        allowed = {"name", "color", "opacity", "emissive", "roughness", "textureId"}
        if not fields or set(fields) - allowed:
            raise CreatureError(f"champs autorisés: {', '.join(sorted(allowed))}")
        with self._transaction():
            m = self.get_material(material_id)
            for k, v in fields.items():
                if k == "color":
                    v = self._color(v)
                elif k == "name":
                    v = self._check_name(v)
                elif k == "textureId" and v is not None:
                    self.get_texture(v)
                m[k] = v

    def remove_material(self, material_id):
        """Supprime une matière ; les parties qui l'utilisaient n'ont plus de matière."""
        self.get_material(material_id)
        with self._transaction():
            self.data["materials"] = [m for m in self.data["materials"] if m["id"] != material_id]
            for p in self.data["parts"]:
                if p.get("materialId") == material_id:
                    p["materialId"] = None

    def assign_material(self, part_id, material_id, with_children=False, symmetric=False):
        """Applique une matière (ou None) à une partie, à ses descendants et/ou à leurs jumelles. Retourne les ids modifiés."""
        self.get_part(part_id)
        if material_id is not None:
            self.get_material(material_id)
        with self._transaction():
            targets = [part_id] + (self.descendants(part_id) if with_children else [])
            if symmetric:
                targets += [self.twin(t)["id"] for t in list(targets) if self.get_part(t).get("mirror")]
            targets = list(dict.fromkeys(targets))
            for t in targets:
                self.get_part(t)["materialId"] = material_id
        return targets

    def add_texture(self, name="Texture", width=16, height=16):
        """Crée une texture vide (toute transparente). Retourne l'id. Taille 1 à 256."""
        name = self._check_name(name)
        with self._transaction():
            t = {"id": self._new_id("tex", name), "name": name, "width": width, "height": height,
                 "palette": [None], "pixels": [0] * (width * height) if isinstance(width, int) and isinstance(height, int) else []}
            self.data["textures"].append(t)
        return t["id"]

    def remove_texture(self, texture_id):
        self.get_texture(texture_id)
        with self._transaction():
            self.data["textures"] = [t for t in self.data["textures"] if t["id"] != texture_id]
            for m in self.data["materials"]:
                if m.get("textureId") == texture_id:
                    m["textureId"] = None

    @staticmethod
    def _palette_index(tex, color):
        color = None if color is None else CreatureProject._color(color)
        if color in tex["palette"]:
            return tex["palette"].index(color)
        if len(tex["palette"]) >= 256:
            raise CreatureError("palette pleine (256 couleurs maximum)")
        tex["palette"].append(color)
        return len(tex["palette"]) - 1

    def paint(self, texture_id, points, color):
        """Peint les texels `points` [(x, y), ...] avec `color` ('#rrggbb') ou efface avec None. Hors limites ignoré. Retourne le nombre de texels changés."""
        with self._transaction():
            t = self.get_texture(texture_id)
            idx, changed = self._palette_index(t, color), 0
            for x, y in points:
                if 0 <= x < t["width"] and 0 <= y < t["height"]:
                    i = y * t["width"] + x
                    if t["pixels"][i] != idx:
                        t["pixels"][i] = idx
                        changed += 1
            return changed

    def fill(self, texture_id, x, y, color):
        """Remplissage par diffusion (4 voisins) depuis le texel (x, y). Retourne le nombre de texels changés."""
        with self._transaction():
            t = self.get_texture(texture_id)
            w, h = t["width"], t["height"]
            if not (0 <= x < w and 0 <= y < h):
                raise CreatureError("texel hors limites")
            idx, src = self._palette_index(t, color), t["pixels"][y * w + x]
            if idx == src:
                return 0
            stack, n = [(x, y)], 0
            while stack:
                cx, cy = stack.pop()
                if 0 <= cx < w and 0 <= cy < h and t["pixels"][cy * w + cx] == src:
                    t["pixels"][cy * w + cx] = idx
                    n += 1
                    stack += [(cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)]
            return n

    def clear_texture(self, texture_id):
        with self._transaction():
            t = self.get_texture(texture_id)
            t["palette"], t["pixels"] = [None], [0] * (t["width"] * t["height"])

    # --------------------------------------------- poses et animations (Étape 6)
    def _purge_bone_refs(self, bone_ids):
        """Retire des poses nommées et des images clés les os supprimés."""
        for po in self.data["skeleton"].get("poses", []):
            po["bones"] = {k: v for k, v in po["bones"].items() if k not in bone_ids}
        for a in self.data["animations"]:
            for k in a.get("keyframes", []):
                k["pose"] = {b: v for b, v in k["pose"].items() if b not in bone_ids}

    def get_animation(self, animation_id):
        for a in self.data["animations"]:
            if a["id"] == animation_id:
                return a
        raise CreatureError(f"animation introuvable: {animation_id}")

    def get_pose(self, pose_id):
        for q in self.data["skeleton"].get("poses", []):
            if q["id"] == pose_id:
                return q
        raise CreatureError(f"pose introuvable: {pose_id}")

    def add_pose(self, name, bones):
        """Enregistre une pose nommée { boneId: {'rotation': [..], 'position': [..]} } dans la bibliothèque. Retourne l'id."""
        name = self._check_name(name)
        with self._transaction():
            q = {"id": self._new_id("pose", name), "name": name, "bones": copy.deepcopy(bones)}
            self.data["skeleton"].setdefault("poses", []).append(q)
        return q["id"]

    def remove_pose(self, pose_id):
        self.get_pose(pose_id)
        with self._transaction():
            self.data["skeleton"]["poses"] = [q for q in self.data["skeleton"]["poses"] if q["id"] != pose_id]

    def add_animation(self, name, duration=1.0, loop=True, keyframes=None):
        """Crée une animation (durée en secondes, > 0). `keyframes` : [{'time': t, 'pose': {...}}, ...] triées. Retourne l'id."""
        name = self._check_name(name)
        with self._transaction():
            a = {"id": self._new_id("anim", name), "name": name, "duration": duration, "loop": loop,
                 "keyframes": copy.deepcopy(keyframes or [])}
            self.data["animations"].append(a)
        return a["id"]

    def update_animation(self, animation_id, name=None, duration=None, loop=None):
        """Modifie nom, durée ou boucle. Réduire la durée en dessous d'une image clé est refusé."""
        with self._transaction():
            a = self.get_animation(animation_id)
            if name is not None:
                a["name"] = self._check_name(name)
            if duration is not None:
                a["duration"] = duration
            if loop is not None:
                a["loop"] = loop

    def remove_animation(self, animation_id):
        self.get_animation(animation_id)
        with self._transaction():
            self.data["animations"] = [a for a in self.data["animations"] if a["id"] != animation_id]
            for g in self.data["behaviors"].get("graphs", []):  # les actions qui jouaient cette animation n'en jouent plus
                for act in g.get("actions", []):
                    if act.get("animationId") == animation_id:
                        del act["animationId"]

    def set_keyframe(self, animation_id, time, pose):
        """Insère ou remplace l'image clé à `time` (arrondi au micro-seconde). Les images clés restent triées."""
        time = round(time, 6)
        with self._transaction():
            a = self.get_animation(animation_id)
            a["keyframes"] = [k for k in a["keyframes"] if k["time"] != time]
            a["keyframes"].append({"time": time, "pose": copy.deepcopy(pose)})
            a["keyframes"].sort(key=lambda k: k["time"])

    def remove_keyframe(self, animation_id, time):
        time = round(time, 6)
        with self._transaction():
            a = self.get_animation(animation_id)
            before = len(a["keyframes"])
            a["keyframes"] = [k for k in a["keyframes"] if k["time"] != time]
            if len(a["keyframes"]) == before:
                raise CreatureError(f"aucune image clé à t={time}")

    def sample(self, animation_id, t):
        """Pose de l'animation à l'instant t (voir sample_pose)."""
        return sample_pose(self.get_animation(animation_id), t)

    # ------------------------------------- comportements et caractéristiques (Étape 7)
    def get_stats(self):
        """Caractéristiques de la créature (valeurs par défaut pour celles qui ne sont pas définies)."""
        return {**DEFAULT_STATS, **self.data["behaviors"].get("stats", {})}

    def set_stats(self, **fields):
        """Définit des caractéristiques : health 1-1000, damage 0-100, armor 0-30, speed 0-1 (lent→rapide), jumpHeight 0-10,
        detectionRange 1-64 (blocs), intelligence 0-1."""
        if not fields:
            raise CreatureError("aucune caractéristique donnée")
        with self._transaction():
            self.data["behaviors"].setdefault("stats", {}).update(fields)

    def get_behavior(self, behavior_id):
        for g in self.data["behaviors"].get("graphs", []):
            if g["id"] == behavior_id:
                return g
        raise CreatureError(f"comportement introuvable: {behavior_id}")

    def add_behavior(self, name, conditions=None, actions=None, enabled=True):
        """Ajoute une règle en dernière position (= priorité la plus basse). Retourne son id."""
        name = self._check_name(name)
        with self._transaction():
            g = {"id": self._new_id("beh", name), "name": name, "enabled": enabled,
                 "conditions": copy.deepcopy(conditions or []), "actions": copy.deepcopy(actions or [])}
            self.data["behaviors"].setdefault("graphs", []).append(g)
        return g["id"]

    def update_behavior(self, behavior_id, name=None, enabled=None):
        with self._transaction():
            g = self.get_behavior(behavior_id)
            if name is not None:
                g["name"] = self._check_name(name)
            if enabled is not None:
                g["enabled"] = enabled

    def remove_behavior(self, behavior_id):
        self.get_behavior(behavior_id)
        with self._transaction():
            self.data["behaviors"]["graphs"] = [g for g in self.data["behaviors"]["graphs"] if g["id"] != behavior_id]

    def move_behavior(self, behavior_id, index):
        """Place la règle à la position `index` de la liste (0 = priorité la plus haute)."""
        graphs = self.data["behaviors"]["graphs"]
        g = self.get_behavior(behavior_id)
        if not 0 <= index < len(graphs):
            raise CreatureError(f"index hors limites (0 à {len(graphs) - 1})")
        with self._transaction():
            graphs.remove(g)
            graphs.insert(index, g)

    def _blocks(self, behavior_id, kind):
        return self.get_behavior(behavior_id).setdefault(kind, [])

    def add_condition(self, behavior_id, condition):
        """Ajoute un bloc SI. Retourne son index."""
        with self._transaction():
            blocks = self._blocks(behavior_id, "conditions")
            blocks.append(copy.deepcopy(condition))
            return len(blocks) - 1

    def set_condition(self, behavior_id, index, condition):
        with self._transaction():
            blocks = self._blocks(behavior_id, "conditions")
            if not 0 <= index < len(blocks):
                raise CreatureError("index de condition hors limites")
            blocks[index] = copy.deepcopy(condition)

    def remove_condition(self, behavior_id, index):
        with self._transaction():
            blocks = self._blocks(behavior_id, "conditions")
            if not 0 <= index < len(blocks):
                raise CreatureError("index de condition hors limites")
            del blocks[index]

    def add_action(self, behavior_id, action):
        """Ajoute un bloc ALORS. Retourne son index."""
        with self._transaction():
            blocks = self._blocks(behavior_id, "actions")
            blocks.append(copy.deepcopy(action))
            return len(blocks) - 1

    def set_action(self, behavior_id, index, action):
        with self._transaction():
            blocks = self._blocks(behavior_id, "actions")
            if not 0 <= index < len(blocks):
                raise CreatureError("index d'action hors limites")
            blocks[index] = copy.deepcopy(action)

    def remove_action(self, behavior_id, index):
        with self._transaction():
            blocks = self._blocks(behavior_id, "actions")
            if not 0 <= index < len(blocks):
                raise CreatureError("index d'action hors limites")
            del blocks[index]

    # ------------------------------------------ sons, effets, capacités (Étape 8)
    def get_sound(self, sound_id):
        for x in self.data["sounds"]:
            if x["id"] == sound_id:
                return x
        raise CreatureError(f"son introuvable: {sound_id}")

    def get_effect(self, effect_id):
        for x in self.data["effects"]:
            if x["id"] == effect_id:
                return x
        raise CreatureError(f"effet introuvable: {effect_id}")

    def add_sound(self, name, sound, volume=1.0, pitch=1.0):
        """`sound` = identifiant de son Minecraft (ex. « mob.zombie.say »). Retourne l'id."""
        self._check_name(name)
        with self._transaction():
            s = {"id": self._new_id("sound", name), "name": name.strip(), "sound": sound, "volume": volume, "pitch": pitch}
            self.data["sounds"].append(s)
            return s["id"]

    def update_sound(self, sound_id, **fields):
        ok = {"name", "sound", "volume", "pitch"}
        if not fields or set(fields) - ok:
            raise CreatureError(f"champs autorisés: {', '.join(sorted(ok))}")
        with self._transaction():
            self.get_sound(sound_id).update(fields)

    def remove_sound(self, sound_id):
        """Supprime le son et les blocs ALORS qui le jouaient ; une capacité qui l'utilisait perd simplement son son."""
        self.get_sound(sound_id)
        with self._transaction():
            self.data["sounds"] = [x for x in self.data["sounds"] if x["id"] != sound_id]
            for g in self.data["behaviors"].get("graphs", []):
                g["actions"] = [a for a in g.get("actions", []) if not (a.get("type") == "playSound" and a.get("soundId") == sound_id)]
                for a in g["actions"]:
                    if a.get("soundId") == sound_id:
                        del a["soundId"]

    def add_effect(self, name, kind="spark", color="#ffffff", count=20, part_id=None):
        self._check_name(name)
        with self._transaction():
            e = {"id": self._new_id("effect", name), "name": name.strip(), "kind": kind, "color": color, "count": count}
            if part_id is not None:
                self.get_part(part_id)
                e["partId"] = part_id
            self.data["effects"].append(e)
            return e["id"]

    def update_effect(self, effect_id, **fields):
        ok = {"name", "kind", "color", "count", "partId"}
        if not fields or set(fields) - ok:
            raise CreatureError(f"champs autorisés: {', '.join(sorted(ok))}")
        with self._transaction():
            e = self.get_effect(effect_id)
            for k, v in fields.items():
                if k == "partId" and v is None:
                    e.pop("partId", None)
                else:
                    e[k] = v

    def remove_effect(self, effect_id):
        self.get_effect(effect_id)
        with self._transaction():
            self.data["effects"] = [x for x in self.data["effects"] if x["id"] != effect_id]
            for g in self.data["behaviors"].get("graphs", []):
                g["actions"] = [a for a in g.get("actions", []) if not (a.get("type") == "effect" and a.get("effectId") == effect_id)]
                for a in g["actions"]:
                    if a.get("effectId") == effect_id:
                        del a["effectId"]

    def select_behavior(self, ctx):
        """Règle active pour ce contexte (voir select_behavior au niveau du module)."""
        return select_behavior(self.data["behaviors"], ctx)
