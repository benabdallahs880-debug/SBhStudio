# CreatureStudio — Format interne

## 1. Identité

Chaque créature possède un `id` stable et un `formatVersion`.

Chaque partie possède également un `id` stable. Un nom peut changer sans casser les références.

## 2. Hiérarchie

`parentId: null` désigne la racine. Une partie enfant hérite de la transformation de son parent.

Règles :
- un seul root ;
- aucun parent inexistant ;
- aucun cycle ;
- un enfant ne doit pas dépendre indirectement de lui-même.

## 3. Transformation

Chaque partie possède :

- `position`: `[x, y, z]` ;
- `rotation`: `[x, y, z]` en degrés dans la représentation actuelle ;
- `scale`: `[x, y, z]`.

Les coordonnées et conventions pourront être adaptées lors d'un export, sans modifier le modèle interne.

## 4. Formes

Les primitives prévues au départ sont :

- `cube`
- `sphere`
- `cylinder`
- `cone`
- `capsule`
- `pyramid` (ajoutée à l'Étape 2)
- `plane` (ajoutée à l'Étape 2)
- `custom`

`custom` réserve le modèle pour une géométrie créée librement lors des étapes suivantes.

## 5. Sockets

Un socket est un point d'attache nommé sur une partie. Exemples futurs : `hand_right`, `head`, `back`, `mouth`, `tail_base`.

Les sockets permettent de brancher des objets sans coder une relation spéciale pour chaque type d'accessoire.

## 6. Extensions futures

Les sections `materials`, `skeleton`, `animations`, `behaviors` et `export` existent déjà dans le contrat afin que les futures étapes puissent s'y raccorder.

Elles ne doivent pas être interprétées comme implémentées tant que leur étape respective n'est pas terminée.

## 7. Pivot, squelette et os (Étape 4)

**Pivot** — champ optionnel `pivot: [x, y, z]` sur une partie (espace local, avant échelle, défaut `[0,0,0]`).
Convention de transformation : un point `v` du maillage va à `position + R·(S∘(v − pivot))` dans l'espace du parent,
R = Rz·Ry·Rx (degrés). Avec un pivot non nul, `position` est donc l'emplacement du pivot. Les anciens fichiers
(sans `pivot`) ne changent pas.

**Squelette** — `skeleton = { "enabled": bool, "bones": [ { "id", "name", "partId", "limits"? } ] }`.
- Un os est attaché à une partie (au plus un os par partie) et articule cette partie autour de son pivot.
- La **hiérarchie des os est déduite** de celle des parties (parent = os de l'ancêtre le plus proche qui en a un) ; elle n'est jamais stockée.
- `limits` (optionnel) : `{ "x": [min, max], "y": [...], "z": [...] }`, degrés, relatives à la pose de repos ; axe absent = libre.
- `enabled` est toujours égal à « il existe au moins un os » (recalculé par le modèle).
- La **pose** (rotation temporaire des os) n'est PAS stockée à l'Étape 4 : les poses nommées et les animations sont l'Étape 6.

## 8. Symétrie (Étape 4 bis)

Champ optionnel `mirror: { "axis": "x"|"y"|"z", "partId": "<id de la jumelle>" }` sur une partie. Le lien est **réciproque**
(la jumelle pointe vers la partie, même axe), un seul jumeau par partie. Il indique quelle partie est l'image miroir de quelle autre ;
il n'oblige à rien : l'utilisateur peut modifier les deux parties indépendamment (la synchronisation n'a lieu que si on la demande).
Plan de symétrie : plan perpendiculaire à `axis` passant par l'origine du **parent** (repère local du parent). Règles de la copie miroir :
`position[axis]` inversée, rotation Euler conjuguée (l'angle autour de `axis` est conservé, les deux autres s'inversent), `pivot[axis]` inversé,
échelle et forme identiques (les primitives sont symétriques), limites d'os : l'axe miroir est conservé, les deux autres sont inversées et permutées (`[lo,hi]` → `[-hi,-lo]`).

## 9. Édition

Les règles d'édition (transactions, ids stables, limites) sont dans `core/operations.md`.

## 10. Matériaux, textures et UV (Étape 5)

**Matière** (`materials[]`) : `{ id, name, color "#rrggbb", opacity 0..1, emissive 0..1, roughness 0..1, textureId|null }`.
Une partie la référence par `materialId` (`null` = pas de matière : couleur automatique de l'éditeur). Une matière peut être **partagée** par plusieurs parties
(modifier la matière modifie toutes ces parties). `opacity` = transparence (1 = opaque), `emissive` = lueur (1 = non assombri par l'éclairage),
`roughness` est **stockée mais pas encore rendue** (utile à l'export, Étape 10).

**Texture** (`textures[]`, champ top-level OPTIONNEL, absent = aucune texture) : `{ id, name, width, height (1 à 256), palette, pixels }`.
`palette` = liste de 1 à 256 couleurs `"#rrggbb"` ou `null` (transparent) ; `pixels` = `width × height` indices dans la palette, ligne par ligne, depuis le coin
haut-gauche. La texture est dessinée **par-dessus** la couleur de la matière (un texel transparent laisse voir la couleur). Une texture neuve est toute transparente
(`palette = [null]`).

**UV** : (u, v) dans [0,1], origine en haut à gauche (v = 0 en haut) ; texel = `(min(W−1, ⌊u·W⌋), min(H−1, ⌊v·H⌋))`. Règles par forme (le générateur `mesh()` de l'éditeur est la
référence ; un port doit reproduire l'ordre des sommets de chaque face, la 1ʳᵉ colonne ci-dessous donne le coin UV du sommet 0, 1, 2, 3 de la face) :
| Forme | Règle |
|---|---|
| `sphere`, `cylinder`, `cone`, `capsule` | 10 segments ; face (anneau *i*, segment *k*) : u de k/10 à (k+1)/10 ; v de `1 − i/(L−1)` à `1 − (i+1)/(L−1)`, L = nombre de points du profil (cylindre 4, cône 3, sphère 7, capsule 8) ; coins `(u0,v0) (u1,v0) (u1,v1) (u0,v1)` ; texture continue, pincée aux pôles |
| `cube`, `custom` | 6 faces dans l'ordre [−z, +z, −x, +x, +y, −y] ; case *c* d'une grille 3×2 : colonne `c mod 3`, ligne `⌊c/3⌋` ; coins `(u0,v1) (u1,v1) (u1,v0) (u0,v0)` |
| `pyramid` | 5 faces (base, 4 côtés) dans les cases 0 à 4 de la même grille ; base = coins de quad comme le cube ; côtés (triangles) : `(u0,v1) (u1,v1) ((u0+u1)/2, v0)` |
| `plane` | 1 face, image entière, coins `(0,1) (1,1) (1,0) (0,0)` |

Exemple : une texture 12×8 donne 3×2 cases de 4×4 texels ; la face +z d'un cube est la case 1 (x 4 à 7, y 0 à 3).
Une partie miroir (`mirror_part`) **partage** la même matière et donc la même texture : l'image n'est pas retournée.

## 11. Poses et animations (Étape 6)

**Pose** : `{ boneId: { "rotation"?: [x,y,z], "position"?: [x,y,z] } }`. Ce sont des **décalages par rapport à la pose de repos** (la transformation du modèle),
rotation en degrés, `position` ajoutée à la position de la partie dans son parent. Un os absent d'une pose vaut « repos » (0). Dans le rendu, la rotation de pose
s'applique après la rotation de repos, autour du pivot : `R = Rpose · Rrepos`.

**Bibliothèque de poses** : `skeleton.poses = [ { id, name, bones: <pose> } ]` (optionnel).

**Animation** (`animations[]`) : `{ id, name, duration (s, > 0), loop (bool), keyframes: [ { time, pose } ] }`. Les `keyframes` sont **strictement triées** par `time`,
chaque `time` dans `[0, duration]`, chaque pose ne référence que des os existants (supprimer un os nettoie les poses et animations).
**Échantillonnage** (référence : `sample_pose` dans `core/creature_model.py`, `samplePose` dans l'éditeur ; les deux sont testés l'un contre l'autre) :
interpolation **linéaire** des angles Euler et des positions entre deux images clés (pas de quaternions : prévoir des angles de moins de 180° entre images clés) ;
sans boucle, la première pose est tenue avant la première clé et la dernière après la dernière ; en boucle, `t` est ramené dans `[0, duration[` et la dernière clé
rejoint la première à `t = duration` (pas besoin de dupliquer la première pose en fin d'animation).
**Animations de base** : l'éditeur les génère d'après les noms (tête, queue, aile, bras, patte/jambe, corps) — Repos, Marche, Course, Saut, Attaque, Dégâts, Mort, Nage, Vol —
et les range dans `animations` comme n'importe quelle animation ; aucun champ ne les distingue ensuite d'une animation faite à la main.

## 12. Caractéristiques et comportements (Étape 7)

`behaviors = { "enabled": bool, "stats": {...}, "graphs": [ <règle>, ... ] }`. `enabled` est **déduit** (vrai s'il existe au moins une règle), comme `skeleton.enabled`.

**Caractéristiques** (`stats`, optionnel, toute clé absente prend la valeur par défaut) :
| Clé | Plage | Défaut | Sens |
|---|---|---|---|
| `health` | 1 à 1000 | 20 | points de vie |
| `damage` | 0 à 100 | 3 | dégâts par attaque |
| `armor` | 0 à 30 | 0 | armure |
| `speed` | 0 à 1 | 0,5 | lent → rapide (valeur normalisée ; l'export la convertira) |
| `jumpHeight` | 0 à 10 | 1 | hauteur de saut, en blocs |
| `detectionRange` | 1 à 64 | 16 | portée de détection du joueur, en blocs |
| `intelligence` | 0 à 1 | 0,5 | réservé (non utilisé par l'aperçu) |

**Règle** (`graphs[]`) : `{ id, name, enabled?, conditions: [...], actions: [...] }`. **L'ordre de la liste est la priorité** (la première = la plus prioritaire, comme les « goals » de Minecraft Bedrock).
La **règle active** est la première règle activée dont **toutes** les conditions (SI) sont vraies ; ses actions (ALORS) s'exécutent **ensemble**. Une règle sans condition est toujours vraie : s'en servir comme règle de repli en dernier.
Référence : `select_behavior` / `evaluate_condition` dans `core/creature_model.py`, `selectBehavior` / `evalCond` dans l'éditeur (testés l'un contre l'autre).

**Conditions** (`type` + paramètres ; `"not": true` inverse n'importe laquelle) :
`playerDetected` (joueur à portée de `detectionRange`) · `distance` `{op: < <= > >=, value ≥ 0}` (distance au joueur ; faux sans joueur) · `time` `{is: "day"|"night"}` ·
`healthBelow` `{percent 0..100}` (vie strictement en dessous) · `attacked` (vient d'être attaqué) · `inWater` · `random` `{chance 0..1}` (tirage strictement inférieur à `chance`).
**Actions** : `chase` · `flee` · `wander` `{speed 0..5 = multiplicateur, défaut 1}` · `idle` · `attack` `{cooldown ≥ 0 s, range > 0}` · `jump` · `playAnimation`.
Toute action peut porter `animationId` (id d'une animation existante ; supprimer l'animation retire la référence). **Au plus une action de déplacement** (`chase`, `flee`, `wander`, `idle`) par règle.
Ces actions et conditions ont été choisies pour se traduire directement en composants de comportement Bedrock à l'Étape 10 ; elles ne contiennent aucun code.


## 13. Sons, effets et capacités spéciales (Étape 8)

Deux listes **facultatives** au niveau racine (absentes = vides ; les anciens fichiers restent valides) :
- `sounds[]` : `{ id, name, sound, volume? 0..1 (défaut 1), pitch? 0.5..2 (défaut 1) }`. `sound` est un **identifiant de son Minecraft** (ex. `mob.zombie.say`) saisi tel quel ; l'existence réelle du son sera revérifiée à l'Étape 9/10.
- `effects[]` : `{ id, name, kind, color? "#rrggbb", count? 1..200, partId? }`. `kind` ∈ `fire, ice, spark, smoke, poison, heart, magic, explosion`. `partId` = partie d'où part l'effet (absent = centre) ; si la partie est supprimée, `partId` est retiré automatiquement.

Les ids de sons et d'effets partagent l'espace d'identifiants des autres éléments (pas de doublon entre sons et effets).

Nouvelles **actions** (dans `behaviors.graphs[].actions[]`) ; aucune n'est une action de déplacement, elles se combinent donc avec `chase`/`flee`/… :
| Action | Paramètres | Sens |
|---|---|---|
| `playSound` | `soundId` (obligatoire, doit exister) | joue le son à l'activation de la règle |
| `effect` | `effectId` (obligatoire, doit exister) | lance l'effet à l'activation de la règle |
| `ability` | `ability` ∈ `fire, ice, lightning, poison, explosion, teleport, shield, invisibility, heal` ; `power` 0..20 (déf. 3) ; `duration` 0..60 s (déf. 3) ; `cooldown` ≥ 0 s (déf. 5) ; `range` > 0 (déf. 8, capacités offensives) ; `effectId?` ; `soundId?` | capacité spéciale avec recharge |

Sens dans l'aperçu (simulateur, hors format) : `fire`/`lightning` = `power` dégâts ; `explosion` = dégâts + joueur repoussé de 3 blocs ; `poison` = `power` dégâts répartis sur `duration` ; `ice` = `power/2` dégâts + joueur ralenti `duration` s ; `teleport` = la créature se place à 2 blocs derrière le joueur ; `shield` = invulnérabilité de la créature `duration` s ; `invisibility` = demi-transparence ; `heal` = rend `2 × power` PV. Les capacités offensives exigent un joueur à portée (`range`).
**Piège** : une règle reste active tant que ses conditions sont vraies, même si sa capacité est en recharge. Une règle de capacité doit donc **aussi porter une action de mouvement** (ex. `chase`) pour que la créature ne reste pas figée (fait pour le Chef et HIPPO III).
Référence : `valid_action`, blocs `sounds`/`effects` de `tools/validate_creature.py` ; `validAction`, `check`, `simStep` dans l'éditeur.

## 14. Diagnostics (Étape 9)

Les diagnostics ne font **pas** partie du format : ils sont calculés à la volée par `diagnose(data)` (`core/diagnostics.py`, miroir JS `diagnose` dans l'éditeur). Ils signalent ce qui est **valide mais probablement faux ou inexportable**, là où le validateur ne refuse que ce qui est structurellement invalide.
Sortie : liste d'éléments `{severity: error|warning|info, code, message (français), ref: {kind, id}}`, triée par gravité, code, id. `error` = l'export serait cassé ; `warning` = comportement probablement non voulu ; `info` = amélioration possible. Aucun diagnostic ne bloque l'enregistrement.

| Code | Gravité | Sens |
|---|---|---|
| `D001` | warning | partie sans matière |
| `D002` | error | dimension nulle ou négative |
| `D003` | warning | noms de parties en double |
| `D004` | warning | angle d'animation/pose hors des limites de l'os |
| `D005` | info | animation sans image clé |
| `D006` | info | jumelle miroir désynchronisée |
| `D010` | warning | aucune règle de repli |
| `D011` | warning | règle inatteignable |
| `D012` | warning | capacité sans mouvement : le personnage se figera pendant la recharge |
| `D013` | warning | règle sans action |
| `D014` | info | mouvement sans animation |
| `D015` | warning | poursuite avec vitesse nulle |
| `D016` | info | dégâts sans action d'attaque |
| `D017` | info | condition de distance au-delà de la portée de détection |
| `D020` | warning | identifiant de son douteux (attendu : minuscules, chiffres, « . » et « _ ») |
| `D021` | info | son non utilisé |
| `D022` | info | effet non utilisé |
| `D030` | info | matière non utilisée |
| `D031` | info | texture non utilisée |
| `D032` | info | texture vide |
| `D033` | info | dimensions de texture qui ne sont pas des puissances de 2 |
| `D040` | warning | squelette sans os alors que des animations existent |
| `D041` | info | os sans limites |
| `D050` | info | forme qui sera exportée en boîte englobante (Bedrock ne dessine que des boîtes) |
| `D051` | warning | partie tournée sous un parent à échelle non uniforme : position fausse dans Bedrock |
| `D052` | info | matière avec lueur ou transparence : non exportée |

Ligne de commande : `python tools/diagnose_creature.py fichier.creature.json [--strict]` (code de sortie 1 s'il y a une erreur, ou un avertissement avec `--strict`).
Les personnages livrés (Soldat standard, HIBOU) doivent rester sans erreur ni avertissement (testé).
