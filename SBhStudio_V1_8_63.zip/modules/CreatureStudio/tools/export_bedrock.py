#!/usr/bin/env python3
"""Exporte une créature vers Minecraft Bedrock (RP + BP + .mcaddon).

    python tools/export_bedrock.py examples/hibou_chef.creature.json --out sortie/ [--namespace sbh]

Écrit aussi EXPORT_REPORT.json (approximations et éléments non exportés). Voir docs/BEDROCK_EXPORT.md.
"""
import argparse, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
from bedrock_export import export_bedrock  # noqa: E402

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("creature"); ap.add_argument("--out", default="export"); ap.add_argument("--namespace", default="sbh")
    a = ap.parse_args()
    rep = export_bedrock(json.loads(Path(a.creature).read_text(encoding="utf-8")), a.out, a.namespace)
    print(f"Exporté : {rep['identifier']} — {rep['bones']} os, texture {rep['texture'][0]}×{rep['texture'][1]}, {len(rep['animations'])} animation(s)")
    for k in ("approximations", "warnings"):
        for x in rep[k]:
            print(("≈ " if k == "approximations" else "▲ ") + x)
    print("Fichiers :", ", ".join(rep["files"][-3:]), "…")
