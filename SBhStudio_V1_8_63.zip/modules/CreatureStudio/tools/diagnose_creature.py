#!/usr/bin/env python3
"""Diagnostic d'un projet : python tools/diagnose_creature.py fichier.creature.json [--strict]
Code de sortie : 1 s'il y a une erreur (ou un avertissement avec --strict), 0 sinon."""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from diagnostics import diagnose, summary  # noqa: E402

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        sys.exit(__doc__)
    d = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    err, _ = validate_creature.check(d)
    if err:
        print("INVALIDE :", err); sys.exit(1)
    items = diagnose(d)
    icon = {"error": "✖", "warning": "▲", "info": "·"}
    for i in items:
        print(f"{icon[i['severity']]} {i['code']} {i['message']}")
    n = summary(items)
    print(f"{n['error']} erreur(s), {n['warning']} avertissement(s), {n['info']} info(s)")
    sys.exit(1 if n["error"] or ("--strict" in sys.argv and n["warning"]) else 0)
