#!/usr/bin/env python3
"""Dependency-free structural validator for CreatureStudio projects.

Étape 2 : la logique a été extraite dans `check(data)` pour être réutilisée par
`core/creature_model.py`. Le comportement en ligne de commande est inchangé
(mêmes messages, mêmes codes de sortie). Formes ajoutées : `pyramid`, `plane`.
Étape 4 : `pivot` optionnel sur les parties ; validation de `skeleton.bones` (os, limites).
Étape 4 bis : `mirror` optionnel sur les parties (lien de symétrie réciproque).
Étape 5 : validation de `materials` (couleur, opacité, lueur, rugosité, texture), de `textures` (optionnel, palette + pixels)
et des références `materialId`.
Étape 7 : validation de `behaviors` (caractéristiques `stats`, règles `graphs` : conditions et actions).
Étape 6 : validation de `animations` (durée, boucle, images clés triées) et de la bibliothèque `skeleton.poses`.
"""
import json, re, sys

ALLOWED_SHAPES = {"cube", "sphere", "cylinder", "cone", "capsule", "pyramid", "plane", "custom"}
HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
TOP_LEVEL = ["formatVersion", "project", "creature", "parts", "sockets", "materials", "skeleton", "animations", "behaviors", "export"]

def valid_vec(v, label=""):
    return isinstance(v, list) and len(v) == 3 and all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in v)

def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)

def valid_pose(pose, bone_ids):
    """pose = { boneId: { "rotation"?: [x,y,z], "position"?: [x,y,z] } } ; décalages par rapport à la pose de repos."""
    if not isinstance(pose, dict): return False
    for bid, v in pose.items():
        if bid not in bone_ids or not isinstance(v, dict) or set(v) - {"rotation", "position"}: return False
        if not all(valid_vec(x) for x in v.values()): return False
    return True

def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and v == v and abs(v) != float("inf")

STAT_RANGES = {"health": (1, 1000), "damage": (0, 100), "armor": (0, 30), "speed": (0, 1),
               "jumpHeight": (0, 10), "detectionRange": (1, 64), "intelligence": (0, 1)}
MOVE_ACTIONS = ("chase", "flee", "wander", "idle")
ABILITIES = ("fire", "ice", "lightning", "poison", "explosion", "teleport", "shield", "invisibility", "heal")   # Étape 8
EFFECT_KINDS = ("fire", "ice", "spark", "smoke", "poison", "heart", "magic", "explosion")
_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")

def valid_condition(c):
    if not isinstance(c, dict) or ("not" in c and not isinstance(c["not"], bool)): return False
    t = c.get("type")
    if t in ("playerDetected", "attacked", "inWater"): return True
    if t == "distance": return c.get("op") in ("<", "<=", ">", ">=") and _is_num(c.get("value")) and c["value"] >= 0
    if t == "time": return c.get("is") in ("day", "night")
    if t == "healthBelow": return _is_num(c.get("percent")) and 0 <= c["percent"] <= 100
    if t == "random": return _is_num(c.get("chance")) and 0 <= c["chance"] <= 1
    return False

def valid_action(a, anim_ids, sound_ids=frozenset(), effect_ids=frozenset()):
    if not isinstance(a, dict): return False
    if "animationId" in a and a["animationId"] not in anim_ids: return False
    t = a.get("type")
    if t in ("chase", "flee", "wander"): return "speed" not in a or (_is_num(a["speed"]) and 0 <= a["speed"] <= 5)
    if t == "attack":
        return ("cooldown" not in a or (_is_num(a["cooldown"]) and a["cooldown"] >= 0)) and ("range" not in a or (_is_num(a["range"]) and a["range"] > 0))
    if t == "playSound": return a.get("soundId") in sound_ids
    if t == "effect": return a.get("effectId") in effect_ids
    if t == "ability":
        return (a.get("ability") in ABILITIES and ("power" not in a or (_is_num(a["power"]) and 0 <= a["power"] <= 20))
                and ("duration" not in a or (_is_num(a["duration"]) and 0 <= a["duration"] <= 60))
                and ("cooldown" not in a or (_is_num(a["cooldown"]) and a["cooldown"] >= 0))
                and ("range" not in a or (_is_num(a["range"]) and a["range"] > 0))
                and ("effectId" not in a or a["effectId"] in effect_ids) and ("soundId" not in a or a["soundId"] in sound_ids))
    return t in ("idle", "jump", "playAnimation")

def valid_limits(lim):
    """limits = {"x": [min, max], "y": [...], "z": [...]} en degrés ; axe absent = libre."""
    if not isinstance(lim, dict): return False
    for axis, r in lim.items():
        if axis not in ("x", "y", "z"): return False
        if not (isinstance(r, list) and len(r) == 2 and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in r) and r[0] <= r[1]):
            return False
    return True

def check(d):
    """Retourne (message_erreur | None, id_racine | None, sans effet de bord)."""
    if not isinstance(d, dict):
        return "project must be a JSON object", None
    for key in TOP_LEVEL:
        if key not in d: return f"missing top-level field: {key}", None
    if d["formatVersion"] != "1.0": return "unsupported formatVersion", None
    if not isinstance(d["parts"], list) or not d["parts"]: return "parts must be a non-empty array", None

    ids = [p.get("id") for p in d["parts"]]
    if any(not isinstance(i, str) or not i for i in ids): return "every part needs a non-empty id", None
    if len(ids) != len(set(ids)): return "duplicate part id", None
    part_map = {p["id"]: p for p in d["parts"]}

    roots = []
    for p in d["parts"]:
        if p.get("parentId") is None:
            roots.append(p["id"])
        elif p["parentId"] not in part_map:
            return f"part {p['id']} references missing parent {p['parentId']}", None
        if p.get("shape") not in ALLOWED_SHAPES:
            return f"part {p.get('id')} has invalid shape", None
        t = p.get("transform", {})
        for k in ("position", "rotation", "scale"):
            if not valid_vec(t.get(k), f"{p['id']}.{k}"):
                return f"invalid transform {k} on part {p['id']}", None
        if "pivot" in p and not valid_vec(p["pivot"]):
            return f"invalid pivot on part {p['id']}", None

    if len(roots) != 1: return f"expected exactly one root, found {len(roots)}", None
    if d["creature"].get("rootPartId") != roots[0]: return "creature.rootPartId does not match the root part", None

    for start in ids:
        seen = set()
        cur = start
        while cur is not None:
            if cur in seen: return f"hierarchy cycle detected from {start}", None
            seen.add(cur)
            cur = part_map[cur].get("parentId")

    socket_ids = set()
    for s in d["sockets"]:
        if s.get("id") in socket_ids: return f"duplicate socket id: {s.get('id')}", None
        socket_ids.add(s.get("id"))
        if s.get("partId") not in part_map: return f"socket {s.get('id')} references missing part", None
        t = s.get("transform", {})
        for k in ("position", "rotation", "scale"):
            if not valid_vec(t.get(k), f"socket.{k}"):
                return f"invalid socket transform {k} on {s.get('id')}", None

    sk = d["skeleton"]
    if not isinstance(sk, dict): return "skeleton must be an object", None
    bones = sk.get("bones", [])
    if not isinstance(bones, list): return "skeleton.bones must be an array", None
    bone_ids, bone_parts = set(), set()
    for b in bones:
        if not isinstance(b, dict): return "every bone must be an object", None
        bid = b.get("id")
        if not isinstance(bid, str) or not bid: return "every bone needs a non-empty id", None
        if bid in bone_ids: return f"duplicate bone id: {bid}", None
        bone_ids.add(bid)
        if b.get("partId") not in part_map: return f"bone {bid} references missing part", None
        if b["partId"] in bone_parts: return f"part {b['partId']} has more than one bone", None
        bone_parts.add(b["partId"])
        if "limits" in b and not valid_limits(b["limits"]): return f"invalid limits on bone {bid}", None
    poses = sk.get("poses", [])
    if not isinstance(poses, list): return "skeleton.poses must be an array", None
    pose_ids = set()
    for po in poses:
        if not isinstance(po, dict) or not isinstance(po.get("id"), str) or not po["id"]: return "every pose needs a non-empty id", None
        if po["id"] in pose_ids: return f"duplicate pose id: {po['id']}", None
        pose_ids.add(po["id"])
        if not isinstance(po.get("name"), str) or not po["name"]: return f"every pose needs a name ({po['id']})", None
        if not valid_pose(po.get("bones"), bone_ids): return f"invalid pose {po['id']}", None

    for p in d["parts"]:
        if "mirror" in p:
            mm = p["mirror"]
            if not isinstance(mm, dict) or mm.get("axis") not in ("x", "y", "z"): return f"invalid mirror on part {p['id']}", None
            if mm.get("partId") not in part_map or mm["partId"] == p["id"]: return f"mirror of part {p['id']} references a missing part or itself", None
            back = part_map[mm["partId"]].get("mirror")
            if not isinstance(back, dict) or back.get("partId") != p["id"] or back.get("axis") != mm["axis"]:
                return f"mirror link of part {p['id']} is not reciprocal", None

    anims = d["animations"]
    if not isinstance(anims, list): return "animations must be an array", None
    # sons et effets (Étape 8) — facultatifs
    sounds, effects = d.get("sounds", []), d.get("effects", [])
    if not isinstance(sounds, list): return "sounds must be an array", None
    sound_ids = set()
    for so in sounds:
        if not isinstance(so, dict) or not isinstance(so.get("id"), str) or not so["id"]: return "every sound needs a non-empty id", None
        if so["id"] in sound_ids: return f"duplicate sound id: {so['id']}", None
        sound_ids.add(so["id"])
        if not isinstance(so.get("name"), str) or not so["name"]: return f"every sound needs a name ({so['id']})", None
        if not isinstance(so.get("sound"), str) or not so["sound"].strip(): return f"sound {so['id']} needs a sound identifier", None
        if "volume" in so and not (_is_num(so["volume"]) and 0 <= so["volume"] <= 1): return f"invalid volume on sound {so['id']}", None
        if "pitch" in so and not (_is_num(so["pitch"]) and 0.5 <= so["pitch"] <= 2): return f"invalid pitch on sound {so['id']}", None
    if not isinstance(effects, list): return "effects must be an array", None
    effect_ids = set()
    for ef in effects:
        if not isinstance(ef, dict) or not isinstance(ef.get("id"), str) or not ef["id"]: return "every effect needs a non-empty id", None
        if ef["id"] in effect_ids or ef["id"] in sound_ids: return f"duplicate effect id: {ef['id']}", None
        effect_ids.add(ef["id"])
        if not isinstance(ef.get("name"), str) or not ef["name"]: return f"every effect needs a name ({ef['id']})", None
        if ef.get("kind") not in EFFECT_KINDS: return f"invalid kind on effect {ef['id']}", None
        if "color" in ef and not (isinstance(ef["color"], str) and _HEX.match(ef["color"])): return f"invalid color on effect {ef['id']}", None
        if "count" in ef and not (_is_int(ef["count"]) and 1 <= ef["count"] <= 200): return f"invalid count on effect {ef['id']}", None
        if "partId" in ef and ef["partId"] not in set(ids): return f"effect {ef['id']} references missing part", None
    anim_ids = set()
    for a in anims:
        if not isinstance(a, dict) or not isinstance(a.get("id"), str) or not a["id"]: return "every animation needs a non-empty id", None
        if a["id"] in anim_ids: return f"duplicate animation id: {a['id']}", None
        anim_ids.add(a["id"])
        if not isinstance(a.get("name"), str) or not a["name"]: return f"every animation needs a name ({a['id']})", None
        dur = a.get("duration")
        if not (_is_num(dur) and dur > 0): return f"invalid duration on animation {a['id']}", None
        if "loop" in a and not isinstance(a["loop"], bool): return f"invalid loop on animation {a['id']}", None
        keys = a.get("keyframes", [])
        if not isinstance(keys, list): return f"keyframes of animation {a['id']} must be an array", None
        prev = -1
        for k in keys:
            if not isinstance(k, dict) or not _is_num(k.get("time")) or not (0 <= k["time"] <= dur) or k["time"] <= prev:
                return f"invalid keyframe time on animation {a['id']}", None
            prev = k["time"]
            if not valid_pose(k.get("pose"), bone_ids): return f"invalid pose in animation {a['id']}", None

    bh = d["behaviors"]
    if not isinstance(bh, dict): return "behaviors must be an object", None
    stats = bh.get("stats", {})
    if not isinstance(stats, dict): return "behaviors.stats must be an object", None
    for k, v in stats.items():
        if k not in STAT_RANGES or not (_is_num(v) and STAT_RANGES[k][0] <= v <= STAT_RANGES[k][1]): return f"invalid stat {k}", None
    graphs = bh.get("graphs", [])
    if not isinstance(graphs, list): return "behaviors.graphs must be an array", None
    beh_ids = set()
    for g in graphs:
        if not isinstance(g, dict) or not isinstance(g.get("id"), str) or not g["id"]: return "every behavior needs a non-empty id", None
        gid = g["id"]
        if gid in beh_ids: return f"duplicate behavior id: {gid}", None
        beh_ids.add(gid)
        if not isinstance(g.get("name"), str) or not g["name"]: return f"every behavior needs a name ({gid})", None
        if "enabled" in g and not isinstance(g["enabled"], bool): return f"invalid enabled on behavior {gid}", None
        conds, acts = g.get("conditions", []), g.get("actions", [])
        if not isinstance(conds, list): return f"behavior {gid}: conditions must be an array", None
        for i, c in enumerate(conds):
            if not valid_condition(c): return f"behavior {gid}: invalid condition {i}", None
        if not isinstance(acts, list): return f"behavior {gid}: actions must be an array", None
        for i, a in enumerate(acts):
            if not valid_action(a, anim_ids, sound_ids, effect_ids): return f"behavior {gid}: invalid action {i}", None
        if sum(1 for a in acts if a["type"] in MOVE_ACTIONS) > 1: return f"behavior {gid}: more than one movement action", None

    mats = d["materials"]
    if not isinstance(mats, list): return "materials must be an array", None
    texs = d.get("textures", [])
    if not isinstance(texs, list): return "textures must be an array", None
    tex_ids = set()
    for t in texs:
        if not isinstance(t, dict) or not isinstance(t.get("id"), str) or not t["id"]: return "every texture needs a non-empty id", None
        if t["id"] in tex_ids: return f"duplicate texture id: {t['id']}", None
        tex_ids.add(t["id"])
        w, h = t.get("width"), t.get("height")
        if not (_is_int(w) and _is_int(h) and 1 <= w <= 256 and 1 <= h <= 256): return f"invalid size on texture {t['id']}", None
        pal = t.get("palette")
        if not (isinstance(pal, list) and 1 <= len(pal) <= 256 and all(c is None or (isinstance(c, str) and HEX.match(c)) for c in pal)):
            return f"invalid palette on texture {t['id']}", None
        px = t.get("pixels")
        if not (isinstance(px, list) and len(px) == w * h and all(_is_int(i) and 0 <= i < len(pal) for i in px)):
            return f"invalid pixels on texture {t['id']}", None
    mat_ids = set()
    for m in mats:
        if not isinstance(m, dict) or not isinstance(m.get("id"), str) or not m["id"]: return "every material needs a non-empty id", None
        if m["id"] in mat_ids: return f"duplicate material id: {m['id']}", None
        mat_ids.add(m["id"])
        if not (isinstance(m.get("color"), str) and HEX.match(m["color"])): return f"invalid color on material {m['id']}", None
        for k in ("opacity", "emissive", "roughness"):
            if k in m and not (isinstance(m[k], (int, float)) and not isinstance(m[k], bool) and 0 <= m[k] <= 1):
                return f"invalid {k} on material {m['id']}", None
        if m.get("textureId") is not None and m["textureId"] not in tex_ids: return f"material {m['id']} references missing texture", None
    for p in d["parts"]:
        if p.get("materialId") is not None and p["materialId"] not in mat_ids:
            return f"part {p['id']} references missing material {p['materialId']}", None
    return None, roots[0]

def main(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:
        print(f"ERROR: cannot read JSON: {e}")
        return False
    error, root = check(d)
    if error:
        print(f"ERROR: {error}")
        return False
    print(f"OK: {path}")
    print(f"  parts: {len(d['parts'])}")
    print(f"  sockets: {len(d['sockets'])}")
    print(f"  root: {root}")
    print("  hierarchy: valid")
    print(f"  bones: {len(d['skeleton'].get('bones', []))}")
    return True

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python tools/validate_creature.py <project.creature.json>")
        sys.exit(2)
    sys.exit(0 if main(sys.argv[1]) else 1)
