#!/usr/bin/env python3
"""Aperçu PNG de plusieurs personnages côte à côte (face, puis trois-quarts), pour comparer des variantes.

    python tools/render_lineup.py sortie.png a.creature.json b.creature.json ... [--views face,34,dos]
"""
import math, sys
from pathlib import Path
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
from render_preview import faces_from_editor, render_view  # noqa: E402

VIEWS = {"face": (0.0, 0.0), "34": (0.6, 0.25), "profil": (math.pi / 2, 0.0), "dos": (math.pi, 0.0)}


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    views = ["face", "34"]
    for a in sys.argv[1:]:
        if a.startswith("--views="):
            views = a.split("=", 1)[1].split(",")
    if len(args) < 2:
        raise SystemExit(__doc__)
    out, files = args[0], args[1:]
    size = (300, 520)
    rows = []
    for v in views:
        tiles = []
        for f in files:
            data = faces_from_editor(f)
            ys = [p[1] for fc in data["faces"] for p in fc["pts"]]
            height = max(ys) - min(ys)
            zoom = 0.88 * size[1] * 7.5 / (min(size) * 1.25 * max(height, 1e-6))
            tiles.append(render_view(data, *VIEWS[v], size=size, center=(0, (min(ys) + max(ys)) / 2, 0), zoom=zoom))
        rows.append(tiles)
    sheet = Image.new("RGB", (size[0] * len(files), size[1] * len(rows)))
    for j, tiles in enumerate(rows):
        for i, t in enumerate(tiles):
            sheet.paste(t, (i * size[0], j * size[1]))
    sheet.save(out)
    print(f"aperçu : {out} ({sheet.width}×{sheet.height})")


if __name__ == "__main__":
    main()
