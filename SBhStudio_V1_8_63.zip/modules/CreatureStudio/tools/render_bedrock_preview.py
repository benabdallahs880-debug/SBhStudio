#!/usr/bin/env python3
"""Aperçu d'un export Bedrock, dessiné DEPUIS les fichiers exportés (géométrie + texture PNG), pour contrôler l'export indépendamment du format source.

    python tools/render_bedrock_preview.py export/le_chef_RP out.png [--yaw 0] [--views 0,150]

Mêmes conventions que l'export (docs/BEDROCK_EXPORT.md) : angles Bedrock = (−x, y, −z) des angles du format ; faces : north −z, south +z, west −x, east +x ; orientation des UV « boîte dépliée ».
"""
import json, math, sys
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
from creature_model import rotation_matrix  # noqa: E402

# face -> (coin haut-gauche (choix min/max par axe), axe u (+/-), axe v (+/-)) ; voir le docstring de build_geometry
FACES = {"north": (("min", "max", "min"), (1, 0, 0), (0, -1, 0)), "south": (("max", "max", "max"), (-1, 0, 0), (0, -1, 0)),
         "west": (("min", "max", "max"), (0, 0, -1), (0, -1, 0)), "east": (("max", "max", "min"), (0, 0, 1), (0, -1, 0)),
         "up": (("min", "max", "max"), (1, 0, 0), (0, 0, -1)), "down": (("min", "min", "min"), (1, 0, 0), (0, 0, 1))}
NORMAL = {"north": (0, 0, -1), "south": (0, 0, 1), "west": (-1, 0, 0), "east": (1, 0, 0), "up": (0, 1, 0), "down": (0, -1, 0)}


def mv(R, v):
    return [sum(R[i][j] * v[j] for j in range(3)) for i in range(3)]


def chain(bones, name):
    out = []
    while name:
        out.append(bones[name]); name = bones[name].get("parent")
    return out                                  # de la feuille vers la racine


def to_world(bones, name, p):
    for b in chain(bones, name):
        r = b.get("rotation", [0, 0, 0]); pv = b["pivot"]
        d = mv(rotation_matrix([-r[0], r[1], -r[2]]), [p[i] - pv[i] for i in range(3)])
        p = [pv[i] + d[i] for i in range(3)]
    return p


def render(rp_dir, out, yaw_deg=0.0, scale=None, size=(300, 520)):
    rp = Path(rp_dir)
    geo = json.loads(next((rp / "models" / "entity").glob("*.geo.json")).read_text(encoding="utf-8"))["minecraft:geometry"][0]
    tex = Image.open(next((rp / "textures").rglob("*.png"))).convert("RGBA")
    bones = {b["name"]: b for b in geo["bones"]}
    top = max(c["origin"][1] + c["size"][1] for b in geo["bones"] for c in b["cubes"])
    sc = scale or (size[1] - 40) / top
    img = Image.new("RGB", size, (30, 30, 36)); dr = ImageDraw.Draw(img)
    yaw = math.radians(yaw_deg); cy, sy = math.cos(yaw), math.sin(yaw)
    quads = []
    for b in geo["bones"]:
        for c in b["cubes"]:
            lo, hi = c["origin"], [c["origin"][i] + c["size"][i] for i in range(3)]
            for face, uv in c["uv"].items():
                if uv["uv_size"] == [0, 0]:
                    continue
                (cx, cy_, cz), ua, va = FACES[face]
                tl = [lo[i] if m == "min" else hi[i] for i, m in enumerate((cx, cy_, cz))]
                du = [ua[i] * c["size"][i] for i in range(3)]; dv = [va[i] * c["size"][i] for i in range(3)]
                nx, ny = max(1, min(24, round(uv["uv_size"][0]))), max(1, min(24, round(uv["uv_size"][1])))
                for j in range(ny):
                    for i in range(nx):
                        pts = []
                        for (a, bb) in ((i, j), (i + 1, j), (i + 1, j + 1), (i, j + 1)):
                            q = [tl[k] + du[k] * a / nx + dv[k] * bb / ny for k in range(3)]
                            pts.append(to_world(bones, b["name"], q))
                        tu = uv["uv"][0] + (i + .5) * uv["uv_size"][0] / nx; tv = uv["uv"][1] + (j + .5) * uv["uv_size"][1] / ny
                        px = tex.getpixel((min(tex.width - 1, int(tu)), min(tex.height - 1, int(tv))))
                        n = mv(rotation_matrix([0, 0, 0]), NORMAL[face])
                        quads.append((pts, px, face))
    def proj(p):
        x, z = p[0] * cy + p[2] * sy, -p[0] * sy + p[2] * cy
        return (size[0] / 2 - x * sc, size[1] - 20 - p[1] * sc, z)
    items = []
    for pts, px, face in quads:
        P = [proj(p) for p in pts]
        # face vue de dos ? (aire signée) — on la saute ; sinon profondeur moyenne (z grand = loin dans cette projection)
        area = sum(P[k][0] * P[(k + 1) % 4][1] - P[(k + 1) % 4][0] * P[k][1] for k in range(4))
        if area == 0:
            continue
        items.append((sum(p[2] for p in P) / 4, area, P, px, face))
    items.sort(key=lambda t: -t[0])
    front_sign = None
    for z, area, P, px, face in items:
        shade = {"up": 1.0, "north": .92, "south": .8, "east": .85, "west": .85, "down": .6}[face]
        if px[3] == 0:
            continue
        dr.polygon([(p[0], p[1]) for p in P], fill=tuple(int(c * shade) for c in px[:3]))
    img.save(out)
    return img


if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    if len(a) < 2:
        sys.exit(__doc__)
    views = [float(v) for v in next((x.split("=")[1] for x in sys.argv if x.startswith("--views=")), "0").split(",")]
    tiles = []
    for v in views:
        tiles.append(render(a[0], a[1], v))
    if len(tiles) > 1:
        W = sum(t.width for t in tiles); out = Image.new("RGB", (W, tiles[0].height)); x = 0
        for t in tiles:
            out.paste(t, (x, 0)); x += t.width
        out.save(a[1])
