#!/usr/bin/env python3
"""Aperçu PNG d'un projet CreatureStudio (4 vues : face, trois-quarts, profil, dos), sans navigateur.

Utilise le MÊME code que l'éditeur (maillages, matrices, pivots, UV) en l'exécutant avec Node, puis dessine avec Pillow (peintre + textures).
Dépendances : Node.js, Pillow, numpy (outil de développement, pas nécessaire au format).

    python tools/render_preview.py examples/soldat_standard.creature.json docs/preview_soldat_standard.png
    python tools/render_preview.py projet.creature.json sortie.png Marche@0.25      # pose d'une animation à t = 0,25 s
"""
import json, math, subprocess, sys, tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "editor" / "creature_editor.html").read_text(encoding="utf-8")
CORE = HTML.split("// ==CORE==")[1].split("// ==ENDCORE==")[0]
RENDER = HTML.split("// ---- rendu")[1].split("// ---- application")[0].split("\n", 1)[1]

JS = r"""
const fs=require('fs');const P=new Project(JSON.parse(fs.readFileSync(process.argv[2],'utf8')));
const pose={},poseP={};
if(process.argv[3]){const[an,t]=process.argv[3].split('@');const A=P.d.animations.find(a=>a.name===an);if(!A)throw Error('animation introuvable: '+an);
 const s=P.sample(A.id,+t);for(const b of P.d.skeleton.bones){const e=s[b.id];if(!e)continue;if(e.rotation)pose[b.partId]=e.rotation;if(e.position)poseP[b.partId]=e.position}}
const W=worlds(P.d,pose,poseP),faces=[];
for(const p of P.d.parts){const m=mesh(p),mt=p.materialId?P.d.materials.find(x=>x.id===p.materialId):null;
 m.f.forEach((f,fi)=>faces.push({pts:f.map(i=>tp(W[p.id],m.v[i])),uv:m.uv[fi],color:mt?mt.color:null,tex:mt&&mt.textureId?mt.textureId:null,em:mt?mt.emissive||0:0,hue:(P.d.parts.indexOf(p)*67)%360}))}
console.log(JSON.stringify({faces,textures:P.d.textures}));
"""


def faces_from_editor(project, pose=None):
    with tempfile.TemporaryDirectory() as d:
        js = Path(d) / "r.js"
        js.write_text(CORE + RENDER + JS, encoding="utf-8")
        args = ["node", str(js), str(project)] + ([pose] if pose else [])
        r = subprocess.run(args, capture_output=True, text=True)
        if r.returncode:
            raise SystemExit(r.stderr[-1500:])
        return json.loads(r.stdout)


def hex_rgb(h):
    return [int(h[i:i + 2], 16) for i in (1, 3, 5)]


def render_view(data, yaw, pitch, size=(380, 600), dist=7.5, zoom=1.0, center=(0, 0, 0)):
    W, H = size
    img = Image.new("RGB", size, (28, 30, 36))
    draw = ImageDraw.Draw(img)
    f = min(W, H) * 1.25 * zoom
    cy, sy, cp, sp = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch)
    light = np.array([0.3, 0.5, -0.8]); light /= np.linalg.norm(light)
    textures = {}
    for t in data["textures"]:
        pal = [None if c is None else hex_rgb(c) for c in t["palette"]]
        arr = np.zeros((t["height"], t["width"], 4), dtype=np.uint8)
        for i, pi in enumerate(t["pixels"]):
            if pal[pi] is not None:
                arr[i // t["width"], i % t["width"]] = pal[pi] + [255]
        textures[t["id"]] = arr

    def view(p):
        x, y, z = p[0] - center[0], p[1] - center[1], p[2] - center[2]
        x2, z2 = x * cy + z * sy, -x * sy + z * cy
        return np.array([x2, y * cp - z2 * sp, y * sp + z2 * cp + dist])

    faces = []
    for fc in data["faces"]:
        q = [view(p) for p in fc["pts"]]
        n = np.zeros(3)
        for i, a in enumerate(q):
            b = q[(i + 1) % len(q)]
            n += [(a[1] - b[1]) * (a[2] + b[2]), (a[2] - b[2]) * (a[0] + b[0]), (a[0] - b[0]) * (a[1] + b[1])]
        ln = np.linalg.norm(n)
        if ln < 1e-9 or any(a[2] < 0.2 for a in q):
            continue
        dot = abs(float(n @ light) / ln)
        faces.append((sum(a[2] for a in q) / len(q), dot, fc, [(W / 2 + f * a[0] / a[2], H * 0.52 - f * a[1] / a[2]) for a in q]))
    faces.sort(key=lambda t: -t[0])
    for _, dot, fc, pts in faces:
        b0 = 0.35 + 0.65 * dot
        sh = min(1.0, b0 + (1 - b0) * fc["em"])
        base = hex_rgb(fc["color"]) if fc["color"] else [int(c * 255) for c in __import__("colorsys").hls_to_rgb(fc["hue"] / 360, 0.5, 0.5)]
        draw.polygon(pts, fill=tuple(int(c * sh) for c in base), outline=(10, 10, 12))
        if fc["tex"]:
            tex = textures[fc["tex"]]
            th, tw = tex.shape[:2]
            for i in range(1, len(pts) - 1):
                tri = [pts[0], pts[i], pts[i + 1]]
                uvs = [fc["uv"][0], fc["uv"][i], fc["uv"][i + 1]]
                xs, ys = [p[0] for p in tri], [p[1] for p in tri]
                x0, x1, y0, y1 = max(0, int(min(xs))), min(W - 1, int(max(xs)) + 1), max(0, int(min(ys))), min(H - 1, int(max(ys)) + 1)
                (ax, ay), (bx, by), (cx, cyy) = tri
                det = (by - cyy) * (ax - cx) + (cx - bx) * (ay - cyy)
                if abs(det) < 1e-9:
                    continue
                for yy in range(y0, y1 + 1):
                    for xx in range(x0, x1 + 1):
                        w1 = ((by - cyy) * (xx - cx) + (cx - bx) * (yy - cyy)) / det
                        w2 = ((cyy - ay) * (xx - cx) + (ax - cx) * (yy - cyy)) / det
                        w3 = 1 - w1 - w2
                        if min(w1, w2, w3) < -1e-6:
                            continue
                        u = uvs[0][0] * w1 + uvs[1][0] * w2 + uvs[2][0] * w3
                        v = uvs[0][1] * w1 + uvs[1][1] * w2 + uvs[2][1] * w3
                        px = tex[min(th - 1, int(v * th)), min(tw - 1, int(u * tw))]
                        if px[3]:
                            img.putpixel((xx, yy), tuple(int(c * sh) for c in px[:3]))
    return img


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    data = faces_from_editor(sys.argv[1], sys.argv[3] if len(sys.argv) > 3 else None)
    views = [(0.0, 0.0), (0.6, 0.25), (math.pi / 2, 0.0), (math.pi, 0.0)]
    ys = [p[1] for fc in data["faces"] for p in fc["pts"]]
    cy = (min(ys) + max(ys)) / 2
    height = max(ys) - min(ys)
    size = (380, 600)
    zoom = 0.88 * size[1] * 7.5 / (min(size) * 1.25 * max(height, 1e-6))   # le modèle occupe ~88 % de la hauteur de la vignette
    tiles = [render_view(data, yaw, pitch, center=(0, cy, 0), zoom=zoom) for yaw, pitch in views]
    sheet = Image.new("RGB", (sum(t.width for t in tiles), tiles[0].height))
    x = 0
    for t in tiles:
        sheet.paste(t, (x, 0)); x += t.width
    sheet.save(sys.argv[2])
    print(f"aperçu : {sys.argv[2]} ({sheet.width}×{sheet.height}) — hauteur du modèle : {height:.2f} blocs")


if __name__ == "__main__":
    main()
