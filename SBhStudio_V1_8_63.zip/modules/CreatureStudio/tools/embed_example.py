#!/usr/bin/env python3
"""Intègre (ou met à jour) l'exemple « Soldat » dans l'éditeur, pour que le bouton 🎖 Soldat fonctionne sans fichier externe.

    python tools/embed_example.py                      # utilise examples/soldat_standard.creature.json
    python tools/embed_example.py autre.creature.json  # un autre projet

Remplace le bloc entre les marqueurs `// ==SOLDIER==` et `// ==ENDSOLDIER==` dans editor/creature_editor.html.
À relancer après chaque `python examples/build_soldier.py` ou `python examples/build_hibou.py` (embarque aussi les 4 personnages HIBOU).
"""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
src = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "examples" / "soldat_standard.creature.json"
html_path = ROOT / "editor" / "creature_editor.html"
html = html_path.read_text(encoding="utf-8")
data = json.dumps(json.loads(src.read_text(encoding="utf-8")), ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
a, b = html.index("// ==SOLDIER==\n"), html.index("// ==ENDSOLDIER==")
hib = {}
for key in ("hippo1", "hippo2", "hippo3", "chef"):      # personnages HIBOU (python examples/build_hibou.py) — facultatifs
    f = ROOT / "examples" / f"hibou_{key}.creature.json"
    if f.exists():
        hib[key] = json.loads(f.read_text(encoding="utf-8"))
hdata = json.dumps(hib, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
html = html[:a] + "// ==SOLDIER==\nconst SOLDIER=" + data + ";\nconst HIBOU=" + hdata + ";\n" + html[b:]
html_path.write_text(html, encoding="utf-8")
print(f"exemple intégré : {src.name} ({len(data) // 1024} Ko) -> {html_path}")
