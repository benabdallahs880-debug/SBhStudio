# Rapport de travail — Étape 7 (+ personnage « Soldat standard »)

**Date : 2026-10-03** — **Projet : CreatureStudio** — **Étape 7 : Comportements et logique visuelle**
**Statut : TERMINÉE** (logique testée ; panneau, simulateur et rendu des textures jamais vus dans un vrai navigateur ni sur téléphone — sauf l'aperçu PNG du soldat, généré avec le même code de rendu)

## 1. Objectif
(1) Donner un cerveau à la créature : caractéristiques et règles SI / ALORS en blocs, testables dans l'éditeur. (2) Sur demande de l'utilisateur, créer un **personnage complet**, le « Soldat standard »
(d'après l'illustration fournie), qui sert d'exemple de bout en bout et de base pour modéliser d'autres personnages.

## 2. Ce qui a été fait — Étape 7
**Format** (`core/format.md` §12 ; ajouts, `formatVersion` reste `1.0`) : `behaviors.stats` (vie, dégâts, armure, vitesse lent→rapide, saut, détection, intelligence) et `behaviors.graphs` = règles
`{ conditions, actions }` dont **l'ordre est la priorité** ; 7 conditions (joueur détecté, distance, jour/nuit, vie en dessous, attaqué, dans l'eau, hasard) avec **NON** ; 7 actions (poursuivre, attaquer, fuir, se promener, rester immobile,
sauter, jouer une animation) ; une seule action de déplacement par règle ; `animationId` optionnel sur toute action.
**Modèle Python** : `get_stats`, `set_stats`, `add/update/remove/move_behavior`, `add/set/remove_condition`, `add/set/remove_action`, `select_behavior` (+ fonctions de module `select_behavior`, `evaluate_condition`).
**Validateur / schéma** : plages des caractéristiques, types et paramètres des blocs, ids uniques, `animationId` existant, un seul déplacement par règle.
**Éditeur** : panneau **Comportement** (7 curseurs de caractéristiques aux libellés simples, liste de règles avec modèles prêts à l'emploi, ▲ ▼ pour la priorité, activer/désactiver, blocs SI et ALORS éditables avec NON,
animation liée à chaque action) et **simulateur d'aperçu** (vue de dessus, joueur déplaçable au doigt, ☀/🌙, 💥 Frapper, ▶ Tester ; affiche la règle active et les points de vie ; **joue l'animation de la règle active dans la vue 3D**).

## 3. Ce qui a été fait — personnage « Soldat standard » (voir `docs/CHARACTER_soldat_standard.md`)
38 parties, 17 os avec limites, 10 matières, 1 texture peinte (keffieh 48×32), 6 animations (Repos, Marche, Course, Attaque, Dégâts, Mort), 2 poses (Bras tendu, Garde), caractéristiques et 5 règles.
Entièrement construit par `examples/build_soldier.py` avec l'API (symétrie, pivots, matières, texture, rig, animations, comportements). Aperçu : `docs/preview_soldat_standard.png`. Bouton **🎖 Soldat** dans l'éditeur.
Choix de design : silhouette héroïque (épaules larges, taille étroite, ≈ 2,05 blocs), keffieh rayé avec yeux lumineux, écharpe rouge, gilet à plaque et poches, sac et antenne, genouillères, gants et bottes. Le fond de l'illustration et toute arme sont volontairement absents.

**Améliorations de l'outillage faites au passage**
- `mirror_name` accorde le genre en français (« Bras droit », « Genouillère droite », « Œil droit ») — Python et JS, testé.
- `tools/render_preview.py` : aperçu PNG d'un projet (4 vues, textures, pose d'une animation) avec le même code que l'éditeur ; `tools/embed_example.py` : intègre un projet dans le bouton 🎖 de l'éditeur.

## 4. Fichiers touchés
| Fichier | Statut |
|---|---|
| `core/creature_model.py` | modifié (stats, règles, blocs, sélection, `mirror_name` accordé) |
| `tools/validate_creature.py`, `schema/creature-project.schema.json` | modifiés (comportements) |
| `editor/creature_editor.html` | modifié (CORE : comportements, simulation ; interface : panneau, simulateur, bouton 🎖 ; exemple intégré) |
| `tests/test_behavior.py` (11), `tests/test_soldier.py` (9) | créés |
| `tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`, `tests/test_symmetry.py` | modifiés (parité des comportements, simulation, panneau, noms accordés) |
| `examples/build_soldier.py`, `examples/soldat_standard.creature.json` | créés |
| `tools/render_preview.py`, `tools/embed_example.py` | créés |
| `docs/CHARACTER_soldat_standard.md`, `docs/preview_soldat_standard.png`, `reports/07_STEP_7.md` | créés |
| `core/format.md`, `core/operations.md`, `CURRENT_STATE.md`, `CHANGELOG.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md` | mis à jour |
| autres fichiers | inchangés |

## 5. Tests
`python -m unittest discover -s tests -v` : **108 tests OK** (11 nécessitent Node). Nouveautés : validation des comportements (10 cas), blocs invalides refusés avec projet inchangé, priorité et ordre, chaque condition (limites incluses, NON),
parité Python/JS de la sélection sur 576 contextes, simulation (poursuite, contact, cooldown et dégâts, fuite quand blessé, mort immobile, promenade bornée, nuit, attaqué qui expire), panneau et simulateur dans l'interface simulée,
soldat (valide, symétrie exacte des 11 paires, noms accordés, **toutes les valeurs d'animation et de pose dans les limites des os**, boucles continues, règles et animations cohérentes, texture, matières).
Vérification visuelle : aperçus PNG du soldat (repos, marche, attaque) examinés. **Non testé** : l'éditeur dans un vrai navigateur / sur téléphone (panneau, simulateur, lecture, texture sur triangles), la lisibilité du panneau sur petit écran.

## 6. Ce qui n'a PAS été fait / limites
- Pas de capacités spéciales, sons ni particules (Étape 8) ; pas d'export (Étape 10) : les règles sont prêtes à être traduites mais rien n'est généré.
- Les actions s'exécutent **ensemble** (pas de séquences avec attente) ; pas de cible autre que « le joueur » ; `intelligence` et `jump` n'ont pas d'effet dans l'aperçu (le saut n'est pas simulé).
- La simulation est un aperçu 2D (monde plat, pas d'obstacles, pas d'eau) ; la vue 3D ne déplace pas la créature (l'animation se joue sur place).
- Le générateur d'animations de base ne gère pas bien les os imbriqués (cuisse + jambe basse + botte tournent tous) : pour le soldat, les animations sont écrites à la main.
- Panneau comportement sans glisser-déposer : l'ordre se change avec ▲ ▼.
- Rendu : tri des faces (peintre) ; petites erreurs d'ordre possibles ; textures dessinées triangle par triangle (coutures possibles).
- Pas de variantes du soldat, d'armes ni d'accessoires.

## 7. Décisions techniques
Règles par **priorité de liste** (comme les « goals » Bedrock) plutôt qu'un graphe libre : traduction directe à l'export, aucun cycle possible ; actions simultanées ; `enabled` déduit ; simulation hors format (pure, testable) ;
caractéristiques stockées en valeurs « enfant » (vitesse 0..1) et converties à l'export ; le soldat est **construit par script** (reproductible, diffable) puis intégré ; un seul côté construit + miroir (noms, os, limites, matières copiés).

## 8. Questions ouvertes
Armes et accessoires du soldat ? Variantes (éclaireur, lourd, officier) ? Séquences d'actions avec attente pour l'Étape 8 (capacités avec recharge) ? Import de textures Minecraft (reporté depuis l'Étape 5) ? Conteneur `.sbhcreature` ? Courbes d'animation ?

## 9. Reprise
Prochaine étape : **Étape 8 — Sons, effets et capacités spéciales** (feu, glace, vol, téléportation…, `[Quand attaqué] → [Créer explosion] → [Reculer] → [Cooldown 5 s]`, sons, particules). Lire : `CURRENT_STATE.md`, `MASTER_PLAN.md`, `docs/VISION.md` (§10 capacités),
`core/format.md` (§11 animations, §12 comportements), `core/operations.md`, `core/creature_model.py`, `editor/creature_editor.html`, ce rapport, `docs/CHARACTER_soldat_standard.md`.
Avant tout : ouvrir l'éditeur sur téléphone, charger 🎖 Soldat, tester Pose, Peindre, timeline et le simulateur ; corriger ce qui casse. Les capacités s'ajoutent comme **nouveaux types** de conditions/actions (ne pas changer ceux de l'Étape 7).
