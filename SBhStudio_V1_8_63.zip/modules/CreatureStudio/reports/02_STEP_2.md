# Rapport de travail — Étape 2

**Date : 2026-09-29**
**Projet : CreatureStudio**
**Étape : 2 — Construction libre des parties et primitives**
**Statut : TERMINÉE (modèle et logique ; aucune interface)**

## 1. Objectif

Rendre le modèle de l'Étape 1 réellement manipulable : créer, supprimer, dupliquer, déplacer, tourner,
redimensionner et réorganiser des parties, sans casser `formatVersion 1.0` et sans toucher aux règles
`id` / `parentId` / transformations.

## 2. Ce qui a été fait

Un module Python sans dépendance, `core/creature_model.py`, avec la classe `CreatureProject`. Chaque
opération est **transactionnelle** : appliquée, revalidée par le validateur, annulée intégralement si le projet
devient invalide. Les opérations, leurs règles et leurs limites sont décrites dans `core/operations.md`.

Opérations : création d'un projet vide, chargement/sauvegarde, ajout de partie, suppression (sous-arbre ou
enfants remontés), duplication de sous-arbre (nouveaux ids, sockets copiés), position/rotation/échelle
(absolues et relatives), renommage, changement de primitive, changement de parent (anti-cycle), réordonnancement
parmi les frères, ajout/suppression de sockets, requêtes (`get_part`, `children`, `descendants`, `tree_text`).

Primitives : `pyramid` et `plane` ajoutées (demandées par la vision), avec paramètres par défaut pour toutes.

## 3. Fichiers touchés

| Fichier | Statut | Détail |
|---|---|---|
| `core/creature_model.py` | créé | modèle et opérations |
| `core/operations.md` | créé | documentation des opérations |
| `tests/test_creature_model.py` | créé | 22 tests unittest |
| `examples/build_demo.py` | créé | démo de construction |
| `examples/demo_dragon.creature.json` | créé | sortie de la démo, validée |
| `docs/VISION.md` | créé | vision utilisateur + correspondance aux étapes |
| `reports/02_STEP_2.md` | créé | ce rapport |
| `tools/validate_creature.py` | modifié | `check(d)` extrait (sans effet de bord), `main` l'utilise ; sortie CLI identique (comparée avant/après sur l'exemple) ; formes `pyramid`, `plane` |
| `schema/creature-project.schema.json` | modifié | enum `shape` : + `pyramid`, `plane` |
| `core/format.md` | modifié | formes + renvoi à `operations.md` |
| `MASTER_PLAN.md` | modifié | Étape 2 cochée, règle 9 (contenu des rapports), références |
| `CHANGELOG.md`, `README.md`, `CURRENT_STATE.md` | mis à jour | |
| `examples/test_creature.creature.json`, `reports/01_STEP_1.md`, `validation_result.txt` | inchangés | |

## 4. Tests effectués

- `python -m unittest discover -s tests -v` : **22 tests, tous OK** (création, refus d'entrées invalides avec projet
  inchangé, racine protégée, suppression avec sockets, duplication, transformations, anti-cycle, réordonnancement,
  stabilité des ids, aller-retour sauvegarde/chargement validé par le validateur en ligne de commande).
- Validateur CLI sur `test_creature.creature.json` et `demo_dragon.creature.json` : OK.
- Le comportement du validateur a été comparé avant/après refactorisation : sortie identique.
- Non testé : exécution sous Android/Kotlin, gros projets (performance), le schéma JSON via une bibliothèque externe.

## 5. Ce qui n'a PAS été fait

Interface et rendu 3D, symétrie automatique, sculpture, annuler/rétablir, validation des `parameters` par forme,
conservation de la position monde lors d'un changement de parent, squelette, matériaux, animation,
comportements, export. Les champs réservés (`materials`, `skeleton`, `animations`, `behaviors`, `export`)
restent des placeholders non fonctionnels.

## 6. Décisions techniques

1. Transformations locales, rotations en degrés, ids jamais modifiés.
2. Échelle à 0 refusée par le modèle (forme dégénérée) ; les échelles négatives restent permises (miroir).
3. La racine ne peut pas être supprimée, dupliquée ni re-parentée (le format exige une racine unique).
4. `reparent` / suppression avec remontée d'enfants conservent la transformation locale (simple et prévisible ;
   la conservation monde demandera des matrices, à faire avec l'éditeur 3D).
5. Ajout de `pyramid` et `plane` : ajout compatible, `formatVersion` inchangé. « Rectangle » de la vision = cube mis à l'échelle.
6. Python est le langage de référence de la logique. Si l'éditeur est en Kotlin/JS/Godot, porter la logique
   selon `core/operations.md` et rejouer les mêmes cas de test.

## 7. Questions ouvertes pour l'utilisateur

1. Plateforme de l'éditeur 3D (Étape 3) : Android/Kotlin, Godot, WebGL/three.js ? À décider avant l'Étape 3.
2. Conteneur `.sbhcreature` (vision) vs fichier unique `.creature.json` (actuel).
3. Où planifier la symétrie X/Y/Z (avant ou dans l'éditeur 3D) ?

## 8. Point d'arrêt exact et consigne au prochain développeur

Prochaine étape : **Étape 3 — Éditeur 3D et prévisualisation interactive.** Lire dans cet ordre :
`CURRENT_STATE.md`, `MASTER_PLAN.md`, `docs/VISION.md`, `core/format.md`, `core/operations.md`,
`core/creature_model.py`, ce rapport. Lancer les commandes de vérification de `CURRENT_STATE.md`, obtenir la
réponse à la question 1, puis commencer. Ne pas remplacer `id`, `parentId` ni les transformations ; toute
modification du modèle passe par les opérations existantes. En fin d'étape : mettre à jour `CURRENT_STATE.md`,
`CHANGELOG.md`, cocher le plan et ajouter `reports/03_STEP_3.md` sur le même modèle.
