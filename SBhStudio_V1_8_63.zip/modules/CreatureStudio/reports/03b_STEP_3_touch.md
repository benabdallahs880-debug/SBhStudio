# Rapport de travail — Étape 3 bis : manipulation tactile

**Date : 2026-09-29** — **Statut : TERMINÉE** (testée par simulation, pas encore sur un vrai téléphone)

## 1. Demande de l'utilisateur
Pouvoir placer les parties **au doigt**, pas seulement par des chiffres : une icône qui change de mode —
un appui = déplacer, un nouvel appui = tourner (l'angle). Les champs numériques restent.

## 2. Ce qui a été fait
Un bouton de mode en tête de la barre, qui tourne en boucle : **👁 Vue → ✥ Déplacer → ⟳ Tourner → 👁 Vue**.
- **Vue** : comportement précédent (glisser = caméra, toucher = sélectionner).
- **Déplacer** : glisser une partie la déplace dans le plan de l'écran, à sa profondeur, en tenant compte de
  la caméra et du parent (le déplacement est converti en coordonnées locales, donc les parties enfants suivent).
- **Tourner** : glisser une partie ↔ la tourne autour de Y, ↕ autour de X (rotation locale, en degrés). L'angle Z se règle dans le panneau.
- En mode Déplacer/Tourner, glisser sur le vide fait toujours tourner la caméra ; le pincement à deux doigts zoome.
- **Un geste = une seule entrée d'annulation** (fonctions `begin / live / commit`). Le projet est revalidé à la fin du geste ; s'il est invalide, il est restauré.
- Une ligne d'aide s'affiche sous la barre selon le mode.

## 3. Fichiers touchés
| Fichier | Statut |
|---|---|
| `editor/creature_editor.html` | modifié : bouton de mode, gestes, `begin/live/commit` (bloc CORE), `solve3` et `dragDelta` (maths du glisser) |
| `tests/test_editor_core.py` | modifié : + test du glisser (maths, parent mis à l'échelle, caméra tournée, historique) |
| `tests/test_editor_ui_smoke.py` | créé : faux DOM sous Node, vérifie le dessin et les 3 modes de geste |
| `reports/03b_STEP_3_touch.md`, `CURRENT_STATE.md`, `CHANGELOG.md`, `README.md` | créé / mis à jour |
| `core/*`, `tools/*`, `schema/*`, `examples/*`, format | inchangés |

## 4. Tests
25 tests OK (`python -m unittest discover -s tests -v`, Node requis pour 3 d'entre eux). **Non testé** : vrai écran tactile
(sensibilité, confort, conflit avec les gestes du navigateur mobile). Réglages à ajuster au besoin : vitesse de rotation (0,6°/pixel)
dans `cv.onpointermove`, taille de la zone de saisie.

## 5. Limites / non fait
Pas d'aimantation à une grille ; pas de rotation autour de Z au doigt ; pas de mode Taille au doigt (proposé : 4e état du bouton) ;
pas de poignées 3D visibles ; le déplacement se fait dans le plan de l'écran (pas de déplacement contraint à un axe) ;
la logique `begin/live/commit` n'existe qu'en JS (pas dans `core/creature_model.py`).

## 6. Reprise
Prochaines étapes recommandées : (a) tester sur téléphone et régler ; (b) point de pivot par partie, symétrie, réglage
rayon/hauteur (voir `docs/VISION.md`) ; (c) Étape 4, squelette et rig. Lire `CURRENT_STATE.md` d'abord.
