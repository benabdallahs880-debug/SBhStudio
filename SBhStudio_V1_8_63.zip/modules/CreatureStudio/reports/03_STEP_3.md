# Rapport de travail — Étape 3

**Date : 2026-09-29** — **Projet : CreatureStudio** — **Étape 3 : Éditeur 3D et prévisualisation interactive**
**Statut : TERMINÉE en version de base (non testée dans un vrai navigateur, voir §4)**

## 1. Objectif
Voir la créature en 3D pendant qu'on la construit, et la modifier directement, sans toucher au JSON.

## 2. Ce qui a été fait
Un éditeur autonome en un seul fichier : `editor/creature_editor.html` (HTML + JavaScript, aucune dépendance,
aucun réseau, s'ouvre dans n'importe quel navigateur, y compris sur téléphone).
- Vue 3D (canvas 2D, rendu projeté ombré) avec rotation au doigt/souris, zoom (pincement/molette), toucher = sélection d'une partie.
- Liste hiérarchique des parties (toucher pour sélectionner), panneau nom / forme / parent / position / rotation / échelle.
- Boutons : ajouter (choix de primitive), dupliquer, supprimer, monter/descendre, annuler/rétablir.
- Import/export : bouton « JSON… » (zone de texte, charger, copier, télécharger). Le JSON exporté est au format `1.0` et passe le validateur Python.
- Une créature de démonstration est construite au démarrage.
- Annuler/rétablir résout une dette de l'Étape 2 (côté éditeur seulement).

**Décision de plateforme (à confirmer par l'utilisateur)** : web (HTML/JS) choisi car il tourne partout, sans
installation, et se teste vite. Ce n'est pas une décision définitive : si SBH Studio exige Kotlin/Godot, porter la
logique du bloc `==CORE==` (miroir de `core/creature_model.py`) et la convention de matrices ci-dessous.

## 3. Fichiers touchés
| Fichier | Statut |
|---|---|
| `editor/creature_editor.html` | créé (éditeur ; bloc `==CORE==` = logique du modèle, reste = rendu et interface) |
| `tests/test_editor_core.py` | créé (exécute le bloc CORE avec Node, puis valide le JSON produit avec le validateur Python ; ignoré si Node absent) |
| `reports/03_STEP_3.md` | créé |
| `CURRENT_STATE.md`, `CHANGELOG.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md` | mis à jour |
| `core/*`, `tools/*`, `schema/*`, `examples/*` | inchangés |

## 4. Tests
- `python -m unittest discover -s tests -v` : 23 tests OK (22 Python + 1 parité JS/Python).
- Vérifié avec Node : géométrie des 8 primitives (aucun NaN, indices de faces valides), matrice identité, syntaxe du script de l'application.
- **Non testé** : affichage réel et gestes tactiles dans un navigateur (pas de navigateur dans l'environnement de travail). À faire en premier par le prochain développeur ou l'utilisateur : ouvrir le fichier, tourner, zoomer, sélectionner, ajouter, annuler, exporter.

## 5. Convention de rendu (à respecter par tout port)
Matrice locale = T · Rz · Ry · Rx · S, rotations en degrés, hiérarchie = produit des matrices parent → enfant. Axe Y vers le haut.
Rendu : faces triées du plus loin au plus proche (algorithme du peintre), ombrage lambertien.

## 6. Ce qui n'a PAS été fait / limites
Pas de manipulateurs 3D (poignées) : l'édition se fait par le panneau ; pas de symétrie ; pas de sculpture ; pas de
peinture ; pas de sockets dans l'interface ; l'ordre de tri des faces peut se tromper pour des formes qui se
pénètrent (limite du rendu 2D, un rendu WebGL avec tampon de profondeur le résoudrait) ; pas de suppression avec
« remonter les enfants » dans l'interface ; les `parameters` des formes (rayon, hauteur…) ne sont pas éditables dans
l'interface (échelle seulement) ; la logique existe en double (Python et JS) — toute règle modifiée doit l'être aux deux endroits.

## 7. Questions ouvertes
1. Plateforme définitive de l'éditeur (web vs Android/Kotlin vs Godot) ?
2. Conteneur `.sbhcreature` vs `.creature.json` ; où planifier la symétrie (voir `docs/VISION.md`) ?

## 8. Point d'arrêt et reprise
Prochaine étape : **Étape 4 — Squelette / rig** (voir `MASTER_PLAN.md`). Lire : `CURRENT_STATE.md`, `MASTER_PLAN.md`,
`docs/VISION.md`, `core/operations.md`, `core/creature_model.py`, `editor/creature_editor.html`, ce rapport.
Avant tout : tester l'éditeur dans un navigateur (§4) et corriger ce qui casse. Ne pas changer `id`, `parentId`, transformations.
