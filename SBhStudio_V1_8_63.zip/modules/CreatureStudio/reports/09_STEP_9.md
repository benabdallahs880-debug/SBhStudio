# Rapport 09 — Étape 9 : validation avancée et diagnostics

## Objectif
Distinguer « le fichier est valide » de « le personnage est correct et exportable », et le dire à l'utilisateur en français, avec un clic pour aller à l'élément en cause.

## Fait
- `core/diagnostics.py` : `diagnose(data)` (fonction pure), 23 codes (`core/format.md` §14), 3 gravités. Couvre modèle (matières, dimensions, noms en double, jumelles désynchronisées, angles hors limites), animations, squelette, comportements (pas de règle de repli, règle inatteignable, capacité sans mouvement, vitesse nulle…), sons/effets, matières/textures.
- Miroir JS `diagnose` + panneau **🩺 Diagnostic** (se met à jour à chaque modification ; un clic sélectionne la partie, la règle ou l'animation).
- CLI `tools/diagnose_creature.py [--strict]`.
- Tests (`tests/test_diagnostics.py`, 7) : chaque code est déclenché par au moins un cas ; parité Python/JS sur tous les exemples + 9 documents altérés (code, gravité, élément) ; personnages livrés sans erreur ni avertissement ; CLI. Total **134 tests OK**.
- Les diagnostics ont trouvé des défauts réels dans mes propres personnages HIBOU : noms en double (Emblème ×3, Poche de ceinture) et matières orphelines — corrigés dans `examples/hibou_kit.py`, fichiers régénérés.

## Décisions
- Les diagnostics **ne bloquent jamais** l'enregistrement et ne sont pas stockés dans le fichier.
- Textures non puissances de 2 : simple info (Bedrock accepte toute taille ; à confirmer à l'étape 10).
- La parité JS/Python porte sur code, gravité et élément ; le texte des messages peut différer sur le format d'un nombre.

## Limites / à faire
1. Les seuils propres à Bedrock (longueur des noms d'os, caractères autorisés, nombre maximal de cubes, tailles de texture) ne sont pas encore contrôlés : à définir avec l'export (étape 10), en ajoutant des codes D05x.
2. Pas de « correction automatique » en un clic (ex. ajouter une règle de repli) — idée pour plus tard.
3. Étape 10 : export Bedrock ; étape 11 : package d'intégration ; test réel de l'éditeur sur téléphone toujours à faire.

## Fichiers
Créés : `core/diagnostics.py`, `tools/diagnose_creature.py`, `tests/test_diagnostics.py`, `reports/09_STEP_9.md`. Modifiés : `editor/creature_editor.html`, `examples/hibou_kit.py`, `examples/hibou_*.creature.json`, `tests/test_hibou.py`, `core/format.md`, `MASTER_PLAN.md`, `CURRENT_STATE.md`, `CHANGELOG.md`, `README.md`.
