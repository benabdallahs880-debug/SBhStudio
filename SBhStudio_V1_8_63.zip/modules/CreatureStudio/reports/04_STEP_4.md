# Rapport de travail — Étape 4

**Date : 2026-09-29** — **Projet : CreatureStudio** — **Étape 4 : Squelette, articulations et rig**
**Statut : TERMINÉE** (logique testée ; interface testée par simulation, pas encore sur un vrai téléphone)

## 1. Objectif
Pouvoir articuler une créature : faire tourner une patte à la hanche, un bras à l'épaule, une tête au cou, et tester
ces articulations, sans toucher au JSON.

## 2. Ce qui a été fait
**Format (ajouts optionnels, `formatVersion` reste `1.0`, anciens fichiers valides)**
- `pivot` sur les parties : point d'articulation. Convention : point → `position + R·(S∘(v − pivot))` (voir `core/format.md` §7).
- `skeleton.bones` : os attachés aux parties, avec `limits` de pose optionnelles par axe. Hiérarchie des os déduite de celle des parties.

**Modèle Python** (`core/creature_model.py`) : `set_pivot` (avec correction de position), `pivot_preset`, `local_point`, `add_bone`,
`remove_bone`, `auto_rig`, `set_bone_limits`, `bone_of_part`, `get_bone`, `bone_parent`. `remove_part` et `duplicate_part` gèrent les os.

**Validateur** : contrôle `pivot`, `skeleton` (objet), `bones` (ids uniques, partie existante, un os par partie, limites valides).
La ligne « bones: N » a été ajoutée à la sortie en ligne de commande.

**Éditeur** (`editor/creature_editor.html`) :
- 4e mode du bouton : **🦴 Pose** (glisser une partie qui a un os la plie autour de son pivot ; limites respectées ; pose **temporaire**, non enregistrée).
- Champ **pivot** (3 nombres) et boutons **Pivot ↑ / ◎ / ↓** (hanche en haut, etc.).
- Boutons **🦴 Créer/Retirer l'os**, **🦴 Tout rigger**, **↺ Pose** (remise à zéro), et champs de **limites** x/y/z (min, max) pour l'os sélectionné.
- Le squelette est dessiné par-dessus le modèle : points orange (articulations, vert si posée), lignes vers l'os parent.
- Chargement/duplication/suppression cohérents avec les os ; annuler/rétablir couvrent pivots, os et limites.

## 3. Fichiers touchés
| Fichier | Statut |
|---|---|
| `core/creature_model.py` | modifié (pivot, os, `rotation_matrix`, `shape_y_bounds`, cohérence remove/duplicate) |
| `tools/validate_creature.py` | modifié (pivot, os, limites ; ligne « bones » en sortie) |
| `schema/creature-project.schema.json` | modifié (`pivot`, `bone`, `skeleton`) |
| `editor/creature_editor.html` | modifié (bloc CORE : pivot/os ; rendu : `loc` avec pivot et pose ; interface) |
| `tests/test_rig.py` | créé (16 tests Python) |
| `tests/test_editor_core.py` | modifié (+ parité JS/Python des pivots, os, bornes) |
| `tests/test_editor_ui_smoke.py` | modifié (mode Pose, limites, historique, reset) |
| `examples/build_rigged_demo.py`, `examples/demo_rigged_quadruped.creature.json` | créés (quadrupède rigué) |
| `core/format.md`, `core/operations.md`, `MASTER_PLAN.md`, `CHANGELOG.md`, `CURRENT_STATE.md`, `README.md`, `docs/VISION.md` | mis à jour |
| `examples/test_creature.creature.json`, `examples/demo_dragon.creature.json`, `reports/01..03b` | inchangés |
| `validation_result.txt` | inchangé (résultat de l'Étape 1 ; la sortie du validateur a maintenant une ligne de plus) |

## 4. Tests
`python -m unittest discover -s tests -v` : **42 tests OK** (Node requis pour 5 d'entre eux). Couvre : pivot qui conserve la forme
en place (avec rotation et échelle), pivot = centre de rotation, présets, os uniques, hiérarchie des os déduite (en sautant les
parties sans os), limites valides/invalides avec projet inchangé, suppression/duplication avec os, validateur (5 cas d'erreurs),
anciens fichiers toujours valides, parité JS/Python (position corrigée, bornes des 8 formes), gestes Pose avec limites (clamp),
pose sans effet sur le modèle ni l'historique. **Non testé** : vrai écran tactile ; confort du mode Pose.

## 5. Ce qui n'a PAS été fait / limites
- Pas de poses nommées ni d'animation (Étape 6) : la pose est perdue au rechargement.
- Le mode Pose ne fait tourner qu'autour de X (↕) et Y (↔) ; l'axe Z n'est pas piloté au doigt (les limites Z existent dans les données).
- Pas de cinématique inverse ; pas de poids/skinning (les parties sont rigides, un os = une partie).
- Le pivot ne se règle au doigt : nombres et présets seulement (haut/centre/bas sur l'axe Y).
- Les limites ne sont appliquées que dans le mode Pose de l'éditeur (pas encore dans le modèle Python, qui n'a pas de notion de pose).
- Conteneur Bedrock : les os et pivots préparent l'export (Étape 10) mais rien n'est exporté.
- Logique dupliquée Python / JS : toute règle modifiée doit l'être aux deux endroits (les tests de parité aident).

## 6. Décisions techniques
1. Un os = une partie (pas de skinning) : simple, colle au modèle Bedrock (un os par groupe de cubes) et évite les os orphelins.
2. Hiérarchie des os déduite, jamais stockée : impossible de créer une incohérence entre os et parties.
3. `skeleton.enabled` déduit du nombre d'os.
4. La pose n'est pas dans le format avant l'Étape 6 (elle deviendra une donnée d'animation).
5. Pivot dans l'espace local avant échelle ; `set_pivot` corrige la position par défaut pour ne pas déplacer la forme.

## 7. Questions ouvertes pour l'utilisateur
1. Faut-il piloter l'axe Z au doigt en mode Pose (par exemple avec deux doigts) ?
2. Poses nommées : les faire dès maintenant (petite étape 4 bis) ou directement dans l'Étape 6 ?
3. Toujours ouvertes : conteneur `.sbhcreature`, placement de la symétrie (voir `docs/VISION.md`).

## 8. Reprise
Prochaine étape : **Étape 5 — Matériaux, textures et apparence** (couleurs par partie, textures, peinture ; voir
`docs/VISION.md`). Lire : `CURRENT_STATE.md`, `MASTER_PLAN.md`, `docs/VISION.md`, `core/format.md`, `core/operations.md`,
`core/creature_model.py`, `editor/creature_editor.html`, ce rapport. Avant de commencer : tester l'éditeur sur téléphone
(modes Déplacer, Tourner, Pose) et corriger. Ne pas changer `id`, `parentId`, transformations, pivot ni la structure des os.
