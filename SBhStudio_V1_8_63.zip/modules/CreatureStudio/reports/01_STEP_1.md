# Rapport de travail — Étape 1

**Date : 2026-09-29**  
**Projet : CreatureStudio**  
**Étape : 1 — Fondations du format interne**  
**Statut : TERMINÉE**

## 1. Objectif

Construire le premier socle autonome permettant de représenter une créature créée de zéro, sans dépendre de SBh Studio, de Minecraft ou d'un moteur 3D.

L'idée centrale est de séparer la **créature interne** de sa future **présentation/exportation**. Cela permettra plus tard de créer une créature très librement puis de décider comment elle sera affichée ou exportée.

## 2. Travail réalisé

### Format de projet

Création d'un format JSON versionné : `formatVersion = 1.0`.

Il contient :
- identité du projet ;
- identité de la créature ;
- liste des parties ;
- sockets ;
- matériaux réservés ;
- squelette réservé ;
- animations réservées ;
- comportements réservés ;
- cibles d'export réservées.

### Hiérarchie

Chaque partie contient `id` et `parentId`. Une seule partie est racine.

Cela permet déjà de représenter :

```text
Body
├── Head
├── Left Arm
├── Right Arm
├── Left Leg
├── Right Leg
└── Tail
```

### Transformations

Chaque partie possède :
- position XYZ ;
- rotation XYZ ;
- échelle XYZ.

Les coordonnées restent dans le format interne. Un export pourra adapter ses propres conventions plus tard.

### Primitives

Le contrat accepte :
- cube ;
- sphere ;
- cylinder ;
- cone ;
- capsule ;
- custom.

`custom` est intentionnellement réservé à la future construction libre.

### Sockets

Les sockets sont déjà modélisés. Ils serviront notamment aux armes, accessoires, objets tenus, oreilles, queues, équipements et autres éléments attachables.

### Validation

Un validateur Python sans dépendance externe a été ajouté. Il vérifie les références et la cohérence structurelle au-delà de ce que le schéma JSON peut exprimer seul.

## 3. Test effectué

Le projet `examples/test_creature.creature.json` a été passé au validateur.

Résultat attendu et obtenu :

- JSON lisible ;
- 7 parties ;
- 3 sockets ;
- une racine ;
- aucun parent manquant ;
- aucun cycle ;
- transformations valides ;
- formes valides.

## 4. Ce qui n'a PAS été implémenté

Ne pas considérer les champs réservés comme fonctionnels :

- `materials` n'est pas encore un système de matériaux ;
- `skeleton` n'est pas encore un rig ;
- `animations` n'est pas encore une animation ;
- `behaviors` n'est pas encore un moteur de comportement ;
- `export` n'exporte encore rien.

Il n'y a également pas encore de rendu 3D ni d'interface graphique.

## 5. Décisions techniques importantes

1. Le format interne est indépendant de Minecraft.
2. Les IDs sont stables et ne doivent pas être remplacés par des indices de tableau.
3. La hiérarchie utilise `parentId`.
4. Les futures étapes doivent conserver la compatibilité avec `formatVersion 1.0` ou prévoir explicitement une migration.
5. Le système doit rester exploitable depuis Android/Kotlin, Python, JavaScript ou un moteur 3D.

## 6. Point d'arrêt exact

L'étape suivante est **Étape 2 — Construction libre des parties et primitives**.

Elle devra permettre de créer, supprimer, dupliquer, déplacer, tourner, redimensionner et réorganiser des parties à partir du modèle actuel.

La prochaine étape ne doit pas encore essayer de résoudre toute la sculpture 3D. Elle doit d'abord rendre le modèle réellement manipulable.

## 7. Consigne au prochain développeur

Lire dans cet ordre :

1. `CURRENT_STATE.md`
2. `MASTER_PLAN.md`
3. `core/format.md`
4. `schema/creature-project.schema.json`
5. `examples/test_creature.creature.json`
6. ce rapport.

Puis commencer l'Étape 2 sans casser le format existant.
