# CHANGELOG

## Étape 11 (2026-10-06)
- Ajout : exporteur Bedrock JS (bloc `==CORE==`) + bouton ⬇ Bedrock ; API hôte `window.CreatureStudio` et messages `creaturestudio:*` (bloc `==HOSTAPI==`) ; paquet `creaturestudio/` + `pyproject.toml` ; `docs/INTEGRATION.md`, `HANDOVER.md` ; tests `test_bedrock_js_parity` (3), `test_host_api` (1), `test_package` (3).
- Modifié : `core/bedrock_export.py` (`build_pack` pur) ; `tests/test_editor_ui_smoke.py` (stub + ancre). Fichiers `__init__.py` vides ajoutés dans `core/`, `tools/`, `editor/`.
- Limite : `pip install .` réel et WebView réelle non essayés.

## Étape 10 (2026-10-05)
- Ajout : `core/bedrock_export.py`, `tools/export_bedrock.py`, `tools/render_bedrock_preview.py`, `tests/test_bedrock_export.py` (18), `docs/BEDROCK_EXPORT.md`, `docs/exports_demo/`, diagnostics D050–D052 (Python + JS) ; `skewed_parts` déplacé dans `core/diagnostics.py`.
- Limite : export non testé dans le jeu ; Python uniquement (pas de bouton dans l'éditeur web).

## Étape 9 (2026-10-05)
- Ajout : `core/diagnostics.py`, `tools/diagnose_creature.py`, miroir JS `diagnose`, panneau 🩺, `tests/test_diagnostics.py`.
- Corrigé dans `examples/hibou_kit.py` : noms uniques (Emblème du front/de la poitrine/…, Poche de ceinture 1/2), matières inutilisées supprimées. Régénérer avec `python examples/build_hibou.py && python tools/embed_example.py`.
- D033 (textures non puissances de 2) classé « info » : Bedrock accepte toute taille.

## Étape 8 (2026-10-05)
- Ajout : `sounds[]`, `effects[]`, actions `playSound` / `effect` / `ability` (format, validateur Python, schéma, modèle Python, miroir JS, éditeur, simulateur) ; `tests/test_step8.py` ; capacités de démonstration pour le Chef et HIPPO III.
- Compatibilité : les fichiers antérieurs restent valides (listes absentes = vides).

## HIBOU (2026-10-05)
- Ajout : Chef + soldats HIPPO I/II/III (`examples/hibou_*.creature.json`), `motion_kit.py`, `hibou_kit.py`, `build_hibou.py`, `tools/render_lineup.py`, `tests/test_hibou.py`, menu 🦉 HIBOU… dans l'éditeur.
- Modifié : accord des noms miroirs (anneau, liseré, brassard, sabre, casque, bracelet, pommeau), `embed_example.py`, `build_soldier.py` (refactor sans changement de sortie).

## 2026-10-03 — Étape 7 (comportements) + personnage « Soldat standard »

### Ajouté
- `behaviors.stats` et `behaviors.graphs` (règles SI/ALORS par priorité de liste ; 7 conditions, 7 actions, NON) — `core/format.md` §12 ;
- modèle : `get_stats`, `set_stats`, `add/update/remove/move_behavior`, `add/set/remove_condition`, `add/set/remove_action`, `select_behavior`, `evaluate_condition` ;
- éditeur : panneau Comportement (caractéristiques, règles, modèles, blocs), simulateur d'aperçu (▶ Tester, joueur déplaçable, jour/nuit, frapper, animation liée), bouton 🎖 Soldat ;
- personnage **Soldat standard** (`examples/build_soldier.py`, `examples/soldat_standard.creature.json`, `docs/CHARACTER_soldat_standard.md`, `docs/preview_soldat_standard.png`) ;
- outils : `tools/render_preview.py` (aperçu PNG), `tools/embed_example.py` ;
- `tests/test_behavior.py`, `tests/test_soldier.py`, `reports/07_STEP_7.md`.

### Modifié
- `mirror_name` accorde le genre (« Bras droit », « Genouillère droite », « Œil droit ») en Python et JS ;
- `core/creature_model.py`, `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`, `tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`, `tests/test_symmetry.py`,
  `core/format.md`, `core/operations.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`, `CURRENT_STATE.md`.

### Compatibilité
- `formatVersion` reste `1.0` ; `behaviors.stats` optionnel ; les fichiers précédents restent valides.
- Les noms des parties miroir créées avec l'ancienne règle (« Bras droite ») ne sont pas renommés dans les fichiers existants.

### Non testé
- éditeur dans un vrai navigateur / sur téléphone (panneau, simulateur, texture, lecture).

## 2026-10-03 — Étape 6 (animation, poses, timeline)

### Ajouté
- `animations[]` (durée, boucle, images clés `{time, pose}`) et `skeleton.poses[]` ; échantillonnage défini (`core/format.md` §11) ;
- modèle : `add_pose`, `remove_pose`, `add_animation`, `update_animation`, `remove_animation`, `set_keyframe`, `remove_keyframe`, `sample`, `sample_pose` ;
- éditeur : timeline (lecture, images clés, durée, boucle), poses nommées, 9 animations de base générées, décalages de position par os ;
- `tests/test_animation.py`, `examples/build_animation_demo.py`, `examples/demo_animated.creature.json`, `reports/06_STEP_6.md`.

### Modifié
- `core/creature_model.py` (suppression d'os nettoie poses et animations), `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`,
  `tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`, `core/format.md`, `core/operations.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`, `CURRENT_STATE.md`.

### Compatibilité
- `formatVersion` reste `1.0` ; `skeleton.poses` optionnel ; les fichiers précédents restent valides.

### Non testé
- lecture fluide et timeline sur téléphone ; qualité visuelle des animations générées.

## 2026-09-30 — Étape 5 (matériaux, textures, apparence)

### Ajouté
- matières (`color`, `opacity`, `emissive`, `roughness`, `textureId`) et champ optionnel `textures` (pixels indexés + palette) ; règles UV des 8 formes (`core/format.md` §10) ;
- modèle : `add_material`, `update_material`, `remove_material`, `assign_material`, `add_texture`, `remove_texture`, `paint`, `fill`, `clear_texture` ;
- éditeur : mode 🖌 Peindre (pinceau, gomme, remplissage, palette), panneau matière, rendu des textures, opacité et lueur ;
- `tests/test_appearance.py`, `examples/build_appearance_demo.py`, `examples/demo_appearance.creature.json`, `reports/05_STEP_5.md`.

### Modifié
- `core/creature_model.py`, `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`, `tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`,
  `core/format.md`, `core/operations.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`, `CURRENT_STATE.md`.

### Compatibilité
- `formatVersion` reste `1.0` ; `textures` est optionnel ; les fichiers précédents restent valides.

### Non testé
- rendu visuel réel des textures ; peinture au doigt sur téléphone.

## 2026-09-30 — Étape 4 bis (symétrie, rotation Z à deux doigts)

### Ajouté
- champ optionnel `mirror` (lien réciproque entre deux parties) ; modèle : `mirror_part`, `unlink_mirror`, `twin`, options `symmetric` / `symmetric_axis` ;
- éditeur : boutons Sym X/Y/Z et ⇋ Miroir, jumelle automatique à l'ajout, glisser/tourner/pose en symétrie ; rotation Z de la pose avec deux doigts ;
- `tests/test_symmetry.py`, `examples/build_symmetric_demo.py`, `examples/demo_symmetric.creature.json`, `reports/04b_STEP_4_symmetry_z.md`.

### Modifié
- `core/creature_model.py` (remove/duplicate gèrent les liens), `tools/validate_creature.py`, `schema/creature-project.schema.json`, `editor/creature_editor.html`,
  `tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`, `core/format.md`, `core/operations.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`.

### Compatibilité
- `formatVersion` reste `1.0` ; les fichiers précédents restent valides.

### Non testé
- vrai écran tactile (deux doigts, symétrie).

## 2026-09-29 — Étape 4 (squelette, articulations, rig)

### Ajouté
- champ optionnel `pivot` sur les parties ; `skeleton.bones` (os, `limits`) ; hiérarchie des os déduite ;
- modèle : `set_pivot`, `pivot_preset`, `local_point`, `add_bone`, `remove_bone`, `auto_rig`, `set_bone_limits`, `bone_of_part`, `get_bone`, `bone_parent` ;
- éditeur : mode 🦴 Pose, pivot (nombres et présets ↑ ◎ ↓), créer/retirer l'os, tout rigger, limites x/y/z, squelette affiché ;
- `tests/test_rig.py`, `examples/build_rigged_demo.py`, `examples/demo_rigged_quadruped.creature.json`, `reports/04_STEP_4.md`.

### Modifié
- `core/creature_model.py` (remove/duplicate gèrent les os), `tools/validate_creature.py` (contrôles pivot/os ; ligne « bones » en sortie), `schema/creature-project.schema.json`,
  `editor/creature_editor.html`, `tests/test_editor_core.py`, `tests/test_editor_ui_smoke.py`, `core/format.md`, `core/operations.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`.

### Compatibilité
- `formatVersion` reste `1.0` ; les fichiers des étapes 1 à 3 restent valides et se chargent sans changement.

### Non testé
- vrai écran tactile (mode Pose).

## 2026-09-29 — Étape 3 bis (tactile)

### Ajouté
- bouton de mode 👁 Vue / ✥ Déplacer / ⟳ Tourner dans l'éditeur ; glisser une partie pour la déplacer ou la tourner ;
- `begin/live/commit` (un geste = une entrée d'historique), `solve3`, `dragDelta` ;
- `tests/test_editor_ui_smoke.py`, tests du glisser dans `tests/test_editor_core.py`, `reports/03b_STEP_3_touch.md`.

### Modifié
- `editor/creature_editor.html`, `CURRENT_STATE.md`, `CHANGELOG.md`, `README.md`. Format et `core/` inchangés.

### Non testé
- vrai écran tactile.

## 2026-09-29 — Étape 3

### Ajouté
- `editor/creature_editor.html` : éditeur 3D autonome (vue orbitale, sélection, hiérarchie, transformations, ajout/duplication/suppression/ordre, annuler/rétablir, import/export JSON) ;
- `tests/test_editor_core.py` : parité de la logique JS avec le validateur Python ;
- `reports/03_STEP_3.md`.

### Modifié
- `CURRENT_STATE.md`, `CHANGELOG.md`, `MASTER_PLAN.md`, `README.md`, `docs/VISION.md`.

### Compatibilité
- Aucun changement de format ; `core/`, `tools/`, `schema/` inchangés.

### Non testé
- Affichage et gestes dans un vrai navigateur.

## 2026-09-29 — Étape 2

### Ajouté
- `core/creature_model.py` : classe `CreatureProject` (création, ajout, suppression, duplication, transformations, renommage, changement de forme, re-parentage, réordonnancement, sockets, chargement/sauvegarde) ;
- opérations transactionnelles (revalidation, restauration si invalide) ;
- formes `pyramid` et `plane` ;
- 22 tests (`tests/`), démo (`examples/build_demo.py`, `examples/demo_dragon.creature.json`) ;
- `core/operations.md`, `docs/VISION.md`, `reports/02_STEP_2.md`.

### Modifié
- `tools/validate_creature.py` : fonction `check(d)` réutilisable, sortie CLI inchangée, formes ajoutées ;
- `schema/creature-project.schema.json` : enum des formes ;
- `core/format.md`, `MASTER_PLAN.md`, `README.md`, `CURRENT_STATE.md`.

### Compatibilité
- `formatVersion` reste `1.0` ; les projets de l'Étape 1 sont lus sans changement.

### Non inclus
- interface, rendu 3D, symétrie, sculpture, annuler/rétablir, rig, animation, comportement, export.

## 2026-09-29 — Étape 1

### Ajouté
- format interne CreatureStudio ;
- schéma JSON ;
- hiérarchie parent/enfant ;
- transformations 3D ;
- primitives `cube`, `sphere`, `cylinder`, `cone`, `capsule`, `custom` ;
- sockets ;
- espaces réservés pour matériaux, squelette, animations, comportements et export ;
- exemple de créature ;
- validateur sans dépendance externe ;
- documentation de reprise.

### Non inclus
- rendu 3D ;
- édition graphique ;
- rig ;
- animation ;
- comportement ;
- export Minecraft.
