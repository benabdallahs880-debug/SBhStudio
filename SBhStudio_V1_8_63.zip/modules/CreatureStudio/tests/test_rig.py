"""Tests de l'Étape 4 : pivots, os, limites, cohérence avec suppression/duplication."""
import copy, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import CreatureError, CreatureProject, shape_y_bounds  # noqa: E402

EXAMPLE = ROOT / "examples" / "test_creature.creature.json"


def example():
    return CreatureProject.load(EXAMPLE)


def near(test, a, b, eps=1e-9):
    test.assertEqual(len(a), len(b))
    for x, y in zip(a, b):
        test.assertAlmostEqual(x, y, delta=eps)


class TestPivot(unittest.TestCase):
    def test_default_pivot_absent_and_old_files_valid(self):
        p = example()
        self.assertNotIn("pivot", p.get_part("part_head"))
        self.assertEqual(p.data["skeleton"]["bones"], [])

    def test_set_pivot_keeps_shape_in_place(self):
        p = example()
        p.set_transform("part_leg_l", rotation=[10, 20, 30], scale=[1, 2, 1])
        probe = [0.3, -0.4, 0.5]
        before = p.local_point("part_leg_l", probe)
        p.set_pivot("part_leg_l", [0, 0.5, 0])
        near(self, p.local_point("part_leg_l", probe), before)
        p.set_pivot("part_leg_l", [0.2, -0.3, 0.1])
        near(self, p.local_point("part_leg_l", probe), before)

    def test_set_pivot_without_keep_moves_shape(self):
        p = example()
        before = p.local_point("part_leg_l", [0, 0, 0])
        p.set_pivot("part_leg_l", [0, 0.5, 0], keep_in_place=False)
        self.assertNotEqual(p.local_point("part_leg_l", [0, 0, 0]), before)

    def test_pivot_is_center_of_rotation(self):
        p = example()
        p.set_pivot("part_leg_l", [0, 0.5, 0])
        pivot_world_before = p.local_point("part_leg_l", [0, 0.5, 0])
        p.set_transform("part_leg_l", rotation=[45, 0, 0])
        near(self, p.local_point("part_leg_l", [0, 0.5, 0]), pivot_world_before)

    def test_presets(self):
        p = example()
        p.set_shape("part_leg_l", "cylinder", {"radius": 0.2, "height": 2})
        p.pivot_preset("part_leg_l", "top")
        self.assertEqual(p.get_part("part_leg_l")["pivot"], [0, 1.0, 0])
        p.pivot_preset("part_leg_l", "bottom")
        self.assertEqual(p.get_part("part_leg_l")["pivot"], [0, -1.0, 0])
        p.pivot_preset("part_leg_l", "center")
        self.assertEqual(p.get_part("part_leg_l")["pivot"], [0, 0, 0])
        with self.assertRaises(CreatureError):
            p.pivot_preset("part_leg_l", "left")

    def test_y_bounds(self):
        self.assertEqual(shape_y_bounds("capsule", {"radius": 0.5, "height": 1}), (-1.0, 1.0))
        self.assertEqual(shape_y_bounds("plane"), (0, 0))

    def test_invalid_pivot_refused_and_unchanged(self):
        p = example()
        before = copy.deepcopy(p.data)
        for bad in ([1, 2], [0, "a", 0], [float("inf"), 0, 0]):
            with self.assertRaises(CreatureError):
                p.set_pivot("part_head", bad)
        self.assertEqual(p.data, before)


class TestBones(unittest.TestCase):
    def test_add_bone_enables_skeleton_and_is_unique(self):
        p = example()
        b = p.add_bone("part_leg_l")
        self.assertTrue(p.data["skeleton"]["enabled"])
        self.assertEqual(p.bone_of_part("part_leg_l")["id"], b)
        with self.assertRaises(CreatureError):
            p.add_bone("part_leg_l")
        p.remove_bone(b)
        self.assertFalse(p.data["skeleton"]["enabled"])

    def test_auto_rig_and_bone_parent_derived_from_hierarchy(self):
        p = example()
        p.add_bone("part_body")
        created = p.auto_rig()
        self.assertEqual(len(created), 6)
        self.assertEqual(p.auto_rig(), [])
        head_bone = p.bone_of_part("part_head")["id"]
        self.assertEqual(p.bone_parent(head_bone), p.bone_of_part("part_body")["id"])
        self.assertIsNone(p.bone_parent(p.bone_of_part("part_body")["id"]))

    def test_bone_parent_skips_parts_without_bone(self):
        p = example()
        p.add_bone("part_body")
        eye = p.add_part("Oeil", "sphere", parent_id="part_head")   # part_head n'a pas d'os
        b = p.add_bone(eye)
        self.assertEqual(p.bone_parent(b), p.bone_of_part("part_body")["id"])

    def test_limits(self):
        p = example()
        b = p.add_bone("part_leg_l", limits={"x": [-30, 60]})
        p.set_bone_limits(b, {"x": [-45, 45], "z": [0, 10]})
        self.assertEqual(p.get_bone(b)["limits"], {"x": [-45, 45], "z": [0, 10]})
        before = copy.deepcopy(p.data)
        for bad in ({"x": [10, -10]}, {"w": [0, 1]}, {"x": [1]}, {"y": "a"}):
            with self.assertRaises(CreatureError):
                p.set_bone_limits(b, bad)
        self.assertEqual(p.data, before)
        p.set_bone_limits(b, None)
        self.assertNotIn("limits", p.get_bone(b))

    def test_remove_part_removes_its_bones(self):
        p = example()
        p.auto_rig()
        r = p.remove_part("part_head")
        self.assertEqual(len(r["removed_bones"]), 1)
        self.assertIsNone(next((b for b in p.data["skeleton"]["bones"] if b["partId"] == "part_head"), None))

    def test_duplicate_copies_bones_with_new_ids(self):
        p = example()
        p.add_part("Oeil", "sphere", parent_id="part_arm_l")
        p.auto_rig()
        p.set_bone_limits(p.bone_of_part("part_arm_l")["id"], {"x": [-20, 20]})
        clone = p.duplicate_part("part_arm_l")
        self.assertIsNotNone(p.bone_of_part(clone))
        self.assertEqual(p.bone_of_part(clone)["limits"], {"x": [-20, 20]})
        ids = [b["id"] for b in p.data["skeleton"]["bones"]]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(len(p.data["skeleton"]["bones"]), len(p.data["parts"]))

    def test_duplicate_of_pivoted_part_keeps_pivot(self):
        p = example()
        p.pivot_preset("part_leg_l", "top")
        clone = p.duplicate_part("part_leg_l")
        self.assertEqual(p.get_part(clone)["pivot"], p.get_part("part_leg_l")["pivot"])


class TestValidatorRig(unittest.TestCase):
    def base(self):
        return copy.deepcopy(example().data)

    def test_validator_rejects_bad_rigs(self):
        d = self.base()
        d["skeleton"]["bones"] = [{"id": "b1", "name": "x", "partId": "nope"}]
        self.assertIn("missing part", validate_creature.check(d)[0])
        d["skeleton"]["bones"] = [{"id": "b1", "name": "x", "partId": "part_head"}, {"id": "b2", "name": "y", "partId": "part_head"}]
        self.assertIn("more than one bone", validate_creature.check(d)[0])
        d["skeleton"]["bones"] = [{"id": "b1", "name": "x", "partId": "part_head"}, {"id": "b1", "name": "y", "partId": "part_body"}]
        self.assertIn("duplicate bone id", validate_creature.check(d)[0])
        d = self.base(); d["skeleton"] = []
        self.assertIn("skeleton must be an object", validate_creature.check(d)[0])
        d = self.base(); d["parts"][1]["pivot"] = [1, 2]
        self.assertIn("invalid pivot", validate_creature.check(d)[0])

    def test_step1_and_step2_files_still_valid(self):
        self.assertEqual(validate_creature.check(self.base())[0], None)
        d = self.base(); d["skeleton"] = {"enabled": False}      # sans "bones" : accepté
        self.assertEqual(validate_creature.check(d)[0], None)


if __name__ == "__main__":
    unittest.main()
