"""Tests de l'Étape 6 : poses nommées, animations, images clés, échantillonnage, cohérence avec les os."""
import copy, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import CreatureError, CreatureProject, sample_pose  # noqa: E402

EXAMPLE = ROOT / "examples" / "test_creature.creature.json"


def rigged():
    p = CreatureProject.load(EXAMPLE)
    p.auto_rig()
    return p


def near(t, a, b, eps=1e-9):
    t.assertEqual(len(a), len(b))
    for x, y in zip(a, b):
        t.assertAlmostEqual(x, y, delta=eps)


class TestPoses(unittest.TestCase):
    def test_old_files_valid_and_pose_library(self):
        p = rigged()
        self.assertIsNone(validate_creature.check(p.data)[0])
        b = p.bone_of_part("part_head")["id"]
        q = p.add_pose("Salut", {b: {"rotation": [20, 0, 0]}})
        self.assertEqual(p.get_pose(q)["name"], "Salut")
        p.remove_pose(q)
        with self.assertRaises(CreatureError):
            p.get_pose(q)

    def test_invalid_poses_refused_and_unchanged(self):
        p = rigged()
        before = copy.deepcopy(p.data)
        b = p.bone_of_part("part_head")["id"]
        for bad in ({"nope": {"rotation": [0, 0, 0]}}, {b: {"rotation": [1, 2]}}, {b: {"scale": [1, 1, 1]}}, {b: "x"}):
            with self.assertRaises(CreatureError):
                p.add_pose("X", bad)
        self.assertEqual(p.data, before)


class TestAnimations(unittest.TestCase):
    def test_create_keyframes_sorted_and_replace(self):
        p = rigged()
        b = p.bone_of_part("part_head")["id"]
        a = p.add_animation("Salut", 2.0, loop=False)
        p.set_keyframe(a, 1.0, {b: {"rotation": [30, 0, 0]}})
        p.set_keyframe(a, 0.0, {})
        p.set_keyframe(a, 2.0, {b: {"rotation": [0, 0, 0]}})
        p.set_keyframe(a, 1.0, {b: {"rotation": [40, 0, 0]}})        # remplace l'image clé existante
        keys = p.get_animation(a)["keyframes"]
        self.assertEqual([k["time"] for k in keys], [0.0, 1.0, 2.0])
        self.assertEqual(keys[1]["pose"][b]["rotation"], [40, 0, 0])
        p.remove_keyframe(a, 0.0)
        self.assertEqual(len(p.get_animation(a)["keyframes"]), 2)
        with self.assertRaises(CreatureError):
            p.remove_keyframe(a, 0.5)

    def test_invalid_animation_data_refused(self):
        p = rigged()
        a = p.add_animation("A", 1.0)
        before = copy.deepcopy(p.data)
        for call in (lambda: p.add_animation("B", 0), lambda: p.add_animation("B", -1), lambda: p.add_animation("B", float("inf")),
                     lambda: p.set_keyframe(a, 1.5, {}), lambda: p.set_keyframe(a, -0.1, {}),
                     lambda: p.set_keyframe(a, 0.5, {"nope": {"rotation": [0, 0, 0]}}),
                     lambda: p.update_animation(a, loop="oui"), lambda: p.add_animation("", 1.0)):
            with self.assertRaises(CreatureError):
                call()
        self.assertEqual(p.data, before)

    def test_shrinking_duration_below_a_key_is_refused(self):
        p = rigged()
        a = p.add_animation("A", 2.0)
        p.set_keyframe(a, 1.5, {})
        with self.assertRaises(CreatureError):
            p.update_animation(a, duration=1.0)
        p.update_animation(a, duration=1.5, name="B", loop=False)
        self.assertEqual((p.get_animation(a)["duration"], p.get_animation(a)["name"], p.get_animation(a)["loop"]), (1.5, "B", False))

    def test_removing_bones_cleans_animations_and_poses(self):
        p = rigged()
        bh = p.bone_of_part("part_head")["id"]
        bt = p.bone_of_part("part_tail")["id"]
        a = p.add_animation("A", 1.0)
        p.set_keyframe(a, 0.0, {bh: {"rotation": [1, 0, 0]}, bt: {"rotation": [0, 5, 0]}})
        q = p.add_pose("P", {bh: {"rotation": [2, 0, 0]}, bt: {"rotation": [0, 3, 0]}})
        p.remove_bone(bt)
        self.assertEqual(list(p.get_animation(a)["keyframes"][0]["pose"]), [bh])
        self.assertEqual(list(p.get_pose(q)["bones"]), [bh])
        p.remove_part("part_head")                                   # supprime aussi l'os de la tête
        self.assertEqual(p.get_animation(a)["keyframes"][0]["pose"], {})
        self.assertEqual(p.get_pose(q)["bones"], {})
        self.assertIsNone(validate_creature.check(p.data)[0])

    def test_remove_animation(self):
        p = rigged()
        a = p.add_animation("A", 1.0)
        p.remove_animation(a)
        self.assertEqual(p.data["animations"], [])


class TestSampling(unittest.TestCase):
    def make(self, loop):
        p = rigged()
        b = p.bone_of_part("part_head")["id"]
        a = p.add_animation("A", 2.0, loop=loop)
        p.set_keyframe(a, 0.5, {b: {"rotation": [0, 0, 0]}})
        p.set_keyframe(a, 1.5, {b: {"rotation": [40, 20, -10], "position": [0, 1, 0]}})
        return p, a, b

    def test_linear_interpolation_between_keys(self):
        p, a, b = self.make(loop=False)
        s = p.sample(a, 1.0)[b]
        near(self, s["rotation"], [20, 10, -5])
        near(self, s["position"], [0, 0.5, 0])                       # position absente de la 1re clé = 0

    def test_not_looping_holds_first_and_last(self):
        p, a, b = self.make(loop=False)
        near(self, p.sample(a, 0.0)[b]["rotation"], [0, 0, 0])
        near(self, p.sample(a, 9.0)[b]["rotation"], [40, 20, -10])
        near(self, p.sample(a, -3.0)[b]["rotation"], [0, 0, 0])

    def test_looping_wraps_last_key_to_first(self):
        p, a, b = self.make(loop=True)
        near(self, p.sample(a, 2.0)[b]["rotation"], p.sample(a, 0.0)[b]["rotation"])        # t = durée = t 0
        near(self, p.sample(a, 4.25)[b]["rotation"], p.sample(a, 0.25)[b]["rotation"])      # modulo
        # t=2.0 - epsilon : proche de la valeur à 0.5+2.0 = 2.5 (retour vers la 1re clé), donc à mi-chemin entre clé 1.5 et 2.5
        near(self, p.sample(a, 2.0 - 1e-9)[b]["rotation"], [20, 10, -5], eps=1e-6)
        near(self, p.sample(a, 0.0)[b]["rotation"], [20, 10, -5])                            # t=0 : mi-chemin entre clé 1.5 (=t -0.5) et 0.5

    def test_single_key_and_empty(self):
        p = rigged()
        b = p.bone_of_part("part_head")["id"]
        a = p.add_animation("A", 1.0, loop=True)
        self.assertEqual(p.sample(a, 0.3), {})
        p.set_keyframe(a, 0.2, {b: {"rotation": [5, 0, 0]}})
        near(self, p.sample(a, 0.9)[b]["rotation"], [5, 0, 0])

    def test_sample_pose_is_pure_function(self):
        anim = {"duration": 1.0, "loop": False, "keyframes": [{"time": 0, "pose": {"b": {"rotation": [0, 0, 0]}}}, {"time": 1, "pose": {"b": {"rotation": [10, 0, 0]}}}]}
        snap = copy.deepcopy(anim)
        near(self, sample_pose(anim, 0.3)["b"]["rotation"], [3, 0, 0])
        self.assertEqual(anim, snap)


class TestValidatorAnimation(unittest.TestCase):
    def test_validator_rejects_bad_animations(self):
        p = rigged()
        b = p.bone_of_part("part_head")["id"]
        a = p.add_animation("A", 1.0)
        p.set_keyframe(a, 0.0, {b: {"rotation": [0, 0, 0]}})
        p.set_keyframe(a, 1.0, {b: {"rotation": [1, 0, 0]}})
        p.add_pose("P", {b: {"rotation": [1, 0, 0]}})
        good = copy.deepcopy(p.data)
        self.assertIsNone(validate_creature.check(good)[0])
        cases = [
            (lambda d: d["animations"][0].__setitem__("duration", 0), "invalid duration"),
            (lambda d: d["animations"][0].__setitem__("loop", 1), "invalid loop"),
            (lambda d: d["animations"][0]["keyframes"][1].__setitem__("time", 0.0), "invalid keyframe time"),   # non strictement croissant
            (lambda d: d["animations"][0]["keyframes"][1].__setitem__("time", 5), "invalid keyframe time"),     # > durée
            (lambda d: d["animations"][0]["keyframes"][0]["pose"].__setitem__("nope", {}), "invalid pose in animation"),
            (lambda d: d["animations"][0]["keyframes"][0]["pose"][b].__setitem__("rotation", [1]), "invalid pose in animation"),
            (lambda d: d["animations"].append(copy.deepcopy(d["animations"][0])), "duplicate animation id"),
            (lambda d: d["skeleton"]["poses"][0].__setitem__("bones", {"nope": {}}), "invalid pose"),
            (lambda d: d["skeleton"]["poses"].append(copy.deepcopy(d["skeleton"]["poses"][0])), "duplicate pose id"),
            (lambda d: d.__setitem__("animations", {}), "animations must be an array"),
            (lambda d: d["skeleton"].__setitem__("poses", {}), "skeleton.poses must be an array"),
        ]
        for mutate, expected in cases:
            d = copy.deepcopy(good)
            mutate(d)
            err = validate_creature.check(d)[0]
            self.assertTrue(err and expected in err, f"{expected!r} attendu, obtenu {err!r}")


if __name__ == "__main__":
    unittest.main()
