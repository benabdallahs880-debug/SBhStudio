"""Tests du personnage « Soldat standard » (examples/soldat_standard.creature.json) : validité, symétrie, rig, animations dans les limites, comportements."""
import copy, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import CreatureProject, mirror_rotation, mirror_vector  # noqa: E402

FILE = ROOT / "examples" / "soldat_standard.creature.json"


def soldier():
    return CreatureProject.load(FILE)


class TestSoldier(unittest.TestCase):
    def test_valid_and_complete(self):
        p = soldier()
        self.assertIsNone(validate_creature.check(p.data)[0])
        names = {x["name"] for x in p.data["parts"]}
        for needed in ("Tête", "Turban", "Voile", "Pan de keffieh", "Écharpe", "Plaque", "Sac à dos", "Bras gauche", "Bras droit", "Jambe haute gauche",
                       "Jambe haute droite", "Botte gauche", "Botte droite", "Gant gauche", "Gant droit", "Œil gauche", "Œil droit"):
            self.assertIn(needed, names)
        self.assertEqual((len(p.data["parts"]), len(p.data["skeleton"]["bones"]), len(p.data["behaviors"]["graphs"])), (38, 17, 5))
        self.assertTrue(p.data["skeleton"]["enabled"] and p.data["behaviors"]["enabled"])

    def test_names_are_gender_correct(self):
        names = {x["name"] for x in soldier().data["parts"]}
        for ok in ("Bras droit", "Avant-bras droit", "Gant droit", "Œil droit", "Genouillère droite", "Jambe haute droite", "Poche droite", "Épaulière droite"):
            self.assertIn(ok, names)
        for bad in ("Bras droite", "Gant droite", "Genouillère droit", "Œil droite"):
            self.assertNotIn(bad, names)

    def test_every_left_part_has_an_exact_right_twin(self):
        p = soldier()
        pairs = [x for x in p.data["parts"] if x.get("mirror") and "gauche" in x["name"].lower()]
        self.assertEqual(len(pairs), 11)          # Œil, Poche, Épaulière, Bras, Avant-bras, Gant, Jambe haute, Poche cargo, Genouillère, Jambe basse, Botte
        for a in pairs:
            b = p.twin(a["id"])
            self.assertEqual(b["transform"]["position"], mirror_vector(a["transform"]["position"], "x"))
            self.assertEqual(b["transform"]["rotation"], mirror_rotation(a["transform"]["rotation"], "x"))
            self.assertEqual((a["shape"], a["materialId"], a.get("parameters")), (b["shape"], b["materialId"], b.get("parameters")))
        for bone in p.data["skeleton"]["bones"]:
            if "gauche" in bone["name"]:
                twin = p.twin(bone["partId"])
                mine, theirs = bone["limits"], p.bone_of_part(twin["id"])["limits"]
                self.assertEqual(mine["x"], theirs["x"])
                self.assertEqual(theirs["z"], [-mine["z"][1], -mine["z"][0]])

    def test_joint_pivots_hang_from_the_joint(self):
        p = soldier()
        for name in ("Bras gauche", "Avant-bras gauche", "Jambe haute gauche", "Jambe basse gauche", "Tête"):
            part = next(x for x in p.data["parts"] if x["name"] == name)
            self.assertIn("pivot", part, name)
            self.assertNotEqual(part["pivot"][1], 0, name)

    def test_all_animation_and_pose_values_respect_bone_limits(self):
        p = soldier()
        bones = {b["id"]: b for b in p.data["skeleton"]["bones"]}

        def check(pose, where):
            for bid, entry in pose.items():
                lim = bones[bid].get("limits", {})
                for i, v in enumerate(entry.get("rotation", [])):
                    lo, hi = lim.get("xyz"[i], (-1e9, 1e9))
                    self.assertTrue(lo - 1e-6 <= v <= hi + 1e-6, f"{where}: {bones[bid]['name']} {'xyz'[i]}={v} hors de [{lo}, {hi}]")
        for a in p.data["animations"]:
            for k in a["keyframes"]:
                check(k["pose"], f"{a['name']}@{k['time']}")
        for q in p.data["skeleton"]["poses"]:
            check(q["bones"], q["name"])

    def test_animations_present_and_loops_close(self):
        p = soldier()
        by = {a["name"]: a for a in p.data["animations"]}
        self.assertEqual(set(by), {"Repos", "Marche", "Course", "Attaque", "Dégâts", "Mort"})
        for name in ("Repos", "Marche", "Course"):
            a = by[name]
            self.assertTrue(a["loop"])
            s0, s1 = p.sample(a["id"], 0), p.sample(a["id"], a["duration"] - 1e-7)
            for bid in s0:
                for field in s0[bid]:
                    for x, y in zip(s0[bid][field], s1[bid][field]):
                        self.assertAlmostEqual(x, y, delta=1e-3, msg=f"{name} boucle continue")
        for name in ("Attaque", "Dégâts", "Mort"):
            self.assertFalse(by[name]["loop"])
        legs = [b["id"] for b in p.data["skeleton"]["bones"] if b["name"] in ("Jambe haute gauche", "Jambe haute droite")]
        s = p.sample(by["Marche"]["id"], 0.125)
        self.assertAlmostEqual(s[legs[0]]["rotation"][0], -s[legs[1]]["rotation"][0], places=6)        # jambes en opposition de phase

    def test_behaviors_pick_the_right_rule(self):
        p = soldier()
        pick = lambda **kw: p.select_behavior({"playerDistance": None, "time": "day", "healthPercent": 100, "attacked": False, "inWater": False, "random": 0.5, **kw})["name"]
        self.assertEqual(pick(), "Patrouiller")
        self.assertEqual(pick(time="night"), "Veiller la nuit")
        self.assertEqual(pick(playerDistance=15), "Poursuivre le joueur")
        self.assertEqual(pick(playerDistance=25), "Patrouiller")                  # hors portée de détection (20)
        self.assertEqual(pick(playerDistance=1.5), "Attaquer au contact")
        self.assertEqual(pick(playerDistance=1.5, healthPercent=10), "Fuir si blessé")
        stats = p.get_stats()
        self.assertEqual((stats["health"], stats["damage"], stats["detectionRange"]), (30, 5, 20))
        anims = {a["id"] for a in p.data["animations"]}
        for g in p.data["behaviors"]["graphs"]:
            for act in g["actions"]:
                self.assertIn(act["animationId"], anims)

    def test_texture_and_materials(self):
        p = soldier()
        tex = p.data["textures"][0]
        self.assertEqual((tex["width"], tex["height"], len(tex["pixels"])), (48, 32, 1536))
        self.assertEqual(set(tex["palette"]), {None, "#f2f2f2", "#101010"})
        keffieh = next(m for m in p.data["materials"] if m["name"] == "Keffieh")
        textured = [x["name"] for x in p.data["parts"] if x["materialId"] == keffieh["id"]]
        self.assertEqual(set(textured), {"Tête", "Turban", "Voile", "Pan de keffieh"})
        eyes = next(m for m in p.data["materials"] if m["name"] == "Lueur des yeux")
        self.assertEqual(eyes["emissive"], 1.0)
        self.assertTrue(all(x["materialId"] for x in p.data["parts"]), "toutes les parties ont une matière")

    def test_is_editable_with_the_model_api(self):
        p = soldier()
        before = len(p.data["parts"])
        p.rotate(next(x["id"] for x in p.data["parts"] if x["name"] == "Bras gauche"), [10, 0, 0], symmetric=True)
        p.add_part("Casque", "sphere", parent_id=next(x["id"] for x in p.data["parts"] if x["name"] == "Tête"))
        self.assertEqual(len(p.data["parts"]), before + 1)
        self.assertIsNone(validate_creature.check(p.data)[0])


if __name__ == "__main__":
    unittest.main()
