"""Teste la logique JS de l'éditeur (bloc ==CORE==) avec Node et la valide avec le validateur Python.
Ignoré (skip) si Node n'est pas installé. Lancer : python -m unittest discover -s tests -v"""
import json, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "editor" / "creature_editor.html").read_text(encoding="utf-8")
CORE = HTML.split("// ==CORE==")[1].split("// ==ENDCORE==")[0]

TEST_JS = r"""
const assert=require('assert');
const p=Project.create('Dragon JS');
const h=p.add('Tête','sphere');const c=p.add('Corne','cone',h);const c2=p.duplicate(c,[.5,0,0]);
assert.strictEqual(p.part(c2).name,'Corne (copie)');
p.setT(h,{position:[0,1,0],rotation:[0,90,0],scale:[2,2,2]});
assert.throws(()=>p.setT(h,{scale:[0,1,1]}));
assert.throws(()=>p.reparent(h,c));                 // cycle
assert.throws(()=>p.remove(p.root));                // racine
p.reorder(c2,0);assert.strictEqual(p.kids(h)[0].id,c2);
const n=p.d.parts.length;p.remove(c);assert.strictEqual(p.d.parts.length,n-1);
p.undo();assert.strictEqual(p.d.parts.length,n);p.redo();assert.strictEqual(p.d.parts.length,n-1);
assert.throws(()=>p.add('X','torus'));
p.add('Toit','pyramid');p.add('Sol','plane');
console.log(JSON.stringify(p.d));
"""

RENDER = HTML.split("// ---- rendu")[1].split("// ---- application")[0].split("\n", 1)[1]

TOUCH_JS = r"""
const assert=require('assert');const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,a+' != '+b);
// 1) un geste = une seule entrée d'historique, annulable
const p=Project.create('Geste');const a=p.add('a','cube');p.hist=[];
p.begin();for(let i=0;i<20;i++)p.live(a,{position:[i*.1,0,0],rotation:[0,i,0]});p.commit();
assert.strictEqual(p.hist.length,1);near(p.part(a).transform.position[0],1.9);
p.undo();near(p.part(a).transform.position[0],0);
p.begin();p.commit();assert.strictEqual(p.hist.length,0);   // geste sans effet : rien dans l'historique
// 2) déplacement écran -> local, caméra de face, parent identité
let W=worlds(p.d),cam={yaw:0,pitch:0,dist:9},fc=900;
let d=dragDelta(W,p.part(a),90,0,cam,fc);near(d[0],.9);near(d[1],0);near(d[2],0);   // 90 px à z=9 : 0.9 unité
d=dragDelta(W,p.part(a),0,90,cam,fc);near(d[1],-.9);                              // vers le bas : y diminue
// 3) caméra tournée de 90° : glisser à droite = déplacer sur l'axe Z monde
cam={yaw:Math.PI/2,pitch:0,dist:9};d=dragDelta(W,p.part(a),90,0,cam,fc);near(d[0],0);near(d[2],.9);
// 4) parent mis à l'échelle x2 : le déplacement local est divisé par 2
cam={yaw:0,pitch:0,dist:9};const c=p.add('c','cube',a);p.setT(a,{scale:[2,2,2]});W=worlds(p.d);
d=dragDelta(W,p.part(c),90,0,cam,fc);near(d[0],.45);
console.log('touch ok');
"""

@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestEditorCore(unittest.TestCase):
    def test_js_core_and_python_validator_agree(self):
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "t.js"; js.write_text(CORE + TEST_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            out = Path(d) / "out.creature.json"; out.write_text(r.stdout, encoding="utf-8")
            v = subprocess.run([sys.executable, str(ROOT / "tools" / "validate_creature.py"), str(out)], capture_output=True, text=True)
            self.assertEqual(v.returncode, 0, v.stdout)

RIG_JS = r"""
const assert=require('assert');
const p=Project.create('Rig JS');const leg=p.add('Jambe','cylinder',null,[0,-1,0]);
p.setT(leg,{rotation:[10,20,30],scale:[1,2,1]});p.pivotPreset(leg,'top');
const oeil=p.add('Oeil','sphere',leg);p.autoRig();p.setLimits(p.boneOf(leg).id,{x:[-45,45]});
assert.strictEqual(p.boneParent(p.part(oeil).parentId).partId,leg);   // boneParent(pid) = os le plus proche à partir de pid (inclus)
assert.throws(()=>p.addBone(leg));assert.throws(()=>p.setLimits(p.boneOf(leg).id,{x:[9,1]}));assert.throws(()=>p.setPivot(leg,[1,2]));
const c=p.duplicate(leg);assert.ok(p.boneOf(c)&&p.boneOf(c).limits.x[1]===45);
assert.strictEqual(p.d.skeleton.bones.length,p.d.parts.length);
p.remove(c);assert.strictEqual(p.d.skeleton.bones.length,p.d.parts.length);
// pivot au sommet : on renvoie la position corrigée et les bornes pour comparer avec Python
console.log(JSON.stringify({project:p.d,pos:p.part(leg).transform.position,pivot:p.part(leg).pivot,yb:['cube','sphere','cylinder','cone','capsule','pyramid','plane','custom'].map(s=>yBounds(s))}));
"""

@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestEditorRigParity(unittest.TestCase):
    def test_js_rig_matches_python_model(self):
        sys.path.insert(0, str(ROOT / "core"))
        from creature_model import CreatureProject, shape_y_bounds
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "r.js"; js.write_text(CORE + RIG_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            out = json.loads(r.stdout)
            f = Path(d) / "rig.creature.json"; f.write_text(json.dumps(out["project"]), encoding="utf-8")
            v = subprocess.run([sys.executable, str(ROOT / "tools" / "validate_creature.py"), str(f)], capture_output=True, text=True)
            self.assertEqual(v.returncode, 0, v.stdout)
        # mêmes opérations côté Python : position corrigée et pivot identiques
        p = CreatureProject.new("Rig PY")
        leg = p.add_part("Jambe", "cylinder", position=[0, -1, 0])
        p.set_transform(leg, rotation=[10, 20, 30], scale=[1, 2, 1])
        p.pivot_preset(leg, "top")
        self.assertEqual(p.get_part(leg)["pivot"], out["pivot"])
        for a, b in zip(p.get_part(leg)["transform"]["position"], out["pos"]):
            self.assertAlmostEqual(a, b, places=9)
        shapes = ["cube", "sphere", "cylinder", "cone", "capsule", "pyramid", "plane", "custom"]
        for shape, yb in zip(shapes, out["yb"]):
            self.assertEqual(list(shape_y_bounds(shape)), yb, shape)


SYM_JS = r"""
const assert=require('assert');
const p=Project.create('Sym');const arm=p.add('Bras gauche','cylinder',null,[1.2,.3,.1]);
p.setT(arm,{rotation:[15,25,35],scale:[.4,1.2,.4]});p.setPivot(arm,[0,.6,0]);
const hand=p.add('Main gauche','cube',arm,[.1,-.7,.2]);p.setT(hand,{rotation:[10,-20,30]});
p.addBone(arm);p.setLimits(p.boneOf(arm).id,{x:[-30,60],y:[10,40]});
const a2=p.mirror(arm,'x'),h2=p.kids(a2)[0].id;
assert.strictEqual(p.part(a2).name,'Bras droit');assert.strictEqual(p.part(h2).name,'Main droite');
assert.deepStrictEqual(p.part(arm).mirror,{axis:'x',partId:a2});assert.strictEqual(p.twin(hand).id,h2);
assert.deepStrictEqual(p.boneOf(a2).limits,{x:[-30,60],y:[-40,-10]});
assert.throws(()=>p.mirror(arm,'x'));assert.throws(()=>p.mirror(p.root,'x'));
const snap=JSON.stringify({project:p.d,a2:p.part(a2),h2:p.part(h2),bone:p.boneOf(a2)});
p.setT(arm,{position:[2,0,0]},true);assert.strictEqual(p.part(a2).transform.position[0],-2);
p.setT(arm,{position:[3,0,0]});assert.strictEqual(p.part(a2).transform.position[0],-2);     // sans symétrie : indépendant
const d=p.add('Doigt gauche','cube',arm,[.2,-1,0],'x');assert.strictEqual(p.twin(d).parentId,a2);assert.strictEqual(p.twin(d).name,'Doigt droit');
p.remove(arm,true);assert.strictEqual(p.d.parts.length,1);   // la racine seule
p.undo();assert.ok(p.part(arm)&&p.part(a2));
const q=p.duplicate(arm);assert.ok(!p.part(q).mirror);          // lien externe non copié
p.remove(a2);assert.ok(!p.part(arm).mirror);                    // lien orphelin nettoyé
console.log(snap);
"""

@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestEditorSymmetryParity(unittest.TestCase):
    def test_js_symmetry_matches_python_model(self):
        sys.path.insert(0, str(ROOT / "core"))
        from creature_model import CreatureProject
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "s.js"; js.write_text(CORE + SYM_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            out = json.loads(r.stdout)
            f = Path(d) / "sym.creature.json"; f.write_text(json.dumps(out["project"]), encoding="utf-8")
            v = subprocess.run([sys.executable, str(ROOT / "tools" / "validate_creature.py"), str(f)], capture_output=True, text=True)
            self.assertEqual(v.returncode, 0, v.stdout)
        p = CreatureProject.new("Sym")
        arm = p.add_part("Bras gauche", "cylinder", position=[1.2, 0.3, 0.1])
        p.set_transform(arm, rotation=[15, 25, 35], scale=[0.4, 1.2, 0.4]); p.set_pivot(arm, [0, 0.6, 0])
        hand = p.add_part("Main gauche", "cube", parent_id=arm, position=[0.1, -0.7, 0.2]); p.set_transform(hand, rotation=[10, -20, 30])
        p.add_bone(arm, limits={"x": [-30, 60], "y": [10, 40]})
        a2 = p.mirror_part(arm, "x"); h2 = p.children(a2)[0]["id"]
        for mine, theirs in ((p.get_part(a2), out["a2"]), (p.get_part(h2), out["h2"])):
            self.assertEqual(mine["name"], theirs["name"])
            self.assertEqual(mine.get("pivot"), theirs.get("pivot"))
            for k in ("position", "rotation", "scale"):
                for a, b in zip(mine["transform"][k], theirs["transform"][k]):
                    self.assertAlmostEqual(a, b, places=9)
        self.assertEqual(p.bone_of_part(a2)["limits"], out["bone"]["limits"])


APPEARANCE_JS = r"""
const assert=require('assert');
const p=Project.create('App');const a=p.add('Tête','cube');
const t=p.addTexture('Yeux',4,4);p.paint(t,[[0,0],[1,0],[9,9],[-1,0]],'#FF0000');p.fill(t,3,3,'#00ff00');
const m=p.addMaterial('Peau','#33AA55',{opacity:.9,emissive:.2,textureId:t});p.assignMaterial(a,m);p.updateMaterial(m,{color:'#112233',roughness:.4});
assert.throws(()=>p.addMaterial('X','red'));assert.throws(()=>p.updateMaterial(m,{opacity:2}));assert.throws(()=>p.updateMaterial(m,{size:1}));
assert.throws(()=>p.addTexture('Bad',0,4));assert.throws(()=>p.addTexture('Bad',2.5,4));assert.throws(()=>p.assignMaterial(a,'nope'));assert.throws(()=>p.fill(t,9,9,'#ffffff'));
const before=JSON.stringify(p.d);assert.throws(()=>p.updateMaterial(m,{textureId:'nope'}));assert.strictEqual(JSON.stringify(p.d),before);   // transaction annulée
const m2=p.addMaterial('Autre');p.assignMaterial(a,m2);p.removeMaterial(m2);assert.strictEqual(p.part(a).materialId,null);p.assignMaterial(a,m);
const copy=p.duplicate(a);assert.strictEqual(p.part(copy).materialId,m);
console.log(JSON.stringify({project:p.d,materials:p.d.materials,textures:p.d.textures}));
"""

UV_JS = r"""
const assert=require('assert');
const cen=uv=>[uv.reduce((s,c)=>s+c[0],0)/uv.length,uv.reduce((s,c)=>s+c[1],0)/uv.length].map(x=>x.toFixed(4)).join();
for(const shape of SHAPES){const m=mesh({shape,parameters:DEF[shape]});
 assert.strictEqual(m.uv.length,m.f.length,shape);
 m.uv.forEach((u,i)=>{assert.strictEqual(u.length,m.f[i].length,shape+' face '+i);u.forEach(c=>{assert.ok(c[0]>=0&&c[0]<=1&&c[1]>=0&&c[1]<=1,shape+' uv hors [0,1]')})});
 if(shape=='cube'||shape=='custom')assert.strictEqual(new Set(m.uv.map(cen)).size,6,'6 cases distinctes');
 if(shape=='pyramid')assert.strictEqual(new Set(m.uv.map(cen)).size,5,'5 cases distinctes');
 if(shape=='plane')assert.deepStrictEqual(m.uv[0],[[0,1],[1,1],[1,0],[0,0]]);
 if(shape=='cylinder'){assert.deepStrictEqual(m.uv[0][0],[0,1]);assert.deepStrictEqual(m.uv[0][1],[.1,1]);assert.strictEqual(m.uv[m.uv.length-1][2][0],1)}}
console.log('uv ok');
"""

@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestEditorAppearance(unittest.TestCase):
    def test_uv_rules(self):
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "uv.js"; js.write_text(CORE + RENDER + UV_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertIn("uv ok", r.stdout)

    def test_js_appearance_matches_python_model(self):
        sys.path.insert(0, str(ROOT / "core"))
        from creature_model import CreatureProject
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "a.js"; js.write_text(CORE + APPEARANCE_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            out = json.loads(r.stdout)
            f = Path(d) / "app.creature.json"; f.write_text(json.dumps(out["project"]), encoding="utf-8")
            v = subprocess.run([sys.executable, str(ROOT / "tools" / "validate_creature.py"), str(f)], capture_output=True, text=True)
            self.assertEqual(v.returncode, 0, v.stdout)
        p = CreatureProject.new("App")
        a = p.add_part("Tête", "cube")
        t = p.add_texture("Yeux", 4, 4); p.paint(t, [(0, 0), (1, 0), (9, 9), (-1, 0)], "#FF0000"); p.fill(t, 3, 3, "#00ff00")
        m = p.add_material("Peau", "#33AA55", opacity=0.9, emissive=0.2, texture_id=t); p.assign_material(a, m)
        p.update_material(m, color="#112233", roughness=0.4)
        self.assertEqual(p.data["textures"], out["textures"])
        self.assertEqual(p.data["materials"], out["materials"])


ANIM_JS = r"""
const assert=require('assert');
const p=Project.create('Anim');const head=p.add('Tête','sphere');p.autoRig();const b=p.boneOf(head).id;
const out={};
for(const loop of[false,true]){const a=p.addAnimation('A'+loop,2,loop);
 p.setKeyframe(a,1.5,{[b]:{rotation:[40,20,-10],position:[0,1,0]}});p.setKeyframe(a,0.5,{[b]:{rotation:[0,0,0]}});
 out[loop]=[-1,0,0.25,0.5,1,1.5,1.9999,2,4.25,9].map(t=>p.sample(a,t));}
assert.deepStrictEqual(p.anim(p.d.animations[0].id).keyframes.map(k=>k.time),[0.5,1.5]);
assert.throws(()=>p.addAnimation('X',0));assert.throws(()=>p.addAnimation('X',1,true,[{time:5,pose:{}}]));
assert.throws(()=>p.setKeyframe(p.d.animations[0].id,0.5,{nope:{rotation:[0,0,0]}}));assert.throws(()=>p.removeKeyframe(p.d.animations[0].id,0.7));
assert.throws(()=>p.updateAnimation(p.d.animations[0].id,{duration:1}));                       // sous une image clé
const q=p.addPose('Salut',{[b]:{rotation:[10,0,0]}});p.removeBone(b);                          // os supprimé : références nettoyées
assert.deepStrictEqual(p.d.animations[0].keyframes[0].pose,{});assert.deepStrictEqual(p.d.skeleton.poses[0].bones,{});
console.log(JSON.stringify({samples:out,project:p.d}));
"""

PRESET_JS = r"""
const assert=require('assert');const fs=require('fs');
const P=new Project(JSON.parse(fs.readFileSync(process.argv[2],'utf8')));
const legs=P.d.skeleton.bones.filter(x=>/Patte/.test(x.name));
const res={};
for(const k of Object.keys(PRESET_NAMES)){const g=genPreset(P,k);const id=P.addAnimation(g.name,g.duration,g.loop,g.keyframes);const A=P.anim(id);
 assert.ok(A.keyframes.length>=3,k);assert.ok(A.keyframes.every((kf,i)=>kf.time>=0&&kf.time<=A.duration&&(i==0||kf.time>A.keyframes[i-1].time)),k+' temps');
 for(let t=0;t<=A.duration;t+=.05)for(const e of Object.values(P.sample(id,t)))for(const v of Object.values(e))assert.ok(v.every(Number.isFinite),k+' fini');
 if(A.loop){const a=P.sample(id,0),b=P.sample(id,A.duration-1e-7);for(const bid in a)for(const f in a[bid])a[bid][f].forEach((x,i)=>assert.ok(Math.abs(x-b[bid][f][i])<1e-3,k+' boucle continue'))}
 res[k]=[A.duration,A.loop,A.keyframes.length]}
// limites : les pattes du quadrupède sont limitées à x ±45, y 0, z 0
for(const k of['walk','run','swim']){const A=P.d.animations.find(a=>a.name===PRESET_NAMES[k]);for(const kf of A.keyframes)for(const l of legs){const r=(kf.pose[l.id]||{}).rotation;if(r){assert.ok(Math.abs(r[0])<=45+1e-9&&r[1]===0&&r[2]===0,k+' limites')}}}
// marche : pattes en diagonale synchronisées (phase = XOR des signes de x et z)
const W=worlds(P.d,{},{});const legPos=Object.fromEntries(legs.map(l=>[l.id,tp(W[l.partId],P.part(l.partId).pivot||[0,0,0])]));
const walk=P.d.animations.find(a=>a.name=='Marche'),s=P.sample(walk.id,.125);
const rot=Object.fromEntries(legs.map(l=>[l.id,s[l.id].rotation[0]]));
const grp=l=>(legPos[l.id][0]>0)===(legPos[l.id][2]>0);
for(const a of legs)for(const b of legs)if(a!==b){const same=grp(a)===grp(b);assert.ok(same?Math.abs(rot[a.id]-rot[b.id])<1e-9:Math.abs(rot[a.id]+rot[b.id])<1e-9,'diagonale')}
// aucune partie reconnue
const Q=Project.create('X');const z=Q.add('Truc','cube');Q.autoRig();Q.removeBone(Q.boneOf(Q.root).id);assert.throws(()=>genPreset(Q,'walk'),/Aucun os reconnu/);assert.throws(()=>genPreset(P,'nope'));
console.log(JSON.stringify({res,project:P.d}));
"""

@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestEditorAnimation(unittest.TestCase):
    def test_js_sampling_matches_python(self):
        sys.path.insert(0, str(ROOT / "core"))
        from creature_model import CreatureProject
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "a.js"; js.write_text(CORE + ANIM_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            out = json.loads(r.stdout)
            f = Path(d) / "anim.creature.json"; f.write_text(json.dumps(out["project"]), encoding="utf-8")
            v = subprocess.run([sys.executable, str(ROOT / "tools" / "validate_creature.py"), str(f)], capture_output=True, text=True)
            self.assertEqual(v.returncode, 0, v.stdout)
        p = CreatureProject.new("Anim"); head = p.add_part("Tête", "sphere"); p.auto_rig(); b = p.bone_of_part(head)["id"]
        for loop in (False, True):
            a = p.add_animation(f"A{str(loop).lower()}", 2, loop)
            p.set_keyframe(a, 1.5, {b: {"rotation": [40, 20, -10], "position": [0, 1, 0]}}); p.set_keyframe(a, 0.5, {b: {"rotation": [0, 0, 0]}})
            for t, js_sample in zip([-1, 0, 0.25, 0.5, 1, 1.5, 1.9999, 2, 4.25, 9], out["samples"][str(loop).lower()]):
                py = p.sample(a, t)
                self.assertEqual(set(py), set(js_sample), (loop, t))
                for bone in py:
                    self.assertEqual(set(py[bone]), set(js_sample[bone]), (loop, t))
                    for field in py[bone]:
                        for x, y in zip(py[bone][field], js_sample[bone][field]):
                            self.assertAlmostEqual(x, y, places=9, msg=(loop, t, field))

    def test_presets_on_rigged_quadruped(self):
        demo = ROOT / "examples" / "demo_rigged_quadruped.creature.json"
        self.assertTrue(demo.exists())
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "p.js"; js.write_text(CORE + RENDER + PRESET_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js), str(demo)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1500:])
            out = json.loads(r.stdout)
            f = Path(d) / "presets.creature.json"; f.write_text(json.dumps(out["project"]), encoding="utf-8")
            v = subprocess.run([sys.executable, str(ROOT / "tools" / "validate_creature.py"), str(f)], capture_output=True, text=True)
            self.assertEqual(v.returncode, 0, v.stdout)
            self.assertEqual(len(out["res"]), 9)
            self.assertEqual(out["res"]["walk"][:2], [1, True])
            self.assertEqual(out["res"]["death"][:2], [1.2, False])


BEHAVIOR_JS = r"""
const assert=require('assert');
const p=Project.create('Zombie');p.setStats({detectionRange:10,damage:4});
const flee=p.addBehavior('Fuir',[{type:'healthBelow',percent:25}],[{type:'flee',speed:1.5}]);
const hit=p.addBehavior('Attaquer',[{type:'distance',op:'<',value:2}],[{type:'attack',cooldown:1}]);
const chase=p.addBehavior('Poursuivre',[{type:'playerDetected'}],[{type:'chase',speed:1}]);
const wander=p.addBehavior('Se promener',[],[{type:'wander',speed:.5}]);
assert.strictEqual(p.d.behaviors.enabled,true);
// blocs invalides refusés, projet inchangé
const snap=JSON.stringify(p.d);
for(const c of[{type:'magic'},{type:'distance',op:'~',value:1},{type:'distance',op:'<',value:-1},{type:'time',is:'dusk'},{type:'healthBelow',percent:120},{type:'random',chance:2},{type:'attacked',not:'oui'},'texte'])assert.throws(()=>p.addCondition(flee,c));
for(const a of[{type:'fly'},{type:'chase',speed:9},{type:'attack',cooldown:-1},{type:'attack',range:0},{type:'idle',animationId:'nope'},{type:'chase',animationId:null},{type:'wander'}])assert.throws(()=>p.addAction(flee,a));
assert.throws(()=>p.setStats({health:0}));assert.throws(()=>p.setStats({mana:1}));assert.throws(()=>p.setStats({}));assert.throws(()=>p.addBehavior(' '));
assert.strictEqual(JSON.stringify(p.d),snap);
// sélection sur une grille de contextes (comparée à Python)
const grid=[];
for(const d of[null,0.5,1.5,2,5,10,10.5,20])for(const time of['day','night'])for(const hp of[100,24,25])for(const att of[false,true])for(const r of[0,.3,.99])grid.push({playerDistance:d,time,healthPercent:hp,attacked:att,inWater:false,random:r});
const picks=grid.map(c=>{const g=selectBehavior(p.d.behaviors,c);return g?g.id:null});
// toutes les conditions, y compris NON
const st=Object.assign({},DEFAULT_STATS,{detectionRange:10});const conds=[[{type:'random',chance:.25},{random:.2},true],[{type:'random',chance:0},{random:0},false],[{type:'distance',op:'<',value:5,not:true},{playerDistance:null},true],[{type:'attacked',not:true},{attacked:true},false],[{type:'playerDetected'},{playerDistance:10},true],[{type:'playerDetected'},{playerDistance:10.1},false],[{type:'distance',op:'<=',value:2},{playerDistance:2},true],[{type:'healthBelow',percent:30},{healthPercent:30},false]];
for(const[c,ctx,e]of conds)assert.strictEqual(evalCond(c,Object.assign({playerDistance:null,time:'day',healthPercent:100,attacked:false,inWater:false,random:.5},ctx),st),e,JSON.stringify(c));
assert.throws(()=>evalCond({type:'magic'},{},st));
p.moveBehavior(hit,3);assert.strictEqual(p.d.behaviors.graphs[3].id,hit);assert.throws(()=>p.moveBehavior(hit,9));
// animation supprimée : références nettoyées
p.addAnimation('Marche',1);const an=p.d.animations[0].id;p.addAction(wander,{type:'jump',animationId:an});p.removeAnimation(an);assert.ok(!('animationId' in p.d.behaviors.graphs.find(g=>g.id==wander).actions[1]));
// modèles fournis valides
for(const[k,[cs,as]]of Object.entries(BEH_TEMPLATES))p.addBehavior(k,cs,as);
for(const g of p.d.behaviors.graphs.slice(0,0))void g;
for(const g of[flee,hit,chase,wander])p.removeBehavior(g);
assert.strictEqual(p.d.behaviors.graphs.length,Object.keys(BEH_TEMPLATES).length);
console.log(JSON.stringify({project:p.d,grid,picks}));
"""

SIM_JS = r"""
const assert=require('assert');
const mkp=()=>{const p=Project.create('Sim');p.setStats({detectionRange:10,damage:4,speed:.5,health:20});
 p.addBehavior('Fuir',[{type:'healthBelow',percent:25}],[{type:'flee',speed:1.5}]);p.addBehavior('Attaquer',[{type:'distance',op:'<',value:2}],[{type:'attack',cooldown:1}]);
 p.addBehavior('Poursuivre',[{type:'playerDetected'}],[{type:'chase',speed:1}]);p.addBehavior('Se promener',[],[{type:'wander',speed:.5}]);return p};
const p=mkp(),B=p.d.behaviors,name=S=>B.graphs.find(g=>g.id==S.active).name,rnd=(()=>{let i=0;return()=>[.5,.9,.1,.7,.3][i++%5]})();
let S=simNew(B,rnd);S.px=8;S.pz=0;                                       // joueur à 8 blocs : détecté
simStep(S,.1,B,rnd);assert.strictEqual(name(S),'Poursuivre');
let d0=Math.hypot(S.px-S.x,S.pz-S.z);for(let i=0;i<10;i++)simStep(S,.1,B,rnd);assert.ok(Math.hypot(S.px-S.x,S.pz-S.z)<d0-1,'poursuite');
for(let i=0;i<60;i++)simStep(S,.1,B,rnd);assert.ok(Math.hypot(S.px-S.x,S.pz-S.z)<=1.8+1e-6&&name(S)=='Attaquer','au contact');
const hp0=S.playerHp,h0=S.hits;for(let i=0;i<25;i++)simStep(S,.1,B,rnd);const dh=S.hits-h0;
assert.ok(dh>=2&&dh<=3,'cooldown 1 s respecté : '+dh+' coups en 2,5 s');assert.strictEqual(hp0-S.playerHp,4*dh,'dégâts = caractéristique damage');
S.hp=4;simStep(S,.1,B,rnd);assert.strictEqual(name(S),'Fuir');                 // 20 % < 25 %
const dd=Math.hypot(S.px-S.x,S.pz-S.z);for(let i=0;i<10;i++)simStep(S,.1,B,rnd);assert.ok(Math.hypot(S.px-S.x,S.pz-S.z)>dd+1,'fuite');
S.hp=0;simStep(S,.1,B,rnd);assert.strictEqual(S.active,null);const x0=S.x;for(let i=0;i<5;i++)simStep(S,.1,B,rnd);assert.strictEqual(S.x,x0,'mort : immobile');
S=simNew(B,rnd);S.playerOn=false;for(let i=0;i<50;i++)simStep(S,.1,B,rnd);assert.strictEqual(name(S),'Se promener');assert.ok(Math.abs(S.x)+Math.abs(S.z)>.5&&Math.abs(S.x)<=12&&Math.abs(S.z)<=12,'promenade bornée');
// nuit : règle prioritaire ; animation liée
const q=Project.create('N');const a=q.addAnimation('Repos',2);q.addBehavior('Nuit',[{type:'time',is:'night'}],[{type:'idle',animationId:a}]);q.addBehavior('Jour',[],[{type:'wander'}]);
const T=simNew(q.d.behaviors,rnd);T.playerOn=false;simStep(T,.1,q.d.behaviors,rnd);assert.strictEqual(T.anim,null);T.time='night';simStep(T,.1,q.d.behaviors,rnd);assert.strictEqual(T.anim,a);const xx=T.x;simStep(T,1,q.d.behaviors,rnd);assert.strictEqual(T.x,xx,'idle : immobile');
// frapper : attacked
const r=Project.create('R');r.addBehavior('Réagir',[{type:'attacked'}],[{type:'flee',speed:2}]);r.addBehavior('Rien',[],[{type:'idle'}]);
const U=simNew(r.d.behaviors,rnd);simStep(U,.1,r.d.behaviors,rnd);assert.strictEqual(U.active,r.d.behaviors.graphs[1].id);U.attackT=1.5;simStep(U,.1,r.d.behaviors,rnd);assert.strictEqual(U.active,r.d.behaviors.graphs[0].id);
for(let i=0;i<20;i++)simStep(U,.1,r.d.behaviors,rnd);assert.strictEqual(U.active,r.d.behaviors.graphs[1].id,'attacked expire après 1,5 s');
console.log('sim ok');
"""

@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestEditorBehavior(unittest.TestCase):
    def test_js_behavior_matches_python(self):
        sys.path.insert(0, str(ROOT / "core"))
        from creature_model import CreatureProject
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "b.js"; js.write_text(CORE + BEHAVIOR_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1500:])
            out = json.loads(r.stdout)
            f = Path(d) / "beh.creature.json"; f.write_text(json.dumps(out["project"]), encoding="utf-8")
            v = subprocess.run([sys.executable, str(ROOT / "tools" / "validate_creature.py"), str(f)], capture_output=True, text=True)
            self.assertEqual(v.returncode, 0, v.stdout)
        p = CreatureProject.new("Zombie"); p.set_stats(detectionRange=10, damage=4)
        p.add_behavior("Fuir", [{"type": "healthBelow", "percent": 25}], [{"type": "flee", "speed": 1.5}])
        p.add_behavior("Attaquer", [{"type": "distance", "op": "<", "value": 2}], [{"type": "attack", "cooldown": 1}])
        p.add_behavior("Poursuivre", [{"type": "playerDetected"}], [{"type": "chase", "speed": 1}])
        p.add_behavior("Se promener", [], [{"type": "wander", "speed": 0.5}])
        picks = []
        for c in out["grid"]:
            g = p.select_behavior(c)
            picks.append(g["id"] if g else None)
        self.assertEqual(picks, out["picks"])
        self.assertGreater(len(set(picks)), 3)

    def test_simulation(self):
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "s.js"; js.write_text(CORE + SIM_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1500:])
            self.assertIn("sim ok", r.stdout)


@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestEditorTouch(unittest.TestCase):
    def test_touch_drag_math_and_history(self):
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "t.js"; js.write_text(CORE + RENDER + TOUCH_JS, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertIn("touch ok", r.stdout)

if __name__ == "__main__":
    unittest.main()
