"""Test de fumée de l'interface de l'éditeur avec un FAUX DOM (Node) : le dessin produit des polygones et les
gestes Vue / Déplacer / Tourner se comportent comme prévu. Ne remplace pas un test dans un vrai navigateur.
Ignoré si Node est absent."""
import shutil, subprocess, tempfile, unittest
from pathlib import Path

HTML = (Path(__file__).resolve().parent.parent / "editor" / "creature_editor.html").read_text(encoding="utf-8")
APP = HTML.split("<script>")[1].split("</script>")[0]

STUB = r"""
const els={};
const mk=()=>({style:{},children:[],value:'',textContent:'',className:'',disabled:false,
 click(){},add(x){this.children.push(x)},append(...a){this.children.push(...a)},appendChild(x){this.children.push(x)},
 set innerHTML(v){this.children=[]},get innerHTML(){return''},setPointerCapture(){},select(){},
 getBoundingClientRect(){return{left:0,top:0,width:390,height:170}},getContext(){return ctxStub()},clientWidth:390,clientHeight:400});
global.Option=function(t,v){return{text:t,value:v}};global.requestAnimationFrame=()=>0;global.devicePixelRatio=1;global.addEventListener=()=>{};
global.URL={createObjectURL:()=>''};global.Blob=function(){};global.navigator={};global.window={};global.atob=s=>Buffer.from(s,'base64').toString('binary');
const ctxStub=()=>new Proxy({},{get:(t,k)=>k=='createImageData'?((w,h)=>({data:new Uint8ClampedArray(w*h*4)})):k in t?t[k]:(()=>{}),set:(t,k,v)=>{t[k]=v;return true}});
global.document={getElementById:id=>els[id]||(els[id]=mk()),createElement:()=>{const o=mk();o.getContext=ctxStub;return o}};
els.cv=mk();els.cv.getContext=ctxStub;
"""

TEST = r"""
const assert=require('assert');
assert.ok(polys.length>20,'polys='+polys.length);
const tete=P.d.parts.find(p=>p.name==='Tête'),before=clone(tete.transform.position);
const ev=(x,y,id=1)=>({pointerId:id,clientX:x,clientY:y});
const pt=()=>polys.find(q=>q.id===tete.id).pts[0];
let cam0=JSON.stringify(cam),[x,y]=pt();
els.cv.onpointerdown(ev(x,y));els.cv.onpointermove(ev(x+40,y));els.cv.onpointerup(ev(x+40,y));
assert.notStrictEqual(JSON.stringify(cam),cam0,'mode Vue: la caméra doit tourner');
els.md.onclick();assert.ok(els.md.textContent.includes('Déplacer'));
const camB=JSON.stringify(cam),n0=P.hist.length;[x,y]=pt();
els.cv.onpointerdown(ev(x,y));els.cv.onpointermove(ev(x+30,y));els.cv.onpointermove(ev(x+60,y+10));els.cv.onpointerup(ev(x+60,y+10));
const t2=P.part(tete.id).transform.position;
assert.ok(Math.abs(t2[0]-before[0])+Math.abs(t2[2]-before[2])>.1,'la tête aurait dû bouger');
assert.strictEqual(JSON.stringify(cam),camB,'la caméra ne doit pas bouger en mode Déplacer');
assert.strictEqual(P.hist.length,n0+1,'un geste = une entrée d\'historique');
els.md.onclick();assert.ok(els.md.textContent.includes('Tourner'));
const r0=clone(P.part(tete.id).transform.rotation);[x,y]=pt();
els.cv.onpointerdown(ev(x,y));els.cv.onpointermove(ev(x+50,y));els.cv.onpointerup(ev(x+50,y));
assert.ok(P.part(tete.id).transform.rotation[1]-r0[1]>10,'rotation Y attendue');
// mode Pose : sans os, rien ne bouge ; avec os, la pose change mais pas le modèle ni l'historique
els.md.onclick();assert.ok(els.md.textContent.includes('Pose'));
const snap=JSON.stringify(P.d.parts);[x,y]=pt();
els.cv.onpointerdown(ev(x,y));els.cv.onpointermove(ev(x+30,y+30));els.cv.onpointerup(ev(x+30,y+30));
assert.strictEqual(Object.keys(pose).length,0,'sans os : pas de pose');
els.ar.onclick();assert.ok(P.d.skeleton.enabled&&P.d.skeleton.bones.length===P.d.parts.length,'tout rigger');
const nh=P.hist.length;P.setLimits(P.boneOf(tete.id).id,{x:[-10,10]});const nh2=P.hist.length;[x,y]=pt();
els.cv.onpointerdown(ev(x,y));els.cv.onpointermove(ev(x+30,y+60));els.cv.onpointerup(ev(x+30,y+60));
assert.ok(pose[tete.id],'la pose doit exister');assert.strictEqual(pose[tete.id][0],10,'limite x respectée (clamp à 10)');assert.ok(pose[tete.id][1]>5,'rotation Y libre');
assert.strictEqual(JSON.stringify(P.d.parts),snap,'le modèle ne change pas');
assert.strictEqual(P.hist.length,nh2,'la pose ne crée pas d\'historique');
const w0=worlds(P.d,{}),w1=worlds(P.d,pose);assert.notDeepStrictEqual(w0[tete.id],w1[tete.id],'la pose déforme le rendu');
els.rp.onclick();assert.strictEqual(Object.keys(pose).length,0,'reset pose');
// deux doigts qui tournent (sens horaire à l'écran) = axe Z de la pose, dans les limites ; sens horaire => z diminue
P.setLimits(P.boneOf(tete.id).id,{});[x,y]=pt();pose={};
els.cv.onpointerdown(ev(x,y,1));els.cv.onpointerdown(ev(x+100,y,2));
els.cv.onpointermove(ev(x+100,y,2));                                     // amorce l'angle de référence
els.cv.onpointermove(ev(x+100*Math.cos(0.3),y+100*Math.sin(0.3),2));      // +0,3 rad (horaire à l'écran)
assert.ok(pose[tete.id]&&pose[tete.id][2]<-15&&pose[tete.id][2]>-19,'z attendu ~ -17 : '+(pose[tete.id]||[]).join());
els.cv.onpointerup(ev(x,y,2));els.cv.onpointerup(ev(x,y,1));
P.setLimits(P.boneOf(tete.id).id,{z:[-5,5]});pose={};[x,y]=pt();
els.cv.onpointerdown(ev(x,y,1));els.cv.onpointerdown(ev(x+100,y,2));els.cv.onpointermove(ev(x+100,y,2));els.cv.onpointermove(ev(x+100*Math.cos(0.5),y+100*Math.sin(0.5),2));
assert.strictEqual(pose[tete.id][2],-5,'limite z respectée');els.cv.onpointerup(ev(x,y,2));els.cv.onpointerup(ev(x,y,1));
// animation : créer, poser, images clés, interpolation, lecture, bibliothèque de poses, presets
els.ar.onclick();assert.ok(P.boneOf(tete.id));const nAnim=P.d.animations.length;
els.an.onchange({target:{value:'__new'}});assert.ok(animId&&P.d.animations.length===nAnim+1,'nouvelle animation');
els.ad.onchange({target:{value:'2'}});assert.strictEqual(P.anim(animId).duration,2);
els.tl.oninput({target:{value:'0.5'}});pose[tete.id]=[30,0,0];els.kk.onclick();
els.tl.oninput({target:{value:'1.5'}});pose={};els.kk.onclick();                           // pose de repos à 1,5 s (le défilement avait gardé la pose précédente)
assert.deepStrictEqual(P.anim(animId).keyframes.map(k=>k.time),[0.5,1.5]);assert.deepStrictEqual(P.anim(animId).keyframes[0].pose[P.boneOf(tete.id).id].rotation,[30,0,0]);
els.tl.oninput({target:{value:'1.0'}});assert.ok(Math.abs(pose[tete.id][0]-15)<1e-9,'interpolation à mi-chemin : '+pose[tete.id]);
els.lo.onchange({target:{checked:true}});assert.strictEqual(P.anim(animId).loop,true);
els.pl.onclick();assert.strictEqual(playing,true);advance(1.2);assert.ok(Math.abs(tNow-0.2)<1e-9&&playing,'boucle : t revient dans [0,durée[ ('+tNow+')');
els.pl.onclick();assert.strictEqual(playing,false);
els.lo.onchange({target:{checked:false}});els.tl.oninput({target:{value:'1.9'}});els.pl.onclick();advance(0.5);assert.ok(tNow===2&&playing===false,'sans boucle : arrêt à la fin');
els.tl.oninput({target:{value:'0.5'}});els.kd.onclick();assert.strictEqual(P.anim(animId).keyframes.length,1,'image clé supprimée');
pose[tete.id]=[10,0,0];els.ps.onclick();const pid=(P.d.skeleton.poses||[])[0].id;els.rp.onclick();assert.strictEqual(Object.keys(pose).length,0);
els.pq.onchange({target:{value:pid}});assert.strictEqual(pose[tete.id][0],10,'pose enregistrée réappliquée');els.rp.onclick();
document.getElementById('pr').value='';els.pg.onclick();const nA=P.d.animations.length;           // aucun type choisi : message, rien créé
document.getElementById('pr').value='walk';els.pg.onclick();assert.strictEqual(P.d.animations.length,nA+1,'preset généré');
assert.strictEqual(P.anim(animId).name,'Marche');assert.strictEqual(P.anim(animId).keyframes.length,8);
advance(0.3);assert.ok(Object.keys(pose).length>0,'la lecture applique la pose');
els.un.onclick();assert.strictEqual(P.d.animations.length,nA,'annuler retire l\'animation');assert.ok(!animId||P.d.animations.some(a=>a.id===animId));
// comportements : caractéristiques, règles à partir de modèles, blocs SI/ALORS, priorité, simulateur
const walkN=(n,f)=>{f(n);(n.children||[]).forEach(c=>{if(c&&typeof c=='object')walkN(c,f)})};
const findN=pred=>{let r=null;walkN(els.bh,n=>{if(!r&&pred(n))r=n});return r};
const btn=t=>findN(n=>n.textContent===t&&n.onclick);
const hp=findN(n=>n.type==='range'&&n.max===1000);hp.value='40';hp.onchange();assert.strictEqual(P.stats().health,40,'curseur de vie');
const tpl=()=>findN(n=>n.children&&n.children[0]&&n.children[0].text==='Modèle…');
tpl().value='Poursuivre le joueur';btn('＋ Règle').onclick();assert.strictEqual(P.d.behaviors.graphs.length,1);assert.ok(ruleId&&P.d.behaviors.enabled);
tpl().value='Se promener';btn('＋ Règle').onclick();assert.strictEqual(P.d.behaviors.graphs.length,2);
btn('▲').onclick();assert.strictEqual(P.d.behaviors.graphs[0].name,'Se promener','priorité : monter la règle');
const addSel=t=>findN(n=>n.children&&n.children[0]&&n.children[0].text===t);
addSel('＋ SI…').value='time';addSel('＋ SI…').onchange();assert.deepStrictEqual(P.d.behaviors.graphs[0].conditions,[{type:'time',is:'night'}]);
addSel('＋ ALORS…').value='flee';addSel('＋ ALORS…').onchange();assert.ok(/movement/.test(els.msg.textContent),'2e action de déplacement refusée : '+els.msg.textContent);
assert.strictEqual(P.d.behaviors.graphs[0].actions.length,1);
btn('✕').onclick();assert.strictEqual(P.d.behaviors.graphs[0].conditions.length,0,'bloc SI supprimé');
P.d.behaviors.graphs.length;els.sr.onclick();assert.strictEqual(simOn,true);simStep(S,.5,P.d.behaviors);simDraw();assert.ok(/règle/.test(els.so.textContent),els.so.textContent);
els.sd.onclick();assert.ok(els.sd.textContent.includes('Nuit')&&S.time==='night');const hpA=S.hp;els.sh.onclick();assert.ok(S.hp<hpA&&S.attackT>0,'frapper');
els.sr.onclick();assert.strictEqual(simOn,false);
els.un.onclick();els.un.onclick();els.un.onclick();els.un.onclick();els.un.onclick();els.un.onclick();els.un.onclick();
// symétrie : le bouton Sym fait X -> Y -> Z -> off ; Miroir et ajout créent les jumelles ; glisser suit la jumelle
const nparts=P.d.parts.length;
els.sy.onclick();assert.ok(els.sy.textContent.includes('X'));
const corne=P.d.parts.find(q=>q.name==='Corne');
els.md.onclick();assert.ok(els.md.textContent.includes('Peindre'));          // Pose -> Peindre
const ct=()=>{const q=polys.find(q=>q.id===tete.id);return[q.pts.reduce((s,a)=>s+a[0],0)/q.pts.length,q.pts.reduce((s,a)=>s+a[1],0)/q.pts.length]};
assert.strictEqual(P.d.textures.length,0);assert.strictEqual(P.part(tete.id).materialId,null);
let hPaint=P.hist.length;[x,y]=ct();document.getElementById('tc').value='#ff0000';
els.cv.onpointerdown(ev(x,y));els.cv.onpointermove(ev(x+6,y+3));els.cv.onpointerup(ev(x+6,y+3));
const mid=P.part(tete.id).materialId,tex=mid&&P.tex(P.mat(mid).textureId);
assert.ok(tex,'peindre crée matière et texture');assert.strictEqual(tex.width,16);assert.deepStrictEqual(tex.palette,[null,'#ff0000']);
assert.ok(tex.pixels.some(i=>i===1),'des texels sont peints');assert.strictEqual(P.hist.length,hPaint+1,'un trait = une entrée d\'historique');
els.un.onclick();assert.strictEqual(P.d.textures.length,0,'annuler retire texture');assert.strictEqual(P.part(tete.id).materialId,null,'annuler retire matière');
els.tf.onclick();[x,y]=ct();document.getElementById('tc').value='#00ff00';hPaint=P.hist.length;      // remplissage : toute la texture neuve est connexe
els.cv.onpointerdown(ev(x,y));els.cv.onpointermove(ev(x+30,y));els.cv.onpointerup(ev(x+30,y));
const t2f=P.d.textures[0];assert.ok(t2f&&new Set(t2f.pixels).size===1&&t2f.pixels[0]>0,'remplir');assert.strictEqual(P.hist.length,hPaint+1);
els.te.onclick();[x,y]=ct();els.cv.onpointerdown(ev(x,y));els.cv.onpointerup(ev(x,y));
assert.ok(P.d.textures[0].pixels.some(i=>i===0),'la gomme efface des texels');
els.tb.onclick();els.un.onclick();els.un.onclick();assert.strictEqual(P.d.textures.length,0);
// matière : couleur sur une partie sans matière => matière créée et assignée ; jumelles en symétrie
els.mc.onchange({target:{value:'#336699'}});assert.strictEqual(P.mat(P.part(tete.id).materialId).color,'#336699');
els.mo.onchange({target:{value:'0.5'}});assert.strictEqual(P.mat(P.part(tete.id).materialId).opacity,0.5);
els.un.onclick();els.un.onclick();assert.strictEqual(P.part(tete.id).materialId,null);
els.md.onclick();assert.ok(els.md.textContent.includes('Vue'));               // Peindre -> Vue
const nAvant=P.d.parts.length;sel=corne.id;els.mi.onclick();
assert.strictEqual(P.d.parts.length,nAvant+1,'Miroir crée une partie');
const tw=P.twin(corne.id);assert.ok(tw&&tw.mirror.partId===corne.id);
assert.ok(Math.abs(tw.transform.position[0]+corne.transform.position[0])<1e-9,'position en miroir');
els.md.onclick();                                                         // Vue -> Déplacer
const cp=polys.find(q=>q.id===corne.id);if(cp){const[cx,cy]=cp.pts[0];els.cv.onpointerdown(ev(cx,cy));els.cv.onpointermove(ev(cx+25,cy));els.cv.onpointerup(ev(cx+25,cy));
 const nx=P.part(corne.id).transform.position[0],tx=P.part(tw.id).transform.position[0];assert.ok(Math.abs(nx+tx)<1e-9,'la jumelle suit en miroir : '+nx+' / '+tx);}
els.sy.onclick();els.sy.onclick();els.sy.onclick();assert.ok(els.sy.textContent.includes('—'),'retour à Sym off');
els.md.onclick();els.md.onclick();els.md.onclick();els.md.onclick();assert.ok(els.md.textContent.includes('Vue'));
// bouton 🎖 Soldat : charge le personnage intégré, animations et comportements utilisables
els.sl.onclick();assert.strictEqual(P.d.parts.length,38,'soldat chargé');assert.strictEqual(P.d.skeleton.bones.length,17);assert.strictEqual(P.d.behaviors.graphs.length,5);
assert.ok(P.d.animations.some(a=>a.name==='Marche')&&P.d.animations.some(a=>a.name==='Attaque'));
els.an.onchange({target:{value:P.d.animations.find(a=>a.name==='Marche').id}});advance(0.3);assert.ok(Object.keys(pose).length>8,'la marche applique la pose aux os');
const jh=P.d.parts.find(q=>q.name==='Jambe haute gauche'),jd=P.d.parts.find(q=>q.name==='Jambe haute droite');
assert.ok(Math.abs(pose[jh.id][0]+pose[jd.id][0])<1e-6&&Math.abs(pose[jh.id][0])>1,'jambes en opposition de phase');
els.sr.onclick();S.px=15;S.pz=0;simStep(S,.1,P.d.behaviors);assert.strictEqual(P.d.behaviors.graphs.find(g=>g.id===S.active).name,'Poursuivre le joueur');
linkAnim();assert.strictEqual(P.anim(animId).name,'Course','la poursuite joue l\'animation Course');els.sr.onclick();
console.log('ui ok');
"""

@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestEditorUiSmoke(unittest.TestCase):
    def test_gestures(self):
        tail = "/* ==ENDHOSTAPI== */\n}"
        assert tail in APP
        script = STUB + APP.replace(tail, "/* ==ENDHOSTAPI== */\n" + TEST + "\n}")
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "ui.js"; js.write_text(script, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1500:])
            self.assertIn("ui ok", r.stdout)

if __name__ == "__main__":
    unittest.main()
