"""Tests de l'Étape 5 : matières, textures, peinture, références."""
import copy, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import CreatureError, CreatureProject  # noqa: E402

EXAMPLE = ROOT / "examples" / "test_creature.creature.json"


def example():
    return CreatureProject.load(EXAMPLE)


class TestMaterials(unittest.TestCase):
    def test_old_files_still_valid(self):
        d = copy.deepcopy(example().data)
        d.pop("textures", None)
        self.assertIsNone(validate_creature.check(d)[0])

    def test_add_update_assign(self):
        p = example()
        m = p.add_material("Peau", "#33AA55", opacity=0.9, emissive=0.2)
        self.assertEqual(p.get_material(m)["color"], "#33aa55")
        p.update_material(m, color="#112233", roughness=0.4, name="Peau verte")
        self.assertEqual((p.get_material(m)["color"], p.get_material(m)["roughness"], p.get_material(m)["name"]), ("#112233", 0.4, "Peau verte"))
        self.assertEqual(p.assign_material("part_head", m), ["part_head"])
        self.assertEqual(p.get_part("part_head")["materialId"], m)

    def test_assign_children_and_symmetric_twin(self):
        p = CreatureProject.new("T")
        arm = p.add_part("Bras gauche", "cube", position=[1, 0, 0], symmetric_axis="x")
        hand = p.add_part("Main", "cube", parent_id=arm)
        m = p.add_material("Fourrure")
        got = p.assign_material(arm, m, with_children=True, symmetric=True)
        self.assertEqual(set(got), {arm, hand, p.twin(arm)["id"]})
        self.assertTrue(all(p.get_part(i)["materialId"] == m for i in got))
        p.assign_material(arm, None)
        self.assertIsNone(p.get_part(arm)["materialId"])

    def test_invalid_values_refused_and_unchanged(self):
        p = example()
        m = p.add_material("X")
        before = copy.deepcopy(p.data)
        for kwargs in ({"color": "red"}, {"color": "#12"}, {"opacity": 1.5}, {"emissive": -0.1}, {"roughness": "a"}, {"textureId": "nope"}, {"size": 3}):
            with self.assertRaises(CreatureError):
                p.update_material(m, **kwargs)
        with self.assertRaises(CreatureError):
            p.assign_material("part_head", "nope")
        with self.assertRaises(CreatureError):
            p.add_material("Y", color="zzz")
        self.assertEqual(p.data, before)

    def test_remove_material_clears_references(self):
        p = example()
        m = p.add_material("X")
        p.assign_material("part_head", m)
        p.remove_material(m)
        self.assertIsNone(p.get_part("part_head")["materialId"])
        self.assertEqual(p.data["materials"], [])

    def test_shared_material_survives_duplicate_and_mirror(self):
        p = CreatureProject.new("T")
        a = p.add_part("Corne gauche", "cone", position=[0.4, 1, 0])
        m = p.add_material("Os")
        p.assign_material(a, m)
        self.assertEqual(p.get_part(p.duplicate_part(a))["materialId"], m)
        self.assertEqual(p.get_part(p.mirror_part(a))["materialId"], m)
        self.assertIsNone(validate_creature.check(p.data)[0])


class TestTextures(unittest.TestCase):
    def test_create_paint_erase(self):
        p = example()
        t = p.add_texture("Yeux", 4, 4)
        self.assertEqual(p.paint(t, [(0, 0), (1, 0), (9, 9), (-1, 0)], "#FF0000"), 2)   # hors limites ignorés
        tex = p.get_texture(t)
        self.assertEqual(tex["palette"], [None, "#ff0000"])
        self.assertEqual(tex["pixels"][:3], [1, 1, 0])
        self.assertEqual(p.paint(t, [(0, 0)], None), 1)
        self.assertEqual(tex["pixels"][0], 0)
        self.assertEqual(p.paint(t, [(1, 0)], "#ff0000"), 0)                           # déjà de cette couleur

    def test_fill_stops_at_borders(self):
        p = example()
        t = p.add_texture("Fond", 4, 4)
        p.paint(t, [(2, y) for y in range(4)], "#000000")                              # mur vertical
        self.assertEqual(p.fill(t, 0, 0, "#00ff00"), 8)                                # moitié gauche
        self.assertEqual(p.get_texture(t)["pixels"][3], 0)                             # moitié droite intacte
        self.assertEqual(p.fill(t, 0, 0, "#00ff00"), 0)
        with self.assertRaises(CreatureError):
            p.fill(t, 9, 9, "#fff000")

    def test_palette_limit_and_clear(self):
        p = example()
        t = p.add_texture("Grand", 16, 16)
        for i in range(255):
            p.paint(t, [(i % 16, i // 16)], f"#{i:02x}00ff")
        with self.assertRaises(CreatureError):
            p.paint(t, [(15, 15)], "#abcdef")
        p.clear_texture(t)
        self.assertEqual(p.get_texture(t)["palette"], [None])

    def test_material_texture_link_and_removal(self):
        p = example()
        t = p.add_texture("Peau", 8, 8)
        m = p.add_material("Peau", texture_id=t)
        self.assertEqual(p.get_material(m)["textureId"], t)
        p.remove_texture(t)
        self.assertIsNone(p.get_material(m)["textureId"])
        with self.assertRaises(CreatureError):
            p.add_material("Z", texture_id="nope")

    def test_bad_sizes_refused(self):
        p = example()
        for w, h in ((0, 4), (300, 4), (4, -1), (2.5, 4)):
            with self.assertRaises(CreatureError):
                p.add_texture("Bad", w, h)
        self.assertEqual(p.data["textures"], [])


class TestValidatorAppearance(unittest.TestCase):
    def test_rejects_bad_data(self):
        p = example()
        t = p.add_texture("T", 2, 2)
        m = p.add_material("M", texture_id=t)
        p.assign_material("part_head", m)
        good = copy.deepcopy(p.data)
        self.assertIsNone(validate_creature.check(good)[0])
        cases = [
            (lambda d: d["parts"][1].__setitem__("materialId", "nope"), "missing material"),
            (lambda d: d["materials"][0].__setitem__("color", "#zzzzzz"), "invalid color"),
            (lambda d: d["materials"][0].__setitem__("opacity", 2), "invalid opacity"),
            (lambda d: d["materials"][0].__setitem__("textureId", "nope"), "missing texture"),
            (lambda d: d["materials"].append(copy.deepcopy(d["materials"][0])), "duplicate material id"),
            (lambda d: d["textures"][0]["pixels"].pop(), "invalid pixels"),
            (lambda d: d["textures"][0]["pixels"].__setitem__(0, 5), "invalid pixels"),
            (lambda d: d["textures"][0].__setitem__("palette", []), "invalid palette"),
            (lambda d: d["textures"][0].__setitem__("width", 0), "invalid size"),
            (lambda d: d.__setitem__("textures", {}), "textures must be an array"),
            (lambda d: d.__setitem__("materials", {}), "materials must be an array"),
        ]
        for mutate, expected in cases:
            d = copy.deepcopy(good)
            mutate(d)
            err = validate_creature.check(d)[0]
            self.assertTrue(err and expected in err, f"{expected!r} attendu, obtenu {err!r}")


if __name__ == "__main__":
    unittest.main()
