"""Teste l'API d'intégration de l'éditeur (window.CreatureStudio, messages, pont) avec le faux DOM de test_editor_ui_smoke."""
import shutil, subprocess, tempfile, unittest
from pathlib import Path
from test_editor_ui_smoke import STUB, APP

TEST = r"""
const assert=require('assert');
const api=window.CreatureStudio;
assert.strictEqual(api.apiVersion,1);
assert.ok(sent.some(m=>m.type==='creaturestudio:ready'),'ready envoyé');
// getProject / loadProject / validate
const d=api.getProject();assert.strictEqual(d.formatVersion,'1.0');
assert.deepStrictEqual(api.loadProject({bad:1}).ok,false);
assert.strictEqual(api.loadProject(api.listExamples()&&JSON.stringify(SOLDIER)).ok,true);
assert.strictEqual(P.d.parts.length,38);
assert.strictEqual(api.validate().ok,true);assert.strictEqual(api.validate({x:1}).ok,false);
assert.ok(api.listExamples().includes('chef')&&api.loadExample('chef').ok&&P.d.parts.length===66);
assert.strictEqual(api.loadExample('nope').ok,false);
// diagnostic
const dg=api.diagnose();assert.ok(Array.isArray(dg.items)&&typeof dg.summary.warning==='number');
// export
const ex=api.exportBedrock('test');assert.ok(ex.ok&&/\.mcaddon$|\.zip$/.test(ex.filename),ex.filename);
const zip=Buffer.from(ex.base64,'base64');assert.strictEqual(zip.length,ex.size);assert.strictEqual(zip.readUInt32LE(0),0x04034b50,'signature zip');
// onChange : une modification déclenche, un rafraîchissement sans changement non
let n=0;const off=api.onChange(()=>n++);refresh();assert.strictEqual(n,0);
run(()=>P.rename(P.root,'Renommé'));assert.strictEqual(n,1);
assert.ok(sent.some(m=>m.type==='creaturestudio:change'));off();run(()=>P.rename(P.root,'Renommé 2'));assert.strictEqual(n,1);
// messages
sent.length=0;
window.CreatureStudioBridge.receive({type:'creaturestudio:get',requestId:'r1'});
let r=sent.find(m=>m.requestId==='r1');assert.ok(r&&r.ok&&r.project.formatVersion==='1.0');
window.CreatureStudioBridge.receive(JSON.stringify({type:'creaturestudio:load',requestId:'r2',project:{bad:1}}));
assert.strictEqual(sent.find(m=>m.requestId==='r2').ok,false);
window.CreatureStudioBridge.receive({type:'creaturestudio:export',requestId:'r3',namespace:'x'});
assert.ok(sent.find(m=>m.requestId==='r3').base64.length>100);
window.CreatureStudioBridge.receive({type:'creaturestudio:zzz',requestId:'r4'});assert.strictEqual(sent.find(m=>m.requestId==='r4').ok,false);
window.CreatureStudioBridge.receive({type:'autre',requestId:'r5'});assert.ok(!sent.some(m=>m.requestId==='r5'),'messages étrangers ignorés');
// bouton ⬇ Bedrock
sent.length=0;els.bx.onclick();assert.ok(sent.some(m=>m.type==='creaturestudio:exported'&&m.filename));
console.log('host ok');
"""

@unittest.skipUnless(shutil.which("node"), "Node.js absent")
class TestHostApi(unittest.TestCase):
    def test_api(self):
        tail = "/* ==ENDHOSTAPI== */\n}"
        assert tail in APP
        pre = "const sent=[];global.window={CreatureStudioBridge:{onMessage:j=>sent.push(JSON.parse(j))}};global.atob=s=>Buffer.from(s,'base64').toString('binary');global.btoa=s=>Buffer.from(s,'binary').toString('base64');\n"
        # window doit exister avant l'exécution de l'application : STUB le redéfinit, on le remplace donc après
        script = STUB + pre + APP.replace(tail, tail[:-1] + TEST + "\n}")
        with tempfile.TemporaryDirectory() as d:
            js = Path(d) / "api.js"; js.write_text(script, encoding="utf-8")
            r = subprocess.run(["node", str(js)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1800:])
            self.assertIn("host ok", r.stdout)

if __name__ == "__main__":
    unittest.main()
