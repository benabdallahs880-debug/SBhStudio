"""Étape 9 — diagnostics : chaque code, parité Python/JS, personnages livrés sans erreur ni avertissement."""
import copy, json, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import CreatureProject  # noqa: E402
from diagnostics import CODES, diagnose, summary  # noqa: E402

HTML = (ROOT / "editor" / "creature_editor.html").read_text(encoding="utf-8")
CORE = HTML.split("// ==CORE==")[1].split("// ==ENDCORE==")[0]
EX = ROOT / "examples"


def load(name):
    return json.loads((EX / f"{name}.creature.json").read_text(encoding="utf-8"))


def codes(d):
    return {i["code"] for i in diagnose(d)}


def mutate(name, fn):
    d = load(name)
    fn(d)
    return d


def valid(d):
    assert validate_creature.check(d)[0] is None, validate_creature.check(d)[0]
    return d


def no_bones(d):
    d["skeleton"]["bones"], d["skeleton"]["poses"] = [], []
    for a in d["animations"]:
        a["keyframes"] = [{"time": 0, "pose": {}}]


def part(d, name):
    return next(p for p in d["parts"] if p["name"] == name)


def rule(d, name):
    return next(g for g in d["behaviors"]["graphs"] if g["name"] == name)


class TestCodes(unittest.TestCase):
    def test_delivered_characters_are_clean(self):
        for n in ("soldat_standard", "hibou_hippo1", "hibou_hippo2", "hibou_hippo3", "hibou_chef"):
            s = summary(diagnose(load(n)))
            self.assertEqual((s["error"], s["warning"]), (0, 0), n)

    def test_every_code_is_documented_and_reachable(self):
        triggered = set()
        cases = [
            valid(mutate("hibou_chef", lambda d: part(d, "Torse").update(materialId=None))),                                  # D001
            valid(mutate("hibou_chef", lambda d: part(d, "Torse")["parameters"].update(size=[0, 1, 1]))),                      # D002
            valid(mutate("hibou_chef", lambda d: part(d, "Torse").update(name="Cape"))),                                       # D003
            valid(mutate("hibou_chef", lambda d: d["animations"][0]["keyframes"][0]["pose"].update({d["skeleton"]["bones"][5]["id"]: {"rotation": [999, 0, 0]}}))),  # D004
            valid(mutate("hibou_chef", lambda d: d["animations"][0].update(keyframes=[]))),                                    # D005
            valid(mutate("hibou_chef", lambda d: part(d, "Bras gauche")["transform"].update(position=[9, 0, 0]))),             # D006
            valid(mutate("hibou_chef", lambda d: d["behaviors"]["graphs"].pop())),                                             # D010
            valid(mutate("hibou_chef", lambda d: d["behaviors"]["graphs"].insert(0, {"id": "beh_x", "name": "X", "conditions": [], "actions": [{"type": "idle"}]}))),   # D011
            valid(mutate("hibou_chef", lambda d: rule(d, "Bouclier du Chef")["actions"].pop())),                               # D012
            valid(mutate("hibou_chef", lambda d: rule(d, "Veiller la nuit").update(actions=[]))),                              # D013
            valid(mutate("hibou_chef", lambda d: [a.pop("animationId") for a in rule(d, "Poursuivre le joueur")["actions"] if "animationId" in a])),   # D014
            valid(mutate("hibou_chef", lambda d: d["behaviors"]["stats"].update(speed=0))),                                    # D015
            valid(mutate("hibou_chef", lambda d: [g.update(actions=[a for a in g["actions"] if a["type"] not in ("attack", "ability")]) for g in d["behaviors"]["graphs"]])),   # D016
            valid(mutate("hibou_chef", lambda d: d["behaviors"]["stats"].update(detectionRange=1))),                           # D017
            valid(mutate("hibou_chef", lambda d: d["sounds"][0].update(sound="Mob.Zombie Say"))),                              # D020
            valid(mutate("hibou_chef", lambda d: d["sounds"].append({"id": "sound_z", "name": "Z", "sound": "a.b"}))),         # D021
            valid(mutate("hibou_chef", lambda d: d["effects"].append({"id": "effect_z", "name": "Z", "kind": "fire"}))),       # D022
            valid(mutate("hibou_chef", lambda d: d["materials"].append({"id": "mat_z", "name": "Z", "color": "#ffffff"}))),    # D030
            valid(mutate("hibou_chef", lambda d: d["textures"].append({"id": "tex_z", "name": "Z", "width": 4, "height": 4, "palette": [None], "pixels": [0] * 16}))),   # D031 D032
            valid(mutate("hibou_chef", lambda d: d["textures"].append({"id": "tex_y", "name": "Y", "width": 6, "height": 4, "palette": [None, "#fff000"], "pixels": [1] * 24}))),   # D033
            valid(mutate("hibou_chef", lambda d: (part(d, "Torse")["transform"].update(scale=[1, 2, 1]), part(d, "Poitrine")["transform"].update(rotation=[10, 0, 0])))),   # D051
            valid(mutate("hibou_chef", lambda d: d["materials"][0].update(emissive=0.5))),                                     # D052
            valid(mutate("hibou_chef", no_bones)),                                                                             # D040
            valid(mutate("hibou_chef", lambda d: None)),                                                                       # D041 (Bassin)
        ]
        for d in cases:
            triggered |= codes(d)
        missing = set(CODES) - triggered
        self.assertFalse(missing, f"codes jamais déclenchés par les tests : {sorted(missing)}")

    def test_specific_messages_and_refs(self):
        d = valid(mutate("hibou_chef", lambda d: rule(d, "Bouclier du Chef")["actions"].pop()))
        hit = [i for i in diagnose(d) if i["code"] == "D012"]
        self.assertEqual(len(hit), 1)
        self.assertEqual(hit[0]["ref"], {"kind": "behavior", "id": rule(d, "Bouclier du Chef")["id"]})
        self.assertIn("figé", hit[0]["message"])

    def test_sorted_by_severity(self):
        d = valid(mutate("hibou_chef", lambda d: (part(d, "Torse")["parameters"].update(size=[0, 1, 1]), part(d, "Cape").update(materialId=None))))
        sev = [i["severity"] for i in diagnose(d)]
        self.assertEqual(sev, sorted(sev, key=["error", "warning", "info"].index))
        self.assertEqual(sev[0], "error")

    def test_model_operations_keep_diagnostics_coherent(self):
        p = CreatureProject.load(EX / "hibou_chef.creature.json")
        p.remove_part(next(x["id"] for x in p.data["parts"] if x["name"] == "Sabre"))
        self.assertEqual(summary(diagnose(p.data))["error"], 0)

    def test_cli(self):
        r = subprocess.run([sys.executable, str(ROOT / "tools" / "diagnose_creature.py"), str(EX / "hibou_chef.creature.json")], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0)
        self.assertIn("0 erreur(s), 0 avertissement(s)", r.stdout)
        r = subprocess.run([sys.executable, str(ROOT / "tools" / "diagnose_creature.py"), str(EX / "demo_dragon.creature.json"), "--strict"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)


@unittest.skipUnless(shutil.which("node"), "Node absent")
class TestParity(unittest.TestCase):
    def test_js_matches_python(self):
        docs = [json.loads(f.read_text(encoding="utf-8")) for f in sorted(EX.glob("*.creature.json"))]
        docs += [mutate("hibou_chef", lambda d: part(d, "Torse").update(materialId=None)), mutate("hibou_chef", lambda d: d["behaviors"]["graphs"].pop()),
                 mutate("hibou_chef", lambda d: part(d, "Bras gauche")["transform"].update(position=[9, 0, 0])), mutate("hibou_chef", lambda d: d["sounds"][0].update(sound="Mob Zombie")),
                 mutate("hibou_chef", lambda d: rule(d, "Bouclier du Chef")["actions"].pop()), mutate("hibou_chef", lambda d: d["behaviors"]["stats"].update(speed=0, detectionRange=1)),
                 mutate("hibou_chef", lambda d: d["animations"][0]["keyframes"][0]["pose"].update({d["skeleton"]["bones"][5]["id"]: {"rotation": [999, 0, 0]}})),
                 mutate("hibou_chef", lambda d: part(d, "Torse")["parameters"].update(size=[0, 1, 1])), mutate("hibou_chef", lambda d: part(d, "Torse").update(name="Cape"))]
        key = lambda i: (i["severity"], i["code"], i["ref"]["kind"], i["ref"]["id"])
        with tempfile.TemporaryDirectory() as t:
            f = Path(t) / "docs.json"; f.write_text(json.dumps(docs), encoding="utf-8")
            js = Path(t) / "t.js"
            js.write_text(CORE + "\nconst L=JSON.parse(require('fs').readFileSync(process.argv[2],'utf8'));console.log(JSON.stringify(L.map(d=>diagnose(d))));", encoding="utf-8")
            r = subprocess.run(["node", str(js), str(f)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1500:])
        got = json.loads(r.stdout)
        for d, g in zip(docs, got):
            self.assertEqual([key(i) for i in diagnose(d)], [key(i) for i in g], d["project"]["name"])


if __name__ == "__main__":
    unittest.main()
