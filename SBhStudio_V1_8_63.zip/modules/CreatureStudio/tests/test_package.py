"""Teste la façade publique `creaturestudio` (API_VERSION 1) et la ligne de commande, depuis les sources
puis depuis un répertoire de build_py (même disposition que l'installation)."""
import json, subprocess, sys, tempfile, unittest, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EX = ROOT / "examples" / "hibou_chef.creature.json"


def run(*args, cwd=None, env=None, iso=False):
    return subprocess.run([sys.executable, *(["-I"] if iso else []), *args], capture_output=True, text=True, cwd=cwd, env=env)


class TestFacade(unittest.TestCase):
    def setUp(self):
        sys.path.insert(0, str(ROOT))

    def test_api(self):
        import creaturestudio as cs
        self.assertEqual((cs.API_VERSION, cs.FORMAT_VERSION), (1, "1.0"))
        for n in cs.__all__:
            self.assertTrue(hasattr(cs, n), n)
        p = cs.load(EX)
        self.assertIsNone(cs.validate(p))
        self.assertIsNone(cs.validate(p.data))
        self.assertTrue(cs.validate({"x": 1}))
        self.assertEqual(cs.summary(cs.diagnose(p))["error"], 0)
        files, report = cs.build_pack(p, "sbh")
        self.assertTrue(any(k.endswith("manifest.json") for k in files))
        with tempfile.TemporaryDirectory() as d:
            cs.export_bedrock(p, d)
            self.assertTrue(list(Path(d).rglob("*.mcaddon")))
        p2 = cs.loads(cs.dumps(p))
        self.assertEqual(p2.data["creature"]["name"], p.data["creature"]["name"])
        self.assertTrue(Path(cs.editor_path()).is_file())

    def test_cli(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertIn("OK", run("-m", "creaturestudio", "validate", str(EX), cwd=ROOT).stdout)
            bad = Path(d) / "bad.json"; bad.write_text('{"x":1}')
            self.assertEqual(run("-m", "creaturestudio", "validate", str(bad), cwd=ROOT).returncode, 1)
            r = run("-m", "creaturestudio", "diagnose", str(EX), cwd=ROOT); self.assertEqual(r.returncode, 0, r.stderr)
            r = run("-m", "creaturestudio", "export", str(EX), "--out", d + "/o", cwd=ROOT); self.assertEqual(r.returncode, 0, r.stderr)
            self.assertTrue(list(Path(d, "o").rglob("*.mcaddon")))

    def test_installed_layout(self):
        """build_py produit la même arborescence que l'installation : la façade doit y fonctionner sans les sources."""
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / "src"; src.mkdir()
            import shutil
            for n in ("core", "tools", "editor", "creaturestudio", "pyproject.toml"):
                (shutil.copytree if (ROOT / n).is_dir() else shutil.copy)(ROOT / n, src / n, **({"ignore": shutil.ignore_patterns("__pycache__")} if (ROOT / n).is_dir() else {}))
            bld = Path(d) / "bld"
            r = subprocess.run([sys.executable, "-c", "from setuptools import setup;setup()", "build_py", "-d", str(bld)], cwd=src, capture_output=True, text=True)
            if r.returncode != 0:
                self.skipTest("setuptools indisponible : " + r.stderr[-200:])
            code = f"import sys;sys.path.insert(0,{str(bld)!r});import creaturestudio as cs;assert '/bld/' in cs.__file__.replace(chr(92),'/');p=cs.load({str(EX)!r});assert cs.validate(p) is None;print(len(cs.build_pack(p)[0]),cs.editor_path())"
            r = run("-c", code, cwd=d, iso=True)
            self.assertEqual(r.returncode, 0, r.stderr[-800:])
            self.assertTrue(r.stdout.strip().endswith("creature_editor.html"), r.stdout)

if __name__ == "__main__":
    unittest.main()
