"""Tests de l'Étape 7 : caractéristiques, règles de comportement (conditions / actions), sélection par priorité."""
import copy, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import DEFAULT_STATS, CreatureError, CreatureProject, evaluate_condition, select_behavior  # noqa: E402

EXAMPLE = ROOT / "examples" / "test_creature.creature.json"


def example():
    return CreatureProject.load(EXAMPLE)


def zombie():
    """Fuir si blessé > attaquer au contact > poursuivre le joueur > se promener (repli)."""
    p = CreatureProject.new("Zombie")
    p.set_stats(detectionRange=10, damage=4)
    flee = p.add_behavior("Fuir", [{"type": "healthBelow", "percent": 25}], [{"type": "flee", "speed": 1.5}])
    hit = p.add_behavior("Attaquer", [{"type": "distance", "op": "<", "value": 2}], [{"type": "attack", "cooldown": 1}])
    chase = p.add_behavior("Poursuivre", [{"type": "playerDetected"}], [{"type": "chase", "speed": 1}])
    wander = p.add_behavior("Se promener", [], [{"type": "wander", "speed": 0.5}])
    return p, flee, hit, chase, wander


class TestStats(unittest.TestCase):
    def test_defaults_and_old_files(self):
        p = example()
        self.assertEqual(p.get_stats(), DEFAULT_STATS)
        self.assertNotIn("stats", p.data["behaviors"])
        self.assertIsNone(validate_creature.check(p.data)[0])

    def test_set_stats_and_ranges(self):
        p = example()
        p.set_stats(health=40, speed=0.9)
        self.assertEqual((p.get_stats()["health"], p.get_stats()["speed"], p.get_stats()["damage"]), (40, 0.9, 3))
        before = copy.deepcopy(p.data)
        for bad in ({"health": 0}, {"speed": 1.5}, {"armor": -1}, {"detectionRange": 100}, {"health": "a"}, {"mana": 5}, {}):
            with self.assertRaises(CreatureError):
                p.set_stats(**bad)
        self.assertEqual(p.data, before)


class TestRules(unittest.TestCase):
    def test_add_edit_move_remove_and_derived_enabled(self):
        p, flee, hit, chase, wander = zombie()
        self.assertTrue(p.data["behaviors"]["enabled"])
        self.assertEqual([g["name"] for g in p.data["behaviors"]["graphs"]], ["Fuir", "Attaquer", "Poursuivre", "Se promener"])
        p.move_behavior(chase, 0)
        self.assertEqual(p.data["behaviors"]["graphs"][0]["id"], chase)
        p.update_behavior(chase, name="Courir vers le joueur", enabled=False)
        self.assertEqual((p.get_behavior(chase)["name"], p.get_behavior(chase)["enabled"]), ("Courir vers le joueur", False))
        with self.assertRaises(CreatureError):
            p.move_behavior(chase, 9)
        for g in (flee, hit, chase, wander):
            p.remove_behavior(g)
        self.assertFalse(p.data["behaviors"]["enabled"])

    def test_block_editing(self):
        p, flee, *_ = zombie()
        i = p.add_condition(flee, {"type": "inWater", "not": True})
        self.assertEqual(i, 1)
        p.set_condition(flee, 1, {"type": "time", "is": "night"})
        self.assertEqual(p.get_behavior(flee)["conditions"][1], {"type": "time", "is": "night"})
        p.remove_condition(flee, 1)
        j = p.add_action(flee, {"type": "jump"})
        p.set_action(flee, j, {"type": "playAnimation"})
        p.remove_action(flee, j)
        for call in (lambda: p.remove_condition(flee, 9), lambda: p.set_action(flee, -1, {"type": "jump"}), lambda: p.remove_action(flee, 5)):
            with self.assertRaises(CreatureError):
                call()

    def test_invalid_blocks_refused_and_unchanged(self):
        p, flee, *_ = zombie()
        before = copy.deepcopy(p.data)
        bad_conditions = [{"type": "magic"}, {"type": "distance", "op": "~", "value": 1}, {"type": "distance", "op": "<", "value": -1},
                          {"type": "time", "is": "dusk"}, {"type": "healthBelow", "percent": 120}, {"type": "random", "chance": 2},
                          {"type": "attacked", "not": "oui"}, "texte"]
        for c in bad_conditions:
            with self.assertRaises(CreatureError):
                p.add_condition(flee, c)
        bad_actions = [{"type": "fly"}, {"type": "chase", "speed": 9}, {"type": "attack", "cooldown": -1}, {"type": "attack", "range": 0},
                       {"type": "idle", "animationId": "nope"}, {"type": "chase", "animationId": None}]
        for a in bad_actions:
            with self.assertRaises(CreatureError):
                p.add_action(flee, a)
        with self.assertRaises(CreatureError):
            p.add_action(flee, {"type": "wander"})                     # 2e action de déplacement (flee + wander)
        with self.assertRaises(CreatureError):
            p.add_behavior("", [], [])
        self.assertEqual(p.data, before)

    def test_removing_an_animation_clears_references(self):
        p = example()
        p.auto_rig()
        a = p.add_animation("Marche", 1.0)
        g = p.add_behavior("Marcher", [], [{"type": "wander", "animationId": a}, {"type": "playAnimation", "animationId": a}][:1])
        p.add_action(g, {"type": "jump"})
        p.remove_animation(a)
        self.assertNotIn("animationId", p.get_behavior(g)["actions"][0])
        self.assertIsNone(validate_creature.check(p.data)[0])


class TestSelection(unittest.TestCase):
    def ctx(self, **kw):
        base = {"playerDistance": None, "time": "day", "healthPercent": 100, "attacked": False, "inWater": False, "random": 0.5}
        base.update(kw)
        return base

    def test_priority_order(self):
        p, flee, hit, chase, wander = zombie()
        pick = lambda **kw: p.select_behavior(self.ctx(**kw))["id"]
        self.assertEqual(pick(), wander)                                           # personne autour : repli
        self.assertEqual(pick(playerDistance=8), chase)                            # détecté (portée 10)
        self.assertEqual(pick(playerDistance=12), wander)                          # hors portée
        self.assertEqual(pick(playerDistance=1.5), hit)                            # au contact : attaquer prime sur poursuivre
        self.assertEqual(pick(playerDistance=1.5, healthPercent=10), flee)         # blessé : fuir prime sur tout
        p.move_behavior(hit, 3)                                                    # attaquer devient la moins prioritaire
        self.assertEqual(pick(playerDistance=1.5), chase)

    def test_disabled_rules_and_no_match(self):
        p, flee, hit, chase, wander = zombie()
        p.update_behavior(wander, enabled=False)
        self.assertIsNone(p.select_behavior(self.ctx()))
        p.update_behavior(chase, enabled=False)
        self.assertIsNone(p.select_behavior(self.ctx(playerDistance=8)))
        self.assertEqual(select_behavior({"graphs": []}, self.ctx()), None)

    def test_each_condition_and_negation(self):
        stats = {**DEFAULT_STATS, "detectionRange": 10}
        cases = [
            ({"type": "playerDetected"}, {"playerDistance": 10}, True), ({"type": "playerDetected"}, {"playerDistance": 10.1}, False),
            ({"type": "playerDetected"}, {"playerDistance": None}, False),
            ({"type": "distance", "op": "<", "value": 2}, {"playerDistance": 2}, False), ({"type": "distance", "op": "<=", "value": 2}, {"playerDistance": 2}, True),
            ({"type": "distance", "op": ">", "value": 2}, {"playerDistance": 3}, True), ({"type": "distance", "op": ">=", "value": 2}, {"playerDistance": None}, False),
            ({"type": "time", "is": "night"}, {"time": "night"}, True), ({"type": "time", "is": "night"}, {"time": "day"}, False),
            ({"type": "healthBelow", "percent": 30}, {"healthPercent": 29.9}, True), ({"type": "healthBelow", "percent": 30}, {"healthPercent": 30}, False),
            ({"type": "attacked"}, {"attacked": True}, True), ({"type": "inWater"}, {}, False), ({"type": "inWater"}, {"inWater": True}, True),
            ({"type": "random", "chance": 0.25}, {"random": 0.2}, True), ({"type": "random", "chance": 0.25}, {"random": 0.25}, False),
            ({"type": "random", "chance": 0}, {"random": 0.0}, False),
            ({"type": "playerDetected", "not": True}, {"playerDistance": None}, True), ({"type": "attacked", "not": True}, {"attacked": True}, False),
            ({"type": "distance", "op": "<", "value": 5, "not": True}, {"playerDistance": None}, True),
        ]
        for cond, ctx, expected in cases:
            self.assertEqual(evaluate_condition(cond, self.ctx(**ctx), stats), expected, (cond, ctx))
        with self.assertRaises(CreatureError):
            evaluate_condition({"type": "magic"}, self.ctx(), stats)

    def test_all_conditions_must_hold(self):
        p = CreatureProject.new("T")
        g = p.add_behavior("Nuit près", [{"type": "time", "is": "night"}, {"type": "playerDetected"}], [{"type": "chase"}])
        self.assertIsNone(p.select_behavior(self.ctx(time="night")))
        self.assertIsNone(p.select_behavior(self.ctx(playerDistance=5)))
        self.assertEqual(p.select_behavior(self.ctx(time="night", playerDistance=5))["id"], g)


class TestValidatorBehavior(unittest.TestCase):
    def test_rejects_bad_data(self):
        p, flee, *_ = zombie()
        good = copy.deepcopy(p.data)
        self.assertIsNone(validate_creature.check(good)[0])
        cases = [
            (lambda d: d.__setitem__("behaviors", []), "behaviors must be an object"),
            (lambda d: d["behaviors"].__setitem__("graphs", {}), "behaviors.graphs must be an array"),
            (lambda d: d["behaviors"]["stats"].__setitem__("health", 0), "invalid stat health"),
            (lambda d: d["behaviors"]["stats"].__setitem__("mana", 1), "invalid stat mana"),
            (lambda d: d["behaviors"]["graphs"].append(copy.deepcopy(d["behaviors"]["graphs"][0])), "duplicate behavior id"),
            (lambda d: d["behaviors"]["graphs"][0].__setitem__("name", ""), "needs a name"),
            (lambda d: d["behaviors"]["graphs"][0].__setitem__("enabled", "oui"), "invalid enabled"),
            (lambda d: d["behaviors"]["graphs"][0].__setitem__("conditions", [{"type": "x"}]), "invalid condition 0"),
            (lambda d: d["behaviors"]["graphs"][0].__setitem__("actions", [{"type": "flee"}, {"type": "idle"}]), "more than one movement action"),
            (lambda d: d["behaviors"]["graphs"][0]["actions"][0].__setitem__("animationId", "nope"), "invalid action 0"),
        ]
        for mutate, expected in cases:
            d = copy.deepcopy(good)
            mutate(d)
            err = validate_creature.check(d)[0]
            self.assertTrue(err and expected in err, f"{expected!r} attendu, obtenu {err!r}")


if __name__ == "__main__":
    unittest.main()
