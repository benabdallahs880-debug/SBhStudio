"""Étape 11 — l'export Bedrock de l'éditeur (JS) doit produire la même chose que core/bedrock_export.py (Python)."""
import base64, io, json, shutil, subprocess, sys, tempfile, unittest, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import bedrock_export as be  # noqa: E402

HTML = (ROOT / "editor" / "creature_editor.html").read_text(encoding="utf-8")
CORE = HTML.split("// ==CORE==")[1].split("// ==ENDCORE==")[0]
EX = ROOT / "examples"
NAMES = sorted(f.name.replace(".creature.json", "") for f in EX.glob("*.creature.json"))

JS = r"""
const fs=require('fs');const names=JSON.parse(process.argv[2]);const out={};
for(const n of names){const d=JSON.parse(fs.readFileSync(process.argv[3]+'/'+n+'.creature.json','utf8'));
 const p=buildBedrockPack(d,'sbh'),x=bedrockExport(d,'sbh');
 out[n]={files:p.files,report:p.report,zip:Buffer.from(x.zip).toString('base64'),zipName:x.filename,zipReport:x.report}}
console.log(JSON.stringify(out));
"""


def close(a, b, path="", tol=2e-3):
    if isinstance(a, dict):
        assert isinstance(b, dict) and set(a) == set(b), f"{path}: clés {sorted(set(a) ^ set(b))}"
        for k in a:
            close(a[k], b[k], f"{path}/{k}", tol)
    elif isinstance(a, list):
        assert isinstance(b, list) and len(a) == len(b), f"{path}: longueurs {len(a)} / {len(b)}"
        for i, (x, y) in enumerate(zip(a, b)):
            close(x, y, f"{path}[{i}]", tol)
    elif isinstance(a, bool) or isinstance(b, bool) or isinstance(a, str) or a is None:
        assert a == b, f"{path}: {a!r} != {b!r}"
    else:
        assert abs(a - b) <= tol, f"{path}: {a} != {b}"


@unittest.skipUnless(shutil.which("node"), "Node absent")
class TestParity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory() as t:
            f = Path(t) / "t.js"
            f.write_text(CORE + "\n" + JS, encoding="utf-8")
            r = subprocess.run(["node", str(f), json.dumps(NAMES), str(EX)], capture_output=True, text=True)
            assert r.returncode == 0, r.stderr[-2000:]
        cls.js = json.loads(r.stdout)

    def test_files_identical_to_python(self):
        for n in NAMES:
            data = json.loads((EX / f"{n}.creature.json").read_text(encoding="utf-8"))
            files, report = be.build_pack(data, "sbh")
            js = self.js[n]
            self.assertEqual(sorted(files), sorted(js["files"]), n)
            for path, item in files.items():
                j = js["files"][path]
                if item[0] == "json":
                    try:
                        close(item[1], j["json"], path)
                    except AssertionError as e:
                        self.fail(f"{n}: {e}")
                else:
                    self.assertEqual((item[1], item[2]), (j["png"]["W"], j["png"]["H"]), n)
                    self.assertEqual([list(map(list, row)) for row in item[3]], j["png"]["px"], f"{n}: pixels de l'atlas")

    def test_reports_identical(self):
        for n in NAMES:
            data = json.loads((EX / f"{n}.creature.json").read_text(encoding="utf-8"))
            _, py = be.build_pack(data, "sbh")
            js = self.js[n]["report"]
            for k in ("identifier", "geometry", "bones", "texture", "animations", "approximations", "warnings", "files"):
                self.assertEqual(py[k], js[k], f"{n}: {k}")
            self.assertAlmostEqual(py["verticalShiftBlocks"], js["verticalShiftBlocks"], places=3)

    def test_js_zip_is_a_valid_addon(self):
        from PIL import Image
        for n in NAMES:
            raw = base64.b64decode(self.js[n]["zip"])
            z = zipfile.ZipFile(io.BytesIO(raw))
            self.assertIsNone(z.testzip(), n)
            self.assertEqual(sorted(z.namelist()), sorted(self.js[n]["files"]), n)
            cname = be.slug(json.loads((EX / f"{n}.creature.json").read_text(encoding="utf-8"))["creature"]["name"])
            self.assertEqual(self.js[n]["zipName"], cname + ".mcaddon")
            for name in z.namelist():
                if name.endswith(".json"):
                    json.loads(z.read(name).decode("utf-8"))
                elif name.endswith(".png"):
                    im = Image.open(io.BytesIO(z.read(name)))
                    im.load()
                    j = self.js[n]["files"][name]["png"]
                    self.assertEqual(im.size, (j["W"], j["H"]))
                    self.assertEqual([im.getpixel((i, 0)) for i in range(min(4, j["W"]))], [tuple(p) for p in j["px"][0][:4]])


if __name__ == "__main__":
    unittest.main()
