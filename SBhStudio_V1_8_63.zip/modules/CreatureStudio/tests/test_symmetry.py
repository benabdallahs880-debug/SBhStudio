"""Tests de l'Étape 4 bis : symétrie (parties miroir liées)."""
import copy, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import (CreatureError, CreatureProject, mirror_limits, mirror_name,  # noqa: E402
                            mirror_rotation, mirror_vector)


def near(t, a, b, eps=1e-9):
    for x, y in zip(a, b):
        t.assertAlmostEqual(x, y, delta=eps)


def arm_project():
    p = CreatureProject.new("Sym")
    arm = p.add_part("Bras gauche", "cylinder", position=[1.2, 0.3, 0.1], rotation=[15, 25, 35], scale=[0.4, 1.2, 0.4])
    p.set_pivot(arm, [0, 0.6, 0])
    hand = p.add_part("Main gauche", "cube", parent_id=arm, position=[0.1, -0.7, 0.2], rotation=[10, -20, 30])
    return p, arm, hand


class TestHelpers(unittest.TestCase):
    def test_vector_rotation_limits_name(self):
        self.assertEqual(mirror_vector([1, 2, 3], "x"), [-1, 2, 3])
        self.assertEqual(mirror_vector([1, 2, 3], "z"), [1, 2, -3])
        self.assertEqual(mirror_rotation([10, 20, 30], "x"), [10, -20, -30])
        self.assertEqual(mirror_rotation([10, 20, 30], "y"), [-10, 20, -30])
        self.assertEqual(mirror_limits({"x": [-10, 40], "y": [5, 20]}, "x"), {"x": [-10, 40], "y": [-20, -5]})
        self.assertEqual(mirror_name("Bras gauche"), "Bras droit")
        self.assertEqual(mirror_name("Jambe haute gauche"), "Jambe haute droite")
        self.assertEqual(mirror_name("Œil droit"), "Œil gauche")
        self.assertEqual(mirror_name("Avant-bras droite"), "Avant-bras gauche")
        self.assertEqual(mirror_name("Gant Gauche"), "Gant Droit")
        self.assertEqual(mirror_name("Genouillère gauche"), "Genouillère droite")   # mot entier : pas « genou »
        self.assertEqual(mirror_name("Genou gauche"), "Genou droit")
        self.assertEqual(mirror_name("Main Gauche"), "Main Droite")
        self.assertEqual(mirror_name("left arm"), "right arm")
        self.assertEqual(mirror_name("Queue"), "Queue")
        with self.assertRaises(CreatureError):
            mirror_vector([1, 2, 3], "w")


class TestMirrorGeometry(unittest.TestCase):
    def test_mirror_is_exact_reflection_two_levels(self):
        p, arm, hand = arm_project()
        arm2 = p.mirror_part(arm, "x")
        hand2 = p.children(arm2)[0]["id"]
        for v in ([0.3, -0.4, 0.5], [0, 0, 0], [-0.2, 0.9, -0.1]):
            mv = mirror_vector(v, "x")
            # niveau 1 : le miroir du point = point du miroir
            near(self, p.local_point(arm2, mv), mirror_vector(p.local_point(arm, v), "x"))
            # niveau 2 : composition enfant puis parent
            w1 = p.local_point(arm, p.local_point(hand, v))
            w2 = p.local_point(arm2, p.local_point(hand2, mv))
            near(self, w2, mirror_vector(w1, "x"))

    def test_mirror_other_axes(self):
        for axis in ("y", "z"):
            p, arm, _ = arm_project()
            arm2 = p.mirror_part(arm, axis)
            v = [0.3, -0.4, 0.5]
            near(self, p.local_point(arm2, mirror_vector(v, axis)), mirror_vector(p.local_point(arm, v), axis))

    def test_names_links_and_hierarchy(self):
        p, arm, hand = arm_project()
        arm2 = p.mirror_part(arm, "x")
        self.assertEqual(p.get_part(arm2)["name"], "Bras droit")
        self.assertEqual(p.children(arm2)[0]["name"], "Main droite")
        self.assertEqual(p.get_part(arm)["mirror"], {"axis": "x", "partId": arm2})
        self.assertEqual(p.get_part(arm2)["mirror"], {"axis": "x", "partId": arm})
        self.assertEqual(p.twin(hand)["id"], p.children(arm2)[0]["id"])
        self.assertEqual(p.get_part(arm2)["parentId"], p.root_id)

    def test_unnamed_side_gets_suffix(self):
        p = CreatureProject.new("T")
        a = p.add_part("Corne", "cone", position=[0.4, 1, 0])
        self.assertEqual(p.get_part(p.mirror_part(a))["name"], "Corne (miroir)")

    def test_errors(self):
        p, arm, hand = arm_project()
        with self.assertRaises(CreatureError):
            p.mirror_part(p.root_id)
        with self.assertRaises(CreatureError):
            p.mirror_part(arm, "w")
        p.mirror_part(arm)
        before = copy.deepcopy(p.data)
        with self.assertRaises(CreatureError):
            p.mirror_part(arm)           # déjà lié
        with self.assertRaises(CreatureError):
            p.mirror_part(hand)          # déjà lié (enfant)
        self.assertEqual(p.data, before)

    def test_bones_limits_sockets_mirrored(self):
        p, arm, _ = arm_project()
        p.add_bone(arm, limits={"x": [-30, 60], "y": [10, 40]})
        p.add_socket(arm, "grip", position=[0.2, -0.5, 0.1], rotation=[0, 30, 0])
        arm2 = p.mirror_part(arm)
        b = p.bone_of_part(arm2)
        self.assertEqual(b["limits"], {"x": [-30, 60], "y": [-40, -10]})
        s = next(s for s in p.data["sockets"] if s["partId"] == arm2)
        self.assertEqual((s["transform"]["position"], s["transform"]["rotation"]), ([-0.2, -0.5, 0.1], [0, -30, 0]))
        self.assertTrue(p.data["skeleton"]["enabled"])

    def test_child_added_under_linked_parent_goes_under_twin(self):
        p, arm, _ = arm_project()
        arm2 = p.mirror_part(arm)
        doigt = p.add_part("Doigt gauche", "cube", parent_id=arm, position=[0.2, -1, 0], symmetric_axis="x")
        twin = p.twin(doigt)
        self.assertEqual(twin["parentId"], arm2)
        self.assertEqual(twin["name"], "Doigt droit")


class TestSymmetricEdits(unittest.TestCase):
    def test_add_part_with_symmetry_creates_twin(self):
        p = CreatureProject.new("T")
        a = p.add_part("Corne gauche", "cone", position=[0.4, 1, 0], symmetric_axis="x")
        t = p.twin(a)
        self.assertEqual(t["name"], "Corne droite")
        self.assertEqual(t["transform"]["position"], [-0.4, 1, 0])

    def test_symmetric_edits_follow_and_independent_edits_do_not(self):
        p = CreatureProject.new("T")
        a = p.add_part("Corne gauche", "cone", position=[0.4, 1, 0], symmetric_axis="x")
        t = p.twin(a)["id"]
        p.set_transform(a, position=[0.6, 1.2, 0.1], rotation=[0, 10, 20], scale=[1, 2, 1], symmetric=True)
        self.assertEqual(p.get_part(t)["transform"], {"position": [-0.6, 1.2, 0.1], "rotation": [0, -10, -20], "scale": [1, 2, 1]})
        p.translate(a, [0.1, 0, 0])                                   # sans symétrie : la jumelle ne bouge pas
        self.assertEqual(p.get_part(t)["transform"]["position"], [-0.6, 1.2, 0.1])
        p.rotate(a, [5, 0, 0], symmetric=True)
        self.assertEqual(p.get_part(t)["transform"]["rotation"][0], 5)
        p.scale_by(a, 2, symmetric=True)
        self.assertEqual(p.get_part(t)["transform"]["scale"], [2, 4, 2])
        p.set_shape(a, "pyramid", symmetric=True)
        self.assertEqual(p.get_part(t)["shape"], "pyramid")
        p.set_pivot(a, [0, 0.5, 0], symmetric=True)
        self.assertEqual(p.get_part(t)["pivot"], [0, 0.5, 0])
        pa, pt = p.local_point(a, [0.2, 0.3, 0.4]), p.local_point(t, [-0.2, 0.3, 0.4])
        near(self, pt, mirror_vector(pa, "x"))                         # toujours une réflexion exacte

    def test_remove_with_and_without_symmetry(self):
        p, arm, _ = arm_project()
        arm2 = p.mirror_part(arm)
        p.remove_part(arm)                                             # sans symétrie : la jumelle reste, lien nettoyé
        self.assertNotIn("mirror", p.get_part(arm2))
        self.assertEqual(validate_creature.check(p.data)[0], None)
        p, arm, _ = arm_project()
        arm2 = p.mirror_part(arm)
        r = p.remove_part(arm, symmetric=True)
        self.assertIn(arm2, r["removed_parts"])
        self.assertEqual(len(p.data["parts"]), 1)

    def test_unlink(self):
        p, arm, _ = arm_project()
        arm2 = p.mirror_part(arm)
        p.unlink_mirror(arm)
        self.assertNotIn("mirror", p.get_part(arm))
        self.assertNotIn("mirror", p.get_part(arm2))
        p.set_transform(arm, position=[9, 9, 9], symmetric=True)       # plus de jumelle : sans effet
        self.assertNotEqual(p.get_part(arm2)["transform"]["position"], [-9, 9, 9])

    def test_duplicate_keeps_internal_links_drops_external(self):
        p, arm, hand = arm_project()
        arm2 = p.mirror_part(arm)
        clone = p.duplicate_part(arm)                                  # lien vers l'extérieur (arm2) : supprimé
        self.assertNotIn("mirror", p.get_part(clone))
        self.assertEqual(validate_creature.check(p.data)[0], None)
        # sous-arbre contenant une paire liée : les liens sont recopiés
        p2 = CreatureProject.new("T")
        g = p2.add_part("Groupe", "cube")
        a = p2.add_part("Aile gauche", "cube", parent_id=g, position=[1, 0, 0], symmetric_axis="x")
        g2 = p2.duplicate_part(g)
        kids = p2.children(g2)
        self.assertEqual(len(kids), 2)
        self.assertEqual(p2.twin(kids[0]["id"])["id"], kids[1]["id"])
        self.assertEqual(validate_creature.check(p2.data)[0], None)


class TestValidatorMirror(unittest.TestCase):
    def test_invalid_links(self):
        p, arm, _ = arm_project()
        p.mirror_part(arm)
        d = copy.deepcopy(p.data)
        next(x for x in d["parts"] if x["id"] == arm)["mirror"]["axis"] = "w"
        self.assertIn("invalid mirror", validate_creature.check(d)[0])
        d = copy.deepcopy(p.data)
        next(x for x in d["parts"] if x["id"] == arm)["mirror"]["partId"] = "nope"
        self.assertIn("missing part", validate_creature.check(d)[0])
        d = copy.deepcopy(p.data)
        next(x for x in d["parts"] if x["id"] == arm)["mirror"]["partId"] = arm
        self.assertIn("itself", validate_creature.check(d)[0])
        d = copy.deepcopy(p.data)
        twin = p.twin(arm)["id"]
        del next(x for x in d["parts"] if x["id"] == twin)["mirror"]
        self.assertIn("not reciprocal", validate_creature.check(d)[0])


if __name__ == "__main__":
    unittest.main()
