"""Tests de l'Étape 2. Lancer : python -m unittest discover -s tests -v (depuis la racine du module)."""
import copy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
from creature_model import CreatureError, CreatureProject  # noqa: E402

EXAMPLE = ROOT / "examples" / "test_creature.creature.json"


def example():
    return CreatureProject.load(EXAMPLE)


class TestCreation(unittest.TestCase):
    def test_new_project_is_valid(self):
        p = CreatureProject.new("Mon Dragon")
        self.assertEqual(p.root_id, "part_body")
        self.assertEqual(len(p.data["parts"]), 1)

    def test_existing_example_loads(self):
        self.assertEqual(len(example().data["parts"]), 7)

    def test_add_part_defaults_to_root_and_generates_unique_ids(self):
        p = CreatureProject.new("T")
        a = p.add_part("Corne", "cone")
        b = p.add_part("Corne", "cone")
        self.assertNotEqual(a, b)
        self.assertEqual(p.get_part(a)["parentId"], "part_body")

    def test_new_shapes_accepted(self):
        p = CreatureProject.new("T")
        p.add_part("Toit", "pyramid")
        p.add_part("Sol", "plane")

    def test_invalid_input_is_refused_and_project_unchanged(self):
        p = CreatureProject.new("T")
        before = copy.deepcopy(p.data)
        for kwargs in ({"name": "X", "shape": "torus"}, {"name": "  "}, {"name": "X", "parent_id": "nope"},
                       {"name": "X", "scale": (1, 0, 1)}, {"name": "X", "position": (1, 2)},
                       {"name": "X", "position": (float("nan"), 0, 0)}):
            with self.assertRaises(CreatureError):
                p.add_part(**kwargs)
        self.assertEqual(p.data, before)


class TestRemove(unittest.TestCase):
    def test_root_cannot_be_removed(self):
        p = example()
        with self.assertRaises(CreatureError):
            p.remove_part("part_body")

    def test_remove_subtree_and_sockets(self):
        p = example()
        r = p.remove_part("part_head")
        self.assertEqual(r["removed_parts"], ["part_head"])
        self.assertEqual(r["removed_sockets"], ["socket_head"])
        self.assertEqual(len(p.data["parts"]), 6)

    def test_remove_with_children_delete(self):
        p = example()
        eye = p.add_part("Oeil", "sphere", parent_id="part_head")
        r = p.remove_part("part_head")
        self.assertIn(eye, r["removed_parts"])

    def test_remove_reparent_keeps_children(self):
        p = example()
        eye = p.add_part("Oeil", "sphere", parent_id="part_head")
        p.remove_part("part_head", children="reparent")
        self.assertEqual(p.get_part(eye)["parentId"], "part_body")
        with self.assertRaises(CreatureError):
            p.get_part("part_head")


class TestDuplicate(unittest.TestCase):
    def test_duplicate_subtree_with_sockets(self):
        p = example()
        p.add_part("Oeil", "sphere", parent_id="part_arm_l")
        clone = p.duplicate_part("part_arm_l", offset=(0, 0, 2))
        c = p.get_part(clone)
        self.assertEqual(c["parentId"], "part_body")
        self.assertEqual(c["name"], "Left Arm (copie)")
        self.assertEqual(c["transform"]["position"], [-1.15, 0.35, 2])
        self.assertEqual(len(p.children(clone)), 1)
        self.assertEqual(sum(1 for s in p.data["sockets"] if s["partId"] == clone), 1)
        ids = [x["id"] for x in p.data["parts"]] + [s["id"] for s in p.data["sockets"]]
        self.assertEqual(len(ids), len(set(ids)))

    def test_duplicate_without_children(self):
        p = example()
        p.add_part("Oeil", "sphere", parent_id="part_head")
        clone = p.duplicate_part("part_head", with_children=False)
        self.assertEqual(p.children(clone), [])

    def test_duplicate_root_refused(self):
        with self.assertRaises(CreatureError):
            example().duplicate_part("part_body")


class TestTransforms(unittest.TestCase):
    def test_set_translate_rotate_scale(self):
        p = example()
        p.set_transform("part_head", position=[0, 3, 0])
        p.translate("part_head", [1, 0, 0])
        p.rotate("part_head", [0, 90, 0])
        p.scale_by("part_head", 2)
        t = p.get_part("part_head")["transform"]
        self.assertEqual(t["position"], [1, 3, 0])
        self.assertEqual(t["rotation"], [0, 90, 0])
        self.assertEqual(t["scale"], [1.8, 1.8, 1.8])

    def test_zero_scale_refused_and_unchanged(self):
        p = example()
        before = copy.deepcopy(p.data)
        with self.assertRaises(CreatureError):
            p.scale_by("part_head", 0)
        self.assertEqual(p.data, before)

    def test_rename_and_set_shape(self):
        p = example()
        p.rename_part("part_head", "Crâne")
        p.set_shape("part_head", "cube")
        h = p.get_part("part_head")
        self.assertEqual((h["name"], h["shape"], h["parameters"]), ("Crâne", "cube", {"size": [1, 1, 1]}))
        self.assertEqual(h["id"], "part_head")  # l'id ne change jamais


class TestHierarchy(unittest.TestCase):
    def test_reparent(self):
        p = example()
        p.reparent("part_tail", "part_leg_l")
        self.assertEqual(p.get_part("part_tail")["parentId"], "part_leg_l")

    def test_cycle_refused(self):
        p = example()
        eye = p.add_part("Oeil", "sphere", parent_id="part_head")
        for child, parent in (("part_head", eye), ("part_head", "part_head")):
            with self.assertRaises(CreatureError):
                p.reparent(child, parent)
        with self.assertRaises(CreatureError):
            p.reparent("part_body", "part_head")

    def test_reorder_only_touches_siblings(self):
        p = example()
        before = [x["id"] for x in p.data["parts"]]
        p.reorder("part_tail", 0)
        after = [x["id"] for x in p.data["parts"]]
        self.assertEqual(after[0], "part_body")
        self.assertEqual(after[1], "part_tail")
        self.assertEqual(sorted(before), sorted(after))
        with self.assertRaises(CreatureError):
            p.reorder("part_tail", 99)

    def test_ids_stable_after_many_operations(self):
        p = example()
        original = {x["id"] for x in p.data["parts"]}
        p.add_part("Aile", "plane")
        p.duplicate_part("part_arm_l")
        p.reparent("part_tail", "part_leg_l")
        p.reorder("part_leg_r", 0)
        self.assertTrue(original <= {x["id"] for x in p.data["parts"]})


class TestSockets(unittest.TestCase):
    def test_add_remove_socket(self):
        p = example()
        s = p.add_socket("part_body", "back", position=[0, 1, -0.5])
        p.remove_socket(s)
        with self.assertRaises(CreatureError):
            p.remove_socket(s)
        with self.assertRaises(CreatureError):
            p.add_socket("nope", "x")


class TestPersistence(unittest.TestCase):
    def test_save_then_cli_validator_accepts(self):
        p = CreatureProject.new("Dragon")
        head = p.add_part("Tête", "cube", position=[0, 1.5, 0])
        p.add_part("Corne", "cone", parent_id=head)
        p.duplicate_part(head)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "x.creature.json"
            p.save(path)
            r = subprocess.run([sys.executable, str(ROOT / "tools" / "validate_creature.py"), str(path)],
                               capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stdout)
            self.assertEqual(CreatureProject.load(path).data, p.data)

    def test_tree_text(self):
        self.assertIn("Head [sphere]", example().tree_text())


if __name__ == "__main__":
    unittest.main()
