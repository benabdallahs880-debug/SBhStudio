"""Tests des personnages HIBOU : Chef + soldats HIPPO I/II/III (examples/hibou_*.creature.json)."""
import sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import CreatureProject, mirror_rotation, mirror_vector  # noqa: E402

NAMES = ("hippo1", "hippo2", "hippo3", "chef")


def load(v):
    return CreatureProject.load(ROOT / "examples" / f"hibou_{v}.creature.json")


class TestHibou(unittest.TestCase):
    def test_all_valid_with_expected_counts(self):
        counts = {"hippo1": 39, "hippo2": 49, "hippo3": 52, "chef": 66}
        for v in NAMES:
            p = load(v)
            self.assertIsNone(validate_creature.check(p.data)[0], v)
            self.assertEqual(len(p.data["parts"]), counts[v], v)
            self.assertTrue(p.data["skeleton"]["enabled"] and p.data["behaviors"]["enabled"])
            self.assertEqual({a["name"] for a in p.data["animations"]}, {"Repos", "Marche", "Course", "Attaque", "Dégâts", "Mort"})

    def test_tiers_gain_armor(self):
        n = [len(load(v).data["parts"]) for v in ("hippo1", "hippo2", "hippo3")]
        self.assertLess(n[0], n[1]); self.assertLess(n[1], n[2])
        h = [load(v).get_stats()["health"] for v in ("hippo1", "hippo2", "hippo3")]
        self.assertLessEqual(h[0], h[1]); self.assertLessEqual(h[1], h[2])

    def test_soldiers_have_real_mask_and_emblem(self):
        for v in ("hippo1", "hippo2", "hippo3"):
            names = {x["name"] for x in load(v).data["parts"]}
            for needed in ("Voile", "Fente des yeux", "Œil gauche", "Œil droit", "Plaque"):
                self.assertIn(needed, names, v)
            self.assertTrue(any(n.startswith("Emblème") for n in names), v)

    def test_chef_has_cape_banners_sabre_textures(self):
        p = load("chef")
        names = {x["name"] for x in p.data["parts"]}
        for needed in ("Cape", "Bannière gauche", "Bannière droite", "Sabre", "Lame", "Plastron", "Bandeau doré"):
            self.assertIn(needed, names)
        self.assertIn("Cape", {b["name"] for b in p.data["skeleton"]["bones"]})
        self.assertEqual({t["name"] for t in p.data["textures"]}, {"Hibou", "Visage du Chef", "Bannière"})
        self.assertTrue(all(x["materialId"] for x in p.data["parts"]))

    def test_gender_names(self):
        for v in NAMES:
            names = {x["name"] for x in load(v).data["parts"]}
            for bad in ("Bras droite", "Gant droite", "Anneau doré droite", "Liseré de genouillère droite", "Brassard droite", "Genouillère droit"):
                self.assertNotIn(bad, names, v)
        names = {x["name"] for x in load("chef").data["parts"]}
        for ok in ("Anneau doré droit", "Liseré de genouillère droit", "Brassard droit", "Genouillère droite"):
            self.assertIn(ok, names)

    def test_left_right_twins_exact(self):
        for v in NAMES:
            p = load(v)
            for a in [x for x in p.data["parts"] if x.get("mirror") and "gauche" in x["name"].lower()]:
                b = p.twin(a["id"])
                self.assertIsNotNone(b, f"{v}: {a['name']}")
                self.assertEqual(b["transform"]["position"], mirror_vector(a["transform"]["position"], "x"), a["name"])
                self.assertEqual(b["transform"]["rotation"], mirror_rotation(a["transform"]["rotation"], "x"), a["name"])

    def test_animations_within_limits_and_loops_close(self):
        for v in NAMES:
            p = load(v)
            bones = {b["id"]: b for b in p.data["skeleton"]["bones"]}
            for a in p.data["animations"]:
                for k in a["keyframes"]:
                    for bid, e in k["pose"].items():
                        for i, val in enumerate(e.get("rotation", [])):
                            lo, hi = bones[bid].get("limits", {}).get("xyz"[i], (-1e9, 1e9))
                            self.assertTrue(lo - 1e-6 <= val <= hi + 1e-6, f"{v} {a['name']} {bones[bid]['name']}")
                if a["loop"]:
                    s0, s1 = p.sample(a["id"], 0), p.sample(a["id"], a["duration"] - 1e-7)
                    for bid in s0:
                        for f in s0[bid]:
                            for x, y in zip(s0[bid][f], s1[bid][f]):
                                self.assertAlmostEqual(x, y, delta=1e-3)

    def test_dressing_follows_the_body(self):
        """Les protections sont des enfants des parties qu'elles habillent : elles suivent donc les poses."""
        for v in NAMES:
            p = load(v)
            byid = {x["id"]: x for x in p.data["parts"]}
            by = {}
            for x in p.data["parts"]:
                by.setdefault(x["name"], x)

            def ancestors(x):
                while x.get("parentId"):
                    x = byid[x["parentId"]]
                    yield x["name"]
            for dress, body in (("Genouillère gauche", "Jambe haute gauche"), ("Gant droit", "Avant-bras droit"), ("Épaulière gauche", "Torse")):
                self.assertIn(body, list(ancestors(by[dress])), f"{v}: {dress} doit suivre {body}")
        p = load("chef")
        by = {x["name"]: x for x in p.data["parts"]}
        byid = {x["id"]: x for x in p.data["parts"]}
        self.assertEqual(byid[by["Sabre"]["parentId"]]["name"], "Gant droit")


if __name__ == "__main__":
    unittest.main()
