"""Étape 10 — export Bedrock : cohérence géométrique (rest + poses d'animation), structure des fichiers, comportement, emballage.
ATTENTION : ces tests prouvent que l'export est cohérent avec ses PROPRES conventions (docs/BEDROCK_EXPORT.md) ; ils ne prouvent pas
que le jeu les interprète ainsi — cela reste à vérifier dans Minecraft Bedrock."""
import copy, json, re, sys, tempfile, unittest, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import bedrock_export as be  # noqa: E402
from creature_model import CreatureProject, rotation_matrix  # noqa: E402

EX = ROOT / "examples"
ALL = sorted(f.stem.replace(".creature", "") for f in EX.glob("*.creature.json"))


def load(name):
    return json.loads((EX / f"{name}.creature.json").read_text(encoding="utf-8"))


def mv(R, v):
    return [sum(R[i][j] * v[j] for j in range(3)) for i in range(3)]


def corners(lo, hi):
    return [[(lo, hi)[(k >> i) & 1][i] for i in range(3)] for k in range(8)]


class Reference:
    """Calcul INDÉPENDANT de l'exporteur : position monde des sommets de boîte, directement depuis le format (convention de core/format.md)."""
    def __init__(self, data):
        self.d, self.by = data, {p["id"]: p for p in data["parts"]}
        self.bone_of_part = {b["partId"]: b["id"] for b in data["skeleton"]["bones"]}

    def world(self, pid, pt, pose):
        p = self.by[pid]
        T = p["transform"]
        pv = p.get("pivot", [0, 0, 0])
        e = pose.get(self.bone_of_part.get(pid), {})
        R = be._mat_mul(rotation_matrix(e["rotation"]), rotation_matrix(T["rotation"])) if "rotation" in e else rotation_matrix(T["rotation"])
        pos = [T["position"][i] + (e["position"][i] if "position" in e else 0) for i in range(3)]
        d = mv(R, [(pt[i] - pv[i]) * T["scale"][i] for i in range(3)])
        q = [pos[i] + d[i] for i in range(3)]
        return q if p["parentId"] is None else self.world(p["parentId"], q, pose)


def bedrock_world(geo, names_by_part, pid, point_units, anim_rot=None, anim_pos=None):
    """Reconstruction côté Bedrock (conventions de l'export) : os imbriqués, rotation autour du pivot, angles Bedrock = repos + animation (addition d'angles)."""
    bones = {b["name"]: b for b in geo["minecraft:geometry"][0]["bones"]}
    cur, name = list(point_units), names_by_part[pid]
    while name:
        b = bones[name]
        r = list(b.get("rotation", [0, 0, 0]))
        if anim_rot and name in anim_rot:
            r = [r[i] + anim_rot[name][i] for i in range(3)]
        R = rotation_matrix([-r[0], r[1], -r[2]])
        pv = b["pivot"]
        off = anim_pos.get(name, [0, 0, 0]) if anim_pos else [0, 0, 0]
        d = mv(R, [cur[i] - pv[i] for i in range(3)])
        cur = [pv[i] + d[i] + off[i] for i in range(3)]
        name = b.get("parent")
    return cur


def anim_at(doc, short, bone_names, t):
    a = next(v for k, v in doc["animations"].items() if k.endswith("." + short))
    rot, pos = {}, {}
    for nm, ch in a["bones"].items():
        for kind, out in (("rotation", rot), ("position", pos)):
            if kind in ch:
                key = next(k for k in ch[kind] if abs(float(k) - t) < 1e-6)
                out[nm] = ch[kind][key]
    return rot, pos


class TestGeometry(unittest.TestCase):
    def check_character(self, name, with_animation=True):
        data = load(name)
        atlas = be.build_atlas(data)
        geo, names, dy, _, _ = be.build_geometry(data, "t", atlas)
        ref = Reference(data)
        poses = [("repos", {}, None, None)]
        if with_animation:
            doc, ids, _ = be.build_animations(data, names, "t")
            proj = CreatureProject(copy.deepcopy(data))
            for a in data["animations"]:
                for k in a["keyframes"][:3]:
                    t = k["time"]
                    rot, pos = anim_at(doc, be.slug(a["name"]), names, t)
                    poses.append((f"{a['name']}@{t}", proj.sample(a["id"], t), rot, pos))
        worst, skew = 0.0, be.skewed_parts(data)
        for label, pose, rot, pos in poses:
            for p in data["parts"]:
                if p["id"] in skew:
                    continue                                              # limite connue et signalée à l'export (skewed_parts)
                lo, hi = be._local_box(p)
                for c in corners(lo, hi):
                    w = ref.world(p["id"], c, pose)                       # blocs, repère du format
                    # côté Bedrock : le coin est d'abord ramené dans le repère « repos à plat » (échelles cumulées), puis les os l'animent
                    L = be._rest_layout(data["parts"])[p["id"]]
                    flat = [L["s"][i] * c[i] + L["t"][i] for i in range(3)]
                    pt = [flat[0] * 16, (flat[1] + dy) * 16, flat[2] * 16]
                    got = bedrock_world(geo, names, p["id"], pt, rot, pos)
                    exp = [w[0] * 16, (w[1] + dy) * 16, w[2] * 16]
                    err = max(abs(got[i] - exp[i]) for i in range(3))
                    worst = max(worst, err)
                    self.assertLess(err, 0.02, f"{name} {label} {p['name']} : écart {err:.4f} unités")
        return worst

    def test_rest_and_animated_poses_match_the_format(self):
        for n in ("soldat_standard", "hibou_hippo1", "hibou_chef", "demo_rigged_quadruped"):
            self.check_character(n)

    def test_every_example_rest_pose(self):
        for n in ALL:
            self.check_character(n, with_animation=False)

    def test_model_stands_on_the_ground(self):
        for n in ALL:
            data = load(n)
            geo, *_ = be.build_geometry(data, "t", be.build_atlas(data))
            ys = [c["origin"][1] for b in geo["minecraft:geometry"][0]["bones"] for c in b["cubes"]]
            self.assertAlmostEqual(min(ys), 0, places=3, msg=n)

    def test_rotation_sign_convention(self):
        self.assertEqual(be.bedrock_rotation([10, 20, 30]), [-10, 20, -30])
        self.assertEqual(be.bedrock_rotation([0, 0, 0]), [0, 0, 0])
        self.assertTrue(all(str(v) != "-0.0" for v in be.bedrock_rotation([0, 0, 0])))

    def test_euler_roundtrip(self):
        for rot in ([10, 20, 30], [-40, 5, 80], [0, 0, 0], [90, 0, 0], [20, -60, 15]):
            back = be.euler_from_matrix(rotation_matrix(rot))
            for a, b in zip(rotation_matrix(rot), rotation_matrix(back)):
                for x, y in zip(a, b):
                    self.assertAlmostEqual(x, y, places=6)

    def test_skew_limit_is_detected_and_reported(self):
        quad = load("demo_rigged_quadruped")
        flagged = be.skewed_parts(quad)
        self.assertEqual({p["name"] for p in quad["parts"] if p["id"] in flagged}, {"Queue"} | {p["name"] for p in quad["parts"] if p["name"] in ("Queue",)})
        with tempfile.TemporaryDirectory() as t:
            self.assertTrue(any("POSITION FAUSSE" in w for w in be.export_bedrock(quad, t)["warnings"]))
        for n in ("soldat_standard", "hibou_chef", "hibou_hippo3"):
            self.assertEqual(be.skewed_parts(load(n)), set(), n)          # les personnages livrés n'ont pas ce défaut

    def test_non_box_shapes_are_reported(self):
        data = load("hibou_chef")
        *_, approx, _ = be.build_geometry(data, "t", be.build_atlas(data))
        self.assertTrue(any("cylinder" in a for a in approx))
        self.assertTrue(any("sphere" in a for a in approx))


class TestFiles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.out = Path(cls.tmp.name)
        cls.data = load("hibou_chef")
        cls.report = be.export_bedrock(cls.data, cls.out, "sbh")

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def j(self, rel):
        return json.loads((self.out / rel).read_text(encoding="utf-8"))

    def test_identifiers_are_consistent(self):
        client = self.j("le_chef_RP/entity/le_chef.entity.json")["minecraft:client_entity"]["description"]
        bp = self.j("le_chef_BP/entities/le_chef.json")["minecraft:entity"]["description"]
        geo = self.j("le_chef_RP/models/entity/le_chef.geo.json")["minecraft:geometry"][0]["description"]
        rc = self.j("le_chef_RP/render_controllers/le_chef.rc.json")["render_controllers"]
        self.assertEqual(client["identifier"], bp["identifier"])
        self.assertEqual(client["identifier"], "sbh:le_chef")
        self.assertEqual(client["geometry"]["default"], geo["identifier"])
        self.assertIn(client["render_controllers"][0], rc)
        self.assertTrue((self.out / "le_chef_RP" / (client["textures"]["default"] + ".png")).exists())
        self.assertRegex(client["spawn_egg"]["base_color"], r"^#[0-9a-f]{6}$")

    def test_bones_unique_parents_exist_and_cubes_inside_texture(self):
        g = self.j("le_chef_RP/models/entity/le_chef.geo.json")["minecraft:geometry"][0]
        names = [b["name"] for b in g["bones"]]
        self.assertEqual(len(names), len(set(names)))
        self.assertEqual(len(names), len(self.data["parts"]))
        W, H = g["description"]["texture_width"], g["description"]["texture_height"]
        for b in g["bones"]:
            self.assertRegex(b["name"], r"^[a-z0-9_]+$")
            if "parent" in b:
                self.assertIn(b["parent"], names)
            for c in b["cubes"]:
                for f, uv in c["uv"].items():
                    self.assertIn(f, ("north", "south", "east", "west", "up", "down"))
                    (u, v), (w, h) = uv["uv"], uv["uv_size"]
                    self.assertTrue(0 <= u and 0 <= v and u + w <= W and v + h <= H, f"{b['name']} {f} hors de la texture")

    def test_png_matches_atlas(self):
        from PIL import Image
        im = Image.open(self.out / "le_chef_RP" / "textures" / "entity" / "sbh" / "le_chef.png")
        g = self.j("le_chef_RP/models/entity/le_chef.geo.json")["minecraft:geometry"][0]["description"]
        self.assertEqual(im.size, (g["texture_width"], g["texture_height"]))
        self.assertEqual(im.mode, "RGBA")
        self.assertEqual(im.getpixel((0, 0))[3], 255)
        self.assertEqual(im.getpixel((0, 0))[:3], tuple(int(self.data["materials"][0]["color"][i:i + 2], 16) for i in (1, 3, 5)))

    def test_animations_reference_existing_bones_and_closed_loops(self):
        geo = self.j("le_chef_RP/models/entity/le_chef.geo.json")["minecraft:geometry"][0]["bones"]
        names = {b["name"] for b in geo}
        anims = self.j("le_chef_RP/animations/le_chef.animation.json")
        client = self.j("le_chef_RP/entity/le_chef.entity.json")["minecraft:client_entity"]["description"]
        self.assertEqual(anims["format_version"], "1.8.0")
        for short, full in client["animations"].items():
            if short == "main":
                continue
            self.assertIn(full, anims["animations"])
        for full, a in anims["animations"].items():
            for nm, ch in a["bones"].items():
                self.assertIn(nm, names)
                for kind in ch:
                    keys = sorted(float(k) for k in ch[kind])
                    self.assertEqual(keys[0], 0.0)
                    self.assertLessEqual(keys[-1], a["animation_length"] + 1e-9)
            if a["loop"]:                                               # boucle fermée : première et dernière valeurs égales
                for ch in a["bones"].values():
                    for kind, frames in ch.items():
                        ks = sorted(frames, key=float)
                        self.assertEqual(frames[ks[0]], frames[ks[-1]], full)

    def test_animation_controller(self):
        ac = self.j("le_chef_RP/animation_controllers/le_chef.ac.json")["animation_controllers"]
        (cid, c), = ac.items()
        self.assertEqual(c["initial_state"], "default")
        for s in c["states"].values():
            for t in s["transitions"]:
                (target, cond), = t.items()
                self.assertIn(target, c["states"])
                self.assertIsInstance(cond, str)

    def test_manifests(self):
        rp, bp = self.j("le_chef_RP/manifest.json"), self.j("le_chef_BP/manifest.json")
        uu = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
        ids = [rp["header"]["uuid"], rp["modules"][0]["uuid"], bp["header"]["uuid"], bp["modules"][0]["uuid"]]
        self.assertTrue(all(uu.match(i) for i in ids))
        self.assertEqual(len(set(ids)), 4)
        self.assertEqual((rp["format_version"], rp["modules"][0]["type"], bp["modules"][0]["type"]), (2, "resources", "data"))
        self.assertEqual(bp["dependencies"][0]["uuid"], rp["header"]["uuid"])
        again = be.export_bedrock(self.data, self.out / "bis", "sbh")                  # UUID déterministes
        self.assertEqual(json.loads((self.out / "bis" / "le_chef_RP" / "manifest.json").read_text(encoding="utf-8"))["header"]["uuid"], rp["header"]["uuid"])
        self.assertEqual(again["identifier"], "sbh:le_chef")

    def test_behavior_entity(self):
        e = self.j("le_chef_BP/entities/le_chef.json")["minecraft:entity"]
        c = e["components"]
        self.assertEqual(c["minecraft:health"]["value"], self.data["behaviors"]["stats"]["health"])
        self.assertEqual(c["minecraft:attack"]["damage"], self.data["behaviors"]["stats"]["damage"])
        for need in ("minecraft:behavior.melee_attack", "minecraft:behavior.random_stroll", "minecraft:behavior.nearest_attackable_target", "minecraft:navigation.walk"):
            self.assertIn(need, c)
        prios = [v["priority"] for k, v in c.items() if k.startswith("minecraft:behavior.")]
        self.assertEqual(min(prios), min(prios))
        self.assertTrue(e["description"]["is_spawnable"])
        self.assertGreater(c["minecraft:collision_box"]["height"], 1.5)

    def test_report_is_honest(self):
        w = " ".join(self.report["warnings"])
        for needle in ("capacité « shield »", "capacité « heal »", "armure", "son(s)"):
            self.assertIn(needle, w)
        self.assertTrue(self.report["approximations"])
        self.assertTrue((self.out / "EXPORT_REPORT.json").exists())

    def test_mcaddon_contents(self):
        with zipfile.ZipFile(self.out / "le_chef.mcaddon") as z:
            names = set(z.namelist())
            self.assertIn("le_chef_RP/manifest.json", names)
            self.assertIn("le_chef_BP/manifest.json", names)
            self.assertIn("le_chef_RP/models/entity/le_chef.geo.json", names)
            self.assertNotIn("EXPORT_REPORT.json", names)
            self.assertIsNone(z.testzip())

    def test_invalid_project_refused(self):
        bad = copy.deepcopy(self.data)
        bad["parts"][1]["parentId"] = "nope"
        with self.assertRaises(ValueError):
            be.export_bedrock(bad, self.out / "x")

    def test_every_example_exports(self):
        for n in ALL:
            with tempfile.TemporaryDirectory() as t:
                r = be.export_bedrock(load(n), t, "sbh")
                self.assertGreater(r["bones"], 0, n)


if __name__ == "__main__":
    unittest.main()
