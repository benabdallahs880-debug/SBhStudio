"""Étape 8 — sons, effets, capacités spéciales : modèle Python, validateur, miroir JS (Node) et simulateur."""
import copy, json, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "tools"))
import validate_creature  # noqa: E402
from creature_model import CreatureError, CreatureProject  # noqa: E402

HTML = (ROOT / "editor" / "creature_editor.html").read_text(encoding="utf-8")
CORE = HTML.split("// ==CORE==")[1].split("// ==ENDCORE==")[0]


def chef():
    return CreatureProject.load(ROOT / "examples" / "hibou_chef.creature.json")


class TestPython(unittest.TestCase):
    def test_sound_and_effect_crud(self):
        p = CreatureProject.new("T")
        s = p.add_sound("Cri", "mob.zombie.say", 0.5, 1.5)
        e = p.add_effect("Feu", "fire", "#ff0000", 10, part_id=p.root_id)
        p.update_sound(s, volume=0.2); p.update_effect(e, kind="ice", partId=None)
        self.assertEqual(p.get_sound(s)["volume"], 0.2)
        self.assertNotIn("partId", p.get_effect(e))
        for bad in (lambda: p.add_sound("X", "  "), lambda: p.add_sound("X", "a", volume=2), lambda: p.add_sound("X", "a", pitch=3),
                    lambda: p.add_effect("X", "lave"), lambda: p.add_effect("X", "fire", color="rouge"), lambda: p.add_effect("X", "fire", count=0),
                    lambda: p.update_sound(s, foo=1), lambda: p.get_effect("nope")):
            with self.assertRaises(CreatureError):
                bad()
        self.assertEqual(len(p.data["sounds"]), 1)          # rien n'a été ajouté par les opérations refusées

    def test_actions_validated(self):
        p = CreatureProject.new("T")
        s = p.add_sound("Cri", "a.b"); e = p.add_effect("F", "fire")
        g = p.add_behavior("R")
        ok = [{"type": "playSound", "soundId": s}, {"type": "effect", "effectId": e}, {"type": "ability", "ability": "poison", "power": 4, "duration": 5, "cooldown": 3, "effectId": e, "soundId": s}]
        for a in ok:
            p.add_action(g, a)
        for ab in ("fire", "ice", "lightning", "poison", "explosion", "teleport", "shield", "invisibility", "heal"):
            p.add_action(g, {"type": "ability", "ability": ab})
        for bad in ({"type": "playSound", "soundId": "inconnu"}, {"type": "effect"}, {"type": "ability", "ability": "vol"}, {"type": "ability", "ability": "fire", "power": 99},
                    {"type": "ability", "ability": "fire", "effectId": "inconnu"}, {"type": "ability", "ability": "fire", "duration": -1}):
            with self.assertRaises(CreatureError):
                p.add_action(g, bad)
        # une capacité n'est pas un mouvement : elle se combine avec chase
        p.add_action(g, {"type": "chase"})

    def test_removal_cascades(self):
        p = chef()
        sid = p.data["sounds"][0]["id"]
        n = sum(1 for g in p.data["behaviors"]["graphs"] for a in g["actions"] if a["type"] == "playSound")
        self.assertEqual(n, 1)
        p.remove_sound(sid)
        self.assertEqual(sum(1 for g in p.data["behaviors"]["graphs"] for a in g["actions"] if a["type"] == "playSound"), 0)
        eid = next(e["id"] for e in p.data["effects"] if e["name"] == "Aura dorée")
        p.remove_effect(eid)
        for g in p.data["behaviors"]["graphs"]:
            for a in g["actions"]:
                self.assertNotEqual(a.get("effectId"), eid)
        self.assertIsNone(validate_creature.check(p.data)[0])

    def test_removing_a_part_detaches_effects(self):
        p = chef()
        sabre = next(x["id"] for x in p.data["parts"] if x["name"] == "Sabre")
        p.remove_part(sabre)
        ef = next(e for e in p.data["effects"] if e["name"] == "Étincelles de lame")
        self.assertNotIn("partId", ef)

    def test_old_files_still_load(self):
        for f in ("demo_dragon", "soldat_standard", "hibou_hippo1"):
            p = CreatureProject.load(ROOT / "examples" / f"{f}.creature.json")
            self.assertEqual((p.data["sounds"], p.data["effects"]), ([], []))

    def test_demo_characters(self):
        c = chef()
        names = [g["name"] for g in c.data["behaviors"]["graphs"]]
        self.assertEqual(names[:2], ["Bouclier du Chef", "Se soigner"])
        abil = {a["ability"] for g in c.data["behaviors"]["graphs"] for a in g["actions"] if a["type"] == "ability"}
        self.assertEqual(abil, {"shield", "heal"})
        h3 = CreatureProject.load(ROOT / "examples" / "hibou_hippo3.creature.json")
        self.assertEqual(h3.data["behaviors"]["graphs"][0]["name"], "Lancer une grenade")
        # une règle de capacité garde un mouvement : le personnage ne reste pas figé pendant la recharge
        for g in c.data["behaviors"]["graphs"][:2]:
            self.assertTrue(any(a["type"] == "chase" for a in g["actions"]))


JS = r"""
const assert=require('assert');
const d=JSON.parse(require('fs').readFileSync(process.argv[2],'utf8'));
const p=new Project(d);
const s=p.addSound('Cri','mob.zombie.say',.5,1.5),e=p.addEffect('Feu','fire','#ff0000',10,p.root);
const g=p.addBehavior('R');
p.addAction(g,{type:'ability',ability:'poison',power:4,effectId:e,soundId:s});p.addAction(g,{type:'playSound',soundId:s});
for(const bad of [{type:'playSound',soundId:'x'},{type:'ability',ability:'vol'},{type:'ability',ability:'fire',power:99},{type:'effect'}])assert.throws(()=>p.addAction(g,bad));
assert.throws(()=>p.addSound('X','  '));
assert.throws(()=>p.addEffect('X','lave'));assert.throws(()=>p.addSound('X','a',2));
p.removeSound(s);assert.ok(!p.beh(g).actions.some(a=>a.type=='playSound'));assert.ok(!('soundId' in p.beh(g).actions[0]));
p.removeEffect(e);assert.strictEqual(p.beh(g).actions.length,1);
// effet attaché à une partie supprimée
const c=p.add('Aile','cube');p.addEffect('E2','magic','#00ff00',5,c);p.remove(c);assert.ok(p.d.effects.every(x=>!('partId' in x)||p.d.parts.some(q=>q.id==x.partId)));
console.log(JSON.stringify(p.d));
"""

SIM = r"""
const assert=require('assert');
const d=JSON.parse(require('fs').readFileSync(process.argv[2],'utf8'));
const beh=Object.assign({},d.behaviors,{sounds:d.sounds,effects:d.effects});
const rnd=()=>.5;
// HIPPO III : grenade à distance 3..8, avec recharge de 10 s ; le soldat continue à avancer
let S=simNew(beh,rnd);S.px=6;S.pz=0;
simStep(S,.1,beh,rnd);
assert.strictEqual(S.abHits,1);assert.ok(S.playerHp<100);assert.ok(S.fx.length>=1);assert.deepStrictEqual(S.snd,['Détonation']);
const hold=()=>{S.x=0;S.z=0;S.px=6;S.pz=0};   // le joueur reste à 6 blocs : on isole la recharge
for(let i=0;i<20;i++){hold();simStep(S,.1,beh,rnd)}assert.strictEqual(S.abHits,1,'recharge respectée');
for(let i=0;i<100;i++){hold();simStep(S,.1,beh,rnd)}assert.ok(S.abHits>=2,'recharge terminée');
// hors de portée : aucune capacité offensive
S=simNew(beh,rnd);S.px=11;S.pz=0;simStep(S,.1,beh,rnd);assert.strictEqual(S.abHits,0);
// joueur absent : pas d'attaque
S=simNew(beh,rnd);S.playerOn=false;simStep(S,.1,beh,rnd);assert.strictEqual(S.abHits,0);
console.log('ok');
"""

SIM2 = r"""
const assert=require('assert');
const mk=(abil)=>({stats:{health:20},graphs:[{id:'g',name:'g',actions:[Object.assign({type:'ability',cooldown:5},abil)]}],sounds:[],effects:[]});
const rnd=()=>.5,run=(abil,pre)=>{const b=mk(abil),S=simNew(b,rnd);if(pre)pre(S);simStep(S,.1,b,rnd);return S};
let S=run({ability:'poison',power:6,duration:3,range:10});assert.strictEqual(S.poisonT>0,true);const h=S.playerHp;for(let i=0;i<40;i++)simStep(S,.1,mk({ability:'poison',power:6,duration:3,range:10}),rnd);assert.ok(S.playerHp<h-4,'le poison fait des dégâts dans la durée');
S=run({ability:'ice',power:2,duration:4,range:10});assert.ok(S.slowT>3.8);assert.strictEqual(S.playerHp,99);
S=run({ability:'explosion',power:5,range:10});assert.ok(S.px>6.5);assert.strictEqual(S.playerHp,95);       // projeté
S=run({ability:'shield',duration:4});assert.ok(S.shield>3.8);
S=run({ability:'invisibility',duration:4});assert.ok(S.invis>3.8);
S=run({ability:'heal',power:3},S=>{S.hp=5});assert.strictEqual(S.hp,11);
S=run({ability:'teleport',range:10},S=>{S.px=8});assert.ok(Math.hypot(S.px-S.x,S.pz-S.z)<2.1);
console.log('ok');
"""


@unittest.skipUnless(shutil.which("node"), "Node absent")
class TestJS(unittest.TestCase):
    def node(self, body, *args):
        with tempfile.TemporaryDirectory() as t:
            f = Path(t) / "t.js"
            f.write_text(CORE + "\n" + body, encoding="utf-8")
            r = subprocess.run(["node", str(f), *args], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr[-1500:])
            return r.stdout

    def test_js_model_matches_python_validator(self):
        out = self.node(JS, str(ROOT / "examples" / "hibou_chef.creature.json"))
        self.assertIsNone(validate_creature.check(json.loads(out))[0])

    def test_js_accepts_python_made_files_with_specials(self):
        for v in ("chef", "hippo3"):
            self.node("new Project(JSON.parse(require('fs').readFileSync(process.argv[2],'utf8')));", str(ROOT / "examples" / f"hibou_{v}.creature.json"))

    def test_js_and_python_agree_on_invalid_documents(self):
        base = json.loads((ROOT / "examples" / "hibou_chef.creature.json").read_text(encoding="utf-8"))
        cases = []
        for mut in (lambda d: d["sounds"][0].update(pitch=5), lambda d: d["sounds"][0].update(sound=""), lambda d: d["effects"][0].update(kind="x"),
                    lambda d: d["effects"][0].update(color="red"), lambda d: d["effects"][0].update(partId="zzz"), lambda d: d["effects"][0].update(count=0),
                    lambda d: d["effects"].append(copy.deepcopy(d["effects"][0])), lambda d: d["behaviors"]["graphs"][0]["actions"][0].update(ability="x"),
                    lambda d: d["behaviors"]["graphs"][0]["actions"][0].update(effectId="zzz"), lambda d: d.update(sounds="x")):
            d = copy.deepcopy(base); mut(d); cases.append(d)
        for d in cases:
            self.assertIsNotNone(validate_creature.check(d)[0])
        body = "const L=JSON.parse(require('fs').readFileSync(process.argv[2],'utf8'));const bad=L.filter(d=>check(d)===null).length;if(bad)throw Error(bad+' documents invalides acceptés par le JS');"
        with tempfile.TemporaryDirectory() as t:
            f = Path(t) / "cases.json"; f.write_text(json.dumps(cases), encoding="utf-8")
            self.node(body, str(f))

    def test_simulator_hippo3_grenade(self):
        self.assertIn("ok", self.node(SIM, str(ROOT / "examples" / "hibou_hippo3.creature.json")))

    def test_simulator_every_ability(self):
        self.assertIn("ok", self.node(SIM2))


if __name__ == "__main__":
    unittest.main()
