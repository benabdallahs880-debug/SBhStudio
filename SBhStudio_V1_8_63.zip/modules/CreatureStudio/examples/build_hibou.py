"""Construit le Chef et les soldats HIPPO I / II / III (voir examples/hibou_kit.py).

Lancer depuis la racine du module : python examples/build_hibou.py
Produit : examples/hibou_hippo1.creature.json, hibou_hippo2…, hibou_hippo3…, hibou_chef.creature.json
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from hibou_kit import VARIANTS, save  # noqa: E402

for variant in VARIANTS:
    p, out = save(variant)
    print(f"{p.data['creature']['name']:<17} parties : {len(p.data['parts']):>3} | os : {len(p.data['skeleton']['bones']):>2} | matières : {len(p.data['materials']):>2} | "
          f"textures : {len(p.data['textures'])} | règles : {len(p.data['behaviors']['graphs'])} -> {out.name}")
