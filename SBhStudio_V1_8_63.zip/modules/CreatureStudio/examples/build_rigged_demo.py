"""Démo Étape 4 : un petit quadrupède avec pivots (hanches, épaules, cou) et squelette complet.

Lancer depuis la racine du module : python examples/build_rigged_demo.py
Produit : examples/demo_rigged_quadruped.creature.json
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
from creature_model import CreatureProject  # noqa: E402

p = CreatureProject.new("Quadrupède", root_name="Corps", root_shape="capsule")
p.set_transform(p.root_id, rotation=[0, 0, 90], scale=[0.8, 1, 0.8])      # capsule couchée
tete = p.add_part("Tête", "cube", position=[1.4, 0.4, 0], scale=[0.7, 0.7, 0.7])
p.pivot_preset(tete, "bottom")                                             # le cou pivote à la base
for nom, x, z in (("Patte avant G", 0.8, 0.4), ("Patte avant D", 0.8, -0.4), ("Patte arrière G", -0.8, 0.4), ("Patte arrière D", -0.8, -0.4)):
    patte = p.add_part(nom, "cylinder", position=[x, -0.5, z], scale=[0.3, 1, 0.3])
    p.pivot_preset(patte, "top")                                           # la patte pivote à la hanche
queue = p.add_part("Queue", "cone", position=[-1.6, 0.2, 0], rotation=[0, 0, 90], scale=[0.3, 1, 0.3])
p.pivot_preset(queue, "bottom")
p.auto_rig()
for nom in ("Patte avant G", "Patte avant D", "Patte arrière G", "Patte arrière D"):
    pid = next(x["id"] for x in p.data["parts"] if x["name"] == nom)
    p.set_bone_limits(p.bone_of_part(pid)["id"], {"x": [-45, 45], "y": [0, 0], "z": [0, 0]})
out = ROOT / "examples" / "demo_rigged_quadruped.creature.json"
p.save(out)
print(p.tree_text())
print("os :", len(p.data["skeleton"]["bones"]), "->", out)
