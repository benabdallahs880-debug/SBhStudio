"""Démo Étape 6 : animations écrites à la main avec l'API Python (le générateur d'animations de base est dans l'éditeur).

Part du quadrupède rigué (examples/build_rigged_demo.py) et ajoute :
- une marche de 1 s en boucle (pattes en diagonale, queue qui balance, léger rebond du corps) ;
- une pose nommée « Salut » ;
- une animation « Hochement » (la tête s'incline), sans boucle.

Lancer depuis la racine du module : python examples/build_animation_demo.py
Produit : examples/demo_animated.creature.json
"""
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
from creature_model import CreatureProject  # noqa: E402

p = CreatureProject.load(ROOT / "examples" / "demo_rigged_quadruped.creature.json")
bone = {x["name"]: x["id"] for x in p.data["skeleton"]["bones"]}
phase = {"Patte avant G": 0, "Patte arrière D": 0, "Patte avant D": math.pi, "Patte arrière G": math.pi}  # diagonales synchronisées

walk = p.add_animation("Marche", duration=1.0, loop=True)
for i in range(8):
    a = 2 * math.pi * i / 8
    pose = {bone[n]: {"rotation": [round(30 * math.sin(a + ph), 4), 0, 0]} for n, ph in phase.items()}
    pose[bone["Queue"]] = {"rotation": [0, round(12 * math.sin(a), 4), 0]}
    pose[bone["Corps"]] = {"position": [0, round(0.04 * math.cos(2 * a), 4), 0]}
    p.set_keyframe(walk, i / 8, pose)

p.add_pose("Salut", {bone["Tête"]: {"rotation": [-25, 0, 0]}})
nod = p.add_animation("Hochement", duration=0.8, loop=False)
for t, angle in ((0, 0), (0.2, 25), (0.5, -10), (0.8, 0)):
    p.set_keyframe(nod, t, {bone["Tête"]: {"rotation": [angle, 0, 0]}})

out = ROOT / "examples" / "demo_animated.creature.json"
p.save(out)
leg = bone["Patte avant G"]
print("animations :", [a["name"] for a in p.data["animations"]], "| poses :", [q["name"] for q in p.data["skeleton"]["poses"]])
print("Patte avant G à t=0.125 :", [round(v, 3) for v in p.sample(walk, 0.125)[leg]["rotation"]], "->", out)
