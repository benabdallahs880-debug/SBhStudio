"""Démo Étape 2 : construit une petite créature depuis zéro avec les opérations du modèle.

Lancer depuis la racine du module : python examples/build_demo.py
Produit : examples/demo_dragon.creature.json
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
from creature_model import CreatureProject  # noqa: E402

p = CreatureProject.new("Petit Dragon", root_name="Corps", root_shape="capsule")
tete = p.add_part("Tête", "cube", position=[0, 1.6, 0.4])
corne = p.add_part("Corne gauche", "cone", parent_id=tete, position=[-0.3, 0.6, 0], scale=[0.2, 0.5, 0.2])
corne_d = p.duplicate_part(corne, offset=[0.6, 0, 0])
p.rename_part(corne_d, "Corne droite")
seg = p.add_part("Queue 1", "cylinder", position=[0, -0.3, -1.2], rotation=[90, 0, 0], scale=[0.4, 0.8, 0.4])
seg2 = p.add_part("Queue 2", "cylinder", parent_id=seg, position=[0, 0.8, 0], scale=[0.7, 1, 0.7])
p.add_part("Queue 3", "cone", parent_id=seg2, position=[0, 0.8, 0], scale=[0.7, 1, 0.7])
p.add_socket(tete, "head")
out = ROOT / "examples" / "demo_dragon.creature.json"
p.save(out)
print(p.tree_text())
print("->", out)
