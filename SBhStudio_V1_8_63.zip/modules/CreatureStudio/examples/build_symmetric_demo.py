"""Démo Étape 4 bis : symétrie. Une seule corne et une seule patte sont construites, le miroir fait le reste.

Lancer depuis la racine du module : python examples/build_symmetric_demo.py
Produit : examples/demo_symmetric.creature.json
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
from creature_model import CreatureProject  # noqa: E402

p = CreatureProject.new("Symétrique", root_name="Corps", root_shape="capsule")
tete = p.add_part("Tête", "cube", position=[0, 1.6, 0.3])
corne = p.add_part("Corne gauche", "cone", parent_id=tete, position=[0.35, 0.6, 0], scale=[0.2, 0.5, 0.2], symmetric_axis="x")  # + Corne droite
patte = p.add_part("Patte gauche", "cylinder", position=[0.5, -1.2, 0], scale=[0.3, 1, 0.3])
p.pivot_preset(patte, "top")
p.add_bone(patte, limits={"x": [-45, 45]})
p.mirror_part(patte, "x")                                              # Patte droite, os et limites compris
p.set_transform(patte, rotation=[20, 0, 0], symmetric=True)            # la jumelle suit en miroir
out = ROOT / "examples" / "demo_symmetric.creature.json"
p.save(out)
print(p.tree_text())
print("->", out)
