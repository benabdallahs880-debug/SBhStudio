"""Univers HIBOU : le Chef et les soldats HIPPO I / II / III, construits avec l'API de CreatureStudio.

D'après le visualiseur Three.js « HIBOU — Chef & Soldats » fourni par l'utilisateur (Chef en armure d'apparat avec cape à doublure bordeaux, bannières, sabre, emblème hibou ;
soldats masqués en trois niveaux d'armure : Léger, Renforcé, Lourd), reconstruit en blocs dans CreatureStudio. Différences voulues avec le fichier d'origine :
- les protections, la cape, les bannières et le sabre sont des **enfants** des parties qu'ils habillent : ils **suivent les poses et les animations** ;
- le masque des soldats est réel (face noire, fente des yeux, yeux lumineux) ; le Chef a un visage visible (texture : peau, barbe, sourcils) ;
- aucune dépendance réseau : tout est dans le fichier `.creature.json` (l'emblème et les bannières sont des textures peintes pixel par pixel).

Repère : le personnage regarde vers -z, « gauche » = côté +x, unités = blocs. Tailles par les paramètres des formes (jamais l'échelle d'un parent).
`build(variant)` retourne un CreatureProject ; variantes : "hippo1", "hippo2", "hippo3", "chef".
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from creature_model import CreatureProject  # noqa: E402
from motion_kit import add_motion, add_rules  # noqa: E402

VARIANTS = {
    # K = corpulence ; sh = taille des épaulières ; vest = épaisseur du gilet ; legs = protection des jambes (valeurs du visualiseur d'origine)
    "hippo1": dict(name="Soldat HIPPO I", label="Léger", K=1.00, sh=0.75, vest=0.50, legs=0.30, molle=False, pouches=2, skirt=False, heavy=False,
                   stats=dict(health=24, damage=4, armor=3, speed=0.55, jumpHeight=1, detectionRange=18, intelligence=0.5)),
    "hippo2": dict(name="Soldat HIPPO II", label="Renforcé", K=1.05, sh=0.95, vest=0.72, legs=0.60, molle=True, pouches=4, skirt=True, heavy=False,
                   stats=dict(health=36, damage=6, armor=8, speed=0.45, jumpHeight=1, detectionRange=20, intelligence=0.6)),
    "hippo3": dict(name="Soldat HIPPO III", label="Lourd", K=1.10, sh=1.18, vest=1.00, legs=1.00, molle=True, pouches=4, skirt=True, heavy=True,
                   stats=dict(health=56, damage=9, armor=15, speed=0.35, jumpHeight=1, detectionRange=22, intelligence=0.7)),
    "chef": dict(name="Le Chef", label="Chef", K=1.02, stats=dict(health=60, damage=9, armor=14, speed=0.40, jumpHeight=1, detectionRange=24, intelligence=0.9)),
}

# Glyphe de hibou 16×16 (moitié gauche, miroir à droite) : 1 = or clair, 2 = or foncé, 0 = trou, . = transparent
OWL_HALF = ["........", ".11.....", ".111....", ".1111111", ".1100011", ".1102011", ".1100011", ".1111112",
            ".1111122", "..111111", "..212121", "..111111", "..212121", "...11111", "....1111", "........"]
OWL_ROWS = [h + h[::-1] for h in OWL_HALF]


def paint_rows(p, tex, rows, colors, ox=0, oy=0):
    by = {}
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch in colors:
                by.setdefault(colors[ch], []).append((ox + x, oy + y))
    for color, pts in by.items():
        p.paint(tex, pts, color)


def build(variant):
    cfg = VARIANTS[variant]
    chief = variant == "chef"
    K = cfg["K"]

    def w(v):          # largeurs et profondeurs suivent la corpulence ; les hauteurs ne changent pas
        return round(v * K, 4)

    p = CreatureProject.new(cfg["name"], root_name="Bassin", root_shape="cube")

    # ---------------------------------------------------------------- matières
    M = {k: p.add_material(n, c, roughness=r, **kw) for k, (n, c, r, kw) in {
        "tissu": ("Tissu noir", "#141416", 0.95, {}), "tissu2": ("Tissu sombre", "#0e0e11", 0.92, {}),
        "acier": ("Acier sombre", "#3a342e", 0.58, {}), "acier_c": ("Acier clair", "#4a423a", 0.5, {}), "acier_s": ("Acier noirci", "#2e2a24", 0.62, {}),
        "or": ("Or", "#a08040", 0.35, {}), "cuir": ("Cuir", "#1c1410", 0.72, {}), "cuir2": ("Cuir clair", "#241a14", 0.68, {}),
        "gant": ("Gant", "#0d0d11", 0.82, {}), "botte": ("Botte", "#0a0a0d", 0.72, {}), "noir": ("Plastique noir", "#0a0a0e", 0.4, {}),
        "bordeaux": ("Bordeaux", "#4a1018", 0.92, {}), "lame": ("Acier de la lame", "#8c8f94", 0.3, {}),
        "yeux": ("Lueur des yeux", "#f0c870", 0.1, {"emissive": 1.0}),
    }.items()}

    owl = p.add_texture("Hibou", 16, 16)                       # emblème : or sur plaque sombre
    paint_rows(p, owl, OWL_ROWS, {"1": "#d9c89a", "2": "#a08040"})
    M["emb"] = p.add_material("Emblème hibou", "#26231f", roughness=0.4, texture_id=owl)

    if chief:
        face = p.add_texture("Visage du Chef", 48, 32)          # 3×2 cases de 16×16 ; case 0 = face avant (-z)
        PEAU, OMBRE, BARBE, OEIL, BOUCHE = "#c09070", "#a8785a", "#1a1512", "#2a2018", "#6b3a30"
        for c in range(6):
            ox, oy = 16 * (c % 3), 16 * (c // 3)
            if c == 0:
                rows = [["s"] * 16 for _ in range(16)]
                for x in (3, 4, 5, 6, 9, 10, 11, 12):
                    rows[4][x] = "b"                            # sourcils
                for x in (4, 5, 10, 11):
                    rows[6][x] = "e"                            # yeux
                for y in range(6, 10):
                    rows[y][7] = rows[y][8] = "n"               # nez
                for y in range(9, 16):                          # barbe
                    for x in range(16):
                        if y >= 10 or x < 4 or x > 11:
                            rows[y][x] = "b"
                for x in (6, 7, 8, 9):
                    rows[11][x] = "m"                           # bouche
                rows = ["".join(r) for r in rows]
            elif c in (2, 3):
                rows = ["s" * 16] * 9 + ["b" * 16] * 7          # côtés : peau puis barbe
            else:
                rows = ["b" * 16] * 16                          # dos, dessus, dessous : cheveux et barbe
            paint_rows(p, face, rows, {"s": PEAU, "n": OMBRE, "b": BARBE, "e": OEIL, "m": BOUCHE}, ox, oy)
        M["visage"] = p.add_material("Visage du Chef", PEAU, roughness=0.62, texture_id=face)

        banner = p.add_texture("Bannière", 24, 48)              # bordeaux (couleur de la matière), bordure et deux hiboux dorés
        border = [(x, y) for x in range(24) for y in range(48) if x in (0, 23) or y in (0, 47)]
        inner = [(x, y) for x in range(24) for y in range(48) if (x in (2, 21) and 2 <= y <= 45) or (y in (2, 45) and 2 <= x <= 21)]
        p.paint(banner, border, "#a08040")
        p.paint(banner, inner, "#6b5428")
        for oy in (5, 27):
            paint_rows(p, banner, OWL_ROWS, {"1": "#b49146", "2": "#8a6c2e"}, 4, oy)
        M["banniere"] = p.add_material("Bannière bordeaux", "#4a1018", roughness=0.88, texture_id=banner)

    def part(name, shape, parent, pos, mat, params=None, rot=(0, 0, 0), sym=None):
        pid = p.add_part(name, shape, parent_id=parent, position=pos, rotation=rot, parameters=params, symmetric_axis=sym)
        p.assign_material(pid, M[mat], symmetric=bool(sym))
        return pid

    def limb(name, shape, parent, joint, mat, params, pivot):
        pid = part(name, shape, parent, joint, mat, params)
        p.set_pivot(pid, pivot, keep_in_place=False)
        return pid

    def emblem(parent, pos, size, where):          # plaque à l'emblème, tournée vers l'avant (-z)
        return part(f"Emblème {where}", "plane", parent, pos, "emb", {"size": [size, size]}, rot=(-90, 0, 0))

    # ---------------------------------------------------------------- tronc
    bassin = p.root_id
    p.set_shape(bassin, "cube", {"size": [w(0.44), 0.22, w(0.28)]})
    p.assign_material(bassin, M["tissu"])
    torse = part("Torse", "cube", bassin, [0, 0.20, 0], "tissu", {"size": [w(0.44), 0.22, w(0.27)]})
    poitrine = part("Poitrine", "cube", torse, [0, 0.22, 0], "tissu", {"size": [w(0.62), 0.30, w(0.33)]})
    part("Ceinture", "cube", torse, [0, -0.09, 0], "cuir", {"size": [w(0.46), 0.06, w(0.285)]})
    cou = part("Cou", "cylinder", poitrine, [0, 0.20, 0], "tissu2" if not chief else "cuir2", {"radius": 0.085, "height": 0.12})
    tete = limb("Tête", "cube", cou, [0, 0.06, 0], "visage" if chief else "tissu2", {"size": [0.34, 0.34, 0.34]}, [0, -0.17, 0])

    # ---------------------------------------------------------------- tête : turban (les deux), masque (soldats) ou visage (Chef)
    part("Turban", "cube", tete, [0, 0.15, 0.02], "tissu", {"size": [0.41, 0.17, 0.41]})
    for i in range(3 if chief else 2):
        part(f"Pli de turban {i + 1}", "cube", tete, [0, 0.10 + 0.045 * i, 0.02], "tissu", {"size": [0.42 - 0.01 * i, 0.035, 0.42 - 0.01 * i]},
             rot=(0, 7 if i % 2 == 0 else -7, 0))
    part("Pan de turban", "cube", tete, [0, -0.12, 0.205], "tissu", {"size": [0.30, 0.34, 0.05]}, rot=(-8, 0, 0))
    if chief:
        part("Bandeau doré", "cube", tete, [0, 0.07, 0.0], "or", {"size": [0.378, 0.028, 0.378]})
        emblem(tete, [0, 0.13, -0.191], 0.06, "du front")
    else:
        part("Voile", "cube", tete, [0, -0.10, -0.005], "tissu2", {"size": [0.355, 0.15, 0.355]})
        part("Fente des yeux", "cube", tete, [0, 0.02, -0.172], "noir", {"size": [0.30, 0.075, 0.02]})
        part("Œil gauche", "cube", tete, [0.075, 0.02, -0.185], "yeux", {"size": [0.06, 0.032, 0.02]}, sym="x")

    # ---------------------------------------------------------------- équipement du torse
    if chief:
        part("Plastron", "cube", poitrine, [0, 0.0, -0.005], "acier", {"size": [w(0.66), 0.33, w(0.35)]})
        part("Dossière", "cube", poitrine, [0, 0.0, 0.19], "acier", {"size": [w(0.64), 0.32, 0.04]})
        emblem(poitrine, [0, 0.03, -w(0.35) / 2 - 0.004], 0.14, "de la poitrine")
        part("Sangle gauche", "cube", poitrine, [0.07, 0.0, -w(0.35) / 2 - 0.012], "cuir", {"size": [0.035, 0.40, 0.012]}, rot=(0, 0, -32), sym="x")
        part("Gorgerin", "cylinder", poitrine, [0, 0.185, 0], "acier_c", {"radius": 0.125, "height": 0.06})
        part("Liseré du gorgerin", "cylinder", poitrine, [0, 0.21, 0], "or", {"radius": 0.13, "height": 0.012})
        part("Boucle dorée", "cube", torse, [0, -0.09, -w(0.135) - 0.016], "or", {"size": [0.07, 0.06, 0.02]})
        emblem(torse, [0, -0.09, -w(0.135) - 0.0275], 0.045, "de la ceinture")
        for i, (nom, mat, dy, sx) in enumerate((("Épaulière", "acier", 0.0, 0.20), ("Épaulière moyenne", "acier_c", 0.045, 0.22), ("Épaulière haute", "acier_s", 0.085, 0.24))):
            part(f"{nom} gauche", "cube", poitrine, [w(0.38), 0.15 + dy, 0], mat, {"size": [sx, 0.07 if i == 0 else 0.045, sx + 0.05]}, sym="x")
        part("Liseré d'épaulière gauche", "cube", poitrine, [w(0.38), 0.265, 0], "or", {"size": [0.25, 0.012, 0.30]}, sym="x")
        part("Agrafe gauche", "sphere", poitrine, [w(0.15), 0.17, 0.19], "or", {"radius": 0.03}, sym="x")
        part("Tablier avant", "cube", bassin, [0, -0.20, -w(0.15)], "acier_s", {"size": [w(0.34), 0.24, 0.03]})
        part("Tablier arrière", "cube", bassin, [0, -0.20, w(0.15)], "acier_s", {"size": [w(0.34), 0.24, 0.03]})
        part("Liseré du tablier", "cube", bassin, [0, -0.325, -w(0.15)], "or", {"size": [w(0.34), 0.012, 0.034]})
        # cape (noire dehors, bordeaux dedans) suspendue aux épaules : un os la fait balancer ; bannières dorées dans le dos
        cape = limb("Cape", "cube", poitrine, [0, 0.14, 0.215], "tissu", {"size": [w(0.52), 0.95, 0.03]}, [0, 0.475, 0])
        part("Doublure de cape", "cube", cape, [0, 0, -0.02], "bordeaux", {"size": [w(0.50), 0.92, 0.012]})
        part("Bannière gauche", "plane", poitrine, [w(0.09), -0.305, 0.27], "banniere", {"size": [0.11, 0.85]}, rot=(90, 0, 180), sym="x")
    else:
        pw, ph, pd = round(0.28 + 0.10 * cfg["vest"], 3), round(0.16 + 0.10 * cfg["vest"], 3), round(0.03 + 0.05 * cfg["vest"], 3)
        part("Plaque", "cube", poitrine, [0, 0.02, -(w(0.165) + pd / 2 - 0.005)], "acier_s", {"size": [w(pw), ph, pd]})
        emblem(poitrine, [0, 0.025, -(w(0.165) + pd + 0.002)], 0.07, "du plastron")
        part("Dossière", "cube", poitrine, [0, 0.0, w(0.165) + 0.02], "tissu2", {"size": [w(0.56), 0.28, 0.04]})
        part("Bretelle gauche", "cube", poitrine, [0.10, 0.0, -w(0.165) - 0.004], "cuir", {"size": [0.03, 0.34, 0.012]}, rot=(0, 0, -14), sym="x")
        if cfg["molle"]:
            for r in range(2):
                for c in (-1, 0, 1):
                    part(f"Sangle MOLLE {r * 3 + c + 2}", "cube", torse, [c * 0.10, 0.03 - 0.06 * r, -w(0.135) - 0.005], "tissu", {"size": [0.045, 0.05, 0.012]})
        xs = [0.10] if cfg["pouches"] == 2 else [0.07, 0.13]
        for n, x in enumerate(xs, 1):
            part(f"Poche de ceinture {n} gauche", "cube", torse, [w(x), -0.07, -w(0.135) - 0.02], "cuir2", {"size": [0.045, 0.07, 0.04]}, sym="x")
        part("Épaulière gauche", "cube", poitrine, [w(0.38), 0.15, 0], "acier", {"size": [round(0.18 * cfg["sh"], 3), 0.07, round(0.24 * cfg["sh"], 3)]}, sym="x")
        if cfg["heavy"]:
            part("Épaulière haute gauche", "cube", poitrine, [w(0.38), 0.20, 0], "acier_c", {"size": [round(0.20 * cfg["sh"], 3), 0.05, round(0.26 * cfg["sh"], 3)]}, sym="x")
            part("Gorgerin", "cylinder", poitrine, [0, 0.185, 0], "acier_c", {"radius": 0.125, "height": 0.06})
        if cfg["skirt"]:
            part("Tablier avant", "cube", bassin, [0, -0.19, -w(0.15)], "tissu", {"size": [w(0.34), 0.22, 0.03]})
            part("Tablier arrière", "cube", bassin, [0, -0.19, w(0.15)], "tissu", {"size": [w(0.34), 0.22, 0.03]})

    # ---------------------------------------------------------------- bras
    bras = limb("Bras gauche", "cylinder", poitrine, [w(0.38), 0.12, 0], "tissu", {"radius": round(0.08 * K, 4), "height": 0.30}, [0, 0.15, 0])
    avbras = limb("Avant-bras gauche", "cylinder", bras, [0, -0.15, 0], "tissu", {"radius": round(0.07 * K, 4), "height": 0.27}, [0, 0.135, 0])
    limb("Gant gauche", "cube", avbras, [0, -0.135, 0], "gant", {"size": [0.11, 0.13, 0.10]}, [0, 0.065, 0])
    if chief:
        part("Brassard gauche", "cylinder", avbras, [0, -0.02, 0], "acier", {"radius": round(0.085 * K, 4), "height": 0.20})
        part("Anneau doré gauche", "cylinder", avbras, [0, 0.07, 0], "or", {"radius": round(0.089 * K, 4), "height": 0.015})

    # ---------------------------------------------------------------- jambes
    cuisse = limb("Jambe haute gauche", "cylinder", bassin, [w(0.12), -0.09, 0], "tissu", {"radius": round(0.105 * K, 4), "height": 0.42}, [0, 0.21, 0])
    tibia = limb("Jambe basse gauche", "cylinder", cuisse, [0, -0.21, 0], "tissu", {"radius": round(0.085 * K, 4), "height": 0.36}, [0, 0.18, 0])
    limb("Botte gauche", "cube", tibia, [0, -0.18, 0], "botte", {"size": [0.17, 0.11, 0.30]}, [0, 0.05, 0.06])
    guards = chief or cfg["legs"] > 0.25
    if guards:
        part("Genouillère gauche", "cube", cuisse, [0, -0.19, -0.11], "acier", {"size": [0.13, 0.12, 0.07]})
        longueur = 0.30 if chief else round(0.36 * 0.75 * (0.6 + 0.4 * cfg["legs"]), 3)
        part("Jambière gauche", "cube", tibia, [0, -0.02, -0.095], "acier", {"size": [0.11, longueur, 0.04]})
        if chief:
            part("Liseré de genouillère gauche", "cube", cuisse, [0, -0.125, -0.11], "or", {"size": [0.135, 0.012, 0.075]})

    # ---------------------------------------------------------------- squelette et limites, avant le miroir
    LIMITES = {
        "Bassin": None, "Torse": {"x": [-20, 30], "y": [-25, 25], "z": [-15, 15]}, "Poitrine": {"x": [-25, 25], "y": [-35, 35], "z": [-15, 15]},
        "Cou": {"x": [-20, 20], "y": [-30, 30], "z": [-10, 10]}, "Tête": {"x": [-40, 40], "y": [-70, 70], "z": [-25, 25]},
        "Bras gauche": {"x": [-60, 170], "y": [-60, 60], "z": [-20, 110]}, "Avant-bras gauche": {"x": [0, 140], "y": [-30, 30], "z": [0, 0]},
        "Gant gauche": {"x": [-40, 40], "y": [-30, 30], "z": [-25, 25]},
        "Jambe haute gauche": {"x": [-70, 110], "y": [-25, 25], "z": [-10, 40]}, "Jambe basse gauche": {"x": [-140, 0], "y": [0, 0], "z": [0, 0]},
        "Botte gauche": {"x": [-30, 45], "y": [-10, 10], "z": [-10, 10]},
    }
    if chief:
        LIMITES["Cape"] = {"x": [-45, 10], "y": [-20, 20], "z": [-15, 15]}
    by_name = {x["name"]: x["id"] for x in p.data["parts"]}
    for nom, lim in LIMITES.items():
        p.add_bone(by_name[nom], limits=lim)
    for racine in (bras, cuisse):
        p.mirror_part(racine, "x")

    # ---------------------------------------------------------------- sabre du Chef, tenu dans la main droite (suit le bras)
    if chief:
        gant_d = next(x["id"] for x in p.data["parts"] if x["name"] == "Gant droit")
        sabre = part("Sabre", "cylinder", gant_d, [0, 0.0, 0], "cuir", {"radius": 0.012, "height": 0.10}, rot=(-18, 0, -8))
        part("Pommeau", "sphere", sabre, [0, 0.062, 0], "or", {"radius": 0.02})
        part("Garde", "cube", sabre, [0, -0.055, 0], "or", {"size": [0.09, 0.012, 0.022]})
        part("Lame", "cube", sabre, [0, -0.21, 0], "lame", {"size": [0.028, 0.30, 0.008]})
        part("Pointe de lame", "cube", sabre, [0.0174, -0.453, 0], "lame", {"size": [0.026, 0.20, 0.008]}, rot=(0, 0, 10))

    # ---------------------------------------------------------------- mouvement, caractéristiques, comportements
    ids = add_motion(p, cape=chief)
    if chief:
        add_rules(p, ids, cfg["stats"], flee=False, speeds=(1.4, 1.0, 0.4), cooldown=1.0)
    else:
        add_rules(p, ids, cfg["stats"], flee_below=20 if variant != "hippo1" else 30, speeds=(1.4, 1.2 if variant != "hippo3" else 1.0, 0.5))
    used = {x.get("materialId") for x in p.data["parts"]}
    for m in [m for m in p.data["materials"] if m["id"] not in used]:     # pas de matières orphelines (diagnostic D030)
        p.remove_material(m["id"])
    return p


def ids_course(p):
    return next(a["id"] for a in p.data["animations"] if a["name"] == "Course")


def add_specials(p, variant):
    """Étape 8 : sons, effets et capacités de démonstration (identifiants de sons Bedrock à revérifier à l'étape d'export)."""
    def first(rule):   # place la règle en tête de liste (priorité maximale)
        g = p.data["behaviors"]["graphs"][-1]["id"]
        p.move_behavior(g, 0)
        return g
    part = lambda name: next(x["id"] for x in p.data["parts"] if x["name"] == name)
    if variant == "chef":
        cry = p.add_sound("Cri de ralliement", "mob.vindicator.celebrate", 1.0, 0.9)
        aura = p.add_effect("Aura dorée", "magic", "#d4a017", 40, part("Torse"))
        spark = p.add_effect("Étincelles de lame", "spark", "#ffe14a", 25, part("Sabre"))
        pid = next(g["id"] for g in p.data["behaviors"]["graphs"] if g["name"] == "Poursuivre le joueur")
        p.add_action(pid, {"type": "playSound", "soundId": cry})
        aid = next(g["id"] for g in p.data["behaviors"]["graphs"] if g["name"] == "Attaquer au contact")
        p.add_action(aid, {"type": "effect", "effectId": spark})
        run = {"type": "chase", "speed": 1.0, "animationId": ids_course(p)}   # la règle garde le mouvement : une capacité en recharge ne fige pas le personnage
        p.add_behavior("Se soigner", [{"type": "healthBelow", "percent": 60}],
                       [{"type": "ability", "ability": "heal", "power": 5, "cooldown": 25, "effectId": aura}, dict(run)])
        first("")
        p.add_behavior("Bouclier du Chef", [{"type": "healthBelow", "percent": 40}],
                       [{"type": "ability", "ability": "shield", "duration": 5, "cooldown": 20, "effectId": aura}, dict(run)])
        first("")
    elif variant == "hippo3":
        boom = p.add_effect("Explosion de grenade", "explosion", "#ffb347", 60)
        bang = p.add_sound("Détonation", "random.explode", 1.0, 1.0)
        p.add_behavior("Lancer une grenade", [{"type": "distance", "op": "<", "value": 8}, {"type": "distance", "op": ">", "value": 3}],
                       [{"type": "ability", "ability": "explosion", "power": 3, "range": 8, "cooldown": 10, "effectId": boom, "soundId": bang},
                        {"type": "chase", "speed": 1.2, "animationId": ids_course(p)}])
        first("")


def save(variant, out=None):
    p = build(variant)
    add_specials(p, variant)
    out = Path(out) if out else ROOT / "examples" / f"hibou_{variant}.creature.json"
    p.save(out)
    return p, out
