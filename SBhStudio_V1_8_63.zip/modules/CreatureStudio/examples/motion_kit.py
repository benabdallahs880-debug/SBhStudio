"""Animations, poses et règles communes aux personnages (soldat standard, soldats HIPPO, Chef).

`add_motion(p, cape=False)` ajoute les animations (Repos, Marche, Course, Attaque, Dégâts, Mort) et les poses (Bras tendu, Garde) à un humanoïde
dont les os portent les noms : Bassin, Torse, Poitrine, Tête, Bras / Avant-bras / Gant (gauche et droit), Jambe haute / Jambe basse / Botte (gauche et droite),
et « Cape » si `cape=True` (la cape balance et se soulève avec le mouvement). Retourne {nom_d_animation: id}.
Angles en degrés ; +x sur un membre qui pend = vers l'avant (le personnage regarde vers -z).
"""
import math


def r4(v):
    return [round(x, 4) for x in v]


def cote(base, i):
    """Nom de l'os pour le côté i (0 = gauche, 1 = droit), avec l'accord masculin/féminin."""
    masc = base in ("Bras", "Avant-bras", "Gant")
    return f"{base} gauche" if i == 0 else f"{base} {'droit' if masc else 'droite'}"


def add_motion(p, cape=False):
    bone = {b["name"]: b["id"] for b in p.data["skeleton"]["bones"]}

    def with_cape(pose, angle):
        if cape:
            pose[bone["Cape"]] = {"rotation": r4([angle, 0, 0])}
        return pose

    def marche(nom, duree, jambe, genou, bras_amp, coude, rebond, penche, torsion, vol_cape):
        a = p.add_animation(nom, duree, loop=True)
        for i in range(8):
            t = 2 * math.pi * i / 8
            pose = {bone["Bassin"]: {"rotation": r4([0, 0.8 * torsion * math.sin(t), 0]), "position": r4([0, rebond * math.cos(2 * t), 0])},
                    bone["Poitrine"]: {"rotation": r4([-penche, -torsion * math.sin(t), 0])},
                    bone["Tête"]: {"rotation": r4([penche * 0.6 + 2 * math.sin(2 * t), 0, 0])}}
            for side in (0, 1):
                ph = t + side * math.pi
                pose[bone[cote("Jambe haute", side)]] = {"rotation": r4([jambe * math.sin(ph), 0, 0])}
                pose[bone[cote("Jambe basse", side)]] = {"rotation": r4([-(genou * 0.5 + genou * 0.5 * math.sin(ph - 1.0)), 0, 0])}
                pose[bone[cote("Botte", side)]] = {"rotation": r4([0.25 * jambe * math.sin(ph), 0, 0])}
                pose[bone[cote("Bras", side)]] = {"rotation": r4([-bras_amp * math.sin(ph), 0, 0])}
                pose[bone[cote("Avant-bras", side)]] = {"rotation": r4([coude - 0.3 * coude * math.sin(ph), 0, 0])}
            p.set_keyframe(a, duree * i / 8, with_cape(pose, -(vol_cape + 0.35 * vol_cape * math.sin(2 * t))))
        return a

    ids = {}
    repos = ids["Repos"] = p.add_animation("Repos", 3.0, loop=True)
    for i in range(6):
        t = 2 * math.pi * i / 6
        pose = {bone["Poitrine"]: {"rotation": r4([1.5 * math.sin(t), 0, 0])}, bone["Bassin"]: {"position": r4([0, 0.008 * math.sin(t), 0])},
                bone["Tête"]: {"rotation": r4([1.5 * math.sin(t - 0.8), 0, 0])}}
        for side in (0, 1):
            pose[bone[cote("Bras", side)]] = {"rotation": r4([3 * math.sin(t + side * math.pi), 0, 0])}
            pose[bone[cote("Avant-bras", side)]] = {"rotation": r4([14 + 3 * math.sin(t), 0, 0])}
        p.set_keyframe(repos, 3.0 * i / 6, with_cape(pose, -(3 + 1.5 * math.sin(t))))

    ids["Marche"] = marche("Marche", 1.0, 28, 36, 24, 22, 0.03, 0, 5, 10)
    ids["Course"] = marche("Course", 0.6, 50, 70, 55, 70, 0.06, 6, 8, 28)

    attaque = ids["Attaque"] = p.add_animation("Attaque", 0.7, loop=False)       # coup de poing du bras droit
    for t, bd, ad, tw in ((0, 0, 0, 0), (0.2, -40, 100, 20), (0.35, 85, 8, -25), (0.7, 0, 0, 0)):
        pose = {bone["Bras droit"]: {"rotation": r4([bd, 0, 0])}, bone["Avant-bras droit"]: {"rotation": r4([ad, 0, 0])},
                bone["Poitrine"]: {"rotation": r4([0, tw, 0])}, bone["Bassin"]: {"rotation": r4([0, tw * 0.5, 0])}}
        p.set_keyframe(attaque, t, with_cape(pose, -abs(tw) * 0.6))

    degats = ids["Dégâts"] = p.add_animation("Dégâts", 0.4, loop=False)
    for t, ax, tx in ((0, 0, 0), (0.1, 12, 18), (0.2, -5, -6), (0.4, 0, 0)):
        p.set_keyframe(degats, t, with_cape({bone["Poitrine"]: {"rotation": r4([ax, 0, 0])}, bone["Tête"]: {"rotation": r4([tx, 0, 0])}}, -ax))

    mort = ids["Mort"] = p.add_animation("Mort", 1.4, loop=False)              # tombe en arrière
    for t, rx, y, knee in ((0, 0, 0, 0), (0.5, 25, -0.15, -40), (1.4, 88, -0.62, -20)):
        pose = {bone["Bassin"]: {"rotation": r4([rx, 0, 0]), "position": r4([0, y, 0])}}
        for side in (0, 1):
            pose[bone[cote("Jambe basse", side)]] = {"rotation": r4([knee, 0, 0])}
        p.set_keyframe(mort, t, pose)

    # poses nommées : « Bras tendu » (le bras droit écarté) et « Garde »
    p.add_pose("Bras tendu", {bone["Bras droit"]: {"rotation": [0, 0, -80]}, bone["Avant-bras droit"]: {"rotation": [10, 0, 0]}})
    p.add_pose("Garde", {bone["Bras gauche"]: {"rotation": [30, 0, 0]}, bone["Bras droit"]: {"rotation": [30, 0, 0]},
                         bone["Avant-bras gauche"]: {"rotation": [95, 0, 0]}, bone["Avant-bras droit"]: {"rotation": [95, 0, 0]}})
    return ids


def add_rules(p, ids, stats, flee_below=20, speeds=(1.4, 1.2, 0.5), cooldown=1.2, flee=True):
    """Caractéristiques et règles (priorité décroissante) : fuir si blessé, attaquer au contact, poursuivre, veiller la nuit, patrouiller."""
    p.set_stats(**stats)
    if flee:
        p.add_behavior("Fuir si blessé", [{"type": "healthBelow", "percent": flee_below}], [{"type": "flee", "speed": speeds[0], "animationId": ids["Course"]}])
    p.add_behavior("Attaquer au contact", [{"type": "distance", "op": "<", "value": 2}], [{"type": "attack", "cooldown": cooldown, "animationId": ids["Attaque"]}])
    p.add_behavior("Poursuivre le joueur", [{"type": "playerDetected"}], [{"type": "chase", "speed": speeds[1], "animationId": ids["Course"]}])
    p.add_behavior("Veiller la nuit", [{"type": "time", "is": "night"}], [{"type": "idle", "animationId": ids["Repos"]}])
    p.add_behavior("Patrouiller", [], [{"type": "wander", "speed": speeds[2], "animationId": ids["Marche"]}])
