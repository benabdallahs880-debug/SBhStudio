"""Personnage « Soldat standard » : un soldat stylisé en keffieh et gilet tactique, entièrement construit avec l'API de CreatureStudio.

Ce que le script exploite : symétrie (un seul côté construit, le miroir fait l'autre), pivots (épaules, coudes, hanches, genoux, cou),
squelette avec limites d'articulation, matières et une texture peinte (keffieh noir et blanc), poses, animations (Repos, Marche, Course,
Attaque, Dégâts, Mort), caractéristiques et comportements.

Repère : le personnage regarde vers -z (face à la caméra de l'éditeur) ; « gauche » = côté +x ; unités = blocs, ~1,97 bloc de haut.
Les tailles sont données par les paramètres des formes (jamais par l'échelle d'un parent, qui déformerait ses enfants).

Lancer depuis la racine du module : python examples/build_soldier.py
Produit : examples/soldat_standard.creature.json
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from creature_model import CreatureProject  # noqa: E402

p = CreatureProject.new("Soldat standard", root_name="Bassin", root_shape="cube")

# ------------------------------------------------------------------ matières
M = {
    "tissu": p.add_material("Treillis olive", "#566044", roughness=0.9),
    "pantalon": p.add_material("Pantalon kaki", "#4b4e3a", roughness=0.9),
    "gilet": p.add_material("Gilet tactique", "#25282d", roughness=0.6),
    "cuir": p.add_material("Cuir noir", "#17171a", roughness=0.5),
    "rouge": p.add_material("Écharpe rouge", "#b3202a", roughness=0.8),
    "noir": p.add_material("Plastique noir", "#0e0e10", roughness=0.4),
    "yeux": p.add_material("Lueur des yeux", "#dff7ff", emissive=1.0, roughness=0.1),
    "sac": p.add_material("Toile du sac", "#3b4333", roughness=0.95),
    "peau": p.add_material("Peau", "#a8744f", roughness=0.7),
}

# Texture du keffieh : 48×32 = 3×2 cases de 16×16 (voir core/format.md §10). Case 0 = face avant (-z) : rayures horizontales
# noires et blanches avec une bande sombre à hauteur des yeux ; cases 1 à 4 : damier fin (pied-de-poule) ; case 5 (dessous) : noir.
BLANC, NOIR = "#f2f2f2", "#101010"
tex = p.add_texture("Keffieh", 48, 32)
cases = {c: (16 * (c % 3), 16 * (c // 3)) for c in range(6)}
blanc, noir = [], []
for c, (ox, oy) in cases.items():
    for y in range(16):
        for x in range(16):
            if c == 0:
                black = (y // 2) % 2 == 0 or 6 <= y <= 8
            elif c == 5:
                black = True
            elif c == 4:
                black = (x // 3 + y // 3) % 2 == 0
            else:
                black = (x // 2 + y // 2) % 2 == 0
            (noir if black else blanc).append((ox + x, oy + y))
p.paint(tex, blanc, BLANC)
p.paint(tex, noir, NOIR)
M["keffieh"] = p.add_material("Keffieh", "#e9e9e9", roughness=0.85, texture_id=tex)


def part(name, shape, parent, pos, mat, params=None, rot=(0, 0, 0), sym=None):
    pid = p.add_part(name, shape, parent_id=parent, position=pos, rotation=rot, parameters=params, symmetric_axis=sym)
    p.assign_material(pid, M[mat], symmetric=bool(sym))
    return pid


def limb(name, shape, parent, joint, mat, params, pivot):
    """Partie suspendue à une articulation : `position` = le point d'articulation, la forme pend sous le pivot."""
    pid = part(name, shape, parent, joint, mat, params)
    p.set_pivot(pid, pivot, keep_in_place=False)
    return pid


# ------------------------------------------------------------------ tronc et tête
bassin = p.root_id
p.set_shape(bassin, "cube", {"size": [0.44, 0.22, 0.28]})
p.assign_material(bassin, M["pantalon"])
torse = part("Torse", "cube", bassin, [0, 0.20, 0], "tissu", {"size": [0.44, 0.22, 0.27]})
poitrine = part("Poitrine", "cube", torse, [0, 0.22, 0], "tissu", {"size": [0.62, 0.30, 0.33]})
part("Ceinture", "cube", torse, [0, -0.09, 0], "cuir", {"size": [0.46, 0.06, 0.285]})
cou = part("Cou", "cylinder", poitrine, [0, 0.20, 0], "peau", {"radius": 0.085, "height": 0.12})
tete = limb("Tête", "cube", cou, [0, 0.06, 0], "keffieh", {"size": [0.34, 0.34, 0.34]}, [0, -0.17, 0])   # pivote au sommet du cou

# Keffieh : turban, voile sur le bas du visage, pan qui retombe dans le dos, bandeau noir (agal), fente des yeux et yeux lumineux
part("Turban", "cube", tete, [0, 0.15, 0.02], "keffieh", {"size": [0.41, 0.17, 0.41]})
part("Voile", "cube", tete, [0, -0.10, -0.005], "keffieh", {"size": [0.355, 0.15, 0.355]})
part("Pan de keffieh", "cube", tete, [0, -0.12, 0.205], "keffieh", {"size": [0.30, 0.34, 0.05]}, rot=(-8, 0, 0))
part("Bandeau", "cube", tete, [0, 0.075, 0], "noir", {"size": [0.375, 0.05, 0.375]})
part("Fente des yeux", "cube", tete, [0, 0.02, -0.172], "noir", {"size": [0.30, 0.075, 0.02]})
part("Œil gauche", "cube", tete, [0.075, 0.02, -0.185], "yeux", {"size": [0.06, 0.032, 0.02]}, sym="x")

# Écharpe rouge et gilet tactique (plaque, poches, épaulières), sac à dos et antenne
part("Écharpe", "cylinder", poitrine, [0, 0.17, -0.005], "rouge", {"radius": 0.15, "height": 0.10})
part("Pan d'écharpe", "cube", poitrine, [0.10, -0.01, -0.19], "rouge", {"size": [0.11, 0.30, 0.035]}, rot=(0, 0, 6))
part("Plaque", "cube", poitrine, [0, 0.0, -0.19], "gilet", {"size": [0.34, 0.22, 0.06]})
part("Poche gauche", "cube", poitrine, [0.20, -0.08, -0.19], "gilet", {"size": [0.13, 0.12, 0.07]}, sym="x")
part("Épaulière gauche", "cube", poitrine, [0.38, 0.15, 0], "gilet", {"size": [0.18, 0.07, 0.24]}, sym="x")
part("Sac à dos", "cube", poitrine, [0, 0.0, 0.245], "sac", {"size": [0.44, 0.42, 0.16]})
part("Antenne", "cylinder", poitrine, [0.17, 0.33, 0.26], "noir", {"radius": 0.012, "height": 0.35})

# ------------------------------------------------------------------ bras et jambes (côté gauche, puis miroir)
bras = limb("Bras gauche", "cylinder", poitrine, [0.38, 0.12, 0], "tissu", {"radius": 0.08, "height": 0.30}, [0, 0.15, 0])
avbras = limb("Avant-bras gauche", "cylinder", bras, [0, -0.15, 0], "tissu", {"radius": 0.07, "height": 0.27}, [0, 0.135, 0])
gant = limb("Gant gauche", "cube", avbras, [0, -0.135, 0], "cuir", {"size": [0.11, 0.13, 0.10]}, [0, 0.065, 0])

cuisse = limb("Jambe haute gauche", "cylinder", bassin, [0.12, -0.09, 0], "pantalon", {"radius": 0.105, "height": 0.42}, [0, 0.21, 0])
part("Poche cargo gauche", "cube", cuisse, [0.115, -0.05, 0], "pantalon", {"size": [0.05, 0.14, 0.13]})
part("Genouillère gauche", "cube", cuisse, [0, -0.19, -0.11], "cuir", {"size": [0.13, 0.12, 0.07]})
tibia = limb("Jambe basse gauche", "cylinder", cuisse, [0, -0.21, 0], "pantalon", {"radius": 0.085, "height": 0.36}, [0, 0.18, 0])
botte = limb("Botte gauche", "cube", tibia, [0, -0.18, 0], "cuir", {"size": [0.17, 0.11, 0.30]}, [0, 0.05, 0.06])   # pivote à la cheville

# ------------------------------------------------------------------ squelette (os des parties qui bougent) et limites, avant le miroir
LIMITES = {
    "Bassin": None,
    "Torse": {"x": [-20, 30], "y": [-25, 25], "z": [-15, 15]},
    "Poitrine": {"x": [-25, 25], "y": [-35, 35], "z": [-15, 15]},
    "Cou": {"x": [-20, 20], "y": [-30, 30], "z": [-10, 10]},
    "Tête": {"x": [-40, 40], "y": [-70, 70], "z": [-25, 25]},
    "Bras gauche": {"x": [-60, 170], "y": [-60, 60], "z": [-20, 110]},
    "Avant-bras gauche": {"x": [0, 140], "y": [-30, 30], "z": [0, 0]},
    "Gant gauche": {"x": [-40, 40], "y": [-30, 30], "z": [-25, 25]},
    "Jambe haute gauche": {"x": [-70, 110], "y": [-25, 25], "z": [-10, 40]},
    "Jambe basse gauche": {"x": [-140, 0], "y": [0, 0], "z": [0, 0]},
    "Botte gauche": {"x": [-30, 45], "y": [-10, 10], "z": [-10, 10]},
}
by_name = {x["name"]: x["id"] for x in p.data["parts"]}
for nom, lim in LIMITES.items():
    p.add_bone(by_name[nom], limits=lim)

# miroir : le côté droit (noms accordés « droit »/« droite », os, limites et matières copiés en miroir)
for racine in (bras, cuisse):
    p.mirror_part(racine, "x")

# ------------------------------------------------------------------ animations, poses, caractéristiques et comportements (communs : examples/motion_kit.py)
from motion_kit import add_motion, add_rules  # noqa: E402

ids = add_motion(p)
add_rules(p, ids, dict(health=30, damage=5, armor=6, speed=0.45, jumpHeight=1, detectionRange=20, intelligence=0.7))

out = ROOT / "examples" / "soldat_standard.creature.json"
p.save(out)
print(p.tree_text())
print(f"parties : {len(p.data['parts'])} | os : {len(p.data['skeleton']['bones'])} | matières : {len(p.data['materials'])} | "
      f"animations : {[a['name'] for a in p.data['animations']]} | règles : {len(p.data['behaviors']['graphs'])} -> {out}")
