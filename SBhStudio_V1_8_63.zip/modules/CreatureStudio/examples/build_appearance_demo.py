"""Démo Étape 5 : matières (couleur, opacité, lueur), texture peinte et matière partagée par symétrie.

Lancer depuis la racine du module : python examples/build_appearance_demo.py
Produit : examples/demo_appearance.creature.json
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core"))
from creature_model import CreatureProject  # noqa: E402

p = CreatureProject.new("Monstre", root_name="Corps", root_shape="capsule")
peau = p.add_material("Peau", "#3d8b4f", roughness=0.9)
p.assign_material(p.root_id, peau)

# Tête : cube avec une texture 12×8 = 3×2 cases de 4×4 texels (voir core/format.md §10). La case 1 (x 4..7, y 0..3) est la face « +z ».
tete = p.add_part("Tête", "cube", position=[0, 1.6, 0.3])
visage = p.add_texture("Visage", 12, 8)
p.paint(visage, [(5, 1), (6, 1)], "#ffe066")                       # deux yeux jaunes
p.paint(visage, [(5, 3), (6, 3)], "#5c1a1a")                       # bouche
p.fill(visage, 4, 0, "#2f6b3d")                                    # fond de la case (remplissage)
p.paint(visage, [(5, 1), (6, 1)], "#ffe066")                       # on repeint les yeux par-dessus
p.paint(visage, [(5, 3), (6, 3)], "#5c1a1a")
p.assign_material(tete, p.add_material("Visage", "#3d8b4f", texture_id=visage))

# Cornes : une seule matière, appliquée aux deux cornes grâce à la symétrie
corne = p.add_part("Corne gauche", "cone", parent_id=tete, position=[0.35, 0.6, 0], scale=[0.2, 0.5, 0.2], symmetric_axis="x")
p.assign_material(corne, p.add_material("Os", "#efe6d0", roughness=0.5), symmetric=True)

# Cristal lumineux (lueur maximale) et aile translucide (opacité 50 %)
cristal = p.add_part("Cristal", "sphere", position=[0, 0.2, 0.6], scale=[0.25, 0.25, 0.25])
p.assign_material(cristal, p.add_material("Cristal", "#7df9ff", emissive=1.0, roughness=0.1))
aile = p.add_part("Aile gauche", "plane", position=[1.1, 0.6, 0], rotation=[0, 0, -30], scale=[1.2, 1, 1.4], symmetric_axis="x")
p.assign_material(aile, p.add_material("Membrane", "#b04fd6", opacity=0.5), symmetric=True)

out = ROOT / "examples" / "demo_appearance.creature.json"
p.save(out)
print(p.tree_text())
print("matières :", len(p.data["materials"]), "| textures :", len(p.data["textures"]), "->", out)
