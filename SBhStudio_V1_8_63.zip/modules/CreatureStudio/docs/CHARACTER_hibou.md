# HIBOU — Le Chef et les soldats HIPPO I / II / III

Repris du fichier Three.js « HIBOU — Chef & Soldats » partagé par l'utilisateur, reconstruit dans le format `.creature.json`.

## Fichiers
| Fichier | Rôle |
|---|---|
| `examples/hibou_kit.py` | Définition des 4 variantes (`VARIANTS`), hibou pixel-art 16×16, `build(variant)` |
| `examples/motion_kit.py` | Animations/poses/règles communes (Repos, Marche, Course, Attaque, Dégâts, Mort ; `cape=True` ajoute un os « Cape ») — partagé avec le Soldat standard |
| `examples/build_hibou.py` | Génère `examples/hibou_{hippo1,hippo2,hippo3,chef}.creature.json` |
| `tools/render_lineup.py` | Aperçu PNG de plusieurs créatures côte à côte (`--views=face,34,profil,dos`) |
| `tests/test_hibou.py` | 8 tests |

## Personnages
| | Parties | Os | Textures | Particularités |
|---|---|---|---|---|
| HIPPO I | 39 | 17 | Hibou | masque réel (voile + fente + yeux lumineux), plaque, emblème |
| HIPPO II | 49 | 17 | Hibou | + MOLLE/poches, jupe |
| HIPPO III | 52 | 17 | Hibou | + épaulières lourdes |
| Le Chef | 66 | 18 | Hibou, Visage du Chef, Bannière | armure dorée, cape (os dédié), 2 bannières dorsales, sabre dans le gant droit |

## Défauts de l'original corrigés
- **Protections qui ne suivent pas la pose** : toutes sont enfants des parties qu'elles habillent (genouillère → jambe, gant → avant-bras, épaulière → torse) ; testé.
- **Bouton Masque inactif** : le masque est de la vraie géométrie (Voile, Fente des yeux), pas un interrupteur.
- **Dépendance unpkg** : aucune ; l'éditeur reste un seul fichier HTML autonome.

## Utilisation
Éditeur : menu **🦉 HIBOU…** → Le Chef / HIPPO I / II / III. Regénérer : `python examples/build_hibou.py && python tools/embed_example.py`.
Aperçus : `docs/preview_hibou.png`, `docs/preview_hibou_chef.png`.

## Limites connues
- Rendu vérifié uniquement par le moteur d'aperçu PNG ; pas testé dans un vrai navigateur/téléphone.
- Les soldats sont volontairement très sombres (tenue noire) : peu lisibles sur fond sombre.
- La cape n'a pas de simulation physique : elle bouge par rotation de l'os « Cape » seulement.
- Pas de sons ni d'effets (Étape 8).
