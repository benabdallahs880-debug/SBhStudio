# Personnage « Soldat standard » — fiche de modèle

Fichier : `examples/soldat_standard.creature.json` · script : `examples/build_soldier.py` · aperçu : `docs/preview_soldat_standard.png` (4 vues) ·
dans l'éditeur : bouton **🎖 Soldat** (le projet est intégré à `editor/creature_editor.html` par `tools/embed_example.py`).

**Commande du projet** (demande de l'utilisateur, 2026-10-03) : utiliser l'illustration fournie (soldat masqué en keffieh noir et blanc, écharpe rouge, veste et gilet tactique)
comme référence pour modéliser des personnages 3D, intégrés dans CreatureStudio ; modèle **entier** (tête, bras, jambes) et **plus stylé** que l'illustration.
Choix antérieur de l'utilisateur : blockout dans CreatureStudio (format `.creature.json`), pas d'export Blender/Godot pour l'instant.

## Ce qui vient de l'illustration (et ce qui est stylisé)
| Élément | Illustration | Modèle |
|---|---|---|
| Tête | keffieh noir et blanc, rayures sur le visage, seuls les yeux dégagés | cube texturé : rayures horizontales sur la face avant, pied-de-poule sur les autres faces ; turban, voile, pan dans le dos, bandeau (agal) noir, fente des yeux, **yeux lumineux** (stylisation) |
| Cou | écharpe rouge | écharpe rouge (cylindre) + pan qui retombe sur la poitrine |
| Torse | veste olive sombre, gilet tactique à poches | veste olive, **plaque** centrale, 2 poches, 2 épaulières, ceinture ; silhouette en V (épaules larges, taille étroite) |
| Dos | non visible | **sac à dos** et antenne radio |
| Bras / jambes | bras droit écarté ; jambes non visibles | bras et jambes complets, genouillères, poches cargo, gants et bottes noirs ; pose nommée **Bras tendu** (bras droit écarté, comme sur l'image) |
| Fond | drapeau rouge, vert, noir en coups de pinceau | **non modélisé** (c'est un fond, pas le personnage) |
| Armes | aucune visible | aucune |

## Repère et proportions
Regarde vers **-z** (face à la caméra de l'éditeur) ; « gauche » = côté **+x** ; unités = blocs ; hauteur ≈ **2,05 blocs** (silhouette héroïque : un joueur Minecraft fait ≈ 1,8).
Origine = centre du bassin. Tailles données par les **paramètres** des formes (jamais par l'échelle d'un parent, qui déformerait ses enfants).
Bassin 0,44×0,22×0,28 · torse 0,44×0,22×0,27 · poitrine 0,62×0,30×0,33 · tête 0,34³ · bras (r 0,08, 0,30 + avant-bras r 0,07, 0,27 + gant 0,11×0,13×0,10) ·
cuisse (r 0,105, 0,42) · jambe basse (r 0,085, 0,36) · botte 0,17×0,11×0,30.

## Palette
Treillis `#566044` · pantalon `#4b4e3a` · gilet `#25282d` · cuir `#17171a` · écharpe `#b3202a` · plastique `#0e0e10` · sac `#3b4333` · peau `#a8744f` ·
keffieh `#f2f2f2` / `#101010` (texture 48×32 : 3×2 cases de 16×16) · yeux `#dff7ff` (lueur 1,0).

## Structure (38 parties, 17 os, 10 matières, 1 texture)
Bassin → Torse → Poitrine → (Cou → Tête → keffieh et yeux) · (écharpe, plaque, poches, épaulières, sac, antenne) · Bras → Avant-bras → Gant ; Bassin → Jambe haute → (poche cargo, genouillère) → Jambe basse → Botte.
**Un seul côté est construit, le miroir fait l'autre** (liens `mirror`, noms accordés : « Bras droit », « Genouillère droite »…). Pivots : cou (sommet), épaules, coudes, poignets, hanches, genoux, chevilles.
Os : Bassin, Torse, Poitrine, Cou, Tête, Bras, Avant-bras, Gant, Jambe haute, Jambe basse, Botte (×2 côtés) avec **limites** réalistes (coude et genou ne plient que dans un sens, etc.) ;
toutes les valeurs des animations et poses sont **vérifiées dans ces limites** par les tests.

## Animations, poses, comportements
Animations : **Repos** (3 s, boucle), **Marche** (1 s, boucle, jambes en opposition de phase, genoux, bras opposés, torsion du buste, rebond), **Course** (0,6 s, boucle, amplitudes plus grandes, buste penché),
**Attaque** (coup de poing du bras droit, 0,7 s), **Dégâts** (0,4 s), **Mort** (tombe en arrière, 1,4 s). Poses : **Bras tendu**, **Garde**.
Caractéristiques : vie 30, dégâts 5, armure 6, vitesse 0,45, saut 1, détection 20, intelligence 0,7.
Règles (priorité décroissante) : Fuir si blessé (< 20 %) → Attaquer au contact (< 2 blocs) → Poursuivre le joueur (détecté, anim. Course) → Veiller la nuit (immobile, anim. Repos) → Patrouiller (repli, anim. Marche).
Essai : bouton **▶ Tester** du simulateur (déplacer le joueur bleu, ☀/🌙, 💥 Frapper) ; l'animation de la règle active se joue dans la vue 3D.

## Améliorations possibles / non fait
- Pas d'arme ni d'accessoires (casque, lunettes, grenades) ; pas de capacités (Étape 8) ; pas de sons.
- Style « blocs » (primitives) : pas de sculpture, pas d'épaules arrondies ; les cylindres ont 10 côtés.
- Les UV du cube sont une grille 3×2 (pas la croix Minecraft) : l'export Bedrock (Étape 10) devra convertir la texture du keffieh.
- Les animations sont écrites à la main dans `build_soldier.py` : le générateur de l'éditeur (par noms) traite les os imbriqués (cuisse + jambe basse + botte) de la même façon et donne une marche trop raide pour ce modèle.
- Le rendu de l'éditeur trie les faces (peintre) : de petites erreurs d'ordre sont possibles là où des parties se chevauchent (poche contre plaque).
- Variantes à faire sur la même base : changer matières et texture pour d'autres unités (« soldat standard » → éclaireur, lourd, officier) ; une 2ᵉ texture de keffieh ; coupe/export par partie.

## Régénérer
    python examples/build_soldier.py               # écrit examples/soldat_standard.creature.json
    python tools/embed_example.py                  # met à jour le bouton 🎖 Soldat de l'éditeur
    python tools/render_preview.py examples/soldat_standard.creature.json docs/preview_soldat_standard.png
    python tools/render_preview.py examples/soldat_standard.creature.json sortie.png "Marche@0.125"   # aperçu d'une pose
