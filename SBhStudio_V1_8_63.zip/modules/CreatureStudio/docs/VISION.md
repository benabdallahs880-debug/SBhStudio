# Vision produit — à quoi sert CreatureStudio

Source : document de vision fourni par l'utilisateur (SBH) le 2026-09-29. Résumé fidèle des idées ; ce n'est
PAS une liste de fonctions déjà implémentées. Le statut réel est dans `CURRENT_STATE.md`.

## But
Permettre à un enfant de créer une créature Minecraft de 0 à 100 %, sans bouton « Générer », dans un atelier de
construction visuelle où chaque partie se manipule directement, avec prévisualisation 3D permanente. Un
utilisateur avancé doit pouvoir faire des créatures très complexes. L'utilisateur ne doit jamais éditer de JSON.

## Principes
- Pas limité à un humanoïde : quadrupède, serpent, oiseau, pieuvre, crabe, robot, créatures bizarres.
- Aucune limite arbitraire de nombre de parties (seulement les limites techniques du téléphone).
- Ne pas commencer par Minecraft : format interne d'abord, exporteur Bedrock ensuite. Le même créateur doit
  servir aux personnages, animaux, monstres, boss, PNJ, armes articulées et autres objets de SBH Studio.
- Modèle et comportement séparés (deux ateliers).
- Interfaces adaptées à l'enfant (curseurs « lent → rapide » plutôt que `movement_speed = 0.2875`).

## Fonctions imaginées (et étape du plan correspondante)
| Idée | Étape du MASTER_PLAN |
|---|---|
| Ajouter/supprimer/déplacer/tourner/agrandir/dupliquer/renommer/changer le point d'attache | 2 (fait côté modèle) |
| Primitives : cube, rectangle, sphère, cylindre, capsule, cône, pyramide, plan, forme perso | 2 (pyramid/plane ajoutées ; « rectangle » = cube mis à l'échelle) |
| Symétrie X/Y/Z avec possibilité de la désactiver | fait à l'Étape 4 bis (un axe à la fois ; `mirror`, bouton Sym) |
| Mode sculpture (tirer, pousser, gonfler, aplatir, étirer, couper, extruder, courber, fusionner, séparer) | 3 et au-delà (`custom`) |
| Prévisualisation 3D permanente, écran Parties / vue 3D / onglets Forme-Texture-Animation | 3 (base faite : vue 3D + liste + panneau ; onglets Texture/Animation à venir) |
| Squelette, sockets d'assemblage | sockets : 1 (fait) ; squelette : 4 (fait : pivots, os, limites, mode Pose) |
| Matériaux, couleurs, textures, peinture sur modèle (pinceau, gomme, remplissage, motifs, palette) | 5 (fait : matières, couleur, opacité, lueur, pinceau, gomme, remplissage, palette ; reste : rugosité rendue, motifs, textures Minecraft/PNG) |
| Atelier animation : Idle, Marche, Course, Saut, Attaque, Dégâts, Mort, Nage, Vol + timeline de poses | 6 (fait : timeline, images clés, poses nommées, 9 animations de base ; reste : courbes, copier/coller, vitesse) |
| Comportement en blocs visuels (SI joueur détecté → poursuivre…) | 7 (fait : règles SI/ALORS par priorité, 7 conditions, 7 actions, simulateur ; reste : séquences avec attente) |
| Caractéristiques (vie, dégâts, armure, vitesse, saut, détection) | 7 (fait : curseurs et plages ; vitesse normalisée lent→rapide) |
| Capacités spéciales en blocs (feu, glace, vol, téléportation, poison, cooldown…) ; sons, particules | 8 |
| Validation puis export Minecraft Bedrock (BP + RP, `.mcaddon`) | 9 et 10 |

## Architecture cible (8 moteurs)
Shape, Skeleton, Material → Animation → Behavior → Preview → Minecraft Exporter → `.mcaddon`, au-dessus d'un
« Creature Project » contenant : model, skeleton, materials, textures, animations, behaviors, sounds,
particles, settings, export.

## Décisions à trancher avec l'utilisateur (ouvertes)
1. Le document parle d'un conteneur `MyCreature.sbhcreature` (dossier/archive), alors que le format actuel est un
   seul fichier `.creature.json`. Garder le JSON comme cœur et l'emballer plus tard, ou changer ?
2. Où placer la symétrie dans le plan ?
3. Particles et sounds figurent dans le conteneur cible : à rattacher explicitement à l'étape 8.
