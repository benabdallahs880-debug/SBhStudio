# Intégrer CreatureStudio dans une application hôte

CreatureStudio ne dépend d'aucune application, d'aucun moteur ni de Minecraft. Trois façons de l'utiliser, au choix ou ensemble.
**Promesse de stabilité** : `API_VERSION = 1` (Python et éditeur) et `formatVersion = "1.0"` ne changent pas de façon incompatible ; tout ajout est facultatif (un fichier ancien reste valide). Une rupture ferait passer `API_VERSION` à 2.

## 1. Bibliothèque Python (`creaturestudio`)
Zéro dépendance. Depuis les sources : `import creaturestudio` fonctionne dès que la racine du dépôt est dans `sys.path`. Installé : `pip install .` (voir `pyproject.toml`).
> Dans l'environnement de développement, `pip wheel` échouait (setuptools Debian incompatible, `install_layout`) : la disposition installée a été vérifiée avec `setup.py build_py` (test `tests/test_package.py::test_installed_layout`). **À refaire avec un `pip install .` réel sur la machine cible.**

```python
import creaturestudio as cs
p = cs.load("hibou_chef.creature.json")      # CreatureProject (lève CreatureError si invalide) ; p.data = dict JSON
cs.validate(p)                               # None si valide, sinon message (str)
items = cs.diagnose(p); cs.summary(items)    # [{severity, code, message, ref}], {'error':0,'warning':0,'info':n}
files, report = cs.build_pack(p, "sbh")      # pack Bedrock en mémoire : {chemin: ('json', obj) | ('png', W, H, rows)}
cs.export_bedrock(p, "out/", namespace="sbh")# écrit RP/BP, .mcaddon, EXPORT_REPORT.json
cs.editor_path()                             # chemin du HTML de l'éditeur
```
Éditer : `p` est un `CreatureProject` avec les opérations de `core/operations.md` (`add_part`, `set_transform`, … transactionnelles, annulables).
Ligne de commande : `python -m creaturestudio validate|diagnose [--strict]|export [--out D --namespace N]|editor|version fichier.creature.json`.

## 2. L'éditeur dans une WebView / un iframe
`editor/creature_editor.html` : un seul fichier, sans réseau, à charger tel quel (`file:///android_asset/…`, `loadUrl`, `srcdoc`, ou `creaturestudio.editor_path()`).

### API JavaScript — `window.CreatureStudio`
| Membre | Rôle |
|---|---|
| `apiVersion` (1), `formatVersion` ("1.0") | versions |
| `getProject()` | copie JSON du projet courant |
| `loadProject(objet\|texte)` | → `{ok:true}` ou `{ok:false,error}` (projet invalide : rien ne change) |
| `newProject(nom)` | projet vide |
| `validate([d])` | `{ok}` / `{ok:false,error}` |
| `diagnose()` | `{items:[…], summary:{error,warning,info}}` |
| `exportBedrock([namespace])` | `{ok,filename,mime,base64,size,report}` — le `.mcaddon` (zip) en base64 |
| `listExamples()`, `loadExample(clé)` | `soldat`, `hippo1..3`, `chef` |
| `onChange(cb)` | rappel à chaque modification (y compris annuler/rétablir) ; renvoie une fonction de désinscription |

### Messages (host ⇄ éditeur)
Format `{type:'creaturestudio:…', requestId?, …}`. Réponse : `{type:'creaturestudio:response', requestId, for, ok, …}`.
- Hôte → éditeur : `creaturestudio:load {project}`, `:new {name}`, `:get`, `:diagnose`, `:export {namespace}`.
- Éditeur → hôte : `creaturestudio:ready` (au démarrage), `:change` (à chaque modification), `:exported {filename, base64, report}` (bouton ⬇ Bedrock), `:response`.
- Transports : **iframe** (`window.parent.postMessage` ; l'éditeur n'accepte que les messages venant de `window.parent`) ; **Android** : définir `window.CreatureStudioBridge.onMessage(jsonString)` (ex. `@JavascriptInterface`) avant le chargement — l'hôte envoie avec `webView.evaluateJavascript("CreatureStudioBridge.receive('…json échappé…')")` ; **React Native** : `ReactNativeWebView.postMessage` est utilisé automatiquement.
- Le bouton **⬇ Bedrock** télécharge le zip (lien `blob:`) ET notifie `:exported`. Dans une WebView Android, le téléchargement `blob:` n'est pas géré par défaut : **préférer `:exported`/`exportBedrock()` et écrire le fichier côté hôte**.
- ⚠ Les « artifacts » de claude.ai interdisent le téléchargement : l'export ne s'y enregistre pas (il fonctionne dans un vrai navigateur/WebView).

Exemple hôte (iframe) :
```js
window.addEventListener('message', e => { if (e.data?.type === 'creaturestudio:ready') frame.contentWindow.postMessage({type:'creaturestudio:load', requestId:1, project: monJson}, '*') })
```

## 3. Fichiers seuls
`.creature.json` + `schema/creature-project.schema.json` + `core/format.md` suffisent à un autre moteur pour lire une créature (sans rien d'autre du dépôt). Un lecteur doit ignorer les champs inconnus.

## Ce que l'hôte doit prévoir
- Stockage des projets (le module ne sauvegarde rien lui-même ; l'hôte garde le JSON renvoyé par `getProject()` / `:change`).
- L'export Bedrock **n'a jamais été testé dans Minecraft** (voir `docs/BEDROCK_EXPORT.md`, checklist en jeu).
- Le comportement (règles, capacités, sons, effets) est décrit dans le JSON mais **interprété par l'hôte/moteur** ; Bedrock n'en reçoit qu'une approximation.
