# Export Minecraft Bedrock (Étape 10)

```
python tools/export_bedrock.py examples/hibou_chef.creature.json --out sortie/ [--namespace sbh]
python tools/render_bedrock_preview.py sortie/le_chef_RP apercu.png --views=0,40,180     # contrôle visuel depuis les fichiers exportés
```
Sortie : `<nom>_RP/` (pack de ressources), `<nom>_BP/` (pack de comportement), `<nom>.mcaddon` (les deux, zippés), `EXPORT_REPORT.json` (tout ce qui est approché ou non exporté). Code : `core/bedrock_export.py`. Un exemple prêt à tester : `docs/exports_demo/le_chef.mcaddon`.

> **STATUT : NON TESTÉ DANS MINECRAFT.** Les formats de fichiers sont ceux de la documentation officielle ; les conventions de rotation, d'orientation des faces et les composants de comportement ci-dessous sont des **hypothèses raisonnées** qu'il faut valider dans le jeu (checklist en fin de document). Les tests prouvent la cohérence interne (`tests/test_bedrock_export.py`), pas le rendu réel.

## Fichiers produits
| Fichier | Contenu | Format |
|---|---|---|
| `RP/manifest.json`, `BP/manifest.json` | UUID déterministes (uuid5 du nom + espace de noms), `min_engine_version` 1.20.0, le BP dépend du RP | format_version 2 |
| `RP/models/entity/<n>.geo.json` | un os par partie, boîtes, UV par face | géométrie 1.12.0 |
| `RP/textures/entity/<ns>/<n>.png` | atlas : rangée 0 = pastilles de couleur (1 texel / matière), dessous = textures empilées ; taille en puissance de 2 | PNG RGBA |
| `RP/entity/<n>.entity.json` | entité client : géométrie, texture, matériau `entity_alphatest`, animations, œuf d'apparition | client_entity 1.10.0 |
| `RP/render_controllers/<n>.rc.json` | Geometry.default / Material.default / Texture.default | 1.10.0 |
| `RP/animations/<n>.animation.json` | une animation Bedrock par animation du projet | 1.8.0 |
| `RP/animation_controllers/<n>.ac.json` | repos / marche / course (vitesse au sol), attaque (`variable.attack_time`) | 1.10.0 |
| `BP/entities/<n>.json` | caractéristiques + objectifs approchés | entity 1.20.0 |

## Correspondances
**Géométrie.** 1 bloc = 16 unités ; modèle posé sur le sol (y min = 0) ; chaque partie → un os (nom ASCII unique `a-z0-9_`), parent = os de la partie parente, `pivot` = point d'articulation en repère absolu « à plat », `rotation` = rotation de repos. Les échelles sont intégrées aux boîtes. Un os n'a qu'une boîte : sphère, cylindre, cône, capsule, pyramide et forme libre deviennent leur **boîte englobante** (le plan devient une boîte d'épaisseur 0).
**Rotations.** Bedrock = (−x, +y, −z) des angles du format. Une animation Bedrock *additionne* les angles au repos alors que le format *compose* les matrices : l'exporteur convertit (angles d'Euler) quand une partie animée a une rotation de repos non nulle. Les translations d'animation sont reprises en 1/16 de bloc.
**Animations.** Images clés échantillonnées par le même code que l'éditeur ; une clé à t = 0 est toujours ajoutée ; les animations en boucle reçoivent une clé finale à t = durée égale à la première (boucle fermée) ; `animation_length` = durée.
**Textures.** La texture est dessinée sur la couleur de la matière (un texel transparent laisse la couleur), comme dans l'éditeur. Cube : grille 3×2, faces −z, +z, −x, +x, +y, −y = `north, south, west, east, up, down`. Matière sans texture : un texel de couleur unie. Lueur et transparence ne sont pas exportées.
**Comportement** (approximation volontaire — Bedrock n'a pas de « règles à conditions ») :
| Format | Bedrock |
|---|---|
| `health` | `minecraft:health` |
| `damage` | `minecraft:attack` |
| `speed` (0–1) | `minecraft:movement` = 0,05 + 0,3 × speed |
| `detectionRange` | `minecraft:follow_range` et distance max des cibles |
| `chase` | `behavior.nearest_attackable_target` (joueurs) + `behavior.melee_attack` |
| `attack` | `behavior.melee_attack` |
| `flee` | `behavior.avoid_mob_type` (joueurs) |
| `wander` | `behavior.random_stroll` |
| `idle` | `behavior.random_look_around` |
| priorité | position de la règle dans la liste (1 = la plus prioritaire) ; un composant n'apparaît qu'une fois (la règle la plus prioritaire gagne) |
**Non exportés (listés dans `EXPORT_REPORT.json`)** : conditions autres que « joueur détecté » et « distance < n », capacités spéciales (feu, glace, bouclier, soin…), sons et effets (déclarés mais non déclenchés), armure, hauteur de saut, lueur/transparence des matières, animations Dégâts et Mort (exportées mais non déclenchées par le contrôleur).
**Limite géométrique connue (D051).** Une partie *tournée* sous un parent à échelle *non uniforme* est mal placée dans Bedrock (le format produit un cisaillement que Bedrock ne représente pas). L'export le signale (« POSITION FAUSSE ») ; contournement : mettre l'échelle sur la forme (paramètres de taille), pas sur la partie parente. Les personnages livrés ne sont pas concernés ; `demo_rigged_quadruped` et `demo_animated` le sont.

## Ce qui est vérifié, ce qui ne l'est pas
Vérifié dans la documentation (voir sources) : structure et noms de champs des fichiers listés ; ordre de rotation « x puis y puis z » ; origine d'une boîte = coin minimal ; pivot d'os en coordonnées absolues du modèle ; manifest v2 (en-tête, modules `resources`/`data`, dépendance par UUID) ; chemins `models/entity`, `entity`, `render_controllers`, `animations`, `textures/entity` ; clés d'animation `loop`, `animation_length`, `bones`, `rotation`, `position`.
**Hypothèses non vérifiées dans le jeu** :
1. Signe des rotations (−x, +y, −z). Déduit : le format est déjà dans le repère de Bedrock (face −z, +x = gauche) ; Blockbench, dans son repère à lui, inverse X et Y en rotation et X en position vers Bedrock ; composé avec le miroir de l'axe X cela donne (−x, +y, −z). Signe confirmé indirectement par le fait qu'une rotation X positive baisse la tête dans les modèles vanilla.
2. Noms de faces : `east` = +x, `west` = −x ; orientation des images « boîte dépliée » (bord haut de la face du dessus côté arrière).
3. Les translations d'animation sont dans le même repère que le modèle.
4. Les composants de comportement et les requêtes Molang (`query.ground_speed`, `variable.attack_time`) acceptés tels quels par la version cible (1.20).
5. Le matériau `entity_alphatest` et les noms `Geometry.default` etc.
6. Les identifiants de sons (ex. `mob.vindicator.celebrate`) n'ont pas été vérifiés (et ne sont de toute façon pas exportés).

## Checklist de validation dans le jeu (à faire par une personne ayant Minecraft Bedrock)
1. Importer `le_chef.mcaddon` ; activer les deux packs sur un monde de test (expériences non requises).
2. `/summon sbh:le_chef` : le modèle apparaît-il sur le sol, de face, texturé ? (sinon : UV / faces / géométrie)
3. Le Chef marche : les jambes et les bras se balancent-ils dans le bon sens, sans déformation ? (signe des rotations)
4. La cape bouge-t-elle sans se détacher ? Le sabre reste-t-il dans la main ?
5. Il poursuit le joueur et attaque ; il se promène sinon.
6. Si une rotation est inversée : modifier `bedrock_rotation()` dans `core/bedrock_export.py` (une seule fonction) et relancer les tests.
7. Noter les écarts dans `reports/` et corriger l'exporteur.

## Sources
- Géométrie 1.12.0 : https://learn.microsoft.com/en-us/minecraft/creator/reference/content/schemasreference/schemas/minecraftschema_geometry_1.12.0
- Entité client, render controller, géométrie, arborescence : https://wiki.bedrock.dev/entities/entity-intro-rp.html
- Entité comportement : https://wiki.bedrock.dev/entities/entity-intro-bp.html
- manifest.json : https://learn.microsoft.com/en-us/minecraft/creator/reference/content/addonsreference/packmanifest
- Animations 1.8.0 : https://bedrock.dev/docs/stable/Schemas.md
- Inversion X/Y de rotation et X de position (Blockbench ↔ Bedrock) : https://github.com/JannisX11/blockbench/issues/3385
