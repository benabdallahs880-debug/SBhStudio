# HANDOVER — dossier de reprise CreatureStudio

Document écrit pour qu'une personne qui n'a pas vu l'historique puisse comprendre, utiliser, vérifier et terminer le travail. Lire dans l'ordre : ce fichier → `CURRENT_STATE.md` → `docs/INTEGRATION.md` → `docs/BEDROCK_EXPORT.md`. Un rapport par étape est dans `reports/`.

## 1. Ce que c'est
Un module **indépendant** (aucune dépendance à l'application hôte, à un moteur ou à Minecraft) pour créer des créatures/personnages 3D : un **format** (`.creature.json`, version 1.0), un **éditeur web** (un seul fichier HTML, pensé tactile), une **bibliothèque Python** (validation, modèle, diagnostics, export) et un **export Minecraft Bedrock**. Destiné à être intégré à une application hôte (SBh Studio, Android) — voir `docs/INTEGRATION.md`.

## 2. État : étapes 1 à 11 TERMINÉES (voir `MASTER_PLAN.md`)
Parties paramétriques (8 formes), hiérarchie, prises (sockets), squelette/os/limites/poses, matières + textures pixel-art + peinture, animations (images clés), comportements (caractéristiques + règles SI/ALORS), sons/effets/capacités, diagnostics, export Bedrock, API d'intégration. Personnages fournis : Soldat standard, Chef HIBOU, HIPPO I/II/III (+ démos).

## 3. Carte du dépôt
| Chemin | Rôle |
|---|---|
| `core/format.md` | **Spécification du format** (référence unique ; §13 sons/effets, §14 diagnostics) |
| `core/operations.md` | Opérations d'édition (transactionnelles, annulables) |
| `core/creature_model.py` | Modèle Python `CreatureProject` + maths (rotation, poses, conditions) |
| `core/diagnostics.py` | Diagnostics non bloquants D001–D052 |
| `core/bedrock_export.py` | Export Bedrock (`build_pack` pur, `export_bedrock` écrit les fichiers) |
| `tools/validate_creature.py` | Validateur (source de vérité de la validation) ; autres CLI : `diagnose_creature.py`, `export_bedrock.py`, rendus `render_*.py`, `embed_example.py` |
| `schema/creature-project.schema.json` | JSON Schema |
| `editor/creature_editor.html` | Éditeur (un fichier). Blocs : `==CORE==` (modèle/validation/diagnostics/export, **miroir JS du Python**), application (UI/dessin/simulateur), `==SOLDIER==` (exemples intégrés, généré), `==HOSTAPI==` (API hôte) |
| `creaturestudio/`, `pyproject.toml` | Façade Python publique et packaging |
| `examples/` | Générateurs (`build_*.py`, kits) et `.creature.json` produits |
| `tests/` | 159 tests |
| `docs/` | VISION, BEDROCK_EXPORT, INTEGRATION, fiches personnages, aperçus, `exports_demo/le_chef.mcaddon` |
| `reports/` | Un rapport par étape (fait / créé / modifié / reste) |

## 4. Lancer et vérifier
    python -m unittest discover -s tests          # 159 tests (certains exigent Node.js ; ignorés sinon)
    python -m creaturestudio validate|diagnose|export <fichier.creature.json>
    python examples/build_hibou.py && python examples/build_soldier.py && python tools/embed_example.py   # régénérer les personnages puis les ré-embarquer dans l'éditeur
Ouvrir l'éditeur : ouvrir `editor/creature_editor.html` dans un navigateur.

## 5. Règles de conception à respecter (sinon tout casse)
- **Python ↔ JS sont des miroirs** : toute règle de validation, d'opération, de diagnostic ou d'export modifiée côté Python doit l'être côté JS (bloc `==CORE==`). Garde-fous : `test_editor_core.py`, `test_bedrock_js_parity.py`, `test_diagnostics.py`.
- **Convention géométrique** : point → position + R·(S∘(v − pivot)), R = Rz·Ry·Rx (degrés) ; le personnage regarde −z ; « gauche » = +x ; pose = R_pose·R_repos ; unités = blocs.
- **Compatibilité du format** : tout ajout est facultatif ; ne jamais rendre invalide un fichier ancien. Changer `formatVersion` seulement pour une rupture.
- **Éditions = transactions** (`tx` / `_transaction`) avec revalidation : une erreur ne laisse jamais un projet à moitié modifié.
- Après modification des fichiers d'`examples/`, relancer `tools/embed_example.py` (sinon l'éditeur embarque d'anciennes versions).
- Mise à jour d'étape obligatoire : rapport `reports/NN_*.md`, `CURRENT_STATE.md`, `CHANGELOG.md`, `MASTER_PLAN.md`, `README.md`.

## 6. Limites connues (honnêteté)
1. **Export Bedrock jamais testé dans Minecraft.** Hypothèses : signe des rotations (−x,+y,−z) — corriger **uniquement** dans `bedrock_rotation()` (Python) / `brRot` (JS) ; noms des faces UV ; composants du comportement. Checklist : `docs/BEDROCK_EXPORT.md`.
2. **Éditeur jamais essayé sur un vrai téléphone/WebView** (seulement faux DOM sous Node + tests de logique). Les gestes tactiles ont été validés par l'utilisateur sur une version antérieure (étapes 3–4).
3. Bedrock ne reçoit pas : conditions, capacités, sons, effets (documenté dans le rapport d'export) ; formes non-boîtes → boîte englobante ; une partie tournée sous un parent à échelle non uniforme est mal placée (D051 / « POSITION FAUSSE »).
4. `pip install .` réel non essayé (bug setuptools de l'environnement de dev) ; la disposition installée a été simulée avec `build_py`.
5. Les « artifacts » claude.ai bloquent les téléchargements : le bouton ⬇ Bedrock ne sauve pas de fichier là ; il marche dans un navigateur/WebView (ou via l'API/les messages).
6. Aucun moteur d'exécution des comportements : le simulateur de l'éditeur n'est qu'un aperçu.

## 7. Reste à faire (par priorité)
1. Valider l'export dans Minecraft Bedrock (checklist) et corriger `bedrock_rotation()` / UV / composants selon le résultat ; mettre à jour `docs/BEDROCK_EXPORT.md` (« vérifié » vs « supposé »).
2. Essayer l'éditeur sur téléphone et dans la WebView de l'hôte ; implémenter côté hôte le pont (`docs/INTEGRATION.md` §2), le stockage des projets et l'écriture du `.mcaddon`.
3. `pip install .` sur la machine cible ; publier si besoin.
4. Idées non commencées : export des animations de comportement en vrai (animation controllers conditionnels), export de formes non-boîtes en plusieurs cubes, import Bedrock → format, autres cibles d'export (glTF), moteur d'exécution des comportements pour l'hôte.

## 8. Historique des décisions utiles
- Format en JSON simple lisible, un os par partie, textures en palette indexée (petites, éditables au doigt).
- Diagnostics non bloquants (la validation reste stricte et minimale).
- L'exporteur est une fonction **pure** (`build_pack`) pour pouvoir tourner partout (Python, JS) et se tester par parité.
- Règle de travail demandée par l'utilisateur : toujours rendre compte (fait / touché / reste à faire) avec un dossier final complet.
