# CreatureStudio

> **Reprise du projet : lire `HANDOVER.md`.** Intégration dans une application : `docs/INTEGRATION.md`. Étapes 1–11 terminées.

Module autonome de création de créatures et d'entités 3D.

**Statut : Étapes 1 à 10 terminées (éditeur 3D web : squelette, symétrie, peinture, animation, comportements) + personnage « Soldat standard » — Étape 5 à venir**
**Date : 2026-09-29**

Ce dossier est volontairement indépendant de SBh Studio, de Minecraft et de tout moteur graphique. Il pourra être intégré plus tard dans une application hôte.

## Ce qui existe dans cette étape

- format de projet `.creature.json` ;
- schéma JSON du format ;
- hiérarchie de parties avec parent/enfant ;
- transformations position/rotation/échelle ;
- types de formes de base ;
- emplacements (`sockets`) pour futures armes, accessoires et éléments ;
- emplacements réservés pour matériaux, squelette, animations, comportements et export ;
- exemple complet ;
- validateur Python sans dépendance externe ;
- rapport détaillé de passage de relais.

## Ce qui n'existe pas encore

Cette étape ne contient volontairement pas encore :

- éditeur 3D ;
- sculpture libre ;
- système de textures ;
- rig/squelette réel ;
- animation ;
- comportements ;
- moteur de jeu ;
- export Minecraft Bedrock.

Le format interne doit rester indépendant de ces systèmes afin de ne pas transformer Minecraft en limite architecturale. L'humanité a déjà assez de formats qui deviennent impossibles à changer après trois semaines de développement.

## Utilisation rapide

1. Ouvrir `examples/test_creature.creature.json`.
2. Modifier ou ajouter des parties.
3. Exécuter `python tools/validate_creature.py examples/test_creature.creature.json`.
4. Consulter `CURRENT_STATE.md` avant toute reprise du travail.

## Étape 2 : éditer une créature par code

    python -m unittest discover -s tests -v     # tests
    python examples/build_demo.py               # construit un dragon depuis zéro

    from creature_model import CreatureProject  # depuis core/
    p = CreatureProject.new("Ma créature")
    tete = p.add_part("Tête", "sphere", position=[0, 1.5, 0])

Règles et API : `core/operations.md`. Vision produit : `docs/VISION.md`. Reprise : `CURRENT_STATE.md`.

## Étape 3 : éditeur

Ouvrir `editor/creature_editor.html` dans un navigateur (aucune installation). Voir `reports/03_STEP_3.md`.

Dans l'éditeur, le bouton en haut à gauche change de mode : 👁 Vue, ✥ Déplacer, ⟳ Tourner (glisser une partie au doigt).

Étape 4 : `python examples/build_rigged_demo.py` construit un quadrupède avec pivots et squelette ; dans l'éditeur, le 4e mode du bouton (🦴 Pose) plie les parties à os autour de leur pivot.

Étape 4 bis : `python examples/build_symmetric_demo.py` ; dans l'éditeur, bouton « Sym » (X/Y/Z) et « ⇋ Miroir » ; en mode Pose, deux doigts qui tournent = axe Z.

Étape 5 : `python examples/build_appearance_demo.py` ; dans l'éditeur, 5e mode du bouton (🖌 Peindre) : glisser sur le modèle pour peindre ; panneau matière (couleur, opacité, lueur).

Étape 6 : `python examples/build_rigged_demo.py && python examples/build_animation_demo.py` ; dans l'éditeur, panneau timeline (choisir une animation, ▶, ＋ Image clé) et menu « Animation type… » + Générer.

HIBOU : menu 🦉 HIBOU… (Chef, HIPPO I/II/III) ; fiche `docs/CHARACTER_hibou.md`, rapport `reports/08_HIBOU.md`.

Étape 10 : export Bedrock `python tools/export_bedrock.py créature.json --out sortie/` (doc `docs/BEDROCK_EXPORT.md`, rapport `reports/10_STEP_10.md`) — non testé dans Minecraft.

Étape 9 : panneau 🩺 Diagnostic et `python tools/diagnose_creature.py` (spéc `core/format.md` §14, rapport `reports/09_STEP_9.md`).

Étape 8 : sons, effets et capacités spéciales (sections 🔊 Sons / ✨ Effets, actions « capacité spéciale ») ; spéc `core/format.md` §13, rapport `reports/08_STEP_8.md`.

Étape 7 : panneau « Comportement » et simulateur (▶ Tester) dans l'éditeur ; bouton 🎖 Soldat pour charger le personnage complet (`python examples/build_soldier.py`, fiche `docs/CHARACTER_soldat_standard.md`).
