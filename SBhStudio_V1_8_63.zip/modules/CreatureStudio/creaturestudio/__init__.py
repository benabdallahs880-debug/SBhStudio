"""CreatureStudio — API Python publique et stable (API_VERSION 1).

Les modules internes (core/, tools/) s'importent entre eux de façon « absolue » ; cette façade ajoute leurs
dossiers à sys.path puis n'expose que ce qui est promis stable. Voir docs/INTEGRATION.md.

    import creaturestudio as cs
    p = cs.load("hibou.creature.json")
    cs.validate(p.data)            # -> None si valide, sinon message
    cs.diagnose(p.data)            # -> liste d'avertissements non bloquants
    files, report = cs.build_pack(p.data, "sbh")
    cs.export_bedrock(p.data, "out/")      # écrit le pack + .mcaddon + EXPORT_REPORT.json
"""
import sys as _sys
from pathlib import Path as _Path

_here = _Path(__file__).resolve().parent
for _d in (_here / "_core", _here / "_tools"):
    if _d.is_dir() and str(_d) not in _sys.path:
        _sys.path.insert(0, str(_d))
if not (_here / "_core").is_dir():          # exécution depuis les sources (dépôt non installé)
    for _d in (_here.parent / "core", _here.parent / "tools"):
        if str(_d) not in _sys.path:
            _sys.path.insert(0, str(_d))

import json as _json                                            # noqa: E402
import validate_creature as _validator                          # noqa: E402
from creature_model import CreatureProject                      # noqa: E402
from diagnostics import diagnose as _diagnose, summary as _summary, CODES  # noqa: E402
from bedrock_export import build_pack as _build_pack, export_bedrock as _export_bedrock  # noqa: E402

__version__ = "1.0.0"
API_VERSION = 1
FORMAT_VERSION = "1.0"
__all__ = ["CreatureProject", "load", "save", "loads", "dumps", "validate", "diagnose", "summary", "build_pack",
           "export_bedrock", "editor_path", "CODES", "__version__", "API_VERSION", "FORMAT_VERSION"]


def load(path):
    """Charge un .creature.json → CreatureProject (lève CreatureError si invalide)."""
    return CreatureProject.load(path)


def save(project, path):
    project.save(path)


def loads(text):
    return CreatureProject(_json.loads(text))


def dumps(project, indent=2):
    return _json.dumps(project.data, ensure_ascii=False, indent=indent)


def validate(data):
    """None si le projet (dict ou CreatureProject) est valide, sinon le message d'erreur (str)."""
    d = data.data if isinstance(data, CreatureProject) else data
    return _validator.check(d)[0]


def diagnose(data):
    d = data.data if isinstance(data, CreatureProject) else data
    return _diagnose(d)


def summary(items):
    return _summary(items)


def build_pack(data, namespace="sbh"):
    """Construit le pack Bedrock en mémoire → (files, report). files = {chemin: ('json', obj) | ('png', W, H, rows)}."""
    d = data.data if isinstance(data, CreatureProject) else data
    return _build_pack(d, namespace)


def export_bedrock(data, out_dir, namespace="sbh", make_mcaddon=True):
    d = data.data if isinstance(data, CreatureProject) else data
    return _export_bedrock(d, out_dir, namespace, make_mcaddon)


def editor_path():
    """Chemin du fichier HTML de l'éditeur (installé avec le paquet, ou dossier editor/ des sources)."""
    for c in (_here / "editor" / "creature_editor.html", _here.parent / "editor" / "creature_editor.html"):
        if c.is_file():
            return str(c)
    raise FileNotFoundError("creature_editor.html introuvable")
