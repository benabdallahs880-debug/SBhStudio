"""python -m creaturestudio validate|diagnose|export|editor …"""
import argparse, json, sys
import creaturestudio as cs


def main(argv=None):
    ap = argparse.ArgumentParser(prog="creaturestudio", description="CreatureStudio — validation, diagnostic, export Bedrock")
    sub = ap.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("validate"); v.add_argument("file")
    d = sub.add_parser("diagnose"); d.add_argument("file"); d.add_argument("--strict", action="store_true")
    e = sub.add_parser("export"); e.add_argument("file"); e.add_argument("--out", default="export_bedrock"); e.add_argument("--namespace", default="sbh")
    sub.add_parser("editor")
    sub.add_parser("version")
    a = ap.parse_args(argv)
    if a.cmd == "version":
        print(f"creaturestudio {cs.__version__} (API {cs.API_VERSION}, format {cs.FORMAT_VERSION})"); return 0
    if a.cmd == "editor":
        print(cs.editor_path()); return 0
    data = json.load(open(a.file, encoding="utf-8"))
    err = cs.validate(data)
    if a.cmd == "validate":
        print("OK" if not err else "INVALIDE : " + err); return 0 if not err else 1
    if err:
        print("INVALIDE : " + err); return 1
    if a.cmd == "diagnose":
        items = cs.diagnose(data); s = cs.summary(items)
        for it in items:
            print(f"[{it["severity"]}] {it['code']} {it['message']}")
        print(s)
        return 1 if s["error"] or (a.strict and s["warning"]) else 0
    rep = cs.export_bedrock(data, a.out, a.namespace)
    print(json.dumps(rep, ensure_ascii=False, indent=2)[:3000]); return 0


if __name__ == "__main__":
    sys.exit(main())
