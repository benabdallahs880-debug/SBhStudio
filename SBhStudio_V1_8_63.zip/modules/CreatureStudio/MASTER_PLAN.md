# MASTER PLAN — CreatureStudio

## Architecture générale

Le module est construit comme un système de création indépendant de la plateforme. Une créature est d'abord un objet CreatureStudio, puis peut être convertie vers une cible comme Minecraft Bedrock.

## Étapes

- [x] Étape 1 — Fondations : format interne, hiérarchie, transformations, sockets, validation
- [x] Étape 2 — Construction libre des parties et primitives (modèle + opérations + tests ; sans interface)
- [x] Étape 3 — Éditeur 3D et prévisualisation interactive (version de base web, non testée en navigateur réel)
- [x] Étape 4 — Squelette, articulations et rig (pivots, os, limites, mode Pose ; pose non enregistrée ; + 4 bis : symétrie et Z à deux doigts)
- [x] Étape 5 — Matériaux, textures et apparence (matières, textures pixel-art, peinture directe ; rugosité non rendue)
- [x] Étape 6 — Animation, poses et timeline (poses nommées, images clés, timeline, 9 animations de base)
- [x] Étape 7 — Comportements et logique visuelle (caractéristiques, règles SI/ALORS par priorité, simulateur ; + personnage Soldat standard)
- [x] Étape 8 — Sons, effets et capacités spéciales (sons Minecraft saisis par id, effets visuels, 9 capacités avec recharge, aperçu dans le simulateur ; pas de lecture audio réelle)
- [x] Étape 9 — Validation avancée et diagnostics (23 codes, panneau 🩺, CLI ; seuils d'export Bedrock encore à préciser à l'étape 10)
- [x] Étape 10 — Export Minecraft Bedrock (RP + BP + .mcaddon par CLI Python ; NON TESTÉ dans le jeu, voir docs/BEDROCK_EXPORT.md ; pas d'export dans l'éditeur web)
- [x] Étape 11 — Package d'intégration dans une application hôte (paquet Python `creaturestudio`, API/messages de l'éditeur, export Bedrock dans l'éditeur, `docs/INTEGRATION.md`, `HANDOVER.md` ; non testé en WebView réelle)

## Règles d'architecture

1. Le format interne ne dépend pas de Minecraft.
2. Chaque objet important possède un identifiant stable.
3. Les références entre objets utilisent leurs identifiants et non leur position dans un tableau.
4. La hiérarchie est explicite avec `parentId`.
5. Les cycles de parenté sont interdits.
6. Le modèle doit pouvoir être lu par Android/Kotlin, Python, JavaScript ou un autre moteur sans réécriture du format.
7. Les fonctions futures sont ajoutées sans casser les projets existants autant que possible.
8. Toute étape terminée doit mettre à jour `CURRENT_STATE.md`, `CHANGELOG.md` et ajouter un rapport dans `reports/`.
9. Chaque rapport d'étape doit dire : ce qui a été fait, chaque fichier créé/modifié/inchangé, ce qui n'a PAS été fait, les décisions et limites connues, ce qui reste à faire, et le point exact de reprise — de sorte qu'une autre personne puisse terminer le travail sans l'historique de la conversation (consigne de l'utilisateur).

## Références

- `docs/VISION.md` : vision produit de l'utilisateur et correspondance idées → étapes.
- `core/operations.md` : règles d'édition du modèle.
