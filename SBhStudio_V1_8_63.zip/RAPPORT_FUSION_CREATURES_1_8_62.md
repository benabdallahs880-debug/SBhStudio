# V1.8.62 : une seule zone « Créatures » (Monstres + Entités 3D + Character Studio) et CreatureStudio intégré

Ce dossier se lit sans l'historique de la conversation. Il dit ce qui a été fait, quels fichiers ont changé, comment tout a été testé et ce qui reste à faire.

Choix de l'utilisateur avant le travail :
- **Character Studio** entre aussi dans la zone unique ;
- **export** : un monstre qui a un corps CreatureStudio est exporté avec ce **vrai corps**, et la forme Minecraft reste la solution de secours.

---

## 1. Le résultat en bref

Avant, il y avait quatre endroits séparés :
- **Monstres** : la fiche Minecraft. Le corps était l'une des 8 formes vanilla.
- **Entités 3D** : les objets, personnages et véhicules .glb pour Map Studio.
- **Character Studio** : la génération image → 3D. Sur téléphone, ses 3 boutons étaient écrasés en traits jaunes sans texte.
- **CreatureStudio** (étapes 1 à 11) : un module à part, pas dans l'app.

Maintenant :

1. **Atelier → Créatures** (l'ancien onglet « Monstres ») remplace les trois onglets. Les onglets « Entités 3D » et « Character Studio » disparaissent de la barre. Les tuiles du Hub ouvrent Créatures avec le bon filtre.
   - **Liste unique** avec les filtres Tout / Monstres / Entités 3D / Personnages IA.
   - **4 boutons de création** :
     - 👹 Monstre ;
     - 🧬 Depuis un modèle ;
     - 📦 Objet / véhicule 3D ;
     - 🪄 Image → 3D.
   - **Une carte par élément** :
     - monstre : aperçu du corps, 🧬 Corps 3D, ⚙ Fiche, 🎞 Animation, 🗑 ;
     - entité : ⚙ Fiche, 🗑 ;
     - personnage IA : Ouvrir, 🗑.
   - La **suppression** demande 2 touches (« Confirmer ? »). Avant, un seul toucher effaçait tout.
   - **⚙ Fiche** ouvre le formulaire existant (MobZone, EntityZone ou Character Studio) avec « ← Créatures » pour revenir. Pour un monstre, la fiche a aussi un bouton 🧬.
2. **🧬 Corps 3D** ouvre **CreatureStudio en plein écran** dans l'app :
   - parties, os, peinture, animations, comportements ;
   - enregistrement automatique à chaque modification ;
   - bouton « ← Atelier » et touche Retour (la page enregistre puis se ferme).
3. **Modèles de départ modifiables** : Soldat standard, Chef HIBOU, Soldat HIPPO I, II et III, ou corps vide. « Créer » ajoute un monstre puis ouvre son corps. Tout se modifie ensuite, rien n'est figé.
4. **Fiche et corps synchronisés** :
   - à l'ouverture, la fiche fait foi pour la vie, les dégâts, la vitesse et la détection ;
   - à la fermeture, les valeurs du corps et sa boîte de collision remontent dans la fiche ;
   - un monstre créé depuis un modèle prend les caractéristiques du modèle.
5. **Export Minecraft** : pour un monstre avec corps, le .mcaddon du projet contient :
   - la vraie géométrie (os) ;
   - la texture ;
   - les animations : repos, marche, course, attaque, dégâts, mort ;
   - le contrôleur d'animation de CreatureStudio.

   Le comportement (IA, attaque, faction…) reste celui de la fiche SBh. Sans corps, ou si le corps est illisible, la forme Minecraft choisie est utilisée comme avant.
6. **Aperçu** : le grand aperçu de l'Atelier et les cartes montrent l'image du corps 3D.
7. **Character Studio réparé** :
   - les 3 boutons sont maintenant chacun sur sa ligne, pleine largeur ;
   - ouvert depuis Créatures, tout le panneau défile (avant, le bas était coupé).
8. **Entités 3D** : deux défauts trouvés et corrigés en passant.
   - « Mettre à jour » perdait le lien vers le .glb (`glbUri`).
   - Le message disait toujours « Entité ajoutée ».

---

## 2. Comment le corps passe dans Minecraft (pour reprendre le code)

```
Éditeur (WebView)                       Android                                   Export du projet
CreatureStudio + sbh_host_glue.js  ──save(projet, corps, aperçu)──►  files/creatures/<projet>/<idMonstre>.creature.json
  buildBedrockPack(...) (code d'export                                 files/creatures/<projet>/<idMonstre>.body.json   ──► PackGenerator
  de CreatureStudio, parité Py↔JS)                                     files/creatures/<projet>/<idMonstre>.png               (RP du .mcaddon)
```

- **Identifiants propres au monstre**, jamais à son nom : `geometry.sbhc_sbh_<8 premiers caractères de l'id>`, `animation.sbhc_sbh_….marche`, `controller.animation.sbhc_sbh_….main`. Renommer un monstre ou changer son identifiant ne casse rien.
- **Le corps Minecraft est calculé par l'éditeur à chaque enregistrement.** L'export du .mcaddon n'a donc besoin ni de WebView ni d'un portage Kotlin de l'exporteur.
- **Ce que `PackGenerator` écrit** dans le Resource Pack pour un monstre avec corps :
  - `entity/<id>.entity.json`, par `MobPackJson.clientEntityFromBody` ;
  - `textures/entity/<clé>.png` ;
  - `models/entity/…geo.json`, `animations/…`, `animation_controllers/…`, seulement ces dossiers (`isSafeRpPath`).

  Le contrôleur de rendu commun `controller.render.default` du pack est réutilisé. L'entité comportement (BP) reste celle de SBh.
- **Avertissements à l'export** :
  - une animation du Studio Animation liée au monstre est ignorée, avec un message, car le corps a ses propres animations ;
  - les remarques du corps (lueur, transparence, position fausse, sons non déclenchés) sont ajoutées au rapport d'export.

---

## 3. Fichiers

| Fichier | Statut | Rôle |
|---|---|---|
| `app/src/main/java/com/sbh/studio/creature/CreatureBody.kt` | **nouveau** | Plusieurs objets :<br>• `CreatureBody` (format du corps Minecraft) ;<br>• `CreatureBodyMapping` (clé, fiche ↔ stats, collision, chemins sûrs, lecture), fonctions pures et testées ;<br>• `CreatureBodyStore` (fichiers par projet, suppression). |
| `app/src/main/java/com/sbh/studio/creature/CreatureEditorScreen.kt` | **nouveau** | `CreatureEditorDialog` : WebView plein écran et pont `SBhCreature` (start, save, close, toast). Retour = enregistrer puis fermer. |
| `app/src/main/java/com/sbh/studio/workshop/CreatureZone.kt` | **nouveau** | Zone « Créatures » : liste, filtres, modèles de départ, cartes, suppression en 2 touches, vue Fiche. |
| `workshop/WorkshopScreen.kt` | modifié | États `creatureFilter`, `previewKind`, `bodyVersion`, `bodyRequest`. Dialogue du corps (remonte les stats). Les 3 anciennes branches sont remplacées par `CreatureZone`. Onglets filtrés. Redirection depuis le Hub. Le corps est supprimé avec le monstre. Classe `BodyRequest`. |
| `workshop/MobZone.kt` | modifié | Paramètres `showList`, `focus`, `focusKey`, `bodyMobIds`. Note « corps 3D » dans la forme de base. |
| `workshop/EntityZone.kt` | modifié | Paramètres `showList`, `focus`, `focusKey`. `glbUri` conservé. Bon message. |
| `workshop/CharacterStudioZone.kt` | modifié | Boutons réparés. Paramètres `showList`, `focus`, `focusKey`. Défilement sans liste. |
| `workshop/HubZone.kt`, `workshop/WorkshopHelpers.kt` | modifiés | Tuile et onglet « Créatures ». Plus de tuiles Entités 3D / Character Studio. |
| `workshop/VisualWorkshopPreview.kt` | modifié | Image du corps 3D dans l'aperçu des monstres (paramètre `bodyVersion`). |
| `generator/MobPackJson.kt` | modifié | `clientEntityFromBody`. |
| `generator/PackGenerator.kt` | modifié | Export du corps (voir § 2). |
| `app/src/main/assets/creature/creature_editor.html` | **nouveau, généré** | Éditeur CreatureStudio avec la liaison SBh. **Ne pas modifier à la main.** |
| `tools/creature_host/` | **nouveau** | `sbh_host_glue.js` (liaison), `build_creature_asset.py` (génère l'asset), `test_creature_host.py` (26 contrôles navigateur), `README.md`. |
| `modules/CreatureStudio/` | **nouveau** | Le module CreatureStudio étape 11, **inchangé**. C'est la source de l'éditeur, avec ses docs, ses 159 tests Python et `HANDOVER.md`. |
| `app/src/test/java/com/sbh/studio/creature/CreatureBodyTest.kt` + `app/src/test/resources/creature/hippo1_body.json` | **nouveaux** | 7 tests Kotlin sur un vrai corps produit par l'éditeur (Soldat HIPPO I). |
| `version.json` (racine et `assets/`) | modifié | 1.8.62, code 97. |

Ce qui n'a pas changé :
- `MobEntity` : aucun champ ajouté, la présence d'un corps se lit sur le disque ;
- le format des sauvegardes ;
- Map Studio ;
- le pipeline Fondation.

---

## 4. Tests effectués

| Test | Résultat |
|---|---|
| `tools/creature_host/test_creature_host.py` : pont Android simulé dans Chromium | **26/26 OK** |
| `CreatureBodyTest.kt` (7 tests) | Écrits, avec des valeurs vérifiées à la main. **Pas exécutés** (voir § 5). |
| Relecture indépendante de tout le Kotlin modifié par un second relecteur (symboles, signatures, imports, `when` exhaustifs, défilements imbriqués, décodage du corps) | Aucune erreur de compilation certaine. 2 défauts d'exécution trouvés et corrigés, voir plus bas. |
| Lecture lexicale de tous les .kt modifiés | 0 problème |

Ce que vérifie `test_creature_host.py` :
- corps créé depuis le modèle « Chef HIBOU » et enregistré tout de suite ;
- corps Minecraft complet : géométrie valide, animations, contrôleur, PNG lisible, collision, stats ;
- aperçu PNG ;
- enregistrement automatique après une modification ;
- 🎖 Soldat demande une 2e touche avant de remplacer le corps ;
- Retour enregistre puis ferme ;
- réouverture d'un corps enregistré : stats de la fiche appliquées, pas d'enregistrement inutile ;
- corps illisible signalé, puis nouveau corps ;
- stats hors limites bornées ;
- échec d'enregistrement affiché ;
- hors de l'app, l'éditeur reste normal.

Les deux défauts corrigés après la relecture :
1. Après l'éditeur de corps, une fiche de monstre restée ouverte gardait les anciennes valeurs, et « Enregistrer » les remettait. La fiche se recharge maintenant.
2. Une détection réglée au-delà de 64 (le maximum de CreatureStudio) redescendait à 64. Elle est maintenant conservée, et un test le vérifie.

---

## 5. Ce qui reste à faire

### À vérifier en priorité sur le téléphone
1. **Compiler** (`./gradlew assembleDebug testDebugUnitTest`). Ici, Gradle et les dépôts Android sont inaccessibles, donc le Kotlin est relu mais pas compilé.
2. **Atelier → Créatures** :
   - la liste et les filtres s'affichent ;
   - ⚙ Fiche ouvre le bon formulaire ;
   - « ← Créatures » revient à la liste ;
   - la suppression demande 2 touches.
3. **🧬 Depuis un modèle → Chef HIBOU** :
   - l'éditeur s'ouvre en plein écran (tester les gestes tactiles dans la WebView) ;
   - Retour ramène dans l'Atelier ;
   - la carte montre l'image du corps ;
   - la fiche reçoit les stats du Chef.
4. **Export du projet puis Minecraft** :
   - le monstre apparaît avec son corps (pas une forme vanilla) ;
   - il se déplace avec ses animations de marche et d'attaque.

   ⚠ L'export Bedrock de CreatureStudio **n'a jamais été testé dans Minecraft**. Le signe des rotations et les faces UV sont des hypothèses. Si le corps est à l'envers ou mal texturé, corriger **uniquement** `brRot` / `bedrock_rotation()` du module, puis relancer `build_creature_asset.py` et rouvrir chaque corps (il est recalculé à l'enregistrement). Suivre la checklist `modules/CreatureStudio/docs/BEDROCK_EXPORT.md`.
5. **Character Studio** : les 3 boutons sont lisibles, et l'import d'image ou de .glb fonctionne.

### Limites connues
- **Map Studio ne montre pas le corps 3D d'un monstre** : CreatureStudio n'a pas d'export glTF. Les monstres liés à une map y restent des repères, comme avant.
- **Le comportement CreatureStudio n'est pas exporté** : règles SI/ALORS, capacités, sons, effets. Le comportement Minecraft vient de la fiche SBh (profil IA, attaque, poursuite…). Seules vie, dégâts, vitesse, détection et collision sont synchronisées. L'armure, la hauteur de saut et l'intelligence ne le sont pas.
- **Dans l'app, le bouton « ⬇ Bedrock » de l'éditeur est masqué**, ainsi que « Télécharger » du panneau JSON. Le .mcaddon du projet contient le corps. « Copier » le JSON reste possible.
- **Remplacer le corps par un modèle** (🎖 / 🦉) demande une 2e touche, mais **↶ ne le rend pas**. C'est une limite du module : un nouveau projet remet l'historique à zéro.
- **Les modèles de départ** sont ceux embarqués dans l'éditeur (Soldat, Chef, HIPPO I/II/III). Les démos du module (dragon, quadrupède…) ne sont pas proposées.
- **Si le format du corps change** dans un futur module, régénérer la fixture de test (voir `tools/creature_host/README.md`).

### Idées pour la suite (non commencées)
- Exporter le corps CreatureStudio en .glb pour Map Studio.
- Traduire une partie des règles CreatureStudio en composants Bedrock de la fiche.
- Dupliquer un monstre avec son corps.

---

## 6. Livraison

- `SBhStudio_V1_8_62.zip` : projet complet. Sur GitHub, supprimer l'ancien zip puis déposer celui-ci à la racine. Le workflow compile l'APK.
- Ce rapport est à la racine du projet.
