package com.sbh.studio.workshop

import org.junit.Assert.assertEquals
import org.junit.Test

/** V1.8.59 — deux créations successives avec l'identifiant par défaut ne doivent plus produire de doublon. */
class WorkshopUniqueIdTest {

    @Test
    fun freeIdentifierIsKept() {
        assertEquals("agw:portal_custom", workshopUniqueId("agw:portal_custom", emptySet()))
    }

    @Test
    fun takenIdentifierGetsSuffix() {
        assertEquals("agw:portal_custom_2", workshopUniqueId("agw:portal_custom", setOf("agw:portal_custom")))
    }

    @Test
    fun suffixSkipsTakenNumbers() {
        val taken = setOf("agw:portal_custom", "agw:portal_custom_2", "agw:portal_custom_3")
        assertEquals("agw:portal_custom_4", workshopUniqueId("agw:portal_custom", taken))
        // Une saisie déjà suffixée repart de la même racine.
        assertEquals("agw:portal_custom_4", workshopUniqueId("agw:portal_custom_2", taken))
    }

    @Test
    fun surroundingSpacesAreIgnored() {
        assertEquals("agw:bloc", workshopUniqueId("  agw:bloc ", emptySet()))
    }
}
