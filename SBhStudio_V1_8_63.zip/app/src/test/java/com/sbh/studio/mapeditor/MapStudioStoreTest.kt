package com.sbh.studio.mapeditor

import com.sbh.studio.workshop.MapBlueprint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** V1.8.60 — liaison Map Studio → Atelier → .mcaddon. */
class MapStudioStoreTest {

    private val export = """
        {"format":"sbh-map-studio","version":3,"name":"Oasis Nord","atelierMapId":"",
         "size":[64,48,32],"world":{"sx":64,"sy":48,"sz":32,"data":""},
         "bedrock":{"functions":["# partie 1\nsetblock ~0 ~0 ~0 minecraft:stone\n","# partie 2\n"]}}
    """.trimIndent()

    @Test
    fun parseExportReadsHeader() {
        val info = MapStudioStore.parseExport(export)
        assertNotNull(info)
        info!!
        assertEquals("Oasis Nord", info.name)
        assertEquals(64, info.sizeX); assertEquals(48, info.sizeY); assertEquals(32, info.sizeZ)
        assertNull(info.atelierMapId)
        assertEquals(2, info.functionCount)
    }

    @Test
    fun parseExportRejectsOtherFormatsAndBadSizes() {
        assertNull(MapStudioStore.parseExport("""{"format":"autre","size":[8,8,8]}"""))
        assertNull(MapStudioStore.parseExport("""{"format":"sbh-map-studio","size":[999,8,8]}"""))
        assertNull(MapStudioStore.parseExport("pas du json"))
    }

    @Test
    fun functionsAreExtracted() {
        val f = MapStudioStore.bedrockFunctionsFromJson(export)
        assertEquals(2, f.size)
        assertTrue(f[0].contains("setblock"))
        assertEquals(emptyList<String>(), MapStudioStore.bedrockFunctionsFromJson(""))
    }

    @Test
    fun upsertCreatesThenUpdatesKeepingAtelierSettings() {
        val info = MapStudioStore.parseExport(export)!!
        val created = MapStudioStore.upsertMap(emptyList(), "p1", "m1", info)
        assertEquals(1, created.size)
        assertEquals("p1", created[0].projectId)
        assertEquals(48, created[0].height)

        val edited = listOf(created[0].copy(theme = "oasis", linkedMobIds = listOf("mob1")))
        val updated = MapStudioStore.upsertMap(edited, "p1", "m1", info.copy(name = "Oasis Sud", sizeX = 128))
        assertEquals(1, updated.size)
        assertEquals("Oasis Sud", updated[0].name)
        assertEquals(128, updated[0].sizeX)
        assertEquals("oasis", updated[0].theme)              // réglage Atelier conservé
        assertEquals(listOf("mob1"), updated[0].linkedMobIds)
    }

    @Test
    fun functionFolderIsSafeAndUnique() {
        assertEquals("oasis_nord", MapStudioStore.functionFolder("Oasis Nord", "m1", emptySet()))
        assertEquals("foret_d_ete", MapStudioStore.functionFolder("Forêt d'été", "m1", emptySet()))
        assertEquals("oasis_nord_2", MapStudioStore.functionFolder("Oasis Nord", "m2", setOf("oasis_nord")))
        assertTrue(MapStudioStore.functionFolder("الزهراء", "abc123", emptySet()).startsWith("map_"))
    }

    @Test
    fun safeIdNeverEmptyAndNoPathTricks() {
        assertEquals("global", MapStudioStore.safeId(""))
        assertEquals("______etc", MapStudioStore.safeId("../../etc"))
    }

    @Suppress("unused")
    private fun unused(m: MapBlueprint) = m
}
