package com.sbh.studio.creature

import com.sbh.studio.data.MobEntity
import com.sbh.studio.generator.MobPackJson
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** V1.8.62 — corps CreatureStudio des monstres : conversions et export Minecraft. */
class CreatureBodyTest {

    /** Corps réel produit par l'éditeur (modèle « Soldat HIPPO I », clé sbh_0f1e2d3c). */
    private val bodyText = javaClass.classLoader!!.getResource("creature/hippo1_body.json")!!.readText()
    private val mob = MobEntity(id = "0F1E2D3C-aaaa-bbbb", projectId = "p1", nom = "Garde", identifiant = "agw:garde",
        vie = 30, degats = 5, vitesse = 0.25, detectionDistance = 24.0)

    @Test
    fun bodyKeyIsStableAndSafe() {
        assertEquals("sbh_0f1e2d3c", CreatureBodyMapping.bodyKey("0F1E2D3C-aaaa-bbbb"))
        assertEquals("sbh_corps", CreatureBodyMapping.bodyKey("---"))
    }

    @Test
    fun statsFromMobUseCreatureStudioRanges() {
        val s = CreatureBodyMapping.statsFromMob(mob)
        assertEquals(30.0, s["health"]!!, 0.0)
        assertEquals(5.0, s["damage"]!!, 0.0)
        assertEquals(0.667, s["speed"]!!, 0.0005)          // (0,25 − 0,05) / 0,3
        assertEquals(24.0, s["detectionRange"]!!, 0.0)
        val big = CreatureBodyMapping.statsFromMob(mob.copy(vie = 5000, degats = -3, vitesse = 9.0, detectionDistance = 128.0))
        assertEquals(1000.0, big["health"]!!, 0.0); assertEquals(0.0, big["damage"]!!, 0.0)
        assertEquals(1.0, big["speed"]!!, 0.0); assertEquals(64.0, big["detectionRange"]!!, 0.0)
    }

    @Test
    fun realBodyParsesAndUpdatesTheMob() {
        val body = CreatureBodyMapping.parse(bodyText)
        assertNotNull(body); body!!
        assertEquals("geometry.sbhc_sbh_0f1e2d3c", body.geometryId)
        assertEquals(listOf("main"), body.client.animate)
        val m = CreatureBodyMapping.applyToMob(mob, body)
        assertEquals(24, m.vie); assertEquals(4, m.degats)
        assertEquals(0.215, m.vitesse, 0.0005)              // 0,05 + 0,3 × 0,55
        assertEquals(18.0, m.detectionDistance, 0.0)
        assertEquals(0.92, m.collisionLargeur, 0.0); assertEquals(2.06, m.collisionHauteur, 0.0)
        assertEquals(mob.identifiant, m.identifiant)        // l'identité ne change jamais
        assertTrue(CreatureBodyMapping.differs(mob, m))
        assertFalse(CreatureBodyMapping.differs(m, m))
        // détection > 64 dans la fiche : le plafond de CreatureStudio (64) ne la réduit pas
        val far = CreatureBodyMapping.applyToMob(mob.copy(detectionDistance = 100.0), body.copy(stats = body.stats!!.copy(detectionRange = 64.0)))
        assertEquals(100.0, far.detectionDistance, 0.0)
    }

    @Test
    fun brokenBodiesAreRejected() {
        assertNull(CreatureBodyMapping.parse(null))
        assertNull(CreatureBodyMapping.parse(""))
        assertNull(CreatureBodyMapping.parse("{pas du json"))
        assertNull(CreatureBodyMapping.parse("""{"format":"autre","geometryId":"g","client":{"geometry":"g"},"texture":{"base64":"AA"}}"""))
        assertNull(CreatureBodyMapping.parse("""{"geometryId":"g","client":{"geometry":"g"},"texture":{"base64":""}}"""))
    }

    @Test
    fun onlyModelAnimationAndControllerPathsAreWritten() {
        assertTrue(CreatureBodyMapping.isSafeRpPath("models/entity/sbh_0f1e2d3c.geo.json"))
        assertTrue(CreatureBodyMapping.isSafeRpPath("animations/sbh_0f1e2d3c.animation.json"))
        assertTrue(CreatureBodyMapping.isSafeRpPath("animation_controllers/sbh_0f1e2d3c.ac.json"))
        assertFalse(CreatureBodyMapping.isSafeRpPath("manifest.json"))
        assertFalse(CreatureBodyMapping.isSafeRpPath("models/entity/../../manifest.json"))
        assertFalse(CreatureBodyMapping.isSafeRpPath("textures/entity/x.png"))
        val body = CreatureBodyMapping.parse(bodyText)!!
        assertTrue(body.files.keys.all { CreatureBodyMapping.isSafeRpPath(it) })
    }

    @Test
    fun clientEntityUsesTheRealBody() {
        val body = CreatureBodyMapping.parse(bodyText)!!
        val doc = Json.parseToJsonElement(MobPackJson.clientEntityFromBody(mob, "agw", "garde", "agw_garde", body)).jsonObject
        val d = doc["minecraft:client_entity"]!!.jsonObject["description"]!!.jsonObject
        assertEquals("agw:garde", d["identifier"]!!.jsonPrimitive.content)
        assertEquals("geometry.sbhc_sbh_0f1e2d3c", d["geometry"]!!.jsonObject["default"]!!.jsonPrimitive.content)
        assertEquals("textures/entity/agw_garde", d["textures"]!!.jsonObject["default"]!!.jsonPrimitive.content)
        assertEquals("controller.render.default", d["render_controllers"]!!.jsonArray[0].jsonPrimitive.content)
        assertEquals("controller.animation.sbhc_sbh_0f1e2d3c.main", d["animations"]!!.jsonObject["main"]!!.jsonPrimitive.content)
        assertEquals("main", d["scripts"]!!.jsonObject["animate"]!!.jsonArray[0].jsonPrimitive.content)
        // la géométrie fournie porte bien l'identifiant référencé
        val geo = Json.parseToJsonElement(body.files.getValue("models/entity/sbh_0f1e2d3c.geo.json")).jsonObject
        assertEquals(body.geometryId, geo["minecraft:geometry"]!!.jsonArray[0].jsonObject["description"]!!.jsonObject["identifier"]!!.jsonPrimitive.content)
    }

    @Test
    fun bodyWithoutAnimationsHasNoScripts() {
        val body = CreatureBodyMapping.parse(bodyText)!!.let { it.copy(client = it.client.copy(animations = emptyMap(), animate = listOf("main"))) }
        val d = Json.parseToJsonElement(MobPackJson.clientEntityFromBody(mob, "agw", "garde", "agw_garde", body)).jsonObject["minecraft:client_entity"]!!
            .jsonObject["description"]!!.jsonObject
        assertNull(d["animations"]); assertNull(d["scripts"])
    }
}
