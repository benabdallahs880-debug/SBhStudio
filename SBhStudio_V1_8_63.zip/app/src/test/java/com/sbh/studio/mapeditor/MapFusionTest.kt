package com.sbh.studio.mapeditor

import com.sbh.studio.workshop.MapBlueprint
import com.sbh.studio.workshop.PlayableSceneBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** V1.8.61 — fusion Map Studio + zone Maps de l'Atelier, test village forge. */
class MapFusionTest {

    private val base = MapBlueprint(
        id = "m1", projectId = "p1", name = "Village", sizeX = 64, sizeZ = 64, height = 48,
        terrain = "desert", notes = ""
    )

    @Test
    fun ficheKeepsIdentityAndSizes() {
        val incoming = base.copy(
            id = "pirate", projectId = "autre", name = "  Nouveau nom  ", sizeX = 999, sizeZ = 1, height = 2,
            terrain = "plaine", dimension = " ", seed = 42L, worldX = 100, worldZ = -50,
            hasOasis = true, hasVillage = false,
            linkedMobIds = listOf("a", "a", "b"), notes = "x".repeat(5000)
        )
        val r = MapStudioStore.applyFiche(base, incoming)
        assertEquals("m1", r.id)
        assertEquals("p1", r.projectId)
        assertEquals(64, r.sizeX); assertEquals(64, r.sizeZ); assertEquals(48, r.height)
        assertEquals("Nouveau nom", r.name)
        assertEquals("plaine", r.terrain)
        assertEquals("minecraft:overworld", r.dimension)
        assertEquals(42L, r.seed)
        assertEquals(100, r.worldX); assertEquals(-50, r.worldZ)
        assertTrue(r.hasOasis); assertFalse(r.hasVillage)
        assertEquals(listOf("a", "b"), r.linkedMobIds)
        assertEquals(4000, r.notes.length)
    }

    @Test
    fun blankNameKeepsOldName() {
        val r = MapStudioStore.applyFiche(base, base.copy(name = "   "))
        assertEquals("Village", r.name)
    }

    @Test
    fun forgeNoteDetected() {
        assertTrue(MapStudioStore.hasForgeNote(base.copy(notes = "Structure: maison_forgeron posée")))
        assertTrue(MapStudioStore.hasForgeNote(base.copy(notes = "la maison du forgeron")))
        assertFalse(MapStudioStore.hasForgeNote(base))
    }

    @Test
    fun compactSceneToPlacements() {
        val c = PlayableSceneBuilder.CompactScene(
            mapId = "m1", name = "Village forge",
            palette = listOf("minecraft:air", "minecraft:stone", "minecraft:chest"),
            // x,y,z,indice : air ignoré, indice hors palette ignoré, reste incomplet ignoré
            blocks = listOf(0, 0, 0, 1, 1, 2, 3, 2, 5, 5, 5, 0, 9, 9, 9, 7, 4, 4),
            mobs = listOf(PlayableSceneBuilder.PlacementMob(1, 2, 3, "agw:forgeron_village")),
            spawn = PlayableSceneBuilder.SpawnPoint(4, 5, 6)
        )
        val p = PlayableSceneBuilder.placementsFromCompact(c)
        assertEquals(2, p.blocks.size)
        assertEquals(PlayableSceneBuilder.PlacementBlock(0, 0, 0, "minecraft:stone"), p.blocks[0])
        assertEquals(PlayableSceneBuilder.PlacementBlock(1, 2, 3, "minecraft:chest"), p.blocks[1])
        assertEquals(1, p.mobs.size)
        assertEquals(6, p.spawn!!.z)
        assertEquals("m1", p.structureId)
        assertEquals("Village forge", p.structureName)
    }

    @Test
    fun emptyCompactScene() {
        val p = PlayableSceneBuilder.placementsFromCompact(PlayableSceneBuilder.CompactScene())
        assertTrue(p.blocks.isEmpty())
        assertNull(p.spawn)
    }
}
