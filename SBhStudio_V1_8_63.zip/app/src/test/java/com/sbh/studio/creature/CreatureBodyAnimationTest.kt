package com.sbh.studio.creature

import com.sbh.studio.animation.AnimState
import com.sbh.studio.animation.AnimStateParams
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.double
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test

/** V1.8.63 — l'âme du Studio Animation appliquée aux animations d'un corps CreatureStudio. */
class CreatureBodyAnimationTest {

    private val body = CreatureBodyMapping.parse(javaClass.classLoader!!.getResource("creature/hippo1_body.json")!!.readText())!!
    private val animDoc = body.files.getValue("animations/sbh_0f1e2d3c.animation.json")
    private val walkId = "animation.sbhc_sbh_0f1e2d3c.marche"

    private fun anims(json: String): JsonObject = Json.parseToJsonElement(json).jsonObject["animations"]!!.jsonObject

    @Test
    fun statesMatchBodyAnimationNames() {
        val names = CreatureBodyAnimation.names(body)
        assertEquals(listOf("repos", "marche", "course", "attaque", "degats", "mort"), names)
        assertEquals("marche", CreatureBodyAnimation.bodyAnimationFor(AnimState.WALK, names))
        assertEquals("degats", CreatureBodyAnimation.bodyAnimationFor(AnimState.HURT, names))
        assertNull(CreatureBodyAnimation.bodyAnimationFor(AnimState.SIT, names))
        assertNull(CreatureBodyAnimation.bodyAnimationFor(AnimState.SWIM, names))
    }

    @Test
    fun soulScalesOnlyTheMatchingAnimation() {
        val states = mapOf(AnimState.WALK.name to AnimStateParams(speed = 2f, amplitude = 0.5f, weight = 1f, loop = false))
        val before = anims(animDoc)
        val after = anims(CreatureBodyAnimation.applySoul(animDoc, body.client.animations, states))
        // les autres animations sont recopiées telles quelles
        assertEquals(before["animation.sbhc_sbh_0f1e2d3c.repos"], after["animation.sbhc_sbh_0f1e2d3c.repos"])
        assertEquals(before["animation.sbhc_sbh_0f1e2d3c.mort"], after["animation.sbhc_sbh_0f1e2d3c.mort"])
        val w0 = before[walkId]!!.jsonObject
        val w1 = after[walkId]!!.jsonObject
        // durée ÷ vitesse, boucle = réglage
        assertEquals(w0["animation_length"]!!.jsonPrimitive.double / 2, w1["animation_length"]!!.jsonPrimitive.double, 1e-6)
        assertFalse(w1["loop"]!!.jsonPrimitive.boolean)
        // image clé 0.25 s → 0.125 s, rotation × 0,5 ; déplacement × 0,5 × 1
        val r0 = w0["bones"]!!.jsonObject["bassin"]!!.jsonObject["rotation"]!!.jsonObject
        val r1 = w1["bones"]!!.jsonObject["bassin"]!!.jsonObject["rotation"]!!.jsonObject
        assertEquals(r0["0.25"]!!.jsonArray[1].jsonPrimitive.double * 0.5, r1["0.125"]!!.jsonArray[1].jsonPrimitive.double, 1e-4)
        assertEquals(r0.size, r1.size)
        val p0 = w0["bones"]!!.jsonObject["bassin"]!!.jsonObject["position"]!!.jsonObject
        val p1 = w1["bones"]!!.jsonObject["bassin"]!!.jsonObject["position"]!!.jsonObject
        assertEquals(p0["0.0"]!!.jsonArray[1].jsonPrimitive.double * 0.5, p1["0.0"]!!.jsonArray[1].jsonPrimitive.double, 1e-4)
    }

    @Test
    fun neutralSoulKeepsTheMotion() {
        val states = mapOf(AnimState.WALK.name to AnimStateParams(speed = 1f, amplitude = 1f, weight = 1f, loop = true))
        val w0 = anims(animDoc)[walkId]!!.jsonObject
        val w1 = anims(CreatureBodyAnimation.applySoul(animDoc, body.client.animations, states))[walkId]!!.jsonObject
        val r0 = w0["bones"]!!.jsonObject["bassin"]!!.jsonObject["rotation"]!!.jsonObject
        val r1 = w1["bones"]!!.jsonObject["bassin"]!!.jsonObject["rotation"]!!.jsonObject
        r0.forEach { (t, v) ->
            assertEquals(v.jsonArray[1].jsonPrimitive.double, r1[CreatureBodyAnimation.timeKey(t.toDouble())]!!.jsonArray[1].jsonPrimitive.double, 1e-9)
        }
    }

    @Test
    fun timeKeysAreWrittenLikeCreatureStudio() {
        assertEquals("0.0", CreatureBodyAnimation.timeKey(0.0))
        assertEquals("0.125", CreatureBodyAnimation.timeKey(0.125))
        assertEquals("1.0", CreatureBodyAnimation.timeKey(1.0))
        assertEquals("0.3333", CreatureBodyAnimation.timeKey(1.0 / 3))
    }
}
