package com.sbh.studio.workshop

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.animation.AnimSoul
import com.sbh.studio.animation.AnimationEditor
import com.sbh.studio.animation.AnimationProject
import com.sbh.studio.animation.AnimationRepository
import com.sbh.studio.character.CharacterProject
import com.sbh.studio.creature.CreatureBodyAnimation
import com.sbh.studio.creature.CreatureBodyStore
import com.sbh.studio.data.MobEntity
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * V1.8.62 — zone unique « Créatures » de l'Atelier.
 *
 * Avant : trois onglets séparés — Monstres (fiche Minecraft, corps = forme vanilla), Entités 3D
 * (objets / personnages / véhicules .glb pour Map Studio) et Character Studio (image → 3D).
 * Maintenant : une seule liste avec filtres, un bouton par action, et le corps 3D des monstres
 * se fait dans CreatureStudio (éditeur plein écran, exporté tel quel dans le .mcaddon).
 * Les formulaires existants (MobZone, EntityZone, CharacterStudioZone) servent de « fiche ».
 */
enum class CreatureKind { MOB, ENTITY, CHARACTER }

enum class CreatureFilter(val label: String) { ALL("Tout"), MOBS("Monstres"), ENTITIES("Entités 3D"), CHARACTERS("Personnages IA") }

/** Modèles de départ (corps CreatureStudio complets, modifiables à volonté une fois copiés). */
data class CreatureTemplate(val key: String, val name: String, val description: String)

val CREATURE_TEMPLATES = listOf(
    CreatureTemplate("soldat", "Soldat standard", "Keffieh, gilet tactique · 38 parties · 6 animations"),
    CreatureTemplate("chef", "Chef HIBOU", "Chef des Hiboux · capacités Bouclier, Soin, Cri"),
    CreatureTemplate("hippo1", "Soldat HIPPO I", "Soldat léger HIBOU"),
    CreatureTemplate("hippo2", "Soldat HIPPO II", "Soldat moyen HIBOU"),
    CreatureTemplate("hippo3", "Soldat HIPPO III", "Soldat lourd HIBOU · grenade"),
    CreatureTemplate("", "Corps vide", "Tu construis tout, partie par partie")
)

private sealed interface CreatureView {
    object Browse : CreatureView
    data class Edit(val kind: CreatureKind, val id: String?) : CreatureView
    /** V1.8.63 : animation (âme du Studio Animation) d'un monstre. */
    data class Anim(val mobId: String) : CreatureView
}

/** Aperçu du corps 3D d'un monstre (image enregistrée par l'éditeur), ou null. */
@Composable
internal fun rememberCreaturePreview(mob: MobEntity?, version: Int = 0): ImageBitmap? {
    if (mob == null) return null
    val context = LocalContext.current
    val file = CreatureBodyStore.previewFile(context, mob.projectId, mob.id)
    val stamp = if (file.exists()) file.lastModified() else 0L
    return remember(mob.id, stamp, version) {
        if (stamp == 0L) null else runCatching { android.graphics.BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap() }.getOrNull()
    }
}

@Composable
internal fun CreatureZone(
    projectId: String,
    hasProject: Boolean,
    mobs: List<MobEntity>,
    entities: List<SceneEntity>,
    characters: List<CharacterProject>,
    maps: List<MapBlueprint>,
    textures: List<TextureProject>,
    bodyVersion: Int,
    filter: CreatureFilter,
    onFilter: (CreatureFilter) -> Unit,
    onPreview: (CreatureKind, String?) -> Unit,
    // monstres
    onSaveMob: (MobEntity) -> Unit,
    onDeleteMob: (MobEntity) -> Unit,
    onAddPresets: () -> Unit,
    /** V1.8.63 : joue un état de l'âme sur le corps 3D (éditeur CreatureStudio). */
    onPreviewBody: (MobEntity, com.sbh.studio.creature.BodyPreview) -> Unit,
    onOpenBody: (MobEntity) -> Unit,
    onCreateFromTemplate: (CreatureTemplate) -> Unit,
    // entités 3D
    onSaveEntity: (SceneEntity) -> Unit,
    onDeleteEntity: (SceneEntity) -> Unit,
    onOpenEditor3D: () -> Unit,
    // personnages IA (Character Studio)
    onSaveCharacter: (CharacterProject) -> Unit,
    onDeleteCharacter: (CharacterProject) -> Unit,
    onSendToMapStudio: (String, String) -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var view by remember(projectId) { mutableStateOf<CreatureView>(CreatureView.Browse) }
    var focusKey by remember(projectId) { mutableStateOf(0) }
    var showTemplates by remember(projectId) { mutableStateOf(false) }
    var pendingDelete by remember(projectId) { mutableStateOf<String?>(null) }
    LaunchedEffect(pendingDelete) { if (pendingDelete != null) { delay(3000); pendingDelete = null } }

    val bodyIds = remember(mobs, bodyVersion) { mobs.filter { CreatureBodyStore.has(context, it.projectId, it.id) }.map { it.id }.toSet() }

    // V1.8.63 : âmes (Studio Animation) et animations des corps, pour les cartes et l'onglet 🎞
    var animVersion by remember(projectId) { mutableStateOf(0) }
    var animProjects by remember(projectId) { mutableStateOf(emptyList<AnimationProject>()) }
    var bodyAnims by remember(projectId) { mutableStateOf(emptyMap<String, List<String>>()) }
    LaunchedEffect(animVersion, mobs) {
        animProjects = withContext(Dispatchers.IO) { runCatching { AnimationRepository(context).loadAll() }.getOrDefault(emptyList()) }
    }
    LaunchedEffect(bodyIds, bodyVersion) {
        bodyAnims = withContext(Dispatchers.IO) {
            mobs.filter { it.id in bodyIds }.associate { m ->
                m.id to (runCatching { CreatureBodyStore.loadBody(context, m.projectId, m.id) }.getOrNull()
                    ?.let { CreatureBodyAnimation.names(it) } ?: emptyList())
            }
        }
    }
    fun animOf(m: MobEntity): AnimationProject? =
        animProjects.firstOrNull { it.linkedMobId == m.id || it.linkedMobIdentifier == m.identifiant }
    fun animLine(m: MobEntity): String {
        val soul = animOf(m)?.let { p -> "🎞 Âme « ${runCatching { AnimSoul.valueOf(p.soul).label }.getOrDefault(p.name)} »" }
        val n = bodyAnims[m.id]?.size ?: 0
        return when {
            n > 0 && soul != null -> "$soul sur $n animation(s) du corps"
            n > 0 -> "🎞 $n animation(s) du corps (âme par défaut)"
            soul != null -> soul
            else -> "🎞 Animation Minecraft par défaut"
        }
    }

    fun open(kind: CreatureKind, id: String?) {
        if (!hasProject) { onMessage("Ouvrez un projet d'abord"); return }
        view = CreatureView.Edit(kind, id)
        focusKey++
        onPreview(kind, id)
    }
    fun back() { view = CreatureView.Browse }

    // Après l'éditeur de corps, la fiche ouverte relit le monstre (vie, dégâts, collision… venus
    // du corps) : sinon « Enregistrer » remettait les anciennes valeurs.
    LaunchedEffect(bodyVersion) {
        val v = view
        if (bodyVersion != 0 && v is CreatureView.Edit && v.kind == CreatureKind.MOB) focusKey++
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        when (val v = view) {
            is CreatureView.Edit -> {
                val mob = if (v.kind == CreatureKind.MOB) mobs.firstOrNull { it.id == v.id } else null
                val title = when (v.kind) {
                    CreatureKind.MOB -> mob?.nom ?: "Nouveau monstre"
                    CreatureKind.ENTITY -> entities.firstOrNull { it.id == v.id }?.name ?: "Nouvelle entité 3D"
                    CreatureKind.CHARACTER -> characters.firstOrNull { it.id == v.id }?.name ?: "Personnage IA"
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { back() }) { Text("← Créatures", color = AgwColors.GoldSoft) }
                    Text(title, color = AgwColors.SacredGold, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (mob != null) TextButton(onClick = { onOpenBody(mob) }) { Text(if (mob.id in bodyIds) "🧬 Corps 3D" else "🧬 Créer le corps", color = AgwColors.SacredGold) }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (v.kind) {
                        CreatureKind.MOB -> MobZone(
                            projectId = projectId,
                            mobs = mobs,
                            hasProject = hasProject,
                            textures = textures,
                            onAddPresets = onAddPresets,
                            onSave = { m -> onSaveMob(m); back() },
                            onDelete = { m -> onDeleteMob(m); back() },
                            onOpenAnimation = { id -> view = CreatureView.Anim(id) },
                            showList = false,
                            focus = mob,
                            focusKey = focusKey,
                            bodyMobIds = bodyIds
                        )
                        CreatureKind.ENTITY -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            GoldOutlineButton("🧊 Éditeur 3D plein écran", onClick = onOpenEditor3D, modifier = Modifier.fillMaxWidth())
                            EntityZone(
                                projectId = projectId,
                                entities = entities,
                                maps = maps,
                                hasProject = hasProject,
                                onSave = { e -> onSaveEntity(e); back() },
                                onDelete = { e -> onDeleteEntity(e); back() },
                                onMessage = onMessage,
                                showList = false,
                                focus = entities.firstOrNull { it.id == v.id },
                                focusKey = focusKey
                            )
                        }
                        CreatureKind.CHARACTER -> CharacterStudioZone(
                            projectId = projectId,
                            hasProject = hasProject,
                            projects = characters,
                            onSave = onSaveCharacter,
                            onDelete = { c -> onDeleteCharacter(c); back() },
                            onMessage = onMessage,
                            onSendToMapStudio = onSendToMapStudio,
                            showList = false,
                            focus = characters.firstOrNull { it.id == v.id },
                            focusKey = focusKey
                        )
                    }
                }
            }
            is CreatureView.Anim -> {
                val mob = mobs.firstOrNull { it.id == v.mobId }
                if (mob == null) LaunchedEffect(v.mobId) { back() } else {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { back() }) { Text("← Créatures", color = AgwColors.GoldSoft) }
                    Text("🎞 ${mob.nom}", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onOpenBody(mob) }) { Text(if (mob.id in bodyIds) "🧬 Corps 3D" else "🧬 Créer le corps", color = AgwColors.SacredGold) }
                }
                key(mob.id) {
                    AnimationEditor(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        fixedMob = mob,
                        bodyAnimations = bodyAnims[mob.id] ?: emptyList(),
                        onPreviewOnBody = { anim, p ->
                            onPreviewBody(mob, com.sbh.studio.creature.BodyPreview(anim, p.speed, p.amplitude, p.weight, p.loop))
                        },
                        onSaved = { animVersion++ },
                        onMessage = onMessage
                    )
                }
                }
            }
            CreatureView.Browse -> {
                val rows = buildList {
                    if (filter == CreatureFilter.ALL || filter == CreatureFilter.MOBS) mobs.forEach { add(CreatureKind.MOB to it.id) }
                    if (filter == CreatureFilter.ALL || filter == CreatureFilter.ENTITIES) entities.forEach { add(CreatureKind.ENTITY to it.id) }
                    if (filter == CreatureFilter.ALL || filter == CreatureFilter.CHARACTERS) characters.forEach { add(CreatureKind.CHARACTER to it.id) }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                    item(key = "head") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Créatures · مخلوقات", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                            Text(
                                "Monstres, personnages, objets et véhicules au même endroit. Un monstre peut avoir un vrai corps 3D " +
                                    "(🧬 CreatureStudio) : c'est lui qui part dans Minecraft.",
                                color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                GoldPrimaryButton("👹 Monstre", onClick = { open(CreatureKind.MOB, null) }, modifier = Modifier.weight(1f))
                                GoldPrimaryButton("🧬 Depuis un modèle", onClick = { showTemplates = !showTemplates }, modifier = Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                GoldOutlineButton("📦 Objet / véhicule 3D", onClick = { open(CreatureKind.ENTITY, null) }, modifier = Modifier.weight(1f))
                                GoldOutlineButton("🪄 Image → 3D", onClick = { open(CreatureKind.CHARACTER, null) }, modifier = Modifier.weight(1f))
                            }
                            if (showTemplates) {
                                Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("Partir d'un modèle — copie modifiable à volonté", color = AgwColors.GoldSoft, fontWeight = FontWeight.SemiBold)
                                        CREATURE_TEMPLATES.forEach { t ->
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth()
                                                    .border(1.dp, AgwColors.Sand.copy(alpha = .25f), RoundedCornerShape(8.dp))
                                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Column(Modifier.weight(1f)) {
                                                    Text(t.name, color = AgwColors.PaleMarble, fontWeight = FontWeight.SemiBold)
                                                    Text(t.description, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                                                }
                                                TextButton(onClick = {
                                                    if (!hasProject) onMessage("Ouvrez un projet d'abord")
                                                    else { showTemplates = false; onCreateFromTemplate(t) }
                                                }) { Text("Créer", color = AgwColors.SacredGold) }
                                            }
                                        }
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                CreatureFilter.entries.forEach { f ->
                                    val n = when (f) {
                                        CreatureFilter.ALL -> mobs.size + entities.size + characters.size
                                        CreatureFilter.MOBS -> mobs.size
                                        CreatureFilter.ENTITIES -> entities.size
                                        CreatureFilter.CHARACTERS -> characters.size
                                    }
                                    FilterChip(selected = filter == f, onClick = { onFilter(f) }, label = { Text("${f.label} ($n)") })
                                }
                            }
                            if (rows.isEmpty()) Text(
                                if (!hasProject) "Ouvre un projet pour créer des créatures." else "Rien ici pour l'instant : crée ta première créature ci-dessus.",
                                color = AgwColors.Sand
                            )
                        }
                    }
                    items(rows, key = { "${it.first}:${it.second}" }) { (kind, id) ->
                        when (kind) {
                            CreatureKind.MOB -> mobs.firstOrNull { it.id == id }?.let { m ->
                                CreatureCard(
                                    thumb = rememberCreaturePreview(m, bodyVersion), icon = "👹",
                                    title = m.nom,
                                    subtitle = "Monstre · ${m.identifiant} · ❤ ${m.vie} · ⚔ ${m.degats}",
                                    detail = if (m.id in bodyIds) "🧬 Corps 3D CreatureStudio" else "Forme Minecraft : ${m.formeBase}",
                                    detailColor = if (m.id in bodyIds) AgwColors.Success else AgwColors.DesertOchre,
                                    extra = animLine(m),
                                    onClick = { onPreview(CreatureKind.MOB, m.id) }
                                ) {
                                    TextButton(onClick = { onPreview(CreatureKind.MOB, m.id); onOpenBody(m) }) { Text("🧬 Corps 3D", fontSize = 12.sp, color = AgwColors.SacredGold) }
                                    TextButton(onClick = { open(CreatureKind.MOB, m.id) }) { Text("⚙ Fiche", fontSize = 12.sp, color = AgwColors.GoldSoft) }
                                    TextButton(onClick = { onPreview(CreatureKind.MOB, m.id); view = CreatureView.Anim(m.id) }) { Text("🎞 Anim", fontSize = 12.sp, color = AgwColors.GoldSoft) }
                                    DeleteButton(pendingDelete == m.id, onArm = { pendingDelete = m.id }) { pendingDelete = null; onDeleteMob(m) }
                                }
                            }
                            CreatureKind.ENTITY -> entities.firstOrNull { it.id == id }?.let { e ->
                                val type = when (e.type) { SceneEntityType.OBJECT -> "Objet"; SceneEntityType.CHARACTER -> "Personnage"; SceneEntityType.VEHICLE -> "Véhicule" }
                                CreatureCard(
                                    thumb = null, icon = when (e.type) { SceneEntityType.OBJECT -> "📦"; SceneEntityType.CHARACTER -> "🧍"; SceneEntityType.VEHICLE -> "🚙" },
                                    title = e.name,
                                    subtitle = "$type 3D · map : ${maps.firstOrNull { it.id == e.linkedMapId }?.name ?: "—"}",
                                    detail = e.glbName ?: "sans fichier .glb",
                                    detailColor = AgwColors.DesertOchre,
                                    onClick = { onPreview(CreatureKind.ENTITY, e.id) }
                                ) {
                                    TextButton(onClick = { open(CreatureKind.ENTITY, e.id) }) { Text("⚙ Fiche", fontSize = 12.sp, color = AgwColors.GoldSoft) }
                                    DeleteButton(pendingDelete == e.id, onArm = { pendingDelete = e.id }) { pendingDelete = null; onDeleteEntity(e) }
                                }
                            }
                            CreatureKind.CHARACTER -> characters.firstOrNull { it.id == id }?.let { c ->
                                CreatureCard(
                                    thumb = null, icon = "🪄",
                                    title = c.name,
                                    subtitle = "Personnage IA · ${c.status.name.lowercase().replace('_', ' ')}",
                                    detail = c.modelName?.let { "3D : $it" } ?: (c.sourceImageName?.let { "Référence : $it" } ?: "à générer"),
                                    detailColor = AgwColors.DesertOchre,
                                    onClick = { onPreview(CreatureKind.CHARACTER, c.id) }
                                ) {
                                    TextButton(onClick = { open(CreatureKind.CHARACTER, c.id) }) { Text("Ouvrir", fontSize = 12.sp, color = AgwColors.GoldSoft) }
                                    DeleteButton(pendingDelete == c.id, onArm = { pendingDelete = c.id }) { pendingDelete = null; onDeleteCharacter(c) }
                                }
                            }
                        }
                    }
                    item(key = "foot") { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

/** Suppression en deux touches (avant : un seul toucher effaçait un monstre et tout son travail). */
@Composable
private fun DeleteButton(armed: Boolean, onArm: () -> Unit, onConfirm: () -> Unit) {
    TextButton(onClick = { if (armed) onConfirm() else onArm() }) {
        Text(if (armed) "Confirmer ?" else "🗑", fontSize = 12.sp, color = Color(0xFFB94E48))
    }
}

@Composable
private fun CreatureCard(
    thumb: ImageBitmap?,
    icon: String,
    title: String,
    subtitle: String,
    detail: String,
    detailColor: Color,
    extra: String? = null,
    onClick: () -> Unit,
    actions: @Composable RowScope.() -> Unit
) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    Modifier.size(56.dp)
                        .background(AgwColors.DeepNight, RoundedCornerShape(8.dp))
                        .border(1.dp, AgwColors.SacredGold.copy(alpha = .6f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (thumb != null) Image(thumb, contentDescription = title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().padding(2.dp))
                    else Text(icon, fontSize = 24.sp)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    TextButton(onClick = onClick, contentPadding = PaddingValues(0.dp)) {
                        Text(title, color = AgwColors.PaleMarble, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(subtitle, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(detail, color = detailColor, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (extra != null) Text(extra, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), content = actions)
        }
    }
}
