package com.sbh.studio.mapeditor

import android.content.Context
import com.sbh.studio.data.SafeStore
import com.sbh.studio.workshop.MapBlueprint
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import java.io.File

/**
 * Stockage de Map Studio, SÉPARÉ PAR PROJET (V1.8.60).
 *
 * Avant : une seule sauvegarde « mcms_save » dans le navigateur interne, commune à tous les
 * projets ; les exports partaient dans files/map_exports/ que rien ne relisait ; les objets .glb
 * n'étaient jamais conservés ; les régions AGW étaient un fichier unique pour toute l'app.
 *
 * Arborescence : files/map_studio/<projet>/
 *   state_autosave.json · state_manual.json   → état complet de l'éditeur (monde + objets)
 *   objects/<clé>.glb                         → modèles 3D importés (rechargés par URL)
 *   maps/<mapId>.json                         → maps envoyées à l'Atelier (+ fonctions Bedrock)
 *   regions.json                              → régions AGW de la Fondation du projet
 *
 * Le dossier map_studio est servi à la WebView sous [URL_BASE] (lecture seule) : les .glb sont
 * chargés par fetch() au lieu de traverser le pont JavaScript en base64.
 */
object MapStudioStore {
    const val URL_PATH = "/mapfiles/"
    const val URL_BASE = "https://appassets.androidplatform.net/mapfiles/"
    private val json = Json { ignoreUnknownKeys = true }

    /** Identifiant sûr pour un nom de dossier / de fichier. */
    fun safeId(raw: String): String =
        raw.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80).ifBlank { "global" }

    fun root(context: Context): File = File(context.filesDir, "map_studio")
    fun projectDir(context: Context, projectId: String): File = File(root(context), safeId(projectId))

    fun stateFile(context: Context, projectId: String, slot: String): File =
        File(projectDir(context, projectId), "state_${safeId(slot)}.json")

    fun objectFile(context: Context, projectId: String, key: String): File =
        File(File(projectDir(context, projectId), "objects"), "${safeId(key)}.glb")

    fun objectUrl(projectId: String, key: String): String =
        "$URL_BASE${safeId(projectId)}/objects/${safeId(key)}.glb"

    fun mapFile(context: Context, projectId: String, mapId: String): File =
        File(File(projectDir(context, projectId), "maps"), "${safeId(mapId)}.json")

    fun regionsFile(context: Context, projectId: String): File =
        File(projectDir(context, projectId), "regions.json")

    fun saveState(context: Context, projectId: String, slot: String, content: String): Boolean = try {
        SafeStore.write(stateFile(context, projectId, slot), content); true
    } catch (e: Exception) {
        android.util.Log.e("MapStudioStore", "Sauvegarde Map Studio impossible", e); false
    }

    fun loadState(context: Context, projectId: String, slot: String): String =
        try { SafeStore.readText(stateFile(context, projectId, slot)) ?: "" } catch (e: Exception) { "" }

    fun saveObject(context: Context, projectId: String, key: String, bytes: ByteArray): Boolean = try {
        val f = objectFile(context, projectId, key)
        f.parentFile?.mkdirs()
        f.writeBytes(bytes)
        f.length() == bytes.size.toLong()
    } catch (e: Exception) {
        android.util.Log.e("MapStudioStore", "Objet .glb non enregistré", e); false
    }

    fun hasObject(context: Context, projectId: String, key: String): Boolean =
        objectFile(context, projectId, key).let { it.exists() && it.length() > 0 }

    fun hasMap(context: Context, projectId: String, mapId: String): Boolean =
        mapFile(context, projectId, mapId).exists()

    fun loadMap(context: Context, projectId: String, mapId: String): String =
        try { SafeStore.readText(mapFile(context, projectId, mapId)) ?: "" } catch (e: Exception) { "" }

    fun saveMap(context: Context, projectId: String, mapId: String, content: String) =
        SafeStore.write(mapFile(context, projectId, mapId), content)

    /** Fonctions Bedrock (texte complet de chaque fichier .mcfunction) d'une map de l'Atelier. */
    fun bedrockFunctions(context: Context, projectId: String, mapId: String): List<String> =
        bedrockFunctionsFromJson(loadMap(context, projectId, mapId))

    // ───────────────── V1.8.61 : fusion zone Maps + Map Studio ─────────────────

    /** Fiches (MapBlueprint) ↔ JSON pour la page : TOUS les champs, valeurs par défaut comprises. */
    val blueprintJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    /** Vue du dessus de la map (PNG), affichée dans la zone Maps de l'Atelier. */
    fun previewFile(context: Context, projectId: String, mapId: String): File =
        File(File(projectDir(context, projectId), "maps"), "${safeId(mapId)}.png")

    fun savePreview(context: Context, projectId: String, mapId: String, pngBase64: String): Boolean = try {
        if (pngBase64.isBlank()) false else {
            val f = previewFile(context, projectId, mapId)
            f.parentFile?.mkdirs()
            f.writeBytes(android.util.Base64.decode(pngBase64, android.util.Base64.DEFAULT))
            true
        }
    } catch (e: Exception) { false }

    private fun lastMapFile(context: Context, projectId: String) = File(projectDir(context, projectId), "last_map.txt")
    fun lastMapId(context: Context, projectId: String): String? =
        try { lastMapFile(context, projectId).takeIf { it.exists() }?.readText()?.trim()?.ifBlank { null } } catch (e: Exception) { null }
    fun setLastMap(context: Context, projectId: String, mapId: String) {
        try { lastMapFile(context, projectId).also { it.parentFile?.mkdirs() }.writeText(mapId) } catch (e: Exception) { }
    }

    /** Structures importées dans l'ANCIENNE zone Maps (files/structures/<mapId>_*.json), pour les poser. */
    fun legacyStructures(context: Context, mapId: String): List<Pair<String, String>> {
        val dir = File(context.filesDir, "structures")
        val prefix = "${mapId}_"
        return dir.listFiles()?.filter { it.name.startsWith(prefix) && it.name.endsWith(".json") }
            ?.sortedBy { it.name }
            ?.mapNotNull { f -> try { f.name.removePrefix(prefix).removeSuffix(".json") to f.readText() } catch (e: Exception) { null } }
            ?: emptyList()
    }

    /** L'ancienne zone Maps notait la maison de forgeron dans les notes au lieu de la poser. */
    fun hasForgeNote(m: MapBlueprint): Boolean =
        m.notes.contains("maison_forgeron", ignoreCase = true) || m.notes.contains("Maison du forgeron", ignoreCase = true)

    /**
     * Fiche modifiée dans Map Studio → fiche enregistrée. Identité (id, projet) et tailles restent
     * celles de l'Atelier : les tailles viennent du contenu réel (enregistré avec la map).
     */
    fun applyFiche(existing: MapBlueprint, incoming: MapBlueprint): MapBlueprint = existing.copy(
        name = incoming.name.trim().ifBlank { existing.name }.take(60),
        terrain = incoming.terrain.take(60),
        dimension = incoming.dimension.trim().ifBlank { "minecraft:overworld" },
        seed = incoming.seed,
        worldX = incoming.worldX,
        worldZ = incoming.worldZ,
        hasVillage = incoming.hasVillage,
        hasDungeon = incoming.hasDungeon,
        hasOasis = incoming.hasOasis,
        hasMountains = incoming.hasMountains,
        hasRoads = incoming.hasRoads,
        linkedMobIds = incoming.linkedMobIds.distinct(),
        linkedItemIds = incoming.linkedItemIds.distinct(),
        linkedBlockIds = incoming.linkedBlockIds.distinct(),
        worldFilterTextureId = incoming.worldFilterTextureId,
        notes = incoming.notes.take(4000)
    )

    /**
     * V1.8.60 gardait UNE sauvegarde automatique par projet (state_autosave.json). Elle devient une
     * vraie map de l'Atelier (ou met à jour la map à laquelle elle était liée), une seule fois.
     * Retourne la liste des maps à jour.
     */
    fun migrateLegacyAutosave(context: Context, projectId: String, maps: List<MapBlueprint>): List<MapBlueprint>? {
        val f = stateFile(context, projectId, "autosave")
        if (!f.exists()) return null
        return try {
            val text = f.readText()
            val info = parseExport(text) ?: run { f.renameTo(File(f.parentFile, "state_autosave.illisible.json")); return null }
            val linked = info.atelierMapId?.let { id -> maps.firstOrNull { it.id == id && it.projectId == projectId } }
            val mapId: String
            val result: List<MapBlueprint>
            if (linked != null) {
                mapId = linked.id
                val current = mapFile(context, projectId, mapId)
                // la sauvegarde auto ne remplace le contenu de la map que si elle est plus récente
                if (!current.exists() || f.lastModified() > current.lastModified()) saveMap(context, projectId, mapId, text)
                result = maps
            } else {
                mapId = java.util.UUID.randomUUID().toString()
                saveMap(context, projectId, mapId, text)
                result = upsertMap(maps, projectId, mapId, info.copy(name = "${info.name} (récupérée)".take(60)))
            }
            f.renameTo(File(f.parentFile, "state_autosave.migrated.json"))
            result
        } catch (e: Exception) {
            android.util.Log.w("MapStudioStore", "Migration de l'ancienne sauvegarde impossible", e)
            null
        }
    }

    // ───────────────────────── Fonctions pures (testées) ─────────────────────────

    /** Données utiles d'un export Map Studio. */
    data class ExportInfo(
        val atelierMapId: String?,
        val name: String,
        val sizeX: Int,
        val sizeY: Int,
        val sizeZ: Int,
        val functionCount: Int
    )

    /** Lit l'en-tête d'un export Map Studio ; null si ce n'est pas un export valide. */
    fun parseExport(text: String): ExportInfo? = try {
        val o = json.parseToJsonElement(text) as JsonObject
        val fmt = (o["format"] as? JsonPrimitive)?.contentOrNull
        if (fmt != "sbh-map-studio") null else {
            val size = o["size"] as? JsonArray
            val sx = (size?.getOrNull(0) as? JsonPrimitive)?.intOrNull
            val sy = (size?.getOrNull(1) as? JsonPrimitive)?.intOrNull
            val sz = (size?.getOrNull(2) as? JsonPrimitive)?.intOrNull
            if (sx == null || sy == null || sz == null || sx !in 1..256 || sy !in 1..256 || sz !in 1..256) null
            else ExportInfo(
                atelierMapId = (o["atelierMapId"] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() },
                name = ((o["name"] as? JsonPrimitive)?.contentOrNull ?: "").trim().ifBlank { "Map Studio" }.take(60),
                sizeX = sx, sizeY = sy, sizeZ = sz,
                functionCount = bedrockFunctionsFromJson(text).size
            )
        }
    } catch (e: Exception) { null }

    fun bedrockFunctionsFromJson(text: String): List<String> = try {
        if (text.isBlank()) emptyList() else {
            val o = json.parseToJsonElement(text) as JsonObject
            val arr = (o["bedrock"] as? JsonObject)?.get("functions") as? JsonArray
            arr?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }?.filter { it.isNotBlank() } ?: emptyList()
        }
    } catch (e: Exception) { emptyList() }

    /**
     * Crée ou met à jour la MapBlueprint correspondant à un export Map Studio.
     * Une map existante garde ses réglages (thème, mobs liés, notes…) : seuls nom et tailles changent.
     */
    fun upsertMap(
        existing: List<MapBlueprint>,
        projectId: String,
        mapId: String,
        info: ExportInfo
    ): List<MapBlueprint> {
        val idx = existing.indexOfFirst { it.id == mapId }
        return if (idx >= 0) {
            existing.toMutableList().also {
                it[idx] = it[idx].copy(name = info.name, sizeX = info.sizeX, sizeZ = info.sizeZ, height = info.sizeY)
            }
        } else {
            existing + MapBlueprint(
                id = mapId,
                projectId = projectId,
                name = info.name,
                sizeX = info.sizeX,
                sizeZ = info.sizeZ,
                height = info.sizeY,
                terrain = "map_studio",
                hasVillage = false,
                hasDungeon = false,
                hasOasis = false,
                notes = "Construite dans Map Studio"
            )
        }
    }

    /**
     * Dossier des fonctions d'une map dans le Behavior Pack : sbh_map/<nom> (minuscules, chiffres, _).
     * [taken] évite que deux maps de même nom écrivent dans le même dossier.
     */
    fun functionFolder(mapName: String, mapId: String, taken: Set<String>): String {
        val base = mapName.lowercase()
            .replace(Regex("[àâä]"), "a").replace(Regex("[éèêë]"), "e").replace(Regex("[îï]"), "i")
            .replace(Regex("[ôö]"), "o").replace(Regex("[ùûü]"), "u").replace("ç", "c")
            .replace(Regex("[^a-z0-9_]"), "_").replace(Regex("_+"), "_").trim('_').take(32)
            .ifBlank { "map_" + safeId(mapId).lowercase().take(6) }
        var candidate = base
        var n = 2
        while (candidate in taken) { candidate = "${base}_$n"; n++ }
        return candidate
    }
}
