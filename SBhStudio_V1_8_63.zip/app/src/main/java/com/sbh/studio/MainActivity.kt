package com.sbh.studio

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.*
import com.sbh.studio.generator.AdvancedPackEngine
import com.sbh.studio.workshop.WorkshopRepository
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AgwTheme
import com.sbh.studio.ui.HomeAtmosphereBackground
import com.sbh.studio.ui.StudioBrandHeader
import com.sbh.studio.ui.rememberAssetBitmap
import com.sbh.studio.ui.AppLang
import com.sbh.studio.ui.S
import com.sbh.studio.ui.UpdateScreen
import com.sbh.studio.ui.ReportsScreen
import com.sbh.studio.debug.DebugScreen
import com.sbh.studio.system.SystemLog
import com.sbh.studio.texture.TextureScreen
import com.sbh.studio.animation.AnimationScreen
import com.sbh.studio.ui.AudioStudioScreen
import com.sbh.studio.ui.AiScreen
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.ModeIconTile
import com.sbh.studio.ui.SectionTitle
import com.sbh.studio.ui.GoldDivider
import com.sbh.studio.ui.IconBadge
import com.sbh.studio.ui.NavAssetIcon
import com.sbh.studio.ui.StatusPill
import com.sbh.studio.ui.ForgeStatusRow
import com.sbh.studio.ui.ForgeMetric
import com.sbh.studio.ui.ForgeSectionCard
import com.sbh.studio.ui.AgwDecor
import com.sbh.studio.workshop.WorkshopScreen
import com.sbh.studio.mapeditor.MapEditorScreen
import com.sbh.studio.character.GraphicsSafety
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SystemLog.init(this)
        installGraphicsCrashGuard()
        setContent { SbhStudioApp() }
    }

    /**
     * Si un crash JVM mentionne Filament/SceneView, désactive l'aperçu 3D Character
     * pour le prochain lancement (évite la boucle de plantage au redémarrage).
     * Ne couvre pas les SIGSEGV purs (natifs), mais limite les Exception Java associées.
     */
    private fun installGraphicsCrashGuard() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            val stack = throwable.stackTraceToString()
            if (GraphicsSafety.looksLikeGraphicsCrash(stack)) {
                try {
                    GraphicsSafety.setCharacter3dDisabled(applicationContext, true)
                    // V1.8.58 (build) : SystemLog.e attend (module, message, erreur) — l'appel de la 1.8.55
                    // ne passait qu'un seul texte et empêchait la compilation.
                    SystemLog.e("MainActivity", "Graphics crash détecté — aperçu 3D Character désactivé: ${throwable.message}", throwable)
                } catch (e: Exception) { android.util.Log.w("MainActivity", "GraphicsSafety flag write failed", e) }
            }
            previous?.uncaughtException(thread, throwable)
        }
    }
}

private sealed class Screen {
    data object Home : Screen()
    data class Project(val id: String) : Screen()
    data class Mob(val projectId: String, val id: String?) : Screen()
    data class Item(val projectId: String, val id: String?) : Screen()
    data class Block(val projectId: String, val id: String?) : Screen()
    data object MineEdit : Screen()
    data object Update : Screen()
    data object AgwWorld : Screen()
    data object Lore : Screen()
    data object Heroes : Screen()
    data object Bestiary : Screen()
    data object Factions : Screen()
    data object Phases : Screen()
    data object Settings : Screen()
    data object Debug : Screen()
    data object Workshop : Screen()
    /** V1.8.60 : on revient à l'écran d'origine (Atelier ou Accueil) au lieu de toujours l'Accueil. */
    data class MapEditor(
        val fromWorkshop: Boolean = false,
        /** V1.8.61 : map de l'Atelier à ouvrir (zone Maps) et action (« place_forge », « test », « forge_test »). */
        val mapId: String? = null,
        val action: String? = null
    ) : Screen()
    data object Texture : Screen()
    data class Animation(val linkedMobId: String? = null) : Screen()
    data object Reports : Screen()
    data object Audio : Screen()
    data object Ai : Screen()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SbhStudioApp() {
    val context = LocalContext.current
    val projectRepo = remember { ProjectRepository(context) }
    val mobRepo = remember { MobRepository(context) }
    val itemRepo = remember { ItemRepository(context) }
    val blockRepo = remember { BlockRepository(context) }
    val agwRepo = remember { AgwDataRepository(context) }
    val agwWorldCoreRepo = remember { AgwWorldCoreRepository(context) }

    var projects by remember { mutableStateOf(listOf(SbhProject(name = "Al-Zahra · الزهراء"))) }
    var mobs by remember { mutableStateOf(emptyList<MobEntity>()) }
    var items by remember { mutableStateOf(emptyList<SbhItem>()) }
    var blocks by remember { mutableStateOf(emptyList<SbhBlock>()) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    // V1.8.63 : zone de l'Atelier à ouvrir (Accueil → Animation ouvre Créatures)
    var workshopStartZone by remember { mutableStateOf<com.sbh.studio.workshop.WorkshopZoneId?>(null) }
    var lang by remember { mutableStateOf(AppLang.FR) }
    var message by remember { mutableStateOf(S.t(AppLang.FR, "ready")) }
    var dialog by remember { mutableStateOf<String?>(null) }
    val appScope = rememberCoroutineScope()
    var bootReady by remember { mutableStateOf(false) }
    // V1.8.57 : projet actif partagé (Accueil → Atelier → Map Studio → IA). Avant, l'Atelier
    // prenait toujours le 1er projet de la liste, quel que soit celui ouvert.
    var activeProjectId by remember { mutableStateOf(ActiveProject.storedId(context)) }
    fun selectProject(id: String) {
        activeProjectId = id
        ActiveProject.set(context, id)
    }

    // Charge projets / contenu hors thread UI (démarrage téléphone)
    LaunchedEffect(Unit) {
        val loaded = withContext(Dispatchers.IO) {
            Triple(
                projectRepo.load().ifEmpty { listOf(SbhProject(name = "Al-Zahra · الزهراء")) },
                mobRepo.loadAll(),
                itemRepo.loadAll() to blockRepo.loadAll()
            )
        }
        projects = loaded.first
        mobs = loaded.second
        items = loaded.third.first
        blocks = loaded.third.second
        bootReady = true
    }

    // V1.8.56 : l'Atelier, l'écran Animation, l'IA et l'import manuel modifient aussi ces fichiers.
    // Avant, ces listes n'étaient lues qu'au démarrage : revenir sur un projet puis ajouter ou
    // supprimer un mob réécrivait l'ancienne liste et effaçait tout ce qui avait été créé ailleurs
    // depuis le lancement (et l'export du projet ignorait ces créations). On relit donc le disque
    // à chaque retour sur l'Accueil ou sur un projet.
    LaunchedEffect(screen, bootReady) {
        if (!bootReady) return@LaunchedEffect
        val s = screen
        if (s is Screen.Home || s is Screen.Project) {
            val fresh = withContext(Dispatchers.IO) {
                Triple(mobRepo.loadAll(), itemRepo.loadAll(), blockRepo.loadAll())
            }
            mobs = fresh.first
            items = fresh.second
            blocks = fresh.third
        }
    }

    // Avant la fin du chargement initial, une sauvegarde aurait écrasé le fichier avec la
    // liste par défaut (perte de tous les projets) : on l'ignore et on prévient.
    fun guardBoot(): Boolean {
        if (!bootReady) message = "Chargement en cours… réessayez dans un instant."
        return bootReady
    }
    // V1.8.57 : une sauvegarde qui échoue (stockage plein, fichier verrouillé…) faisait planter
    // l'application (exception non interceptée dans la coroutine). On prévient l'utilisateur.
    fun persist(label: String, block: () -> Unit) {
        appScope.launch(Dispatchers.IO) {
            try {
                block()
            } catch (e: Exception) {
                android.util.Log.e("SbhStudioApp", "Sauvegarde $label impossible", e)
                withContext(Dispatchers.Main) {
                    dialog = "Sauvegarde $label impossible : ${e.message ?: "erreur inconnue"}\n" +
                        "Vérifiez l'espace de stockage disponible. Vos dernières modifications ne sont peut-être pas enregistrées."
                }
            }
        }
    }
    fun saveProjects(v: List<SbhProject>) { if (!guardBoot()) return; projects = v; persist("des projets") { projectRepo.save(v) } }
    fun saveMobs(v: List<MobEntity>) { if (!guardBoot()) return; mobs = v; persist("des mobs") { mobRepo.saveAll(v) } }
    fun saveItems(v: List<SbhItem>) { if (!guardBoot()) return; items = v; persist("des items") { itemRepo.saveAll(v) } }
    fun saveBlocks(v: List<SbhBlock>) { if (!guardBoot()) return; blocks = v; persist("des blocs") { blockRepo.saveAll(v) } }

    var exporting by remember { mutableStateOf(false) }

    fun exportResult(report: AdvancedPackEngine.BuildReport) {
        try {
            if (!report.ok || report.file == null) {
                dialog = (report.errors + report.warnings).joinToString("\n").ifBlank { "Export failed" }
                return
            }
            val file = report.file
            // Transmission réelle : Intent ACTION_VIEW + MIME application/mcaddon.
            // Le résultat d'import Minecraft n'est pas observable → IMPORT_UNKNOWN.
            val core = com.sbh.studio.communication.SBhCommunicationCore(context)
            val tx = com.sbh.studio.communication.SBhTransmitter.transmitMcaddon(
                context, file, S.t(lang, "export")
            )
            report.sbhReport?.let { sbh ->
                com.sbh.studio.communication.SBhTransmitter.recordTransmission(core, sbh, tx)
            }
            if (tx.launched) {
                message = "OK ${file.name} — import Minecraft non confirmable"
            } else {
                dialog = tx.detail
            }
        } catch (e: Exception) {
            dialog = e.message ?: "Export error"
        }
    }

    // Export : la génération (zip, textures, bitmaps) tourne maintenant hors du thread UI
    // (avant : écran figé, voire « l'application ne répond pas » sur téléphone).
    fun export(p: SbhProject) {
        if (exporting) return
        exporting = true
        message = "Export en cours…"
        appScope.launch {
            try {
                val report = withContext(Dispatchers.IO) {
                    val engine = AdvancedPackEngine(context)
                    val ws = WorkshopRepository(context)
                    engine.exportAdvanced(
                        p,
                        mobRepo.loadAll().filter { it.projectId == p.id },
                        itemRepo.loadAll().filter { it.projectId == p.id },
                        blockRepo.loadAll().filter { it.projectId == p.id },
                        ws.loadPortals().filter { it.projectId == p.id },
                        ws.loadMaps().filter { it.projectId == p.id },
                        ws.loadRecipes().filter { it.projectId == p.id }
                    )
                }
                exportResult(report)
            } catch (e: Exception) {
                dialog = e.message ?: "Export error"
            } finally {
                exporting = false
            }
        }
    }

    val dir = if (lang == AppLang.AR) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        AgwTheme(dark = true) {
            // Écrans "racine" : la barre de navigation du bas y est visible.
            // Les écrans de détail (projet ouvert, éditeurs, fiches Univers...)
            // restent en plein écran avec juste une flèche retour, comme avant.
            val bottomNavScreens = setOf(Screen.Home, Screen.Workshop, Screen.AgwWorld, Screen.Update, Screen.Audio, Screen.Ai)
            Scaffold(
                containerColor = AgwColors.DeepNight,
                bottomBar = {
                    if (screen in bottomNavScreens) {
                        NavigationBar(
                            containerColor = AgwColors.NightStone,
                            contentColor = AgwColors.PaleMarble
                        ) {
                            NavigationBarItem(
                                selected = screen == Screen.Home,
                                onClick = { screen = Screen.Home },
                                icon = { NavAssetIcon("branding/icons/icon_hub.png", screen == Screen.Home) },
                                label = { Text(S.t(lang, "home")) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AgwColors.SacredGold,
                                    selectedTextColor = AgwColors.SacredGold,
                                    indicatorColor = AgwColors.SacredGold.copy(alpha = 0.18f),
                                    unselectedIconColor = AgwColors.Sand,
                                    unselectedTextColor = AgwColors.Sand
                                )
                            )
                            NavigationBarItem(
                                selected = screen == Screen.Workshop,
                                onClick = { workshopStartZone = null; screen = Screen.Workshop },
                                icon = { NavAssetIcon("branding/icons/icon_workshop.png", screen == Screen.Workshop) },
                                label = { Text(S.t(lang, "workshop")) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AgwColors.SacredGold,
                                    selectedTextColor = AgwColors.SacredGold,
                                    indicatorColor = AgwColors.SacredGold.copy(alpha = 0.18f),
                                    unselectedIconColor = AgwColors.Sand,
                                    unselectedTextColor = AgwColors.Sand
                                )
                            )
                            NavigationBarItem(
                                selected = screen == Screen.AgwWorld,
                                onClick = { screen = Screen.AgwWorld },
                                icon = { NavAssetIcon("branding/icons/icon_world.png", screen == Screen.AgwWorld) },
                                label = { Text(S.t(lang, "world_agw")) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AgwColors.SacredGold,
                                    selectedTextColor = AgwColors.SacredGold,
                                    indicatorColor = AgwColors.SacredGold.copy(alpha = 0.18f),
                                    unselectedIconColor = AgwColors.Sand,
                                    unselectedTextColor = AgwColors.Sand
                                )
                            )
                            NavigationBarItem(
                                selected = screen == Screen.Audio,
                                onClick = { screen = Screen.Audio },
                                icon = { Text("♫", color = if (screen == Screen.Audio) AgwColors.SacredGold else AgwColors.Sand) },
                                label = { Text("نشيد") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AgwColors.SacredGold,
                                    selectedTextColor = AgwColors.SacredGold,
                                    indicatorColor = AgwColors.SacredGold.copy(alpha = 0.18f),
                                    unselectedIconColor = AgwColors.Sand,
                                    unselectedTextColor = AgwColors.Sand
                                )
                            )
                            NavigationBarItem(
                                selected = screen == Screen.Ai,
                                onClick = { screen = Screen.Ai },
                                icon = { Text("🧠", color = if (screen == Screen.Ai) AgwColors.SacredGold else AgwColors.Sand) },
                                label = { Text("IA") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AgwColors.SacredGold,
                                    selectedTextColor = AgwColors.SacredGold,
                                    indicatorColor = AgwColors.SacredGold.copy(alpha = 0.18f),
                                    unselectedIconColor = AgwColors.Sand,
                                    unselectedTextColor = AgwColors.Sand
                                )
                            )
                            NavigationBarItem(
                                selected = screen == Screen.Update,
                                onClick = { screen = Screen.Update },
                                icon = { NavAssetIcon("branding/icons/icon_updates.png", screen == Screen.Update) },
                                label = { Text(S.t(lang, "updates")) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AgwColors.SacredGold,
                                    selectedTextColor = AgwColors.SacredGold,
                                    indicatorColor = AgwColors.SacredGold.copy(alpha = 0.18f),
                                    unselectedIconColor = AgwColors.Sand,
                                    unselectedTextColor = AgwColors.Sand
                                )
                            )
                        }
                    }
                }
            ) { innerPadding ->
            // Padding bas uniquement : les écrans ont déjà leur propre TopAppBar / Scaffold
            Box(Modifier.fillMaxSize().padding(bottom = innerPadding.calculateBottomPadding())) {
            when (val s = screen) {
                Screen.Home -> HomeScreen(
                    lang, projects, message,
                    activeProjectId = ActiveProject.resolve(context, projects)?.id,
                    onNewProject = {
                        val n = projects.size + 1
                        saveProjects(projects + SbhProject(name = "مشروع $n · Projet $n"))
                        message = S.t(lang, "new_project")
                    },
                    onOpenProject = { selectProject(it.id); screen = Screen.Project(it.id) },
                    onSaveProject = { p ->
                        saveProjects(projects.map {
                            if (it.id == p.id) it.copy(
                                status = "Sauvegarde",
                                versionHistory = it.versionHistory + "v${it.versionHistory.size + 1}"
                            ) else it
                        })
                        message = S.t(lang, "save")
                    },
                    onAgw = { screen = Screen.AgwWorld },
                    onLore = { screen = Screen.Lore },
                    onHeroes = { screen = Screen.Heroes },
                    onBestiary = { screen = Screen.Bestiary },
                    onFactions = { screen = Screen.Factions },
                    onPhases = { screen = Screen.Phases },
                    onMine = { screen = Screen.MineEdit },
                    onUpdate = { screen = Screen.Update },
                    onSettings = { screen = Screen.Settings },
                    onWorkshop = { workshopStartZone = null; screen = Screen.Workshop },
                    onMapEditor = { screen = Screen.MapEditor() },
                    onTexture = { screen = Screen.Texture },
                    // V1.8.63 : l'animation des monstres se fait dans Atelier → Créatures (🎞)
                    onAnimation = {
                        workshopStartZone = com.sbh.studio.workshop.WorkshopZoneId.MOBS
                        message = "Animation : choisis un monstre dans Créatures puis touche 🎞"
                        screen = Screen.Workshop
                    },
                    onReports = { screen = Screen.Reports },
                    onAudio = { screen = Screen.Audio }
                )
                is Screen.Project -> {
                    val p = projects.find { it.id == s.id }
                    if (p == null) screen = Screen.Home
                    else ProjectDetail(
                        lang, p,
                        mobs.filter { it.projectId == p.id },
                        items.filter { it.projectId == p.id },
                        blocks.filter { it.projectId == p.id },
                        { screen = Screen.Home },
                        { screen = Screen.Mob(p.id, null) },
                        { screen = Screen.Item(p.id, null) },
                        { screen = Screen.Block(p.id, null) },
                        { m -> saveMobs(mobs - m) },
                        { i -> saveItems(items - i) },
                        { b -> saveBlocks(blocks - b) },
                        { export(p) }
                    )
                }
                is Screen.Mob -> MobEditor(s.projectId, mobs.find { it.id == s.id }, { screen = Screen.Project(s.projectId) }) { m ->
                    saveMobs(if (s.id == null) mobs + m else mobs.map { if (it.id == m.id) m else it })
                    screen = Screen.Project(s.projectId)
                }
                is Screen.Item -> ItemEditor(s.projectId, items.find { it.id == s.id }, { screen = Screen.Project(s.projectId) }) { i ->
                    saveItems(if (s.id == null) items + i else items.map { if (it.id == i.id) i else it })
                    screen = Screen.Project(s.projectId)
                }
                is Screen.Block -> BlockEditor(s.projectId, blocks.find { it.id == s.id }, { screen = Screen.Project(s.projectId) }) { b ->
                    saveBlocks(if (s.id == null) blocks + b else blocks.map { if (it.id == b.id) b else it })
                    screen = Screen.Project(s.projectId)
                }
                Screen.MineEdit -> MineEdit({ screen = Screen.Home }) { message = it }
                Screen.Update -> UpdateScreen { screen = Screen.Home }
                Screen.AgwWorld -> AgwWorldScreen(lang, agwRepo, agwWorldCoreRepo) { screen = Screen.Home }
                Screen.Lore -> LoreScreen(lang, agwRepo) { screen = Screen.Home }
                Screen.Heroes -> HeroesScreen(lang, agwRepo) { screen = Screen.Home }
                Screen.Bestiary -> BestiaryScreen(lang, agwRepo) { screen = Screen.Home }
                Screen.Factions -> FactionsScreen(lang, agwRepo) { screen = Screen.Home }
                Screen.Phases -> PhasesScreen(lang, agwRepo) { screen = Screen.Home }
                Screen.Settings -> SettingsScreen(
                    lang = lang,
                    onLang = { lang = it; message = S.t(it, "ready") },
                    onOpenDebug = { screen = Screen.Debug },
                    back = { screen = Screen.Home }
                )
                Screen.Debug -> DebugScreen(
                    onBack = { screen = Screen.Settings },
                    onMessage = { message = it }
                )
                Screen.Workshop -> WorkshopScreen(
                    projects.firstOrNull { it.id == activeProjectId } ?: projects.firstOrNull(),
                    { screen = Screen.Home },
                    allProjects = projects,
                    onSelectProject = { selectProject(it) },
                    onMessage = { message = it },
                    onOpenMapEditor = { mapId, action -> screen = Screen.MapEditor(fromWorkshop = true, mapId = mapId, action = action) },
                    onOpenAnimation = { mobId -> screen = Screen.Animation(mobId) },
                    initialZone = workshopStartZone,
                    onInitialZoneUsed = { workshopStartZone = null }
                )
                is Screen.MapEditor -> MapEditorScreen(
                    mapId = s.mapId,
                    action = s.action,
                    onBack = { screen = if (s.fromWorkshop) Screen.Workshop else Screen.Home },
                    onMapExported = { name ->
                        message = "Map « $name » enregistrée dans l'Atelier"
                    }
                )
                Screen.Texture -> TextureScreen(
                    onBack = { screen = Screen.Home },
                    onMessage = { message = it }
                )
                is Screen.Animation -> {
                    val animScreen = screen as Screen.Animation
                    AnimationScreen(
                        onBack = { screen = Screen.Home },
                        onMessage = { message = it },
                        initialLinkedMobId = animScreen.linkedMobId
                    )
                }
                Screen.Reports -> ReportsScreen(onBack = { screen = Screen.Home })
                Screen.Audio -> AudioStudioScreen(back = { screen = Screen.Home })
                Screen.Ai -> AiScreen(back = { screen = Screen.Home })
            }
            dialog?.let { d ->
                AlertDialog(
                    onDismissRequest = { dialog = null },
                    confirmButton = { TextButton({ dialog = null }) { Text("OK") } },
                    title = { Text("SBh Studio") },
                    text = { Text(d) }
                )
            }
            }
            }
        }
    }
}

private data class ArabicPoem(val verses: String, val author: String, val category: String)

@Composable
private fun ArabicPoetryCard() {
    val poems = remember {
        listOf(
            ArabicPoem("دع الأيام تفعل ما تشاء\nوطب نفسًا إذا حكم القضاء", "الإمام الشافعي", "الحكمة · الصبر"),
            ArabicPoem("ومن يتهيب صعود الجبال\nيعش أبد الدهر بين الحفر", "أبو القاسم الشابي", "العزيمة"),
            ArabicPoem("إذا غامرت في شرف مروم\nفلا تقنع بما دون النجوم", "المتنبي", "الهمة"),
            ArabicPoem("على قدر أهل العزم تأتي العزائم\nوتأتي على قدر الكرام المكارم", "المتنبي", "العزيمة · الهمة"),
            ArabicPoem("إذا أنت أكرمت الكريم ملكته\nوإن أنت أكرمت اللئيم تمردا", "المتنبي", "الأخلاق"),
            ArabicPoem("لا تحسبن المجد تمرا أنت آكله\nلن تبلغ المجد حتى تلعق الصبرا", "المتنبي", "الصبر"),
            ArabicPoem("أعز مكان في الدنى سرج سابح\nوخير جليس في الزمان كتاب", "المتنبي", "العلم"),
            ArabicPoem("وما نيل المطالب بالتمني\nولكن تؤخذ الدنيا غلابا", "أحمد شوقي", "العزيمة"),
            ArabicPoem("وطني لو شغلت بالخلد عنه\nنازعتني إليه في الخلد نفسي", "أحمد شوقي", "الوطن"),
            ArabicPoem("إنما الأمم الأخلاق ما بقيت\nفإن هم ذهبت أخلاقهم ذهبوا", "أحمد شوقي", "الأخلاق"),
            ArabicPoem("ومن لم يذق مر التعلم ساعة\nتجرع ذل الجهل طول حياته", "الإمام الشافعي", "العلم · الصبر"),
            ArabicPoem("رأيت القناعة رأس الغنى\nفصرت بأذيالها متمسك", "الإمام الشافعي", "القناعة"),
            ArabicPoem("إذا المرء لا يرعاك إلا تكلفا\nفدعه ولا تكثر عليه التأسفا", "الإمام الشافعي", "الحكمة"),
            ArabicPoem("وكن رجلا على الأهوال جلدا\nوشيمتك السماحة والوفاء", "المتنبي", "الشجاعة · الأخلاق")
        )
    }
    val categories = remember(poems) { listOf("الكل") + poems.flatMap { it.category.split(" · ") }.distinct() }
    var selectedCategory by rememberSaveable { mutableStateOf("الكل") }
    var index by rememberSaveable { mutableIntStateOf(0) }

    val filtered = remember(selectedCategory, poems) {
        if (selectedCategory == "الكل") poems
        else poems.filter { selectedCategory in it.category.split(" · ") }
    }
    LaunchedEffect(selectedCategory) { index = 0 }
    val poem = filtered[index.coerceIn(0, filtered.lastIndex)]

    ForgeSectionCard(title = "شِعْر عربي") {
        Text(
            "مختارات من الشعر العربي الكلاسيكي",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Right
        )
        Spacer(Modifier.height(8.dp))
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 2.dp)
        ) {
            items(categories) { category ->
                FilterChip(
                    selected = selectedCategory == category,
                    onClick = { selectedCategory = category },
                    label = { Text(category, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AgwColors.SacredGold.copy(alpha = 0.18f),
                        selectedLabelColor = AgwColors.SacredGold,
                        containerColor = AgwColors.NightGlassSoft,
                        labelColor = AgwColors.Sand
                    )
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            poem.verses,
            color = AgwColors.PaleMarble,
            fontSize = 22.sp,
            lineHeight = 36.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        Text(
            poem.author,
            color = AgwColors.SacredGold,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            poem.category,
            color = AgwColors.DesertOchre,
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
        )
        Spacer(Modifier.height(10.dp))
        GoldOutlineButton(
            text = "قصيدة أخرى",
            onClick = { index = (index + 1) % filtered.size },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "${index + 1} / ${filtered.size}",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/* StudioLogo remplacé par StudioBrandHeader (ui/Branding.kt) */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(
    lang: AppLang,
    projects: List<SbhProject>,
    message: String,
    activeProjectId: String?,
    onNewProject: () -> Unit,
    onOpenProject: (SbhProject) -> Unit,
    onSaveProject: (SbhProject) -> Unit,
    onAgw: () -> Unit,
    onLore: () -> Unit,
    onHeroes: () -> Unit,
    onBestiary: () -> Unit,
    onFactions: () -> Unit,
    onPhases: () -> Unit,
    onMine: () -> Unit,
    onUpdate: () -> Unit,
    onSettings: () -> Unit,
    onWorkshop: () -> Unit,
    onMapEditor: () -> Unit,
    onTexture: () -> Unit,
    onAnimation: () -> Unit,
    onReports: () -> Unit,
    onAudio: () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        HomeAtmosphereBackground(Modifier.fillMaxSize())
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(S.t(lang, "app_name"), fontWeight = FontWeight.Bold, color = AgwColors.GoldSoft, letterSpacing = 0.2.sp)
                            Text(
                                "HUB · " + S.t(lang, "app_subtitle"),
                                style = MaterialTheme.typography.labelSmall,
                                color = AgwColors.SilverMuted,
                                letterSpacing = 0.8.sp
                            )
                        }
                    },
                    actions = {
                        TextButton(onSettings) {
                            IconBadge("branding/icons/icon_settings.png", 28.dp)
                        }
                        TextButton(onUpdate) {
                            IconBadge("branding/icons/icon_updates.png", 28.dp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
                )
            },
            containerColor = Color.Transparent
        ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { StudioBrandHeader(lang) }
            item {
                ArabicPoetryCard()
            }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(
                        S.t(lang, "world_name"),
                        fontWeight = FontWeight.Bold,
                        color = AgwColors.SacredGold,
                        fontSize = 22.sp
                    )
                    Text(
                        S.t(lang, "tagline"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = AgwColors.PaleMarble,
                        lineHeight = 20.sp
                    )
                    if (message.isNotBlank()) {
                        Text(
                            message,
                            style = MaterialTheme.typography.bodySmall,
                            color = AgwColors.DesertOchre,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ÉTAT DU STUDIO", fontWeight = FontWeight.Bold, color = AgwColors.PaleMarble, fontSize = 13.sp)
                            Text("Prêt · Visual Workshop · Dark Forge", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        }
                        StatusPill("PRÊT")
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusPill("AGW CORE")
                        StatusPill("ATELIER")
                        StatusPill("3D VIEW")
                    }
                }
            }
            item {
                SectionTitle("Création")
                GoldDivider(Modifier.padding(bottom = 8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ModeIconTile(
                            S.t(lang, "workshop"),
                            "branding/icons/icon_workshop.png",
                            onWorkshop,
                            Modifier.weight(1f),
                            subtitle = "Atelier 3D",
                            featured = true
                        )
                        ModeIconTile(
                            "Map Studio",
                            "branding/icons/icon_map.png",
                            onMapEditor,
                            Modifier.weight(1f),
                            subtitle = "Cartes",
                            featured = true
                        )
                        ModeIconTile(
                            "Textures",
                            "branding/icons/icon_blocks.png",
                            onTexture,
                            Modifier.weight(1f),
                            subtitle = "Matériaux"
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ModeIconTile("Animation", "branding/icons/icon_mobs.png", onAnimation, Modifier.weight(1f), subtitle = "Mouvement")
                        ModeIconTile("نشيد", "branding/icons/icon_workshop.png", onAudio, Modifier.weight(1f), subtitle = "Audio")
                        ModeIconTile("Rapports", "branding/icons/icon_export.png", onReports, Modifier.weight(1f), subtitle = "Export")
                    }
                }
            }
            item {
                SectionTitle("Monde AGW")
                GoldDivider(Modifier.padding(bottom = 8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ModeIconTile(S.t(lang, "world_agw"), "branding/icons/icon_world.png", onAgw, Modifier.weight(1f), subtitle = "Core")
                        ModeIconTile(S.t(lang, "lore"), "branding/icons/icon_lore.png", onLore, Modifier.weight(1f))
                        ModeIconTile(S.t(lang, "heroes"), "branding/icons/icon_heroes.png", onHeroes, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ModeIconTile(S.t(lang, "bestiary"), "branding/icons/icon_bestiary.png", onBestiary, Modifier.weight(1f))
                        ModeIconTile(S.t(lang, "factions"), "branding/icons/icon_factions.png", onFactions, Modifier.weight(1f))
                        ModeIconTile(S.t(lang, "phases"), "branding/icons/icon_phases.png", onPhases, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ModeIconTile(S.t(lang, "mine_edit"), "branding/icons/icon_mine.png", onMine, Modifier.weight(1f), subtitle = "Édition")
                        Spacer(Modifier.weight(1f))
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SectionTitle(S.t(lang, "projects"))
                    GoldPrimaryButton(S.t(lang, "new_project"), onNewProject)
                }
            }
            if (projects.isEmpty()) {
                item { Text(S.t(lang, "no_projects"), color = AgwColors.Sand) }
            }
            items(projects) { p ->
                Card(
                    onClick = { onOpenProject(p) },
                    colors = CardDefaults.cardColors(containerColor = AgwColors.NightGlassSoft),
                    shape = AgwDecor.CardShape,
                    modifier = Modifier.fillMaxWidth().border(AgwDecor.GoldBorderStrong, AgwDecor.CardShape)
                ) {
                    Row(
                        Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                            IconBadge("branding/icons/icon_workshop.png", 42.dp)
                            Column {
                                Text(p.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble, fontSize = 15.sp)
                                Text("${p.status} · v${p.version}", style = MaterialTheme.typography.bodySmall, color = AgwColors.Sand)
                                if (p.id == activeProjectId) {
                                    Text("● Projet actif (Atelier, Map Studio, IA)", style = MaterialTheme.typography.labelSmall, color = AgwColors.SacredGold)
                                }
                            }
                        }
                        GoldOutlineButton(S.t(lang, "save"), { onSaveProject(p) })
                    }
                }
            }
            item {
                Text(
                    S.t(lang, "owl_motto"),
                    style = MaterialTheme.typography.labelMedium,
                    color = AgwColors.DesertOchre,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        }
        }
    }
}

@Composable
private fun QuickChip(label: String, onClick: () -> Unit) {
    // Conservé pour compat ; préférer ModeIconTile
    AssistChip(
        onClick = onClick,
        label = { Text(label, maxLines = 1) },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = AgwColors.NightGlass,
            labelColor = AgwColors.PaleMarble
        ),
        border = BorderStroke(1.dp, AgwColors.GoldGlass)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PageScaffold(title: String, back: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(title, color = AgwColors.SacredGold, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("SBH STUDIO · DARK FORGE", color = AgwColors.Sand, fontSize = 9.sp, letterSpacing = 1.1.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = back) {
                        Text("‹", color = AgwColors.GoldSoft, fontSize = 30.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AgwColors.NightGlass,
                    titleContentColor = AgwColors.SacredGold
                )
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp, vertical = 14.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
private fun AgwWorldScreen(lang: AppLang, repo: AgwDataRepository, worldCoreRepo: AgwWorldCoreRepository, back: () -> Unit) {
    val summary = remember { repo.summaryFr() }
    val project = remember { repo.loadProject() }
    val core = remember { worldCoreRepo.load() }
    val factions = core.nodes.count { it.type == "faction" }
    val npcs = core.nodes.count { it.type == "npc" }
    val maps = core.nodes.count { it.type == "map" }
    val portals = core.nodes.count { it.type == "portal" }
    PageScaffold(S.t(lang, "world_agw"), back) {
        ForgeSectionCard("MONDE ACTIF") {
            Text(project.name.ifBlank { S.t(lang, "world_name") }, fontWeight = FontWeight.Bold, color = AgwColors.PaleMarble, fontSize = 22.sp)
            Text(S.t(lang, "tagline"), color = AgwColors.Sand)
            Text(summary, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        }
        ForgeSectionCard("AGW WORLD CORE", trailing = { StatusPill("SYNCHRONISÉ") }) {
            Text("${core.worldName} · ${core.nodes.size} nœuds", color = AgwColors.PaleMarble)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ForgeMetric(factions.toString(), "FACTIONS", Modifier.weight(1f))
                ForgeMetric(npcs.toString(), "PNJ", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ForgeMetric(maps.toString(), "MAPS", Modifier.weight(1f))
                ForgeMetric(portals.toString(), "PORTAILS", Modifier.weight(1f))
            }
        }
        ForgeSectionCard("PIPELINE SBH") {
            ForgeStatusRow("AGW World Core", "Contrat partagé et données du monde", "OK")
            ForgeStatusRow("Map Atelier", "Projection des cartes vers le Core", if (maps > 0) "PRÊT" else "EN ATTENTE", maps > 0)
            ForgeStatusRow("SBH World", "Runtime Godot", "PRÉPARATION", false)
        }
        Text("Prefix ${project.prefix} · World ID ${core.worldId}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun LoreScreen(lang: AppLang, repo: AgwDataRepository, back: () -> Unit) {
    val lore = remember { repo.loadLore() }
    val key = if (lang == AppLang.EN) "en" else "fr"
    PageScaffold(S.t(lang, "lore"), back) {
        Text(
            lore.world_name[key] ?: S.t(lang, "world_name"),
            fontWeight = FontWeight.Bold,
            color = AgwColors.SacredGold,
            fontSize = 22.sp
        )
        Text(
            lore.tagline[key] ?: S.t(lang, "tagline"),
            color = AgwColors.PaleMarble,
            style = MaterialTheme.typography.bodyMedium,
            lineHeight = 20.sp
        )
        if (!lore.setting[key].isNullOrBlank()) {
            Text(
                lore.setting[key] ?: "",
                color = AgwColors.Sand,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        if (!lore.core_promise[key].isNullOrBlank()) {
            Text(
                lore.core_promise[key] ?: "",
                fontWeight = FontWeight.Medium,
                color = AgwColors.GoldSoft,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        lore.atmosphere.forEach {
            Text(
                "· $it",
                color = AgwColors.DesertOchre,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun HeroesScreen(lang: AppLang, repo: AgwDataRepository, back: () -> Unit) {
    val heroes = remember { repo.loadHeroes() }
    val key = if (lang == AppLang.EN) "en" else "fr"
    PageScaffold(S.t(lang, "heroes"), back) {
        if (!heroes.player_role[key].isNullOrBlank()) {
            Text(
                heroes.player_role[key] ?: "",
                color = AgwColors.Sand,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        heroes.npcs.forEach { npc ->
            Card(
                colors = CardDefaults.cardColors(containerColor = AgwColors.NightGlassSoft),
                shape = AgwDecor.CardShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(AgwDecor.GoldBorder, AgwDecor.CardShape)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    val ar = when (npc.id) {
                        "yusuf" -> S.t(lang, "yusuf")
                        "nadia" -> S.t(lang, "nadia")
                        "rashid" -> S.t(lang, "rashid")
                        else -> npc.name[key] ?: npc.id
                    }
                    Text(
                        "$ar · ${npc.name[key] ?: ""}",
                        fontWeight = FontWeight.Bold,
                        color = AgwColors.SacredGold,
                        fontSize = 17.sp
                    )
                    Text(
                        npc.title[key] ?: "",
                        color = AgwColors.DesertOchre,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        npc.personality,
                        color = AgwColors.PaleMarble,
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 18.sp
                    )
                }
            }
        }
        heroes.bosses.forEach { b ->
            Card(
                colors = CardDefaults.cardColors(containerColor = AgwColors.DriedBlood.copy(0.28f)),
                shape = AgwDecor.CardShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, AgwColors.SacredGold.copy(alpha = 0.45f)), AgwDecor.CardShape)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        S.t(lang, "sultan_djinn"),
                        fontWeight = FontWeight.Bold,
                        color = AgwColors.GoldSoft,
                        fontSize = 17.sp
                    )
                    Text(b.title[key] ?: "", color = AgwColors.Sand)
                    Text(
                        "${b.phases} phases · ${b.location}",
                        color = AgwColors.PaleMarble,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun BestiaryScreen(lang: AppLang, repo: AgwDataRepository, back: () -> Unit) {
    val heroes = remember { repo.loadHeroes() }
    PageScaffold(S.t(lang, "bestiary"), back) {
        listOf("dune_scorpion", "ruin_specter", "night_djinn", "sultan_djinn").forEach { key ->
            val creature = heroes.creatures.find { it.id == key }
            val boss = heroes.bosses.find { it.id == key }
            Card(
                colors = CardDefaults.cardColors(containerColor = AgwColors.NightGlassSoft),
                shape = AgwDecor.CardShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(AgwDecor.GoldBorder, AgwDecor.CardShape)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        S.t(lang, key),
                        fontWeight = FontWeight.Bold,
                        color = AgwColors.SacredGold,
                        fontSize = 17.sp
                    )
                    when {
                        creature != null -> Text(
                            "${creature.biome} · ${creature.role}",
                            color = AgwColors.Sand,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        boss != null -> Text(
                            "${boss.phases} phases · ${boss.location}",
                            color = AgwColors.Sand,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        else -> Text("agw:$key", color = AgwColors.Sand)
                    }
                }
            }
        }
        Text(
            "/summon agw:dune_scorpion · agw:djinn_sultan",
            style = MaterialTheme.typography.bodySmall,
            color = AgwColors.DesertOchre,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun FactionsScreen(lang: AppLang, repo: AgwDataRepository, back: () -> Unit) {
    val factions = remember { repo.loadFactions() }
    val rider = rememberAssetBitmap("branding/art_desert_rider.png")
    val byId = remember(factions) { factions.associateBy { it.id } }

    fun factionName(id: String): String =
        byId[id]?.name?.get("fr") ?: id.replace('_', ' ')

    fun relationLabel(ids: List<String>): String =
        if (ids.isEmpty()) "Aucune" else ids.joinToString(" · ") { factionName(it) }

    PageScaffold(S.t(lang, "factions"), back) {
        if (rider != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone),
                modifier = Modifier.fillMaxWidth()
            ) {
                androidx.compose.foundation.Image(
                    bitmap = rider,
                    contentDescription = "Art faction AGW",
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(160.dp)
                )
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Factions d'Al-Zahra",
                        color = AgwColors.SacredGold,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Identité, territoire, réputation et relations entre factions.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (factions.isEmpty()) {
            Text(
                "Aucune faction chargée. Vérifiez assets/agw/factions.json.",
                color = AgwColors.Sand
            )
        }

        factions.forEach { f ->
            Card(
                colors = CardDefaults.cardColors(containerColor = AgwColors.NightGlassSoft),
                shape = AgwDecor.CardShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(AgwDecor.GoldBorder, AgwDecor.CardShape)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            f.name["fr"] ?: f.name["en"] ?: f.id,
                            fontWeight = FontWeight.Bold,
                            color = AgwColors.SacredGold,
                            fontSize = 18.sp,
                            modifier = Modifier.weight(1f)
                        )
                        AssistChip(
                            onClick = {},
                            label = { Text(f.type.ifBlank { "faction" }, maxLines = 1) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = AgwColors.NightGlass,
                                labelColor = AgwColors.PaleMarble
                            ),
                            border = BorderStroke(1.dp, AgwColors.GoldGlass)
                        )
                    }

                    Text(f.culture.ifBlank { "Culture non renseignée." }, color = AgwColors.PaleMarble)
                    Text("Territoire : ${f.territory.ifBlank { "non renseigné" }}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)

                    val minRep = f.reputationRange.getOrNull(0) ?: -100
                    val maxRep = f.reputationRange.getOrNull(1) ?: 100
                    Text("Réputation : $minRep à $maxRep", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)

                    Text("Relations", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                    Text("Alliés : ${relationLabel(f.allies)}", color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
                    Text("Ennemis : ${relationLabel(f.enemies)}", color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
                    Text("Neutres : ${relationLabel(f.neutrals)}", color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)

                    if (f.npcs.isNotEmpty()) {
                        Text("PNJ : ${f.npcs.joinToString(" · ")}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun PhasesScreen(lang: AppLang, repo: AgwDataRepository, back: () -> Unit) {
    val phases = remember { repo.loadPhases() }
    PageScaffold(S.t(lang, "phases"), back) {
        phases.forEach { ph ->
            val done = ph.status == "done"
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (done) AgwColors.PersianBlue.copy(0.35f) else AgwColors.NightGlassSoft
                ),
                shape = AgwDecor.CardShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        if (done) BorderStroke(1.dp, AgwColors.GoldSoft.copy(alpha = 0.5f))
                        else AgwDecor.GoldBorder,
                        AgwDecor.CardShape
                    )
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Phase ${ph.id} — ${ph.name}",
                        fontWeight = FontWeight.Bold,
                        color = if (done) AgwColors.GoldSoft else AgwColors.PaleMarble,
                        fontSize = 16.sp
                    )
                    Text(
                        if (done) S.t(lang, "phase_done") else S.t(lang, "phase_planned"),
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.labelSmall
                    )
                    ph.deliverables.forEach {
                        Text("· $it", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    lang: AppLang,
    onLang: (AppLang) -> Unit,
    onOpenDebug: () -> Unit = {},
    back: () -> Unit
) {
    PageScaffold(S.t(lang, "settings"), back) {
        Text(S.t(lang, "interface_settings"), fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Spacer(Modifier.height(6.dp))
        Text(S.t(lang, "language"), color = AgwColors.Sand)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(AppLang.FR to "Français", AppLang.EN to "English", AppLang.AR to "العربية").forEach { (l, label) ->
                FilterChip(
                    selected = lang == l,
                    onClick = { onLang(l) },
                    label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AgwColors.SacredGold,
                        selectedLabelColor = AgwColors.DeepNight
                    )
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(S.t(lang, "world_settings"), fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text(S.t(lang, "world_settings_desc"), color = AgwColors.Sand)
        Spacer(Modifier.height(12.dp))
        Text(S.t(lang, "updates_settings"), fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text(S.t(lang, "updates_settings_desc"), color = AgwColors.Sand)
        Spacer(Modifier.height(16.dp))
        Text("Débogage", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Journal runtime, erreurs capturées, inspection du stockage et dump complet.", color = AgwColors.Sand)
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = onOpenDebug,
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Ouvrir les outils de débogage") }
        Spacer(Modifier.height(16.dp))
        Text(S.t(lang, "about"), fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("SBh Studio ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}) · Arabian Gothic", color = AgwColors.Sand)
        Text(S.t(lang, "world_core_v1"), color = AgwColors.Sand)
        Text(S.t(lang, "owl_motto"), color = AgwColors.DesertOchre)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProjectDetail(
    lang: AppLang,
    p: SbhProject,
    mobs: List<MobEntity>,
    items: List<SbhItem>,
    blocks: List<SbhBlock>,
    back: () -> Unit,
    addMob: () -> Unit,
    addItem: () -> Unit,
    addBlock: () -> Unit,
    delMob: (MobEntity) -> Unit,
    delItem: (SbhItem) -> Unit,
    delBlock: (SbhBlock) -> Unit,
    export: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(p.name, color = AgwColors.SacredGold) },
                navigationIcon = { TextButton(back) { Text("←") } },
                actions = {
                    Button(
                        onClick = export,
                        colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
                    ) { Text(S.t(lang, "export")) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("${p.status} · v${p.version}", color = AgwColors.Sand)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(addMob) { Text(S.t(lang, "mobs")) }
                    Button(addItem) { Text(S.t(lang, "items")) }
                    Button(addBlock) { Text(S.t(lang, "blocks")) }
                }
            }
            item { Text(S.t(lang, "mobs"), fontWeight = FontWeight.Bold, color = AgwColors.GoldSoft) }
            items(mobs) { m ->
                Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(m.nom, color = AgwColors.PaleMarble)
                        TextButton({ delMob(m) }) { Text("X") }
                    }
                }
            }
            item { Text(S.t(lang, "items"), fontWeight = FontWeight.Bold, color = AgwColors.GoldSoft) }
            items(items) { i ->
                Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(i.name, color = AgwColors.PaleMarble)
                        TextButton({ delItem(i) }) { Text("X") }
                    }
                }
            }
            item { Text(S.t(lang, "blocks"), fontWeight = FontWeight.Bold, color = AgwColors.GoldSoft) }
            items(blocks) { b ->
                Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(b.name, color = AgwColors.PaleMarble)
                        TextButton({ delBlock(b) }) { Text("X") }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MobEditor(projectId: String, existing: MobEntity?, back: () -> Unit, save: (MobEntity) -> Unit) {
    val context = LocalContext.current
    var n by rememberSaveable { mutableStateOf(existing?.nom ?: "Nouveau mob") }
    var id by rememberSaveable { mutableStateOf(existing?.identifiant ?: "agw:nouveau_mob") }
    var vie by rememberSaveable { mutableStateOf((existing?.vie ?: 20).toString()) }
    var vit by rememberSaveable { mutableStateOf((existing?.vitesse ?: 0.25).toString()) }
    var deg by rememberSaveable { mutableStateOf((existing?.degats ?: 3).toString()) }
    var tex by rememberSaveable { mutableStateOf(existing?.textureUri) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    SimpleEditor("Creature", back) {
        Field("Nom", n) { n = it }
        Field("Identifiant", id) { id = it }
        TripleFields(vie, vit, deg, { vie = it }, { vit = it }, { deg = it })
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Texture" else "Texture OK")
        }
        Text(
            "Comportement, IA, faction et pouvoirs se règlent dans l'Atelier → Mobs.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        Button({
            // Partir du mob existant (copy) : avant, on recréait un MobEntity avec 5 champs et tout le
            // reste (hostilité, profil IA, faction, pouvoirs, collision, historique) repassait aux défauts.
            val base = existing ?: MobEntity(projectId = projectId, nom = n, identifiant = id)
            save(
                base.copy(
                    projectId = projectId,
                    nom = n,
                    identifiant = id,
                    vie = vie.toIntOrNull() ?: 20,
                    vitesse = com.sbh.studio.data.NumberInput.decimal(vit) ?: 0.25,
                    degats = deg.toIntOrNull() ?: 3,
                    textureUri = tex
                )
            )
        }, Modifier.fillMaxWidth()) { Text("Enregistrer") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ItemEditor(projectId: String, existing: SbhItem?, back: () -> Unit, save: (SbhItem) -> Unit) {
    val context = LocalContext.current
    var n by rememberSaveable { mutableStateOf(existing?.name ?: "Nouvel item") }
    var id by rememberSaveable { mutableStateOf(existing?.identifier ?: "agw:nouvel_item") }
    var dmg by rememberSaveable { mutableStateOf((existing?.damage ?: 0).toString()) }
    var dur by rememberSaveable { mutableStateOf((existing?.durability ?: 100).toString()) }
    var tex by rememberSaveable { mutableStateOf(existing?.textureUri) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    SimpleEditor("Objet", back) {
        Field("Nom", n) { n = it }
        Field("Identifiant", id) { id = it }
        Field("Degats", dmg) { dmg = it }
        Field("Durabilite", dur) { dur = it }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Texture" else "Texture OK")
        }
        Button({
            save(SbhItem(existing?.id ?: java.util.UUID.randomUUID().toString(), projectId, n, id, dmg.toIntOrNull() ?: 0, dur.toIntOrNull() ?: 100, tex))
        }, Modifier.fillMaxWidth()) { Text("Enregistrer") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlockEditor(projectId: String, existing: SbhBlock?, back: () -> Unit, save: (SbhBlock) -> Unit) {
    val context = LocalContext.current
    var n by rememberSaveable { mutableStateOf(existing?.name ?: "Nouveau bloc") }
    var id by rememberSaveable { mutableStateOf(existing?.identifier ?: "agw:nouveau_bloc") }
    var h by rememberSaveable { mutableStateOf((existing?.hardness ?: 1.0).toString()) }
    var tex by rememberSaveable { mutableStateOf(existing?.textureUri) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    SimpleEditor("Bloc", back) {
        Field("Nom", n) { n = it }
        Field("Identifiant", id) { id = it }
        Field("Resistance", h) { h = it }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Texture" else "Texture OK")
        }
        Button({
            save(SbhBlock(existing?.id ?: java.util.UUID.randomUUID().toString(), projectId, n, id, com.sbh.studio.data.NumberInput.decimal(h) ?: 1.0, tex))
        }, Modifier.fillMaxWidth()) { Text("Enregistrer") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleEditor(title: String, back: () -> Unit, body: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, color = AgwColors.SacredGold) },
                navigationIcon = { TextButton(back) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(9.dp),
            content = body
        )
    }
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}

@Composable
private fun TripleFields(a: String, b: String, c: String, aa: (String) -> Unit, bb: (String) -> Unit, cc: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        OutlinedTextField(a, aa, label = { Text("Vie") }, modifier = Modifier.weight(1f))
        OutlinedTextField(b, bb, label = { Text("Vitesse") }, modifier = Modifier.weight(1f))
        OutlinedTextField(c, cc, label = { Text("Degats") }, modifier = Modifier.weight(1f))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MineEdit(back: () -> Unit, message: (String) -> Unit) {
    var x1 by rememberSaveable { mutableStateOf("0") }
    var y1 by rememberSaveable { mutableStateOf("64") }
    var z1 by rememberSaveable { mutableStateOf("0") }
    var x2 by rememberSaveable { mutableStateOf("10") }
    var y2 by rememberSaveable { mutableStateOf("70") }
    var z2 by rememberSaveable { mutableStateOf("10") }
    var confirm by rememberSaveable { mutableStateOf(false) }
    val values = listOf(x1, y1, z1, x2, y2, z2).map { it.toLongOrNull() }
    val parsed = values.filterNotNull()
    val valid = parsed.size == 6
    val width = if (valid) kotlin.math.abs(parsed[3] - parsed[0]) + 1 else 0
    val height = if (valid) kotlin.math.abs(parsed[4] - parsed[1]) + 1 else 0
    val depth = if (valid) kotlin.math.abs(parsed[5] - parsed[2]) + 1 else 0
    val volume = if (valid) width * height * depth else 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mine Edit · volume seul", color = AgwColors.SacredGold) },
                navigationIcon = { TextButton(back) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text("Calculateur de volume (pas d'édition monde)", fontWeight = FontWeight.Bold, color = AgwColors.GoldSoft)
            Text("Deux positions définissent la zone. Aucune modification du monde Minecraft — outil de mesure uniquement.", color = AgwColors.Sand)
            Text("Position 1", fontWeight = FontWeight.Bold, color = AgwColors.PaleMarble)
            TripleFields(x1, y1, z1, { x1 = it }, { y1 = it }, { z1 = it })
            Text("Position 2", fontWeight = FontWeight.Bold, color = AgwColors.PaleMarble)
            TripleFields(x2, y2, z2, { x2 = it }, { y2 = it }, { z2 = it })
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone)) {
                Text(
                    if (valid) "Volume : $width x $height x $depth = $volume blocs"
                    else "Coordonnees invalides.",
                    Modifier.padding(14.dp),
                    color = AgwColors.Sand
                )
            }
            Button(onClick = { confirm = true }, enabled = valid, modifier = Modifier.fillMaxWidth()) {
                Text("Valider")
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Confirmation") },
            text = { Text("$volume blocs. Mine Edit ne modifie pas le monde (mesure uniquement).") },
            confirmButton = {
                Button(onClick = {
                    confirm = false
                    message("Mine Edit : volume $volume blocs (mesure seule, pas d'action monde).")
                }) { Text("OK") }
            },
            dismissButton = { TextButton({ confirm = false }) { Text("Annuler") } }
        )
    }
}
