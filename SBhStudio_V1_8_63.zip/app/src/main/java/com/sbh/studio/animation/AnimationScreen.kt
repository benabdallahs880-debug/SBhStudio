package com.sbh.studio.animation

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Studio Animation V2 — 12 âmes (dont 6 inspirées FreshAnimations), 7 états, liaison mob + preset forme.
 *
 * V1.8.63 : le contenu est dans [AnimationEditor], utilisé tel quel dans Atelier → Créatures (🎞 d'un
 * monstre). Cet écran à part n'est plus ouvert par l'app (l'Accueil mène à Créatures) ; il reste
 * utilisable pour animer sans passer par l'Atelier.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimationScreen(
    onBack: () -> Unit,
    onMessage: (String) -> Unit = {},
    initialLinkedMobId: String? = null
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Studio Animation", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text("Âme + 7 états · lien monstre", color = AgwColors.Sand, fontSize = 11.sp)
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←", color = AgwColors.SacredGold) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        AnimationEditor(
            modifier = Modifier.fillMaxSize().padding(pad),
            fixedMob = null,
            initialLinkedMobId = initialLinkedMobId,
            onMessage = onMessage
        )
    }
}

/**
 * Éditeur d'âme et d'états (contenu du Studio Animation).
 *
 * [fixedMob] non nul (zone Créatures) : l'âme de CE monstre est ouverte (ou créée avec le preset
 * recommandé pour sa forme) ; pas de choix de monstre ni de liste des autres âmes.
 * [bodyAnimations] : noms courts des animations du corps 3D CreatureStudio du monstre (« repos »,
 * « marche »…) ; non vide = les réglages s'appliquent à ces animations à l'export, et
 * [onPreviewOnBody] ouvre le corps 3D pour voir l'animation réglée.
 */
@Composable
fun AnimationEditor(
    modifier: Modifier = Modifier,
    fixedMob: MobEntity? = null,
    initialLinkedMobId: String? = null,
    bodyAnimations: List<String> = emptyList(),
    onPreviewOnBody: ((bodyAnimation: String, params: AnimStateParams) -> Unit)? = null,
    onSaved: (AnimationProject) -> Unit = {},
    onMessage: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val repo = remember { AnimationRepository(context) }
    val mobRepo = remember { MobRepository(context) }
    val embedded = fixedMob != null
    val hasBody = bodyAnimations.isNotEmpty()

    var projects by remember { mutableStateOf(emptyList<AnimationProject>()) }
    var mobs by remember { mutableStateOf(emptyList<MobEntity>()) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val (loadedProjects, loadedMobs) = withContext(Dispatchers.IO) {
            repo.loadAll() to mobRepo.loadAll()
        }
        projects = loadedProjects
        mobs = loadedMobs
        loaded = true
    }
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var name by rememberSaveable { mutableStateOf("Âme AGW") }
    var soulName by rememberSaveable { mutableStateOf(AnimSoul.DESERT.name) }
    var linkedMobId by rememberSaveable { mutableStateOf<String?>(null) }
    var activeState by rememberSaveable { mutableStateOf(AnimState.IDLE.name) }
    var speed by remember { mutableStateOf(1f) }
    var amplitude by remember { mutableStateOf(1f) }
    var weight by remember { mutableStateOf(1f) }
    var loop by remember { mutableStateOf(true) }
    var notes by rememberSaveable { mutableStateOf("") }
    var previewTick by remember { mutableStateOf(0f) }
    // V1.8.63 : réglages de TOUS les états en cours d'édition. Avant, passer d'un état à l'autre
    // repartait de la version enregistrée : les réglages d'un état modifié puis quitté étaient perdus.
    var working by remember { mutableStateOf(AnimationPresets.applySoul(AnimSoul.DESERT)) }

    val soul = AnimSoul.entries.find { it.name == soulName } ?: AnimSoul.DESERT
    val stateEnum = AnimState.entries.find { it.name == activeState } ?: AnimState.IDLE

    // Preview animation loop
    LaunchedEffect(speed, activeState) {
        while (true) {
            kotlinx.coroutines.delay(32)
            previewTick = (previewTick + 0.032f * speed.coerceIn(0.25f, 2.5f)) % 100f
        }
    }

    fun loadStateParams(states: Map<String, AnimStateParams>) {
        val p = states[activeState] ?: AnimStateParams()
        speed = p.speed
        amplitude = p.amplitude
        weight = p.weight
        loop = p.loop
    }

    fun currentStates(): Map<String, AnimStateParams> =
        working.toMutableMap().also { it[activeState] = AnimStateParams(speed, amplitude, weight, loop) }

    fun switchState(st: AnimState) {
        working = currentStates()
        activeState = st.name
        loadStateParams(working)
    }

    fun applySoulPreset(s: AnimSoul) {
        soulName = s.name
        working = AnimationPresets.applySoul(s)
        loadStateParams(working)
        onMessage("Âme « ${s.label} » appliquée")
    }

    fun save() {
        val mobId = fixedMob?.id ?: linkedMobId
        val mob = fixedMob ?: mobs.find { it.id == mobId }
        val full = AnimationPresets.applySoul(soul).toMutableMap()
        full.putAll(currentStates())
        val p = AnimationProject(
            id = editingId ?: java.util.UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Âme" },
            soul = soulName,
            linkedMobId = mobId,
            linkedMobIdentifier = mob?.identifiant,
            states = full,
            notes = notes,
            createdAt = projects.firstOrNull { it.id == editingId }?.createdAt ?: System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        val next = projects.filter { it.id != p.id } + p
        // Un mob = une âme principale
        val dedup = if (mobId != null) {
            next.map {
                if (it.id != p.id && (it.linkedMobId == mobId || (mob != null && it.linkedMobIdentifier == mob.identifiant)))
                    it.copy(linkedMobId = null, linkedMobIdentifier = null)
                else it
            }
        } else next
        // V1.8.57 : une écriture qui échoue ne fait plus planter l'écran.
        try {
            repo.saveAll(dedup)
        } catch (e: Exception) {
            android.util.Log.e("AnimationScreen", "Sauvegarde animation impossible", e)
            onMessage("⚠ Animation non enregistrée : ${e.message ?: "erreur"} — vérifiez l'espace de stockage.")
            return
        }
        projects = dedup
        working = full
        editingId = p.id
        onSaved(p)
        onMessage("Animation « ${p.name} » enregistrée" + (mob?.let { " → ${it.nom}" } ?: ""))
    }

    fun load(p: AnimationProject) {
        editingId = p.id
        name = p.name
        soulName = p.soul
        linkedMobId = p.linkedMobId
        notes = p.notes
        activeState = AnimState.IDLE.name
        val soulOf = AnimSoul.entries.find { it.name == p.soul } ?: AnimSoul.DESERT
        working = AnimationPresets.applySoul(soulOf) + p.states
        loadStateParams(working)
    }

    fun reset() {
        editingId = null
        name = "Âme AGW"
        soulName = AnimSoul.DESERT.name
        linkedMobId = null
        notes = ""
        activeState = AnimState.IDLE.name
        working = AnimationPresets.applySoul(AnimSoul.DESERT)
        loadStateParams(working)
    }

    var appliedInitial by remember { mutableStateOf(false) }
    LaunchedEffect(initialLinkedMobId, fixedMob?.id, mobs, projects, loaded) {
        if (appliedInitial || !loaded) return@LaunchedEffect
        val mid = fixedMob?.id ?: initialLinkedMobId ?: return@LaunchedEffect
        val mob = fixedMob ?: mobs.find { it.id == mid } ?: return@LaunchedEffect
        appliedInitial = true
        linkedMobId = mid
        val existing = projects.firstOrNull {
            it.linkedMobId == mid || it.linkedMobIdentifier == mob.identifiant
        }
        if (existing != null) {
            load(existing)
            linkedMobId = mid
        } else {
            val recommended = AnimationPresets.soulForForme(mob.formeBase)
            soulName = recommended.name
            name = "Âme · ${mob.nom}"
            working = AnimationPresets.applySoul(recommended)
            loadStateParams(working)
            onMessage("Nouvelle âme pour ${mob.nom} (preset ${recommended.label}) — « Enregistrer » pour la garder")
        }
    }

    Column(
        modifier
            .padding(horizontal = 12.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (embedded) {
            Text(
                if (hasBody) "🧬 Ce monstre a un corps 3D : l'âme règle la vitesse, l'amplitude et la boucle de SES animations " +
                    "(${bodyAnimations.joinToString(", ")}). Les images clés se modifient dans 🧬 Corps 3D."
                else "L'âme anime la forme Minecraft du monstre (${fixedMob?.formeBase ?: "humanoid"}).",
                color = if (hasBody) AgwColors.Success else AgwColors.Sand,
                fontSize = 12.sp
            )
        }
        OutlinedTextField(
            name, { name = it },
            label = { Text("Nom de l'âme") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )

        SectionTitle("Âme (personnalité) — 12 presets")
        Text(soul.description, color = AgwColors.Sand, fontSize = 12.sp)
        soul.recommendedForme?.let { forme ->
            Text("Idéal pour forme : $forme", color = AgwColors.DesertOchre, fontSize = 11.sp)
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AnimSoul.entries.forEach { s ->
                FilterChip(
                    selected = soulName == s.name,
                    onClick = { applySoulPreset(s) },
                    label = { Text(s.label, fontSize = 11.sp) }
                )
            }
        }

        SectionTitle("État animé — 7 états")
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AnimState.entries.forEach { st ->
                FilterChip(
                    selected = activeState == st.name,
                    onClick = { switchState(st) },
                    label = { Text(st.label, fontSize = 12.sp) }
                )
            }
        }

        SectionTitle("Réglages · ${stateEnum.label}")
        ParamSlider("Vitesse", speed, 0.25f, 2.5f) { speed = it }
        ParamSlider("Amplitude", amplitude, 0.25f, 2f) { amplitude = it }
        ParamSlider("Poids", weight, 0.4f, 1.6f) { weight = it }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(loop, { loop = it }, colors = CheckboxDefaults.colors(checkedColor = AgwColors.SacredGold))
            Text("Boucle", color = AgwColors.PaleMarble)
        }

        SectionTitle("Aperçu · ${stateEnum.label}")
        // Niveau C : raccourcis d'états collés à l'aperçu
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AnimState.entries.forEach { st ->
                FilterChip(
                    selected = activeState == st.name,
                    onClick = { switchState(st) },
                    label = { Text(st.label, fontSize = 11.sp) }
                )
            }
        }
        if (hasBody) {
            val bodyAnim = com.sbh.studio.creature.CreatureBodyAnimation.bodyAnimationFor(stateEnum, bodyAnimations)
            if (bodyAnim != null) {
                Text(
                    "« ${stateEnum.label} » → animation « $bodyAnim » du corps 3D" +
                        " (vitesse ×${"%.2f".format(speed)}, amplitude ×${"%.2f".format(amplitude)})",
                    color = AgwColors.DesertOchre, fontSize = 12.sp
                )
                if (onPreviewOnBody != null) GoldPrimaryButton(
                    "▶ Voir « ${stateEnum.label} » sur le corps 3D",
                    onClick = { onPreviewOnBody(bodyAnim, AnimStateParams(speed, amplitude, weight, loop)) },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Text(
                    "Le corps 3D n'a pas d'animation pour « ${stateEnum.label} » : ce réglage n'aura pas d'effet. " +
                        "Crée-la dans 🧬 Corps 3D (animation nommée « ${com.sbh.studio.creature.CreatureBodyAnimation.expectedName(stateEnum)} »).",
                    color = AgwColors.Warning, fontSize = 12.sp
                )
            }
        } else {
            val linkedMob = fixedMob ?: mobs.find { it.id == linkedMobId }
            CreaturePreview(
                tick = previewTick,
                amplitude = amplitude,
                weight = weight,
                state = stateEnum,
                soul = soul,
                formeBase = linkedMob?.formeBase ?: soul.recommendedForme ?: "humanoid",
                textureUri = linkedMob?.textureUri,
                mobName = linkedMob?.nom
            )
        }

        if (!embedded) {
            SectionTitle("Lier à un monstre de l'Atelier")
            if (mobs.isEmpty()) {
                Text(
                    "Aucun monstre. Crée-en dans Atelier → Créatures, puis reviens ici.",
                    color = AgwColors.Sand,
                    fontSize = 12.sp
                )
            } else {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = linkedMobId == null,
                        onClick = { linkedMobId = null },
                        label = { Text("Aucun", fontSize = 11.sp) }
                    )
                    mobs.forEach { m ->
                        FilterChip(
                            selected = linkedMobId == m.id,
                            onClick = {
                                linkedMobId = m.id
                                if (name == "Âme AGW" || name.startsWith("Âme ")) {
                                    name = "Âme · ${m.nom}"
                                }
                            },
                            label = { Text(m.nom, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }
        val linkedNow = fixedMob ?: linkedMobId?.let { id -> mobs.find { it.id == id } }
        if (linkedNow != null) {
            Text(
                "Lié : ${linkedNow.nom} (${linkedNow.identifiant}) · forme ${linkedNow.formeBase}",
                color = AgwColors.DesertOchre,
                fontSize = 11.sp
            )
            val recommended = AnimationPresets.soulForForme(linkedNow.formeBase)
            Text(
                "Preset recommandé : ${recommended.label} — ${recommended.description}",
                color = AgwColors.Sand,
                fontSize = 11.sp
            )
            GoldOutlineButton(
                "Appliquer le preset « ${recommended.label} »",
                onClick = {
                    applySoulPreset(recommended)
                    onMessage("Preset ${recommended.label} appliqué (forme ${linkedNow.formeBase})")
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        OutlinedTextField(
            notes, { notes = it },
            label = { Text("Notes") },
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldPrimaryButton("💾 Enregistrer l'âme", onClick = { save() }, modifier = Modifier.weight(1f))
            if (!embedded) GoldOutlineButton("Nouveau", onClick = { reset() }, modifier = Modifier.weight(1f))
        }

        if (!embedded) {
            SectionTitle("Animations enregistrées (${projects.size})")
            if (projects.isEmpty()) {
                Text("Aucune âme pour l'instant.", color = AgwColors.Sand, fontSize = 12.sp)
            } else {
                projects.sortedByDescending { it.updatedAt }.forEach { p ->
                    val mobLabel = mobs.find { it.id == p.linkedMobId }?.nom
                        ?: p.linkedMobIdentifier
                        ?: "—"
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                                Text(
                                    "${runCatching { AnimSoul.valueOf(p.soul).label }.getOrDefault(p.soul)} · monstre : $mobLabel",
                                    color = AgwColors.Sand,
                                    fontSize = 11.sp
                                )
                            }
                            TextButton({ load(p) }) { Text("Ouvrir", color = AgwColors.GoldSoft) }
                            TextButton({
                                val rest = projects.filter { it.id != p.id }
                                try {
                                    repo.saveAll(rest)
                                    projects = rest
                                    if (editingId == p.id) reset()
                                    onMessage("Supprimé")
                                } catch (e: Exception) {
                                    onMessage("⚠ Suppression non enregistrée : ${e.message ?: "erreur"}")
                                }
                            }) { Text("X", color = Color(0xFFB94E48)) }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun ParamSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = AgwColors.PaleMarble, fontSize = 12.sp)
            Text("%.2f".format(value), color = AgwColors.SacredGold, fontSize = 12.sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = AgwColors.SacredGold,
                activeTrackColor = AgwColors.SacredGold,
                inactiveTrackColor = AgwColors.NightStone
            )
        )
    }
}


@Composable
private fun CreaturePreview(
    tick: Float,
    amplitude: Float,
    weight: Float,
    state: AnimState,
    soul: AnimSoul,
    formeBase: String,
    textureUri: String?,
    mobName: String?
) {
    val context = LocalContext.current
    val skinBitmap by produceState<ImageBitmap?>(initialValue = null, textureUri) {
        value = null
        if (textureUri.isNullOrBlank()) return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                when {
                    textureUri.startsWith("asset://") -> {
                        val path = textureUri.removePrefix("asset://")
                        context.assets.open(path).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
                    }
                    textureUri.startsWith("content://") || textureUri.startsWith("file:") -> {
                        val uri = android.net.Uri.parse(textureUri)
                        context.contentResolver.openInputStream(uri)?.use {
                            BitmapFactory.decodeStream(it)?.asImageBitmap()
                        }
                    }
                    else -> {
                        // asset relative (skins_library/…)
                        context.assets.open(textureUri).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
                    }
                }
            }.getOrNull()
        }
    }
    // Local pour éviter smart-cast délégué
    val skin = skinBitmap

    val tSec = tick * 0.55f
    val pose = remember(tick, amplitude, weight, state, soul, formeBase) {
        AnimationMotion.pose(tSec, state, soul, amplitude, weight, formeBase)
    }

    val accent = when (soul) {
        AnimSoul.ASSASSIN -> Color(0xFFAB47BC)
        AnimSoul.BEAST -> Color(0xFFB94E48)
        AnimSoul.MYSTIC -> Color(0xFF5DADE2)
        AnimSoul.DESERT -> AgwColors.SacredGold
        AnimSoul.MERCHANT -> Color(0xFF7AA66D)
        AnimSoul.GUARDIAN -> AgwColors.GoldSoft
        AnimSoul.WOLF -> Color(0xFF8D6E63)
        AnimSoul.UNDEAD -> Color(0xFF66BB6A)
        AnimSoul.ARACHNID -> Color(0xFF78909C)
        AnimSoul.FLYER -> Color(0xFF4FC3F7)
        AnimSoul.HEAVY_QUAD -> Color(0xFFA1887F)
        AnimSoul.AGILE -> Color(0xFFFFB74D)
    }

    val forme = formeBase.lowercase()
    val isQuad = forme in setOf("wolf", "cow", "pig", "sheep", "horse")
    val isSpider = forme == "spider"
    val isCreeper = forme == "creeper"
    val isChicken = forme == "chicken"

    Box(
        Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0A0E14))
            .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f + pose.lateral
            val groundY = size.height - 28f
            // sol
            drawLine(
                AgwColors.GoldSoft.copy(alpha = 0.3f),
                Offset(cx - 70f, groundY),
                Offset(cx + 70f, groundY),
                strokeWidth = 2f,
                cap = StrokeCap.Round
            )

            val scale = (1.1f * weight.coerceIn(0.6f, 1.4f)).coerceIn(0.7f, 1.5f)
            val crouchOff = pose.crouch * 28f * scale

            if (isSpider) {
                drawSpider(cx, groundY - 20f - pose.bob, pose, accent, scale)
            } else if (isQuad) {
                drawQuad(cx, groundY - 18f - pose.bob, pose, accent, scale, isChicken)
            } else if (isCreeper) {
                drawCreeper(cx, groundY - pose.bob - crouchOff, pose, accent, scale)
            } else {
                drawHumanoid(cx, groundY - pose.bob - crouchOff, pose, accent, scale, isChicken)
            }
        }

        // Vignette texture (tête / corps) si skin disponible
        if (skin != null) {
            val headSize = 36.dp
            Image(
                bitmap = skin,
                contentDescription = mobName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-36).dp)
                    .size(headSize)
                    .clip(RoundedCornerShape(6.dp))
                    .border(1.dp, AgwColors.SacredGold.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            )
        }

        Column(Modifier.align(Alignment.TopStart).padding(10.dp)) {
            Text(state.label, color = AgwColors.SacredGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(
                mobName?.let { "$it · $formeBase" } ?: "Forme $formeBase",
                color = AgwColors.Sand,
                fontSize = 10.sp
            )
        }
        Text(
            soul.label,
            color = AgwColors.DesertOchre,
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
        )
        if (skin == null && !textureUri.isNullOrBlank()) {
            Text("Texture…", color = AgwColors.Sand, fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
        }
        if (textureUri.isNullOrBlank() && mobName == null) {
            Text("Lie un mob pour skin + forme", color = AgwColors.Sand.copy(alpha = 0.7f), fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp))
        }
    }
}

/** Silhouette humanoïde / zombie / squelette. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawHumanoid(
    cx: Float, baseY: Float, pose: AnimationMotion.PoseFrame, accent: Color, scale: Float, small: Boolean
) {
    val s = scale * (if (small) 0.75f else 1f)
    val lean = pose.lean
    val bodyH = 36f * s
    val bodyW = 16f * s
    val headR = 11f * s
    val hipY = baseY - 8f * s
    val shoulderY = hipY - bodyH
    val headY = shoulderY - headR - 2f * s + pose.headPitch * 0.15f

    // jambes
    val legLen = 28f * s
    drawLine(accent, Offset(cx + lean * 0.3f, hipY), Offset(cx - 8f * s + pose.legSwing, hipY + legLen), 4f * s, StrokeCap.Round)
    drawLine(accent, Offset(cx + lean * 0.3f, hipY), Offset(cx + 8f * s - pose.legSwing, hipY + legLen), 4f * s, StrokeCap.Round)

    // corps (rect approx via stroke box)
    drawRoundRect(
        color = accent.copy(alpha = 0.9f),
        topLeft = Offset(cx + lean - bodyW / 2f, shoulderY),
        size = Size(bodyW, bodyH),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f * s, 4f * s)
    )

    // bras — raise = bras vers l'avant/haut (zombie)
    val armLen = 24f * s
    val raiseRad = (pose.armRaise) * (PI.toFloat() / 180f)
    val armSwing = pose.armSwing
    // bras droit
    val rx = cx + lean + bodyW / 2f
    val ry = shoulderY + 4f * s
    val rEndX = rx + sin(raiseRad) * armLen * 0.3f + 6f * s
    val rEndY = ry + cos(raiseRad * 0.5f) * armLen - armSwing * 0.4f
    drawLine(accent, Offset(rx, ry), Offset(rEndX, rEndY), 3.5f * s, StrokeCap.Round)
    // bras gauche
    val lx = cx + lean - bodyW / 2f
    val ly = shoulderY + 4f * s
    val lEndX = lx - sin(raiseRad) * armLen * 0.3f - 6f * s
    val lEndY = ly + cos(raiseRad * 0.5f) * armLen + armSwing * 0.4f
    drawLine(accent, Offset(lx, ly), Offset(lEndX, lEndY), 3.5f * s, StrokeCap.Round)

    // tête
    val hx = cx + lean * 0.5f + pose.headYaw * 0.2f
    drawCircle(AgwColors.PaleMarble, headR, Offset(hx, headY))
    drawCircle(accent.copy(alpha = 0.5f), headR, Offset(hx, headY), style = Stroke(width = 1.5f * s))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCreeper(
    cx: Float, baseY: Float, pose: AnimationMotion.PoseFrame, accent: Color, scale: Float
) {
    val s = scale
    val lean = pose.lean * 0.5f
    val footY = baseY
    val legLen = 18f * s
    drawLine(accent, Offset(cx - 6f * s + lean, footY - legLen), Offset(cx - 8f * s + pose.legSwing * 0.5f, footY), 4f * s, StrokeCap.Round)
    drawLine(accent, Offset(cx + 6f * s + lean, footY - legLen), Offset(cx + 8f * s - pose.legSwing * 0.5f, footY), 4f * s, StrokeCap.Round)
    val bodyH = 40f * s
    val bodyW = 14f * s
    val top = footY - legLen - bodyH
    drawRoundRect(accent.copy(alpha = 0.9f), Offset(cx + lean - bodyW / 2f, top), Size(bodyW, bodyH), androidx.compose.ui.geometry.CornerRadius(3f, 3f))
    drawCircle(AgwColors.PaleMarble, 10f * s, Offset(cx + lean, top - 10f * s))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawQuad(
    cx: Float, baseY: Float, pose: AnimationMotion.PoseFrame, accent: Color, scale: Float, small: Boolean
) {
    val s = scale * (if (small) 0.7f else 1f)
    val bodyW = 48f * s
    val bodyH = 16f * s
    val y = baseY - bodyH
    drawRoundRect(accent.copy(alpha = 0.9f), Offset(cx - bodyW / 2f + pose.lean * 0.2f, y), Size(bodyW, bodyH), androidx.compose.ui.geometry.CornerRadius(6f * s, 6f * s))
    // 4 pattes
    val leg = 16f * s
    val swing = pose.legSwing
    listOf(-18f, -8f, 8f, 18f).forEachIndexed { i, ox ->
        val sw = if (i % 2 == 0) swing else -swing
        drawLine(accent, Offset(cx + ox * s, y + bodyH), Offset(cx + ox * s + sw * 0.4f, y + bodyH + leg), 3.5f * s, StrokeCap.Round)
    }
    // tête
    drawCircle(AgwColors.PaleMarble, 9f * s, Offset(cx + bodyW / 2f - 4f * s + pose.headYaw * 0.15f, y + 4f * s))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSpider(
    cx: Float, baseY: Float, pose: AnimationMotion.PoseFrame, accent: Color, scale: Float
) {
    val s = scale
    val bodyR = 14f * s
    drawCircle(accent.copy(alpha = 0.9f), bodyR, Offset(cx, baseY))
    drawCircle(AgwColors.PaleMarble, 8f * s, Offset(cx + bodyR * 0.9f + pose.headYaw * 0.1f, baseY - 2f * s))
    // 8 pattes
    for (i in 0 until 8) {
        val side = if (i < 4) -1f else 1f
        val idx = i % 4
        val ang = (-40f + idx * 25f) * (PI.toFloat() / 180f)
        val swing = pose.legSwing * (if (idx % 2 == 0) 1f else -1f) * 0.5f
        val len = 22f * s
        val x2 = cx + side * cos(ang) * len + swing
        val y2 = baseY + sin(ang) * len * 0.6f + 8f * s
        drawLine(accent, Offset(cx + side * 6f * s, baseY), Offset(x2, y2), 2.5f * s, StrokeCap.Round)
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AgwColors.SacredGold,
    unfocusedBorderColor = AgwColors.GoldSoft.copy(alpha = 0.4f),
    focusedTextColor = AgwColors.PaleMarble,
    unfocusedTextColor = AgwColors.PaleMarble
)
