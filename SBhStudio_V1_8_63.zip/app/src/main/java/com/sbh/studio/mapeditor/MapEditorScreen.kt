package com.sbh.studio.mapeditor

import android.annotation.SuppressLint
import android.graphics.Color
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.sbh.studio.data.ActiveProject
import com.sbh.studio.data.ProjectRepository
import com.sbh.studio.data.RuntimeDiagnosticStore
import com.sbh.studio.data.RuntimeErrorRecord
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.workshop.SceneEntity
import com.sbh.studio.workshop.SceneEntityType
import com.sbh.studio.workshop.WorkshopRepository
import com.sbh.studio.texture.TextureRepository
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/**
 * Éditeur de maps 3D intégré (Three.js via WebView) — V1.8.60.
 *
 * Changements par rapport à la V1.8.59 (voir RAPPORT_REPARATION_MAP_STUDIO_1_8_60.md) :
 *  - tout est rangé PAR PROJET (MapStudioStore) : sauvegarde auto, sauvegarde manuelle, objets .glb ;
 *  - les données de l'Atelier sont lues À LA DEMANDE par la page (projectInfo / atelierData),
 *    filtrées sur le projet actif — plus d'injection après coup, plus de course au chargement ;
 *  - « Exporter vers SBh » crée/met à jour une vraie map de l'Atelier, incluse ensuite dans le
 *    .mcaddon (fonctions Bedrock) ; le résultat réel est renvoyé à la page ;
 *  - les objets 3D remontent dans l'Atelier (ajout, mise à jour ET suppression) ;
 *  - les .glb sont servis par URL (WebViewAssetLoader) au lieu de traverser le pont en base64 ;
 *  - Retour : la page enregistre d'abord la map, puis l'écran se ferme.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MapEditorScreen(
    onBack: () -> Unit,
    onMapExported: (String) -> Unit = {},
    /** V1.8.61 : map de l'Atelier à ouvrir (zone Maps) ; null = dernière map du projet. */
    mapId: String? = null,
    /** V1.8.61 : action à faire à l'ouverture : "place_forge", "test", "forge_test". */
    action: String? = null
) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var loadStage by remember { mutableStateOf(0) }
    var pageReady by remember { mutableStateOf(false) }
    var studioReady by remember { mutableStateOf(false) }
    var retryCount by remember { mutableStateOf(0) }
    var closing by remember { mutableStateOf(false) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val runtimeDiagnostics = remember { RuntimeDiagnosticStore(context) }
    val webViewHolder = remember { arrayOfNulls<WebView>(1) }
    var fileChooserCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val fileChooserLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        fileChooserCallback?.onReceiveValue(uri?.let { arrayOf(it) } ?: emptyArray())
        fileChooserCallback = null
    }

    // Projet actif : le même que celui affiché dans l'Atelier.
    val project = remember { ActiveProject.resolve(context, ProjectRepository(context).load()) }
    val projectId = project?.id ?: "global"

    /** Étapes de chargement : la barre ne recule jamais (avant : 4 → 1 → 2 → 3 → 4). */
    fun advance(stage: Int) { if (stage > loadStage) loadStage = stage }

    fun openInMinecraftOrShare(file: java.io.File) {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            val isPack = file.name.endsWith(".mcaddon", true) || file.name.endsWith(".mcpack", true)
            if (isPack) {
                // Même ouverture directe que l'export de l'Atelier : Minecraft n'apparaît que sur ACTION_VIEW.
                val view = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/mcaddon")
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val opened = runCatching { context.startActivity(view) }.isSuccess
                if (opened) return
            }
            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "application/octet-stream"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(
                android.content.Intent.createChooser(send, "Enregistrer / partager ${file.name}")
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Log.w("MapEditor", "Ouverture / partage impossible", e)
        }
    }

    val bridge = remember {
        object {
            @JavascriptInterface
            fun close() {
                mainHandler.post { onBack() }
            }

            /** Projet actif (lu par la page au démarrage). */
            @JavascriptInterface
            fun projectInfo(): String = JSONObject().apply {
                put("id", projectId)
                put("name", project?.name ?: "Sans projet")
                put("hasProject", project != null)
            }.toString()

            /** Map à ouvrir + action demandée par l'Atelier (lue une seule fois au démarrage). */
            @JavascriptInterface
            fun startInfo(): String = JSONObject().apply {
                put("mapId", mapId ?: JSONObject.NULL)
                put("action", action ?: JSONObject.NULL)
                put("lastMapId", MapStudioStore.lastMapId(context, projectId) ?: JSONObject.NULL)
            }.toString()

            /** Maps du projet (fiches de l'Atelier). Migre au passage l'ancienne sauvegarde unique (V1.8.60). */
            @JavascriptInterface
            fun listMaps(): String = try {
                val ws = WorkshopRepository(context)
                var all = ws.loadMaps()
                if (project != null) {
                    MapStudioStore.migrateLegacyAutosave(context, projectId, all)?.let { migrated ->
                        ws.saveMaps(migrated); all = migrated
                    }
                }
                JSONArray().apply {
                    all.filter { it.projectId == projectId }.forEach { m ->
                        put(JSONObject().apply {
                            put("id", m.id); put("name", m.name)
                            put("sizeX", m.sizeX); put("sizeZ", m.sizeZ); put("height", m.height)
                            put("hasStudio", MapStudioStore.hasMap(context, projectId, m.id))
                        })
                    }
                }.toString()
            } catch (e: Exception) {
                Log.w("MapEditor", "Liste des maps impossible", e); "[]"
            }

            /**
             * Ouvre une map : fiche + contenu Map Studio (vide pour une map jamais ouverte : la page la
             * construit d'après sa fiche) + structures importées dans l'ancienne zone Maps.
             */
            @JavascriptInterface
            fun openMap(id: String): String = try {
                val m = WorkshopRepository(context).loadMaps().firstOrNull { it.id == id && it.projectId == projectId }
                if (m == null) "null" else {
                    MapStudioStore.setLastMap(context, projectId, m.id)
                    JSONObject().apply {
                        put("blueprint", JSONObject(MapStudioStore.blueprintJson.encodeToString(com.sbh.studio.workshop.MapBlueprint.serializer(), m)))
                        put("content", MapStudioStore.loadMap(context, projectId, m.id))
                        put("forge", MapStudioStore.hasForgeNote(m))
                        put("structures", JSONArray().apply {
                            MapStudioStore.legacyStructures(context, m.id).forEach { (key, text) ->
                                put(JSONObject().apply {
                                    put("key", key)
                                    put("name", runCatching { JSONObject(text).optString("name", key) }.getOrDefault(key))
                                    put("json", text)
                                })
                            }
                        })
                    }.toString()
                }
            } catch (e: Exception) {
                Log.w("MapEditor", "Ouverture de la map impossible", e); "null"
            }

            /**
             * Enregistre le contenu de la map (+ fonctions Bedrock + vue du dessus) et met sa fiche
             * à jour (nom, tailles). Appelé par la sauvegarde automatique de la page.
             */
            @JavascriptInterface
            fun saveMap(id: String, json: String, previewPngBase64: String): Boolean = try {
                val info = MapStudioStore.parseExport(json)
                if (project == null || info == null) false else {
                    val ws = WorkshopRepository(context)
                    val maps = ws.loadMaps()
                    if (maps.none { it.id == id && it.projectId == projectId }) false else {
                        MapStudioStore.saveMap(context, projectId, id, json)
                        ws.saveMaps(MapStudioStore.upsertMap(maps, projectId, id, info))
                        MapStudioStore.savePreview(context, projectId, id, previewPngBase64)
                        MapStudioStore.setLastMap(context, projectId, id)
                        MapStudioStore.hasMap(context, projectId, id)
                    }
                }
            } catch (e: Exception) {
                Log.e("MapEditor", "Enregistrement de la map impossible", e); false
            }

            /** Crée une nouvelle map dans l'Atelier ; renvoie sa fiche (ou "null" sans projet). */
            @JavascriptInterface
            fun createMap(blueprintJson: String): String = try {
                if (project == null) "null" else {
                    val incoming = MapStudioStore.blueprintJson.decodeFromString(com.sbh.studio.workshop.MapBlueprint.serializer(), blueprintJson)
                    val created = incoming.copy(
                        id = java.util.UUID.randomUUID().toString(),
                        projectId = projectId,
                        name = incoming.name.trim().ifBlank { "Nouvelle map" }.take(60),
                        sizeX = incoming.sizeX.coerceIn(8, 256), sizeZ = incoming.sizeZ.coerceIn(8, 256), height = incoming.height.coerceIn(8, 256)
                    )
                    val ws = WorkshopRepository(context)
                    ws.saveMaps(ws.loadMaps() + created)
                    MapStudioStore.setLastMap(context, projectId, created.id)
                    MapStudioStore.blueprintJson.encodeToString(com.sbh.studio.workshop.MapBlueprint.serializer(), created)
                }
            } catch (e: Exception) {
                Log.e("MapEditor", "Création de map impossible", e); "null"
            }

            /** Fiche modifiée dans Map Studio (panneau « Fiche ») → Atelier. */
            @JavascriptInterface
            fun saveBlueprint(blueprintJson: String): Boolean = try {
                val incoming = MapStudioStore.blueprintJson.decodeFromString(com.sbh.studio.workshop.MapBlueprint.serializer(), blueprintJson)
                val ws = WorkshopRepository(context)
                val maps = ws.loadMaps()
                val idx = maps.indexOfFirst { it.id == incoming.id && it.projectId == projectId }
                if (idx < 0) false else {
                    ws.saveMaps(maps.toMutableList().also { it[idx] = MapStudioStore.applyFiche(maps[idx], incoming) })
                    true
                }
            } catch (e: Exception) {
                Log.w("MapEditor", "Fiche non enregistrée", e); false
            }

            /** Lie / délie un portail du projet à une map (comme l'ancienne zone Maps). */
            @JavascriptInterface
            fun linkPortal(portalId: String, mapId: String): Boolean = try {
                val ws = WorkshopRepository(context)
                val portals = ws.loadPortals()
                val idx = portals.indexOfFirst { it.id == portalId && it.projectId == projectId }
                if (idx < 0) false else {
                    ws.savePortals(portals.toMutableList().also { it[idx] = portals[idx].copy(linkedMapId = mapId.ifBlank { null }) })
                    true
                }
            } catch (e: Exception) { false }

            /**
             * Listes de l'Atelier DU PROJET ACTIF pour la fiche et le ▶ Tester : mobs, items, blocs,
             * textures, portails, entités, régions AGW.
             */
            @JavascriptInterface
            fun atelierLists(): String = try {
                val ws = WorkshopRepository(context)
                val root = JSONObject()
                root.put("mobs", JSONArray().apply {
                    com.sbh.studio.data.MobRepository(context).loadForProject(projectId).forEach { m ->
                        put(JSONObject().apply { put("id", m.id); put("name", m.nom); put("identifier", m.identifiant) })
                    }
                })
                root.put("items", JSONArray().apply {
                    com.sbh.studio.data.ItemRepository(context).loadAll().filter { it.projectId == projectId }.forEach { i ->
                        put(JSONObject().apply { put("id", i.id); put("name", i.name); put("identifier", i.identifier) })
                    }
                })
                root.put("blocks", JSONArray().apply {
                    com.sbh.studio.data.BlockRepository(context).loadAll().filter { it.projectId == projectId }.forEach { b ->
                        put(JSONObject().apply { put("id", b.id); put("name", b.name); put("identifier", b.identifier) })
                    }
                })
                root.put("textures", JSONArray().apply {
                    TextureRepository(context).loadAll().forEach { t ->
                        put(JSONObject().apply { put("id", t.id); put("name", t.name) })
                    }
                })
                root.put("portals", JSONArray().apply {
                    ws.loadPortals().filter { it.projectId == projectId }.forEach { p ->
                        put(JSONObject().apply {
                            put("id", p.id); put("name", p.name)
                            put("linkedMapId", p.linkedMapId ?: JSONObject.NULL)
                            put("mapX", p.mapX); put("mapY", p.mapY); put("mapZ", p.mapZ)
                            put("width", p.width); put("height", p.height)
                        })
                    }
                })
                root.put("entities", JSONArray().apply {
                    ws.loadEntities().filter { it.projectId == projectId }.forEach { e ->
                        put(JSONObject().apply {
                            put("id", e.id); put("name", e.name)
                            put("glbName", e.glbName ?: JSONObject.NULL)
                            put("linkedMapId", e.linkedMapId ?: JSONObject.NULL)
                            put("posX", e.posX.toDouble()); put("posY", e.posY.toDouble()); put("posZ", e.posZ.toDouble())
                            put("rotY", e.rotY.toDouble()); put("scale", e.scale.toDouble())
                            put("glbKey", if (MapStudioStore.hasObject(context, projectId, e.id)) e.id else JSONObject.NULL)
                        })
                    }
                })
                val regions = MapStudioStore.regionsFile(context, projectId)
                if (regions.exists()) runCatching { root.put("regions", JSONObject(regions.readText())) }
                root.toString()
            } catch (e: Exception) {
                Log.w("MapEditor", "Lecture Atelier impossible", e); "{}"
            }

            /** ▶ Tester : scène jouable SBH World construite depuis la map réelle (placements.json). */
            @JavascriptInterface
            fun buildPlayable(compactJson: String): String {
                val r = com.sbh.studio.workshop.PlayableSceneBuilder.buildFromCompact(
                    context, projectId, project?.name ?: "SBh", compactJson
                )
                if (r.ok) runtimeDiagnostics.appendEvent("Playable: ${r.blocksCount} blocks, ${r.mobsCount} mobs")
                return JSONObject().apply {
                    put("ok", r.ok); put("message", r.message)
                    put("blocks", r.blocksCount); put("mobs", r.mobsCount)
                }.toString()
            }

            /** Conserve un modèle .glb importé (avant V1.8.60 : perdu à la fermeture). */
            @JavascriptInterface
            fun saveObjectGlb(key: String, base64: String): Boolean = try {
                MapStudioStore.saveObject(context, projectId, key, Base64.decode(base64, Base64.DEFAULT))
            } catch (e: Exception) {
                Log.e("MapEditor", "Objet .glb non enregistré", e); false
            }

            /** Adresse de lecture d'un .glb conservé, ou "" s'il n'existe pas. */
            @JavascriptInterface
            fun objectUrl(key: String): String =
                if (MapStudioStore.hasObject(context, projectId, key)) MapStudioStore.objectUrl(projectId, key) else ""

            @JavascriptInterface
            fun ready() {
                try {
                    java.io.File(context.filesDir, "map_studio_last_error.txt").delete()
                    java.io.File(context.filesDir, "map_studio_last_ready.txt").writeText(System.currentTimeMillis().toString())
                } catch (e: Exception) { Log.w("MapEditor", "Opération fichier map non critique", e) }
                mainHandler.post {
                    studioReady = true
                    advance(8)
                    loading = false
                    // Personnage envoyé depuis Character Studio : copié HORS du thread principal dans les
                    // objets du projet, puis chargé par URL (avant : lu + converti en base64 sur le thread
                    // principal et passé comme une chaîne de ~33 Mo).
                    PendingMapImport.take()?.let { pending ->
                        Thread {
                            try {
                                val src = java.io.File(pending.filePath)
                                require(src.exists()) { "fichier introuvable" }
                                require(src.length() <= 80L * 1024 * 1024) { "modèle trop lourd (${src.length() / (1024 * 1024)} Mo, max 80 Mo)" }
                                val key = "import_" + System.currentTimeMillis()
                                val dest = MapStudioStore.objectFile(context, projectId, key)
                                dest.parentFile?.mkdirs()
                                src.copyTo(dest, overwrite = true)
                                val url = MapStudioStore.objectUrl(projectId, key)
                                mainHandler.post {
                                    webViewHolder[0]?.evaluateJavascript(
                                        "window.sbhImportGlbFromUrl && window.sbhImportGlbFromUrl(" +
                                            JSONObject.quote(url) + ", " + JSONObject.quote(pending.displayName) + ", " +
                                            JSONObject.quote(key) + ");",
                                        null
                                    )
                                }
                            } catch (e: Exception) {
                                mainHandler.post {
                                    Toast.makeText(context, "Échec de l'import : ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        }.start()
                    }
                }
            }

            @JavascriptInterface
            fun error(name: String, message: String, filename: String, line: Int, column: Int, function: String, stack: String) {
                val recent = runtimeDiagnostics.recentEvents()
                val record = RuntimeErrorRecord(
                    module = "Map Studio",
                    action = "Runtime JavaScript",
                    state = "WebView",
                    name = name.ifBlank { "Error" },
                    message = message,
                    filename = filename.ifBlank { null },
                    line = line.takeIf { it > 0 },
                    column = column.takeIf { it > 0 },
                    function = function.ifBlank { null },
                    stack = stack.ifBlank { null },
                    lastEvent = recent.lastOrNull(),
                    recentActions = recent,
                    runtimeState = mapOf("module" to "Map Studio", "state" to "WebView", "page" to "mapstudio.html", "project" to projectId),
                    raw = listOf(name, message, filename, line, column, function, stack).joinToString(" | "),
                    interpretation = when (name) {
                        "WebGLError" -> "Le GPU ou la WebView ne peut pas initialiser le rendu 3D. Mettez à jour Android System WebView ou réessayez."
                        "TypeError" -> "Une opération utilise une valeur d'un type inattendu ou une affectation interdite."
                        "ReferenceError" -> "Le code utilise un identifiant qui n'est pas défini dans ce contexte."
                        "SyntaxError" -> "Le moteur JavaScript n'a pas pu analyser le code concerné."
                        else -> "Erreur JavaScript capturée pendant l'exécution du module."
                    }
                )
                runtimeDiagnostics.save(record)
                runtimeDiagnostics.appendEvent("EXCEPTION ${record.name}: ${record.message}")
                try { java.io.File(context.filesDir, "map_studio_last_error.txt").writeText(record.developerReport()) } catch (e: Exception) { Log.w("MapEditor", "Opération fichier map non critique", e) }
                mainHandler.post {
                    if (studioReady && name != "WebGLError") {
                        Toast.makeText(context, "Map Studio : ${record.message} [${record.errorId}]", Toast.LENGTH_LONG).show()
                        return@post
                    }
                    loadError = if (name == "WebGLError") {
                        "Rendu 3D indisponible sur cet appareil.\n${record.message}\nMettez à jour Android System WebView, puis Réessayer."
                    } else {
                        "Erreur JavaScript Map Studio : ${record.message} [${record.errorId}]"
                    }
                    loading = false
                    studioReady = false
                }
            }

            /**
             * Enregistre un fichier produit par Map Studio (.mcaddon Bedrock, .schem, .json).
             * Un .mcaddon s'ouvre directement dans Minecraft ; les autres passent par le partage.
             * map_exports/ garde seulement les 10 fichiers les plus récents (avant : grossissait sans fin).
             */
            @JavascriptInterface
            fun saveFile(base64: String, fileName: String): Boolean {
                return try {
                    val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "map_export.bin" }
                    val dir = java.io.File(context.filesDir, "map_exports").apply { mkdirs() }
                    val out = java.io.File(dir, safeName)
                    out.writeBytes(Base64.decode(base64, Base64.DEFAULT))
                    val ok = out.exists() && out.length() > 0
                    dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(10)?.forEach { it.delete() }
                    if (ok) mainHandler.post { openInMinecraftOrShare(out) }
                    ok
                } catch (e: Exception) {
                    Log.e("MapEditor", "Enregistrement $fileName impossible", e)
                    false
                }
            }

            @JavascriptInterface
            fun toast(msg: String) {
                mainHandler.post { Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
            }

            /**
             * Objets 3D de Map Studio → entités de l'Atelier du projet actif.
             * Payload : {entities:[{id,name,pos,rotY,scale,glbName}], removed:[id], linkedMapId}
             * Avant : jamais appelé par la page, et sans suppression.
             */
            @JavascriptInterface
            fun syncEntities(json: String): Boolean = try {
                val root = JSONObject(json)
                val arr = root.optJSONArray("entities") ?: JSONArray()
                val removed = root.optJSONArray("removed")?.let { r -> (0 until r.length()).map { r.optString(it) }.toSet() } ?: emptySet()
                val linkedMapId = root.optString("linkedMapId").ifBlank { null }
                val ws = WorkshopRepository(context)
                val existing = ws.loadEntities()
                    .filterNot { it.projectId == projectId && it.id in removed }
                    .toMutableList()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id.isBlank()) continue
                    val pos = o.optJSONArray("pos")
                    val posX = pos?.optDouble(0, 0.0)?.toFloat() ?: 0f
                    val posY = pos?.optDouble(1, 0.0)?.toFloat() ?: 0f
                    val posZ = pos?.optDouble(2, 0.0)?.toFloat() ?: 0f
                    val rotY = o.optDouble("rotY", 0.0).toFloat()
                    val scale = o.optDouble("scale", 1.0).toFloat().coerceIn(0.05f, 50f)
                    val glbName = o.optString("glbName").ifBlank { null }
                    val idx = existing.indexOfFirst { it.id == id }
                    if (idx >= 0) {
                        val prev = existing[idx]
                        existing[idx] = prev.copy(
                            name = o.optString("name", prev.name),
                            posX = posX, posY = posY, posZ = posZ, rotY = rotY, scale = scale,
                            glbName = glbName ?: prev.glbName,
                            linkedMapId = linkedMapId ?: prev.linkedMapId
                        )
                    } else {
                        existing.add(
                            SceneEntity(
                                id = id, projectId = projectId, name = o.optString("name", id),
                                type = SceneEntityType.OBJECT, glbName = glbName, linkedMapId = linkedMapId,
                                posX = posX, posY = posY, posZ = posZ, rotY = rotY, scale = scale
                            )
                        )
                    }
                }
                ws.saveEntities(existing)
                true
            } catch (e: Exception) {
                Log.w("MapEditor", "Sync entités impossible", e)
                false
            }
        }
    }

    val assetLoader = remember {
        MapStudioStore.root(context).mkdirs()
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            // Objets .glb du projet, lus par fetch() (lecture seule, dossier map_studio uniquement).
            .addPathHandler(MapStudioStore.URL_PATH, WebViewAssetLoader.InternalStoragePathHandler(context, MapStudioStore.root(context)))
            .build()
    }

    val webView = remember {
        WebView(context).apply {
            setBackgroundColor(Color.parseColor("#1A1612"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mediaPlaybackRequiresUserGesture = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                // Le HTML possède déjà un viewport mobile explicite.
                useWideViewPort = false
                loadWithOverviewMode = false
                // ⚠️ Ne PAS forcer setLayerType(LAYER_TYPE_HARDWARE, ...) : cause connue d'écran noir.
            }
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    consoleMessage?.let {
                        runtimeDiagnostics.appendEvent("CONSOLE ${it.messageLevel()}: ${it.message()} @ ${it.sourceId()}:${it.lineNumber()}")
                    }
                    return true
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = filePathCallback
                    return try {
                        fileChooserLauncher.launch(arrayOf("application/json", "application/octet-stream", "*/*"))
                        true
                    } catch (e: Exception) {
                        Log.w("MapEditor", "File chooser échoué", e)
                        fileChooserCallback?.onReceiveValue(null)
                        fileChooserCallback = null
                        false
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val url = request?.url ?: return null
                    return assetLoader.shouldInterceptRequest(url)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    return uri.scheme != "https" || uri.host != "appassets.androidplatform.net"
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url?.contains("mapstudio.html") != true) return
                    pageReady = true
                    advance(5)
                    runtimeDiagnostics.appendEvent("Module loaded: Map Studio")
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    if (request?.isForMainFrame == true) {
                        runtimeDiagnostics.appendEvent("LOAD_ERROR: ${error?.description ?: "Erreur de chargement Map Studio"}")
                        loadError = error?.description?.toString() ?: "Erreur de chargement Map Studio"
                        loading = false
                        studioReady = false
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        advance(1); delay(180)
        advance(2); delay(180)
        advance(3); delay(220)
        advance(4)
        delay(900)
        if (!studioReady && loadError == null && pageReady) advance(6)
    }

    val timeoutRunnable = remember { Runnable {
        if (loading && !studioReady && loadError == null) {
            loadError = "Map Studio n'a pas terminé son initialisation après 25 secondes.\nVérifiez la WebView système, la mémoire disponible, puis Réessayer."
            loading = false
        }
    } }

    DisposableEffect(Unit) {
        runtimeDiagnostics.appendEvent("Module opened")
        webViewHolder[0] = webView
        webView.addJavascriptInterface(bridge, "SBhBridge")
        mainHandler.postDelayed(timeoutRunnable, 25_000L)
        webView.loadUrl("https://appassets.androidplatform.net/assets/mapstudio.html")
        onDispose {
            mainHandler.removeCallbacks(timeoutRunnable)
            webViewHolder[0] = null
            try {
                webView.removeJavascriptInterface("SBhBridge")
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            } catch (e: Exception) { Log.w("MapEditor", "Échec non critique", e) }
        }
    }

    LaunchedEffect(retryCount) {
        if (retryCount <= 0) return@LaunchedEffect
        loading = true
        loadError = null
        pageReady = false
        studioReady = false
        loadStage = 1
        mainHandler.removeCallbacks(timeoutRunnable)
        mainHandler.postDelayed(timeoutRunnable, 25_000L)
        webView.loadUrl("https://appassets.androidplatform.net/assets/mapstudio.html")
    }

    // Retour : la page enregistre la map (sauvegarde auto du projet) AVANT la fermeture.
    // Avant : fermeture immédiate → tout le travail non sauvegardé était perdu.
    BackHandler {
        if (closing) return@BackHandler
        if (!studioReady || loadError != null) { onBack(); return@BackHandler }
        closing = true
        val fallback = Runnable { onBack() }
        mainHandler.postDelayed(fallback, 2_000L)
        // V1.8.61 : la page ferme d'abord sa fenêtre ouverte (fiche, code, rapport, dialogue…) ;
        // elle n'enregistre la map et ne demande la fermeture que s'il n'y a rien d'ouvert.
        webView.evaluateJavascript("(window.sbhBack ? window.sbhBack() : (window.sbhBeforeClose && window.sbhBeforeClose(), 'close'))") { result ->
            mainHandler.removeCallbacks(fallback)
            if (result?.contains("handled") == true) closing = false else onBack()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AgwColors.DeepNight)
    ) {
        AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())

        if (loading) {
            Box(
                modifier = Modifier.fillMaxSize().background(AgwColors.DeepNight),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "SBH / MAP STUDIO",
                        color = AgwColors.SacredGold,
                        style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                    Text(
                        "ÉDITEUR DE MONDE · ${project?.name ?: "sans projet"}",
                        color = AgwColors.Sand,
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    LinearProgressIndicator(
                        progress = { ((loadStage.coerceIn(0, 8)) / 8f) },
                        color = AgwColors.SacredGold,
                        trackColor = AgwColors.NightStone,
                        modifier = Modifier.padding(top = 18.dp).fillMaxWidth().height(3.dp)
                    )
                    androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))
                    CircularProgressIndicator(color = AgwColors.SacredGold)
                    Text(
                        when (loadStage.coerceIn(0, 8)) {
                            0 -> "Préparation de Map Studio"
                            1 -> "Initialisation de Map Studio"
                            2 -> "Préparation du projet"
                            3 -> "Chargement du World Core"
                            4 -> "Chargement de l'éditeur 3D"
                            5 -> "Chargement des régions et ressources"
                            6 -> "Construction du monde"
                            7 -> "Préparation de la caméra"
                            else -> "Monde prêt · entrée dans Map Studio"
                        },
                        color = AgwColors.PaleMarble,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        }

        if (loadError != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AgwColors.DeepNight.copy(alpha = 0.92f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Map Studio n'a pas pu se charger", color = AgwColors.SacredGold)
                    Text(loadError ?: "", color = AgwColors.Sand, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
                    androidx.compose.foundation.layout.Row(
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(onClick = { retryCount++ }) { Text("Réessayer", color = AgwColors.SacredGold) }
                        TextButton(onClick = onBack) { Text("← Retour", color = AgwColors.GoldSoft) }
                    }
                }
            }
        }
    }
}
