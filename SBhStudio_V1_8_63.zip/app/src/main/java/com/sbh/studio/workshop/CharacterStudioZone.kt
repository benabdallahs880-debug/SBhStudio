package com.sbh.studio.workshop

import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Divider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sbh.studio.character.*
import com.sbh.studio.ui.*

/** Character Studio Étape 2 : projets + import de modèle + viewport 3D réel. */
@Composable
fun CharacterStudioZone(
    projectId: String,
    hasProject: Boolean,
    projects: List<CharacterProject>,
    onSave: (CharacterProject) -> Unit,
    onDelete: (CharacterProject) -> Unit,
    onMessage: (String) -> Unit,
    onSendToMapStudio: (filePath: String, displayName: String) -> Unit = { _, _ -> },
    /** V1.8.62 (zone Créatures) : la liste est affichée par la zone Créatures, pas ici. */
    showList: Boolean = true,
    /** V1.8.62 : personnage à ouvrir (null = aucun), appliqué à chaque [focusKey]. */
    focus: CharacterProject? = null,
    focusKey: Int = 0
) {
    var selected by remember(projectId) { mutableStateOf<CharacterProject?>(null) }
    var name by remember(projectId) { mutableStateOf("Nouveau personnage") }
    var previewMode by remember(projectId) { mutableStateOf(true) }
    var analysis by remember(projectId) { mutableStateOf<CharacterAnalysisResult?>(null) }
    var referenceView by remember(projectId) { mutableStateOf(CharacterReferenceView.FRONT) }
    var readiness by remember(projectId) { mutableStateOf<CharacterGenerationReadiness?>(null) }
    var generationJob by remember(projectId) { mutableStateOf<CharacterGenerationJob?>(null) }
    var generationOptions by remember(projectId) { mutableStateOf(CharacterGenerationOptions()) }
    var remoteEndpoint by remember(projectId) { mutableStateOf("") }
    val context = LocalContext.current
    var meshyApiKey by remember(projectId) { mutableStateOf(MeshyApiKeyStore.load(context = context).orEmpty()) }
    var showMeshyKey by remember(projectId) { mutableStateOf(false) }
    val generationScope = rememberCoroutineScope()

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        if (!hasProject) {
            onMessage("Ouvrez un projet avant de créer un personnage")
            return@rememberLauncherForActivityResult
        }
        runCatching {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
        }
        val current = selected ?: CharacterProject(projectId = projectId, name = name)
        val updated = current.copy(
            projectId = projectId,
            name = name.ifBlank { current.name },
            sourceImageUri = uri.toString(),
            sourceImageName = uri.lastPathSegment,
            status = CharacterStatus.IMAGE_IMPORTED,
            updatedAt = System.currentTimeMillis()
        )
        onSave(updated)
        selected = updated
        onMessage("Image importée. Référence enregistrée.")
    }

    val referenceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        val current = selected ?: CharacterProject(projectId = projectId, name = name)
        val ref = CharacterReference(
            uri = uri.toString(),
            name = uri.lastPathSegment ?: "reference",
            view = referenceView
        )
        val updated = current.copy(
            references = (current.references.filterNot { it.view == referenceView } + ref),
            sourceImageUri = current.sourceImageUri ?: uri.toString(),
            sourceImageName = current.sourceImageName ?: (uri.lastPathSegment ?: "reference"),
            status = CharacterStatus.IMAGE_IMPORTED,
            updatedAt = System.currentTimeMillis()
        )
        onSave(updated)
        selected = updated
        readiness = CharacterGenerationPlanner.evaluate(updated)
        onMessage("Vue ${referenceView.name.lowercase()} ajoutée au dossier de génération.")
    }

    val modelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        if (!hasProject) {
            onMessage("Ouvrez un projet avant d'importer un modèle")
            return@rememberLauncherForActivityResult
        }
        runCatching {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
        }
        val current = selected ?: CharacterProject(projectId = projectId, name = name)
        val updated = current.copy(
            projectId = projectId,
            name = name.ifBlank { current.name },
            modelUri = uri.toString(),
            modelName = uri.lastPathSegment ?: "modele.glb",
            status = CharacterStatus.MODEL_READY,
            updatedAt = System.currentTimeMillis()
        )
        onSave(updated)
        selected = updated
        previewMode = true
        onMessage("Modèle 3D importé. Le viewport est prêt.")
    }

    LaunchedEffect(focusKey) {
        if (focusKey != 0) {
            selected = focus
            if (focus != null) { name = focus.name; previewMode = true } else name = "Nouveau personnage"
        }
    }

    // V1.8.62 : sans la liste (zone Créatures), tout le contenu défile (avant : panneau coupé en bas).
    Column(
        (if (showList) Modifier.fillMaxSize() else Modifier.fillMaxSize().verticalScroll(rememberScrollState())).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionTitle("Character Studio 3D")
        Text(
            "Étape 2 · prévisualisation 3D réelle du personnage.",
            color = AgwColors.Sand
        )
        Text(
            "GLB/GLTF · rotation tactile · zoom · éclairage · inspecteur. Le rig reste indépendant.",
            color = AgwColors.SilverMuted,
            style = MaterialTheme.typography.bodySmall
        )

        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nom du personnage") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                // V1.8.62 : trois boutons sur une seule ligne sans largeur imposée → sur téléphone
                // ils étaient écrasés en traits jaunes sans texte. Un bouton pleine largeur par ligne.
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    GoldPrimaryButton(text = "🖼 Importer une image", modifier = Modifier.fillMaxWidth(), onClick = {
                        imageLauncher.launch(arrayOf("image/*"))
                    })
                    GoldPrimaryButton(text = "📦 Importer un modèle 3D (.glb)", modifier = Modifier.fillMaxWidth(), onClick = {
                        modelLauncher.launch(arrayOf("model/gltf-binary", "model/gltf+json", "application/octet-stream"))
                    })
                    GoldOutlineButton(text = "➕ Nouveau personnage", modifier = Modifier.fillMaxWidth(), onClick = {
                        if (!hasProject) onMessage("Ouvrez un projet")
                        else {
                            val c = CharacterProject(
                                projectId = projectId,
                                name = name.ifBlank { "Nouveau personnage" }
                            )
                            onSave(c)
                            selected = c
                            onMessage("Projet personnage créé")
                        }
                    })
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GoldOutlineButton(text = if (previewMode) "Inspecteur" else "Aperçu 3D", onClick = {
                previewMode = !previewMode
            })
            selected?.let { c ->
                Text(
                    "État : ${c.status.name} · Rig : ${c.rigMode.name}",
                    color = AgwColors.SilverMuted,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        val current = selected
        if (previewMode && current != null) {
            CharacterPreviewPanel(
                character = current,
                modifier = Modifier.fillMaxWidth()
            )
            current.modelUri?.takeIf { it.isNotBlank() }?.let { modelPath ->
                GoldPrimaryButton(
                    text = "📤 Envoyer vers Map Studio",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                    val file = java.io.File(modelPath)
                    if (!file.exists()) {
                        onMessage("Fichier modèle introuvable, régénérez le personnage")
                    } else {
                        onSendToMapStudio(modelPath, current.modelName ?: current.name)
                        onMessage("« ${current.name} » envoyé — ouverture de Map Studio…")
                    }
                })
            }
            CharacterGenerationPanel(
                character = current,
                analysis = analysis,
                onAnalyze = { uri ->
                    analysis = runCatching { CharacterImageAnalyzer.analyze(context, uri) }
                        .onFailure { onMessage("Analyse impossible : ${it.message ?: "erreur inconnue"}") }
                        .getOrNull()
                    if (analysis != null) onMessage("Référence analysée localement. Aucune image n'a été envoyée.")
                },
                onMessage = onMessage,
                generationJob = generationJob,
                options = generationOptions,
                onOptionsChange = { generationOptions = it },
                remoteEndpoint = remoteEndpoint,
                onRemoteEndpointChange = { remoteEndpoint = it },
                onGenerate = { character ->
                    // V1.8.56 : avant, TOUS les fournisseurs (Meshy, IA distante) aboutissaient au
                    // générateur local, qui recopie le mannequin embarqué — la clé Meshy était
                    // demandée mais jamais utilisée et l'écran annonçait « Modèle généré ».
                    val provider = generationOptions.provider
                    val optionsSnapshot = generationOptions
                    val apiKey = meshyApiKey.trim()
                    val endpoint = remoteEndpoint.trim()
                    generationJob = CharacterGenerationJob(
                        characterId = character.id,
                        generatorId = when (provider) {
                            CharacterGenerationProvider.MESHY -> "meshy"
                            CharacterGenerationProvider.REMOTE_AI -> CharacterGenerationProvider.REMOTE_AI.name
                            else -> LocalPreviewGenerator.id
                        }
                    )
                    generationScope.launch(Dispatchers.IO) {
                        val onProgress: (Int, String) -> Unit = { progress, message ->
                            generationScope.launch(Dispatchers.Main) { generationJob = generationJob?.copy(status = CharacterGenerationJobStatus.RUNNING, progress = progress, message = message) }
                        }
                        val result = when (provider) {
                            CharacterGenerationProvider.MESHY ->
                                MeshyImageTo3DClient.generate(context, character, apiKey, onProgress = onProgress)
                            CharacterGenerationProvider.REMOTE_AI ->
                                RemoteCharacterGenerationClient.submit(
                                    context,
                                    character,
                                    CharacterGenerationRequestFactory.create(character, optionsSnapshot),
                                    RemoteGenerationConfig(endpoint),
                                    onProgress
                                )
                            else -> CharacterGenerationEngine.generateLocalPrototype(context, character, onProgress)
                        }
                        generationScope.launch(Dispatchers.Main) {
                            generationJob = result.job
                            if (result.modelUri != null) {
                                val updated = character.copy(modelUri = result.modelUri, modelName = result.modelName, status = CharacterStatus.MODEL_READY, updatedAt = System.currentTimeMillis())
                                onSave(updated)
                                selected = updated
                                onMessage("Modèle généré et injecté dans le viewport 3D.")
                            } else onMessage("Génération échouée : ${result.job.message}")
                        }
                    }
                },
                meshyApiKey = meshyApiKey,
                onMeshyApiKeyChange = { meshyApiKey = it },
                showMeshyKey = showMeshyKey,
                onShowMeshyKeyChange = { showMeshyKey = it }
            )
            CharacterGenerationPreparationPanel(
                character = current,
                readiness = readiness,
                referenceView = referenceView,
                onViewChange = { referenceView = it },
                onAddReference = { referenceLauncher.launch(arrayOf("image/*")) },
                onPrepare = {
                    readiness = CharacterGenerationPlanner.evaluate(current)
                    if (readiness?.ready == true) onMessage("Dossier Image→3D prêt : ${current.references.size} vue(s). Génération réelle à connecter au moteur choisi.")
                    else onMessage("Dossier incomplet : corrigez les éléments bloquants avant la génération.")
                }
            )
        } else if (!previewMode && current != null) {
            CharacterInspector(current)
            CharacterGenerationPanel(
                character = current,
                analysis = analysis,
                onAnalyze = { uri -> analysis = runCatching { CharacterImageAnalyzer.analyze(context, uri) }.getOrNull() },
                onMessage = onMessage,
                meshyApiKey = meshyApiKey,
                onMeshyApiKeyChange = { meshyApiKey = it },
                showMeshyKey = showMeshyKey,
                onShowMeshyKeyChange = { showMeshyKey = it }
            )
        }

        if (showList) {
        SectionTitle("Personnages du projet")
        if (projects.isEmpty()) {
            Text(
                "Aucun personnage. Créez-en un puis importez une image ou un modèle 3D.",
                color = AgwColors.Sand
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(projects, key = { it.id }) { item ->
                    GlassCard(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.name,
                                    color = AgwColors.PaleMarble,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    "${item.status.name} · rig ${item.rigMode.name}",
                                    color = AgwColors.SilverMuted,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                item.modelName?.let {
                                    Text("3D : $it", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                                }
                                item.sourceImageName?.let {
                                    Text("Référence : $it", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            TextButton(onClick = {
                                selected = item
                                name = item.name
                                previewMode = true
                            }) { Text("Ouvrir") }
                            TextButton(onClick = { onDelete(item); if (selected?.id == item.id) selected = null }) {
                                Text("Supprimer")
                            }
                        }
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun CharacterGenerationPreparationPanel(
    character: CharacterProject,
    readiness: CharacterGenerationReadiness?,
    referenceView: CharacterReferenceView,
    onViewChange: (CharacterReferenceView) -> Unit,
    onAddReference: () -> Unit,
    onPrepare: () -> Unit
) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Étape 4 · dossier multi-vues → génération 3D", color = AgwColors.PaleMarble, style = MaterialTheme.typography.titleMedium)
            Text("Prépare les vues avant de lancer un moteur Image→3D. Rien n'est envoyé automatiquement.", color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(CharacterReferenceView.FRONT, CharacterReferenceView.LEFT, CharacterReferenceView.RIGHT, CharacterReferenceView.BACK).forEach { view ->
                    GoldOutlineButton(text = view.name.lowercase(), onClick = { onViewChange(view) })
                }
            }
            Text("Vue sélectionnée : ${referenceView.name.lowercase()}", color = AgwColors.Sand)
            Text("Références enregistrées : ${character.references.size}", color = AgwColors.Sand)
            character.references.forEach { Text("• ${it.view.name.lowercase()} · ${it.name}", color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldPrimaryButton(text = "Ajouter cette vue", onClick = onAddReference)
                GoldOutlineButton(text = "Préparer génération", onClick = onPrepare)
            }
            readiness?.let { r ->
                Text("Préparation : ${r.score}%", color = AgwColors.PaleMarble)
                r.blockers.forEach { Text("Bloquant · $it", color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall) }
                r.recommendations.forEach { Text("Conseil · $it", color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
private fun CharacterInspector(character: CharacterProject) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Inspecteur du modèle", color = AgwColors.PaleMarble, style = MaterialTheme.typography.titleMedium)
            Text("Nom : ${character.name}", color = AgwColors.Sand)
            Text("Modèle : ${character.modelName ?: "Aucun modèle importé"}", color = AgwColors.Sand)
            Text("Format : GLB / GLTF", color = AgwColors.Sand)
            Text("Rig : ${character.rigMode.name}", color = AgwColors.Sand)
            Text("Animation : ${if (character.status == CharacterStatus.ANIMATED) "présente" else "aucune"}", color = AgwColors.Sand)
            Text(
                "Le modèle et le squelette sont volontairement séparés. Cette étape ne modifie pas la géométrie.",
                color = AgwColors.SilverMuted,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}


@Composable
private fun CharacterGenerationPanel(
    character: CharacterProject,
    analysis: CharacterAnalysisResult?,
    onAnalyze: (Uri) -> Unit,
    onMessage: (String) -> Unit,
    generationJob: CharacterGenerationJob? = null,
    options: CharacterGenerationOptions = CharacterGenerationOptions(),
    onOptionsChange: (CharacterGenerationOptions) -> Unit = {},
    remoteEndpoint: String = "",
    onRemoteEndpointChange: (String) -> Unit = {},
    onGenerate: (CharacterProject) -> Unit = {},
    meshyApiKey: String = "",
    onMeshyApiKeyChange: (String) -> Unit = {},
    showMeshyKey: Boolean = false,
    onShowMeshyKeyChange: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onAnalyze(uri)
    }
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Étape 3 · Image → analyse → préparation 3D", color = AgwColors.PaleMarble, style = MaterialTheme.typography.titleMedium)
            Text(
                "Cette étape prépare réellement la référence pour un futur moteur Image→3D. L'analyse est locale et ne prétend pas fabriquer un modèle IA qui n'existe pas encore.",
                color = AgwColors.SilverMuted,
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                GoldPrimaryButton(text = "Analyser l'image", onClick = {
                    launcher.launch(arrayOf("image/*"))
                })
                Text("Source : ${character.sourceImageName ?: "aucune"}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            }
            analysis?.let { result ->
                Divider()
                Text("Profil de génération", color = AgwColors.PaleMarble)
                Text("${result.profile.format} · ${result.profile.imageWidth} × ${result.profile.imageHeight} · ${result.profile.quality}", color = AgwColors.Sand)
                Text("Cadrage : ${result.profile.detectedView}", color = AgwColors.Sand)
                if (result.warnings.isNotEmpty()) {
                    Text("Points à corriger", color = AgwColors.PaleMarble)
                    result.warnings.forEach { Text("• $it", color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall) }
                }
                Text("Préparation recommandée", color = AgwColors.PaleMarble)
                result.suggestions.forEach { Text("• $it", color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall) }
            }
            Divider()
            Text("Étape 6 · moteur de génération", color = AgwColors.PaleMarble, style = MaterialTheme.typography.titleMedium)
            Text("Choisissez le moteur et les paramètres qui seront transmis au job. Le connecteur distant reste désactivé tant qu'aucun service n'est configuré.", color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GoldOutlineButton(text = "Local", onClick = {
                    onOptionsChange(options.copy(provider = CharacterGenerationProvider.LOCAL_PREVIEW))
                })
                GoldOutlineButton(text = "IA distante", onClick = {
                    onOptionsChange(options.copy(provider = CharacterGenerationProvider.REMOTE_AI))
                })
                GoldOutlineButton(text = "Meshy", onClick = {
                    onOptionsChange(options.copy(provider = CharacterGenerationProvider.MESHY))
                })
            }
            Text("Moteur : ${CharacterGeneratorCatalog.descriptor(options.provider).label}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            if (options.provider == CharacterGenerationProvider.REMOTE_AI) {
                OutlinedTextField(
                    value = remoteEndpoint,
                    onValueChange = onRemoteEndpointChange,
                    label = { Text("Endpoint HTTPS du moteur") },
                    placeholder = { Text("https://serveur.example/jobs") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Contrat attendu : POST /jobs → jobId, puis GET /jobs/{id} → resultUrl GLB.", color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall)
            }
            if (options.provider == CharacterGenerationProvider.MESHY) {
                OutlinedTextField(
                    value = meshyApiKey,
                    onValueChange = onMeshyApiKeyChange,
                    label = { Text("Clé API Meshy") },
                    visualTransformation = if (showMeshyKey) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GoldOutlineButton(
                        text = if (showMeshyKey) "Masquer" else "Afficher",
                        onClick = { onShowMeshyKeyChange(!showMeshyKey) }
                    )
                    GoldOutlineButton(
                        text = "Enregistrer la clé",
                        onClick = {
                            runCatching { MeshyApiKeyStore.save(context, meshyApiKey.trim()) }
                                .onSuccess { onMessage("Clé Meshy enregistrée dans Android Keystore.") }
                                .onFailure { onMessage(it.message ?: "Impossible d'enregistrer la clé.") }
                        }
                    )
                    GoldOutlineButton(
                        text = "Effacer",
                        onClick = {
                            MeshyApiKeyStore.clear(context)
                            onMeshyApiKeyChange("")
                            onMessage("Clé Meshy supprimée.")
                        }
                    )
                }
                Text(
                    "Meshy accepte une image unique ou 2 à 4 vues. SBh Studio utilisera le multi-image quand plusieurs références sont disponibles.",
                    color = AgwColors.SilverMuted,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GoldOutlineButton(
                    text = "Style ${options.targetStyle}",
                    onClick = {
                        val next = if (options.targetStyle == "REALISTIC_GAME") "STYLIZED_GAME" else "REALISTIC_GAME"
                        onOptionsChange(options.copy(targetStyle = next))
                    }
                )
                GoldOutlineButton(
                    text = "Détail ${options.detailLevel}",
                    onClick = {
                        onOptionsChange(options.copy(detailLevel = (options.detailLevel % 3) + 1))
                    }
                )
                GoldOutlineButton(
                    text = "Textures ${options.textureQuality}",
                    onClick = {
                        val next = if (options.textureQuality == "2K") "4K" else "2K"
                        onOptionsChange(options.copy(textureQuality = next))
                    }
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldOutlineButton(
                    text = if (options.generateTextures) "Textures : oui" else "Textures : non",
                    onClick = {
                        onOptionsChange(options.copy(generateTextures = !options.generateTextures))
                    }
                )
                GoldOutlineButton(
                    text = if (options.generateSkeleton) "Rig : oui" else "Rig : non",
                    onClick = {
                        onOptionsChange(options.copy(generateSkeleton = !options.generateSkeleton))
                    }
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldPrimaryButton(
                    text = when (options.provider) {
                        CharacterGenerationProvider.LOCAL_PREVIEW -> "Générer localement"
                        CharacterGenerationProvider.MESHY -> "Générer avec Meshy"
                        else -> "Lancer IA distante"
                    },
                    onClick = {
                        val readiness = CharacterGenerationPlanner.evaluate(character)
                        if (!readiness.ready) {
                            onMessage("Génération bloquée : ${readiness.blockers.joinToString(" · ")}")
                        } else if (options.provider == CharacterGenerationProvider.REMOTE_AI) {
                            val config = RemoteGenerationConfig(remoteEndpoint)
                            if (!RemoteCharacterGenerationClient.isConfigured(config)) {
                                onMessage("Configurez un endpoint HTTPS avant de lancer l'IA distante.")
                            } else {
                                onGenerate(character)
                            }
                        } else if (options.provider == CharacterGenerationProvider.MESHY) {
                            if (meshyApiKey.isBlank()) {
                                onMessage("Renseignez une clé API Meshy avant de générer.")
                            } else {
                                onGenerate(character)
                            }
                        } else {
                            CharacterGenerationRequestFactory.create(character, options)
                            onGenerate(character)
                        }
                    }
                )
                GoldOutlineButton(
                    text = "Voir le contrat",
                    onClick = {
                        onMessage(
                            if (options.provider == CharacterGenerationProvider.REMOTE_AI)
                                "Contrat distant : POST /jobs puis suivi GET /jobs/{id}."
                            else
                                "Requête locale prête : références + style + détail + textures + rig."
                        )
                    }
                )
            }
            generationJob?.let { job ->
                Divider()
                Text("Job ${job.status.name} · ${job.progress}%", color = AgwColors.PaleMarble)
                Text(job.message, color = AgwColors.SilverMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

