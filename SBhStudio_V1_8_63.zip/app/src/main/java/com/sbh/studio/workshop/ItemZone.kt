package com.sbh.studio.workshop

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.SbhItem
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle
import java.util.UUID

private val ITEM_CATEGORIES = listOf(
    "weapon", "tool", "armor", "shield", "material", "food", "other"
)
private val ITEM_SLOTS = listOf(
    "none", "mainhand", "offhand", "head", "chest", "legs", "feet"
)

/**
 * Zone Items — atelier libre unifié.
 * Liste + recherche + édition / duplication / suppression. Aucune génération forcée.
 */
@Composable
internal fun ItemZone(
    projectId: String,
    items: List<SbhItem>,
    textures: List<TextureProject> = emptyList(),
    onSave: (SbhItem) -> Unit,
    onDelete: (SbhItem) -> Unit,
    onAddReclamationPresets: (() -> Unit)? = null,
    onAddPracticeWeapons: (() -> Unit)? = null,
    onAddPracticeArmor: (() -> Unit)? = null,
    onAddPracticeDefense: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var filterCategory by rememberSaveable { mutableStateOf("all") }
    var tab by rememberSaveable { mutableStateOf(0) } // 0 Identité · 1 Stats · 2 Rendu · 3 Notes

    var name by rememberSaveable { mutableStateOf("Nouvel item") }
    var identifier by rememberSaveable { mutableStateOf("agw:nouvel_item") }
    var dmg by rememberSaveable { mutableStateOf("0") }
    var dur by rememberSaveable { mutableStateOf("100") }
    var category by rememberSaveable { mutableStateOf("other") }
    var description by rememberSaveable { mutableStateOf("") }
    var tagsText by rememberSaveable { mutableStateOf("") }
    var maxStack by rememberSaveable { mutableStateOf("64") }
    var slot by rememberSaveable { mutableStateOf("none") }
    var enchantable by rememberSaveable { mutableStateOf(false) }
    var glow by rememberSaveable { mutableStateOf(false) }
    var notes by rememberSaveable { mutableStateOf("") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            tex = u.toString()
        }
    }

    fun resetForm() {
        editingId = null
        name = "Nouvel item"
        identifier = "agw:nouvel_item"
        dmg = "0"
        dur = "100"
        category = "other"
        description = ""
        tagsText = ""
        maxStack = "64"
        slot = "none"
        enchantable = false
        glow = false
        notes = ""
        tex = null
        tab = 0
    }

    fun loadItem(item: SbhItem) {
        editingId = item.id
        name = item.name
        identifier = item.identifier
        dmg = item.damage.toString()
        dur = item.durability.toString()
        category = item.category.ifBlank { "other" }
        description = item.description
        tagsText = item.tags.joinToString(", ")
        maxStack = item.maxStack.toString()
        slot = item.slot.ifBlank { "none" }
        enchantable = item.enchantable
        glow = item.glow
        notes = item.notes
        tex = item.textureUri
        tab = 0
    }

    fun buildItem(keepId: String? = editingId): SbhItem {
        val tags = tagsText.split(",", ";", " ")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
        val stack = maxStack.toIntOrNull()?.coerceIn(1, 64) ?: 64
        val isEquip = category in listOf("weapon", "tool", "armor", "shield")
        return SbhItem(
            id = keepId ?: UUID.randomUUID().toString(),
            projectId = projectId,
            name = name.trim().ifBlank { "Item" },
            identifier = identifier.trim().ifBlank { "agw:item" },
            damage = dmg.toIntOrNull()?.coerceAtLeast(0) ?: 0,
            durability = dur.toIntOrNull()?.coerceAtLeast(1) ?: 100,
            textureUri = tex,
            category = category,
            description = description.trim(),
            tags = tags,
            maxStack = if (isEquip) 1 else stack,
            slot = slot,
            enchantable = enchantable,
            glow = glow,
            notes = notes.trim()
        )
    }

    val filtered = remember(items, search, filterCategory) {
        items.filter { item ->
            val q = search.trim().lowercase()
            val matchQ = q.isEmpty() ||
                item.name.lowercase().contains(q) ||
                item.identifier.lowercase().contains(q) ||
                item.tags.any { it.lowercase().contains(q) }
            val matchCat = filterCategory == "all" || item.category == filterCategory
            matchQ && matchCat
        }
    }

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
    ) {
        SectionTitle("Objets & armes")
        Text(
            "${items.size} item(s) · atelier libre — créer, modifier, dupliquer",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        // Presets
        if (onAddPracticeWeapons != null) {
            GoldPrimaryButton("Practice — Armes", onClick = onAddPracticeWeapons, modifier = Modifier.fillMaxWidth())
        }
        if (onAddPracticeDefense != null) {
            GoldPrimaryButton("Practice — Boucliers", onClick = onAddPracticeDefense, modifier = Modifier.fillMaxWidth())
        }
        if (onAddPracticeArmor != null) {
            GoldPrimaryButton("Practice — Armures", onClick = onAddPracticeArmor, modifier = Modifier.fillMaxWidth())
        }
        if (onAddReclamationPresets != null) {
            GoldOutlineButton("Presets Reclamation", onClick = onAddReclamationPresets, modifier = Modifier.fillMaxWidth())
        }

        // Recherche / filtre
        OutlinedTextField(
            search,
            { search = it },
            label = { Text("Rechercher (nom, id, tag)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            FilterChip(
                selected = filterCategory == "all",
                onClick = { filterCategory = "all" },
                label = { Text("Tous") }
            )
            ITEM_CATEGORIES.take(4).forEach { cat ->
                FilterChip(
                    selected = filterCategory == cat,
                    onClick = { filterCategory = cat },
                    label = { Text(cat) }
                )
            }
        }

        // Liste
        Text(
            if (editingId == null) "Liste (${filtered.size})" else "Liste — appuyer pour changer d'item",
            fontWeight = FontWeight.SemiBold,
            color = AgwColors.SacredGold
        )
        if (filtered.isEmpty()) {
            Text("Aucun item. Crée-en un ci-dessous ou importe un preset.", color = AgwColors.Sand)
        } else {
            filtered.forEach { item ->
                val selected = item.id == editingId
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) AgwColors.NightStone else AgwColors.DeepNight
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (selected) Modifier.border(2.dp, AgwColors.SacredGold, RoundedCornerShape(8.dp))
                            else Modifier
                        )
                        .clickable { loadItem(item) }
                ) {
                    Row(
                        Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(item.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                            Text(
                                "${item.identifier} · ${item.category} · dmg ${item.damage} · dur ${item.durability}",
                                color = AgwColors.Sand,
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (item.tags.isNotEmpty()) {
                                Text(
                                    item.tags.joinToString(" · "),
                                    color = AgwColors.DesertOchre,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        TextButton(onClick = {
                            if (editingId == item.id) resetForm()
                            onDelete(item)
                        }) { Text("X") }
                    }
                }
            }
        }

        HorizontalDivider(color = AgwColors.Sand.copy(alpha = 0.3f))

        // Éditeur
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (editingId == null) "Nouvel item" else "Modifier l'item",
                    fontWeight = FontWeight.SemiBold,
                    color = AgwColors.SacredGold
                )

                TabRow(selectedTabIndex = tab, containerColor = AgwColors.DeepNight) {
                    listOf("Identité", "Stats", "Rendu", "Notes").forEachIndexed { i, label ->
                        Tab(
                            selected = tab == i,
                            onClick = { tab = i },
                            text = { Text(label, fontSize = 12.sp) }
                        )
                    }
                }

                when (tab) {
                    0 -> {
                        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text("Catégorie", color = AgwColors.Sand, fontSize = 12.sp)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                        ) {
                            ITEM_CATEGORIES.forEach { cat ->
                                FilterChip(
                                    selected = category == cat,
                                    onClick = {
                                        category = cat
                                        if (cat in listOf("weapon", "tool", "armor", "shield")) {
                                            maxStack = "1"
                                            if (slot == "none" && cat == "weapon") slot = "mainhand"
                                            if (cat == "shield") slot = "offhand"
                                        }
                                    },
                                    label = { Text(cat, fontSize = 11.sp) }
                                )
                            }
                        }
                        OutlinedTextField(
                            description,
                            { description = it },
                            label = { Text("Description") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            tagsText,
                            { tagsText = it },
                            label = { Text("Tags (séparés par virgule)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    1 -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(dur, { dur = it }, label = { Text("Durabilité") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(maxStack, { maxStack = it }, label = { Text("Stack max") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Text("Slot d'équipement", color = AgwColors.Sand, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            ITEM_SLOTS.forEach { s ->
                                FilterChip(
                                    selected = slot == s,
                                    onClick = { slot = s },
                                    label = { Text(s, fontSize = 11.sp) }
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(enchantable, { enchantable = it })
                            Text("Enchantable", color = AgwColors.PaleMarble)
                            Spacer(Modifier.width(12.dp))
                            Checkbox(glow, { glow = it })
                            Text("Lueur", color = AgwColors.PaleMarble)
                        }
                    }
                    2 -> {
                        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
                            val currentTex = tex
                            Text(
                                when {
                                    currentTex == null -> "Fichier image externe"
                                    currentTex.startsWith("sbhtex://") -> "Texture Studio liée ✓"
                                    currentTex.startsWith("asset://") -> "Texture asset ✓"
                                    else -> "Fichier externe ✓"
                                }
                            )
                        }
                        StudioTexturePicker(
                            textures = textures,
                            selectedUri = tex,
                            onSelect = { tex = it },
                            preferredFormats = listOf("BLOCK_16", "BLOCK_32", "ITEM_16", "FILTER_MAP")
                        )
                        if (tex != null) {
                            TextButton(onClick = { tex = null }) { Text("Retirer la texture") }
                        }
                    }
                    3 -> {
                        OutlinedTextField(
                            notes,
                            { notes = it },
                            label = { Text("Notes libres (atelier)") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    GoldPrimaryButton(
                        if (editingId == null) "Créer l'item" else "Enregistrer",
                        onClick = {
                            val built = buildItem()
                            val taken = items.filter { it.id != editingId }.map { it.identifier }.toSet()
                            val unique = workshopUniqueId(built.identifier, taken)
                            if (unique != built.identifier) {
                                android.widget.Toast.makeText(context, "Identifiant déjà utilisé → renommé en $unique", android.widget.Toast.LENGTH_LONG).show()
                            }
                            onSave(built.copy(identifier = unique))
                            if (editingId == null) resetForm() else identifier = unique
                        },
                        modifier = Modifier.weight(1f)
                    )
                    if (editingId != null) {
                        GoldOutlineButton(
                            "Dupliquer",
                            onClick = {
                                val copy = buildItem(keepId = null).copy(
                                    name = "$name (copie)",
                                    identifier = workshopIdCopy(identifier.trim(), items.map { it.identifier }.toSet())
                                )
                                onSave(copy)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                if (editingId != null) {
                    TextButton(onClick = { resetForm() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Nouveau (quitter l'édition)")
                    }
                }
            }
        }
    }
}
