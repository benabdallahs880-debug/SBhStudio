package com.sbh.studio.creature

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.webkit.WebViewAssetLoader
import com.sbh.studio.data.MobEntity
import com.sbh.studio.ui.AgwColors
import org.json.JSONObject

/**
 * V1.8.62 — éditeur CreatureStudio plein écran pour le corps 3D d'un monstre de l'Atelier.
 *
 * La page (assets/creature/creature_editor.html, construite par tools/creature_host/) lit
 * start() une fois, enregistre toute seule à chaque modification (save) et demande la fermeture
 * (close). Retour d'Android : la page enregistre d'abord, puis l'éditeur se ferme.
 *
 * [example] : modèle de départ pour un corps neuf ("soldat", "chef", "hippo1", "hippo2", "hippo3").
 * [keepTemplateStats] : vrai pour un monstre créé depuis un modèle → les caractéristiques du modèle
 * remontent dans la fiche ; sinon la fiche (vie, dégâts, vitesse, détection) fait foi.
 * [onClose] reçoit le corps Minecraft enregistré (null s'il n'y en a pas).
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CreatureEditorDialog(
    mob: MobEntity,
    example: String? = null,
    keepTemplateStats: Boolean = false,
    /** V1.8.63 : joue un état de l'âme (Studio Animation) sur le corps à l'ouverture. */
    preview: BodyPreview? = null,
    onClose: (CreatureBody?) -> Unit
) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    var pageLoaded by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var closed by remember { mutableStateOf(false) }

    fun finish() {
        if (closed) return
        closed = true
        val body = runCatching { CreatureBodyStore.loadBody(context, mob.projectId, mob.id) }.getOrNull()
        onClose(body)
    }

    val bridge = remember {
        object {
            @JavascriptInterface
            fun start(): String = JSONObject().apply {
                put("name", mob.nom)
                put("bodyKey", CreatureBodyMapping.bodyKey(mob.id))
                val saved = CreatureBodyStore.loadProject(context, mob.projectId, mob.id)
                put("project", saved ?: JSONObject.NULL)
                put("example", if (saved == null && example != null) example else JSONObject.NULL)
                val useTemplateStats = saved == null && example != null && keepTemplateStats
                put("stats", if (useTemplateStats) JSONObject.NULL else JSONObject(CreatureBodyMapping.statsFromMob(mob) as Map<*, *>))
                put("preview", preview?.let { pv ->
                    JSONObject().apply {
                        put("anim", pv.animation); put("speed", pv.speed.toDouble()); put("amplitude", pv.amplitude.toDouble())
                        put("weight", pv.weight.toDouble()); put("loop", pv.loop)
                    }
                } ?: JSONObject.NULL)
            }.toString()

            @JavascriptInterface
            fun save(projectJson: String, bodyJson: String, previewDataUrl: String): Boolean =
                CreatureBodyStore.save(context, mob.projectId, mob.id, projectJson, bodyJson, previewDataUrl)

            @JavascriptInterface
            fun close() { mainHandler.post { finish() } }

            @JavascriptInterface
            fun toast(text: String) { mainHandler.post { Toast.makeText(context, text, Toast.LENGTH_LONG).show() } }
        }
    }

    val assetLoader = remember {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
    }

    val webView = remember {
        WebView(context).apply {
            setBackgroundColor(Color.parseColor("#17171C"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                    request?.url?.let { assetLoader.shouldInterceptRequest(it) }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    return uri.scheme != "https" || uri.host != "appassets.androidplatform.net"
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (url?.contains("creature_editor.html") == true) pageLoaded = true
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                    if (request?.isForMainFrame == true) loadError = error?.description?.toString() ?: "Chargement impossible"
                }
            }
        }
    }

    DisposableEffect(Unit) {
        webView.addJavascriptInterface(bridge, "SBhCreature")
        webView.loadUrl("https://appassets.androidplatform.net/assets/creature/creature_editor.html")
        onDispose {
            try {
                webView.removeJavascriptInterface("SBhCreature")
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            } catch (e: Exception) { Log.w("CreatureEditor", "Fermeture non critique", e) }
        }
    }

    /** Retour : la page ferme sa fenêtre JSON ouverte, sinon enregistre puis l'éditeur se ferme. */
    fun requestBack() {
        if (closed) return
        if (!pageLoaded || loadError != null) { finish(); return }
        val fallback = Runnable { finish() }
        mainHandler.postDelayed(fallback, 2_000L)
        webView.evaluateJavascript("(window.sbhCreatureBack ? window.sbhCreatureBack() : 'close')") { result ->
            mainHandler.removeCallbacks(fallback)
            if (result?.contains("handled") != true) finish()
        }
    }

    Dialog(
        onDismissRequest = { requestBack() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Box(Modifier.fillMaxSize().background(AgwColors.DeepNight)) {
            AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
            if (!pageLoaded || loadError != null) {
                Box(Modifier.fillMaxSize().background(AgwColors.DeepNight), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (loadError == null) CircularProgressIndicator(color = AgwColors.SacredGold)
                        Text(
                            loadError?.let { "CreatureStudio n'a pas pu se charger : $it\n(Retour pour revenir à l'Atelier)" }
                                ?: "🧬 Corps 3D de « ${mob.nom} »…",
                            color = AgwColors.PaleMarble,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }
    }
}
