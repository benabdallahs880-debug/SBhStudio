package com.sbh.studio.creature

import com.sbh.studio.animation.AnimState
import com.sbh.studio.animation.AnimStateParams
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlin.math.roundToLong

/**
 * V1.8.63 — l'âme du Studio Animation règle les animations d'un corps 3D CreatureStudio.
 *
 * Les animations du corps portent des noms fixes (générées par CreatureStudio : Repos, Marche,
 * Course, Attaque, Dégâts, Mort, Nage…). Chaque état du Studio Animation correspond à l'une d'elles :
 *   Repos → repos · Marche → marche · Course → course · Attaque → attaque · Blessé → degats ·
 *   Nage → nage · Assis → assis (n'existe pas dans les animations de base).
 * À l'export, pour l'état correspondant : durée et instants des images clés ÷ vitesse, rotations ×
 * amplitude, déplacements × amplitude × poids, boucle = case « Boucle ». Fonctions pures (testées).
 */
object CreatureBodyAnimation {

    fun expectedName(state: AnimState): String = when (state) {
        AnimState.IDLE -> "repos"
        AnimState.WALK -> "marche"
        AnimState.RUN -> "course"
        AnimState.ATTACK -> "attaque"
        AnimState.HURT -> "degats"
        AnimState.SIT -> "assis"
        AnimState.SWIM -> "nage"
    }

    /** Animation du corps qui joue cet état, ou null si le corps ne l'a pas. */
    fun bodyAnimationFor(state: AnimState, bodyAnimations: Collection<String>): String? =
        expectedName(state).takeIf { it in bodyAnimations }

    /** Noms courts des animations d'un corps (sans le contrôleur « main »). */
    fun names(body: CreatureBody): List<String> = body.client.animations.keys.filter { it != "main" }

    /**
     * Applique l'âme (états → réglages) à un document d'animations Bedrock du corps.
     * [animIds] : nom court → identifiant complet (body.client.animations). Les animations sans
     * état correspondant (mort, saut, vol…) ou sans réglage sont recopiées telles quelles.
     */
    fun applySoul(animDocJson: String, animIds: Map<String, String>, states: Map<String, AnimStateParams>): String {
        val doc = Json.parseToJsonElement(animDocJson).jsonObject
        val anims = doc["animations"] as? JsonObject ?: return animDocJson
        val shortOf = animIds.entries.associate { (short, full) -> full to short }
        val byName = AnimState.entries.associateBy { expectedName(it) }
        return buildJsonObject {
            doc.forEach { (k, v) -> if (k != "animations") put(k, v) }
            put("animations", buildJsonObject {
                anims.forEach { (fullId, anim) ->
                    val state = shortOf[fullId]?.let { byName[it] }
                    val p = state?.let { states[it.name] }
                    put(fullId, if (p == null || anim !is JsonObject) anim else scaleAnimation(anim, p))
                }
            })
        }.toString()
    }

    internal fun scaleAnimation(anim: JsonObject, p: AnimStateParams): JsonObject {
        val speed = p.speed.toDouble().coerceIn(0.25, 2.5)
        val rot = p.amplitude.toDouble().coerceIn(0.25, 2.0)
        val pos = rot * p.weight.toDouble().coerceIn(0.4, 1.6)
        return buildJsonObject {
            anim.forEach { (k, v) ->
                when (k) {
                    "animation_length" -> put(k, (v as? JsonPrimitive)?.doubleOrNull?.let { JsonPrimitive(round4(it / speed)) } ?: v)
                    "loop" -> {}
                    // sons / particules / timeline : mêmes instants que les images clés
                    "sound_effects", "particle_effects", "timeline" -> put(k, retime(v, speed))
                    "bones" -> put(k, (v as? JsonObject)?.let { bones ->
                        buildJsonObject {
                            bones.forEach { (bone, channels) ->
                                put(bone, (channels as? JsonObject)?.let { ch ->
                                    buildJsonObject {
                                        ch.forEach { (name, value) ->
                                            put(name, when (name) {
                                                "rotation" -> scaleChannel(value, rot, speed)
                                                "position" -> scaleChannel(value, pos, speed)
                                                else -> retime(value, speed)
                                            })
                                        }
                                    }
                                } ?: channels)
                            }
                        }
                    } ?: v)
                    else -> put(k, v)
                }
            }
            // « hold_on_last_frame » (rester sur la dernière image) est gardé si la boucle est coupée
            val original = anim["loop"]
            if (!p.loop && original is JsonPrimitive && original.isString) put("loop", original) else put("loop", p.loop)
        }
    }

    /** Canal : valeur constante [x,y,z], ou images clés { "t": valeur | {pre, post} }. */
    private fun scaleChannel(value: JsonElement, factor: Double, speed: Double): JsonElement = when (value) {
        is JsonArray -> scaleVector(value, factor)
        is JsonObject -> if (value.keys.all { it.toDoubleOrNull() != null }) buildJsonObject {
            value.forEach { (t, kv) -> put(timeKey(t.toDouble() / speed), scaleKey(kv, factor)) }
        } else value
        else -> value
    }

    private fun retime(value: JsonElement, speed: Double): JsonElement =
        if (value is JsonObject && value.isNotEmpty() && value.keys.all { it.toDoubleOrNull() != null })
            buildJsonObject { value.forEach { (t, kv) -> put(timeKey(t.toDouble() / speed), kv) } }
        else value

    private fun scaleKey(kv: JsonElement, factor: Double): JsonElement = when (kv) {
        is JsonArray -> scaleVector(kv, factor)
        is JsonObject -> buildJsonObject {
            kv.forEach { (k, v) -> put(k, if ((k == "pre" || k == "post") && v is JsonArray) scaleVector(v, factor) else v) }
        }
        else -> kv
    }

    /** Multiplie les nombres ; une expression Molang (texte) reste telle quelle. */
    private fun scaleVector(a: JsonArray, factor: Double): JsonArray = JsonArray(a.map { e ->
        val d = (e as? JsonPrimitive)?.takeIf { !it.isString }?.doubleOrNull
        if (d != null) JsonPrimitive(round4(d * factor)) else e
    })

    private fun round4(d: Double): Double = (d * 10000).roundToLong() / 10000.0

    /** Même écriture que l'export CreatureStudio : « 0.0 », « 0.5 », « 1.25 ». */
    internal fun timeKey(t: Double): String {
        if (t == 0.0) return "0.0"
        val s = "%.4f".format(java.util.Locale.ROOT, round4(t)).trimEnd('0').trimEnd('.')
        return if (s.contains('.')) s else "$s.0"
    }
}
