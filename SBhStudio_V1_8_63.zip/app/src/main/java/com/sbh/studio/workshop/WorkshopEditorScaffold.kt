package com.sbh.studio.workshop

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton

/**
 * Socle UI atelier (phase A) — motifs partagés liste / onglets / actions.
 * Les zones restent libres : pas de génération forcée.
 */

@Composable
internal fun WorkshopSearchField(
    value: String,
    onChange: (String) -> Unit,
    label: String = "Rechercher"
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
internal fun WorkshopFilterRow(
    options: List<Pair<String, String>>, // id to label
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
    ) {
        options.forEach { (id, label) ->
            FilterChip(
                selected = selected == id,
                onClick = { onSelect(id) },
                label = { Text(label, fontSize = 11.sp) }
            )
        }
    }
}

@Composable
internal fun WorkshopTabRow(
    tabs: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit
) {
    TabRow(selectedTabIndex = selected, containerColor = AgwColors.DeepNight) {
        tabs.forEachIndexed { i, label ->
            Tab(
                selected = selected == i,
                onClick = { onSelect(i) },
                text = { Text(label, fontSize = 12.sp) }
            )
        }
    }
}

@Composable
internal fun WorkshopListCard(
    title: String,
    subtitle: String,
    extra: String? = null,
    selected: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    trailing: @Composable RowScope.() -> Unit = {}
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (selected) AgwColors.NightStone else AgwColors.DeepNight
        ),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) Modifier.border(2.dp, AgwColors.SacredGold, RoundedCornerShape(8.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                Text(subtitle, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                if (!extra.isNullOrBlank()) {
                    Text(extra, color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
                }
            }
            trailing()
            TextButton(onClick = onDelete) { Text("X") }
        }
    }
}

@Composable
internal fun WorkshopEditorActions(
    isEditing: Boolean,
    onSave: () -> Unit,
    onDuplicate: (() -> Unit)? = null,
    onNew: (() -> Unit)? = null,
    saveLabel: String = if (isEditing) "Enregistrer" else "Créer"
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        GoldPrimaryButton(saveLabel, onClick = onSave, modifier = Modifier.weight(1f))
        if (isEditing && onDuplicate != null) {
            GoldOutlineButton("Dupliquer", onClick = onDuplicate, modifier = Modifier.weight(1f))
        }
    }
    if (isEditing && onNew != null) {
        TextButton(onClick = onNew, modifier = Modifier.fillMaxWidth()) {
            Text("Nouveau (quitter l'édition)")
        }
    }
}

@Composable
internal fun WorkshopIdPickerRow(
    label: String,
    options: List<Pair<String, String>>, // identifier to display name
    selectedId: String,
    onSelect: (String) -> Unit
) {
    if (options.isEmpty()) return
    Text(label, color = AgwColors.Sand, fontSize = 12.sp)
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
    ) {
        options.take(40).forEach { (id, name) ->
            FilterChip(
                selected = selectedId == id,
                onClick = { onSelect(id) },
                label = { Text(name.ifBlank { id }.take(18), fontSize = 11.sp) }
            )
        }
    }
}

/**
 * Identifiant libre pour une copie (V1.8.58) — règle unique des zones Blocs, Items, Recettes.
 * Avant : toujours « _copy » → dupliquer deux fois créait deux identifiants identiques
 * (collision qui bloquait l'export).
 */
/**
 * V1.8.59 — identifiant unique à l'enregistrement.
 * Les formulaires « Nouveau » proposent toujours le même identifiant par défaut
 * (agw:portal_custom, agw:nouveau_bloc…) : créer deux éléments sans le changer produisait
 * un doublon, détecté seulement à l'export (SBH-ERR-003 / 011). Désormais, si l'identifiant
 * est déjà pris par UN AUTRE élément du projet, on ajoute _2, _3…
 * [taken] = identifiants des autres éléments (sans celui qu'on édite).
 */
internal fun workshopUniqueId(wanted: String, taken: Set<String>): String {
    val w = wanted.trim()
    if (w !in taken) return w
    val root = w.replace(Regex("_\\d+$"), "")
    var n = 2
    while ("${root}_$n" in taken) n++
    return "${root}_$n"
}

internal fun workshopIdCopy(base: String, existing: Set<String> = emptySet()): String {
    val root = (if (base.contains(":")) base else "agw:$base").removeSuffix("_copy")
    var candidate = "${root}_copy"
    var n = 2
    while (candidate in existing) {
        candidate = "${root}_copy$n"
        n++
    }
    return candidate
}
