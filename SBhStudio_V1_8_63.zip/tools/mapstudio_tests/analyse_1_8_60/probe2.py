import asyncio, json, time
from playwright.async_api import async_playwright
B='http://127.0.0.1:8766/'
ARGS=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']
MOCK=open('bridge.py').read().split("MOCK = r'''")[1].split("'''")[0]
async def ready(p):
    await p.wait_for_function('window.__sbhStudioReady === true', timeout=60000); await p.wait_for_timeout(300)
async def touch(cdp, typ, pts):
    await cdp.send('Input.dispatchTouchEvent', {'type':typ, 'touchPoints':[{'x':x,'y':y,'id':i} for i,(x,y) in enumerate(pts)]})
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(args=ARGS)
        # ---------- navigateur (localStorage) ----------
        ctx = await b.new_context(viewport={'width':1280,'height':800}, has_touch=True)
        page = await ctx.new_page(); await page.goto(B+'mapstudio.html'); await ready(page)
        cdp = await ctx.new_cdp_session(page)
        # T9 box on flat terrain
        await page.select_option('#tType','flat'); await page.evaluate("document.querySelector('#tBase').value=10")
        await page.click('#btnGen'); await page.wait_for_timeout(700)
        n0 = await page.evaluate('__sbhDebug.blockCount()')
        await page.evaluate("document.querySelectorAll('.tool')[3].click()")
        bx = await page.locator('#cv').bounding_box(); cx,cy = bx['x']+bx['width']/2, bx['y']+bx['height']/2
        await touch(cdp,'touchStart',[(cx-80,cy)]); 
        for k in range(1,5): await touch(cdp,'touchMove',[(cx-80+k*40,cy+k*10)])
        await touch(cdp,'touchEnd',[]); await page.evaluate('__sbhDebug.flush()')
        n1 = await page.evaluate('__sbhDebug.blockCount()')
        print('T9 Boîte sur sol plat : blocs', n0, '→', n1, '(hauteur ajoutée = 0 si égal)')
        # T3 object drag not autosaved
        await page.set_input_files('#objFileInput','tri.glb'); await page.wait_for_timeout(2500)  # autosave after import
        await page.evaluate("document.querySelectorAll('.tool')[8].click()")  # Objets
        p0 = await page.evaluate("JSON.parse(localStorage.getItem('sbh_mapstudio_autosave')).objects[0].pos")
        # find object screen pos: project its world pos
        await touch(cdp,'touchStart',[(cx,cy)]); await touch(cdp,'touchEnd',[])
        sel = await page.evaluate("__sbhDebug.objects")
        # drag from object position: compute screen projection via probe
        sp = await page.evaluate("""(()=>{const o=__probe.scene.getObjectByProperty('type','Group');return null})()""")
        # simpler: select via list click then drag anywhere (dragging requires hit on object) -> use pickless approach: simulate move via sliders (rotation) which is autosaved, and compare with direct move
        # Direct test of the code path: emulate endPointer of a drag
        print('T3 (lecture du code) : endPointer outil Objets → scheduleEntitySync() seulement, pas scheduleAutosave()')
        # T6 registry order dependence
        await page.click('#btnSave'); await page.wait_for_timeout(300)
        stone_before = await page.evaluate("(()=>{const w=__sbhDebug.world;const id=__sbhDebug.blockFromName('stone');let c=0;for(const v of w.data) if(v===id)c++;return c;})()")
        page2 = await ctx.new_page(); await page2.goto(B+'mapstudio_v2.html'); await ready(page2)
        stone_after = await page2.evaluate("(()=>{const w=__sbhDebug.world;const id=__sbhDebug.blockFromName('stone');let c=0;for(const v of w.data) if(v===id)c++;return c;})()")
        marble = await page2.evaluate("(()=>{const w=__sbhDebug.world;const id=__sbhDebug.blockFromName('marble');let c=0;for(const v of w.data) if(v===id)c++;return c;})()")
        print('T6 même sauvegarde relue par une version avec 1 bloc de plus : pierre', stone_before, '→', stone_after, '| « marbre » apparu :', marble)
        await ctx.close()
        # ---------- Android simulé ----------
        ctx = await b.new_context(viewport={'width':1280,'height':800}, has_touch=True)
        await ctx.add_init_script(MOCK)
        page = await ctx.new_page(); await page.goto(B+'mapstudio.html'); await ready(page)
        await page.click('#btnExport2'); await page.wait_for_timeout(500)
        print('T4 lié après envoi :', await page.evaluate('__sbhDebug.meta.atelierMapId'))
        await page.click('#btnNew'); await page.click('#dlgYes'); await page.wait_for_timeout(500)
        await page.click('#btnUndo'); await page.wait_for_timeout(800)
        print('T4 après « Nouvelle map » puis Annuler : blocs', await page.evaluate('__sbhDebug.blockCount()'), '| lien Atelier =', await page.evaluate('__sbhDebug.meta.atelierMapId'), '| nom =', await page.evaluate('__sbhDebug.meta.name'))
        # T7: modify current map (unsent), open the Atelier map → autosave overwritten?
        await page.click('#btnExport2'); await page.wait_for_timeout(400)   # creates second map (unlinked → new)
        maps = await page.evaluate("JSON.parse(SBhBridge.atelierData()).maps.map(m=>m.id)")
        await page.evaluate("document.querySelector('#mapName').value='Travail non envoyé'; document.querySelector('#mapName').dispatchEvent(new Event('input'))")
        await page.wait_for_timeout(1800)
        nm_before = await page.evaluate("JSON.parse(__files.state_autosave).name")
        # open first atelier studio map (m-new)
        rows = page.locator('#atelierMaps .atl')
        cnt = await rows.count()
        for i in range(cnt):
            t = await rows.nth(i).text_content()
            if 'Map Al-Zahra' in t or 'Map Studio' in t:
                await rows.nth(i).click(); break
        await page.wait_for_timeout(300)
        if await page.is_visible('#dlg.open'): await page.click('#dlgYes')
        await page.wait_for_timeout(2200)
        nm_after = await page.evaluate("JSON.parse(__files.state_autosave).name")
        print('T7 sauvegarde auto avant/après « Ouvrir » une map de l\'Atelier :', nm_before, '→', nm_after)
        await b.close()
asyncio.run(main())
