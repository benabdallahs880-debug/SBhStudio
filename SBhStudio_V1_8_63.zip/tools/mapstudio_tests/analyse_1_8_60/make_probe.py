"""Fabrique probe/ : copie de mapstudio.html avec un accès lecture (renderer, scène, caméra) pour les sondes,
et une variante « v2 » avec un bloc ajouté en tête de palette (simule une future mise à jour).
Usage : python3 ../mkfiles.py && python3 make_probe.py && cp tri.glb probe/ && (cd probe && python3 -m http.server 8766 &)
puis python3 probe1.py … probe5.py (probe2/3 lisent le pont simulé dans ../bridge.py)."""
import os, shutil
SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../app/src/main/assets')
os.makedirs('probe', exist_ok=True)
shutil.copytree(os.path.join(SRC, 'js'), 'probe/js', dirs_exist_ok=True)
s = open(os.path.join(SRC, 'mapstudio.html')).read()
s = s.replace("window.__sbhDebug = {", "window.__probe = { get renderer(){ return renderer; }, get scene(){ return scene; }, get camera(){ return camera; }, THREE, refreshMarkers: () => refreshMarkers(), get atelier(){ return atelier; } };\nwindow.__sbhDebug = {", 1)
open('probe/mapstudio.html', 'w').write(s)
s2 = s.replace("def('stone','Pierre','Naturel',{all:['stone','#7d7d7d']});", "def('marble','Marbre','Naturel',{all:['smooth','#eeeeee']});\ndef('stone','Pierre','Naturel',{all:['stone','#7d7d7d']});", 1)
open('probe/mapstudio_v2.html', 'w').write(s2)
print('probe/ prêt')
