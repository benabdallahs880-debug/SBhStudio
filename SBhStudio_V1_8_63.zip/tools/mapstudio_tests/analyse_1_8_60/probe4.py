import asyncio, json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8766/'
ARGS=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']
async def touch(cdp, typ, pts):
    await cdp.send('Input.dispatchTouchEvent', {'type':typ, 'touchPoints':[{'x':x,'y':y,'id':i} for i,(x,y) in enumerate(pts)]})
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(args=ARGS)
        ctx = await b.new_context(viewport={'width':1280,'height':800}, has_touch=True)
        page = await ctx.new_page(); await page.goto(B+'mapstudio.html')
        await page.wait_for_function('window.__sbhStudioReady === true', timeout=60000); await page.wait_for_timeout(300)
        cdp = await ctx.new_cdp_session(page)
        await page.set_input_files('#objFileInput','tri.glb'); await page.wait_for_timeout(2300)
        await page.evaluate("document.querySelectorAll('.tool')[8].click()")
        proj = """(()=>{const P=__probe; let g=null; P.scene.traverse(o=>{ if(o.userData && o.userData.sbhId && String(o.userData.sbhId).startsWith('obj_')) g=o; });
          const v=g.position.clone(); v.y+=0.3; v.x+=0.3; v.project(P.camera); const r=document.querySelector('#cv').getBoundingClientRect();
          return [r.left+(v.x+1)/2*r.width, r.top+(1-v.y)/2*r.height, g.position.x, g.position.z]; })()"""
        x,y,ox,oz = await page.evaluate(proj)
        await touch(cdp,'touchStart',[(x,y)])
        for k in range(1,8): await touch(cdp,'touchMove',[(x+k*25,y+k*5)])
        await touch(cdp,'touchEnd',[]); await page.wait_for_timeout(200)
        _,_,nx,nz = await page.evaluate(proj)
        await page.evaluate('window.sbhBeforeClose()')
        saved = await page.evaluate("JSON.parse(localStorage.getItem('sbh_mapstudio_autosave')).objects[0].pos")
        print('T3 objet déplacé de', (ox,oz), 'à', (nx,nz), '| position sauvegardée au Retour :', saved)
        await b.close()
asyncio.run(main())
