import asyncio, time
from playwright.async_api import async_playwright
B='http://127.0.0.1:8766/'
ARGS=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--enable-precise-memory-info']
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(args=ARGS)
        ctx = await b.new_context(viewport={'width':1280,'height':800}, accept_downloads=True)
        page = await ctx.new_page(); await page.goto(B+'mapstudio.html')
        await page.wait_for_function('window.__sbhStudioReady === true', timeout=60000)
        mem = lambda: page.evaluate('Math.round(performance.memory.usedJSHeapSize/1e6)')
        for (sx,sy,sz) in [(256,128,256),(256,256,256)]:
            await page.fill('#wSX',str(sx)); await page.fill('#wSY',str(sy)); await page.fill('#wSZ',str(sz))
            t=time.time(); await page.click('#btnResize'); await page.wait_for_function("document.querySelector('#hud').textContent==='Prêt'", timeout=300000)
            r=time.time()-t
            await page.evaluate("document.querySelector('#tBase').value=40")
            t=time.time(); await page.click('#btnGen'); await page.wait_for_function("document.querySelector('#hud').textContent==='Prêt'", timeout=300000); g=time.time()-t
            t=time.time(); n = await page.evaluate("__sbhDebug.bedrockFunctionFiles().length"); f=time.time()-t
            t=time.time(); ok = await page.evaluate("(()=>{window.sbhBeforeClose(); return (localStorage.getItem('sbh_mapstudio_autosave')||'').length})()"); s=time.time()-t
            print(f'{sx}x{sy}x{sz}: redim {r:.1f}s · générer {g:.1f}s · fonctions Bedrock {n} parties en {f:.1f}s · autosave {ok/1e6:.1f} Mo en {s:.1f}s · tas JS {await mem()} Mo · historique {await page.evaluate("__sbhDebug.undoCount")}')
        await b.close()
asyncio.run(main())
