import asyncio, json, time
from playwright.async_api import async_playwright
B='http://127.0.0.1:8766/'
ARGS=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']
async def ready(p): 
    await p.wait_for_function('window.__sbhStudioReady === true', timeout=60000); await p.wait_for_timeout(300)
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(args=ARGS)
        ctx = await b.new_context(viewport={'width':1280,'height':800}, has_touch=True)
        page = await ctx.new_page()
        await page.goto(B+'mapstudio.html'); await ready(page)
        # T1 XSS via structures in imported JSON
        evil = {"format":"sbh-map-studio","version":3,"name":"Piège","size":[16,16,16],
                "world":{"sx":16,"sy":16,"sz":16,"data":""},
                "structures":[{"type":"bâtiment","name":"<img src=x onerror=\"window.__xss=1\">","x":1,"z":1}]}
        open('evil.json','w').write(json.dumps(evil))
        await page.set_input_files('#fileInput','evil.json'); await page.wait_for_timeout(800)
        await page.click('#btnReport'); await page.wait_for_timeout(500)
        print('T1 XSS exécuté depuis un fichier importé :', await page.evaluate('window.__xss===1'))
        await page.click('#btnReportClose')
        # T2 codeLine huge
        await page.click('#btnCode')
        await page.fill('#codeEditor','map.create(32,32,32)\nline 0 0 0 30000000 0 0 stone')
        t=time.time()
        try:
            await page.click('#btnCodeRun', timeout=60000)
            await page.wait_for_function('document.querySelector("#codeStatus").textContent.length>0', timeout=60000)
        except Exception as e: print('T2 exception', e)
        print('T2 « line » 30 millions : %.1fs, statut=%s' % (time.time()-t, await page.text_content('#codeStatus')))
        await page.click('#btnCodeClose')
        # T5 texture leak via refreshMarkers (simulate regions)
        await page.evaluate("__probe.atelier.regions = {regions:[{name:'A',x:0,z:0},{name:'B',x:100,z:50},{name:'C',x:-40,z:90}]}")
        t0 = await page.evaluate('__probe.renderer.info.memory.textures')
        for i in range(20): await page.evaluate('__probe.refreshMarkers()'); await page.wait_for_timeout(30)
        t1 = await page.evaluate('__probe.renderer.info.memory.textures')
        objs = await page.evaluate('__probe.scene.children.length')
        print('T5 textures GPU avant/après 20 rafraîchissements des repères :', t0, '→', t1, '| objets scène', objs)
        # T13 atlas url size
        print('T13 taille ATLAS data URL (octets) :', await page.evaluate("getComputedStyle(document.querySelector('.blk')).backgroundImage.length"))
        await b.close()
asyncio.run(main())
