import asyncio, json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8766/'
ARGS=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']
MOCK=open('bridge.py').read().split("MOCK = r'''")[1].split("'''")[0].replace("const id = o.atelierMapId || 'm-new';","const id = o.atelierMapId || ('m'+(maps.length+1));")
async def ready(p):
    await p.wait_for_function('window.__sbhStudioReady === true', timeout=60000); await p.wait_for_timeout(300)
async def touch(cdp, typ, pts):
    await cdp.send('Input.dispatchTouchEvent', {'type':typ, 'touchPoints':[{'x':x,'y':y,'id':i} for i,(x,y) in enumerate(pts)]})
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(args=ARGS)
        ctx = await b.new_context(viewport={'width':1280,'height':800}, has_touch=True)
        await ctx.add_init_script(MOCK)
        page = await ctx.new_page(); await page.goto(B+'mapstudio.html'); await ready(page)
        cdp = await ctx.new_cdp_session(page)
        # map A envoyée
        await page.evaluate("document.querySelector('#mapName').value='Map A'; document.querySelector('#mapName').dispatchEvent(new Event('input'))")
        await page.click('#btnExport2'); await page.wait_for_timeout(400)
        idA = await page.evaluate('__sbhDebug.meta.atelierMapId')
        # Nouvelle map B, travail non envoyé
        await page.click('#btnNew'); await page.click('#dlgYes'); await page.wait_for_timeout(500)
        await page.evaluate("document.querySelector('#mapName').value='Map B non envoyée'; document.querySelector('#mapName').dispatchEvent(new Event('input'))")
        await page.wait_for_timeout(1800)
        before = await page.evaluate("JSON.parse(__files.state_autosave).name")
        # ouvrir A depuis la liste
        rows = page.locator('#atelierMaps .atl')
        for i in range(await rows.count()):
            if 'Map A' in (await rows.nth(i).text_content()): await rows.nth(i).click(); break
        await page.wait_for_selector('#dlg.open'); await page.click('#dlgYes'); await page.wait_for_timeout(2200)
        after = await page.evaluate("JSON.parse(__files.state_autosave).name")
        print('T7 autosave :', before, '→', after, '(la map B n\'existe plus que dans l\'historique Annuler de la session)')
        # T3 : déplacer un objet puis Retour
        await page.set_input_files('#objFileInput','tri.glb'); await page.wait_for_timeout(2300)
        await page.evaluate("document.querySelectorAll('.tool')[8].click()")
        sp = await page.evaluate("""(()=>{const s=__probe.scene; let g=null; s.traverse(o=>{ if(o.userData && o.userData.sbhId && o.userData.sbhId.startsWith('obj_')) g=o; });
            const v=g.position.clone(); v.y+=0.5; const cam=s.parent; return null })()""")
        # projection via camera: get camera from renderer? use probe: compute screen coords
        xy = await page.evaluate("""(()=>{const s=__probe.scene; let g=null; s.traverse(o=>{ if(o.userData && o.userData.sbhId && o.userData.sbhId.startsWith('obj_')) g=o; });
            const r=document.querySelector('#cv').getBoundingClientRect(); return [g.position.x,g.position.y,g.position.z, r.left, r.top, r.width, r.height]; })()""")
        print('objet en', xy[:3])
        await b.close()
asyncio.run(main())
