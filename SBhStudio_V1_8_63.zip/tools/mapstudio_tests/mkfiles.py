from nbtw import *
import gzip, json, struct
W,H,L=4,3,5
# grid: y0 = grass_block[snowy=false], y1 x0 = oak_log[axis=y], y1 x1 = unknown 'minecraft:fancy_block', rest air
pal={'minecraft:air':0,'minecraft:grass_block[snowy=false]':1,'minecraft:oak_log[axis=y]':2,'minecraft:fancy_block':3}
data=[]
for y in range(H):
    for z in range(L):
        for x in range(W):
            v=0
            if y==0: v=1
            elif y==1 and x==0: v=2
            elif y==1 and x==1: v=3
            data.append(v)
v2={'Version':(3,2),'DataVersion':(3,3700),'Width':(2,W),'Height':(2,H),'Length':(2,L),
    'PaletteMax':(3,4),'Palette':(10,{k:(3,i) for k,i in pal.items()}),'BlockData':(7,list(varints(data)))}
open('t_v2.schem','wb').write(gzip.compress(root(v2,name='Schematic')))
v3={'Schematic':(10,{'Version':(3,3),'DataVersion':(3,3700),'Width':(2,W),'Height':(2,H),'Length':(2,L),
    'Blocks':(10,{'Palette':(10,{k:(3,i) for k,i in pal.items()}),'Data':(7,list(varints(data)))})})}
open('t_v3.schem','wb').write(gzip.compress(root(v3)))
# Java structure .nbt
palette=[{'Name':(8,'minecraft:sandstone')},{'Name':(8,'minecraft:stone_bricks')}]
blocks=[{'pos':(9,(3,[x,0,z])),'state':(3,0)} for x in range(3) for z in range(2)]+[{'pos':(9,(3,[1,1,1])),'state':(3,1)}]
nbt={'size':(9,(3,[3,2,2])),'palette':(9,(10,palette)),'blocks':(9,(10,blocks)),'DataVersion':(3,3700)}
open('t_struct.nbt','wb').write(gzip.compress(root(nbt)))
# Bedrock mcstructure (LE), size 2x2x2, order x,y,z
names=['minecraft:air','minecraft:hardened_clay','minecraft:snow']
idx=[]
for x in range(2):
    for y in range(2):
        for z in range(2):
            idx.append(1 if y==0 else (2 if (x==1 and z==1) else 0))
mc={'format_version':(3,1),'size':(9,(3,[2,2,2])),
    'structure':(10,{'block_indices':(9,(9,[(3,idx),(3,[-1]*8)])),'entities':(9,(10,[])),
       'palette':(10,{'default':(10,{'block_palette':(9,(10,[{'name':(8,n),'states':(10,{}),'version':(3,18090528)} for n in names])),'block_position_data':(10,{})})})}),
    'structure_world_origin':(9,(3,[0,0,0]))}
open('t.mcstructure','wb').write(root(mc,le=True))
# huge schem dims
big={'Version':(3,2),'Width':(2,600),'Height':(2,10),'Length':(2,10),'Palette':(10,{'minecraft:air':(3,0)}),'BlockData':(7,[0])}
open('t_big.schem','wb').write(gzip.compress(root(big,name='Schematic')))
# minimal glb: one triangle
import json as J
pos=struct.pack('<9f',0,0,0, 1,0,0, 0,1,0)
gl={"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"mesh":0,"name":"tri"}],
    "meshes":[{"primitives":[{"attributes":{"POSITION":0}}]}],
    "buffers":[{"byteLength":len(pos)}],"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":len(pos)}],
    "accessors":[{"bufferView":0,"componentType":5126,"count":3,"type":"VEC3","min":[0,0,0],"max":[1,1,0]}]}
js=J.dumps(gl).encode(); js+=b' '*((4-len(js)%4)%4)
bn=pos+b'\x00'*((4-len(pos)%4)%4)
total=12+8+len(js)+8+len(bn)
glb=struct.pack('<III',0x46546C67,2,total)+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(bn),0x004E4942)+bn
open('tri.glb','wb').write(glb)
gl2=dict(gl); gl2['extensionsRequired']=['KHR_draco_mesh_compression']
js2=J.dumps(gl2).encode(); js2+=b' '*((4-len(js2)%4)%4)
total=12+8+len(js2)+8+len(bn)
open('draco.glb','wb').write(struct.pack('<III',0x46546C67,2,total)+struct.pack('<II',len(js2),0x4E4F534A)+js2+struct.pack('<II',len(bn),0x004E4942)+bn)
print('files ok')
