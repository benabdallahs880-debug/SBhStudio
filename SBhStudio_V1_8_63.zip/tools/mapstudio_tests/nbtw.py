import struct, gzip
# Minimal NBT writer: values are tuples (type, value)
def w(t, v, le):
    e = '<' if le else '>'
    if t==1: return struct.pack(e+'b', v)
    if t==2: return struct.pack(e+'h', v)
    if t==3: return struct.pack(e+'i', v)
    if t==4: return struct.pack(e+'q', v)
    if t==7: return struct.pack(e+'i', len(v)) + bytes(v)
    if t==8: b=v.encode(); return struct.pack(e+'H', len(b))+b
    if t==9:
        et, items = v
        return struct.pack(e+'b', et) + struct.pack(e+'i', len(items)) + b''.join(w(et,i,le) for i in items)
    if t==10:
        out=b''
        for name,(tt,vv) in v.items(): out += struct.pack(e+'b',tt) + w(8,name,le) + w(tt,vv,le)
        return out + b'\x00'
    if t==11: return struct.pack(e+'i', len(v)) + b''.join(struct.pack(e+'i',x) for x in v)
    raise ValueError(t)
def root(comp, le=False, name=''):
    return b'\x0a' + w(8,name,le) + w(10,comp,le)
def varints(vals):
    out=bytearray()
    for v in vals:
        while v>0x7f: out.append((v&0x7f)|0x80); v>>=7
        out.append(v)
    return bytes(out)
