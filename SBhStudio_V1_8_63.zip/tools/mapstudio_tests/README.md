# Tests navigateur de Map Studio (V1.8.61)

Ces scripts chargent `app/src/main/assets/mapstudio.html` dans un vrai Chromium (rendu WebGL logiciel),
simulent doigts / souris et vérifient chaque correctif (MS-01 … MS-38).

```bash
pip install playwright && playwright install chromium   # une fois (hors de l'environnement Claude)
cd app/src/main/assets && python3 -m http.server 8765 &
cd tools/mapstudio_tests
python3 mkfiles.py      # fabrique les fichiers d'import de test (.schem v2/v3, .nbt, .mcstructure, .glb)
python3 full.py         # tactile, Annuler/Rétablir, Ligne, sol vide, Boîte, génération, Code Studio, export Bedrock, .schem
python3 imp.py          # imports, objets .glb, sauvegarde auto, écrêtage, paysage (lancer APRÈS full.py : réutilise test.schem)
python3 fusion.py       # V1.8.61 pont Android simulé : maps de l'Atelier, fiche, ▶ Tester, structures, Nouvelle map, ancienne sauvegarde, Retour (F01…F33)
python3 forge_action.py # V1.8.61 actions « ▶ Tester le village forge » / « 🏠 Poser la forge », import de structure (H01…H13)
```

Chaque ligne affichée commence par OK ou KO. `line.js` et `undo.js` : reproductions Node des bugs MS-03 / MS-04 de la V1.8.59.
Chromium : ajouter `--use-angle=swiftshader --enable-unsafe-swiftshader --ignore-gpu-blocklist` si la machine n'a pas de GPU.

`bridge.py` (V1.8.60) est remplacé par `fusion.py` : l'ancienne API du pont (saveState, exportMap…) n'existe plus.
