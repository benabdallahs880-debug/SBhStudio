import asyncio, json, time, os
from playwright.async_api import async_playwright
URL='http://127.0.0.1:8765/mapstudio.html'
R=[]
def ok(name, cond, info=''): R.append(('OK ' if cond else 'KO ')+name+(' — '+str(info) if info else ''))
async def ev(page, js): return await page.evaluate(js)
async def ready(page):
    await page.wait_for_function('window.__sbhStudioReady === true', timeout=60000); await page.wait_for_timeout(300)
async def imp(page, path):
    await page.set_input_files('#fileInput', path)
    await page.wait_for_timeout(900)
    return await page.text_content('#toast')
CNT='''(n=>{const w=__sbhDebug.world;const id=__sbhDebug.blockFromName(n);let c=0;for(const v of w.data) if(v===id) c++;return c;})'''
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
        ctx = await b.new_context(viewport={'width':412,'height':900}, has_touch=True, is_mobile=True, accept_downloads=True)
        page = await ctx.new_page(); errs=[]
        page.on('pageerror', lambda e: errs.append('PAGEERROR: '+str(e)))
        page.on('console', lambda m: errs.append(m.type+': '+m.text) if m.type=='error' else None)
        await page.goto(URL); await ready(page)
        t = await imp(page,'t_v2.schem')
        dims = await ev(page,'[__sbhDebug.world.sx,__sbhDebug.world.sy,__sbhDebug.world.sz]')
        g = await ev(page, CNT+'("grass_block")'); l = await ev(page, CNT+'("oak_log")')
        ok('MS-16 .schem v2 avec états : herbe et bûches gardées', dims==[4,3,5] and g==20 and l==5, f'herbe={g} bûches={l}')
        ok('MS-16 blocs inconnus signalés', 'inconnu' in t and 'fancy_block' in t, t)
        t = await imp(page,'t_v3.schem'); g = await ev(page, CNT+'("grass_block")')
        ok('MS-17 .schem v3 (WorldEdit récent)', g==20, t)
        t = await imp(page,'t_struct.nbt')
        dims = await ev(page,'[__sbhDebug.world.sx,__sbhDebug.world.sy,__sbhDebug.world.sz]')
        ok('MS-17 structure Java .nbt', dims==[3,2,2] and (await ev(page,CNT+'("sandstone")'))==6 and (await ev(page,CNT+'("stone_bricks")'))==1, t)
        t = await imp(page,'t.mcstructure')
        ok('import .mcstructure Bedrock (noms Bedrock reconnus)', (await ev(page,CNT+'("terracotta")'))==4 and (await ev(page,CNT+'("snow_block")'))==1, t)
        dims0 = await ev(page,'[__sbhDebug.world.sx,__sbhDebug.world.sy,__sbhDebug.world.sz]')
        t = await imp(page,'t_big.schem')
        dims1 = await ev(page,'[__sbhDebug.world.sx,__sbhDebug.world.sy,__sbhDebug.world.sz]')
        ok('MS-17 taille limitée (600 refusé, monde intact)', dims0==dims1 and '256' in (t or ''), t)
        # undo import
        u = await ev(page,'__sbhDebug.undoCount')
        ok('import annulable', u>=3, u)
        # .schem round-trip from earlier export
        if os.path.exists('test.schem'):
            t = await imp(page,'test.schem')
            ok('ré-import du .schem exporté', (await ev(page,'__sbhDebug.blockCount()'))>1000 and 'inconnu' not in t, t)
        # json export/import round trip
        n = await ev(page,'__sbhDebug.blockCount()')
        async with page.expect_download() as dl:
            await page.locator('#btnExpJson').scroll_into_view_if_needed(); await page.click('#btnExpJson')
        d = await dl.value; await d.save_as('rt.json')
        await page.locator('#btnNew').scroll_into_view_if_needed(); await page.click('#btnNew'); await page.click('#dlgYes'); await page.wait_for_timeout(300)
        t = await imp(page,'rt.json')
        ok('.json export → import identique', (await ev(page,'__sbhDebug.blockCount()'))==n, t)

        # objets glb
        await page.set_input_files('#objFileInput','draco.glb'); await page.wait_for_timeout(600)
        ok('MS-34 .glb compressé : message clair', 'compression' in (await page.text_content('#toast')), await page.text_content('#toast'))
        await page.set_input_files('#objFileInput','tri.glb'); await page.wait_for_timeout(900)
        objs = await ev(page,'__sbhDebug.objects')
        ok('import .glb', len(objs)==1 and not objs[0]['missing'], objs)
        # autosave then reload → map + object restored
        nb = await ev(page,'__sbhDebug.blockCount()')
        await page.wait_for_timeout(2000)
        await page.reload(); await ready(page); await page.wait_for_timeout(600)
        objs2 = await ev(page,'__sbhDebug.objects'); nb2 = await ev(page,'__sbhDebug.blockCount()')
        ok('MS-13 sauvegarde auto : map restaurée après rechargement', nb2==nb, f'{nb}→{nb2}')
        ok('MS-15 objet .glb restauré (pas un cube)', len(objs2)==1 and not objs2[0]['missing'], objs2)
        # MS-18 clip pick: set yMax=0 with a fresh generated terrain and tap → hit must be y<=0
        await page.locator('#btnGen').scroll_into_view_if_needed(); await page.select_option('#tType','hills'); await page.evaluate("document.querySelector('#tBase').value=18")
        await page.click('#btnGen'); await page.wait_for_timeout(900)
        await page.evaluate("const e=document.querySelector('#vYMax'); e.value=6; e.dispatchEvent(new Event('input'))")
        await page.evaluate("document.querySelectorAll('.tool')[1].click()")  # gomme
        before = await ev(page,'__sbhDebug.blockCount()')
        snap = await ev(page,'Array.from(__sbhDebug.world.data)')
        box = await page.locator('#cv').bounding_box(); cx, cy = box['x']+box['width']/2, box['y']+box['height']/2
        await page.touchscreen.tap(cx, cy+40); await page.evaluate('__sbhDebug.flush()')
        snap2 = await ev(page,'Array.from(__sbhDebug.world.data)')
        W = await ev(page,'[__sbhDebug.world.sx,__sbhDebug.world.sz]')
        changed=[i for i in range(len(snap)) if snap[i]!=snap2[i]]
        ys=[i//(W[0]*W[1]) for i in changed]
        ok('MS-18 écrêtage : le clic touche un bloc visible (y ≤ 6)', changed and max(ys)<=6, ys[:3])
        # landscape
        await page.set_viewport_size({'width':860,'height':400}); await page.wait_for_timeout(500)
        lv = await page.is_visible('#tools'); 
        lb = await page.locator('#left').bounding_box(); vb = await page.locator('#viewport').bounding_box()
        ok('MS-19 paysage : outils visibles à côté de la vue', lv and lb['width']>100 and vb['width']>300 and lb['y']<vb['y']+vb['height'], (lb, vb))
        await page.screenshot(path='shot_land.png')
        print('\n'.join(R)); print('ERRORS:', errs)
        await b.close()
asyncio.run(main())
