// Copie fidèle de la logique Map Studio (sans rendu)
const world={sx:4,sy:4,sz:4,data:new Uint16Array(64)};
const undoStack=[],redoStack=[];let curEdit=null;
function beginEdit(){curEdit={idx:[],from:[],to:[],seen:new Set()};}
function commitEdit(){if(curEdit&&curEdit.idx.length){undoStack.push(curEdit);redoStack.length=0;}curEdit=null;}
function setBlock(x,y,z,v){const i=(y*world.sz+z)*world.sx+x;const old=world.data[i];if(old===v)return;if(curEdit){if(!curEdit.seen.has(i)){curEdit.seen.add(i);curEdit.idx.push(i);curEdit.from.push(old);curEdit.to.push(v);}else{const k=curEdit.idx.indexOf(i);if(k>=0)curEdit.to[k]=v;}}world.data[i]=v;}
function applyUndo(stack,other){const e=stack.pop();if(!e)return;beginEdit();for(let k=0;k<e.idx.length;k++){world.data[e.idx[k]]=e.from[k];}curEdit=null;other.push(e);}
beginEdit();setBlock(1,1,1,7);commitEdit();
console.log('après pose  :',world.data[(1*4+1)*4+1]);
applyUndo(undoStack,redoStack); console.log('après Annuler :',world.data[(1*4+1)*4+1]);
applyUndo(redoStack,undoStack); console.log('après Rétablir:',world.data[(1*4+1)*4+1],'(attendu 7)');
