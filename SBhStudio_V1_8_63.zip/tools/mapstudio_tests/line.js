function linePoints(a,b){
  const pts=[];
  let x0=a.x,y0=a.y,z0=a.z;
  const x1=b.x,y1=b.y,z1=b.z;
  const dx=Math.abs(x1-x0), dy=Math.abs(y1-y0), dz=Math.abs(z1-z0);
  const sx=x0<x1?1:-1, sy=y0<y1?1:-1, sz=z0<z1?1:-1;
  let err = dx-Math.max(dy,dz);
  const n = Math.max(dx,dy,dz);
  for(let i=0;i<=n;i++){
    pts.push([x0,y0,z0]);
    const e2 = 2*err;
    if(e2 > -dx){ err -= dy+dz; x0 += sx; }
    if(e2 < dy*2){ err += dx; y0 += sy; }
    if(e2 < dz*2){ err += dx; z0 += sz; }
  }
  return pts;
}
const cases=[[{x:0,y:0,z:0},{x:10,y:0,z:0}],[{x:0,y:0,z:0},{x:0,y:10,z:0}],[{x:0,y:0,z:0},{x:10,y:10,z:0}],[{x:0,y:0,z:0},{x:10,y:3,z:0}],[{x:0,y:5,z:0},{x:0,y:5,z:10}]];
for(const [a,b] of cases){const p=linePoints(a,b);console.log(JSON.stringify(a),'->',JSON.stringify(b),'| dernier point:',p[p.length-1].join(','),'| points:',p.map(q=>q.join(',')).join(' '));}
