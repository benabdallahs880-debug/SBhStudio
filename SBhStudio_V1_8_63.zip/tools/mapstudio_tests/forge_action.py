"""V1.8.61 — Accueil « ▶ Tester le village forge » et « 🏠 Poser la forge » (actions de démarrage)."""
import asyncio, json, sys
from playwright.async_api import async_playwright
from fusion import MOCK, URL
R = []
def ok(n, c, i=''): R.append(('OK ' if c else 'KO ') + n + (' — ' + str(i)[:300] if (i != '' and not c) else ''))

async def run(b, start, extra=''):
    ctx = await b.new_context(viewport={'width': 412, 'height': 900}, has_touch=True, is_mobile=True)
    mock = MOCK.replace("JSON.stringify({ mapId:'m-old', action:null, lastMapId:null })", json.dumps(json.dumps(start)))
    await ctx.add_init_script(mock + extra)
    page = await ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    await page.goto(URL)
    await page.wait_for_function('window.__sbhStudioReady === true', timeout=90000); await page.wait_for_timeout(1500)
    return ctx, page, errs

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        # Hub : map « Village forge » neuve (note forge) + action forge_test
        new_vf = """
          (()=>{ const add = { id:'m-vf', projectId:'p1', name:'Village forge', sizeX:64, sizeZ:64, height:48, terrain:'plaine', seed:3,
             worldX:0, worldZ:0, hasVillage:false, hasDungeon:false, hasOasis:false, hasMountains:false, hasRoads:false, dimension:'minecraft:overworld',
             linkedMobIds:[], linkedItemIds:[], linkedBlockIds:[], worldFilterTextureId:null, notes:'Structure: maison_forgeron' };
             const t = setInterval(()=>{ if(window.__maps){ window.__maps.push(add); clearInterval(t); } }, 0); window.__maps && window.__maps.push(add); })();
        """
        ctx, page, errs = await run(b, {'mapId': 'm-vf', 'action': 'forge_test', 'lastMapId': None}, new_vf)
        st = [s['name'] for s in await page.evaluate('__sbhDebug.structures')]
        bp = await page.evaluate("__calls.filter(c=>c[0]==='buildPlayable')")
        ok('H01 forge_test : map « Village forge » ouverte', (await page.evaluate('__sbhDebug.meta'))['id'] == 'm-vf')
        ok('H02 maison de forgeron posée UNE fois', sum('forgeron' in s.lower() for s in st) == 1, st)
        ok('H03 ▶ Tester lancé automatiquement', len(bp) == 1 and bp[0][1]['structureId'] == 'maison_forgeron', bp and bp[0][1]['structureId'])
        ok('H04 forgeron par défaut dans la scène', bp and [m['identifier'] for m in bp[0][1]['mobs']] == ['agw:forgeron_village'])
        ok('H05 barre de test affichée', await page.evaluate("document.querySelector('#testBar').classList.contains('on')"))
        ok('H06 pas d\'erreur', not errs, errs)
        await ctx.close()
        # place_forge sur une map qui a déjà du contenu → posée comme action annulable
        ctx, page, errs = await run(b, {'mapId': 'm-leg', 'action': 'place_forge', 'lastMapId': None})
        st = [s['name'] for s in await page.evaluate('__sbhDebug.structures')]
        ok('H07 place_forge : maison posée sur la map ouverte', any('forgeron' in s.lower() for s in st) and (await page.evaluate('__sbhDebug.meta'))['id'] == 'm-leg', st)
        ok('H08 annulable (↶)', await page.evaluate('__sbhDebug.undoCount') == 1)
        ok('H09 pas de test lancé', not await page.evaluate("__calls.some(c=>c[0]==='buildPlayable')"))
        await page.wait_for_timeout(2500)
        ok('H10 enregistrée automatiquement', await page.evaluate("__calls.some(c=>c[0]==='saveMap' && c[1]==='m-leg')"))
        # import d'une structure (.nbt) → liste Structures → mode « poser »
        c0 = await page.evaluate('__sbhDebug.blockCount()')
        await page.set_input_files('#structFileInput', 't_struct.nbt'); await page.wait_for_timeout(1200)
        items = await page.evaluate("[...document.querySelectorAll('#structList .stl')].map(e=>e.textContent)")
        ok('H12 structure importée ajoutée à la liste (sans remplacer la map)', any(t.startswith('📥') for t in items) and await page.evaluate('__sbhDebug.blockCount()') == c0, items)
        ok('H13 mode « poser » actif', any('Arrêter' in t for t in items), items)
        ok('H11 pas d\'erreur', not errs, errs)
        await ctx.close()
        print('\n'.join(R))
        await b.close()
        return sum(1 for x in R if x.startswith('KO'))
if __name__ == '__main__':
    sys.exit(asyncio.run(main()))
