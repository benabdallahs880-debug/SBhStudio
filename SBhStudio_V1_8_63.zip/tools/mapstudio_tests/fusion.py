"""V1.8.61 — fusion Map Studio + zone Maps : test du pont Android simulé (nouvelle API)."""
import asyncio, json, base64, struct, sys
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].startswith('http') else 'http://127.0.0.1:8765/mapstudio.html'

# Ancienne sauvegarde V1.8.60 (codes numériques) : 256 blocs « deepslate_bricks » (code 9) puis de l'air.
rle = [9, 256, 0, 16*16*16 - 256]
LEGACY = json.dumps({"format": "sbh-map-studio", "version": 3, "name": "Ancienne", "size": [16, 16, 16],
                     "world": {"sx": 16, "sy": 16, "sz": 16, "data": base64.b64encode(struct.pack('<4H', *rle)).decode()},
                     "objects": []})

MOCK = r'''
(() => {
  const calls = []; window.__calls = calls; const files = {}; window.__files = files;
  const bp = (id, name, extra) => Object.assign({ id, projectId:'p1', name, sizeX:64, sizeZ:64, height:48, theme:'desert_gothic',
     terrain:'désert', seed:7, worldX:0, worldZ:0, hasVillage:false, hasDungeon:false, hasOasis:false, hasMountains:false, hasRoads:false,
     dimension:'minecraft:overworld', linkedMobIds:[], linkedItemIds:[], linkedBlockIds:[], worldFilterTextureId:null, notes:'' }, extra||{});
  const maps = [
    bp('m-old', 'Village <img src=x onerror="window.__xss=1">', { hasVillage:true, hasRoads:true, notes:'Structure: maison_forgeron (15x12x20)' }),
    bp('m-leg', 'Ancienne', { sizeX:16, sizeZ:16, height:16 })
  ];
  files['map_m-leg'] = __LEGACY__;
  window.__maps = maps;
  const portals = [{id:'po', name:'Porte', linkedMapId:null, mapX:5, mapY:10, mapZ:5, width:4, height:5}];
  window.SBhBridge = {
    close(){ calls.push(['close']); }, ready(){ calls.push(['ready']); }, toast(m){ calls.push(['toast', m]); },
    error(...a){ calls.push(['error', ...a]); },
    projectInfo(){ return JSON.stringify({id:'p1', name:'Al-Zahra', hasProject:true}); },
    startInfo(){ return JSON.stringify({ mapId:'m-old', action:null, lastMapId:null }); },
    listMaps(){ return JSON.stringify(maps.map(m => ({ id:m.id, name:m.name, sizeX:m.sizeX, sizeZ:m.sizeZ, height:m.height, hasStudio: !!files['map_'+m.id] }))); },
    openMap(id){ const m = maps.find(x => x.id === id); calls.push(['openMap', id]); if(!m) return 'null';
      return JSON.stringify({ blueprint: JSON.parse(JSON.stringify(m)), content: files['map_'+id] || '', forge: /maison_forgeron/i.test(m.notes), structures: [] }); },
    saveMap(id, json, png){ const o = JSON.parse(json); if(!maps.find(m => m.id === id)) return false;
      files['map_'+id] = json; files['png_'+id] = png; const m = maps.find(x => x.id === id); m.name = o.name;
      calls.push(['saveMap', id, o.name, png.length, (o.bedrock && o.bedrock.functions || []).length]); return true; },
    createMap(j){ const b = JSON.parse(j); b.id = 'm-new' + maps.length; maps.push(b); calls.push(['createMap', b.id]); return JSON.stringify(b); },
    saveBlueprint(j){ const b = JSON.parse(j); const i = maps.findIndex(m => m.id === b.id); if(i < 0) return false; maps[i] = b; calls.push(['saveBlueprint', b]); return true; },
    linkPortal(pid, mid){ const p = portals.find(x => x.id === pid); if(!p) return false; p.linkedMapId = mid || null; calls.push(['linkPortal', pid, mid]); return true; },
    atelierLists(){ return JSON.stringify({ mobs:[{id:'mob1', name:'Forgeron', identifier:'agw:forgeron_village'}, {id:'mob2', name:'Garde', identifier:'agw:garde'}],
       items:[{id:'it1', name:'Épée'}], blocks:[], textures:[{id:'tx1', name:'Brume'}], portals,
       entities:[{id:'e1', name:'Statue', linkedMapId:'m-old', posX:10, posY:20, posZ:10, rotY:0, scale:1, glbKey:null},
                 {id:'e2', name:'Autre', linkedMapId:'m-zzz', posX:1, posY:20, posZ:1, rotY:0, scale:1, glbKey:null}],
       regions:{regions:[{name:'Camp', x:30, y:20, z:30},{name:'Loin', x:-900, y:20, z:-600}]} }); },
    buildPlayable(j){ const c = JSON.parse(j); calls.push(['buildPlayable', c]);
      return JSON.stringify({ ok:true, message:'ok', blocks: c.blocks.length/4, mobs: c.mobs.length }); },
    saveObjectGlb(k, b64){ files['glb_'+k] = b64; calls.push(['saveObjectGlb', k]); return true; },
    objectUrl(k){ return files['glb_'+k] ? 'data:application/octet-stream;base64,' + files['glb_'+k] : ''; },
    saveFile(b64, name){ calls.push(['saveFile', name, b64.length]); return true; },
    syncEntities(j){ calls.push(['syncEntities', JSON.parse(j)]); return true; }
  };
})();
'''.replace('__LEGACY__', json.dumps(LEGACY))

R = []
def ok(n, c, i=''): R.append(('OK ' if c else 'KO ') + n + (' — ' + str(i)[:300] if (i != '' and not c) else ''))
async def calls(page, name): return await page.evaluate(f'__calls.filter(c=>c[0]==={json.dumps(name)})')

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        ctx = await b.new_context(viewport={'width': 412, 'height': 900}, has_touch=True, is_mobile=True, device_scale_factor=1)
        await ctx.add_init_script(MOCK)
        page = await ctx.new_page(); errs = []
        page.on('pageerror', lambda e: errs.append('PAGEERROR ' + str(e)))
        page.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        await page.goto(URL)
        await page.wait_for_function('window.__sbhStudioReady === true', timeout=90000); await page.wait_for_timeout(500)
        cdp = await ctx.new_cdp_session(page)

        # 1. ancienne map de l'Atelier construite d'après sa fiche
        meta = await page.evaluate('__sbhDebug.meta')
        ok('F01 map demandée ouverte (m-old)', meta['id'] == 'm-old', meta)
        n0 = await page.evaluate('__sbhDebug.blockCount()')
        ok('F02 map jamais ouverte construite d\'après sa fiche', n0 > 1000, n0)
        st = [s['name'] for s in await page.evaluate('__sbhDebug.structures')]
        ok('F03 village de la fiche posé', 'Village' in st, st)
        ok('F04 maison de forgeron notée → POSÉE', any('forgeron' in s.lower() for s in st), st)
        pal = await page.evaluate('__sbhDebug.serializeState().world.palette')
        ok('F05 terrain « désert » → sable', 'minecraft:sand' in pal, pal)
        ok('F06 route de la fiche (dirt_path)', 'minecraft:dirt_path' in pal or 'minecraft:grass_path' in pal, pal)
        sm = await calls(page, 'saveMap')
        ok('F07 map construite enregistrée tout de suite (+ vue du dessus PNG + fonctions)', sm and sm[0][1] == 'm-old' and sm[0][3] > 100 and sm[0][4] >= 1, sm)
        objs = [o['id'] for o in await page.evaluate('__sbhDebug.objects')]
        ok('F08 entité liée à CETTE map ajoutée, pas celle d\'une autre map', 'e1' in objs and 'e2' not in objs, objs)
        ok('F09 ready() appelé', any(c[0] == 'ready' for c in await page.evaluate('__calls')))

        # 2. XSS : le nom de la map n'est jamais interprété
        await page.click('#btnReport'); await page.wait_for_timeout(400)
        imgs = await page.evaluate("document.querySelectorAll('#reportBody img').length")
        r0 = await page.evaluate("window.sbhBack()")  # ferme le rapport
        await page.click('#btnMapsList'); await page.wait_for_timeout(200)
        xss = await page.evaluate('window.__xss')
        imgs += await page.evaluate("document.querySelectorAll('#atelierMaps img').length")
        ok('F10 nom piégé non exécuté (rapport + liste des maps)', xss is None and imgs == 0 and r0 == 'handled', (xss, imgs, r0))
        await page.click('#btnMapsList'); await page.wait_for_timeout(100)

        # 3. Fiche
        await page.click('#btnFiche'); await page.wait_for_timeout(300)
        ok('F11 panneau Fiche ouvert', await page.evaluate("document.querySelector('#fichePanel').classList.contains('open')"))
        await page.locator('#ficheBody .chip', has_text='Oasis').click()
        await page.locator('#ficheBody .chip', has_text='Forgeron').click()
        await page.fill('#f_notes', 'notes test')
        await page.fill('#f_worldX', '120')
        await page.select_option('#f_texture', 'tx1')
        await page.locator('#ficheBody .chip', has_text='Porte').click(); await page.wait_for_timeout(200)
        ok('F12 portail lié à la map', any(c[2] == 'm-old' for c in await calls(page, 'linkPortal')))
        r = await page.evaluate('window.sbhBack()')   # Retour : ferme la fiche ET l'enregistre tout de suite
        sb = await calls(page, 'saveBlueprint')
        last = sb[-1][1] if sb else {}
        ok('F13 Retour ferme la fiche (handled) sans fermer Map Studio', r == 'handled' and not any(c[0] == 'close' for c in await page.evaluate('__calls')), r)
        ok('F14 fiche enregistrée (oasis, mob, notes, X, texture)', last.get('hasOasis') and last.get('linkedMobIds') == ['mob1'] and last.get('notes') == 'notes test'
           and last.get('worldX') == 120 and last.get('worldFilterTextureId') == 'tx1', last)

        # 4. ▶ Tester depuis la map réelle
        await page.click('#btnTest'); await page.wait_for_timeout(500)
        bp = await calls(page, 'buildPlayable')
        sc = bp[-1][1] if bp else {}
        nb = await page.evaluate('__sbhDebug.blockCount()')
        ok('F15 ▶ Tester envoie la map réelle (tous les blocs)', sc and len(sc['blocks']) == 4 * nb and sc['mapId'] == 'm-old', (len(sc.get('blocks', [])), nb))
        ok('F16 mob lié dans la scène + départ', sc and [m['identifier'] for m in sc['mobs']] == ['agw:forgeron_village'] and sc['spawn']['y'] > 0, sc and (sc['mobs'], sc['spawn']))
        ok('F17 palette en noms Bedrock', sc and all(x.startswith('minecraft:') for x in sc['palette']), sc and sc['palette'][:5])
        ok('F18 barre de test + mode Vue', await page.evaluate("document.querySelector('#testBar').classList.contains('on')") and (await page.evaluate('__sbhDebug.mode')) == 'view')
        r = await page.evaluate('window.sbhBack()')
        ok('F19 Retour quitte d\'abord le test', r == 'handled' and not await page.evaluate("document.querySelector('#testBar').classList.contains('on')"))

        # 5. Structure : pose au toucher + Annuler
        await page.locator('#structList .stl', has_text='Maison de forgeron').click(); await page.wait_for_timeout(500)
        u0 = await page.evaluate('__sbhDebug.undoCount'); c0 = await page.evaluate('__sbhDebug.blockCount()')
        box = await page.locator('#cv').bounding_box()
        x, y = box['x'] + box['width'] * 0.5, box['y'] + box['height'] * 0.55
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x, 'y': y, 'id': 0}]})
        await page.wait_for_timeout(60)
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []})
        await page.wait_for_timeout(400)
        u1 = await page.evaluate('__sbhDebug.undoCount'); c1 = await page.evaluate('__sbhDebug.blockCount()')
        ok('F20 maison posée au toucher (1 action annulable)', u1 == u0 + 1 and c1 != c0, (u0, u1, c0, c1))
        await page.evaluate('window.sbhBack()')   # arrêter de poser
        await page.click('#btnUndo'); await page.wait_for_timeout(300)
        ok('F21 ↶ Annuler retire la maison', await page.evaluate('__sbhDebug.blockCount()') == c0)
        await page.click('#btnRedo'); await page.wait_for_timeout(300)
        n_before_switch = await page.evaluate('__sbhDebug.blockCount()')

        # 6. Nouvelle map = une nouvelle map ; l'ancienne reste enregistrée
        before = len(await calls(page, 'saveMap'))
        await page.click('#btnNew'); await page.wait_for_selector('#dlg.open'); await page.click('#dlgYes'); await page.wait_for_timeout(600)
        cm = await calls(page, 'createMap'); sm = await calls(page, 'saveMap')
        meta = await page.evaluate('__sbhDebug.meta')
        ok('F22 Nouvelle map crée une map de l\'Atelier', cm and meta['id'] == cm[-1][1], (cm, meta))
        ok('F23 l\'ancienne map enregistrée AVANT (avec la maison)', any(c[1] == 'm-old' for c in sm[before:]), sm[before:])
        ok('F24 nouvelle map vide', await page.evaluate('__sbhDebug.blockCount()') == 0)
        ok('F25 Annuler ne mélange pas les maps', await page.evaluate('__sbhDebug.undoCount') == 0)
        # pose d'un bloc puis retour sur m-old via « Mes maps »
        new_id = meta['id']
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x, 'y': y, 'id': 0}]})
        await page.wait_for_timeout(60)
        await cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []}); await page.wait_for_timeout(300)
        placed = await page.evaluate('__sbhDebug.blockCount()')
        await page.click('#btnMapsList'); await page.wait_for_timeout(200)
        await page.locator('#atelierMaps .atl', has_text='Village').click(); await page.wait_for_timeout(1500)
        sm = await calls(page, 'saveMap')
        ok('F26 map courante enregistrée avant le changement', any(c[1] == new_id for c in sm), [c[1] for c in sm])
        ok('F27 m-old rouverte avec son contenu (maison incluse)', (await page.evaluate('__sbhDebug.meta'))['id'] == 'm-old' and await page.evaluate('__sbhDebug.blockCount()') == n_before_switch,
           (await page.evaluate('__sbhDebug.blockCount()'), n_before_switch))
        ok('F28 la map neuve a gardé son bloc', placed >= 1 and json.loads(await page.evaluate(f'__files["map_{new_id}"]'))['world']['enc'] == 'pal1', placed)

        # 7. Ancienne sauvegarde à codes numériques (V1.8.60)
        await page.click('#btnMapsList'); await page.wait_for_timeout(200)
        await page.locator('#atelierMaps .atl', has_text='Ancienne').click(); await page.wait_for_timeout(1500)
        cnt = await page.evaluate('__sbhDebug.blockCount()')
        pal = await page.evaluate('__sbhDebug.serializeState().world.palette')
        ok('F29 sauvegarde V1.8.60 relue (bons blocs)', cnt == 256 and 'minecraft:deepslate_bricks' in pal, (cnt, pal))

        # 8. Retour final : enregistre puis ferme
        await page.evaluate("document.querySelector('#mapName').value='Ancienne renommée'; document.querySelector('#mapName').dispatchEvent(new Event('input'))")
        r = await page.evaluate('window.sbhBack()')
        sm = await calls(page, 'saveMap'); sb = await calls(page, 'saveBlueprint')
        ok('F31 Retour sans panneau → « close » après enregistrement', r == 'close' and sm[-1][1] == 'm-leg' and sm[-1][2] == 'Ancienne renommée', (r, sm[-1][:3]))
        saved = json.loads(await page.evaluate('__files["map_m-leg"]'))
        ok('F30 ancienne map ré-enregistrée au nouveau format (noms)', saved['world'].get('enc') == 'pal1' and saved['version'] == 4, saved['world'].get('enc'))
        ok('F32 nom de la fiche mis à jour aussi', sb and sb[-1][1]['id'] == 'm-leg' and sb[-1][1]['name'] == 'Ancienne renommée', sb[-1][1].get('name') if sb else None)

        bad = [e for e in errs if 'Draco' not in e and 'trop grand' not in e]
        ok('F33 aucune erreur JS', not bad, bad)
        await page.screenshot(path='shot_fusion.png')
        print('\n'.join(R)); print('ERRORS', errs)
        await b.close()
        return sum(1 for x in R if x.startswith('KO'))
if __name__ == '__main__':
    sys.exit(asyncio.run(main()))
