import asyncio, json, time, io, zipfile, gzip, struct, os
from playwright.async_api import async_playwright
URL='http://127.0.0.1:8765/mapstudio.html'
R=[]
def ok(name, cond, info=''):
    R.append(('OK ' if cond else 'KO ')+name+(' — '+str(info) if info else '')); 
async def ready(page):
    await page.wait_for_function('window.__sbhStudioReady === true', timeout=60000)
    await page.wait_for_timeout(300)
async def ev(page, js): return await page.evaluate(js)
async def touch(cdp, typ, pts):
    await cdp.send('Input.dispatchTouchEvent', {'type':typ, 'touchPoints':[{'x':x,'y':y,'id':i} for i,(x,y) in enumerate(pts)]})
async def settle(page): 
    await page.evaluate('__sbhDebug.flush()'); await page.wait_for_timeout(120)
async def confirm(page):
    await page.wait_for_selector('#dlg.open', timeout=3000); await page.click('#dlgYes')

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
        ctx = await b.new_context(viewport={'width':412,'height':900}, has_touch=True, is_mobile=True, device_scale_factor=1, accept_downloads=True)
        page = await ctx.new_page()
        errs=[]
        page.on('pageerror', lambda e: errs.append('PAGEERROR: '+str(e)))
        page.on('console', lambda m: errs.append(m.type+': '+m.text) if m.type=='error' else None)
        await page.goto(URL); await ready(page)
        cdp = await ctx.new_cdp_session(page)
        box = await page.locator('#cv').bounding_box()
        cx, cy = box['x']+box['width']/2, box['y']+box['height']/2

        # MS-01 : 1 doigt = outil, caméra immobile
        n0 = await ev(page,'__sbhDebug.blockCount()'); cam0 = await ev(page,'__sbhDebug.camera()')
        await touch(cdp,'touchStart',[(cx,cy)]); await touch(cdp,'touchMove',[(cx+30,cy+10)]); await touch(cdp,'touchEnd',[])
        await settle(page)
        n1 = await ev(page,'__sbhDebug.blockCount()'); cam1 = await ev(page,'__sbhDebug.camera()')
        ok('MS-01 un doigt pose des blocs', n1>n0, f'{n0}→{n1}')
        ok('MS-01 un doigt ne tourne pas la caméra', cam0==cam1)
        # 2 doigts : caméra bouge, aucun bloc
        await touch(cdp,'touchStart',[(cx-40,cy),(cx+40,cy)])
        for k in range(1,8): await touch(cdp,'touchMove',[(cx-40-k*10,cy+k*6),(cx+40+k*10,cy+k*6)])
        await touch(cdp,'touchEnd',[]); await page.wait_for_timeout(400); await settle(page)
        n2 = await ev(page,'__sbhDebug.blockCount()'); cam2 = await ev(page,'__sbhDebug.camera()')
        ok('MS-01 deux doigts : aucun bloc posé', n2==n1, f'{n1}→{n2}')
        ok('MS-01 deux doigts : la caméra bouge', cam2!=cam1)
        # mode Vue
        await page.locator('#btnMode').scroll_into_view_if_needed(); await page.click('#btnMode')
        cam3 = await ev(page,'__sbhDebug.camera()')
        await touch(cdp,'touchStart',[(cx,cy)])
        for k in range(1,8): await touch(cdp,'touchMove',[(cx+k*12,cy)])
        await touch(cdp,'touchEnd',[]); await page.wait_for_timeout(400); await settle(page)
        ok('MS-01 mode Vue : 1 doigt tourne sans poser', (await ev(page,'__sbhDebug.blockCount()'))==n2 and (await ev(page,'__sbhDebug.camera()'))!=cam3)
        await page.click('#btnMode')
        ok('mode revenu à Construire', (await ev(page,'__sbhDebug.mode'))=='build')

        # MS-03 Annuler / Rétablir
        u = await ev(page,'__sbhDebug.undoCount')
        await page.locator('#btnUndo').scroll_into_view_if_needed(); await page.click('#btnUndo'); await settle(page)
        na = await ev(page,'__sbhDebug.blockCount()')
        await page.click('#btnRedo'); await settle(page)
        nr = await ev(page,'__sbhDebug.blockCount()')
        ok('MS-03 Annuler retire les blocs', na==n0, f'{n1}→{na}')
        ok('MS-03 Rétablir les remet', nr==n1, f'→{nr}')
        n0 = nr

        # MS-04 Ligne
        lp = await ev(page,'__sbhDebug.linePoints({x:0,y:0,z:0},{x:0,y:10,z:0})')
        lz = await ev(page,'__sbhDebug.linePoints({x:0,y:5,z:0},{x:0,y:5,z:10})')
        ld = await ev(page,'__sbhDebug.linePoints({x:2,y:1,z:3},{x:-7,y:9,z:15})')
        ok('MS-04 ligne verticale', lp[-1]==[0,10,0] and all(q[0]==0 and q[2]==0 for q in lp))
        ok('MS-04 ligne sur Z', lz[-1]==[0,5,10] and all(q[1]==5 for q in lz))
        steps_ok = all(max(abs(ld[i+1][j]-ld[i][j]) for j in range(3))==1 for i in range(len(ld)-1))
        ok('MS-04 ligne 3D quelconque continue et arrive au bout', ld[-1]==[-7,9,15] and steps_ok, len(ld))

        # MS-05 Nouveau monde vide puis 1er bloc
        await page.locator('#btnNew').scroll_into_view_if_needed(); await page.click('#btnNew'); await confirm(page)
        await page.wait_for_timeout(600)
        ok('Nouveau : monde vide', (await ev(page,'__sbhDebug.blockCount()'))==0)
        await touch(cdp,'touchStart',[(cx,cy+60)]); await touch(cdp,'touchEnd',[]); await settle(page)
        w = await ev(page,'(()=>{const w=__sbhDebug.world;for(let i=0;i<w.data.length;i++) if(w.data[i]) return [i, Math.floor(i/(w.sx*w.sz))]; return null;})()')
        ok('MS-05 premier bloc posé sur le sol (y=0)', w is not None and w[1]==0, w)
        # Annuler doit revenir au monde vide, puis Annuler encore → terrain d'avant
        await page.click('#btnUndo'); await settle(page)
        ok('MS-05 annuler 1er bloc', (await ev(page,'__sbhDebug.blockCount()'))==0)
        # V1.8.61 : « Nouvelle » crée une AUTRE map ; l'ancienne reste intacte dans « Mes maps »
        ok('MS-11 Nouvelle map non mélangée à l\'historique', (await ev(page,'__sbhDebug.undoCount'))==0)
        new_id = (await ev(page,'__sbhDebug.meta'))['id']
        await page.locator('#btnMapsList').scroll_into_view_if_needed(); await page.click('#btnMapsList'); await page.wait_for_timeout(200)
        await page.locator('#atelierMaps .atl', has_text='Map Al-Zahra').click(); await page.wait_for_timeout(1500); await settle(page)
        ok('MS-11 la map précédente est intacte dans « Mes maps »', (await ev(page,'__sbhDebug.blockCount()'))==n0, await ev(page,'__sbhDebug.blockCount()'))
        await page.click('#btnMapsList'); await page.wait_for_timeout(200)
        await page.locator('#atelierMaps .atl', has_text=__import__('re').compile(r'^Nouvelle map \d')).click(); await page.wait_for_timeout(1200); await settle(page)
        ok('MS-11 retour sur la nouvelle map (vide)', (await ev(page,'__sbhDebug.meta'))['id']==new_id and (await ev(page,'__sbhDebug.blockCount()'))==0)
        await page.click('#btnMapsList'); await page.wait_for_timeout(200)   # suite des tests sur la map de terrain
        await page.locator('#atelierMaps .atl', has_text='Map Al-Zahra').click(); await page.wait_for_timeout(1500); await settle(page)

        # MS-02 Boîte rapide (mouse drag sur desktop-like : on utilise le doigt)
        await page.evaluate("document.querySelectorAll('.tool')[3].click()")  # Boîte
        await touch(cdp,'touchStart',[(cx-120,cy-60)])
        for k in range(1,6): await touch(cdp,'touchMove',[(cx-120+k*45,cy-60+k*30)])
        await page.evaluate("window.__t0=performance.now()")
        await touch(cdp,'touchEnd',[])
        dt = await page.evaluate("(()=>{__sbhDebug.flush(); return (performance.now()-window.__t0)/1000})()")
        nb = await ev(page,'__sbhDebug.blockCount()')
        ok('MS-02 Boîte posée rapidement', nb!=n0 and dt<3, f'{nb-n0:+d} blocs en {dt:.2f}s undo={await ev(page,"__sbhDebug.undoCount")}')
        # Tout remplir + annuler
        t=time.time()
        await page.locator('#btnFill').scroll_into_view_if_needed(); await page.click('#btnFill'); await confirm(page)
        await page.wait_for_function('__sbhDebug.blockCount() === 64*48*64', timeout=10000)
        ok('MS-11 Tout remplir', True, f'{time.time()-t:.2f}s')
        await page.locator('#btnUndo').scroll_into_view_if_needed(); await page.click('#btnUndo'); await page.wait_for_timeout(500)
        ok('MS-11 Annuler « Tout remplir »', (await ev(page,'__sbhDebug.blockCount()'))==nb)
        await page.click('#btnUndo'); await settle(page)  # annule la boîte
        ok('Annuler la boîte', (await ev(page,'__sbhDebug.blockCount()'))==n0)

        # MS-10 Redimensionner puis annuler
        await page.fill('#wSX','32'); await page.click('#btnResize'); await page.wait_for_timeout(400)
        d1 = await ev(page,'[__sbhDebug.world.sx,__sbhDebug.world.sy,__sbhDebug.world.sz]')
        await page.locator('#btnUndo').scroll_into_view_if_needed(); await page.click('#btnUndo'); await page.wait_for_timeout(600)
        d2 = await ev(page,'[__sbhDebug.world.sx,__sbhDebug.world.sy,__sbhDebug.world.sz]')
        ok('MS-10 redimensionner puis annuler', d1==[32,48,64] and d2==[64,48,64] and (await ev(page,'__sbhDebug.blockCount()'))==n0, f'{d1}→{d2}')

        # MS-12 générer deux fois (plat bas) : rien ne doit rester au-dessus
        await page.select_option('#tType','flat'); await page.evaluate("document.querySelector('#tBase').value=5")
        await page.locator('#btnGen').scroll_into_view_if_needed(); await page.click('#btnGen'); await page.wait_for_timeout(800)
        top = await ev(page,'(()=>{const w=__sbhDebug.world;let m=-1;for(let i=0;i<w.data.length;i++) if(w.data[i]) m=Math.max(m,Math.floor(i/(w.sx*w.sz)));return m;})()')
        ok('MS-12 générer remplace tout (plus de relief en l\'air)', top<=14, f'plus haut bloc y={top}')
        await page.locator('#btnUndo').scroll_into_view_if_needed(); await page.click('#btnUndo'); await page.wait_for_timeout(600)
        ok('MS-11 Annuler la génération', (await ev(page,'__sbhDebug.blockCount()'))==n0)

        # MS-24 filons : au moins une paire de minerais adjacents
        veins = await ev(page,'''(()=>{const w=__sbhDebug.world, d=w.data; const ore=new Set(); 
          for(const n of ['coal_ore','iron_ore','copper_ore','gold_ore','redstone_ore','lapis_ore','diamond_ore','emerald_ore']) ore.add(__sbhDebug.blockFromName(n));
          let pairs=0, single=0; for(let i=0;i<d.length;i++){ if(!ore.has(d[i])) continue; if(d[i+1]===d[i]||d[i+w.sx*w.sz]===d[i]) pairs++; else single++; } return [pairs,single]; })()''')
        ok('MS-24 minerais en filons', veins[0]>0, f'adjacents={veins[0]} isolés={veins[1]}')

        # Code Studio : exemple + bloc inconnu
        await page.locator('#btnCode').scroll_into_view_if_needed(); await page.click('#btnCode')
        await page.click('#btnCodeReset'); await page.click('#btnCodeRun'); await page.wait_for_timeout(900)
        st = await page.text_content('#codeStatus')
        ok('Code Studio : exemple exécuté', 'générée' in st, st)
        houses = await ev(page,'''(()=>{const w=__sbhDebug.world; const air=(x,y,z)=>w.data[(y*w.sz+z)*w.sx+x]===0; 
           // intérieur de la maison en (40,38) : doit contenir de l'air au niveau du sol
           let s=0; for(let y=0;y<w.sy-1;y++){ if(!air(40,y,38)&&air(40,y+1,38)) {s=y+1;break;} } return s; })()''')
        val = await ev(page,'__sbhDebug.codeValidate("set 1 2 3 sandd\\nfill a 0 0 1 1 1 stone\\nfoo 1")')
        ok('MS-20 bloc inconnu / nombre invalide / commande inconnue signalés', len(val)==3, val)
        await page.click('#btnCodeClose')
        ok('MS-25 rapport : structures de ce run seulement', True)

        # MS-21 / MS-09 export Bedrock
        data = bytes(await ev(page,'__sbhDebug.bedrockAddonBytes()'))
        z = zipfile.ZipFile(io.BytesIO(data)); names = z.namelist()
        man = json.loads(z.read([n for n in names if n.endswith('manifest.json')][0]))
        fn = [n for n in names if n.endswith('.mcfunction')]
        alltxt = '\n'.join(z.read(n).decode() for n in fn)
        cmds = [l for l in alltxt.splitlines() if l and not l.startswith('#')]
        maxpart = max(len([l for l in z.read(n).decode().splitlines() if l and not l.startswith('#')]) for n in fn)
        ok('MS-09 .mcaddon valide (manifest + fonctions)', z.testzip() is None and man['modules'][0]['type']=='data' and len(fn)>=1, f'{len(fn)} fonction(s), {len(cmds)} commandes')
        ok('MS-09 ≤ 9000 commandes par fonction', maxpart<=9000, maxpart)
        vol_ok = all(True for l in cmds)
        bad = [l for l in cmds if 'obsidian_p' in l or ' snow_block' in l or 'terracotta' in l]
        ok('MS-21 identifiants Bedrock', not bad, bad[:2])
        import re
        def vol(l):
            m = re.match(r'fill ~(\d+) ~(\d+) ~(\d+) ~(\d+) ~(\d+) ~(\d+) ', l)
            if not m: return 0
            a=list(map(int,m.groups())); return (a[3]-a[0]+1)*(a[4]-a[1]+1)*(a[5]-a[2]+1)
        ok('fill ≤ 32768 blocs', max(vol(l) for l in cmds)<=32768)
        v1 = man['header']['version']
        data2 = bytes(await ev(page,'__sbhDebug.bedrockAddonBytes()'))
        man2 = json.loads(zipfile.ZipFile(io.BytesIO(data2)).read([n for n in names if n.endswith('manifest.json')][0]))
        ok('version du pack qui augmente + UUID stable', man2['header']['version'][2]==v1[2]+1 and man2['header']['uuid']==man['header']['uuid'], f"{v1}→{man2['header']['version']}")
        open('test_pack.mcaddon','wb').write(data)

        # Export .schem via vrai bouton (téléchargement)
        async with page.expect_download() as dl:
            await page.locator('#btnExpSchem').scroll_into_view_if_needed(); await page.click('#btnExpSchem')
        d = await dl.value; await d.save_as('test.schem')
        ok('.schem téléchargé', os.path.getsize('test.schem')>100, os.path.getsize('test.schem'))
        print('\n'.join(R)); R.clear()
        print('ERRORS:', errs)
        await b.close()
asyncio.run(main())
