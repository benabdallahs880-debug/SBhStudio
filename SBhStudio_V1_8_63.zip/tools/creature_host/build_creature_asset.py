"""Construit app/src/main/assets/creature/creature_editor.html (V1.8.62).

Source de vérité : modules/CreatureStudio/editor/creature_editor.html (module CreatureStudio, inchangé)
+ tools/creature_host/sbh_host_glue.js (intégration SBh), inséré juste avant « /* ==ENDHOSTAPI== */ »
pour avoir accès aux fonctions internes de l'éditeur (P, buildBedrockPack, brPng…).

Usage (depuis la racine du dépôt) :  python3 tools/creature_host/build_creature_asset.py
À relancer après toute mise à jour du module CreatureStudio ou du fichier de liaison.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "modules/CreatureStudio/editor/creature_editor.html"
GLUE = ROOT / "tools/creature_host/sbh_host_glue.js"
OUT = ROOT / "app/src/main/assets/creature/creature_editor.html"
MARK = "/* ==ENDHOSTAPI== */"


def build() -> str:
    html = SRC.read_text(encoding="utf-8")
    if html.count(MARK) != 1:
        sys.exit(f"repère {MARK} introuvable ou en double dans {SRC}")
    glue = GLUE.read_text(encoding="utf-8")
    return html.replace(MARK, glue.rstrip() + "\n" + MARK)


if __name__ == "__main__":
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(build(), encoding="utf-8")
    print(f"écrit : {OUT.relative_to(ROOT)} ({OUT.stat().st_size} octets)")
