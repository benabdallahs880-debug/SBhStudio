# Intégration CreatureStudio dans SBh Studio (V1.8.62)

- Module d'origine (inchangé, avec ses 159 tests Python) : `modules/CreatureStudio/`.
- Liaison SBh : `sbh_host_glue.js` (pont `window.SBhCreature` : start / save / close / toast).
- Page utilisée par l'app : `app/src/main/assets/creature/creature_editor.html`, **générée** — ne pas la modifier à la main :

```bash
python3 tools/creature_host/build_creature_asset.py      # module + liaison → asset de l'app
cd app/src/main/assets && python3 -m http.server 8765 &  # puis :
python3 tools/creature_host/test_creature_host.py         # 32 contrôles (pont Android simulé, dont l'aperçu de l'âme)
```

Le corps Minecraft (géométrie, animations, contrôleur, texture PNG) est calculé par l'éditeur à chaque
enregistrement avec le code d'export de CreatureStudio, sous des identifiants propres au monstre
(`geometry.sbhc_sbh_<8 premiers caractères de l'id>`), puis relu par `PackGenerator` à l'export du projet.
Après une mise à jour du module, régénérer aussi `app/src/test/resources/creature/hippo1_body.json`
si le format du corps change (voir `CreatureBodyTest.kt`).
