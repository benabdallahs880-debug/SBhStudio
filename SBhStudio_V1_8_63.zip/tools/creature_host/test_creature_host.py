"""V1.8.62 — tests navigateur de la liaison SBh ↔ éditeur CreatureStudio (pont Android simulé).

    cd app/src/main/assets && python3 -m http.server 8765 &
    python3 tools/creature_host/test_creature_host.py
"""
import asyncio, base64, json, sys
from playwright.async_api import async_playwright

URL = 'http://127.0.0.1:8765/creature/creature_editor.html'
R = []
def ok(n, c, i=''): R.append(('OK ' if c else 'KO ') + n + (' — ' + str(i)[:400] if (i != '' and not c) else ''))

def mock(start):
    return '''(() => { const calls = []; window.__calls = calls;
      window.SBhCreature = {
        start(){ return %s; },
        save(p, b, png){ calls.push(['save', p, b, png]); return !window.__failSave; },
        close(){ calls.push(['close']); }, toast(t){ calls.push(['toast', t]); } }; })();''' % json.dumps(json.dumps(start))

async def page_with(b, start):
    ctx = await b.new_context(viewport={'width': 412, 'height': 860}, has_touch=True, is_mobile=True)
    await ctx.add_init_script(mock(start))
    pg = await ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.goto(URL); await pg.wait_for_timeout(600)
    return ctx, pg, errs

async def saves(pg): return await pg.evaluate("__calls.filter(c=>c[0]==='save')")

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        # 1) nouveau monstre depuis le modèle « Chef HIBOU », sans stats (le modèle garde les siennes)
        ctx, pg, errs = await page_with(b, {'name': 'Mon Chef', 'project': None, 'example': 'chef', 'stats': None, 'bodyKey': 'sbh_1a2b3c4d'})
        sv = await saves(pg)
        ok('C01 corps créé depuis le modèle et enregistré tout de suite', len(sv) == 1, len(sv))
        proj = json.loads(sv[0][1]); body = json.loads(sv[0][2])
        ok('C02 nom du monstre repris', proj['creature']['name'] == 'Mon Chef', proj['creature']['name'])
        ok('C03 corps Minecraft : identifiants propres au monstre', body['geometryId'] == 'geometry.sbhc_sbh_1a2b3c4d' and body['bodyKey'] == 'sbh_1a2b3c4d', body['geometryId'])
        ok('C04 géométrie + animations + contrôleur fournis', any(k.startswith('models/entity/') for k in body['files']) and any(k.startswith('animations/') for k in body['files'])
           and any(k.startswith('animation_controllers/') for k in body['files']), list(body['files']))
        geo = json.loads(next(v for k, v in body['files'].items() if k.startswith('models/entity/')))
        ok('C05 géométrie Bedrock valide (os + taille de texture)', geo['minecraft:geometry'][0]['description']['identifier'] == body['geometryId'] and len(geo['minecraft:geometry'][0]['bones']) == body['bones'] > 5)
        png = base64.b64decode(body['texture']['base64'])
        ok('C06 texture PNG lisible', png[:8] == b'\x89PNG\r\n\x1a\n' and body['texture']['width'] >= 16)
        ok('C07 entité client : animations + script main', body['client']['animate'] == ['main'] and 'main' in body['client']['animations'] and body['client']['geometry'] == body['geometryId'])
        ok('C08 boîte de collision et stats du modèle remontées', body['collision'] and body['collision']['height'] > 1 and body['stats']['health'] > 20, (body['collision'], body['stats']))
        ok('C09 aperçu PNG fourni', sv[0][3].startswith('data:image/png;base64,') and len(sv[0][3]) > 500)
        ok('C10 barre SBh + bouton Bedrock masqué', await pg.evaluate("!!document.getElementById('sbhBack') && getComputedStyle(document.getElementById('bx')).display==='none'"))
        # modification → enregistrement automatique
        await pg.evaluate("document.getElementById('ad').click()"); await pg.wait_for_timeout(1300)
        sv2 = await saves(pg)
        ok('C11 modification enregistrée automatiquement', len(sv2) == 2 and len(json.loads(sv2[1][1])['parts']) == len(proj['parts']) + 1, len(sv2))
        # 🎖 Soldat : 1re touche = demande de confirmation, rien n'est remplacé
        await pg.click('#sl'); await pg.wait_for_timeout(300)
        ok('C12 🎖 Soldat demande une 2e touche', await pg.evaluate("CreatureStudio.getProject().creature.name") == 'Mon Chef' and 'Touche encore' in await pg.text_content('#msg'))
        await pg.click('#sl'); await pg.wait_for_timeout(1300)
        ok('C13 2e touche : corps remplacé puis enregistré', json.loads((await saves(pg))[-1][1])['creature']['name'].startswith('Soldat'))
        # Retour : enregistre puis « close »
        n = len(await saves(pg))
        r = await pg.evaluate('window.sbhCreatureBack()')
        ok('C14 Retour enregistre puis ferme', r == 'close' and len(await saves(pg)) == n + 1)
        await pg.click('#sbhBack'); await pg.wait_for_timeout(100)
        ok('C15 bouton ← Atelier ferme', any(c[0] == 'close' for c in await pg.evaluate('__calls')))
        ok('C16 aucune erreur JS', not errs, errs)
        saved_project = json.loads((await saves(pg))[-1][1])
        await ctx.close()

        # 2) réouverture d'un corps enregistré : la fiche (stats) fait foi, pas de sauvegarde inutile
        ctx, pg, errs = await page_with(b, {'name': 'Soldat', 'project': json.dumps(saved_project), 'example': None,
                                            'stats': {'health': 77, 'damage': 9, 'speed': 0.25, 'detectionRange': 40}, 'bodyKey': 'sbh_1a2b3c4d'})
        d = await pg.evaluate('CreatureStudio.getProject()')
        ok('C17 corps enregistré rouvert', d['project']['id'] == saved_project['project']['id'] and len(d['parts']) == len(saved_project['parts']))
        ok('C18 stats de la fiche appliquées', d['behaviors']['stats']['health'] == 77 and d['behaviors']['stats']['damage'] == 9 and d['behaviors']['stats']['detectionRange'] == 40, d['behaviors']['stats'])
        ok('C19 pas d\'enregistrement à l\'ouverture', len(await saves(pg)) == 0)
        await pg.evaluate("document.getElementById('un').click()"); await pg.wait_for_timeout(200)
        ok('C20 aucune erreur JS', not errs, errs)
        await ctx.close()

        # 3) projet illisible → nouveau corps + message ; stats hors limites bornées
        ctx, pg, errs = await page_with(b, {'name': 'Bête', 'project': '{"pas":"valide"}', 'example': None,
                                            'stats': {'health': 99999, 'damage': -5, 'speed': 3}, 'bodyKey': 'sbh_ffff0000'})
        d = await pg.evaluate('CreatureStudio.getProject()')
        t = [c[1] for c in await pg.evaluate("__calls.filter(c=>c[0]==='toast')")]
        ok('C21 corps illisible signalé, nouveau corps « Bête »', d['creature']['name'] == 'Bête' and t and 'illisible' in t[0], (d['creature']['name'], t))
        ok('C22 stats bornées (1000 / 0 / 1)', d['behaviors']['stats']['health'] == 1000 and d['behaviors']['stats']['damage'] == 0 and d['behaviors']['stats']['speed'] == 1, d['behaviors']['stats'])
        sv = await saves(pg)
        ok('C23 corps vide enregistré avec un corps Minecraft', len(sv) == 1 and json.loads(sv[0][2])['geometryId'] == 'geometry.sbhc_sbh_ffff0000', sv and sv[0][2][:200])
        await pg.evaluate("window.__failSave = true; document.getElementById('ad').click()"); await pg.wait_for_timeout(1300)
        ok('C24 échec d\'enregistrement affiché', '⚠' in await pg.text_content('#sbhState'), await pg.text_content('#sbhState'))
        ok('C25 aucune erreur JS', not errs, errs)
        await ctx.close()

        # 4) V1.8.63 : aperçu de l'âme sur le corps (Marche, vitesse ×2, amplitude ×0,5)
        ctx, pg, errs = await page_with(b, {'name': 'Soldat', 'project': json.dumps(saved_project), 'example': None, 'stats': None,
                                            'bodyKey': 'sbh_1a2b3c4d', 'preview': {'anim': 'marche', 'speed': 2, 'amplitude': 0.5, 'weight': 1, 'loop': True}})
        await pg.wait_for_timeout(700)
        txt = await pg.evaluate("document.body.innerText")
        ok('C27 aperçu de l\'âme lancé sur l\'animation « Marche »', await pg.evaluate('__sbhCreature.previewOn') and 'vitesse ×2.00' in txt and 'amplitude ×0.50' in txt, txt[:300])
        t1 = float(await pg.evaluate("document.getElementById('tl').value"))
        await pg.wait_for_timeout(330)   # (pas 500 ms : à vitesse ×2 une boucle de 1 s revient au même instant)
        t2 = float(await pg.evaluate("document.getElementById('tl').value"))
        ok('C28 l\'animation joue (et en boucle)', t1 != t2, (t1, t2))
        ok('C29 l\'aperçu ne modifie pas le corps (aucun enregistrement)', len(await saves(pg)) == 0)
        await pg.click('#sbhPvStop'); await pg.wait_for_timeout(200)
        ok('C30 ⏹ arrête l\'aperçu', not await pg.evaluate('__sbhCreature.previewOn'))
        ok('C31 aucune erreur JS', not errs, errs)
        await ctx.close()
        ctx, pg, errs = await page_with(b, {'name': 'Soldat', 'project': json.dumps(saved_project), 'example': None, 'stats': None,
                                            'bodyKey': 'sbh_1a2b3c4d', 'preview': {'anim': 'assis', 'speed': 1, 'amplitude': 1}})
        ok('C32 animation absente du corps : message clair', 'assis' in await pg.text_content('#msg') and not errs, (await pg.text_content('#msg'), errs))
        await ctx.close()

        # 5) hors de l'app : page CreatureStudio normale
        ctx = await b.new_context(); pg = await ctx.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(400)
        ok('C26 hors app : aucune barre SBh, éditeur normal', not await pg.evaluate("!!document.getElementById('sbhBar')") and await pg.evaluate("getComputedStyle(document.getElementById('bx')).display!=='none'") and not errs, errs)
        await ctx.close()
        await b.close()
    print('\n'.join(R))
    return sum(1 for x in R if x.startswith('KO'))

if __name__ == '__main__':
    sys.exit(asyncio.run(main()))
