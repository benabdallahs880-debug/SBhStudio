# Réparation complète de Map Studio — SBh Studio V1.8.60

**Date :** 05/10/2026
**Point de départ :** V1.8.59, `ANALYSE_MAP_STUDIO_1_8_59.md` (38 problèmes MS-01 à MS-38).
**Résultat :** les 38 points sont traités. Map Studio est aussi publié comme page Claude (lien dans la conversation).
**Version :** `version.json` (racine et assets) → **1.8.60, code 95**.

---

## 1. Ce qui a été vérifié, et comment

| Vérification | Moyen | Résultat |
|--------------|-------|----------|
| Éditeur 3D (`mapstudio.html`) | Chromium réel (WebGL logiciel), doigts et souris simulés, 3 suites de tests | **62 contrôles OK, 0 KO** (32 + 15 + 15) (scripts dans `tools/mapstudio_tests/`) |
| Flux Android (projet, Atelier, export, entités, Retour) | Même page, pont `SBhBridge` simulé fidèlement (mêmes méthodes, mêmes retours) | 15/15 OK |
| Pack Bedrock `.mcaddon` | Archive ouverte avec `zipfile` (Python) : CRC, manifest, fonctions, volume des `fill` | OK |
| Code Kotlin | Analyse lexicale + relecture | ⚠ **pas compilé ici** (pas de réseau) → la compilation GitHub fait foi |
| Tests unitaires Kotlin | `MapStudioStoreTest` (6 tests) écrit | ⚠ pas exécuté ici (le workflow GitHub ne lance pas encore les tests) |
| Dans Minecraft | — | ⚠ **à faire** : voir section 5 |

---

## 2. Fichiers touchés

| Fichier | Nature |
|---------|--------|
| `app/src/main/assets/mapstudio.html` | Réécrit en grande partie : 3 253 → environ 3 900 lignes |
| `app/src/main/java/com/sbh/studio/mapeditor/MapStudioStore.kt` | **Nouveau** : stockage par projet + fonctions pures testées |
| `app/src/main/java/com/sbh/studio/mapeditor/MapEditorScreen.kt` | Réécrit : nouveau pont, chargement, Retour |
| `app/src/main/java/com/sbh/studio/generator/AdvancedPackEngine.kt` | Les maps Map Studio entrent dans le `.mcaddon` (fonctions Bedrock) |
| `app/src/main/java/com/sbh/studio/MainActivity.kt` | `Screen.MapEditor(fromWorkshop)` : retour à l'écran d'origine |
| `app/src/main/java/com/sbh/studio/workshop/WorkshopScreen.kt` | Régions AGW rangées par projet |
| `app/src/test/java/com/sbh/studio/mapeditor/MapStudioStoreTest.kt` | **Nouveau** |
| `tools/mapstudio_tests/*` | **Nouveau** : tests navigateur + README |
| `version.json`, `app/src/main/assets/version.json` | 1.8.60 / 95 |

Inchangés : `js/three.module.js` (r160), `js/OrbitControls.js`, `PendingMapImport.kt`.

---

## 3. Principe des réparations

Les réparations suivent le principe de l'enquête 1.8.57 : **une seule règle, un seul propriétaire, et une boucle fermée**.

- **Une seule écriture de bloc** (`setBlock`) : elle marque les morceaux de map (chunks) à redessiner, et la boucle de rendu les redessine par petits lots.
- **Un seul historique**, avec deux sortes d'actions :
  - les actions fines (`idx/from/to`, indexées par une `Map`) ;
  - les instantanés avant/après, dimensions comprises : générer, vider, remplir, redimensionner, importer, Code Studio, charger, nouvelle map.
- **Une seule règle de noms de blocs** :
  - `bedrockId()` pour tout ce qui part vers Bedrock ;
  - `blockFromName()` pour tout ce qui arrive d'un fichier (états `[...]`, noms Bedrock, anciens noms).
- **Une seule fabrique de fonctions Bedrock** (`bedrockFunctionFiles()`), utilisée à la fois par l'export `.mcaddon` autonome et par l'envoi à l'Atelier. Kotlin ne fait que les ranger dans le pack.
- **Un seul stockage par projet** (`MapStudioStore`) : `files/map_studio/<projet>/` contient l'état auto et l'état manuel, les objets `.glb`, les maps envoyées et les régions.
- **Résultat réel affiché** : `exportMap` renvoie `{ok, mapId, message}`, et les imports comptent et nomment les blocs perdus.

---

## 4. Les 38 points, un par un

| N° | Problème (V1.8.59) | Réparation | Vérifié |
|----|--------------------|-----------|---------|
| MS-01 | Un doigt = caméra + peinture | **Deux modes**. 🖌 Construire : 1 doigt = outil, 2 doigts = tourner/zoomer. ✋ Vue : 1 doigt = tourner, 2 doigts = zoom/déplacement. Un 2ᵉ doigt **annule** le trait en cours. Bascule par le bouton d'en-tête ou en touchant le bandeau de la vue. | Navigateur : 1 doigt pose sans bouger la caméra ; 2 doigts bougent la caméra sans poser ; mode Vue OK |
| MS-02 | Chaque bloc reconstruit son chunk → gel | Les chunks modifiés sont marqués « sales », puis redessinés par lots (≈ 12 ms par image). | Boîte de 6 652 blocs : **0,34 s** (avant : environ 8,5 s sur PC, plus sur téléphone) |
| MS-03 | Rétablir ne rétablit rien | Annuler applique `from`, Rétablir applique `to`. | Pose → Annuler → Rétablir : bloc revenu |
| MS-04 | Ligne de travers | Vrai Bresenham 3D (axe directeur). | Verticale, axe Z, diagonale 3D : continues et arrivées au bon point |
| MS-05 | Monde vide : 1er bloc impossible | Le clic parcourt directement la grille (DDA) et touche le sol y = 0. | Nouveau → toucher → bloc posé à y = 0 |
| MS-06 | « Exporter vers SBh » → fichier jamais relu | `exportMap` crée ou met à jour une **MapBlueprint du projet actif** et range la map (et ses fonctions) dans `map_studio/<projet>/maps/`. `AdvancedPackEngine` ajoute `BP/functions/sbh_map/<nom>/partN.mcfunction` au `.mcaddon`, avec une entrée « Map incluse » dans le rapport. | Pont simulé : map liée, fonctions transmises, message réel ; Kotlin non compilé |
| MS-07 | Objets jamais envoyés à l'Atelier | `syncEntities` est appelé après import, déplacement, rotation, échelle, duplication, suppression, envoi et Retour. Il gère aussi la **suppression** et la map liée. | Pont simulé : envoi + suppression OK |
| MS-08 | Données Atelier injectées mais inutilisées | Panneau **Atelier** : nom du projet, liste des maps (ouvrir une map Map Studio, ou lier la map actuelle à une map existante), bouton d'envoi qui dit « nouvelle map » ou « mettre à jour X ». Portails liés affichés en cadres violets. | Pont simulé : liste, ouverture, liaison |
| MS-09 | Aucun export jouable dans Bedrock | Bouton **🎮 Bedrock** : `.mcaddon` contenant un pack de comportement (manifest, `functions/sbh_map/partN.mcfunction`, LISEZMOI). UUID stables par map et version qui **augmente** à chaque export, pour que Minecraft remplace le pack. | Archive valide, ≤ 9 000 commandes par fonction, `fill` ≤ 32 768 blocs |
| MS-10 | Annuler après Redimensionner abîme la map | Le redimensionnement devient un instantané (dimensions comprises). | 64→32→Annuler : 64×48×64, blocs identiques |
| MS-11 | Vider / Remplir / Générer non annulables, sans confirmation | Instantanés + **fenêtre de confirmation intégrée à la page**. `confirm()` est désactivé dans les pages Claude et peu fiable en WebView. | Remplir puis Annuler, Générer puis Annuler, Nouvelle map puis Annuler : OK |
| MS-12 | L'ancien relief reste en l'air | La génération vide le monde d'abord. | 2ᵉ génération plate : plus haut bloc y = 14 |
| MS-13 | Retour = map perdue ; une seule sauvegarde pour tous les projets | **Sauvegarde automatique** 1,5 s après chaque changement, par projet. Avant fermeture, Retour (bouton Android ou page) appelle `sbhBeforeClose()`. Au démarrage, la map est restaurée. 💾/📂 = emplacement manuel par projet. | Rechargement : map identique ; Retour : sauvegarde avant `close` |
| MS-14 | Retour toujours à l'Accueil | `Screen.MapEditor(fromWorkshop)` | Relecture (Kotlin non compilé) |
| MS-15 | Objets .glb perdus (cubes dorés) | Le `.glb` est conservé : fichier du projet dans l'app, IndexedDB dans un navigateur. Il est rechargé par URL (`WebViewAssetLoader`, `/mapfiles/`). Chaque objet est un **conteneur** : l'échelle de l'utilisateur n'écrase plus la normalisation. | Rechargement : objet restauré, pas un cube |
| MS-16 | Import : états de blocs → air, sans le dire | `blockFromName()` retire les `[états]` et reconnaît les noms Bedrock et les anciens noms. Les blocs inconnus sont **comptés et nommés** dans le message. | Herbe `[snowy=false]` et bûches `[axis=y]` gardées ; `fancy_block` signalé |
| MS-17 | v3, .nbt, taille | Sponge v3, structure Java `.nbt` **et `.mcstructure` Bedrock** (petit-boutiste) pris en charge. Le format est détecté au contenu. Au-delà de 256 par côté : refus clair, monde intact. Ancien `.schematic` MCEdit : message dédié. | v2, v3, .nbt, .mcstructure, 600×10×10 refusé |
| MS-18 | Écrêtage Y ignoré au clic | Le parcours de grille ignore les blocs hors de [Y min, Y max]. | Gomme avec Y max = 6 : seuls des blocs y ≤ 6 touchés |
| MS-19 | Paysage : plus d'outils | Mise en page 3 colonnes en paysage (outils · vue · réglages). | 860×400 : outils visibles à côté de la vue |
| MS-20 | Code Studio : pierre silencieuse, maisons pleines, forteresse fermée | Vérification avant exécution (bloc inconnu, nombre invalide, commande inconnue). `box` = pavé **creux**. Maisons creuses (fondation, coins en bûches, toit, porte, fenêtres). Forteresse qui **suit le relief**, avec tours en `deepslate_bricks` (ajouté à la palette) et **entrée**. Bouton 📘 Aide. | 3 erreurs signalées ; capture de l'exemple |
| MS-21 | Identifiants Java / `obsidian_p` | `obsidian_p` → `crying_obsidian`. Table Bedrock : `snow`, `hardened_clay`, `slime`, `end_bricks`, `nether_brick`, `red_nether_brick`, `grass_path`. | Aucune commande avec un nom Java connu pour différer |
| MS-22 | Une fenêtre de partage par partie | Un seul `.mcaddon`, qui contient toutes les parties. Kotlin l'ouvre **directement dans Minecraft** (`ACTION_VIEW`, comme l'export de l'Atelier). | Pont simulé : un seul `saveFile` |
| MS-23 | Code Studio : `indexOf` → gel | Un programme = un instantané, plus aucune recherche linéaire. | Exemple exécuté instantanément |
| MS-24 | Filons écrasés | Les minerais sont posés en 2ᵉ passe. | 385 paires adjacentes |
| MS-25 | Rapport : structures fantômes | La liste est vidée par Nouveau, Vider, Générer, Import et `map.create`, et sauvegardée avec la map. | OK |
| MS-26 | `fill` sans limite X/Z | Toutes les plages sont bornées au monde. | Relecture |
| MS-27 | « Mode compatibilité GPU » toujours affiché | Affiché seulement si la 1ʳᵉ configuration WebGL a échoué. | Aucun message en test |
| MS-28 | Densité de pixels écrasée | Même plafond (`MAX_DPR`) au démarrage et au redimensionnement. | Relecture |
| MS-29 | Écran noir avant le monde | `ready()` est envoyé **après** la construction du monde et la 1ʳᵉ image. | Pont simulé : `ready` après construction |
| MS-30 | Barre de chargement qui recule | `advance()` ne fait que monter. | Relecture |
| MS-31 | Rendu permanent (batterie) | Rendu **à la demande**, plus une image de sécurité par seconde. | Relecture + tests visuels |
| MS-32 | « Exportée ✓ » avant vérification | Le message vient du résultat renvoyé par Kotlin. | Pont simulé |
| MS-33 | Gros .glb lu sur le thread principal | Copie du fichier sur un autre thread, puis chargement par URL (plus de base64 de 33 Mo). Limite portée à 80 Mo. | Relecture |
| MS-34 | .glb compressé : erreur obscure | Message clair (Draco / Meshopt). Accesseurs vides gérés, adresses blob libérées. Le modèle est validé **avant** d'être ajouté. | Message affiché, aucun objet fantôme |
| MS-35 | Données de tous les projets | `atelierData()` filtré sur le projet actif. | Relecture |
| MS-36 | Régions hors map, fichier global | Régions **par projet**, ramenées dans la map et posées sur le sol. Plus de sonde toutes les 1,5 s. | Relecture + pont simulé |
| MS-37 | Raccourcis dans l'éditeur de code | Ignorés dans les champs, les listes, l'éditeur de code et le panneau Code ouvert. Ctrl+Maj+Z = Rétablir. | Relecture |
| MS-38 | `map_exports/` sans fin ; pile d'erreur perdue | 10 fichiers max. L'erreur réelle (nom + pile) est transmise. | Relecture |

---

## 5. Ce qui reste à faire

### 5.1 Compilation (GitHub)

Sur GitHub :
- supprimer `SBhStudio_V1_8_59.zip` ;
- envoyer `SBhStudio_V1_8_60.zip`.

**Fichiers à regarder en premier si ça échoue :** `MapEditorScreen.kt`, `MapStudioStore.kt`, `AdvancedPackEngine.kt`, `MainActivity.kt` (et `WorkshopScreen.kt`, une ligne).

**Points sensibles :**
- `WebViewAssetLoader.InternalStoragePathHandler` (androidx.webkit 1.12.1 : présent) ;
- `Screen.MapEditor` devenu `data class` ;
- signature `mapDocJson(m, hint)`.

### 5.2 Sur le téléphone

| # | Test | Attendu |
|---|------|---------|
| 1 | Map Studio : 1 doigt avec le Pinceau, puis 2 doigts | 1 doigt pose sans tourner ; 2 doigts tournent et zooment sans poser |
| 2 | Grande Boîte (≈ 30×10×30) | Pas de gel |
| 3 | Pose → ↶ → ↷ | Le bloc revient |
| 4 | Construire, appuyer sur Retour, rouvrir Map Studio | La map est là |
| 5 | Importer un `.glb` (Character Studio → Map Studio), Retour, rouvrir | Le modèle est là, pas un cube |
| 6 | Atelier SBh → Envoyer à l'Atelier, puis zone Maps de l'Atelier | La map apparaît |
| 7 | Export `.mcaddon` du projet (Atelier → Export) | Le rapport contient « Map incluse … /function sbh_map/<nom>/part1 » |
| 8 | Le bouton « ← Retour » de la page | Revient à l'écran d'origine (Atelier ou Accueil) |

### 5.3 Dans Minecraft (test n° 9 du plan, mis à jour)

1. 🎮 Bedrock → le `.mcaddon` s'ouvre dans Minecraft.
2. Monde avec le pack activé et les commandes activées, puis `/function sbh_map/part1` (puis part2…).
3. Noter dans le journal de contenu toute ligne refusée. Elle indiquera un **nom de bloc Bedrock à corriger** dans la table `BEDROCK_NAME` de `mapstudio.html`. C'est la seule partie qui dépend de la version de Minecraft.

### 5.4 Limites connues (non bloquantes)

- Avec l'écrêtage Y, la coupe d'un relief laisse voir l'intérieur « creux » : les faces internes ne sont pas dessinées. Le clic, lui, est juste.
- Les entités Atelier créées hors Map Studio (sans `.glb` conservé) apparaissent comme des repères dorés.
- La version publiée dans Claude ne voit pas l'Atelier : sa sauvegarde reste dans le navigateur. Ses fichiers arrivent en `.zip` quand le format n'est pas autorisé par la page (`.mcaddon`, `.schem`) : il faut le décompresser.
