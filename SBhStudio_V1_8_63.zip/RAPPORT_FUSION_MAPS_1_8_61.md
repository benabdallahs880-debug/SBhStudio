# V1.8.61 : Map Studio et la zone Maps de l'Atelier fusionnés, test « village forge »

Ce dossier se lit sans l'historique de la conversation. Il dit ce qui a été fait, quels fichiers ont changé, comment tout a été testé et ce qui reste à faire.

---

## 1. Le résultat en bref

Avant, il y avait **trois endroits** pour une map :
- la **zone Maps de l'Atelier** : une fiche avec terrain, taille, drapeaux, mobs liés, etc. ;
- **Map Studio** : la vraie construction 3D, mais une seule sauvegarde par projet ;
- l'**Éditeur 3D** : il servait au test « village forge », limité à 700 blocs, et ignorait la map choisie.

Maintenant :

1. **Une map = une seule chose.** Elle a une fiche dans l'Atelier, et son contenu 3D est dans `files/map_studio/<projet>/maps/<id>.json`.
   - Il y a une sauvegarde automatique **par map**.
   - Changer de map enregistre d'abord la map courante.
2. **Une ancienne map jamais ouverte dans Map Studio** est construite d'après sa fiche à la première ouverture. La construction utilise :
   - la taille, le terrain (désert → sable) et la graine ;
   - les drapeaux village, oasis, donjon et routes ;
   - les structures importées dans l'ancienne zone Maps ;
   - la maison de forgeron, si elle était seulement « notée ».
3. **Atelier → Maps** est devenu le sommaire :
   - chaque carte montre la **vraie vue du dessus** ;
   - le bouton « 🗺 Ouvrir dans Map Studio » ouvre la map ;
   - les boutons « 🏠 Poser la forge » et « ▶ Tester » sont là aussi ;
   - « Créer la map » crée la fiche puis ouvre Map Studio ;
   - sous l'aperçu de la zone, un bouton « 🗺 Ouvrir « nom » dans Map Studio » ouvre la map affichée.
4. **Dans Map Studio** :
   - le panneau **📝 Fiche** reprend les mêmes réglages que l'Atelier : terrain, dimension, monde X/Z, graine, drapeaux, mobs / items / blocs liés, filtre texture, portails et notes ;
   - la section **Structures** contient la maison de forgeron et les structures importées (.nbt, .schem, .json, .mcstructure). Elles se posent au toucher, et chaque pose s'annule avec ↶ ;
   - **📂 Maps** et **➕ Nouvelle** gèrent plusieurs maps.
5. **▶ Tester** construit la scène jouable SBH World (`placements.json`, `protocol.json`, `structure_ref.json`) depuis **la map réelle** :
   - tous les blocs de la map ;
   - les mobs liés dans la fiche, ou le forgeron par défaut s'il y a une forge ;
   - le point de départ devant la forge.

   Dans l'éditeur, la caméra se place sur le départ et des repères marquent le joueur et les mobs.
6. **Accueil « ▶ Tester le village forge »** ouvre la map « Village forge ». Si elle n'existe pas, elle est créée (64×64×48). La maison de forgeron est posée une seule fois, puis le test démarre.
7. **L'Éditeur 3D** (700 blocs) ne sert plus aux maps. Il reste seulement dans Atelier → Entités.

Ces critiques de l'analyse 1.8.60 sont corrigées dans le même travail :

| n° | Problème | Correction |
|---|---|---|
| 1 | Sauvegardes liées à l'ordre des blocs | Sauvegarde par **noms** (`enc: 'pal1'`). Les anciennes sont relues avec la table figée `LEGACY_1860`. |
| 2 | Le Livre de rapport pouvait exécuter du code | Tout est échappé avec `esc()`. |
| 3 | Une seule sauvegarde automatique, écrasée en 1,5 s | Sauvegarde **par map**. Changer de map enregistre avant. |
| 4 | Déplacer un objet au doigt n'était pas enregistré | C'est enregistré, et l'Atelier est prévenu. |
| 5 | « Nouvelle map » vidait la map courante | « Nouvelle map » crée une **nouvelle** map. L'ancienne reste dans « Mes maps ». |

Ces points de l'analyse sont aussi corrigés :
- n° 7 : `line` est limitée et `codeValidate` refuse les coordonnées au-delà de |100 000| ;
- n° 8 : la fuite de textures des repères ;
- n° 12 : seules les entités de **cette** map sont chargées ;
- n° 13 : les régions AGW ne s'affichent que dans la zone réelle de la map (worldX/worldZ) ;
- n° 14 : Retour d'Android ferme d'abord le panneau ouvert ;
- n° 17 : la clé du .glb est l'id de l'entité.

En fin de travail, j'ai trouvé et corrigé un dernier défaut. Une fiche modifiée moins de 0,7 s avant Retour ou un changement de map était perdue, ou écrite sur la mauvaise map. La fonction `flushFiche()` l'enregistre maintenant tout de suite (fermeture de la fiche, Retour, changement de map, nouvelle map).

---

## 2. Fichiers modifiés

| Fichier | Ce qui a changé |
|---|---|
| `app/src/main/assets/mapstudio.html` | Fichier principal, voir le détail ci-dessous. |
| `mapeditor/MapEditorScreen.kt` | Paramètres `mapId` et `action`. Nouveau pont, voir § 3. Les anciens `saveState`, `loadState`, `loadAtelierMap`, `exportMap` et `atelierData` sont retirés. Retour appelle `window.sbhBack`. |
| `mapeditor/MapStudioStore.kt` | Ajouts :<br>• `blueprintJson` ;<br>• `previewFile` et `savePreview` (PNG) ;<br>• `lastMapId` et `setLastMap` (`last_map.txt`) ;<br>• `legacyStructures` ;<br>• `hasForgeNote` ;<br>• `applyFiche` ;<br>• `migrateLegacyAutosave` (l'ancienne `state_autosave.json` devient une map). |
| `workshop/PlayableSceneBuilder.kt` | Ajouts : `CompactScene`, `placementsFromCompact` (fonction pure, testée) et `buildFromCompact`. |
| `workshop/WorkshopScreen.kt` | `onOpenMapEditor(mapId, action)`, `openMapInStudio`, `playVillageForge` passe par Map Studio, bouton sous l'aperçu de la zone Maps. Le drapeau mort `loadForgeOnEditorOpen` est retiré. |
| `workshop/MapZone.kt` | Cartes avec la vraie vue du dessus et les boutons Ouvrir / Poser la forge / Tester. La création ouvre Map Studio. Les anciens boutons de structure sont retirés. Ajout de `rememberMapPreview()`. |
| `workshop/VisualWorkshopPreview.kt` | La zone MAPS affiche la vraie vue du dessus quand elle existe. |
| `MainActivity.kt` | `Screen.MapEditor(fromWorkshop, mapId, action)`. |
| `app/src/test/.../mapeditor/MapFusionTest.kt` | **Nouveau.** 5 tests : `applyFiche`, `hasForgeNote`, `placementsFromCompact`. |
| `tools/mapstudio_tests/` | `full.py` adapté (« Nouvelle » crée une autre map). **Nouveaux** : `fusion.py` (33 contrôles) et `forge_action.py` (13 contrôles). `bridge.py` est supprimé (il testait l'ancien pont). |
| `version.json` (racine et `assets/`) | 1.8.61, code 96. |

### Détail de `mapstudio.html`

- **Registre de blocs :**
  - 19 blocs de la forge ajoutés **à la fin** : escaliers, dalles, barrières, coffre, four, enclume, entonnoir, etc. ;
  - `LEGACY_1860` garde l'ancien ordre (135 noms) ;
  - des alias Bedrock sont ajoutés (`web`, `unpowered_repeater`, `lit_furnace`…).
- **Sauvegarde :**
  - `serializeWorld` (palette de noms) et `deserializeWorldInto` (ancien ou nouveau format, blocs inconnus comptés) ;
  - `serializeState` passe en version 4.
- **Interface :**
  - en-tête : 📂 Maps, ➕ Nouvelle, 📝 Fiche, ▶ Tester ;
  - section « Map de l'Atelier » (`#atelierSect`), section « Structures » (`#structSect`) ;
  - `#testBar`, `#fichePanel`.
- **Stockage `store` :** une même interface pour l'app (pont) et le navigateur (localStorage + IndexedDB pour les .glb).
- **Fonctions :**
  - maps : `openMapById`, `switchMap`, `newMap`, `buildFromBlueprint`, `terrainPlan` ;
  - fiche : `renderFiche`, `saveFicheSoon`, `flushFiche` ;
  - structures : `stampStructure`, `stampAtSurface`, `startStamp`, `endStamp` ;
  - test : `buildTestScene`, `runTest` ;
  - `window.sbhBack`.
- **Démarrage :**
  - ouvre, dans l'ordre : la map demandée, la dernière map, la première map, sinon une nouvelle map ;
  - puis exécute l'action demandée : `place_forge`, `forge_test` ou `test`.

---

## 3. Pont Android → page (`SBhBridge`, synchrone)

| Méthode | Rôle |
|---|---|
| `projectInfo()` | `{id, name, hasProject}` |
| `startInfo()` | `{mapId, action, lastMapId}` : map et action demandées par l'Atelier |
| `listMaps()` | Maps du projet (fiches) avec `hasStudio`. Fait aussi la migration de l'ancienne sauvegarde unique. |
| `openMap(id)` | `{blueprint, content, forge, structures[]}` |
| `saveMap(id, json, pngBase64)` | Contenu, fonctions Bedrock et vue du dessus. Met à jour nom et tailles de la fiche. |
| `createMap(bpJson)` | Crée une fiche et la renvoie avec son id. |
| `saveBlueprint(bpJson)` | Fiche modifiée dans Map Studio (`applyFiche` garde l'id, le projet et les tailles). |
| `linkPortal(portalId, mapId)` | Lie ou délie un portail. |
| `atelierLists()` | Mobs, items, blocs, textures, portails, entités et régions **du projet**. |
| `buildPlayable(compactJson)` | Écrit la scène SBH World. Renvoie `{ok, message, blocks, mobs}`. |
| `saveObjectGlb`, `objectUrl`, `syncEntities`, `saveFile`, `ready`, `toast`, `close`, `error` | Inchangés. |

---

## 4. Tests effectués

| Suite | Résultat |
|---|---|
| `full.py` (tactile, Annuler/Rétablir, Ligne, Boîte, génération, Code Studio, export Bedrock, .schem) | **34/34 OK** |
| `imp.py` (imports .schem v2/v3, .nbt, .mcstructure, .glb, sauvegarde auto, écrêtage, paysage) | **15/15 OK** |
| `fusion.py`, avec l'app simulée par un faux pont | **33/33 OK** |
| `forge_action.py` | **13/13 OK** |
| **Total navigateur : 95/95 OK** | |
| `MapFusionTest.kt` + lecture lexicale de tous les .kt modifiés | Écrits ; lecture lexicale sans erreur. **Pas exécutés** (voir § 5). |

Ce que vérifie `fusion.py` :
- ancienne map construite d'après sa fiche, avec village, route, sable et forge ;
- entités de la seule map ouverte ;
- nom piégé `<img onerror>` non exécuté ;
- fiche enregistrée par Retour ;
- portail lié ;
- ▶ Tester envoie tous les blocs, le mob lié et le départ ;
- pose de la forge au toucher, puis Annuler et Rétablir ;
- Nouvelle map, puis retour à l'ancienne avec son contenu intact ;
- sauvegarde V1.8.60 en codes numériques relue puis réécrite par noms ;
- Retour enregistre puis ferme.

Ce que vérifie `forge_action.py` :
- l'action Accueil « Tester le village forge » : forge posée une fois, test lancé, forgeron dans la scène ;
- « Poser la forge » sur une map existante : action annulable, enregistrement automatique ;
- import d'une structure .nbt dans la liste Structures.

Les deux messages d'erreur de console d'`imp.py` sont **voulus** : ce sont les contrôles d'une structure trop grande et d'un .glb Draco refusés.

La page publiée dans le chat (artifact) est mise à jour avec la même version. La maison de forgeron y est jointe.

---

## 5. Ce qui reste à faire

### À vérifier en priorité sur le téléphone
1. **Compiler** (`./gradlew assembleDebug testDebugUnitTest`). Ici, Gradle et les dépôts Android sont inaccessibles. Le code Kotlin est relu et vérifié lexicalement, mais pas compilé. Les points sensibles :
   - imports `asImageBitmap` et `TextureRepository` ;
   - appels `MobRepository.loadForProject`, `ItemRepository` et `BlockRepository` dans `atelierLists()`. Vérifier que les noms de champs (`nom`, `identifiant`, `identifier`) correspondent.
2. Ouvrir une **ancienne** map de l'Atelier. Elle doit se construire d'après sa fiche, puis l'aperçu doit apparaître dans la zone Maps au retour.
3. Ouvrir un projet qui avait une sauvegarde Map Studio V1.8.60. Elle doit devenir une map nommée, et le fichier `state_autosave.migrated.json` doit apparaître.
4. Accueil « ▶ Tester le village forge ». Vérifier que SBH World lit bien le `placements.json` écrit. Le runtime Godot n'est pas dans l'app et n'a pas été testé.
5. Bouton Retour d'Android : avec la fiche ouverte, il doit la fermer. Sinon, il doit enregistrer puis quitter.

### Points de l'analyse 1.8.60 non traités
- **n° 6** : Boîte, Sphère et Ligne ne montent pas en hauteur sur un sol plat.
- **n° 9** : mémoire et temps de calcul des grands mondes (256³) sur téléphone.
- **n° 10** : les .glb passent en base64, et les fichiers d'objets supprimés ne sont jamais effacés.
- **n° 11** : effets réels des fonctions Bedrock dans Minecraft, à tester en jeu.
- **n° 15** : une sauvegarde illisible est mise de côté, mais pas réparée.
- **n° 16** : Annuler un import ne rend pas les objets.
- **n° 18 à 30, sauf 17** :
  - la palette est lourde ;
  - le rendu se relance sur un défilement ;
  - l'aperçu de la Ligne est faux ;
  - le pinceau laisse des trous ;
  - l'écrêtage ne protège pas les blocs cachés ;
  - des options glTF sont ignorées ;
  - il reste du code mort ;
  - le bandeau de mode est cliquable ;
  - le projet « global » est utilisé sans projet ;
  - « Dupliquer » une map dans l'Atelier ne copie pas son contenu 3D ;
  - le picking est faux quand la caméra est dans un bloc ;
  - l'oasis et le village sont mal posés sur un relief.

### Limites connues de la fusion
- Changer la **taille** d'une map dans la fiche de l'Atelier ne redimensionne pas son contenu. La taille réelle vient du contenu, et il faut la changer dans Map Studio, section Monde. `applyFiche` ignore volontairement les tailles envoyées depuis Map Studio.
- Les structures des anciennes maps, dans `files/structures/<mapId>_*.json`, sont posées à la première construction et proposées dans la liste Structures. Elles ne sont pas supprimées.
- L'Éditeur 3D reste disponible dans Atelier → Entités.
- Dans la page publiée (navigateur), « ▶ Tester » télécharge `placements.json` au lieu de lancer SBH World.

---

## 6. Livraison

- `SBhStudio_V1_8_61.zip` : projet complet. Sur GitHub, supprimer l'ancien zip puis envoyer celui-ci.
- Ce rapport est à la racine du projet.
