# SBh Studio 0.6.1

## Correctif 0.6.1 — Export vers Minecraft
Le bouton "Exporter" utilisait un partage générique (`ACTION_SEND`, type `application/octet-stream`), qui liste toutes les apps capables de recevoir un fichier quelconque — Minecraft ne s'y affiche jamais, même si le `.mcaddon` généré est parfaitement valide. Minecraft Bedrock ne réagit qu'à une **ouverture directe** du fichier.
Le code utilise maintenant `ACTION_VIEW` avec le type `application/mcaddon`, exactement comme lorsqu'on appuie sur le fichier depuis un gestionnaire de fichiers — avec un repli automatique sur le partage classique si aucune app ne peut l'ouvrir directement (Minecraft non installé, association différente selon l'appareil).
`version.json` pointe maintenant vers une vraie URL de Release GitHub (le workflow publie déjà des releases versionnées comme `v0.6.0`), pour que la page "Mises à jour" fonctionne réellement.

SBh Studio est un atelier Android orienté Minecraft Bedrock.

## Fonctionnalités
- projets sauvegardés avec écritures atomiques ;
- créatures, items et blocs configurables ;
- sélection de textures depuis le téléphone ;
- validation avant génération ;
- génération de structures Behavior Pack / Resource Pack ;
- export `.mcaddon` ;
- Mine Edit avec deux positions, normalisation, calcul du volume et confirmation avant opération ;
- système de mise à jour GitHub / APK.

## Limites volontairement conservées
Mine Edit prépare encore les opérations de monde mais ne modifie pas directement un monde Bedrock dans cette version. La génération Bedrock est une base automatisée et doit être testée sur la version Minecraft cible avant distribution.

## Tests
Le projet distingue les flux normaux, les entrées invalides et les opérations destructives protégées par confirmation.
