package com.sbh.studio.workshop

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sbh.studio.data.BlockRepository
import com.sbh.studio.data.ItemRepository
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.generator.AdvancedPackEngine
import com.sbh.studio.foundation.SBhWorldFoundation
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AgwDecor
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.ModeIconChip
import com.sbh.studio.ui.ModeIconTile
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.SectionTitle
import com.sbh.studio.ui.GoldDivider
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkshopScreen(
    project: SbhProject?,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val repo = remember { WorkshopRepository(context) }
    val mobRepo = remember { MobRepository(context) }
    val itemRepo = remember { ItemRepository(context) }
    val blockRepo = remember { BlockRepository(context) }
    val engine = remember { AdvancedPackEngine(context) }

    var zone by remember { mutableStateOf(WorkshopZoneId.HUB) }
    var portals by remember { mutableStateOf(repo.loadPortals()) }
    var maps by remember { mutableStateOf(repo.loadMaps()) }
    var mobs by remember { mutableStateOf(mobRepo.loadAll()) }
    var items by remember { mutableStateOf(itemRepo.loadAll()) }
    var blocks by remember { mutableStateOf(blockRepo.loadAll()) }
    var reportText by remember { mutableStateOf("") }
    var lastExport by remember { mutableStateOf<File?>(null) }

    val projectId = project?.id ?: "global"
    fun projectMobs() = mobs.filter { it.projectId == projectId }
    fun projectItems() = items.filter { it.projectId == projectId }
    fun projectBlocks() = blocks.filter { it.projectId == projectId }
    fun projectPortals() = portals.filter { it.projectId == projectId }
    fun projectMaps() = maps.filter { it.projectId == projectId }

    fun savePortals(v: List<PortalBlueprint>) { portals = v; repo.savePortals(v) }
    fun saveMaps(v: List<MapBlueprint>) { maps = v; repo.saveMaps(v) }
    fun saveMobs(v: List<MobEntity>) { mobs = v; mobRepo.saveAll(v) }
    fun saveItems(v: List<SbhItem>) { items = v; itemRepo.saveAll(v) }
    fun saveBlocks(v: List<SbhBlock>) { blocks = v; blockRepo.saveAll(v) }

    fun generateFoundation() {
        onMessage("Génération de la fondation en cours…")
        try {
            val result = SBhWorldFoundation.generateAndExport(context)
            lastExport = result.addonFile

            // Import automatique dans le projet Compose (mobs + items)
            val pid = project?.id ?: "global"
            val foundationMobs = listOf(
                MobEntity(projectId = pid, nom = "Yahya ibn Harith", identifiant = "agw:yahya", vie = 32, degats = 7, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Zaynab", identifiant = "agw:zaynab", vie = 20, degats = 0, hostile = false),
                MobEntity(projectId = pid, nom = "Chef de Hibou", identifiant = "agw:chef_hibou", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Chef de Ghurab", identifiant = "agw:chef_ghurab", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Le Roi", identifiant = "agw:roi", vie = 30, degats = 5, hostile = false),
                MobEntity(projectId = pid, nom = "Garde royal", identifiant = "agw:garde_royal", vie = 24, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Combattant Hibou", identifiant = "agw:soldat_hibou", vie = 22, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Combattant Ghurab", identifiant = "agw:soldat_ghurab", vie = 22, degats = 5, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Templier", identifiant = "agw:templier", vie = 28, degats = 6, hostile = false, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Marchand bédouin", identifiant = "agw:marchand_bedouin", vie = 18, degats = 0, hostile = false),
                MobEntity(projectId = pid, nom = "Vautour", identifiant = "agw:vautour", vie = 20, degats = 4, hostile = true, poursuite = true, attaque = true),
                MobEntity(projectId = pid, nom = "Hashashin", identifiant = "agw:hashashin", vie = 26, degats = 7, hostile = true, poursuite = true, attaque = true)
            )
            val foundationItems = listOf(
                SbhItem(projectId = pid, name = "Sabre de Hibou", identifier = "agw:sabre_hibou", damage = 7, durability = 600),
                SbhItem(projectId = pid, name = "Sabre de Ghurab", identifier = "agw:sabre_ghurab", damage = 7, durability = 600),
                SbhItem(projectId = pid, name = "Sabre royal", identifier = "agw:sabre_royal", damage = 8, durability = 650),
                SbhItem(projectId = pid, name = "Sabre templier", identifier = "agw:sabre_templier", damage = 8, durability = 650),
                SbhItem(projectId = pid, name = "Fusil royal", identifier = "agw:fusil_royal", damage = 11, durability = 400),
                SbhItem(projectId = pid, name = "Fusil de Hibou", identifier = "agw:fusil_hibou", damage = 10, durability = 380),
                SbhItem(projectId = pid, name = "Pistolet templier", identifier = "agw:pistolet_templier", damage = 8, durability = 300),
                SbhItem(projectId = pid, name = "Pistolet royal", identifier = "agw:pistolet_royal", damage = 8, durability = 300),
                SbhItem(projectId = pid, name = "Mitrailleuse lourde", identifier = "agw:mitrailleuse_lourde", damage = 14, durability = 800),
                SbhItem(projectId = pid, name = "NRJ noire", identifier = "agw:nrj_noire", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Minerai brut", identifier = "agw:minerai_brut", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Plan mécanique", identifier = "agw:plan_mecanique", damage = 0, durability = 1),
                SbhItem(projectId = pid, name = "Composant rare", identifier = "agw:composant_rare", damage = 0, durability = 1)
            )
            saveMobs((mobs + foundationMobs).distinctBy { it.identifiant })
            saveItems((items + foundationItems).distinctBy { it.identifier })

            // Régions → Map Studio (fichier partagé)
            try {
                val regionsSrc = java.io.File(result.project.mapDir, "regions.json")
                if (regionsSrc.exists()) {
                    val dest = java.io.File(context.filesDir, "map_studio_regions.json")
                    regionsSrc.copyTo(dest, overwrite = true)
                }
            } catch (_: Exception) {}

            reportText = result.message + "\n\n✅ Importé dans le projet : ${foundationMobs.size} mobs, ${foundationItems.size} items\n📍 Régions prêtes pour Map Studio"
            onMessage("Fondation + import projet OK")
            zone = WorkshopZoneId.EXPORT
        } catch (e: Exception) {
            onMessage("Erreur fondation : ${e.message}")
            reportText = "❌ ${e.message}"
        }
    }

    fun importAgwPresets() {
        if (project == null) {
            onMessage("Ouvrez un projet d'abord")
            return
        }
        val pid = project.id
        val newMobs = engine.presetMobs(pid)
        val newItems = listOf(
            SbhItem(projectId = pid, name = "Cimeterre de fer", identifier = "agw:iron_scimitar", damage = 7, durability = 250),
            SbhItem(projectId = pid, name = "Lanterne suspendue", identifier = "agw:hanging_lantern", damage = 0, durability = 100)
        )
        val newBlocks = listOf(
            SbhBlock(projectId = pid, name = "Grès sombre", identifier = "agw:dark_sandstone", hardness = 1.5),
            SbhBlock(projectId = pid, name = "Pierre arabesque", identifier = "agw:arabesque_stone", hardness = 2.0),
            SbhBlock(projectId = pid, name = "Briques de nuit", identifier = "agw:night_bricks", hardness = 1.8),
            SbhBlock(projectId = pid, name = "Mosaïque sacrée", identifier = "agw:sacred_mosaic", hardness = 1.2)
        )
        saveMobs((mobs + newMobs).distinctBy { it.identifiant })
        saveItems((items + newItems).distinctBy { it.identifier })
        saveBlocks((blocks + newBlocks).distinctBy { it.identifier })
        val portal = PortalBlueprint(projectId = pid, name = "Portail Al-Zahra", identifier = "agw:portal_al_zahra", destinationHint = "الزهراء")
        val map = MapBlueprint(projectId = pid, name = "Cité Al-Zahra", sizeX = 48, sizeZ = 48, hasVillage = true, hasDungeon = true, hasOasis = true)
        savePortals((portals + portal).distinctBy { it.identifier })
        saveMaps((maps + map).distinctBy { it.name })
        onMessage("Monde AGW importé dans le projet")
        reportText = "✅ Import AGW : ${newMobs.size} mobs, ${newItems.size} items, ${newBlocks.size} blocs, 1 portail, 1 map"
        zone = WorkshopZoneId.EXPORT
    }

    fun runValidate() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet (Accueil → projet) puis revenez à l'atelier."
            return
        }
        val r = engine.validateAll(project, projectMobs(), projectItems(), projectBlocks(), projectPortals(), projectMaps())
        reportText = buildString {
            append(if (r.ok) "✅ Validation OK\n" else "❌ Erreurs\n")
            append("Contenu : ${projectMobs().size} mobs · ${projectItems().size} items · ${projectBlocks().size} blocs · ${projectPortals().size} portails · ${projectMaps().size} maps\n")
            r.errors.forEach { append("· $it\n") }
            r.warnings.forEach { append("⚠ $it\n") }
        }
    }

    fun runExport() {
        if (project == null) {
            reportText = "❌ Ouvrez un projet d'abord."
            return
        }
        val r = engine.exportAdvanced(project, projectMobs(), projectItems(), projectBlocks(), projectPortals(), projectMaps())
        lastExport = r.file
        reportText = buildString {
            append(if (r.ok) "✅ Export réussi\n" else "❌ Échec export\n")
            append("Fichier : ${r.file?.name ?: "—"}\n")
            append("Contenu : ${projectMobs().size} mobs · ${projectItems().size} items · ${projectBlocks().size} blocs · ${projectPortals().size} portails · ${projectMaps().size} maps\n")
            r.errors.forEach { append("· $it\n") }
            r.warnings.forEach { append("⚠ $it\n") }
        }
        if (r.ok && r.file != null) {
            onMessage("Pack généré : ${r.file.name}")
            try {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", r.file)
                // Même correctif que l'export du détail projet : Minecraft n'apparaît
                // jamais dans un partage générique (ACTION_SEND), seulement lors d'une
                // ouverture directe du fichier (ACTION_VIEW). Ce chemin d'export-ci avait
                // été oublié lors du premier correctif — désormais aligné.
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/mcaddon")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runCatching { context.startActivity(viewIntent) }.onFailure {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Partager le pack"))
                }
            } catch (_: Exception) { }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Atelier · الورشة", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text(project?.name ?: "Aucun projet ouvert", style = MaterialTheme.typography.labelSmall, color = AgwColors.Sand)
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(WorkshopZoneId.entries.toList()) { z ->
                    ModeIconChip(
                        label = zoneLabel(z),
                        iconAsset = zoneIcon(z),
                        selected = zone == z,
                        onClick = { zone = z }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            when (zone) {
                WorkshopZoneId.HUB -> HubZone(
                    onSelect = { zone = it },
                    mobCount = projectMobs().size,
                    portalCount = projectPortals().size,
                    mapCount = projectMaps().size,
                    itemCount = projectItems().size,
                    blockCount = projectBlocks().size,
                    onImportAgw = { importAgwPresets() },
                    onGenerateFoundation = { generateFoundation() },
                    onComingSoon = { label -> onMessage("$label : pas encore disponible, en préparation.") }
                )
                WorkshopZoneId.MOBS -> MobZone(
                    projectId = projectId,
                    mobs = projectMobs(),
                    hasProject = project != null,
                    onAddPresets = {
                        if (project == null) onMessage("Ouvrez un projet")
                        else {
                            val presets = engine.presetMobs(projectId)
                            saveMobs((mobs + presets).distinctBy { it.identifiant })
                            onMessage("Presets monstres ajoutés")
                        }
                    },
                    onSave = { m ->
                        if (project == null) { onMessage("Ouvrez un projet"); return@MobZone }
                        saveMobs(mobs.filter { it.id != m.id } + m)
                    },
                    onDelete = { m -> saveMobs(mobs - m) }
                )
                WorkshopZoneId.PORTALS -> PortalZone(
                    projectId = projectId,
                    portals = projectPortals(),
                    onSave = { p ->
                        savePortals(portals.filter { it.id != p.id } + p)
                    },
                    onDelete = { p -> savePortals(portals - p) }
                )
                WorkshopZoneId.MAPS -> MapZone(
                    projectId = projectId,
                    maps = projectMaps(),
                    onSave = { m -> saveMaps(maps.filter { it.id != m.id } + m) },
                    onDelete = { m -> saveMaps(maps - m) }
                )
                WorkshopZoneId.BLOCKS -> BlockZone(
                    projectId = projectId,
                    blocks = projectBlocks(),
                    onAdd = { block -> saveBlocks(blocks + block) },
                    onDelete = { b -> saveBlocks(blocks - b) }
                )
                WorkshopZoneId.ITEMS -> ItemZone(
                    projectId = projectId,
                    items = projectItems(),
                    onAdd = { item -> saveItems(items + item) },
                    onDelete = { i -> saveItems(items - i) }
                )
                WorkshopZoneId.EXPORT -> ExportZone(
                    reportText = reportText,
                    hasProject = project != null,
                    counts = "${projectMobs().size}m ${projectItems().size}i ${projectBlocks().size}b ${projectPortals().size}p ${projectMaps().size}maps",
                    onValidate = { runValidate() },
                    onExport = { runExport() },
                    onImportAgw = { importAgwPresets() }
                )
            }
        }
    }
}

@Composable
private fun HubZone(
    onSelect: (WorkshopZoneId) -> Unit,
    mobCount: Int,
    portalCount: Int,
    mapCount: Int,
    itemCount: Int,
    blockCount: Int,
    onImportAgw: () -> Unit,
    onGenerateFoundation: () -> Unit,
    onComingSoon: (String) -> Unit = {}
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        SectionTitle("Zones de l'atelier")
        GoldDivider(Modifier.padding(bottom = 6.dp))
        // Tuiles icônées par zone
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Mobs ($mobCount)", "branding/icons/icon_mobs.png", { onSelect(WorkshopZoneId.MOBS) }, Modifier.weight(1f))
                ModeIconTile("Portails ($portalCount)", "branding/icons/icon_portals.png", { onSelect(WorkshopZoneId.PORTALS) }, Modifier.weight(1f))
                ModeIconTile("Maps ($mapCount)", "branding/icons/icon_map.png", { onSelect(WorkshopZoneId.MAPS) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Items ($itemCount)", "branding/icons/icon_items.png", { onSelect(WorkshopZoneId.ITEMS) }, Modifier.weight(1f))
                ModeIconTile("Blocs ($blockCount)", "branding/icons/icon_blocks.png", { onSelect(WorkshopZoneId.BLOCKS) }, Modifier.weight(1f))
                ModeIconTile("Export", "branding/icons/icon_export.png", { onSelect(WorkshopZoneId.EXPORT) }, Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(4.dp))
        SectionTitle("Bientôt disponible")
        GoldDivider(Modifier.padding(bottom = 6.dp))
        Text(
            "Ces catégories sont prévues mais pas encore fonctionnelles — pas de faux bouton qui ne mène nulle part, juste l'ampleur de ce qui reste à construire.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        val comingSoon = listOf(
            "Recettes", "Biomes", "Fonctions", "Projectiles",
            "Structures", "Dimensions", "Particules", "Commerce",
            "Dialogues PNJ", "Nature", "Interface", "Machines"
        )
        comingSoon.chunked(3).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { label ->
                    ModeIconTile(
                        label = label,
                        iconAsset = "branding/icons/icon_soon.png", // pas d'asset dédié -> repli automatique sur ◆
                        onClick = { onComingSoon(label) },
                        modifier = Modifier.weight(1f),
                        subtitle = "Bientôt",
                        enabled = false
                    )
                }
                // Complète la ligne si elle a moins de 3 éléments, pour garder l'alignement.
                repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }

        Spacer(Modifier.height(8.dp))
        SectionTitle("Minimap de l'atelier")
        MinimapCanvas(
            pins = listOf(
                MinimapPin("hub", "Hub", 50f, 50f, WorkshopZoneId.HUB),
                MinimapPin("mobs", "Mobs ($mobCount)", 18f, 28f, WorkshopZoneId.MOBS),
                MinimapPin("portals", "Portails ($portalCount)", 82f, 22f, WorkshopZoneId.PORTALS),
                MinimapPin("maps", "Maps ($mapCount)", 78f, 72f, WorkshopZoneId.MAPS),
                MinimapPin("items", "Items ($itemCount)", 22f, 75f, WorkshopZoneId.ITEMS),
                MinimapPin("blocks", "Blocs ($blockCount)", 40f, 88f, WorkshopZoneId.BLOCKS),
                MinimapPin("export", "Export", 55f, 88f, WorkshopZoneId.EXPORT)
            ),
            onPin = onSelect
        )
        GoldPrimaryButton(
            "Importer le monde AGW dans ce projet",
            onImportAgw,
            modifier = Modifier.fillMaxWidth()
        )
        GoldOutlineButton(
            "Générer la fondation complète (Bac à sable)",
            onGenerateFoundation,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            "Parcours : Fondation → Import AGW → ajuster zones → Export. Tout le contenu projet part dans le .mcaddon.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun MinimapCanvas(pins: List<MinimapPin>, onPin: (WorkshopZoneId) -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(AgwColors.NightGlass)
            .border(1.dp, AgwColors.GoldGlass, RoundedCornerShape(14.dp))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val step = size.minDimension / 8f
            var x = 0f
            while (x < size.width) {
                drawLine(Color(0x22C9A227), Offset(x, 0f), Offset(x, size.height), 1f)
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(Color(0x22C9A227), Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }
            val cx = size.width * 0.5f
            val cy = size.height * 0.5f
            listOf(
                Offset(size.width * 0.18f, size.height * 0.28f),
                Offset(size.width * 0.82f, size.height * 0.22f),
                Offset(size.width * 0.78f, size.height * 0.72f),
                Offset(size.width * 0.55f, size.height * 0.88f)
            ).forEach { drawLine(Color(0x66C9A227), Offset(cx, cy), it, 3f) }
        }
        pins.forEach { pin ->
            Column(
                Modifier
                    .offset(x = (pin.x / 100f * 280).dp, y = (pin.y / 100f * 160).dp)
                    .clickable { onPin(pin.zone) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(14.dp)
                        .background(AgwColors.SacredGold, CircleShape)
                        .border(1.dp, AgwColors.GoldSoft, CircleShape)
                )
                Text(pin.label, color = AgwColors.PaleMarble, fontSize = 9.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun MobZone(
    projectId: String,
    mobs: List<MobEntity>,
    hasProject: Boolean,
    onAddPresets: () -> Unit,
    onSave: (MobEntity) -> Unit,
    onDelete: (MobEntity) -> Unit
) {
    val context = LocalContext.current

    // Nul tant qu'on crée un nouveau monstre ; rempli avec l'id du monstre en cours d'édition.
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }

    var name by rememberSaveable { mutableStateOf("Créature") }
    var id by rememberSaveable { mutableStateOf("agw:creature") }
    var vie by rememberSaveable { mutableStateOf("20") }
    var dmg by rememberSaveable { mutableStateOf("4") }
    var vit by rememberSaveable { mutableStateOf("0.25") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    // Comportement réel : ces booléens pilotent le JSON de comportement exporté
    // (minecraft:attack, poursuite du joueur, riposte aux dégâts subis).
    var hostile by rememberSaveable { mutableStateOf(true) }
    var poursuite by rememberSaveable { mutableStateOf(true) }
    var attaque by rememberSaveable { mutableStateOf(true) }
    var reactionDegats by rememberSaveable { mutableStateOf(true) }
    // Pouvoirs (buffs appliqués à l'entité côté PackGenerator).
    var pouvoirVitesse by rememberSaveable { mutableStateOf(false) }
    var pouvoirResistance by rememberSaveable { mutableStateOf(false) }
    var pouvoirInvisibilite by rememberSaveable { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }

    fun resetForm() {
        editingId = null
        name = "Créature"; id = "agw:creature"; vie = "20"; dmg = "4"; vit = "0.25"; tex = null
        hostile = true; poursuite = true; attaque = true; reactionDegats = true
        pouvoirVitesse = false; pouvoirResistance = false; pouvoirInvisibilite = false
    }

    fun loadForEdit(m: MobEntity) {
        editingId = m.id
        name = m.nom; id = m.identifiant
        vie = m.vie.toString(); dmg = m.degats.toString(); vit = m.vitesse.toString()
        tex = m.textureUri
        hostile = m.hostile; poursuite = m.poursuite; attaque = m.attaque; reactionDegats = m.reactionDegats
        pouvoirVitesse = m.pouvoirVitesse; pouvoirResistance = m.pouvoirResistance; pouvoirInvisibilite = m.pouvoirInvisibilite
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Création de monstres", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        GoldPrimaryButton("Presets AGW (4 créatures)", onAddPresets)

        Text(
            if (editingId == null) "Nouveau monstre" else "Modification : ${name.ifBlank { "monstre" }}",
            fontWeight = FontWeight.SemiBold,
            color = AgwColors.GoldSoft
        )
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(vie, { vie = it }, label = { Text("PV") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(vit, { vit = it }, label = { Text("Vitesse") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Choisir une texture" else "Texture choisie ✓")
        }

        Text("Comportement", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text(
            "Un monstre hostile qui ne poursuit ni n'attaque restera immobile en jeu — coche les trois ensemble pour un vrai monstre agressif.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(hostile, { v -> hostile = v; if (v) { poursuite = true; attaque = true } })
            Text("Hostile", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(poursuite, { poursuite = it }); Text("Poursuit le joueur", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(attaque, { attaque = it }); Text("Attaque au contact", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(reactionDegats, { reactionDegats = it }); Text("Riposte quand on l'attaque", color = AgwColors.PaleMarble)
        }

        Text("Pouvoirs", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirVitesse, { pouvoirVitesse = it }); Text("Vitesse (+50%)", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirResistance, { pouvoirResistance = it }); Text("Résistance", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirInvisibilite, { pouvoirInvisibilite = it }); Text("Invisibilité", color = AgwColors.PaleMarble)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onSave(
                        MobEntity(
                            id = editingId ?: java.util.UUID.randomUUID().toString(),
                            projectId = projectId,
                            nom = name,
                            identifiant = id,
                            vie = vie.toIntOrNull() ?: 20,
                            degats = dmg.toIntOrNull() ?: 4,
                            vitesse = vit.toDoubleOrNull() ?: 0.25,
                            hostile = hostile,
                            poursuite = poursuite,
                            attaque = attaque,
                            reactionDegats = reactionDegats,
                            pouvoirVitesse = pouvoirVitesse,
                            pouvoirResistance = pouvoirResistance,
                            pouvoirInvisibilite = pouvoirInvisibilite,
                            textureUri = tex
                        )
                    )
                    resetForm()
                },
                modifier = Modifier.weight(1f),
                enabled = hasProject
            ) { Text(if (editingId == null) "Ajouter" else "Enregistrer les modifications") }
            if (editingId != null) {
                OutlinedButton({ resetForm() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
            }
        }

        mobs.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(m.nom, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.identifiant} · PV ${m.vie} · DMG ${m.degats}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        val tags = buildList {
                            if (m.hostile) add("hostile")
                            if (m.poursuite) add("poursuite")
                            if (m.attaque) add("attaque")
                            if (m.pouvoirVitesse) add("+vitesse")
                            if (m.pouvoirResistance) add("+résistance")
                            if (m.pouvoirInvisibilite) add("+invisibilité")
                        }
                        if (tags.isNotEmpty()) {
                            Text(tags.joinToString(" · "), color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    TextButton({ loadForEdit(m) }) { Text("✎") }
                    TextButton({ if (editingId == m.id) resetForm(); onDelete(m) }) { Text("X") }
                }
            }
        }
        if (mobs.isEmpty()) Text("Aucun monstre pour ce projet.", color = AgwColors.Sand)
    }
}

private val PORTAL_DIMENSIONS = listOf("minecraft:overworld", "minecraft:nether", "minecraft:the_end")
private fun dimensionLabel(id: String) = when (id) {
    "minecraft:nether" -> "Nether"
    "minecraft:the_end" -> "End"
    else -> "Overworld"
}

@Composable
private fun PortalZone(
    projectId: String,
    portals: List<PortalBlueprint>,
    onSave: (PortalBlueprint) -> Unit,
    onDelete: (PortalBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }

    var name by rememberSaveable { mutableStateOf("Portail Al-Zahra") }
    var identifier by rememberSaveable { mutableStateOf("agw:portal_custom") }
    var width by rememberSaveable { mutableStateOf("4") }
    var height by rememberSaveable { mutableStateOf("5") }
    var frame by rememberSaveable { mutableStateOf("agw:night_bricks") }
    var dest by rememberSaveable { mutableStateOf("الزهراء · Al-Zahra") }
    // Coordonnées réelles de téléportation : avant, seule la description ci-dessus existait
    // et n'avait aucun effet en jeu — le portail était purement décoratif.
    var destX by rememberSaveable { mutableStateOf("0") }
    var destY by rememberSaveable { mutableStateOf("64") }
    var destZ by rememberSaveable { mutableStateOf("0") }
    var destDim by rememberSaveable { mutableStateOf(PORTAL_DIMENSIONS[0]) }

    fun resetForm() {
        editingId = null
        name = "Portail Al-Zahra"; identifier = "agw:portal_custom"; width = "4"; height = "5"
        frame = "agw:night_bricks"; dest = "الزهراء · Al-Zahra"
        destX = "0"; destY = "64"; destZ = "0"; destDim = PORTAL_DIMENSIONS[0]
    }

    fun loadForEdit(p: PortalBlueprint) {
        editingId = p.id
        name = p.name; identifier = p.identifier
        width = p.width.toString(); height = p.height.toString()
        frame = p.frameBlock; dest = p.destinationHint
        destX = p.destX.toString(); destY = p.destY.toString(); destZ = p.destZ.toString()
        destDim = p.destDimension
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Portails Minecraft", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text(
            "Marcher sur le bloc du portail téléporte réellement le joueur aux coordonnées choisies ci-dessous (script embarqué dans le pack).",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(width, { width = it }, label = { Text("Largeur") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(height, { height = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedTextField(frame, { frame = it }, label = { Text("Bloc cadre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(dest, { dest = it }, label = { Text("Description destination") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Text("Coordonnées de téléportation", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(destX, { destX = it }, label = { Text("X") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(destY, { destY = it }, label = { Text("Y") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(destZ, { destZ = it }, label = { Text("Z") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PORTAL_DIMENSIONS.forEach { d ->
                val selected = destDim == d
                OutlinedButton(
                    onClick = { destDim = d },
                    colors = if (selected) ButtonDefaults.outlinedButtonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
                             else ButtonDefaults.outlinedButtonColors(contentColor = AgwColors.PaleMarble)
                ) { Text(dimensionLabel(d)) }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onSave(
                        PortalBlueprint(
                            id = editingId ?: java.util.UUID.randomUUID().toString(),
                            name = name,
                            identifier = identifier,
                            width = width.toIntOrNull() ?: 4,
                            height = height.toIntOrNull() ?: 5,
                            frameBlock = frame,
                            destinationHint = dest,
                            destX = destX.toIntOrNull() ?: 0,
                            destY = destY.toIntOrNull() ?: 64,
                            destZ = destZ.toIntOrNull() ?: 0,
                            destDimension = destDim,
                            projectId = projectId
                        )
                    )
                    resetForm()
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
            ) { Text(if (editingId == null) "Enregistrer le portail" else "Enregistrer les modifications") }
            if (editingId != null) {
                OutlinedButton({ resetForm() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
            }
        }

        portals.forEach { p ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${p.identifier} · ${p.width}×${p.height}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        Text(
                            "→ ${p.destinationHint} · (${p.destX}, ${p.destY}, ${p.destZ}) ${dimensionLabel(p.destDimension)}",
                            color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall
                        )
                    }
                    TextButton({ loadForEdit(p) }) { Text("✎") }
                    TextButton({ if (editingId == p.id) resetForm(); onDelete(p) }) { Text("X") }
                }
            }
        }
        if (portals.isEmpty()) Text("Aucun portail pour ce projet.", color = AgwColors.Sand)
    }
}

@Composable
private fun MapZone(
    projectId: String,
    maps: List<MapBlueprint>,
    onSave: (MapBlueprint) -> Unit,
    onDelete: (MapBlueprint) -> Unit
) {
    var name by rememberSaveable { mutableStateOf("Plan cité") }
    var sizeX by rememberSaveable { mutableStateOf("32") }
    var sizeZ by rememberSaveable { mutableStateOf("32") }
    var village by rememberSaveable { mutableStateOf(true) }
    var dungeon by rememberSaveable { mutableStateOf(true) }
    var oasis by rememberSaveable { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Plans de map", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom du plan") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(sizeX, { sizeX = it }, label = { Text("Taille X") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(sizeZ, { sizeZ = it }, label = { Text("Taille Z") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(village, { village = it }); Text("Village", color = AgwColors.PaleMarble)
            Checkbox(dungeon, { dungeon = it }); Text("Donjon", color = AgwColors.PaleMarble)
            Checkbox(oasis, { oasis = it }); Text("Oasis", color = AgwColors.PaleMarble)
        }
        Button(
            onClick = {
                onSave(
                    MapBlueprint(
                        name = name,
                        sizeX = sizeX.toIntOrNull() ?: 32,
                        sizeZ = sizeZ.toIntOrNull() ?: 32,
                        hasVillage = village,
                        hasDungeon = dungeon,
                        hasOasis = oasis,
                        projectId = projectId,
                        theme = "desert_gothic"
                    )
                )
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Enregistrer le plan") }

        maps.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.sizeX}×${m.sizeZ} · ${m.theme}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(m) }) { Text("X") }
                }
            }
        }
    }
}

@Composable
private fun ItemZone(
    projectId: String,
    items: List<SbhItem>,
    onAdd: (SbhItem) -> Unit,
    onDelete: (SbhItem) -> Unit
) {
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("Nouvel item") }
    var id by rememberSaveable { mutableStateOf("agw:nouvel_item") }
    var dmg by rememberSaveable { mutableStateOf("0") }
    var dur by rememberSaveable { mutableStateOf("100") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Objets & armes", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(dur, { dur = it }, label = { Text("Durabilité") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Choisir une texture" else "Texture choisie ✓")
        }
        Button(
            onClick = {
                onAdd(SbhItem(projectId = projectId, name = name, identifier = id, damage = dmg.toIntOrNull() ?: 0, durability = dur.toIntOrNull() ?: 100, textureUri = tex))
                tex = null
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Ajouter l'item") }

        items.forEach { i ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(i.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${i.identifier} · DMG ${i.damage} · Dur ${i.durability}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(i) }) { Text("X") }
                }
            }
        }
        if (items.isEmpty()) Text("Aucun item pour ce projet.", color = AgwColors.Sand)
    }
}

@Composable
private fun BlockZone(
    projectId: String,
    blocks: List<SbhBlock>,
    onAdd: (SbhBlock) -> Unit,
    onDelete: (SbhBlock) -> Unit
) {
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("Nouveau bloc") }
    var id by rememberSaveable { mutableStateOf("agw:nouveau_bloc") }
    var hardness by rememberSaveable { mutableStateOf("1.0") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Blocs & architecture", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(hardness, { hardness = it }, label = { Text("Résistance") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Choisir une texture" else "Texture choisie ✓")
        }
        Button(
            onClick = {
                onAdd(SbhBlock(projectId = projectId, name = name, identifier = id, hardness = hardness.toDoubleOrNull() ?: 1.0, textureUri = tex))
                tex = null
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Ajouter le bloc") }

        blocks.forEach { b ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(b.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${b.identifier} · Résistance ${b.hardness}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(b) }) { Text("X") }
                }
            }
        }
        if (blocks.isEmpty()) Text("Aucun bloc pour ce projet.", color = AgwColors.Sand)
    }
}

@Composable
private fun ExportZone(
    reportText: String,
    hasProject: Boolean,
    counts: String,
    onValidate: () -> Unit,
    onExport: () -> Unit,
    onImportAgw: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Validation & export complet", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Projet : ${if (hasProject) "ouvert" else "aucun"} · $counts", color = AgwColors.Sand)
        if (!hasProject) {
            Text("Astuce : Accueil → ouvrez un projet → Atelier.", color = AgwColors.DesertOchre)
        }
        GoldOutlineButton("Importer AGW puis exporter", onImportAgw, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldOutlineButton("Valider", onValidate, modifier = Modifier.weight(1f))
            GoldPrimaryButton("Exporter", onExport, modifier = Modifier.weight(1f))
        }
        if (reportText.isNotBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = AgwColors.NightGlass),
                shape = AgwDecor.CardShape,
                modifier = Modifier.fillMaxWidth().border(AgwDecor.GoldBorder, AgwDecor.CardShape)
            ) {
                Text(reportText, Modifier.padding(12.dp), color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun zoneLabel(z: WorkshopZoneId) = when (z) {
    WorkshopZoneId.HUB -> "Hub"
    WorkshopZoneId.MOBS -> "Monstres"
    WorkshopZoneId.PORTALS -> "Portails"
    WorkshopZoneId.MAPS -> "Maps"
    WorkshopZoneId.BLOCKS -> "Blocs"
    WorkshopZoneId.ITEMS -> "Items"
    WorkshopZoneId.EXPORT -> "Export"
}

private fun zoneIcon(z: WorkshopZoneId) = when (z) {
    WorkshopZoneId.HUB -> "branding/icons/icon_hub.png"
    WorkshopZoneId.MOBS -> "branding/icons/icon_mobs.png"
    WorkshopZoneId.PORTALS -> "branding/icons/icon_portals.png"
    WorkshopZoneId.MAPS -> "branding/icons/icon_map.png"
    WorkshopZoneId.BLOCKS -> "branding/icons/icon_blocks.png"
    WorkshopZoneId.ITEMS -> "branding/icons/icon_items.png"
    WorkshopZoneId.EXPORT -> "branding/icons/icon_export.png"
}
