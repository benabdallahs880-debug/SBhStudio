package com.sbh.studio.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioStudioScreen(back: () -> Unit) {
    val context = LocalContext.current

    fun openQuranApp() {
        val launcher = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val chooser = Intent.createChooser(launcher, "Ouvrir une application Coran")
        try {
            context.startActivity(chooser)
        } catch (_: Exception) {
            Toast.makeText(context, "Aucune application disponible.", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareReminder() {
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_TEXT,
                "اتق الله فيما تسمع\n\nقال الله تعالى:\n﴿إِنَّ السَّمْعَ وَالْبَصَرَ وَالْفُؤَادَ كُلُّ أُولَٰئِكَ كَانَ عَنْهُ مَسْؤُولًا﴾\n\nالإسراء 17:36"
            )
        }
        context.startActivity(Intent.createChooser(share, "Partager le rappel"))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("نشيد", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                        Text("STUDIO AUDIO", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                    }
                },
                navigationIcon = {
                    TextButton(onClick = back) { Text("‹", fontSize = 32.sp, color = AgwColors.PaleMarble) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                ForgeSectionCard(
                    title = "نشيد · مساحة الصوت"
                ) {
                    Text("استمع أثناء العمل دون مغادرة SBH Studio", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                    Text(
                        "يمكنك فتح أي تطبيق قرآن مثبت على هاتفك عبر واجهة أندرويد، ثم متابعة العمل في SBH Studio. استمرار الصوت في الخلفية يعتمد على التطبيق الذي اخترته وإعداداته.",
                        color = AgwColors.PaleMarble,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Right
                    )
                    Spacer(Modifier.height(8.dp))
                    GoldPrimaryButton(
                        text = "فتح تطبيق قرآن",
                        onClick = ::openQuranApp,
                        modifier = Modifier.fillMaxWidth()
                    )
                    GoldOutlineButton(
                        text = "مشاركة التذكير",
                        onClick = ::shareReminder,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                ForgeSectionCard(
                    title = "اتق الله فيما تسمع"
                ) {
                    Text("تذكير قبل تشغيل الصوت", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                    Text(
                        "اتق الله فيما تسمع",
                        color = AgwColors.SacredGold,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "هذه عبارة تذكيرية، وليست آية. والآية التي تعبّر مباشرة عن مسؤولية السمع هي:",
                        color = AgwColors.Sand,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "﴿إِنَّ السَّمْعَ وَالْبَصَرَ وَالْفُؤَادَ كُلُّ أُولَٰئِكَ كَانَ عَنْهُ مَسْؤُولًا﴾",
                        color = AgwColors.PaleMarble,
                        fontSize = 22.sp,
                        lineHeight = 34.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "سورة الإسراء · 17:36",
                        color = AgwColors.DesertOchre,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    )
                }

                ForgeSectionCard(
                    title = "مبدأ نشيد"
                ) {
                    Text("الصوت يبقى تابعاً للعمل، لا العكس", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                    Text(
                        "اختيار تطبيق القرآن يتم عبر أندرويد. لا يدّعي SBH Studio التحكم في تطبيق خارجي أو في محتواه الصوتي. يوفّر الاستوديو نقطة وصول واضحة للاستماع أثناء العمل.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Right
                    )
                }
            }
        }
    }
}
