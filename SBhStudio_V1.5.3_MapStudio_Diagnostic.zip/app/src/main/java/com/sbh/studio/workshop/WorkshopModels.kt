package com.sbh.studio.workshop

import kotlinx.serialization.Serializable
import java.util.UUID

/** Zones de l'atelier SBh Studio */
enum class WorkshopZoneId {
    HUB,           // Accueil atelier / minimap
    MOBS,          // Création de monstres
    PORTALS,       // Portails Minecraft
    MAPS,          // Plans de map / structures
    BLOCKS,        // Blocs & architecture
    ITEMS,         // Objets & armes
    EXPORT         // Validation & export
}

@Serializable
data class WorkshopBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val zone: String,           // WorkshopZoneId name
    val title: String,
    val notes: String = "",
    val meta: Map<String, String> = emptyMap(),
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class PortalBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val identifier: String = "agw:portal_custom",
    val width: Int = 4,
    val height: Int = 5,
    val frameBlock: String = "agw:night_bricks",
    val destinationHint: String = "Al-Zahra · الزهراء",
    // Coordonnées réelles de téléportation. Avant, seul destinationHint existait (texte libre,
    // jamais utilisé pour téléporter réellement le joueur) : le portail était décoratif.
    val destX: Int = 0,
    val destY: Int = 64,
    val destZ: Int = 0,
    val destDimension: String = "minecraft:overworld",
    // Lien structurel avec une map de l'atelier. Les coordonnées sont relatives à cette map.
    val linkedMapId: String? = null,
    val mapX: Int = 0,
    val mapY: Int = 64,
    val mapZ: Int = 0,
    val notes: String = ""
)

@Serializable
data class MapBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val sizeX: Int = 32,
    val sizeZ: Int = 32,
    val height: Int = 64,
    val theme: String = "desert_gothic",
    val terrain: String = "desert",
    val seed: Long = 0L,
    val worldX: Int = 0,
    val worldZ: Int = 0,
    val hasVillage: Boolean = true,
    val hasDungeon: Boolean = true,
    val hasOasis: Boolean = false,
    val hasMountains: Boolean = false,
    val hasRoads: Boolean = false,
    // Les portails liés sont calculés depuis PortalBlueprint.linkedMapId.
    val dimension: String = "minecraft:overworld",
    val notes: String = ""
)

/** Point sur la minimap (coordonnées logiques 0..100) */
data class MinimapPin(
    val id: String,
    val label: String,
    val x: Float,
    val y: Float,
    val zone: WorkshopZoneId,
    val colorHint: Long = 0xFFC9A227
)
