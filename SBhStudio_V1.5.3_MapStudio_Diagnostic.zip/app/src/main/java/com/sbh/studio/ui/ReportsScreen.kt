package com.sbh.studio.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.sbh.studio.communication.ExportRecord
import com.sbh.studio.communication.ExportStatus
import com.sbh.studio.communication.ReportEntry
import com.sbh.studio.communication.ReportLevel
import com.sbh.studio.communication.SBhCommunicationCore
import com.sbh.studio.communication.SBhReport
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

/**
 * Écran Rapports + Historique.
 *
 * Lit exclusivement les données du SBhCommunicationCore :
 * - liste = getHistory() → ExportRecord (journal)
 * - détail = getReport(id) → SBhReport complet (fichiers sbh_reports/)
 *
 * Étape 4 : Copier (presse-papiers), Télécharger (TXT/JSON/HTML via SAF),
 * Partager (Intent ACTION_SEND + FileProvider).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val core = remember { SBhCommunicationCore(context) }
    val history = remember { core.getHistory(100) }

    // null = liste, non-null = détail d'un exportId
    var selectedId by remember { mutableStateOf<String?>(null) }

    if (selectedId != null) {
        val id = selectedId!!
        val report = remember(id) { core.getReport(id) }
        ReportDetailScreen(
            core = core,
            report = report,
            exportId = id,
            onBack = { selectedId = null }
        )
    } else {
        ReportListScreen(
            history = history,
            onOpen = { selectedId = it },
            onBack = onBack
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReportListScreen(
    history: List<ExportRecord>,
    onOpen: (String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Rapports", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text(
                            "${history.size} export(s)",
                            style = MaterialTheme.typography.labelSmall,
                            color = AgwColors.Sand
                        )
                    }
                },
                navigationIcon = {
                    TextButton(onBack) {
                        Text("←", color = AgwColors.GoldSoft, fontSize = 18.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            ForgeSectionCard(title = "CENTRE DE RAPPORTS", modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ForgeMetric(history.size.toString(), "EXPORTS", Modifier.weight(1f))
                    ForgeMetric(history.count { it.errorCount > 0 || it.criticalCount > 0 }.toString(), "À VÉRIFIER", Modifier.weight(1f))
                    ForgeMetric(history.count { it.status == ExportStatus.SUCCESS }.toString(), "VALIDES", Modifier.weight(1f))
                }
                Text(
                    "Historique des validations et exports SBH",
                    color = AgwColors.Sand,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            if (history.isEmpty()) {
            Box(
                Modifier.fillMaxSize().padding(pad),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Aucun rapport", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Les rapports apparaissent ici après un export.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(history, key = { it.exportId.value }) { record ->
                    ReportListItem(record = record, onClick = { onOpen(record.exportId.value) })
                }
            }
        }
        }
    }
}

@Composable
private fun ReportListItem(record: ExportRecord, onClick: () -> Unit) {
    val dateFmt = remember {
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
    }
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    record.exportId.value,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = AgwColors.SacredGold,
                    fontSize = 13.sp
                )
                Text(
                    record.projectName,
                    color = AgwColors.PaleMarble,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    dateFmt.format(Date(record.createdAtMs)),
                    style = MaterialTheme.typography.labelSmall,
                    color = AgwColors.Sand
                )
            }
            Spacer(Modifier.width(8.dp))
            StatusBadge(record.status)
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CountChip("I", record.infoCount, AgwColors.PersianBlue)
            CountChip("W", record.warningCount, AgwColors.DesertOchre)
            CountChip("E", record.errorCount, AgwColors.DriedBlood)
            CountChip("C", record.criticalCount, Color(0xFF9B1B1B))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReportDetailScreen(
    core: SBhCommunicationCore,
    report: SBhReport?,
    exportId: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val dateFmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Contenu en attente d'écriture via Storage Access Framework
    var pendingContent by remember { mutableStateOf<String?>(null) }

    val saveTxtLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri -> writeUri(context, uri, pendingContent, scope, snackbar); pendingContent = null }

    val saveJsonLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> writeUri(context, uri, pendingContent, scope, snackbar); pendingContent = null }

    val saveHtmlLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/html")
    ) { uri -> writeUri(context, uri, pendingContent, scope, snackbar); pendingContent = null }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Rapport", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text(
                            exportId,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.labelSmall,
                            color = AgwColors.Sand
                        )
                    }
                },
                navigationIcon = {
                    TextButton(onBack) {
                        Text("←", color = AgwColors.GoldSoft, fontSize = 18.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightGlass)
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        if (report == null) {
            Box(
                Modifier.fillMaxSize().padding(pad),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Rapport introuvable", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "L'entrée journal existe mais le détail complet n'a pas été persisté\n(export antérieur à l'Étape 3).",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            return@Scaffold
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(report.projectName, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold, fontSize = 18.sp)
                    Text(report.projectType, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Statut : ", color = AgwColors.PaleMarble)
                        StatusBadge(report.status)
                    }
                    Text(
                        "Date : ${dateFmt.format(Date(report.createdAtMs))}",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.labelSmall
                    )
                    if (report.projectVersion.isNotBlank()) {
                        Text("Version projet : ${report.projectVersion}", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                    }
                    if (report.studioVersion.isNotBlank()) {
                        Text("SBh Studio : ${report.studioVersion}", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                    }
                    report.archivePath?.let {
                        Text(
                            "Archive : ${it.substringAfterLast('/')}",
                            color = AgwColors.DesertOchre,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CountChip("INFO", report.infoCount, AgwColors.PersianBlue)
                        CountChip("WARN", report.warningCount, AgwColors.DesertOchre)
                        CountChip("ERR", report.errorCount, AgwColors.DriedBlood)
                        CountChip("CRIT", report.criticalCount, Color(0xFF9B1B1B))
                    }
                    when (report.status) {
                        ExportStatus.IMPORT_CONFIRMED -> {
                            Spacer(Modifier.height(6.dp))
                            Text("🟢 Import Minecraft confirmé", color = Color(0xFF4CAF50), fontWeight = FontWeight.Medium)
                        }
                        ExportStatus.IMPORT_UNKNOWN -> {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "⏳ Import non confirmé — SBh Studio ne peut pas observer l'installation Minecraft",
                                color = AgwColors.DesertOchre,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        ExportStatus.IMPORT_PENDING -> {
                            Spacer(Modifier.height(6.dp))
                            Text("⏳ En attente de confirmation d'import", color = AgwColors.Sand)
                        }
                        else -> {}
                    }
                }
            }

            // ── Actions Étape 4 ──────────────────────────────────────────
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Text("Actions", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                    Spacer(Modifier.height(8.dp))

                    // Copier
                    Button(
                        onClick = {
                            val text = core.formatAsText(report)
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("SBh Report ${report.exportId}", text))
                            scope.launch { snackbar.showSnackbar("Rapport copié dans le presse-papiers") }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AgwColors.SacredGold,
                            contentColor = AgwColors.DeepNight
                        )
                    ) { Text("📋 Copier le rapport") }

                    Spacer(Modifier.height(8.dp))

                    // Télécharger
                    Text("Télécharger", color = AgwColors.Sand, style = MaterialTheme.typography.labelMedium)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(onClick = {
                            pendingContent = core.formatAsText(report)
                            saveTxtLauncher.launch(core.suggestedFileName(report, "txt"))
                        }) { Text("TXT") }
                        OutlinedButton(onClick = {
                            pendingContent = core.formatAsJson(report)
                            saveJsonLauncher.launch(core.suggestedFileName(report, "json"))
                        }) { Text("JSON") }
                        OutlinedButton(onClick = {
                            pendingContent = core.formatAsHtml(report)
                            saveHtmlLauncher.launch(core.suggestedFileName(report, "html"))
                        }) { Text("HTML") }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Partager (vrai Sharesheet)
                    Button(
                        onClick = {
                            try {
                                val text = core.formatAsText(report)
                                val file = File(context.cacheDir, core.suggestedFileName(report, "txt"))
                                file.writeText(text, Charsets.UTF_8)
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    file
                                )
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "SBh Report ${report.exportId}")
                                    putExtra(Intent.EXTRA_TEXT, text)
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    clipData = ClipData.newUri(context.contentResolver, "SBh Report", uri)
                                }
                                context.startActivity(
                                    Intent.createChooser(intent, "Partager le rapport SBh")
                                )
                            } catch (e: Exception) {
                                scope.launch {
                                    snackbar.showSnackbar("Partage impossible : ${e.message}")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AgwColors.PersianBlue,
                            contentColor = AgwColors.PaleMarble
                        )
                    ) { Text("📤 Partager") }
                }
            }

            if (report.entries.isEmpty()) {
                item {
                    Text("Aucune entrée détaillée.", color = AgwColors.Sand)
                }
            } else {
                item {
                    Text(
                        "Détails (${report.entries.size})",
                        fontWeight = FontWeight.Bold,
                        color = AgwColors.SacredGold
                    )
                }
                items(report.entries, key = { it.id }) { entry ->
                    EntryCard(entry)
                }
            }
        }
    }
}

private fun writeUri(
    context: Context,
    uri: Uri?,
    content: String?,
    scope: kotlinx.coroutines.CoroutineScope,
    snackbar: SnackbarHostState
) {
    if (uri == null || content == null) return
    try {
        context.contentResolver.openOutputStream(uri)?.use { os ->
            os.write(content.toByteArray(Charsets.UTF_8))
        }
        scope.launch { snackbar.showSnackbar("Fichier enregistré") }
    } catch (e: Exception) {
        scope.launch { snackbar.showSnackbar("Échec enregistrement : ${e.message}") }
    }
}

@Composable
private fun EntryCard(entry: ReportEntry) {
    val (bg, border, icon) = when (entry.level) {
        ReportLevel.INFO -> Triple(Color(0x221F3A5F), AgwColors.PersianBlue, "🟢")
        ReportLevel.WARNING -> Triple(Color(0x228C6A3F), AgwColors.DesertOchre, "🟡")
        ReportLevel.ERROR -> Triple(Color(0x226B1E1E), AgwColors.DriedBlood, "🔴")
        ReportLevel.CRITICAL -> Triple(Color(0x339B1B1B), Color(0xFF9B1B1B), "⛔")
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(bg)
            .border(1.dp, border.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 14.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                entry.title,
                fontWeight = FontWeight.Bold,
                color = AgwColors.PaleMarble,
                modifier = Modifier.weight(1f)
            )
        }
        entry.code?.let { code ->
            Text(
                "${code.code} — ${code.shortName}",
                fontFamily = FontFamily.Monospace,
                color = AgwColors.SacredGold,
                fontSize = 12.sp
            )
        }
        Text(
            "Étape : ${entry.step.name}",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.labelSmall
        )
        if (entry.detail.isNotBlank()) {
            Text(entry.detail, color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
        }
        entry.file?.let {
            Text("Fichier : $it", color = AgwColors.DesertOchre, style = MaterialTheme.typography.labelSmall)
        }
        entry.cause?.let {
            Text("Cause : $it", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        }
        entry.suggestedFix?.let {
            Text("Correction : $it", color = Color(0xFF81C784), style = MaterialTheme.typography.bodySmall)
        }
        if (entry.autoRepairable) {
            Text("🔧 Réparable automatiquement", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun StatusBadge(status: ExportStatus) {
    val (label, color) = when (status) {
        ExportStatus.READY_TO_SEND -> "Prêt" to Color(0xFF4CAF50)
        ExportStatus.IMPORT_CONFIRMED -> "Import OK" to Color(0xFF4CAF50)
        ExportStatus.IMPORT_UNKNOWN -> "Import ?" to AgwColors.DesertOchre
        ExportStatus.IMPORT_PENDING -> "En attente" to AgwColors.Sand
        ExportStatus.BLOCKED -> "Bloqué" to AgwColors.DriedBlood
        ExportStatus.FAILED -> "Échec" to AgwColors.DriedBlood
        ExportStatus.REPAIRED -> "Réparé" to AgwColors.GoldSoft
        ExportStatus.EXPORTING -> "Export…" to AgwColors.PersianBlue
        ExportStatus.TRANSMITTING -> "Envoi…" to AgwColors.PersianBlue
        ExportStatus.VALIDATING -> "Validation…" to AgwColors.Sand
        ExportStatus.PREPARING -> "Préparation" to AgwColors.Sand
    }
    Box(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.2f))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(label, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CountChip(label: String, count: Int, color: Color) {
    Row(
        Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.18f))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(3.dp))
        Text("$count", color = AgwColors.PaleMarble, fontSize = 11.sp)
    }
}
