package com.sbh.studio.workshop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.MobRepository
import com.sbh.studio.data.SbhProject
import com.sbh.studio.generator.AdvancedPackEngine
import com.sbh.studio.ui.AgwColors

/**
 * Atelier multi-zones + minimap.
 * Zones : Hub, Mobs, Portails, Maps, Blocs, Items, Export.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkshopScreen(
    project: SbhProject?,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val repo = remember { WorkshopRepository(context) }
    val mobRepo = remember { MobRepository(context) }
    val engine = remember { AdvancedPackEngine(context) }

    var zone by remember { mutableStateOf(WorkshopZoneId.HUB) }
    var portals by remember { mutableStateOf(repo.loadPortals()) }
    var maps by remember { mutableStateOf(repo.loadMaps()) }
    var mobs by remember { mutableStateOf(mobRepo.loadAll()) }
    var reportText by remember { mutableStateOf("") }

    val projectId = project?.id ?: "global"

    fun savePortals(v: List<PortalBlueprint>) {
        portals = v
        repo.savePortals(v)
    }
    fun saveMaps(v: List<MapBlueprint>) {
        maps = v
        repo.saveMaps(v)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Atelier · الورشة", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                        Text(project?.name ?: "Sans projet", style = MaterialTheme.typography.labelSmall, color = AgwColors.Sand)
                    }
                },
                navigationIcon = { TextButton(onBack) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            // Barre de zones
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(WorkshopZoneId.entries.toList()) { z ->
                    FilterChip(
                        selected = zone == z,
                        onClick = { zone = z },
                        label = { Text(zoneLabel(z)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AgwColors.SacredGold,
                            selectedLabelColor = AgwColors.DeepNight
                        )
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            when (zone) {
                WorkshopZoneId.HUB -> HubZone(
                    onSelect = { zone = it },
                    portalCount = portals.size,
                    mapCount = maps.size,
                    mobCount = mobs.filter { it.projectId == projectId || project == null }.size
                )
                WorkshopZoneId.MOBS -> MobZone(
                    projectId = projectId,
                    mobs = mobs.filter { it.projectId == projectId || project == null },
                    onAddPresets = {
                        val presets = engine.presetMobs(projectId)
                        val merged = (mobs + presets).distinctBy { it.identifiant }
                        mobs = merged
                        mobRepo.saveAll(merged)
                        onMessage("Presets AGW ajoutés (${presets.size})")
                    },
                    onDelete = { m ->
                        val next = mobs - m
                        mobs = next
                        mobRepo.saveAll(next)
                    }
                )
                WorkshopZoneId.PORTALS -> PortalZone(
                    portals = portals.filter { it.projectId == projectId || project == null },
                    onAdd = {
                        val p = PortalBlueprint(
                            projectId = projectId,
                            name = "Portail Al-Zahra ${portals.size + 1}",
                            identifier = "agw:portal_${portals.size + 1}",
                            destinationHint = "الزهراء · Al-Zahra"
                        )
                        savePortals(portals + p)
                    },
                    onDelete = { p -> savePortals(portals - p) }
                )
                WorkshopZoneId.MAPS -> MapZone(
                    maps = maps.filter { it.projectId == projectId || project == null },
                    onAdd = {
                        val m = MapBlueprint(
                            projectId = projectId,
                            name = "Plan ${maps.size + 1}",
                            theme = "desert_gothic",
                            hasVillage = true,
                            hasDungeon = true
                        )
                        saveMaps(maps + m)
                    },
                    onDelete = { m -> saveMaps(maps - m) }
                )
                WorkshopZoneId.BLOCKS, WorkshopZoneId.ITEMS -> {
                    Text(
                        "Utilisez le détail du projet pour éditer blocs/items, puis revenez ici pour exporter.",
                        color = AgwColors.Sand
                    )
                    Text("Zone reliée au projet ouvert.", color = AgwColors.DesertOchre)
                }
                WorkshopZoneId.EXPORT -> ExportZone(
                    reportText = reportText,
                    onValidate = {
                        if (project == null) {
                            reportText = "Ouvrez un projet d'abord."
                            return@ExportZone
                        }
                        val r = engine.validateAll(
                            project,
                            mobs.filter { it.projectId == project.id },
                            emptyList(),
                            emptyList(),
                            portals.filter { it.projectId == project.id },
                            maps.filter { it.projectId == project.id }
                        )
                        reportText = buildString {
                            append(if (r.ok) "✅ Validation OK\n" else "❌ Erreurs\n")
                            r.errors.forEach { append("· $it\n") }
                            r.warnings.forEach { append("⚠ $it\n") }
                        }
                    },
                    onExport = {
                        if (project == null) {
                            reportText = "Ouvrez un projet d'abord."
                            return@ExportZone
                        }
                        val r = engine.exportAdvanced(
                            project,
                            mobs.filter { it.projectId == project.id },
                            emptyList(),
                            emptyList(),
                            portals.filter { it.projectId == project.id },
                            maps.filter { it.projectId == project.id }
                        )
                        reportText = buildString {
                            append(if (r.ok) "✅ Export : ${r.file?.name}\n" else "❌ Échec\n")
                            r.errors.forEach { append("· $it\n") }
                            r.warnings.forEach { append("⚠ $it\n") }
                        }
                        if (r.ok) onMessage("Pack avancé généré")
                    }
                )
            }
        }
    }
}

@Composable
private fun HubZone(
    onSelect: (WorkshopZoneId) -> Unit,
    portalCount: Int,
    mapCount: Int,
    mobCount: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Minimap de l'atelier", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        MinimapCanvas(
            pins = listOf(
                MinimapPin("hub", "Hub", 50f, 50f, WorkshopZoneId.HUB),
                MinimapPin("mobs", "Mobs ($mobCount)", 20f, 30f, WorkshopZoneId.MOBS),
                MinimapPin("portals", "Portails ($portalCount)", 80f, 25f, WorkshopZoneId.PORTALS),
                MinimapPin("maps", "Maps ($mapCount)", 75f, 70f, WorkshopZoneId.MAPS),
                MinimapPin("export", "Export", 50f, 85f, WorkshopZoneId.EXPORT)
            ),
            onPin = onSelect
        )
        Text("Touchez un point pour ouvrir la zone.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Text(
            "Architecture : Hub → fabrication par zone → validation Export. Moteur AdvancedPackEngine.",
            color = AgwColors.DesertOchre,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun MinimapCanvas(pins: List<MinimapPin>, onPin: (WorkshopZoneId) -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(AgwColors.NightStone)
            .border(1.dp, AgwColors.DesertOchre.copy(0.5f), RoundedCornerShape(12.dp))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            // Grille douce
            val step = size.minDimension / 8f
            var x = 0f
            while (x < size.width) {
                drawLine(Color(0x22C9A227), Offset(x, 0f), Offset(x, size.height), 1f)
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(Color(0x22C9A227), Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }
            // Routes
            drawLine(Color(0x66C9A227), Offset(size.width * 0.5f, size.height * 0.5f), Offset(size.width * 0.2f, size.height * 0.3f), 3f)
            drawLine(Color(0x66C9A227), Offset(size.width * 0.5f, size.height * 0.5f), Offset(size.width * 0.8f, size.height * 0.25f), 3f)
            drawLine(Color(0x66C9A227), Offset(size.width * 0.5f, size.height * 0.5f), Offset(size.width * 0.75f, size.height * 0.7f), 3f)
            drawLine(Color(0x66C9A227), Offset(size.width * 0.5f, size.height * 0.5f), Offset(size.width * 0.5f, size.height * 0.85f), 3f)
        }
        pins.forEach { pin ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(4.dp),
                contentAlignment = Alignment.TopStart
            ) {
                Column(
                    Modifier
                        .offset(
                            x = (pin.x / 100f * 280).dp,
                            y = (pin.y / 100f * 160).dp
                        )
                        .clickable { onPin(pin.zone) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier
                            .size(14.dp)
                            .background(AgwColors.SacredGold, CircleShape)
                            .border(1.dp, AgwColors.GoldSoft, CircleShape)
                    )
                    Text(pin.label, color = AgwColors.PaleMarble, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun MobZone(
    projectId: String,
    mobs: List<MobEntity>,
    onAddPresets: () -> Unit,
    onDelete: (MobEntity) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Création de monstres", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Button(
            onClick = onAddPresets,
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Charger presets AGW (4 créatures)") }
        mobs.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(m.nom, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.identifiant} · PV ${m.vie} · DMG ${m.degats}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(m) }) { Text("X") }
                }
            }
        }
        if (mobs.isEmpty()) Text("Aucun monstre — utilisez les presets ou le projet.", color = AgwColors.Sand)
    }
}

@Composable
private fun PortalZone(
    portals: List<PortalBlueprint>,
    onAdd: () -> Unit,
    onDelete: (PortalBlueprint) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Portails Minecraft", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Cadre, taille, destination narrative (Al-Zahra).", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)) {
            Text("+ Nouveau portail")
        }
        portals.forEach { p ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${p.identifier} · ${p.width}×${p.height} · ${p.frameBlock}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        Text("→ ${p.destinationHint}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(p) }) { Text("X") }
                }
            }
        }
    }
}

@Composable
private fun MapZone(
    maps: List<MapBlueprint>,
    onAdd: () -> Unit,
    onDelete: (MapBlueprint) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Plans de map", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Village, donjon, oasis — plans logiques pour construction in-game.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)) {
            Text("+ Nouveau plan")
        }
        maps.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.sizeX}×${m.sizeZ} · ${m.theme}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        Text(
                            listOfNotNull(
                                if (m.hasVillage) "Village" else null,
                                if (m.hasDungeon) "Donjon" else null,
                                if (m.hasOasis) "Oasis" else null
                            ).joinToString(" · "),
                            color = AgwColors.DesertOchre,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    TextButton({ onDelete(m) }) { Text("X") }
                }
            }
        }
    }
}

@Composable
private fun ExportZone(reportText: String, onValidate: () -> Unit, onExport: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Validation & export avancé", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onValidate) { Text("Valider") }
            Button(
                onClick = onExport,
                colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
            ) { Text("Exporter .mcaddon") }
        }
        if (reportText.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Text(reportText, Modifier.padding(12.dp), color = AgwColors.PaleMarble, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun zoneLabel(z: WorkshopZoneId) = when (z) {
    WorkshopZoneId.HUB -> "Hub"
    WorkshopZoneId.MOBS -> "Monstres"
    WorkshopZoneId.PORTALS -> "Portails"
    WorkshopZoneId.MAPS -> "Maps"
    WorkshopZoneId.BLOCKS -> "Blocs"
    WorkshopZoneId.ITEMS -> "Items"
    WorkshopZoneId.EXPORT -> "Export"
}
