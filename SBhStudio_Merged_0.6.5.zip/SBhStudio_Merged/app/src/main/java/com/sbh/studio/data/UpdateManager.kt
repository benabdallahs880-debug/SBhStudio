package com.sbh.studio.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private const val LATEST_RELEASE_URL =
    "https://api.github.com/repos/benabdallahs880-debug/SBhStudio/releases/latest"

private val json = Json { ignoreUnknownKeys = true }

sealed class UpdateCheckResult {
    data class UpdateAvailable(val info: UpdateInfo) : UpdateCheckResult()
    data object UpToDate : UpdateCheckResult()
    data class Error(val message: String) : UpdateCheckResult()
}

sealed class DownloadState {
    data object Idle : DownloadState()
    data object Downloading : DownloadState()
    data class ReadyToInstall(val apkFile: File) : DownloadState()
    data class Failed(val message: String) : DownloadState()
}

class UpdateManager(private val context: Context) {

    /**
     * Compare version codes de façon stable :
     * "0.6.4" → 6*100+4 = 604 ; "1.2.3" → 10203
     * Évite l'ancien bug 0.6.4 → 6+4=10 trop fragile.
     */
    fun parseVersionCode(versionName: String): Int {
        val parts = versionName.removePrefix("v").split('.').mapNotNull { it.toIntOrNull() }
        return when {
            parts.isEmpty() -> 0
            parts.size == 1 -> parts[0]
            parts.size == 2 -> parts[0] * 100 + parts[1]
            else -> parts[0] * 10000 + parts[1] * 100 + parts[2]
        }
    }

    suspend fun checkForUpdate(currentVersionCode: Int): UpdateCheckResult = withContext(Dispatchers.IO) {
        try {
            val connection = URL(LATEST_RELEASE_URL).openConnection() as HttpURLConnection
            connection.connectTimeout = 12000
            connection.readTimeout = 12000
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            connection.instanceFollowRedirects = true
            val code = connection.responseCode
            if (code != 200) {
                return@withContext UpdateCheckResult.Error(
                    "GitHub a répondu $code. Vérifiez le réseau ou les releases publiques."
                )
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = json.parseToJsonElement(body).jsonObject
            val tag = root["tag_name"]?.toString()?.trim('"')
                ?: return@withContext UpdateCheckResult.Error("Release sans tag_name.")
            val versionName = tag.removePrefix("v")
            val remoteCode = parseVersionCode(versionName)
            val assets = root["assets"]?.jsonArray.orEmpty()
            val apk = assets.firstOrNull {
                it.jsonObject["name"]?.toString()?.trim('"')?.endsWith(".apk", ignoreCase = true) == true
            }?.jsonObject?.get("browser_download_url")?.toString()?.trim('"')
                ?: return@withContext UpdateCheckResult.Error("La release $tag ne contient aucun APK.")
            val notes = root["body"]?.toString()?.trim('"')?.replace("\\n", "\n") ?: "Nouvelle version SBh Studio."
            val info = UpdateInfo(versionCode = remoteCode, versionName = versionName, apkUrl = apk, notes = notes)
            if (remoteCode > currentVersionCode) UpdateCheckResult.UpdateAvailable(info)
            else UpdateCheckResult.UpToDate
        } catch (e: Exception) {
            UpdateCheckResult.Error(e.message ?: "Erreur réseau")
        }
    }

    fun startDownload(apkUrl: String): Long {
        val updatesDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "sbh_updates")
        if (!updatesDir.exists()) updatesDir.mkdirs()
        val destFile = File(updatesDir, "sbh-studio-update.apk")
        if (destFile.exists()) destFile.delete()

        val request = DownloadManager.Request(Uri.parse(apkUrl))
            .setTitle("SBh Studio — mise à jour")
            .setDescription("Téléchargement de la nouvelle version")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(
                context,
                Environment.DIRECTORY_DOWNLOADS,
                "sbh_updates/sbh-studio-update.apk"
            )
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return dm.enqueue(request)
    }

    fun apkFile(): File = File(
        File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "sbh_updates"),
        "sbh-studio-update.apk"
    )

    /** Suit le DownloadManager jusqu'à succès / échec (max ~3 min). */
    suspend fun awaitDownload(downloadId: Long): DownloadState = withContext(Dispatchers.IO) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        repeat(90) {
            val q = DownloadManager.Query().setFilterById(downloadId)
            dm.query(q)?.use { c: Cursor ->
                if (c.moveToFirst()) {
                    val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    when (status) {
                        DownloadManager.STATUS_SUCCESSFUL -> {
                            val file = apkFile()
                            return@withContext if (file.exists() && file.length() > 0)
                                DownloadState.ReadyToInstall(file)
                            else DownloadState.Failed("Fichier APK introuvable après téléchargement.")
                        }
                        DownloadManager.STATUS_FAILED -> {
                            val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                            return@withContext DownloadState.Failed("Échec téléchargement (code $reason)")
                        }
                    }
                }
            }
            delay(2000)
        }
        DownloadState.Failed("Délai dépassé pour le téléchargement.")
    }

    fun installApk(apkFile: File) {
        if (!apkFile.exists()) return
        val uri = FileProvider.getUriForFile(context, "com.sbh.studio.fileprovider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
