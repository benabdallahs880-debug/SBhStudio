package com.sbh.studio.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sbh.studio.BuildConfig
import com.sbh.studio.data.DownloadState
import com.sbh.studio.data.UpdateCheckResult
import com.sbh.studio.data.UpdateInfo
import com.sbh.studio.data.UpdateManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdateScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val updateManager = remember { UpdateManager(context) }
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var checkResult by remember { mutableStateOf<UpdateCheckResult?>(null) }
    var downloadState by remember { mutableStateOf<DownloadState>(DownloadState.Idle) }
    val currentCode = BuildConfig.VERSION_CODE
    val currentName = BuildConfig.VERSION_NAME

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mises à jour", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onBack) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Version installée : $currentName ($currentCode)", color = AgwColors.Sand)
            Text(
                "Vérifie les releases GitHub publiques et installe l'APK en toute sécurité (FileProvider).",
                style = MaterialTheme.typography.bodySmall,
                color = AgwColors.DesertOchre
            )

            Button(
                onClick = {
                    checking = true
                    checkResult = null
                    downloadState = DownloadState.Idle
                    scope.launch {
                        checkResult = updateManager.checkForUpdate(currentCode)
                        checking = false
                    }
                },
                enabled = !checking && downloadState !is DownloadState.Downloading,
                colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
            ) {
                Text(if (checking) "Vérification..." else "Vérifier les mises à jour")
            }

            when (val result = checkResult) {
                is UpdateCheckResult.UpToDate -> Text("Tu as déjà la dernière version.", color = AgwColors.GoldSoft)
                is UpdateCheckResult.Error -> Text("Impossible de vérifier : ${result.message}", color = AgwColors.DriedBlood)
                is UpdateCheckResult.UpdateAvailable -> UpdateAvailableCard(
                    info = result.info,
                    downloadState = downloadState,
                    onDownload = {
                        downloadState = DownloadState.Downloading
                        scope.launch {
                            val id = updateManager.startDownload(result.info.apkUrl)
                            downloadState = updateManager.awaitDownload(id)
                        }
                    },
                    onInstall = { file -> updateManager.installApk(file) }
                )
                null -> {}
            }

            Spacer(Modifier.weight(1f))
            Text(
                "Correctifs 0.6.5 : versionCode stable, téléchargement dans fichiers app, suivi DownloadManager, messages d'erreur clairs.",
                style = MaterialTheme.typography.bodySmall,
                color = AgwColors.Sand
            )
        }
    }
}

@Composable
private fun UpdateAvailableCard(
    info: UpdateInfo,
    downloadState: DownloadState,
    onDownload: () -> Unit,
    onInstall: (java.io.File) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Nouvelle version : ${info.versionName}", style = MaterialTheme.typography.titleMedium, color = AgwColors.SacredGold)
            if (info.notes.isNotBlank()) Text(info.notes, style = MaterialTheme.typography.bodyMedium, color = AgwColors.PaleMarble)

            when (val s = downloadState) {
                is DownloadState.Idle -> Button(onClick = onDownload) { Text("Télécharger") }
                is DownloadState.Downloading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = AgwColors.SacredGold)
                    Spacer(Modifier.width(8.dp))
                    Text("Téléchargement...", color = AgwColors.Sand)
                }
                is DownloadState.ReadyToInstall -> Button(onClick = { onInstall(s.apkFile) }) {
                    Text("Installer maintenant")
                }
                is DownloadState.Failed -> Text("Échec : ${s.message}", color = AgwColors.DriedBlood)
            }
        }
    }
}
