package com.sbh.studio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.sbh.studio.data.*
import com.sbh.studio.generator.PackGenerator
import com.sbh.studio.ui.UpdateScreen
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { SbhStudioApp() } }
}

private sealed class Screen { data object Home: Screen(); data class Project(val id:String): Screen(); data class Mob(val projectId:String,val id:String?): Screen(); data class Item(val projectId:String,val id:String?): Screen(); data class Block(val projectId:String,val id:String?): Screen(); data object MineEdit: Screen(); data object Update: Screen() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun SbhStudioApp() {
    val context = LocalContext.current
    val projectRepo = remember { ProjectRepository(context) }; val mobRepo = remember { MobRepository(context) }; val itemRepo = remember { ItemRepository(context) }; val blockRepo = remember { BlockRepository(context) }
    var projects by remember { mutableStateOf(projectRepo.load().ifEmpty { listOf(SbhProject(name="SBh Test 01")) }) }
    var mobs by remember { mutableStateOf(mobRepo.loadAll()) }; var items by remember { mutableStateOf(itemRepo.loadAll()) }; var blocks by remember { mutableStateOf(blockRepo.loadAll()) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }; var message by remember { mutableStateOf("Studio prêt. Les opérations destructives restent bloquées par défaut.") }; var dialog by remember { mutableStateOf<String?>(null) }
    fun saveProjects(v:List<SbhProject>){projects=v;projectRepo.save(v)}; fun saveMobs(v:List<MobEntity>){mobs=v;mobRepo.saveAll(v)}; fun saveItems(v:List<SbhItem>){items=v;itemRepo.saveAll(v)}; fun saveBlocks(v:List<SbhBlock>){blocks=v;blockRepo.saveAll(v)}
    fun export(project:SbhProject){
        val pm=mobs.filter{it.projectId==project.id}; val pi=items.filter{it.projectId==project.id}; val pb=blocks.filter{it.projectId==project.id}; val errors=PackGenerator(context).validate(project,pm,pi,pb)
        if(errors.isNotEmpty()){dialog=errors.joinToString("\n");return}
        runCatching { PackGenerator(context).export(project,pm,pi,pb) }.onSuccess { file ->
            val uri=FileProvider.getUriForFile(context,"com.sbh.studio.fileprovider",file); context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/octet-stream";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Exporter ${file.name}")); message="Export réussi : ${file.name}"
        }.onFailure{dialog="Export impossible : ${it.message}"}
    }
    MaterialTheme {
        when(val s=screen){
            Screen.Home->Home(projects,mobs,items,blocks,message,{val n=projects.size+1;saveProjects(projects+SbhProject(name="Nouveau projet $n"));message="Projet créé."},{screen=Screen.MineEdit},{screen=Screen.Update},{project->screen=Screen.Project(project.id)},{project->saveProjects(projects.map{if(it.id==project.id)it.copy(status="Sauvegardé",versionHistory=it.versionHistory+"v${it.versionHistory.size+1} — sauvegarde")else it});message="Projet sauvegardé."})
            is Screen.Project->{val p=projects.find{it.id==s.id}; if(p==null)screen=Screen.Home else ProjectDetail(p,mobs.filter{it.projectId==p.id},items.filter{it.projectId==p.id},blocks.filter{it.projectId==p.id},{screen=Screen.Home},{screen=Screen.Mob(p.id,null)},{screen=Screen.Item(p.id,null)},{screen=Screen.Block(p.id,null)},{m->saveMobs(mobs-m)},{i->saveItems(items-i)},{b->saveBlocks(blocks-b)},{export(p)})}
            is Screen.Mob->{MobEditor(s.projectId,mobs.find{it.id==s.id},{screen=Screen.Project(s.projectId)},{m->saveMobs(if(s.id==null)mobs+m else mobs.map{if(it.id==m.id)m else it});screen=Screen.Project(s.projectId)})}
            is Screen.Item->{ItemEditor(s.projectId,items.find{it.id==s.id},{screen=Screen.Project(s.projectId)},{i->saveItems(if(s.id==null)items+i else items.map{if(it.id==i.id)i else it});screen=Screen.Project(s.projectId)})}
            is Screen.Block->{BlockEditor(s.projectId,blocks.find{it.id==s.id},{screen=Screen.Project(s.projectId)},{b->saveBlocks(if(s.id==null)blocks+b else blocks.map{if(it.id==b.id)b else it});screen=Screen.Project(s.projectId)})}
            Screen.MineEdit->MineEdit({screen=Screen.Home},{message=it})
            Screen.Update->UpdateScreen{screen=Screen.Home}
        }
        dialog?.let{d->AlertDialog(onDismissRequest={dialog=null},confirmButton={TextButton({dialog=null}){Text("Fermer")}},title={Text("Contrôle SBh Studio")},text={Text(d)})}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun Home(projects:List<SbhProject>,mobs:List<MobEntity>,items:List<SbhItem>,blocks:List<SbhBlock>,message:String,newProject:()->Unit,mine:()->Unit,update:()->Unit,open:(SbhProject)->Unit,save:(SbhProject)->Unit){
    Scaffold(topBar={TopAppBar(title={Text("SBh Studio",fontWeight=FontWeight.Bold)},actions={TextButton(update){Text("Mise à jour")}})}){pad->LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text("SBh STUDIO 0.6",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Atelier Bedrock : création, génération et export .mcaddon.");Text(message,style=MaterialTheme.typography.bodySmall)}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(newProject,Modifier.weight(1f)){Text("+ Projet")};OutlinedButton(mine,Modifier.weight(1f)){Text("Mine Edit")}}}
        item{Text("${projects.size} projet(s) · ${mobs.size} mob(s) · ${items.size} item(s) · ${blocks.size} bloc(s)",fontWeight=FontWeight.Medium)}
        items(projects,key={it.id}){p->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.version} · ${p.status}",style=MaterialTheme.typography.bodySmall);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({save(p)}){Text("Sauvegarder")};Button({open(p)}){Text("Ouvrir")}}}}}
    }}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun ProjectDetail(p:SbhProject,mobs:List<MobEntity>,items:List<SbhItem>,blocks:List<SbhBlock>,back:()->Unit,newMob:()->Unit,newItem:()->Unit,newBlock:()->Unit,delMob:(MobEntity)->Unit,delItem:(SbhItem)->Unit,delBlock:(SbhBlock)->Unit,export:()->Unit){
    Scaffold(topBar={TopAppBar(title={Text(p.name)},navigationIcon={TextButton(back){Text("←")}})}){pad->Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Création",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Construis tes éléments puis exporte le pack.")
        Button(newMob,Modifier.fillMaxWidth()){Text("+ Créature")}; Button(newItem,Modifier.fillMaxWidth()){Text("+ Item")}; Button(newBlock,Modifier.fillMaxWidth()){Text("+ Bloc")}; Button(export,Modifier.fillMaxWidth()){Text("📦 Générer le .mcaddon")}
        Text("Créatures",fontWeight=FontWeight.Bold); mobs.forEach{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(it.nom);Text(it.identifiant,style=MaterialTheme.typography.bodySmall)};TextButton({delMob(it)}){Text("Supprimer")}}}
        Text("Items",fontWeight=FontWeight.Bold);items.forEach{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(it.name);Text(it.identifier,style=MaterialTheme.typography.bodySmall)};TextButton({delItem(it)}){Text("Supprimer")}}}
        Text("Blocs",fontWeight=FontWeight.Bold);blocks.forEach{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(it.name);Text(it.identifier,style=MaterialTheme.typography.bodySmall)};TextButton({delBlock(it)}){Text("Supprimer")}}}
    }}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun MobEditor(projectId:String,existing:MobEntity?,back:()->Unit,save:(MobEntity)->Unit){
    val context = LocalContext.current; var name by remember{mutableStateOf(existing?.nom?:("Nouvelle créature"))};var id by remember{mutableStateOf(existing?.identifiant?:"sbh:nouvelle_creature")};var hp by remember{mutableStateOf((existing?.vie?:20).toString())};var speed by remember{mutableStateOf((existing?.vitesse?:0.25).toString())};var dmg by remember{mutableStateOf((existing?.degats?:3).toString())};var hostile by remember{mutableStateOf(existing?.hostile?:false)};var attack by remember{mutableStateOf(existing?.attaque?:false)};var pursuit by remember{mutableStateOf(existing?.poursuite?:false)};var react by remember{mutableStateOf(existing?.reactionDegats?:true)};var texture by remember{mutableStateOf(existing?.textureUri)}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u:Uri?->if(u!=null){runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) };texture=u.toString()}}
    Scaffold(topBar={TopAppBar(title={Text("Créature")},navigationIcon={TextButton(back){Text("←")}})}){pad->Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){Field("Nom",name){name=it};Field("Identifiant namespace:id",id){id=it};TripleFields(hp,speed,dmg,{hp=it},{speed=it},{dmg=it});Check("Hostile",hostile){hostile=it};Check("Poursuite",pursuit){pursuit=it};Check("Attaque",attack){attack=it};Check("Réaction aux dégâts",react){react=it};OutlinedButton({picker.launch(arrayOf("image/png","image/jpeg"))},Modifier.fillMaxWidth()){Text(if(texture==null)"Choisir une texture PNG/JPG" else "Texture sélectionnée")};Button({save(MobEntity(existing?.id?:java.util.UUID.randomUUID().toString(),projectId,name,id,hp.toIntOrNull()?:20,speed.toDoubleOrNull()?:0.25,dmg.toIntOrNull()?:3,hostile,pursuit,attack,react,textureUri=texture,versionHistory=(existing?.versionHistory?:listOf("v1 — création de la créature"))+"v${(existing?.versionHistory?.size?:1)+1} — sauvegarde"))},Modifier.fillMaxWidth()){Text("Enregistrer")}}}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun ItemEditor(projectId:String,existing:SbhItem?,back:()->Unit,save:(SbhItem)->Unit){val context = LocalContext.current; var n by remember{mutableStateOf(existing?.name?:"Nouvel item")};var id by remember{mutableStateOf(existing?.identifier?:"sbh:nouvel_item")};var d by remember{mutableStateOf((existing?.damage?:0).toString())};var dur by remember{mutableStateOf((existing?.durability?:100).toString())};var tex by remember{mutableStateOf(existing?.textureUri)};val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null){runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) };tex=u.toString()}};SimpleEditor("Item",back,{Field("Nom",n){n=it};Field("Identifiant namespace:id",id){id=it};Field("Dégâts",d){d=it};Field("Durabilité",dur){dur=it};OutlinedButton({picker.launch(arrayOf("image/png","image/jpeg"))},Modifier.fillMaxWidth()){Text(if(tex==null)"Choisir une texture" else "Texture sélectionnée")};Button({save(SbhItem(existing?.id?:java.util.UUID.randomUUID().toString(),projectId,n,id,d.toIntOrNull()?:0,dur.toIntOrNull()?:100,tex))},Modifier.fillMaxWidth()){Text("Enregistrer")}})}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun BlockEditor(projectId:String,existing:SbhBlock?,back:()->Unit,save:(SbhBlock)->Unit){val context = LocalContext.current; var n by remember{mutableStateOf(existing?.name?:"Nouveau bloc")};var id by remember{mutableStateOf(existing?.identifier?:"sbh:nouveau_bloc")};var h by remember{mutableStateOf((existing?.hardness?:1.0).toString())};var tex by remember{mutableStateOf(existing?.textureUri)};val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null){runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) };tex=u.toString()}};SimpleEditor("Bloc",back,{Field("Nom",n){n=it};Field("Identifiant namespace:id",id){id=it};Field("Résistance/destruction",h){h=it};OutlinedButton({picker.launch(arrayOf("image/png","image/jpeg"))},Modifier.fillMaxWidth()){Text(if(tex==null)"Choisir une texture" else "Texture sélectionnée")};Button({save(SbhBlock(existing?.id?:java.util.UUID.randomUUID().toString(),projectId,n,id,h.toDoubleOrNull()?:1.0,tex))},Modifier.fillMaxWidth()){Text("Enregistrer")}})}

@Composable private fun SimpleEditor(title:String,back:()->Unit,body:@Composable ColumnScope.()->Unit){Scaffold(topBar={TopAppBar(title={Text(title)},navigationIcon={TextButton(back){Text("←")}})}){pad->Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp),content=body)}}
@Composable private fun Field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth())}
@Composable private fun TripleFields(a:String,b:String,c:String,aa:(String)->Unit,bb:(String)->Unit,cc:(String)->Unit){Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(a,aa,label={Text("Vie")},modifier=Modifier.weight(1f));OutlinedTextField(b,bb,label={Text("Vitesse")},modifier=Modifier.weight(1f));OutlinedTextField(c,cc,label={Text("Dégâts")},modifier=Modifier.weight(1f))}}
@Composable private fun Check(label:String,value:Boolean,on:(Boolean)->Unit){Row(verticalAlignment=Alignment.CenterVertically){Checkbox(value,on);Text(label)}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MineEdit(back: () -> Unit, message: (String) -> Unit) {
    var x1 by remember { mutableStateOf("0") }
    var y1 by remember { mutableStateOf("64") }
    var z1 by remember { mutableStateOf("0") }
    var x2 by remember { mutableStateOf("10") }
    var y2 by remember { mutableStateOf("70") }
    var z2 by remember { mutableStateOf("10") }
    var confirm by remember { mutableStateOf(false) }

    val values = listOf(x1, y1, z1, x2, y2, z2).map { it.toLongOrNull() }
    val valid = values.all { it != null }
    val width = if (valid) kotlin.math.abs(x2.toLong() - x1.toLong()) + 1 else 0
    val height = if (valid) kotlin.math.abs(y2.toLong() - y1.toLong()) + 1 else 0
    val depth = if (valid) kotlin.math.abs(z2.toLong() - z1.toLong()) + 1 else 0
    val volume = if (valid) width * height * depth else 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mine Edit") },
                navigationIcon = { TextButton(back) { Text("←") } }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text(
                "Sélection sécurisée",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Deux positions définissent la zone. La v0.6 valide et prépare le flux sans modifier directement un monde."
            )
            Text("Position 1", fontWeight = FontWeight.Bold)
            TripleFields(x1, y1, z1, { x1 = it }, { y1 = it }, { z1 = it })
            Text("Position 2", fontWeight = FontWeight.Bold)
            TripleFields(x2, y2, z2, { x2 = it }, { y2 = it }, { z2 = it })
            Card(Modifier.fillMaxWidth()) {
                Text(
                    if (valid) "Volume : $width × $height × $depth = $volume blocs\nSélection normalisée min/max."
                    else "Coordonnées invalides.",
                    Modifier.padding(14.dp)
                )
            }
            Button(
                onClick = { confirm = true },
                enabled = valid,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Valider avant opération")
            }
            Text(
                "Tests prévus : NORMAL · ÉCHEC · INTERMÉDIAIRE",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Confirmation requise") },
            text = {
                Text(
                    "$volume blocs seraient concernés. Aucune modification destructive n'est exécutée dans cette version."
                )
            },
            confirmButton = {
                Button(onClick = {
                    confirm = false
                    message("Sélection Mine Edit validée : $volume blocs.")
                }) {
                    Text("Confirmer")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) {
                    Text("Annuler")
                }
            }
        )
    }
}
