package com.sbh.studio.workshop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.SectionTitle
import java.util.UUID

/**
 * Zone Recettes — atelier libre unifié (phase B).
 * Liste + recherche + édition / duplication + grille avec picker projet.
 */
@Composable
internal fun RecipeZone(
    projectId: String,
    recipes: List<RecipeBlueprint>,
    items: List<SbhItem>,
    blocks: List<SbhBlock> = emptyList(),
    onSave: (RecipeBlueprint) -> Unit,
    onDelete: (RecipeBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var filterType by rememberSaveable { mutableStateOf("all") }
    var tab by rememberSaveable { mutableStateOf(0) }
    var pickCell by rememberSaveable { mutableStateOf<Int?>(null) } // 0..8 grille, -1 résultat

    var name by rememberSaveable { mutableStateOf("Nouvelle recette") }
    var identifier by rememberSaveable { mutableStateOf("agw:recipe_custom") }
    var type by rememberSaveable { mutableStateOf("minecraft:recipe_shaped") }
    var resultId by rememberSaveable { mutableStateOf("agw:item_custom") }
    var resultCount by rememberSaveable { mutableStateOf("1") }
    var c0 by rememberSaveable { mutableStateOf("") }
    var c1 by rememberSaveable { mutableStateOf("") }
    var c2 by rememberSaveable { mutableStateOf("") }
    var c3 by rememberSaveable { mutableStateOf("") }
    var c4 by rememberSaveable { mutableStateOf("") }
    var c5 by rememberSaveable { mutableStateOf("") }
    var c6 by rememberSaveable { mutableStateOf("") }
    var c7 by rememberSaveable { mutableStateOf("") }
    var c8 by rememberSaveable { mutableStateOf("") }
    var ingredientsText by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }

    fun cells(): List<String> = listOf(c0, c1, c2, c3, c4, c5, c6, c7, c8)
    fun setCell(i: Int, v: String) {
        when (i) {
            0 -> c0 = v; 1 -> c1 = v; 2 -> c2 = v; 3 -> c3 = v; 4 -> c4 = v
            5 -> c5 = v; 6 -> c6 = v; 7 -> c7 = v; 8 -> c8 = v
        }
    }

    fun reset() {
        editingId = null
        name = "Nouvelle recette"; identifier = "agw:recipe_custom"
        type = "minecraft:recipe_shaped"; resultId = "agw:item_custom"; resultCount = "1"
        c0 = ""; c1 = ""; c2 = ""; c3 = ""; c4 = ""; c5 = ""; c6 = ""; c7 = ""; c8 = ""
        ingredientsText = ""; notes = ""; tab = 0; pickCell = null
    }

    fun load(r: RecipeBlueprint) {
        editingId = r.id; name = r.name; identifier = r.identifier; type = r.type
        resultId = r.resultId; resultCount = r.resultCount.toString(); notes = r.notes
        val p = r.pattern + List(9) { "" }
        c0 = p[0]; c1 = p[1]; c2 = p[2]; c3 = p[3]; c4 = p[4]; c5 = p[5]; c6 = p[6]; c7 = p[7]; c8 = p[8]
        ingredientsText = r.ingredients.joinToString(", ")
        tab = 0; pickCell = null
    }

    fun build(keepId: String? = editingId): RecipeBlueprint = RecipeBlueprint(
        id = keepId ?: UUID.randomUUID().toString(),
        projectId = projectId,
        name = name.trim().ifBlank { "Recette" },
        identifier = identifier.trim().ifBlank { "agw:recipe_custom" },
        type = type,
        resultId = resultId.trim().ifBlank { "agw:item_custom" },
        resultCount = resultCount.toIntOrNull()?.coerceIn(1, 64) ?: 1,
        pattern = cells(),
        ingredients = ingredientsText.split(",", ";", "\n").map { it.trim() }.filter { it.isNotEmpty() },
        notes = notes.trim()
    )

    val catalogIds = remember(items, blocks) {
        (items.map { it.identifier to it.name } + blocks.map { it.identifier to it.name })
            .distinctBy { it.first }
    }

    val filtered = remember(recipes, search, filterType) {
        recipes.filter { r ->
            val q = search.trim().lowercase()
            val matchQ = q.isEmpty() || r.name.lowercase().contains(q) ||
                r.identifier.lowercase().contains(q) || r.resultId.lowercase().contains(q)
            val matchT = filterType == "all" || r.type.contains(filterType)
            matchQ && matchT
        }
    }

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
    ) {
        SectionTitle("Recettes de craft")
        Text(
            "${recipes.size} recette(s) · atelier libre — grille + items du projet",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        WorkshopSearchField(search, { search = it }, "Rechercher (nom, id, résultat)")
        WorkshopFilterRow(
            listOf(
                "all" to "Toutes",
                "shaped" to "Shaped",
                "shapeless" to "Shapeless",
                "furnace" to "Four"
            ),
            filterType
        ) { filterType = it }

        Text("Liste (${filtered.size})", fontWeight = FontWeight.SemiBold, color = AgwColors.SacredGold)
        if (filtered.isEmpty()) {
            Text("Aucune recette. Crée-en une ci-dessous.", color = AgwColors.Sand)
        } else {
            filtered.forEach { r ->
                WorkshopListCard(
                    title = r.name,
                    subtitle = "${r.identifier} · ${r.type.substringAfterLast(':')} → ${r.resultId} ×${r.resultCount}",
                    extra = r.notes.takeIf { it.isNotBlank() },
                    selected = r.id == editingId,
                    onClick = { load(r) },
                    onDelete = { if (editingId == r.id) reset(); onDelete(r) }
                )
            }
        }

        HorizontalDivider(color = AgwColors.Sand.copy(alpha = 0.3f))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (editingId == null) "Nouvelle recette" else "Modifier la recette",
                    fontWeight = FontWeight.SemiBold,
                    color = AgwColors.SacredGold
                )
                WorkshopTabRow(listOf("Identité", "Grille", "Aperçu", "Notes"), tab) { tab = it }

                when (tab) {
                    0 -> {
                        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text("Type", color = AgwColors.Sand, fontSize = 12.sp)
                        WorkshopFilterRow(
                            listOf(
                                "minecraft:recipe_shaped" to "Shaped",
                                "minecraft:recipe_shapeless" to "Shapeless",
                                "minecraft:recipe_furnace" to "Four"
                            ),
                            type
                        ) { type = it }
                        OutlinedTextField(resultId, { resultId = it }, label = { Text("Résultat (id)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(resultCount, { resultCount = it }, label = { Text("Quantité") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        WorkshopIdPickerRow(
                            "Résultat depuis le projet",
                            catalogIds,
                            resultId
                        ) { resultId = it }
                    }
                    1 -> {
                        if (type.contains("shapeless")) {
                            OutlinedTextField(
                                ingredientsText,
                                { ingredientsText = it },
                                label = { Text("Ingrédients (ids séparés par virgule)") },
                                minLines = 2,
                                modifier = Modifier.fillMaxWidth()
                            )
                            WorkshopIdPickerRow("Ajouter un ingrédient projet", catalogIds, "") { id ->
                                ingredientsText = if (ingredientsText.isBlank()) id else "$ingredientsText, $id"
                            }
                        } else {
                            Text("Toucher une case puis choisir un item/bloc du projet", color = AgwColors.Sand, fontSize = 12.sp)
                            RecipeEditableGrid(
                                cells = cells(),
                                selected = pickCell,
                                onSelect = { pickCell = it }
                            )
                            if (pickCell != null) {
                                Text("Case ${(pickCell ?: 0) + 1} — choisir :", color = AgwColors.DesertOchre, fontSize = 12.sp)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.horizontalScroll(rememberScrollState())
                                ) {
                                    FilterChip(
                                        selected = false,
                                        onClick = {
                                            setCell(pickCell!!, "")
                                            pickCell = null
                                        },
                                        label = { Text("Vider", fontSize = 11.sp) }
                                    )
                                    catalogIds.take(40).forEach { (id, n) ->
                                        FilterChip(
                                            selected = cells().getOrNull(pickCell ?: -1) == id,
                                            onClick = {
                                                setCell(pickCell!!, id)
                                                pickCell = null
                                            },
                                            label = { Text((n.ifBlank { id }).take(14), fontSize = 11.sp) }
                                        )
                                    }
                                }
                                OutlinedTextField(
                                    cells().getOrElse(pickCell ?: 0) { "" },
                                    { setCell(pickCell ?: 0, it) },
                                    label = { Text("Ou saisir l'id à la main") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                    2 -> {
                        RecipeGridPreview(cells(), resultId, resultCount.toIntOrNull() ?: 1)
                        Text(
                            if (type.contains("shapeless")) "Shapeless : ${ingredientsText.ifBlank { "—" }}"
                            else "Shaped 3×3 → $resultId ×${resultCount}",
                            color = AgwColors.Sand,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    3 -> {
                        OutlinedTextField(
                            notes,
                            { notes = it },
                            label = { Text("Notes libres") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                WorkshopEditorActions(
                    isEditing = editingId != null,
                    onSave = {
                        onSave(build())
                        if (editingId == null) reset()
                    },
                    onDuplicate = {
                        onSave(
                            build(null).copy(
                                name = "$name (copie)",
                                identifier = workshopIdCopy(identifier.trim())
                            )
                        )
                    },
                    onNew = { reset() }
                )
            }
        }
    }
}

@Composable
private fun RecipeEditableGrid(
    cells: List<String>,
    selected: Int?,
    onSelect: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (row in 0 until 3) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (col in 0 until 3) {
                    val idx = row * 3 + col
                    val cell = cells.getOrElse(idx) { "" }
                    val isSel = selected == idx
                    Box(
                        Modifier
                            .size(48.dp)
                            .background(
                                if (cell.isBlank()) Color(0xFF1A1F28) else Color(0xFF2A3544),
                                RoundedCornerShape(6.dp)
                            )
                            .border(
                                if (isSel) 2.dp else 1.dp,
                                if (isSel) AgwColors.SacredGold else AgwColors.GoldSoft.copy(alpha = 0.4f),
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { onSelect(idx) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (cell.isNotBlank()) {
                            Text(cell.substringAfterLast(':').take(6), color = AgwColors.PaleMarble, fontSize = 9.sp, maxLines = 1)
                        } else {
                            Text("·", color = AgwColors.Sand, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecipeGridPreview(pattern: List<String>, resultId: String, resultCount: Int) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (row in 0 until 3) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (col in 0 until 3) {
                        val idx = row * 3 + col
                        val cell = pattern.getOrElse(idx) { "" }
                        Box(
                            Modifier
                                .size(28.dp)
                                .background(if (cell.isBlank()) Color(0xFF1A1F28) else Color(0xFF2A3544), RoundedCornerShape(4.dp))
                                .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.4f), RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (cell.isNotBlank()) {
                                Text(cell.takeLast(3), color = AgwColors.PaleMarble, fontSize = 7.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        Text("→", color = AgwColors.SacredGold, fontSize = 20.sp)
        Box(
            Modifier
                .size(40.dp)
                .background(Color(0xFF2A3544), RoundedCornerShape(6.dp))
                .border(1.dp, AgwColors.SacredGold, RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(resultId.takeLast(4), color = AgwColors.PaleMarble, fontSize = 8.sp, maxLines = 1)
                if (resultCount > 1) Text("×$resultCount", color = AgwColors.SacredGold, fontSize = 9.sp)
            }
        }
    }
}
