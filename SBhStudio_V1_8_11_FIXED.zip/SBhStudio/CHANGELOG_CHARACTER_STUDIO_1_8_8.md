# SBh Studio V1.8.8 — Character Studio Étape 6

## Moteur de génération et contrat Image→3D

- ajout d'un catalogue de moteurs local / distant
- choix du moteur dans Character Studio
- paramètres de génération : style, niveau de détail, qualité textures, textures et squelette
- création centralisée de `CharacterGenerationRequest`
- garde-fou : le moteur distant ne lance aucun réseau tant qu'il n'est pas configuré
- le générateur local existant reste opérationnel
- préparation de l'architecture pour brancher un véritable backend Image→3D

## Validation

Le validateur statique SBh doit rester à 0 erreur / 0 avertissement.
