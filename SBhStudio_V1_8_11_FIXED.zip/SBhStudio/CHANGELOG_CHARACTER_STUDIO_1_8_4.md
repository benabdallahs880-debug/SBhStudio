# SBh Studio V1.8.4 — Character Studio Étape 2

## Prévisualisation 3D réelle

- Ajout de SceneView/Filament pour rendre les modèles 3D dans l'Atelier.
- Support de prévisualisation GLB/GLTF importé depuis le sélecteur Android.
- Conservation de l'URI `content://` avec permission de lecture persistante lorsque le fournisseur Android le permet.
- Caméra orbitale tactile : rotation, zoom et déplacement via le contrôleur de caméra 3D.
- Éclairage principal pour éviter un viewport noir.
- Modèle mannequin GLB léger embarqué comme aperçu de secours lorsqu'aucun modèle n'est encore importé.
- Inspecteur Character Studio affichant modèle, format, rig et état d'animation.
- Séparation maintenue entre géométrie du personnage et rigging : aucun squelette n'est imposé à cette étape.

## Validation

- `tools/validate_sbh.py` : 0 erreur, 0 avertissement.
- Compilation Gradle non exécutée ici : le runner ne peut pas télécharger `gradle-8.11.1-bin.zip` car l'accès réseau externe est indisponible dans cet environnement.
