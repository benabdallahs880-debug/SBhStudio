# SBh Studio — Améliorations نشيد (Audio)

## Contenu de cette version

### Écran نشيد (onglet ♫)
- Lecteur audio intégré (play / pause / stop + barre de progression)
- Import de fichiers (ogg, mp3, m4a, wav…)
- Bibliothèque locale avec suppression
- Choix d’événement Minecraft (music.game, music.menu, disques, ambiance, custom)
- Toggle « Pack » pour inclusion à l’export
- Rappel coranique et accès app Coran conservés

### Zone Sons dans le Workshop (par projet)
- Nouvelle zone **Sons / نشيد** dans l’atelier
- Import lié au projet ouvert
- Gestion Pack / Événement / Suppression
- Compteurs sur le Hub et l’Export

### Export Resource Pack Minecraft
- Génération de `sounds/sound_definitions.json`
- Fichiers audio sous `sounds/sbh/`
- Remplacement possible de la musique de jeu (music.game, etc.)
- Avertissement si un son n’est pas en Ogg

### Conversion automatique → Ogg
- `AudioOggConverter` : Ogg natif, FFmpegKit, ou ffmpeg système
- Dépendance : `com.arthenica:retiré (plus sur Maven)`
  (à commenter dans `app/build.gradle.kts` si résolution Maven impossible)

## Fichiers principaux
- `data/SoundModels.kt`
- `data/SoundRepository.kt`
- `data/AudioOggConverter.kt`
- `ui/AudioStudioScreen.kt`
- `workshop/WorkshopModels.kt` (zone SOUNDS)
- `workshop/WorkshopScreen.kt` (SoundZone)
- `generator/AdvancedPackEngine.kt`
- `app/build.gradle.kts`

## Build
```bash
./gradlew assembleDebug
```

## V1.8.3 — Character Studio · Étape 1
- Ajout d’un espace Character Studio dans l’Atelier.
- Ajout des projets personnage persistants.
- Import d’une image de référence comme première étape du pipeline.
- Préparation des états modèle/rig/animation sans imposer de squelette.
