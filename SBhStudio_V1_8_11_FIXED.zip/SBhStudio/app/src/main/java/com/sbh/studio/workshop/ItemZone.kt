package com.sbh.studio.workshop

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sbh.studio.data.SbhItem
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors

@Composable
internal fun ItemZone(
    projectId: String,
    items: List<SbhItem>,
    textures: List<TextureProject> = emptyList(),
    onAdd: (SbhItem) -> Unit,
    onDelete: (SbhItem) -> Unit
) {
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("Nouvel item") }
    var id by rememberSaveable { mutableStateOf("agw:nouvel_item") }
    var dmg by rememberSaveable { mutableStateOf("0") }
    var dur by rememberSaveable { mutableStateOf("100") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Objets & armes", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(dur, { dur = it }, label = { Text("Durabilité") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Fichier image externe" else if (tex!!.startsWith("sbhtex://")) "Texture Studio liée ✓" else "Fichier externe ✓")
        }
        StudioTexturePicker(
            textures = textures,
            selectedUri = tex,
            onSelect = { tex = it },
            preferredFormats = listOf("BLOCK_16", "BLOCK_32", "FILTER_MAP")
        )
        Button(
            onClick = {
                onAdd(SbhItem(projectId = projectId, name = name, identifier = id, damage = dmg.toIntOrNull() ?: 0, durability = dur.toIntOrNull() ?: 100, textureUri = tex))
                tex = null
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Ajouter l'item") }

        items.forEach { i ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(i.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${i.identifier} · DMG ${i.damage} · Dur ${i.durability}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(i) }) { Text("X") }
                }
            }
        }
        if (items.isEmpty()) Text("Aucun item pour ce projet.", color = AgwColors.Sand)
    }
}
