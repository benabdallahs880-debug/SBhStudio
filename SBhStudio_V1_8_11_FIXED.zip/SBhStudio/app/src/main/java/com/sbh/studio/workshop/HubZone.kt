package com.sbh.studio.workshop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldDivider
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.ModeIconTile
import com.sbh.studio.ui.SectionTitle

@Composable
internal fun HubZone(
    onSelect: (WorkshopZoneId) -> Unit,
    mobCount: Int,
    portalCount: Int,
    mapCount: Int,
    itemCount: Int,
    blockCount: Int,
    recipeCount: Int,
    soundCount: Int = 0,
    entityCount: Int = 0,
    gameBuilderCount: Int = 0,
    maps: List<MapBlueprint>,
    portals: List<PortalBlueprint>,
    mobs: List<MobEntity>,
    items: List<SbhItem>,
    blocks: List<SbhBlock>,
    recipes: List<RecipeBlueprint>,
    textures: List<TextureProject>,
    onImportAgw: () -> Unit,
    onGenerateFoundation: () -> Unit,
    onApplyTemplate: (WorkshopTemplate) -> Unit,
    agwWorldName: String = "Al-Zahra",
    agwFactionCount: Int = 0,
    agwNodeCount: Int = 0,
    validation: HubValidationSummary = HubValidationSummary(0, 0),
    onOpenExport: () -> Unit = {},
    onComingSoon: (String) -> Unit = {}
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        SectionTitle("Monde AGW · $agwWorldName")
        Text("World Core : $agwNodeCount nœud(s) · $agwFactionCount faction(s) · synchronisé avec l'Atelier", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)

        HubValidationBadge(summary = validation, onOpenExport = onOpenExport)

        GoldDivider(Modifier.padding(bottom = 6.dp))
        WorkshopConnectionPanel(
            maps = maps,
            portals = portals,
            mobs = mobs,
            items = items,
            blocks = blocks,
            recipes = recipes,
            textures = textures
        )

        GoldDivider(Modifier.padding(bottom = 6.dp))
        SectionTitle("Zones de l'atelier")
        GoldDivider(Modifier.padding(bottom = 6.dp))
        // Tuiles icônées par zone
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Mobs ($mobCount)", "branding/icons/icon_mobs.png", { onSelect(WorkshopZoneId.MOBS) }, Modifier.weight(1f))
                ModeIconTile("Portails ($portalCount)", "branding/icons/icon_portals.png", { onSelect(WorkshopZoneId.PORTALS) }, Modifier.weight(1f))
                ModeIconTile("Maps ($mapCount)", "branding/icons/icon_map.png", { onSelect(WorkshopZoneId.MAPS) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Items ($itemCount)", "branding/icons/icon_items.png", { onSelect(WorkshopZoneId.ITEMS) }, Modifier.weight(1f))
                ModeIconTile("Blocs ($blockCount)", "branding/icons/icon_blocks.png", { onSelect(WorkshopZoneId.BLOCKS) }, Modifier.weight(1f))
                ModeIconTile("Recettes ($recipeCount)", "branding/icons/icon_items.png", { onSelect(WorkshopZoneId.RECIPES) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Sons / نشيد ($soundCount)", "branding/icons/icon_export.png", { onSelect(WorkshopZoneId.SOUNDS) }, Modifier.weight(1f))
                ModeIconTile("Entités 3D ($entityCount)", "branding/icons/icon_items.png", { onSelect(WorkshopZoneId.ENTITIES) }, Modifier.weight(1f))
                ModeIconTile("Character Studio", "branding/icons/icon_mobs.png", { onSelect(WorkshopZoneId.CHARACTER_STUDIO) }, Modifier.weight(1f))
                ModeIconTile("Game Builder ($gameBuilderCount)", "branding/icons/icon_map.png", { onSelect(WorkshopZoneId.GAME_BUILDER) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeIconTile("Export", "branding/icons/icon_export.png", { onSelect(WorkshopZoneId.EXPORT) }, Modifier.weight(1f))
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(4.dp))
        SectionTitle("Templates prêts à l'emploi")
        GoldDivider(Modifier.padding(bottom = 6.dp))
        Text(
            "Applique un set cohérent (map + portail + contenus) en un clic. Les éléments sont ajoutés au projet courant.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        val templates = listOf(
            WorkshopTemplate("desert_gothic", "Désert Gothique", "Map désert + portail + 2 mobs + 1 item", "desert_gothic", 0xFFC9A227),
            WorkshopTemplate("oasis", "Oasis Vivante", "Map oasis + village + portail + recettes", "oasis", 0xFF3D6B45),
            WorkshopTemplate("forteresse", "Forteresse Noire", "Map montagne + donjon + mobs hostiles", "fortress", 0xFF5A5550),
            WorkshopTemplate("route_caravane", "Route des Caravanes", "Map routes + commerce + portails liés", "caravan", 0xFFE0A458)
        )
        templates.chunked(2).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { t ->
                    GlassCard(modifier = Modifier.weight(1f).clickable { onApplyTemplate(t) }) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(t.name, fontWeight = FontWeight.Bold, color = Color(t.iconColor))
                            Text(t.description, color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(4.dp))
        SectionTitle("Bientôt disponible")
        GoldDivider(Modifier.padding(bottom = 6.dp))
        Text(
            "Ces catégories sont prévues mais pas encore fonctionnelles — pas de faux bouton qui ne mène nulle part, juste l'ampleur de ce qui reste à construire.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        val comingSoon = listOf(
            "Biomes", "Fonctions", "Projectiles",
            "Structures", "Dimensions", "Particules", "Commerce",
            "Dialogues PNJ", "Nature", "Interface", "Machines"
        )
        comingSoon.chunked(3).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { label ->
                    ModeIconTile(
                        label = label,
                        iconAsset = "branding/icons/icon_soon.png", // pas d'asset dédié -> repli automatique sur ◆
                        onClick = { onComingSoon(label) },
                        modifier = Modifier.weight(1f),
                        subtitle = "Bientôt",
                        enabled = false
                    )
                }
                // Complète la ligne si elle a moins de 3 éléments, pour garder l'alignement.
                Spacer(Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(8.dp))
        SectionTitle("Minimap de l'atelier")
        Text(
            "Vue vivante du projet : les cartes et portails enregistrés apparaissent directement dans l'atelier.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        AtelierMinimap(
            maps = maps,
            portals = portals,
            counts = listOf(mobCount, portalCount, mapCount, itemCount, blockCount, recipeCount),
            onZone = onSelect
        )
        GoldPrimaryButton(
            "Importer le monde AGW dans ce projet",
            onImportAgw,
            modifier = Modifier.fillMaxWidth()
        )
        GoldOutlineButton(
            "Générer la fondation complète (Bac à sable)",
            onGenerateFoundation,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            "Parcours : Fondation → Import AGW → ajuster zones → Export. Tout le contenu projet part dans le .mcaddon.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun AtelierMinimap(
    maps: List<MapBlueprint>,
    portals: List<PortalBlueprint>,
    counts: List<Int>,
    onZone: (WorkshopZoneId) -> Unit
) {
    var showMaps by rememberSaveable { mutableStateOf(true) }
    var showPortals by rememberSaveable { mutableStateOf(true) }
    var showTools by rememberSaveable { mutableStateOf(true) }

    // Pins dynamiques : maps en haut, portails positionnés près de leur map liée si possible
    val mapPins = maps.mapIndexed { i, m ->
        val col = i % 4
        val row = i / 4
        MinimapPin("map_${m.id}", m.name.take(12), 14f + col * 22f, 18f + row * 14f, WorkshopZoneId.MAPS, 0xFF5DADE2, m.id)
    }
    val portalPins = portals.mapIndexed { i, p ->
        val linked = mapPins.firstOrNull { it.linkedMapId == p.linkedMapId }
        val baseX = linked?.x ?: (18f + (i % 4) * 20f)
        val baseY = (linked?.y ?: 70f) + 10f
        MinimapPin("portal_${p.id}", p.name.take(10), baseX.coerceIn(8f, 92f), baseY.coerceIn(8f, 92f), WorkshopZoneId.PORTALS, 0xFFB06AB3, p.linkedMapId)
    }
    val toolPins = listOf(
        MinimapPin("hub", "Hub", 50f, 50f, WorkshopZoneId.HUB, 0xFFC9A227),
        MinimapPin("mobs", "Mobs ${counts.getOrElse(0) { 0 }}", 12f, 50f, WorkshopZoneId.MOBS, 0xFFB94E48),
        MinimapPin("items", "Items ${counts.getOrElse(3) { 0 }}", 88f, 50f, WorkshopZoneId.ITEMS, 0xFF8E7CC3),
        MinimapPin("blocks", "Blocs ${counts.getOrElse(4) { 0 }}", 50f, 88f, WorkshopZoneId.BLOCKS, 0xFF7AA66D),
        MinimapPin("recipes", "Recettes ${counts.getOrElse(5) { 0 }}", 88f, 88f, WorkshopZoneId.RECIPES, 0xFFD4A017),
        MinimapPin("export", "Export", 50f, 10f, WorkshopZoneId.EXPORT, 0xFFE0A458)
    )
    val pins = buildList {
        if (showMaps) addAll(mapPins)
        if (showPortals) addAll(portalPins)
        if (showTools) addAll(toolPins)
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        // Filtres
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = showMaps, onClick = { showMaps = !showMaps }, label = { Text("Maps", fontSize = 10.sp) })
            FilterChip(selected = showPortals, onClick = { showPortals = !showPortals }, label = { Text("Portails", fontSize = 10.sp) })
            FilterChip(selected = showTools, onClick = { showTools = !showTools }, label = { Text("Outils", fontSize = 10.sp) })
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(240.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF0E1218))
                .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
        ) {
            Canvas(Modifier.fillMaxSize()) {
                // Fond grille
                val step = size.width / 10f
                for (i in 1 until 10) {
                    drawLine(Color(0x22C9A227), Offset(i * step, 0f), Offset(i * step, size.height), 1f)
                    drawLine(Color(0x22C9A227), Offset(0f, i * (size.height / 10f)), Offset(size.width, i * (size.height / 10f)), 1f)
                }
                // Zone centrale
                drawRoundRect(
                    color = Color(0x18C9A227),
                    topLeft = Offset(size.width * 0.36f, size.height * 0.36f),
                    size = androidx.compose.ui.geometry.Size(size.width * .28f, size.height * .28f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f)
                )
                // Chemins vers les pôles
                val c = Offset(size.width * .5f, size.height * .5f)
                listOf(
                    Offset(size.width * .12f, size.height * .5f),
                    Offset(size.width * .88f, size.height * .5f),
                    Offset(size.width * .5f, size.height * .10f),
                    Offset(size.width * .5f, size.height * .90f)
                ).forEach { drawLine(Color(0x55C9A227), c, it, 2f) }
                // Traits de liaison map → portail
                if (showMaps && showPortals) {
                    for (pp in portalPins) {
                        val mp = mapPins.firstOrNull { it.linkedMapId != null && it.linkedMapId == pp.linkedMapId }
                        if (mp != null) {
                            val a = Offset(mp.x / 100f * size.width, mp.y / 100f * size.height)
                            val b = Offset(pp.x / 100f * size.width, pp.y / 100f * size.height)
                            drawLine(Color(0x66B06AB3), a, b, 1.5f)
                        }
                    }
                }
            }
            pins.forEach { pin ->
                val px = ((pin.x.coerceIn(4f, 96f)) / 100f * 92f).dp
                val py = ((pin.y.coerceIn(4f, 96f)) / 100f * 228f).dp
                Column(
                    Modifier
                        .offset(x = px, y = py)
                        .clickable { onZone(pin.zone) }
                        .padding(2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier
                            .size(if (pin.id.startsWith("map_") || pin.id.startsWith("portal_")) 12.dp else 16.dp)
                            .background(Color(pin.colorHint), CircleShape)
                            .border(1.dp, AgwColors.GoldSoft, CircleShape)
                    )
                    Text(pin.label, color = AgwColors.PaleMarble, fontSize = 8.sp, maxLines = 1)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LegendDot("Hub", 0xFFC9A227)
            LegendDot("Maps", 0xFF5DADE2)
            LegendDot("Portails", 0xFFB06AB3)
            LegendDot("Outils", 0xFF7AA66D)
        }
        Text(
            "${maps.size} carte(s) · ${portals.size} portail(s) · filtres actifs · liaisons map↔portail affichées",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.labelSmall
        )
    }
}


@Composable
private fun LegendDot(label: String, color: Long) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(Color(color), CircleShape))
        Spacer(Modifier.width(4.dp))
        Text(label, color = AgwColors.PaleMarble, fontSize = 8.sp, maxLines = 1)
    }
}


@Composable
private fun HubValidationBadge(
    summary: HubValidationSummary,
    onOpenExport: () -> Unit
) {
    val borderColor = when {
        summary.hasErrors -> AgwColors.Error
        summary.hasWarnings -> AgwColors.Warning
        else -> AgwColors.Success
    }
    val title = when {
        summary.hasErrors -> "Validation · ${summary.errorCount} erreur(s)"
        summary.hasWarnings -> "Validation · ${summary.warningCount} avertissement(s)"
        else -> "Validation · OK"
    }
    val subtitle = when {
        summary.hasErrors -> "Liens cassés ou données invalides — corrigez avant export."
        summary.hasWarnings -> "Le pack peut être exporté, mais des points méritent attention."
        else -> "Aucun problème croisé détecté sur le contenu du projet."
    }
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenExport() }
    ) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(borderColor)
            )
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = borderColor)
                Text(subtitle, color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                if (summary.messages.isNotEmpty()) {
                    summary.messages.take(3).forEach { msg ->
                        Text("· $msg", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                    }
                    if (summary.messages.size > 3) {
                        Text("… +${summary.messages.size - 3}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Text("Export →", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelMedium)
        }
    }
}
