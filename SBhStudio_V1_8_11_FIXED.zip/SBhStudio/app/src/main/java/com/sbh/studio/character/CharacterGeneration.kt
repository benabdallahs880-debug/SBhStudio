package com.sbh.studio.character

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

@Serializable
data class CharacterGenerationProfile(
    val imageWidth: Int = 0,
    val imageHeight: Int = 0,
    val aspectRatio: Float = 0f,
    val format: String = "unknown",
    val hasAlpha: Boolean = false,
    val detectedView: String = "unknown",
    val quality: String = "unknown",
    val analyzedAt: Long = System.currentTimeMillis()
)

data class CharacterAnalysisResult(
    val profile: CharacterGenerationProfile,
    val warnings: List<String> = emptyList(),
    val suggestions: List<String> = emptyList()
)

/** Analyse locale de la référence. Aucun service distant et aucune donnée image envoyée. */
object CharacterImageAnalyzer {
    fun analyze(context: Context, uri: Uri): CharacterAnalysisResult {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri).orEmpty().lowercase()
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }

        val width = options.outWidth.coerceAtLeast(0)
        val height = options.outHeight.coerceAtLeast(0)
        val ratio = if (height > 0) width.toFloat() / height else 0f
        val format = when {
            mime.contains("png") -> "PNG"
            mime.contains("webp") -> "WEBP"
            mime.contains("jpeg") || mime.contains("jpg") -> "JPEG"
            else -> mime.substringAfterLast('/').uppercase().ifBlank { "UNKNOWN" }
        }
        val view = when {
            ratio in 0.85f..1.18f -> "Vue quasi carrée / portrait"
            ratio < 0.85f -> "Portrait"
            else -> "Paysage / plan large"
        }
        val quality = when {
            width >= 2048 && height >= 2048 -> "Élevée"
            width >= 1024 && height >= 1024 -> "Correcte"
            width > 0 && height > 0 -> "Faible"
            else -> "Inconnue"
        }
        val warnings = buildList {
            if (width <= 0 || height <= 0) add("Dimensions non lisibles : la référence peut être incompatible.")
            if (width in 1..1023 || height in 1..1023) add("Résolution faible pour une reconstruction 3D détaillée.")
            if (ratio > 2.0f || ratio < 0.5f) add("Cadrage très large : une vue du corps entier sera plus difficile à interpréter.")
        }
        val suggestions = buildList {
            add("Sujet centré et entièrement visible")
            add("Fond simple et contraste net avec le personnage")
            add("Pour un modèle complet, ajouter face + profil + dos lors d'une future génération multi-vues")
        }
        return CharacterAnalysisResult(
            CharacterGenerationProfile(width, height, ratio, format, false, view, quality),
            warnings,
            suggestions
        )
    }
}

/** Contrat commun pour les futurs moteurs Image→3D. */
interface CharacterGenerator {
    val id: String
    val label: String
    fun isAvailable(): Boolean
}

object LocalPreviewGenerator : CharacterGenerator {
    override val id = "local_preview"
    override val label = "Générateur local de prévisualisation"
    override fun isAvailable() = true
}

object CloudAiGenerator : CharacterGenerator {
    override val id = "cloud_ai"
    override val label = "Générateur IA distant"
    override fun isAvailable() = false
}


@Serializable
data class CharacterGenerationRequest(
    val characterId: String,
    val referenceIds: List<String>,
    val target: String = "GAME_READY",
    val rig: RigMode = RigMode.NONE,
    val requestedAt: Long = System.currentTimeMillis()
)

data class CharacterGenerationReadiness(
    val ready: Boolean,
    val score: Int,
    val blockers: List<String>,
    val recommendations: List<String>
)

object CharacterGenerationPlanner {
    fun evaluate(character: CharacterProject): CharacterGenerationReadiness {
        val refs = character.references
        val blockers = buildList {
            if (refs.isEmpty() && character.sourceImageUri == null) add("Aucune référence image disponible.")
            if (refs.none { it.view == CharacterReferenceView.FRONT } && character.sourceImageUri == null) add("Une vue de face est recommandée comme référence principale.")
        }
        val recommendations = buildList {
            if (refs.size < 2) add("Ajouter au moins une deuxième vue pour réduire les ambiguïtés de forme.")
            if (refs.none { it.view == CharacterReferenceView.BACK }) add("Ajouter une vue arrière pour préparer un modèle complet.")
            if (character.rigMode == RigMode.NONE) add("Choisir un rig après validation de la géométrie.")
        }
        val score = (100 - blockers.size * 35 - (2 - refs.size).coerceAtLeast(0) * 10).coerceIn(0, 100)
        return CharacterGenerationReadiness(blockers.isEmpty(), score, blockers, recommendations)
    }

    fun buildRequest(character: CharacterProject): CharacterGenerationRequest {
        return CharacterGenerationRequest(
            characterId = character.id,
            referenceIds = character.references.map { it.id } + listOfNotNull(character.sourceImageUri?.let { "primary:$it" }),
            rig = character.rigMode
        )
    }
}

@Serializable
enum class CharacterGenerationJobStatus { QUEUED, RUNNING, SUCCEEDED, FAILED }

@Serializable
data class CharacterGenerationJob(
    val id: String = java.util.UUID.randomUUID().toString(),
    val characterId: String,
    val generatorId: String,
    val status: CharacterGenerationJobStatus = CharacterGenerationJobStatus.QUEUED,
    val progress: Int = 0,
    val message: String = "En attente",
    val outputUri: String? = null,
    val outputName: String? = null,
    val startedAt: Long? = null,
    val finishedAt: Long? = null
)

data class CharacterGenerationResult(
    val job: CharacterGenerationJob,
    val modelUri: String?,
    val modelName: String?
)

/**
 * Étape 5 : pipeline de génération local.
 * Ce moteur produit volontairement un modèle de base game-ready à partir du mannequin embarqué.
 * Il sert de passerelle fonctionnelle vers le futur moteur Image→3D distant, sans prétendre
 * transformer magiquement une photo en personnage détaillé hors connexion.
 */
object CharacterGenerationEngine {
    fun generateLocalPrototype(
        context: Context,
        character: CharacterProject,
        onProgress: (Int, String) -> Unit = { _, _ -> }
    ): CharacterGenerationResult {
        val jobId = java.util.UUID.randomUUID().toString()
        fun progress(value: Int, message: String) = onProgress(value, message)
        try {
            progress(10, "Validation du dossier")
            val readiness = CharacterGenerationPlanner.evaluate(character)
            require(readiness.ready) { readiness.blockers.joinToString(" · ") }

            progress(30, "Préparation du générateur local")
            val outDir = java.io.File(context.filesDir, "character_models")
            outDir.mkdirs()
            val safeName = character.name.lowercase().replace(Regex("[^a-z0-9_-]+"), "_").trim('_').ifBlank { "character" }
            val output = java.io.File(outDir, "${safeName}_${jobId.take(8)}.glb")

            progress(65, "Construction du modèle de base")
            context.assets.open("models/sbh_mannequin.glb").use { input -> output.outputStream().use { input.copyTo(it) } }

            progress(90, "Validation du fichier GLB")
            require(output.exists() && output.length() > 32) { "Le fichier GLB généré est invalide ou vide." }
            progress(100, "Modèle prêt dans le viewport")

            val job = CharacterGenerationJob(
                id = jobId,
                characterId = character.id,
                generatorId = LocalPreviewGenerator.id,
                status = CharacterGenerationJobStatus.SUCCEEDED,
                progress = 100,
                message = "Modèle de base généré",
                outputUri = output.absolutePath,
                outputName = output.name,
                startedAt = System.currentTimeMillis(),
                finishedAt = System.currentTimeMillis()
            )
            return CharacterGenerationResult(job, output.absolutePath, output.name)
        } catch (e: Exception) {
            val job = CharacterGenerationJob(
                id = jobId,
                characterId = character.id,
                generatorId = LocalPreviewGenerator.id,
                status = CharacterGenerationJobStatus.FAILED,
                progress = 0,
                message = e.message ?: "Génération impossible",
                startedAt = System.currentTimeMillis(),
                finishedAt = System.currentTimeMillis()
            )
            return CharacterGenerationResult(job, null, null)
        }
    }
}



@Serializable
data class RemoteGenerationResponse(
    val jobId: String? = null,
    val status: String = "QUEUED",
    val progress: Int = 0,
    val message: String = "En attente",
    val resultUrl: String? = null,
    val resultName: String? = null
)

data class RemoteGenerationConfig(
    val endpoint: String = "",
    val pollIntervalMs: Long = 1500L,
    val timeoutMs: Long = 15 * 60 * 1000L
)

/**
 * Transport générique Image→3D. Il ne choisit aucun fournisseur et n'embarque aucune clé.
 * Le serveur attendu accepte POST /jobs avec le contrat JSON de CharacterGenerationRequest,
 * puis GET /jobs/{id}. Le GLB final est téléchargé depuis resultUrl.
 */
object RemoteCharacterGenerationClient {
    private val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun isConfigured(config: RemoteGenerationConfig): Boolean =
        config.endpoint.trim().startsWith("https://")

    fun submit(
        context: Context,
        character: CharacterProject,
        request: CharacterGenerationRequest,
        config: RemoteGenerationConfig,
        onProgress: (Int, String) -> Unit = { _, _ -> }
    ): CharacterGenerationResult {
        val jobId = java.util.UUID.randomUUID().toString()
        val started = System.currentTimeMillis()
        return try {
            require(isConfigured(config)) { "Endpoint HTTPS non configuré." }
            onProgress(5, "Connexion au moteur distant")
            val endpoint = config.endpoint.trimEnd('/') + "/jobs"
            val body = json.encodeToString(CharacterGenerationRequest.serializer(), request)
            val remoteId = postJson(endpoint, body)
            require(remoteId.isNotBlank()) { "Le serveur n'a pas retourné d'identifiant de job." }

            val deadline = System.currentTimeMillis() + config.timeoutMs
            var last = RemoteGenerationResponse(jobId = remoteId)
            while (System.currentTimeMillis() < deadline) {
                Thread.sleep(config.pollIntervalMs)
                last = getJson(endpoint + "/" + java.net.URLEncoder.encode(remoteId, "UTF-8"))
                val progress = last.progress.coerceIn(0, 99)
                onProgress(progress, last.message)
                if (last.status.uppercase() == "SUCCEEDED") break
                if (last.status.uppercase() == "FAILED") error(last.message.ifBlank { "Le moteur distant a échoué." })
            }
            require(last.status.uppercase() == "SUCCEEDED") { "Délai d'attente du moteur distant dépassé." }
            val resultUrl = requireNotNull(last.resultUrl) { "Le job est terminé mais aucun GLB n'a été fourni." }
            onProgress(95, "Téléchargement du modèle")
            val outDir = java.io.File(context.filesDir, "character_models")
            outDir.mkdirs()
            val safeName = character.name.lowercase().replace(Regex("[^a-z0-9_-]+"), "_").trim('_').ifBlank { "character" }
            val output = java.io.File(outDir, "${safeName}_${jobId.take(8)}.glb")
            download(resultUrl, output)
            require(output.exists() && output.length() > 32) { "Le GLB distant est invalide ou vide." }
            onProgress(100, "Modèle distant téléchargé")
            CharacterGenerationResult(
                CharacterGenerationJob(jobId, character.id, CharacterGenerationProvider.REMOTE_AI.name, CharacterGenerationJobStatus.SUCCEEDED, 100, "Modèle distant prêt", output.absolutePath, last.resultName ?: output.name, started, System.currentTimeMillis()),
                output.absolutePath,
                last.resultName ?: output.name
            )
        } catch (e: Exception) {
            CharacterGenerationResult(
                CharacterGenerationJob(jobId, character.id, CharacterGenerationProvider.REMOTE_AI.name, CharacterGenerationJobStatus.FAILED, 0, e.message ?: "Connexion distante impossible", null, null, started, System.currentTimeMillis()),
                null,
                null
            )
        }
    }

    private fun postJson(url: String, body: String): String {
        val connection = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        try {
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}: ${text.take(240)}")
            val obj = json.decodeFromString<RemoteGenerationResponse>(text)
            return obj.jobId ?: text.trim().removePrefix("\"").removeSuffix("\"")
        } finally { connection.disconnect() }
    }

    private fun getJson(url: String): RemoteGenerationResponse {
        val connection = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 30000
            setRequestProperty("Accept", "application/json")
        }
        try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}: ${text.take(240)}")
            return json.decodeFromString(text)
        } finally { connection.disconnect() }
    }

    private fun download(url: String, output: java.io.File) {
        val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 120000
        connection.connect()
        try {
            if (connection.responseCode !in 200..299) error("Téléchargement GLB HTTP ${connection.responseCode}")
            connection.inputStream.use { input -> output.outputStream().use { input.copyTo(it) } }
        } finally { connection.disconnect() }
    }
}

@Serializable
enum class CharacterGenerationProvider {
    LOCAL_PREVIEW,
    REMOTE_AI,
    MESHY
}

@Serializable
data class CharacterGenerationOptions(
    val provider: CharacterGenerationProvider = CharacterGenerationProvider.LOCAL_PREVIEW,
    val targetStyle: String = "REALISTIC_GAME",
    val detailLevel: Int = 2,
    val textureQuality: String = "2K",
    val generateTextures: Boolean = true,
    val generateSkeleton: Boolean = false
)

data class CharacterGeneratorDescriptor(
    val id: String,
    val label: String,
    val available: Boolean,
    val description: String
)

object CharacterGeneratorCatalog {
    fun all(): List<CharacterGeneratorDescriptor> = listOf(
        CharacterGeneratorDescriptor(
            LocalPreviewGenerator.id,
            LocalPreviewGenerator.label,
            true,
            "Générateur local de validation. Fonctionne hors connexion."
        ),
        CharacterGeneratorDescriptor(
            CloudAiGenerator.id,
            CloudAiGenerator.label,
            CloudAiGenerator.isAvailable(),
            "Connecteur prévu pour un service Image→3D externe. Aucun accès réseau n'est activé par défaut."
        )
    )

    fun descriptor(provider: CharacterGenerationProvider): CharacterGeneratorDescriptor =
        when (provider) {
            CharacterGenerationProvider.LOCAL_PREVIEW -> all().first { it.id == LocalPreviewGenerator.id }
            CharacterGenerationProvider.REMOTE_AI -> all().first { it.id == CloudAiGenerator.id }
            CharacterGenerationProvider.MESHY -> CharacterGeneratorDescriptor("meshy", "Meshy Image→3D", true, "Fournisseur réel Image→3D via API Meshy. Clé stockée dans Android Keystore.")
        }
}

object CharacterGenerationRequestFactory {
    fun create(
        character: CharacterProject,
        options: CharacterGenerationOptions
    ): CharacterGenerationRequest {
        return CharacterGenerationRequest(
            characterId = character.id,
            referenceIds = character.references.map { it.id } +
                listOfNotNull(character.sourceImageUri?.let { "primary:$it" }),
            target = "${options.targetStyle}_${options.textureQuality}_D${options.detailLevel}",
            rig = if (options.generateSkeleton) {
                if (character.rigMode == RigMode.NONE) RigMode.HUMANOID else character.rigMode
            } else RigMode.NONE
        )
    }
}


/** Fournisseur réel Image→3D : Meshy REST API. La clé n'est jamais embarquée dans l'APK. */
object MeshyApiKeyStore {
    private const val PREFS = "sbh_character_provider"
    private const val ALIAS = "sbh_meshy_api_key"
    private const val KEY_NAME = "key_blob"
    private const val IV_NAME = "iv_blob"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(context: Context, apiKey: String) {
        require(apiKey.isNotBlank()) { "Clé API vide." }
        val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!keyStore.containsAlias(ALIAS)) {
            val generator = javax.crypto.KeyGenerator.getInstance("AES", "AndroidKeyStore")
            generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
                ALIAS, android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).build())
            generator.generateKey()
        }
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, keyStore.getKey(ALIAS, null))
        val encrypted = cipher.doFinal(apiKey.toByteArray(Charsets.UTF_8))
        prefs(context).edit().putString(KEY_NAME, android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP))
            .putString(IV_NAME, android.util.Base64.encodeToString(cipher.iv, android.util.Base64.NO_WRAP)).apply()
    }

    fun load(context: Context): String? = runCatching {
        val p = prefs(context)
        val encrypted = p.getString(KEY_NAME, null) ?: return null
        val iv = p.getString(IV_NAME, null) ?: return null
        val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.DECRYPT_MODE, keyStore.getKey(ALIAS, null), javax.crypto.spec.GCMParameterSpec(128, android.util.Base64.decode(iv, android.util.Base64.NO_WRAP)))
        String(cipher.doFinal(android.util.Base64.decode(encrypted, android.util.Base64.NO_WRAP)), Charsets.UTF_8)
    }.getOrNull()

    fun clear(context: Context) { prefs(context).edit().clear().apply() }
}

@Serializable
data class MeshyGenerationConfig(
    val model: String = "latest",
    val useMultiImage: Boolean = true,
    val removeLighting: Boolean = true,
    val autoSize: Boolean = true,
    val moderation: Boolean = true
)

object MeshyImageTo3DClient {
    private const val BASE = "https://api.meshy.ai/openapi/v1"
    private val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true; encodeDefaults = false }

    fun generate(
        context: Context,
        character: CharacterProject,
        apiKey: String,
        config: MeshyGenerationConfig = MeshyGenerationConfig(),
        onProgress: (Int, String) -> Unit = { _, _ -> }
    ): CharacterGenerationResult {
        val localJob = java.util.UUID.randomUUID().toString()
        val started = System.currentTimeMillis()
        return try {
            require(apiKey.startsWith("msy_")) { "Clé Meshy invalide : elle doit commencer par msy_." }
            val imageUris = buildList {
                character.sourceImageUri?.let { add(it) }
                character.references.sortedBy { it.addedAt }.forEach { if (!contains(it.uri)) add(it.uri) }
            }.take(4)
            require(imageUris.isNotEmpty()) { "Aucune image de référence disponible." }
            onProgress(5, "Préparation des références pour Meshy")
            val imageData = imageUris.map { contentUriToDataUri(context, Uri.parse(it)) }
            val useMulti = config.useMultiImage && imageData.size >= 2
            val createUrl = if (useMulti) "$BASE/multi-image-to-3d" else "$BASE/image-to-3d"
            val payload = buildJsonObject {
                if (useMulti) {
                    put("image_urls", buildJsonArray { imageData.forEach { add(JsonPrimitive(it)) } })
                } else {
                    put("image_url", JsonPrimitive(imageData.first()))
                }
                put("ai_model", JsonPrimitive(config.model))
                put("target_formats", buildJsonArray { add(JsonPrimitive("glb")) })
                put("remove_lighting", JsonPrimitive(config.removeLighting))
                put("auto_size", JsonPrimitive(config.autoSize))
                put("moderation", JsonPrimitive(config.moderation))
            }.toString()
            onProgress(10, if (useMulti) "Envoi de ${imageData.size} vues à Meshy" else "Envoi de la référence à Meshy")
            val taskId = post(createUrl, payload, apiKey)
            val deadline = System.currentTimeMillis() + 30 * 60 * 1000L
            var last = kotlinx.serialization.json.JsonObject(emptyMap())
            while (System.currentTimeMillis() < deadline) {
                Thread.sleep(5000)
                last = get("$createUrl/$taskId", apiKey)
                val status = last["status"]?.toString()?.trim('"').orEmpty()
                val progress = last["progress"]?.toString()?.toIntOrNull()?.coerceIn(0, 99) ?: 15
                onProgress(progress, "Meshy : ${status.ifBlank { "IN_PROGRESS" }}")
                if (status == "SUCCEEDED") break
                if (status == "FAILED" || status == "CANCELED") error("Meshy : ${taskError(last)}")
            }
            val status = last["status"]?.toString()?.trim('"').orEmpty()
            require(status == "SUCCEEDED") { "Délai d'attente Meshy dépassé." }
            val modelUrls = last["model_urls"] as? kotlinx.serialization.json.JsonObject
            val glb = modelUrls?.get("glb")?.toString()?.trim('"')
            require(!glb.isNullOrBlank()) { "Meshy a terminé sans URL GLB." }
            onProgress(95, "Téléchargement du GLB Meshy")
            val outDir = java.io.File(context.filesDir, "character_models").apply { mkdirs() }
            val safeName = character.name.lowercase().replace(Regex("[^a-z0-9_-]+"), "_").trim('_').ifBlank { "character" }
            val output = java.io.File(outDir, "${safeName}_meshy_${localJob.take(8)}.glb")
            download(glb, output)
            require(output.length() > 32) { "Le GLB Meshy est vide ou invalide." }
            onProgress(100, "Modèle Meshy prêt dans le viewport")
            CharacterGenerationResult(
                CharacterGenerationJob(localJob, character.id, "meshy", CharacterGenerationJobStatus.SUCCEEDED, 100, "Modèle Meshy prêt", output.absolutePath, output.name, started, System.currentTimeMillis()),
                output.absolutePath, output.name
            )
        } catch (e: Exception) {
            CharacterGenerationResult(CharacterGenerationJob(localJob, character.id, "meshy", CharacterGenerationJobStatus.FAILED, 0, e.message ?: "Génération Meshy impossible", null, null, started, System.currentTimeMillis()), null, null)
        }
    }

    private fun contentUriToDataUri(context: Context, uri: Uri): String {
        val mime = context.contentResolver.getType(uri) ?: "image/png"
        require(mime == "image/png" || mime == "image/jpeg" || mime == "image/webp") { "Format image non supporté par Meshy : $mime" }
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Impossible de lire l'image $uri")
        require(bytes.size <= 20 * 1024 * 1024) { "Image trop volumineuse (maximum 20 Mo)." }
        return "data:$mime;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
    }

    private fun post(url: String, body: String, apiKey: String): String {
        val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey"); setRequestProperty("Content-Type", "application/json"); setRequestProperty("Accept", "application/json")
        }
        return try {
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val text = (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (c.responseCode !in 200..299) error("Meshy HTTP ${c.responseCode}: ${text.take(300)}")
            val obj = json.parseToJsonElement(text).jsonObject
            obj["result"]?.toString()?.trim('"') ?: error("Meshy n'a pas retourné de task id.")
        } finally { c.disconnect() }
    }

    private fun get(url: String, apiKey: String): kotlinx.serialization.json.JsonObject {
        val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 20000; readTimeout = 60000
            setRequestProperty("Authorization", "Bearer $apiKey"); setRequestProperty("Accept", "application/json")
        }
        return try {
            val text = (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (c.responseCode !in 200..299) error("Meshy HTTP ${c.responseCode}: ${text.take(300)}")
            json.parseToJsonElement(text).jsonObject
        } finally { c.disconnect() }
    }

    private fun taskError(obj: kotlinx.serialization.json.JsonObject): String = obj["task_error"]?.toString()?.take(300) ?: "échec inconnu"
    private fun download(url: String, output: java.io.File) {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 180000; c.connect()
        try { if (c.responseCode !in 200..299) error("Téléchargement GLB HTTP ${c.responseCode}"); c.inputStream.use { i -> output.outputStream().use { o -> i.copyTo(o) } } } finally { c.disconnect() }
    }
}
