package com.sbh.studio.workshop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle

internal val PORTAL_DIMENSIONS = listOf("minecraft:overworld", "minecraft:nether", "minecraft:the_end")
internal fun dimensionLabel(id: String) = when (id) {
    "minecraft:nether" -> "Nether"
    "minecraft:the_end" -> "End"
    else -> "Overworld"
}

private fun portalCodeTokens(line: String): List<String> =
    Regex("\\\"[^\\\"]*\\\"|'[^']*'|[^\\s]+")
        .findAll(line.trim())
        .map { it.value.trim('\"', '\'') }
        .toList()

private fun portalCodeUnquote(value: String): String = value.trim().trim('\"', '\'')

private fun validatePortalCode(source: String): List<String> {
    val errors = mutableListOf<String>()
    source.lines().forEachIndexed { index, raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) return@forEachIndexed
        val t = portalCodeTokens(line)
        when (t.firstOrNull()) {
            "portal.create" -> if (t.size < 2) errors += "Ligne ${index + 1} : portal.create(\"Nom\")"
            "portal.size" -> if (t.size < 3 || t[1].toIntOrNull() == null || t[2].toIntOrNull() == null) errors += "Ligne ${index + 1} : portal.size(largeur hauteur)"
            "portal.frame" -> if (t.size < 2) errors += "Ligne ${index + 1} : portal.frame(\"namespace:bloc\")"
            "portal.destination" -> if (t.size < 5 || t[1].toIntOrNull() == null || t[2].toIntOrNull() == null || t[3].toIntOrNull() == null) errors += "Ligne ${index + 1} : portal.destination(X Y Z \"dimension\")"
            "portal.description" -> if (t.size < 2) errors += "Ligne ${index + 1} : portal.description(\"Description\")"
            "portal.map" -> if (t.size < 5 || t[2].toIntOrNull() == null || t[3].toIntOrNull() == null || t[4].toIntOrNull() == null) errors += "Ligne ${index + 1} : portal.map(\"mapId\" X Y Z)"
            else -> errors += "Ligne ${index + 1} : commande inconnue « ${t.firstOrNull() ?: ""} »"
        }
    }
    return errors
}

private fun applyPortalCode(source: String, base: PortalBlueprint): PortalBlueprint {
    var result = base
    source.lines().forEach { raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) return@forEach
        val t = portalCodeTokens(line)
        when (t.firstOrNull()) {
            "portal.create" -> if (t.size >= 2) result = result.copy(name = portalCodeUnquote(t[1]))
            "portal.size" -> if (t.size >= 3) result = result.copy(width = t[1].toIntOrNull() ?: result.width, height = t[2].toIntOrNull() ?: result.height)
            "portal.frame" -> if (t.size >= 2) result = result.copy(frameBlock = portalCodeUnquote(t[1]))
            "portal.destination" -> if (t.size >= 5) result = result.copy(
                destX = t[1].toIntOrNull() ?: result.destX,
                destY = t[2].toIntOrNull() ?: result.destY,
                destZ = t[3].toIntOrNull() ?: result.destZ,
                destDimension = portalCodeUnquote(t[4])
            )
            "portal.description" -> if (t.size >= 2) result = result.copy(destinationHint = portalCodeUnquote(t[1]))
            "portal.map" -> if (t.size >= 5) result = result.copy(linkedMapId = portalCodeUnquote(t[1]), mapX = t[2].toIntOrNull() ?: result.mapX, mapY = t[3].toIntOrNull() ?: result.mapY, mapZ = t[4].toIntOrNull() ?: result.mapZ)
        }
    }
    return result
}

@Composable
internal fun PortalPreview(portal: PortalBlueprint) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("👁 Aperçu visuel du portail", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
            Text("Vue frontale · ${portal.width}×${portal.height} · ${portal.frameBlock}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(AgwColors.DeepNight)
            ) {
                val cols = portal.width.coerceIn(2, 16)
                val rows = portal.height.coerceIn(3, 16)
                val cell = minOf(size.width / (cols + 4f), size.height / (rows + 4f))
                val totalW = cols * cell
                val totalH = rows * cell
                val left = (size.width - totalW) / 2f
                val top = (size.height - totalH) / 2f
                val frameColor = AgwColors.DesertOchre
                val innerColor = Color(0xFF24163A)
                val glowColor = AgwColors.SacredGold.copy(alpha = 0.28f)
                drawRect(glowColor, Offset(left + cell, top + cell), androidx.compose.ui.geometry.Size(totalW - 2 * cell, totalH - 2 * cell))
                for (x in 0 until cols) for (y in 0 until rows) {
                    val isFrame = x == 0 || x == cols - 1 || y == 0 || y == rows - 1
                    drawRect(
                        if (isFrame) frameColor else innerColor,
                        Offset(left + x * cell, top + y * cell),
                        androidx.compose.ui.geometry.Size(cell - 1.5f, cell - 1.5f)
                    )
                }
                drawRect(frameColor, Offset(left, top), androidx.compose.ui.geometry.Size(totalW, totalH), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f))
            }
            Text("Destination : ${portal.destinationHint} · (${portal.destX}, ${portal.destY}, ${portal.destZ}) · ${dimensionLabel(portal.destDimension)}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
            if (portal.linkedMapId != null) Text("🔗 Map liée : ${portal.linkedMapId} · position (${portal.mapX}, ${portal.mapY}, ${portal.mapZ})", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
internal fun PortalZone(
    projectId: String,
    portals: List<PortalBlueprint>,
    maps: List<MapBlueprint>,
    textures: List<TextureProject> = emptyList(),
    onSave: (PortalBlueprint) -> Unit,
    onDelete: (PortalBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var codeMode by rememberSaveable { mutableStateOf(false) }
    var codeStatus by rememberSaveable { mutableStateOf("Prêt") }
    var code by rememberSaveable {
        mutableStateOf(
            "portal.create(\"Portail Al-Zahra\")\n" +
            "portal.size(4 5)\n" +
            "portal.frame(\"agw:night_bricks\")\n" +
            "portal.destination(0 64 0 \"minecraft:overworld\")\n" +
            "portal.description(\"الزهراء · Al-Zahra\")" + if (maps.isNotEmpty()) "\nportal.map(\"${maps.first().id}\" 8 64 8)" else ""
        )
    }

    var name by rememberSaveable { mutableStateOf("Portail Al-Zahra") }
    var identifier by rememberSaveable { mutableStateOf("agw:portal_custom") }
    var width by rememberSaveable { mutableStateOf("4") }
    var height by rememberSaveable { mutableStateOf("5") }
    var frame by rememberSaveable { mutableStateOf("agw:night_bricks") }
    var dest by rememberSaveable { mutableStateOf("الزهراء · Al-Zahra") }
    var destX by rememberSaveable { mutableStateOf("0") }
    var destY by rememberSaveable { mutableStateOf("64") }
    var destZ by rememberSaveable { mutableStateOf("0") }
    var destDim by rememberSaveable { mutableStateOf(PORTAL_DIMENSIONS[0]) }
    var linkedMapId by rememberSaveable { mutableStateOf<String?>(null) }
    var mapX by rememberSaveable { mutableStateOf("0") }
    var mapY by rememberSaveable { mutableStateOf("64") }
    var mapZ by rememberSaveable { mutableStateOf("0") }

    fun currentPortal() = PortalBlueprint(
        id = editingId ?: java.util.UUID.randomUUID().toString(), projectId = projectId,
        name = name, identifier = identifier, width = width.toIntOrNull() ?: 4, height = height.toIntOrNull() ?: 5,
        frameBlock = frame, destinationHint = dest, destX = destX.toIntOrNull() ?: 0,
        destY = destY.toIntOrNull() ?: 64, destZ = destZ.toIntOrNull() ?: 0, destDimension = destDim,
        linkedMapId = linkedMapId, mapX = mapX.toIntOrNull() ?: 0, mapY = mapY.toIntOrNull() ?: 64, mapZ = mapZ.toIntOrNull() ?: 0
    )

    fun loadIntoForm(p: PortalBlueprint) {
        editingId = p.id; name = p.name; identifier = p.identifier; width = p.width.toString(); height = p.height.toString()
        frame = p.frameBlock; dest = p.destinationHint; destX = p.destX.toString(); destY = p.destY.toString(); destZ = p.destZ.toString(); destDim = p.destDimension
        linkedMapId = p.linkedMapId; mapX = p.mapX.toString(); mapY = p.mapY.toString(); mapZ = p.mapZ.toString()
        code = "portal.create(\"${p.name}\")\nportal.size(${p.width} ${p.height})\nportal.frame(\"${p.frameBlock}\")\nportal.destination(${p.destX} ${p.destY} ${p.destZ} \"${p.destDimension}\")\nportal.description(\"${p.destinationHint}\")" + if (p.linkedMapId != null) "\nportal.map(\"${p.linkedMapId}\" ${p.mapX} ${p.mapY} ${p.mapZ})" else ""
    }

    fun resetForm() {
        editingId = null; name = "Portail Al-Zahra"; identifier = "agw:portal_custom"; width = "4"; height = "5"; frame = "agw:night_bricks"
        dest = "الزهراء · Al-Zahra"; destX = "0"; destY = "64"; destZ = "0"; destDim = PORTAL_DIMENSIONS[0]
        linkedMapId = null; mapX = "0"; mapY = "64"; mapZ = "0"
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Portails Minecraft", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                Text("Crée le portail visuellement ou par code, puis vérifie immédiatement son apparence.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = { codeMode = !codeMode }) { Text(if (codeMode) "✎ Formulaire" else "💻 Code") }
        }

        if (codeMode) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💻 SBh PORTAL CODE", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold, modifier = Modifier.weight(1f))
                        Text(codeStatus, color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("Écris les commandes du portail. Le clavier Android apparaît directement dans le champ.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it; codeStatus = "Modifié" },
                        modifier = Modifier.fillMaxWidth().height(210.dp),
                        textStyle = LocalTextStyle.current.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                        label = { Text("Code de génération") }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("()", "{}", "[ ]", "\"\"", "=", ",").forEach { key ->
                            OutlinedButton(onClick = { code += key.first().toString() }) { Text(key) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val errors = validatePortalCode(code)
                            codeStatus = if (errors.isEmpty()) "✓ Code valide" else "✕ ${errors.first()}"
                        }, modifier = Modifier.weight(1f)) { Text("✓ Vérifier") }
                        Button(onClick = {
                            val errors = validatePortalCode(code)
                            if (errors.isNotEmpty()) { codeStatus = "✕ ${errors.first()}"; return@Button }
                            val p = applyPortalCode(code, currentPortal())
                            loadIntoForm(p)
                            codeStatus = "✓ Portail généré"
                        }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)) { Text("▶ Générer") }
                    }
                }
            }
            PortalPreview(currentPortal())
        } else {
            Text("Marcher sur le bloc du portail téléporte réellement le joueur aux coordonnées choisies ci-dessous (script embarqué dans le pack).", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(width, { width = it }, label = { Text("Largeur") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(height, { height = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            OutlinedTextField(frame, { frame = it }, label = { Text("Bloc cadre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(dest, { dest = it }, label = { Text("Description destination") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Coordonnées de téléportation", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(destX, { destX = it }, label = { Text("X") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(destY, { destY = it }, label = { Text("Y") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(destZ, { destZ = it }, label = { Text("Z") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PORTAL_DIMENSIONS.forEach { d ->
                    val selected = destDim == d
                    OutlinedButton(onClick = { destDim = d }, colors = if (selected) ButtonDefaults.outlinedButtonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight) else ButtonDefaults.outlinedButtonColors(contentColor = AgwColors.PaleMarble)) { Text(dimensionLabel(d)) }
                }
            }
            Text("🔗 Connexion à une map", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
            Text("Le portail peut maintenant appartenir à une map et transmettre sa position au mode Map.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                OutlinedButton(onClick = { linkedMapId = null }) { Text(if (linkedMapId == null) "Aucune map" else "Déconnecter") }
                maps.forEach { m ->
                    val selected = linkedMapId == m.id
                    OutlinedButton(onClick = { linkedMapId = m.id }, colors = if (selected) ButtonDefaults.outlinedButtonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight) else ButtonDefaults.outlinedButtonColors(contentColor = AgwColors.PaleMarble)) { Text(m.name) }
                }
            }
            if (linkedMapId != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(mapX, { mapX = it }, label = { Text("Map X") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(mapY, { mapY = it }, label = { Text("Map Y") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(mapZ, { mapZ = it }, label = { Text("Map Z") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
            PortalPreview(currentPortal())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onSave(currentPortal()); resetForm() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)) { Text(if (editingId == null) "Enregistrer le portail" else "Enregistrer les modifications") }
                if (editingId != null) OutlinedButton({ resetForm() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
            }
        }

        portals.forEach { p ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${p.identifier} · ${p.width}×${p.height}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        Text("→ ${p.destinationHint} · (${p.destX}, ${p.destY}, ${p.destZ}) ${dimensionLabel(p.destDimension)}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ loadIntoForm(p) }) { Text("✎") }
                    TextButton({ if (editingId == p.id) resetForm(); onDelete(p) }) { Text("X") }
                }
            }
        }
        if (portals.isEmpty()) Text("Aucun portail pour ce projet.", color = AgwColors.Sand)
    }
}

