package com.sbh.studio.workshop

import kotlinx.serialization.Serializable
import java.util.UUID

/** Profil de performance mobile (aligné sur game_builder/templates). */
enum class GamePerformanceProfile {
    LIGHT,
    BALANCED,
    PERFORMANCE;

    fun schemaValue(): String = name.lowercase()

    companion object {
        fun fromSchema(value: String): GamePerformanceProfile =
            entries.find { it.name.equals(value, ignoreCase = true) } ?: BALANCED
    }
}

enum class GameTarget {
    ANDROID_MOBILE,
    ANDROID_TABLET;

    fun schemaValue(): String = when (this) {
        ANDROID_MOBILE -> "android_mobile"
        ANDROID_TABLET -> "android_tablet"
    }

    companion object {
        fun fromSchema(value: String): GameTarget = when (value.lowercase()) {
            "android_tablet" -> ANDROID_TABLET
            else -> ANDROID_MOBILE
        }
    }
}

/**
 * Blueprint de projet jeu 3D autonome (Atelier 2.0 / Game Builder).
 * Aligné sur app/src/main/assets/game_builder/game_project.schema.json
 */
@Serializable
data class GameProjectBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val engine: String = "godot",
    val target: String = "android_mobile",
    val performance: String = "balanced",
    val worldScene: String = "worlds/main.tscn",
    val worldSizeX: Int = 1024,
    val worldSizeY: Int = 256,
    val worldSizeZ: Int = 1024,
    val playerPrefab: String = "player/default",
    val factions: List<String> = listOf("player", "neutral", "enemy"),
    val missions: List<String> = emptyList(),
    val vehicles: List<String> = emptyList(),
    /** Profil JSON brut (light/balanced/performance) pour référence. */
    val profileJson: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/** Template listé depuis assets/game_builder/templates. */
data class GameBuilderTemplate(
    val id: String,
    val name: String,
    val description: String,
    val isWorldTemplate: Boolean,
    val performanceHint: String? = null
)
