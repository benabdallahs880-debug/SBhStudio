package com.sbh.studio.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Formes & surfaces — verre fin + argent */
object AgwDecor {
    val CardShape = RoundedCornerShape(18.dp)
    val ChipShape = RoundedCornerShape(12.dp)
    val ButtonShape = RoundedCornerShape(12.dp)
    val TileShape = RoundedCornerShape(16.dp)

    /** Contour argent fin (bulles / cartes). */
    val SilverBorder = BorderStroke(1.dp, AgwColors.SilverGlass)
    val SilverBorderSoft = BorderStroke(0.8.dp, AgwColors.SilverMuted.copy(alpha = 0.55f))
    val SilverBorderStrong = BorderStroke(1.2.dp, AgwColors.SilverSoft.copy(alpha = 0.75f))

    /** Compat : anciens appels « GoldBorder » → argent fin. */
    val GoldBorder = SilverBorder
    val GoldBorderStrong = SilverBorderStrong

    val PanelBrush = Brush.verticalGradient(
        listOf(AgwColors.PanelRaised.copy(alpha = 0.55f), AgwColors.Panel.copy(alpha = 0.4f))
    )
    val GoldSheen = Brush.verticalGradient(
        listOf(
            AgwColors.SilverVeil,
            Color.Transparent,
            Color.Transparent
        )
    )
    val CrystalSheen = Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = 0.08f),
            Color.Transparent,
            AgwColors.SilverVeil
        )
    )
}

@Composable
fun GoldPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp),
        shape = AgwDecor.ButtonShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = AgwColors.SacredGold,
            contentColor = AgwColors.DeepNight,
            disabledContainerColor = AgwColors.NightStone,
            disabledContentColor = AgwColors.Sand.copy(alpha = 0.5f)
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp, pressedElevation = 1.dp)
    ) {
        Text(text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun GoldOutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 44.dp),
        shape = AgwDecor.ButtonShape,
        border = AgwDecor.SilverBorderStrong,
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = AgwColors.SilverSoft,
            containerColor = AgwColors.CrystalGlass
        )
    ) {
        Text(text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .border(AgwDecor.SilverBorder, AgwDecor.CardShape),
        shape = AgwDecor.CardShape,
        // Verre fin : le fond photo reste visible derrière
        colors = CardDefaults.cardColors(containerColor = AgwColors.CrystalGlass),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box {
            Box(Modifier.matchParentSize().background(AgwDecor.CrystalSheen))
            Column(
                Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                content = content
            )
        }
    }
}

/**
 * Tuile de mode : icône (asset branding/icons) + libellé.
 * Utilisée sur l'accueil et dans l'atelier.
 */
@Composable
fun ModeIconTile(
    label: String,
    iconAsset: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    selected: Boolean = false,
    enabled: Boolean = true
) {
    val border = if (selected) AgwDecor.SilverBorderStrong else AgwDecor.SilverBorder
    val bg = if (selected) AgwColors.SilverMuted.copy(alpha = 0.35f) else AgwColors.CrystalGlassSoft
    val bmp = rememberAssetBitmap(iconAsset)
    val fade = if (enabled) 1f else 0.45f

    Column(
        modifier = modifier
            .clip(AgwDecor.TileShape)
            .background(bg)
            .border(border, AgwDecor.TileShape)
            .alpha(fade)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Médaillon logo : anneau argent double, fond très léger
        Box(
            Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            AgwColors.SilverSoft.copy(alpha = 0.18f),
                            AgwColors.DeepNight.copy(alpha = 0.35f)
                        )
                    )
                )
                .border(1.dp, AgwColors.SilverSoft.copy(alpha = 0.7f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .border(0.7.dp, AgwColors.SilverMuted.copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (bmp != null) {
                    Image(
                        bitmap = bmp,
                        contentDescription = label,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.size(34.dp)
                    )
                } else {
                    Text("◆", color = AgwColors.SilverSoft, fontSize = 20.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            label,
            color = if (selected) AgwColors.SilverSoft else AgwColors.PaleMarble,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
        if (subtitle != null) {
            Text(
                subtitle,
                color = if (selected) AgwColors.SilverMuted else AgwColors.Sand,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ModeIconChip(
    label: String,
    iconAsset: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bmp = rememberAssetBitmap(iconAsset)
    val bg = if (selected) AgwColors.SilverSoft.copy(alpha = 0.85f) else AgwColors.CrystalGlass
    val fg = if (selected) AgwColors.DeepNight else AgwColors.PaleMarble
    Row(
        modifier = modifier
            .clip(AgwDecor.ChipShape)
            .background(bg)
            .border(
                if (selected) BorderStroke(1.dp, AgwColors.SilverSoft) else AgwDecor.SilverBorder,
                AgwDecor.ChipShape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(22.dp)
            )
        }
        Text(label, color = fg, fontWeight = FontWeight.Medium, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(bottom = 6.dp),
        fontWeight = FontWeight.Bold,
        color = AgwColors.SilverSoft,
        fontSize = 16.sp,
        letterSpacing = 0.3.sp
    )
}

@Composable
fun GoldDivider(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        AgwColors.SilverSoft.copy(alpha = 0.45f),
                        Color.Transparent
                    )
                )
            )
    )
}

@Composable
fun IconBadge(
    iconAsset: String,
    size: Dp = 36.dp
) {
    val bmp = rememberAssetBitmap(iconAsset)
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(AgwColors.CrystalGlass)
            .border(1.dp, AgwColors.SilverSoft.copy(alpha = 0.65f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(size * 0.78f))
        }
    }
}

@Composable
fun StatusPill(text: String, ok: Boolean = true) {
    val dot = if (ok) AgwColors.Success else AgwColors.Warning
    Row(
        modifier = Modifier
            .clip(AgwDecor.ChipShape)
            .background(dot.copy(alpha = 0.12f))
            .border(1.dp, dot.copy(alpha = 0.35f), AgwDecor.ChipShape)
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(dot))
        Text(text, color = dot, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
    }
}


@Composable
fun ForgeStatusRow(
    label: String,
    detail: String,
    state: String,
    ok: Boolean = true,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(AgwDecor.ChipShape)
            .background(AgwColors.NightGlassSoft)
            .border(1.dp, AgwColors.Outline, AgwDecor.ChipShape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = AgwColors.PaleMarble, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(detail, color = AgwColors.Sand, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        StatusPill(state, ok)
    }
}

@Composable
fun ForgeMetric(
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(AgwDecor.ChipShape)
            .background(AgwColors.DeepNight.copy(alpha = 0.48f))
            .border(1.dp, AgwColors.Outline, AgwDecor.ChipShape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text(value, color = AgwColors.GoldSoft, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Text(label, color = AgwColors.Sand, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ForgeSectionCard(
    title: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable (() -> Unit))? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(AgwDecor.GoldBorder, AgwDecor.CardShape),
        shape = AgwDecor.CardShape,
        colors = CardDefaults.cardColors(containerColor = AgwColors.CrystalGlass),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = AgwColors.GoldSoft, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                trailing?.invoke()
            }
            content()
        }
    }
}

@Composable
fun NavAssetIcon(asset: String, selected: Boolean = false) {
    val bmp = rememberAssetBitmap(asset)
    Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(22.dp).alpha(if (selected) 1f else 0.72f))
        } else {
            Box(Modifier.size(7.dp).clip(CircleShape).background(if (selected) AgwColors.SacredGold else AgwColors.Sand))
        }
    }
}
