package com.sbh.studio.workshop

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle

@Composable
internal fun EntityZone(
    projectId: String,
    entities: List<SceneEntity>,
    maps: List<MapBlueprint>,
    hasProject: Boolean,
    onSave: (SceneEntity) -> Unit,
    onDelete: (SceneEntity) -> Unit,
    onMessage: (String) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var name by rememberSaveable { mutableStateOf("Nouvel objet") }
    var type by rememberSaveable { mutableStateOf(SceneEntityType.OBJECT.name) }
    var linkedMapId by rememberSaveable { mutableStateOf<String?>(null) }
    var posX by rememberSaveable { mutableStateOf("0") }
    var posY by rememberSaveable { mutableStateOf("0") }
    var posZ by rememberSaveable { mutableStateOf("0") }
    var rotY by rememberSaveable { mutableStateOf("0") }
    var scale by rememberSaveable { mutableStateOf("1") }
    var notes by rememberSaveable { mutableStateOf("") }
    var glbName by rememberSaveable { mutableStateOf("") }

    fun reset() {
        editingId = null
        name = "Nouvel objet"
        type = SceneEntityType.OBJECT.name
        linkedMapId = null
        posX = "0"; posY = "0"; posZ = "0"
        rotY = "0"; scale = "1"
        notes = ""; glbName = ""
    }

    fun load(e: SceneEntity) {
        editingId = e.id
        name = e.name
        type = e.type.name
        linkedMapId = e.linkedMapId
        posX = e.posX.toString()
        posY = e.posY.toString()
        posZ = e.posZ.toString()
        rotY = e.rotY.toString()
        scale = e.scale.toString()
        notes = e.notes
        glbName = e.glbName.orEmpty()
    }

    fun submit() {
        if (!hasProject) {
            onMessage("Ouvrez un projet avant d'ajouter une entité")
            return
        }
        val entity = SceneEntity(
            id = editingId ?: java.util.UUID.randomUUID().toString(),
            projectId = projectId,
            name = name.trim().ifBlank { "Entité" },
            type = runCatching { SceneEntityType.valueOf(type) }.getOrDefault(SceneEntityType.OBJECT),
            glbName = glbName.trim().ifBlank { null },
            linkedMapId = linkedMapId,
            posX = posX.replace(',', '.').toFloatOrNull() ?: 0f,
            posY = posY.replace(',', '.').toFloatOrNull() ?: 0f,
            posZ = posZ.replace(',', '.').toFloatOrNull() ?: 0f,
            rotY = rotY.replace(',', '.').toFloatOrNull() ?: 0f,
            scale = (scale.replace(',', '.').toFloatOrNull() ?: 1f).coerceIn(0.05f, 50f),
            notes = notes
        )
        onSave(entity)
        reset()
        onMessage(if (editingId != null) "Entité mise à jour" else "Entité ajoutée")
    }

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.verticalScroll(rememberScrollState())
    ) {
        Text("Entités 3D · Objets / Personnages / Véhicules", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text(
            "Couche indépendante des voxels. Placez les .glb dans Map Studio ; l'atelier garde l'identité, le type, le transform et le lien map.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        OutlinedTextField(
            name, { name = it },
            label = { Text("Nom") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Type", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SceneEntityType.entries.forEach { t ->
                FilterChip(
                    selected = type == t.name,
                    onClick = { type = t.name },
                    label = {
                        Text(
                            when (t) {
                                SceneEntityType.OBJECT -> "Objet"
                                SceneEntityType.CHARACTER -> "Personnage"
                                SceneEntityType.VEHICLE -> "Véhicule"
                            },
                            fontSize = 11.sp
                        )
                    }
                )
            }
        }

        OutlinedTextField(
            glbName, { glbName = it },
            label = { Text("Nom fichier .glb (optionnel)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Map liée", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            FilterChip(
                selected = linkedMapId == null,
                onClick = { linkedMapId = null },
                label = { Text("Aucune", fontSize = 11.sp) }
            )
            maps.take(6).forEach { m ->
                FilterChip(
                    selected = linkedMapId == m.id,
                    onClick = { linkedMapId = m.id },
                    label = { Text(m.name.take(14), fontSize = 11.sp) }
                )
            }
        }

        Text("Transform", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(posX, { posX = it }, label = { Text("X") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(posY, { posY = it }, label = { Text("Y") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(posZ, { posZ = it }, label = { Text("Z") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(rotY, { rotY = it }, label = { Text("Rot Y °") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(scale, { scale = it }, label = { Text("Échelle") }, modifier = Modifier.weight(1f), singleLine = true)
        }

        OutlinedTextField(
            notes, { notes = it },
            label = { Text("Notes") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldPrimaryButton(
                if (editingId != null) "Mettre à jour" else "Ajouter",
                onClick = { submit() },
                modifier = Modifier.weight(1f)
            )
            if (editingId != null) {
                GoldOutlineButton("Annuler", onClick = { reset() }, modifier = Modifier.weight(1f))
            }
        }

        SectionTitle("Entités du projet (${entities.size})")
        if (entities.isEmpty()) {
            Text(
                "Aucune entité. Créez-en une ici ou placez des .glb dans Map Studio (ils pourront remonter ensuite).",
                color = AgwColors.Sand
            )
        } else {
            entities.forEach { e ->
                val mapName = maps.firstOrNull { it.id == e.linkedMapId }?.name ?: "—"
                val typeLabel = when (e.type) {
                    SceneEntityType.OBJECT -> "Objet"
                    SceneEntityType.CHARACTER -> "Personnage"
                    SceneEntityType.VEHICLE -> "Véhicule"
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                            Text(
                                "$typeLabel · map: $mapName",
                                color = AgwColors.Sand,
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                "pos (${e.posX}, ${e.posY}, ${e.posZ}) · rotY ${e.rotY}° · ×${e.scale}" +
                                    (e.glbName?.let { " · $it" } ?: ""),
                                color = AgwColors.DesertOchre,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        TextButton(onClick = { load(e) }) {
                            Text("Éditer", color = AgwColors.GoldSoft)
                        }
                        TextButton(onClick = { onDelete(e); if (editingId == e.id) reset() }) {
                            Text("Suppr.", color = Color(0xFFB94E48))
                        }
                    }
                }
            }
        }
    }
}
