package com.sbh.studio.communication

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.sbh.studio.data.Identifiers
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.data.SbhSound
import com.sbh.studio.workshop.MapBlueprint
import com.sbh.studio.workshop.PortalBlueprint
import com.sbh.studio.workshop.RecipeBlueprint
import com.sbh.studio.workshop.SceneEntity
import java.io.File
import java.util.UUID

/**
 * SBh Validation Engine
 *
 * Moteur de validation centralisé.
 * Produit de vrais [ReportEntry] structurés et les enregistre via le [SBhCommunicationCore].
 *
 * Flux :
 *   AdvancedPackEngine / export
 *     → SBhValidationEngine.validate(...)
 *     → SBhCommunicationCore (SBhReport + ExportRecord)
 *
 * Ne dépend pas de Map Studio, Factions ou Mobs en tant que modules.
 * Il reçoit uniquement les données nécessaires et reste agnostique.
 *
 * Ne prétend jamais confirmer un import Minecraft (impossible à observer de façon fiable).
 */
class SBhValidationEngine(
    private val context: Context,
    private val core: SBhCommunicationCore
) {

    data class ValidationResult(
        val report: SBhReport,
        val blocking: Boolean,          // true = export doit être bloqué
        val entries: List<ReportEntry>
    )

    /**
     * Point d'entrée principal.
     * Crée un SBhReport, exécute toutes les validations utiles, met à jour le Core.
     */
    fun validate(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint> = emptyList(),
        maps: List<MapBlueprint> = emptyList(),
        recipes: List<RecipeBlueprint> = emptyList(),
        entities: List<SceneEntity> = emptyList(),
        sounds: List<SbhSound> = emptyList(),
        studioVersion: String = ""
    ): ValidationResult {
        var report = core.createReport(
            projectId = project.id,
            projectName = project.name,
            projectVersion = project.version,
            studioVersion = studioVersion,
            projectType = "Minecraft Bedrock Add-on"
        )

        report = core.updateStatus(report, ExportStatus.VALIDATING)

        val entries = mutableListOf<ReportEntry>()

        // ── 1. Structure du projet ──────────────────────────────────────────
        entries += validateProjectStructure(project)

        // ── 2. Contenu vide ─────────────────────────────────────────────────
        entries += validateContentPresence(mobs, items, blocks, portals)

        // ── 3. Identifiants (validité + collisions) ─────────────────────────
        entries += validateIdentifiers(mobs, items, blocks, portals)

        // ── 4. Valeurs numériques / cohérence métier ────────────────────────
        entries += validateNumericRanges(mobs, items, blocks)

        // ── 5. Textures référencées ─────────────────────────────────────────
        entries += validateTextures(mobs, items, blocks)

        // ── 6. Portails (données fournies, pas le module Map Studio) ────────
        entries += validatePortals(portals, maps)

        // ── 7. Maps (données fournies uniquement) ───────────────────────────
        entries += validateMaps(maps, mobs, items, blocks)

        // ── 8. Recettes (résultat + ingrédients) ─────────────────────────────
        entries += validateRecipes(recipes, items, blocks)

        // ── 9. Entités 3D (liens map + transforms) ───────────────────────────
        entries += validateEntities(entities, maps)

        // ── 10. Sons (format export) ─────────────────────────────────────────
        entries += validateSounds(sounds)

        // ── 11. UUID de packs persistants (format) ───────────────────────────
        entries += validatePackUuids(project.id)

        // Enregistre toutes les entrées
        if (entries.isNotEmpty()) {
            report = core.addEntries(report, entries)
        }

        val hasCritical = entries.any { it.level == ReportLevel.CRITICAL }
        val hasError = entries.any { it.level == ReportLevel.ERROR }
        val blocking = hasCritical || hasError

        val finalStatus = when {
            blocking -> ExportStatus.BLOCKED
            entries.any { it.level == ReportLevel.WARNING } -> ExportStatus.READY_TO_SEND
            else -> ExportStatus.READY_TO_SEND
        }
        report = core.updateStatus(report, finalStatus)

        // Info de synthèse
        if (!blocking) {
            report = core.addEntry(
                report,
                core.info(
                    LifecycleStep.VALIDATE,
                    "Validation terminée",
                    "Aucune erreur bloquante. ${entries.count { it.level == ReportLevel.WARNING }} avertissement(s)."
                )
            )
        }

        return ValidationResult(report = report, blocking = blocking, entries = entries)
    }

    // =========================================================================
    // Validations individuelles
    // =========================================================================

    private fun validateProjectStructure(project: SbhProject): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()

        if (project.name.isBlank()) {
            out += core.critical(
                step = LifecycleStep.VALIDATE,
                title = "Nom de projet manquant",
                detail = "Le projet doit avoir un nom non vide.",
                cause = "Champ name vide ou composé uniquement d'espaces.",
                suggestedFix = "Donner un nom au projet avant d'exporter.",
                code = SBhErrorCode.MANIFEST_INVALID
            )
        } else if (project.name.length > 64) {
            out += core.warning(
                step = LifecycleStep.VALIDATE,
                title = "Nom de projet très long",
                detail = "« ${project.name} » dépasse 64 caractères. Peut poser problème dans certains contextes Minecraft.",
                code = SBhErrorCode("SBH-ERR-005", "Nom trop long")
            )
        }

        if (project.version.isBlank()) {
            out += core.warning(
                step = LifecycleStep.VALIDATE,
                title = "Version de projet manquante",
                detail = "Aucune version renseignée. Une version par défaut sera utilisée dans le manifest.",
                code = SBhErrorCode("SBH-ERR-006", "Version manquante")
            )
        } else {
            val parts = project.version.split('.')
            if (parts.any { it.toIntOrNull() == null }) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Format de version non numérique",
                    detail = "Version « ${project.version} ». Minecraft attend généralement major.minor.patch (ex. 1.0.0).",
                    code = SBhErrorCode("SBH-ERR-007", "Version invalide")
                )
            }
        }

        return out
    }

    private fun validateContentPresence(
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint>
    ): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()
        if (mobs.isEmpty() && items.isEmpty() && blocks.isEmpty() && portals.isEmpty()) {
            out += core.warning(
                step = LifecycleStep.VALIDATE,
                title = "Pack quasi vide",
                detail = "Aucun contenu (créature, item, bloc ou portail). Le pack sera techniquement valide mais inutile.",
                code = SBhErrorCode.PACK_EMPTY,
                suggestedFix = "Ajouter au moins un élément de contenu avant d'exporter."
            )
        }
        return out
    }

    private fun validateIdentifiers(
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint>
    ): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()

        fun checkId(kind: String, name: String, id: String) {
            Identifiers.explain(id)?.let { reason ->
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Identifiant invalide ($kind)",
                    detail = "« $name » → $id",
                    cause = reason,
                    suggestedFix = "Corriger l'identifiant au format namespace:nom (ex. agw:mon_item).",
                    code = SBhErrorCode.IDENTIFIER_INVALID,
                    file = null
                )
            }
        }

        mobs.forEach { checkId("Créature", it.nom, it.identifiant) }
        items.forEach { checkId("Item", it.name, it.identifier) }
        blocks.forEach { checkId("Bloc", it.name, it.identifier) }
        portals.forEach { checkId("Portail", it.name, it.identifier) }

        // Collisions d'identifiants exacts
        val all = mutableListOf<Pair<String, String>>() // id → label
        mobs.forEach { all += it.identifiant to "Créature « ${it.nom} »" }
        items.forEach { all += it.identifier to "Item « ${it.name} »" }
        blocks.forEach { all += it.identifier to "Bloc « ${it.name} »" }
        portals.forEach { all += it.identifier to "Portail « ${it.name} »" }

        all.groupBy { it.first }
            .filter { it.value.size > 1 }
            .forEach { (id, list) ->
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Identifiant en double",
                    detail = "« $id » utilisé par : ${list.joinToString { it.second }}",
                    cause = "Deux contenus partagent le même identifiant exact.",
                    suggestedFix = "Rendre chaque identifiant unique.",
                    code = SBhErrorCode.UUID_COLLISION
                )
            }

        // Collisions de clé de texture (namespace_name)
        fun textureKey(id: String) = id.replace(':', '_')
        all.filter { Identifiers.isValid(it.first) }
            .groupBy { textureKey(it.first) }
            .filter { it.value.size > 1 }
            .forEach { (key, list) ->
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Collision de clé de texture",
                    detail = "Clé « $key » partagée par : ${list.joinToString { it.second }}",
                    cause = "Des identifiants différents produisent la même clé de fichier texture.",
                    suggestedFix = "Modifier un des identifiants pour éviter le conflit de nom de fichier.",
                    code = SBhErrorCode("SBH-ERR-011", "Collision texture")
                )
            }

        return out
    }

    private fun validateNumericRanges(
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>
    ): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()

        mobs.forEach { m ->
            if (m.vie <= 0) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Vie invalide",
                    detail = "Créature « ${m.nom} » : vie = ${m.vie}",
                    cause = "La vie doit être strictement positive.",
                    suggestedFix = "Mettre une valeur de vie > 0.",
                    code = SBhErrorCode("SBH-ERR-012", "Stat invalide")
                )
            }
            if (m.degats < 0) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Dégâts invalides",
                    detail = "Créature « ${m.nom} » : dégâts = ${m.degats}",
                    cause = "Les dégâts ne peuvent pas être négatifs.",
                    suggestedFix = "Mettre des dégâts ≥ 0.",
                    code = SBhErrorCode("SBH-ERR-012", "Stat invalide")
                )
            }
            if (m.vitesse <= 0) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Vitesse invalide",
                    detail = "Créature « ${m.nom} » : vitesse = ${m.vitesse}",
                    cause = "La vitesse doit être strictement positive.",
                    suggestedFix = "Mettre une vitesse > 0.",
                    code = SBhErrorCode("SBH-ERR-012", "Stat invalide")
                )
            }
            if (m.detectionDistance < 0 || m.detectionDistance > 128) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Distance de détection inhabituelle",
                    detail = "Créature « ${m.nom} » : detectionDistance = ${m.detectionDistance}",
                    code = SBhErrorCode("SBH-ERR-013", "Stat limite")
                )
            }
        }

        items.forEach { i ->
            if (i.damage < 0) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Dégâts d'item invalides",
                    detail = "Item « ${i.name} » : damage = ${i.damage}",
                    cause = "Les dégâts ne peuvent pas être négatifs.",
                    suggestedFix = "Mettre damage ≥ 0.",
                    code = SBhErrorCode("SBH-ERR-012", "Stat invalide")
                )
            }
            if (i.durability <= 0) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Durabilité invalide",
                    detail = "Item « ${i.name} » : durability = ${i.durability}",
                    cause = "La durabilité doit être strictement positive.",
                    suggestedFix = "Mettre durability > 0.",
                    code = SBhErrorCode("SBH-ERR-012", "Stat invalide")
                )
            }
        }

        blocks.forEach { b ->
            if (b.hardness < 0) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Résistance de bloc invalide",
                    detail = "Bloc « ${b.name} » : hardness = ${b.hardness}",
                    cause = "La résistance ne peut pas être négative.",
                    suggestedFix = "Mettre hardness ≥ 0.",
                    code = SBhErrorCode("SBH-ERR-012", "Stat invalide")
                )
            }
        }

        return out
    }

    /**
     * Vérifie les textures référencées.
     * - null → WARNING (placeholder sera généré)
     * - URI illisible / fichier inaccessible → ERROR (ou WARNING selon criticité)
     * On ne peut pas garantir que Minecraft affichera correctement la texture ;
     * on vérifie seulement ce que SBh Studio peut observer (accès local).
     */
    private fun validateTextures(
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>
    ): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()

        fun checkTexture(kind: String, name: String, uri: String?, expectedPathHint: String) {
            if (uri.isNullOrBlank()) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Texture manquante ($kind)",
                    detail = "« $name » n'a pas de texture. Une texture provisoire sera générée.",
                    file = expectedPathHint,
                    cause = "Aucune URI de texture fournie.",
                    suggestedFix = "Ajouter une texture dans l'éditeur, ou laisser le placeholder.",
                    code = SBhErrorCode.TEXTURE_MISSING
                )
                return
            }

            val readable = isTextureReadable(uri)
            if (!readable) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Texture illisible ($kind)",
                    detail = "« $name » → $uri",
                    file = expectedPathHint,
                    cause = "Le fichier de texture est inaccessible, déplacé, supprimé ou dans un format non lisible.",
                    suggestedFix = "Resélectionner la texture ou vérifier les permissions d'accès au fichier.",
                    code = SBhErrorCode.TEXTURE_MISSING,
                    autoRepairable = false
                )
            }
        }

        mobs.forEach { m ->
            val key = m.identifiant.replace(':', '_')
            checkTexture("Créature", m.nom, m.textureUri, "textures/entity/$key.png")
        }
        items.forEach { i ->
            val key = i.identifier.replace(':', '_')
            checkTexture("Item", i.name, i.textureUri, "textures/items/$key.png")
        }
        blocks.forEach { b ->
            val key = b.identifier.replace(':', '_')
            checkTexture("Bloc", b.name, b.textureUri, "textures/blocks/$key.png")
        }

        return out
    }

    private fun isTextureReadable(uriString: String): Boolean {
        return try {
            val uri = Uri.parse(uriString)
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
            opts.outWidth > 0 && opts.outHeight > 0
        } catch (_: Exception) {
            false
        }
    }

    private fun validatePortals(
        portals: List<PortalBlueprint>,
        maps: List<MapBlueprint>
    ): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()
        val validDimensions = setOf("minecraft:overworld", "minecraft:nether", "minecraft:the_end")

        portals.forEach { p ->
            if (p.width < 2 || p.height < 3) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Taille de portail trop petite",
                    detail = "Portail « ${p.name} » : ${p.width}×${p.height}",
                    cause = "Taille minimale requise : 2×3.",
                    suggestedFix = "Augmenter width ≥ 2 et height ≥ 3.",
                    code = SBhErrorCode("SBH-ERR-021", "Portail invalide")
                )
            }
            if (p.width > 16 || p.height > 16) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Portail très grand",
                    detail = "Portail « ${p.name} » : ${p.width}×${p.height}. Peut impacter les performances.",
                    code = SBhErrorCode("SBH-ERR-022", "Portail limite")
                )
            }
            if (p.destDimension !in validDimensions) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Dimension de destination invalide",
                    detail = "Portail « ${p.name} » → ${p.destDimension}",
                    cause = "Dimension non reconnue. Valeurs acceptées : overworld, nether, the_end.",
                    suggestedFix = "Choisir une dimension Minecraft valide.",
                    code = SBhErrorCode("SBH-ERR-023", "Dimension invalide")
                )
            }
            if (p.destY < -64 || p.destY > 320) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Altitude de destination hors limites",
                    detail = "Portail « ${p.name} » : Y = ${p.destY}",
                    cause = "Y doit être entre -64 et 320.",
                    suggestedFix = "Corriger la coordonnée Y.",
                    code = SBhErrorCode("SBH-ERR-024", "Coordonnée invalide")
                )
            }
            if (p.linkedMapId != null && maps.none { it.id == p.linkedMapId }) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Map liée introuvable",
                    detail = "Portail « ${p.name} » référence la map ${p.linkedMapId} qui n'existe plus.",
                    cause = "Référence cassée vers une map supprimée ou inexistante.",
                    suggestedFix = "Retirer le lien ou restaurer la map.",
                    code = SBhErrorCode.DEPENDENCY_MISSING
                )
            }
            if (p.linkedMapId != null) {
                val linked = maps.find { it.id == p.linkedMapId }
                if (linked != null && (p.mapX < 0 || p.mapX >= linked.sizeX || p.mapZ < 0 || p.mapZ >= linked.sizeZ)) {
                    out += core.warning(
                        step = LifecycleStep.VALIDATE,
                        title = "Position hors de la map liée",
                        detail = "Portail « ${p.name} » : pos (${p.mapX}, ${p.mapZ}) hors de ${linked.sizeX}×${linked.sizeZ}.",
                        code = SBhErrorCode("SBH-ERR-027", "Position map")
                    )
                }
            }
        }
        return out
    }

    private fun validateMaps(
        maps: List<MapBlueprint>,
        mobs: List<MobEntity> = emptyList(),
        items: List<SbhItem> = emptyList(),
        blocks: List<SbhBlock> = emptyList()
    ): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()
        val mobIds = mobs.map { it.id }.toSet()
        val itemIds = items.map { it.id }.toSet()
        val blockIds = blocks.map { it.id }.toSet()
        maps.forEach { m ->
            if (m.sizeX < 8 || m.sizeZ < 8) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Map trop petite",
                    detail = "Map « ${m.name} » : ${m.sizeX}×${m.sizeZ}",
                    cause = "Taille minimale : 8×8.",
                    suggestedFix = "Augmenter sizeX et sizeZ.",
                    code = SBhErrorCode("SBH-ERR-025", "Map invalide")
                )
            }
            if (m.sizeX * m.sizeZ > 128 * 128) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Map très large",
                    detail = "Map « ${m.name} » : ${m.sizeX}×${m.sizeZ}. Peut être lourd pour Bedrock.",
                    code = SBhErrorCode("SBH-ERR-026", "Map limite")
                )
            }
            // Liens croisés map → mobs / items / blocs
            m.linkedMobIds.filter { it !in mobIds }.forEach { missing ->
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Mob lié introuvable",
                    detail = "Map « ${m.name} » référence le mob $missing qui n'existe plus.",
                    cause = "Référence cassée (mob supprimé ou autre projet).",
                    suggestedFix = "Retirer le lien ou restaurer le monstre dans l'atelier.",
                    code = SBhErrorCode.DEPENDENCY_MISSING
                )
            }
            m.linkedItemIds.filter { it !in itemIds }.forEach { missing ->
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Item lié introuvable",
                    detail = "Map « ${m.name} » référence l'item $missing qui n'existe plus.",
                    cause = "Référence cassée (item supprimé ou autre projet).",
                    suggestedFix = "Retirer le lien ou restaurer l'item.",
                    code = SBhErrorCode.DEPENDENCY_MISSING
                )
            }
            m.linkedBlockIds.filter { it !in blockIds }.forEach { missing ->
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Bloc lié introuvable",
                    detail = "Map « ${m.name} » référence le bloc $missing qui n'existe plus.",
                    cause = "Référence cassée (bloc supprimé ou autre projet).",
                    suggestedFix = "Retirer le lien ou restaurer le bloc.",
                    code = SBhErrorCode.DEPENDENCY_MISSING
                )
            }
        }
        return out
    }

    private fun validateRecipes(
        recipes: List<RecipeBlueprint>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>
    ): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()
        val knownIds = (items.map { it.identifier } + blocks.map { it.identifier }).toSet()
        val knownMinecraft = { id: String ->
            id.startsWith("minecraft:") || id.startsWith("agw:") || id.startsWith("sbh:") || id in knownIds
        }
        recipes.forEach { r ->
            if (r.name.isBlank()) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Recette sans nom",
                    detail = "Identifiant « ${r.identifier} ».",
                    code = SBhErrorCode("SBH-ERR-030", "Recette")
                )
            }
            Identifiers.explain(r.identifier)?.let { msg ->
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Identifiant de recette invalide",
                    detail = "Recette « ${r.name} » : $msg (${r.identifier})",
                    cause = msg,
                    suggestedFix = "Corriger le format namespace:id.",
                    code = SBhErrorCode("SBH-ERR-031", "Identifiant")
                )
            }
            if (r.resultId.isBlank()) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Résultat de recette manquant",
                    detail = "Recette « ${r.name} » n'a pas de resultId.",
                    suggestedFix = "Indiquer l'identifiant de l'item produit.",
                    code = SBhErrorCode.DEPENDENCY_MISSING
                )
            } else if (r.resultId !in knownIds && !r.resultId.startsWith("minecraft:")) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Résultat hors projet",
                    detail = "Recette « ${r.name} » → « ${r.resultId} » n'est pas un item/bloc du projet.",
                    cause = "Le résultat peut être un vanilla ou un pack externe.",
                    suggestedFix = "Créer l'item dans l'atelier ou utiliser un id minecraft:.",
                    code = SBhErrorCode("SBH-ERR-032", "Résultat recette")
                )
            }
            if (r.resultCount < 1 || r.resultCount > 64) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Quantité résultat invalide",
                    detail = "Recette « ${r.name} » : qté ${r.resultCount}",
                    cause = "Doit être entre 1 et 64.",
                    suggestedFix = "Ajuster resultCount.",
                    code = SBhErrorCode("SBH-ERR-033", "Quantité")
                )
            }
            if (r.type.contains("shaped") && r.pattern.all { it.isBlank() }) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Grille shaped vide",
                    detail = "Recette « ${r.name} » : aucune case renseignée.",
                    suggestedFix = "Remplir au moins une case de la grille 3×3.",
                    code = SBhErrorCode("SBH-ERR-034", "Grille vide")
                )
            }
            if (r.type.contains("shapeless") && r.ingredients.isEmpty()) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Ingrédients shapeless absents",
                    detail = "Recette « ${r.name} ».",
                    suggestedFix = "Ajouter au moins un ingrédient.",
                    code = SBhErrorCode("SBH-ERR-035", "Ingrédients")
                )
            }
            // Ingrédients pattern non vides inconnus → warning
            val cells = if (r.type.contains("shaped")) r.pattern.filter { it.isNotBlank() } else r.ingredients
            cells.filter { !knownMinecraft(it) }.forEach { cell ->
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Ingrédient non résolu",
                    detail = "Recette « ${r.name} » utilise « $cell » absent du projet.",
                    code = SBhErrorCode("SBH-ERR-036", "Ingrédient")
                )
            }
        }
        return out
    }

    private fun validateEntities(
        entities: List<SceneEntity>,
        maps: List<MapBlueprint>
    ): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()
        val mapIds = maps.map { it.id }.toSet()
        entities.forEach { e ->
            if (e.name.isBlank()) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Entité 3D sans nom",
                    detail = "id=${e.id}",
                    code = SBhErrorCode("SBH-ERR-040", "Entité")
                )
            }
            if (e.linkedMapId != null && e.linkedMapId !in mapIds) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Map d'entité introuvable",
                    detail = "Entité « ${e.name} » → map ${e.linkedMapId} inexistante.",
                    cause = "Référence cassée.",
                    suggestedFix = "Retirer le lien ou restaurer la map.",
                    code = SBhErrorCode.DEPENDENCY_MISSING
                )
            }
            if (e.scale < 0.05f || e.scale > 50f) {
                out += core.error(
                    step = LifecycleStep.VALIDATE,
                    title = "Échelle d'entité hors limites",
                    detail = "Entité « ${e.name} » : scale=${e.scale}",
                    cause = "Échelle autorisée : 0.05 à 50.",
                    suggestedFix = "Corriger l'échelle.",
                    code = SBhErrorCode("SBH-ERR-041", "Échelle")
                )
            }
            if (e.glbUri.isNullOrBlank() && e.glbName.isNullOrBlank()) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Entité sans fichier .glb",
                    detail = "Entité « ${e.name} » : placeholder uniquement côté Map Studio.",
                    suggestedFix = "Importer un .glb dans Map Studio ou renseigner glbName.",
                    code = SBhErrorCode("SBH-ERR-042", "GLB manquant")
                )
            }
        }
        return out
    }

    private fun validateSounds(sounds: List<SbhSound>): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()
        sounds.filter { it.includeInPack }.forEach { s ->
            if (!s.extension.equals("ogg", ignoreCase = true)) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Son non-Ogg dans le pack",
                    detail = "« ${s.name} » (.${s.extension}). Minecraft Bedrock préfère Ogg.",
                    suggestedFix = "Convertir en Ogg avant export (outil Nashid).",
                    code = SBhErrorCode("SBH-ERR-050", "Format audio")
                )
            }
            if (s.soundEvent.isBlank()) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Événement sonore manquant",
                    detail = "« ${s.name} » n'a pas d'événement Minecraft assigné.",
                    suggestedFix = "Choisir music.game, music.menu, etc.",
                    code = SBhErrorCode("SBH-ERR-051", "Événement audio")
                )
            }
        }
        return out
    }

    /**
     * Vérifie uniquement le format des UUID de packs déjà stockés.
     * Ne génère pas de nouveaux UUID ici (responsabilité de PackGenerator).
     */
    private fun validatePackUuids(projectId: String): List<ReportEntry> {
        val out = mutableListOf<ReportEntry>()
        val safeId = projectId.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
        val file = File(context.filesDir, "sbh_pack_ids_$safeId.json")
        if (!file.exists()) {
            // Pas encore d'UUID → normal pour un premier export. Info seulement.
            out += core.info(
                step = LifecycleStep.VALIDATE,
                title = "UUID de packs absents",
                detail = "Aucun UUID persistant trouvé pour ce projet. Ils seront générés lors de l'export."
            )
            return out
        }

        try {
            val text = file.readText()
            // Vérification très légère : présence de chaînes ressemblant à des UUID
            val uuidRegex = Regex("""[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}""")
            val found = uuidRegex.findAll(text).map { it.value }.toList()
            if (found.isEmpty()) {
                out += core.warning(
                    step = LifecycleStep.VALIDATE,
                    title = "Fichier UUID de packs illisible",
                    detail = "Le fichier sbh_pack_ids_$safeId.json existe mais ne contient aucun UUID reconnu.",
                    file = file.absolutePath,
                    cause = "Fichier corrompu ou format inattendu.",
                    suggestedFix = "Supprimer le fichier pour forcer la régénération des UUID au prochain export.",
                    code = SBhErrorCode.UUID_INVALID
                )
            } else {
                found.forEach { u ->
                    try {
                        UUID.fromString(u)
                    } catch (_: Exception) {
                        out += core.error(
                            step = LifecycleStep.VALIDATE,
                            title = "UUID de pack invalide",
                            detail = u,
                            file = file.absolutePath,
                            cause = "Format UUID incorrect.",
                            suggestedFix = "Supprimer le fichier d'UUID pour régénération.",
                            code = SBhErrorCode.UUID_INVALID,
                            autoRepairable = true
                        )
                    }
                }
            }
        } catch (e: Exception) {
            out += core.warning(
                step = LifecycleStep.VALIDATE,
                title = "Impossible de lire les UUID de packs",
                detail = e.message ?: "Erreur de lecture",
                file = file.absolutePath,
                code = SBhErrorCode.UUID_INVALID
            )
        }
        return out
    }
}
