package com.sbh.studio.character

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import io.github.sceneview.SceneView
import io.github.sceneview.math.Position
import io.github.sceneview.rememberCameraManipulator
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberModelInstance
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberModelLoader
import io.github.sceneview.rememberMainLightNode
import io.github.sceneview.node.ModelNode

/** Véritable viewport 3D du Character Studio. Les GLB/GLTF sont rendus par Filament via SceneView. */
@Composable
fun CharacterPreview3D(
    modelUri: String?,
    fallbackAsset: String = "models/sbh_mannequin.glb",
    modifier: Modifier = Modifier
) {
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    val location = modelUri?.takeIf { it.isNotBlank() } ?: fallbackAsset
    val instance = rememberModelInstance(modelLoader, location)

    Box(
        modifier = modifier
            .background(AgwColors.DeepNight, RoundedCornerShape(18.dp))
    ) {
        SceneView(
            modifier = Modifier.fillMaxSize(),
            engine = engine,
            modelLoader = modelLoader,
            cameraManipulator = rememberCameraManipulator(),
            cameraNode = rememberCameraNode(engine) { position = Position(z = 4f) },
            mainLightNode = rememberMainLightNode(engine) { intensity = 90_000f }
        ) {
            instance?.let {
                ModelNode(
                    modelInstance = it,
                    scaleToUnits = 1.8f,
                    autoAnimate = false,
                    position = Position(y = -0.9f)
                )
            }
        }

        if (instance == null) {
            GlassCard(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Chargement du modèle 3D…", color = AgwColors.PaleMarble)
                    Text(
                        "GLB / GLTF",
                        color = AgwColors.SilverMuted,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
fun CharacterPreviewPanel(
    character: CharacterProject,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(character.name, color = AgwColors.PaleMarble, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (character.modelUri.isNullOrBlank()) "Aperçu mannequin de test · aucun modèle importé"
                    else "Modèle importé · ${character.modelName ?: "GLB/GLTF"}",
                    color = AgwColors.SilverMuted,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        CharacterPreview3D(
            modelUri = character.modelUri,
            modifier = Modifier.fillMaxWidth().height(360.dp)
        )
        Text(
            "Touchez et faites glisser pour orbiter autour du modèle · pincez pour zoomer.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
