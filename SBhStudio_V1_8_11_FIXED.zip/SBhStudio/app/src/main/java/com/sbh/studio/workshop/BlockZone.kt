package com.sbh.studio.workshop

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors

@Composable
internal fun BlockZone(
    projectId: String,
    blocks: List<SbhBlock>,
    textures: List<TextureProject> = emptyList(),
    onAdd: (SbhBlock) -> Unit,
    onDelete: (SbhBlock) -> Unit
) {
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("Nouveau bloc") }
    var id by rememberSaveable { mutableStateOf("agw:nouveau_bloc") }
    var hardness by rememberSaveable { mutableStateOf("1.0") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Blocs & architecture", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(hardness, { hardness = it }, label = { Text("Résistance") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Fichier image externe" else if (tex!!.startsWith("sbhtex://")) "Texture Studio liée ✓" else "Fichier externe ✓")
        }
        StudioTexturePicker(
            textures = textures,
            selectedUri = tex,
            onSelect = { tex = it },
            preferredFormats = listOf("BLOCK_16", "BLOCK_32", "FILTER_MAP")
        )
        Button(
            onClick = {
                onAdd(SbhBlock(projectId = projectId, name = name, identifier = id, hardness = hardness.toDoubleOrNull() ?: 1.0, textureUri = tex))
                tex = null
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
        ) { Text("Ajouter le bloc") }

        blocks.forEach { b ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(b.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${b.identifier} · Résistance ${b.hardness}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ onDelete(b) }) { Text("X") }
                }
            }
        }
        if (blocks.isEmpty()) Text("Aucun bloc pour ce projet.", color = AgwColors.Sand)
    }
}
