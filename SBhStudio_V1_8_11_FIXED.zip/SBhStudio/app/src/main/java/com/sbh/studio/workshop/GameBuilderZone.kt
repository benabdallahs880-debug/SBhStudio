package com.sbh.studio.workshop

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle

@Composable
internal fun GameBuilderZone(
    projectId: String,
    hasProject: Boolean,
    blueprints: List<GameProjectBlueprint>,
    templates: List<GameBuilderTemplate>,
    onSave: (GameProjectBlueprint) -> Unit,
    onDelete: (GameProjectBlueprint) -> Unit,
    onApplyTemplate: (String) -> Unit,
    onMessage: (String) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var name by rememberSaveable { mutableStateOf("Mon jeu mobile") }
    var target by rememberSaveable { mutableStateOf(GameTarget.ANDROID_MOBILE.schemaValue()) }
    var performance by rememberSaveable { mutableStateOf(GamePerformanceProfile.BALANCED.schemaValue()) }
    var worldScene by rememberSaveable { mutableStateOf("worlds/main.tscn") }
    var sizeX by rememberSaveable { mutableStateOf("1024") }
    var sizeY by rememberSaveable { mutableStateOf("256") }
    var sizeZ by rememberSaveable { mutableStateOf("1024") }
    var player by rememberSaveable { mutableStateOf("player/default") }
    var notes by rememberSaveable { mutableStateOf("") }

    fun reset() {
        editingId = null
        name = "Mon jeu mobile"
        target = GameTarget.ANDROID_MOBILE.schemaValue()
        performance = GamePerformanceProfile.BALANCED.schemaValue()
        worldScene = "worlds/main.tscn"
        sizeX = "1024"; sizeY = "256"; sizeZ = "1024"
        player = "player/default"
        notes = ""
    }

    fun load(b: GameProjectBlueprint) {
        editingId = b.id
        name = b.name
        target = b.target
        performance = b.performance
        worldScene = b.worldScene
        sizeX = b.worldSizeX.toString()
        sizeY = b.worldSizeY.toString()
        sizeZ = b.worldSizeZ.toString()
        player = b.playerPrefab
        notes = b.notes
    }

    fun submit() {
        if (!hasProject) {
            onMessage("Ouvrez un projet Studio avant de créer un blueprint jeu")
            return
        }
        val bp = GameProjectBlueprint(
            id = editingId ?: java.util.UUID.randomUUID().toString(),
            projectId = projectId,
            name = name.trim().ifBlank { "Jeu sans nom" },
            target = target,
            performance = performance,
            worldScene = worldScene.trim().ifBlank { "worlds/main.tscn" },
            worldSizeX = sizeX.toIntOrNull()?.coerceIn(64, 8192) ?: 1024,
            worldSizeY = sizeY.toIntOrNull()?.coerceIn(64, 1024) ?: 256,
            worldSizeZ = sizeZ.toIntOrNull()?.coerceIn(64, 8192) ?: 1024,
            playerPrefab = player.trim().ifBlank { "player/default" },
            notes = notes,
            updatedAt = System.currentTimeMillis(),
            createdAt = blueprints.find { it.id == editingId }?.createdAt ?: System.currentTimeMillis()
        )
        onSave(bp)
        reset()
        onMessage(if (editingId != null) "Blueprint jeu mis à jour" else "Blueprint jeu créé")
    }

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.verticalScroll(rememberScrollState())
    ) {
        Text("Game Builder 3D · Atelier 2.0", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text(
            "Chaîne : Projet → Blueprint JSON → scènes/ressources → profil mobile → validation → build Android.\n" +
                "Cette zone pose la fondation (pas encore d'éditeur de scènes ni d'aperçu jouable).",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        SectionTitle("Nouveau blueprint")
        OutlinedTextField(name, { name = it }, label = { Text("Nom du jeu") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Text("Cible", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(
                GameTarget.ANDROID_MOBILE.schemaValue() to "Mobile",
                GameTarget.ANDROID_TABLET.schemaValue() to "Tablette"
            ).forEach { (id, label) ->
                FilterChip(selected = target == id, onClick = { target = id }, label = { Text(label, fontSize = 11.sp) })
            }
        }

        Text("Profil performance", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(
                "light" to "Light 30fps",
                "balanced" to "Balanced 45fps",
                "performance" to "Perf 60fps"
            ).forEach { (id, label) ->
                FilterChip(selected = performance == id, onClick = { performance = id }, label = { Text(label, fontSize = 11.sp) })
            }
        }

        OutlinedTextField(worldScene, { worldScene = it }, label = { Text("Scène monde (.tscn)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(sizeX, { sizeX = it }, label = { Text("Size X") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(sizeY, { sizeY = it }, label = { Text("Size Y") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(sizeZ, { sizeZ = it }, label = { Text("Size Z") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedTextField(player, { player = it }, label = { Text("Prefab joueur") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldPrimaryButton(
                if (editingId != null) "Mettre à jour" else "Créer le blueprint",
                onClick = { submit() },
                modifier = Modifier.weight(1f)
            )
            if (editingId != null) {
                GoldOutlineButton("Annuler", onClick = { reset() }, modifier = Modifier.weight(1f))
            }
        }

        SectionTitle("Templates assets (${templates.size})")
        Text(
            "Profils mobile (light / balanced / performance) et template monde démo.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        templates.forEach { t ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.name, fontWeight = FontWeight.SemiBold, color = AgwColors.SacredGold)
                        Text(t.description, color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                        t.performanceHint?.let {
                            Text("hint: $it", color = AgwColors.DesertOchre, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    if (t.isWorldTemplate) {
                        TextButton(onClick = {
                            if (!hasProject) onMessage("Ouvrez un projet")
                            else onApplyTemplate(t.id)
                        }) { Text("Appliquer", color = AgwColors.GoldSoft) }
                    } else {
                        TextButton(onClick = {
                            performance = t.performanceHint ?: performance
                            onMessage("Profil « ${t.performanceHint} » sélectionné — créez ou mettez à jour un blueprint")
                        }) { Text("Utiliser", color = AgwColors.GoldSoft) }
                    }
                }
            }
        }

        SectionTitle("Blueprints du projet (${blueprints.size})")
        if (blueprints.isEmpty()) {
            Text(
                "Aucun blueprint. Créez-en un ci-dessus ou appliquez le template « demo world ».",
                color = AgwColors.Sand
            )
        } else {
            blueprints.forEach { b ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(b.name, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                            Text(
                                "${b.engine} · ${b.target} · ${b.performance}",
                                color = AgwColors.Sand,
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                "monde ${b.worldSizeX}×${b.worldSizeY}×${b.worldSizeZ} · ${b.worldScene}",
                                color = AgwColors.DesertOchre,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        TextButton(onClick = { load(b) }) { Text("Éditer", color = AgwColors.GoldSoft) }
                        TextButton(onClick = { onDelete(b); if (editingId == b.id) reset() }) {
                            Text("Suppr.", color = Color(0xFFB94E48))
                        }
                    }
                }
            }
        }

        SectionTitle("Prochaines étapes (hors P4)")
        Text(
            "• Éditeur de scènes 3D\n• Import d'assets / génération Godot\n• Aperçu jouable\n• Validation mobile + export APK/AAB",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
