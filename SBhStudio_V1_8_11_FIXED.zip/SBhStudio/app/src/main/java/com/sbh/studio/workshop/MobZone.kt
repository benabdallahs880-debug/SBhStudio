package com.sbh.studio.workshop

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GoldPrimaryButton

@Composable
internal fun MobZone(
    projectId: String,
    mobs: List<MobEntity>,
    hasProject: Boolean,
    textures: List<TextureProject> = emptyList(),
    onAddPresets: () -> Unit,
    onSave: (MobEntity) -> Unit,
    onDelete: (MobEntity) -> Unit
) {
    val context = LocalContext.current

    // Nul tant qu'on crée un nouveau monstre ; rempli avec l'id du monstre en cours d'édition.
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }

    var name by rememberSaveable { mutableStateOf("Créature") }
    var id by rememberSaveable { mutableStateOf("agw:creature") }
    var vie by rememberSaveable { mutableStateOf("20") }
    var dmg by rememberSaveable { mutableStateOf("4") }
    var vit by rememberSaveable { mutableStateOf("0.25") }
    var tex by rememberSaveable { mutableStateOf<String?>(null) }
    // Comportement réel : ces booléens pilotent le JSON de comportement exporté
    // (minecraft:attack, poursuite du joueur, riposte aux dégâts subis).
    var hostile by rememberSaveable { mutableStateOf(true) }
    var poursuite by rememberSaveable { mutableStateOf(true) }
    var attaque by rememberSaveable { mutableStateOf(true) }
    var reactionDegats by rememberSaveable { mutableStateOf(true) }
    // Pouvoirs (buffs appliqués à l'entité côté PackGenerator).
    var pouvoirVitesse by rememberSaveable { mutableStateOf(false) }
    var pouvoirResistance by rememberSaveable { mutableStateOf(false) }
    var pouvoirInvisibilite by rememberSaveable { mutableStateOf(false) }
    var profilIA by rememberSaveable { mutableStateOf("guerrier") }
    var faction by rememberSaveable { mutableStateOf("neutre") }
    var detectionDistance by rememberSaveable { mutableStateOf("24") }
    var vitesseAttaque by rememberSaveable { mutableStateOf("1.0") }
    var cooldownAttaque by rememberSaveable { mutableStateOf("0") }
    var collisionLargeur by rememberSaveable { mutableStateOf("0.6") }
    var collisionHauteur by rememberSaveable { mutableStateOf("1.8") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tex = u.toString()
        }
    }

    fun resetForm() {
        editingId = null
        name = "Créature"; id = "agw:creature"; vie = "20"; dmg = "4"; vit = "0.25"; tex = null
        hostile = true; poursuite = true; attaque = true; reactionDegats = true
        pouvoirVitesse = false; pouvoirResistance = false; pouvoirInvisibilite = false
        profilIA = "guerrier"; faction = "neutre"; detectionDistance = "24"; vitesseAttaque = "1.0"
        cooldownAttaque = "0"; collisionLargeur = "0.6"; collisionHauteur = "1.8"
    }

    fun loadForEdit(m: MobEntity) {
        editingId = m.id
        name = m.nom; id = m.identifiant
        vie = m.vie.toString(); dmg = m.degats.toString(); vit = m.vitesse.toString()
        tex = m.textureUri
        hostile = m.hostile; poursuite = m.poursuite; attaque = m.attaque; reactionDegats = m.reactionDegats
        pouvoirVitesse = m.pouvoirVitesse; pouvoirResistance = m.pouvoirResistance; pouvoirInvisibilite = m.pouvoirInvisibilite
        profilIA = m.profilIA; faction = m.faction; detectionDistance = m.detectionDistance.toString()
        vitesseAttaque = m.vitesseAttaque.toString(); cooldownAttaque = m.cooldownAttaque.toString()
        collisionLargeur = m.collisionLargeur.toString(); collisionHauteur = m.collisionHauteur.toString()
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Création de monstres", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        GoldPrimaryButton("Presets AGW (4 créatures)", onAddPresets)

        Text(
            if (editingId == null) "Nouveau monstre" else "Modification : ${name.ifBlank { "monstre" }}",
            fontWeight = FontWeight.SemiBold,
            color = AgwColors.GoldSoft
        )
        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(id, { id = it }, label = { Text("Identifiant namespace:id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(vie, { vie = it }, label = { Text("PV") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(dmg, { dmg = it }, label = { Text("Dégâts") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(vit, { vit = it }, label = { Text("Vitesse") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedButton({ picker.launch(arrayOf("image/png", "image/jpeg")) }, Modifier.fillMaxWidth()) {
            Text(if (tex == null) "Fichier image externe" else if (tex!!.startsWith("sbhtex://")) "Texture Studio liée ✓" else "Fichier externe ✓")
        }
        StudioTexturePicker(
            textures = textures,
            selectedUri = tex,
            onSelect = { tex = it },
            preferredFormats = listOf("ITEM_16", "BLOCK_16")
        )

        Text("Comportement", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text(
            "Un monstre hostile qui ne poursuit ni n'attaque restera immobile en jeu — coche les trois ensemble pour un vrai monstre agressif.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(hostile, { v -> hostile = v; if (v) { poursuite = true; attaque = true } })
            Text("Hostile", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(poursuite, { poursuite = it }); Text("Poursuit le joueur", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(attaque, { attaque = it }); Text("Attaque au contact", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(reactionDegats, { reactionDegats = it }); Text("Riposte quand on l'attaque", color = AgwColors.PaleMarble)
        }

        Text("IA avancée", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Text("Profil", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("passif", "garde", "guerrier", "archer", "boss").forEach { option ->
                FilterChip(selected = profilIA == option, onClick = { profilIA = option }, label = { Text(option) })
            }
        }
        OutlinedTextField(faction, { faction = it.lowercase().replace(' ', '_') }, label = { Text("Faction") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(detectionDistance, { detectionDistance = it }, label = { Text("Détection") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(vitesseAttaque, { vitesseAttaque = it }, label = { Text("Vitesse attaque") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(cooldownAttaque, { cooldownAttaque = it }, label = { Text("Recharge (s)") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Text("Collision / taille", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(collisionLargeur, { collisionLargeur = it }, label = { Text("Largeur") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(collisionHauteur, { collisionHauteur = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
        }

        Text("Pouvoirs", fontWeight = FontWeight.SemiBold, color = AgwColors.GoldSoft)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirVitesse, { pouvoirVitesse = it }); Text("Vitesse (+50%)", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirResistance, { pouvoirResistance = it }); Text("Résistance", color = AgwColors.PaleMarble)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(pouvoirInvisibilite, { pouvoirInvisibilite = it }); Text("Invisibilité", color = AgwColors.PaleMarble)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onSave(
                        MobEntity(
                            id = editingId ?: java.util.UUID.randomUUID().toString(),
                            projectId = projectId,
                            nom = name,
                            identifiant = id,
                            vie = vie.toIntOrNull() ?: 20,
                            degats = dmg.toIntOrNull() ?: 4,
                            vitesse = vit.toDoubleOrNull() ?: 0.25,
                            hostile = hostile,
                            poursuite = poursuite,
                            attaque = attaque,
                            reactionDegats = reactionDegats,
                            pouvoirVitesse = pouvoirVitesse,
                            pouvoirResistance = pouvoirResistance,
                            pouvoirInvisibilite = pouvoirInvisibilite,
                            profilIA = profilIA,
                            faction = faction.ifBlank { "neutre" },
                            detectionDistance = detectionDistance.replace(',', '.').toDoubleOrNull()?.coerceIn(1.0, 128.0) ?: 24.0,
                            vitesseAttaque = vitesseAttaque.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 4.0) ?: 1.0,
                            cooldownAttaque = cooldownAttaque.replace(',', '.').toDoubleOrNull()?.coerceIn(0.0, 60.0) ?: 0.0,
                            collisionLargeur = collisionLargeur.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 4.0) ?: 0.6,
                            collisionHauteur = collisionHauteur.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 8.0) ?: 1.8,
                            textureUri = tex
                        )
                    )
                    resetForm()
                },
                modifier = Modifier.weight(1f),
                enabled = hasProject
            ) { Text(if (editingId == null) "Ajouter" else "Enregistrer les modifications") }
            if (editingId != null) {
                OutlinedButton({ resetForm() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
            }
        }

        mobs.forEach { m ->
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(m.nom, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                        Text("${m.identifiant} · PV ${m.vie} · DMG ${m.degats}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        val tags = buildList {
                            if (m.hostile) add("hostile")
                            if (m.poursuite) add("poursuite")
                            if (m.attaque) add("attaque")
                            if (m.pouvoirVitesse) add("+vitesse")
                            if (m.pouvoirResistance) add("+résistance")
                            if (m.pouvoirInvisibilite) add("+invisibilité")
                            if (m.faction != "neutre") add("faction:${m.faction}")
                            add("IA:${m.profilIA}")
                        }
                        if (tags.isNotEmpty()) {
                            Text(tags.joinToString(" · "), color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    TextButton({ loadForEdit(m) }) { Text("✎") }
                    TextButton({ if (editingId == m.id) resetForm(); onDelete(m) }) { Text("X") }
                }
            }
        }
        if (mobs.isEmpty()) Text("Aucun monstre pour ce projet.", color = AgwColors.Sand)
    }
}

