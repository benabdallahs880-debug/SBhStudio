package com.sbh.studio.character
import kotlinx.serialization.Serializable
import java.util.UUID
@Serializable
data class CharacterProject(
    val id: String = UUID.randomUUID().toString(), val projectId: String,
    val name: String = "Nouveau personnage", val sourceImageUri: String? = null,
    val sourceImageName: String? = null, val references: List<CharacterReference> = emptyList(), val modelUri: String? = null, val modelName: String? = null,
    val rigMode: RigMode = RigMode.NONE, val status: CharacterStatus = CharacterStatus.DRAFT,
    val notes: String = "", val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = System.currentTimeMillis()
)
@Serializable
data class CharacterReference(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String,
    val view: CharacterReferenceView = CharacterReferenceView.OTHER,
    val addedAt: Long = System.currentTimeMillis()
)

@Serializable
enum class CharacterReferenceView { FRONT, LEFT, RIGHT, BACK, OTHER }

enum class RigMode { NONE, HUMANOID, CREATURE, CUSTOM }
enum class CharacterStatus { DRAFT, IMAGE_IMPORTED, MODEL_READY, RIGGED, ANIMATED, EXPORTED }
