package com.sbh.studio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** SBH Dark Forge: interface technique sombre, lisible et chaleureuse. */
object AgwColors {
    val DeepNight = Color(0xFF0D1117)
    val NightStone = Color(0xFF151B22)
    val Panel = Color(0xFF1A222C)
    val PanelRaised = Color(0xFF202A35)
    val Outline = Color(0xFF33404D)
    val SacredGold = Color(0xFFD6B45A)
    val GoldSoft = Color(0xFFF0D78A)
    val GoldMuted = Color(0xFF3A301A)
    val DesertOchre = Color(0xFFB08A4B)
    val PersianBlue = Color(0xFF2B526E)
    val PaleMarble = Color(0xFFE8E2D5)
    val Sand = Color(0xFFBDB4A3)
    val Success = Color(0xFF63B77A)
    val Warning = Color(0xFFD7A84B)
    val Error = Color(0xFFC96A6A)
    val Info = Color(0xFF6DA7C9)

    // Argent — contours fins, reflets logos
    val Silver = Color(0xFFC8D0D8)
    val SilverSoft = Color(0xFFE8EEF2)
    val SilverMuted = Color(0xFF8A959E)
    val SilverGlass = Color(0x66C8D0D8)      // bordure translucide
    val SilverVeil = Color(0x22C8D0D8)

    // Verre plus transparent pour laisser voir le fond photo
    val NightGlass = Color(0x99151B22)       // ~60% opacité (était ~90%)
    val NightGlassSoft = Color(0x7A1A222C)  // ~48%
    val StoneGlass = Color(0x99202A35)
    val CrystalGlass = Color(0x551A222C)    // très léger pour bulles
    val CrystalGlassSoft = Color(0x40151B22)

    val GoldGlass = Color(0x55D6B45A)
    val GoldVeil = Color(0x1FD6B45A)
    val DriedBlood = Error
    val SandBackground = Color(0xFFF1E9D8)
}

private val SbhTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 13.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.2.sp)
)

private val DarkScheme = darkColorScheme(
    primary = AgwColors.SacredGold,
    onPrimary = AgwColors.DeepNight,
    secondary = AgwColors.PersianBlue,
    onSecondary = AgwColors.PaleMarble,
    tertiary = AgwColors.Info,
    background = AgwColors.DeepNight,
    onBackground = AgwColors.PaleMarble,
    surface = AgwColors.Panel,
    onSurface = AgwColors.PaleMarble,
    surfaceVariant = AgwColors.PanelRaised,
    onSurfaceVariant = AgwColors.Sand,
    error = AgwColors.Error,
    primaryContainer = AgwColors.GoldMuted,
    onPrimaryContainer = AgwColors.GoldSoft,
    outline = AgwColors.Outline
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF765A1E),
    onPrimary = Color.White,
    secondary = AgwColors.PersianBlue,
    background = AgwColors.SandBackground,
    onBackground = Color(0xFF1C1A17),
    surface = Color(0xFFFFFBF3),
    onSurface = Color(0xFF1C1A17),
    primaryContainer = Color(0xFFEBD8A8),
    onPrimaryContainer = Color(0xFF2A210F),
    outline = Color(0xFF8C806A)
)

@Composable
fun AgwTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = SbhTypography,
        content = content
    )
}
