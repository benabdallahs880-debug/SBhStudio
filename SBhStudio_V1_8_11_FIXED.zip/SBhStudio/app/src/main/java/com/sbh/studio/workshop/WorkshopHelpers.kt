package com.sbh.studio.workshop

import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhSound

/** Label affichable pour une zone de l'atelier. */
internal fun zoneLabel(z: WorkshopZoneId) = when (z) {
    WorkshopZoneId.HUB -> "Hub"
    WorkshopZoneId.MOBS -> "Monstres"
    WorkshopZoneId.PORTALS -> "Portails"
    WorkshopZoneId.MAPS -> "Maps"
    WorkshopZoneId.BLOCKS -> "Blocs"
    WorkshopZoneId.ITEMS -> "Items"
    WorkshopZoneId.RECIPES -> "Recettes"
    WorkshopZoneId.SOUNDS -> "Sons"
    WorkshopZoneId.ENTITIES -> "Entités 3D"
    WorkshopZoneId.CHARACTER_STUDIO -> "Character Studio"
    WorkshopZoneId.GAME_BUILDER -> "Game Builder"
    WorkshopZoneId.EXPORT -> "Export"
}

/** Chemin d'asset icône pour une zone de l'atelier. */
internal fun zoneIcon(z: WorkshopZoneId) = when (z) {
    WorkshopZoneId.HUB -> "branding/icons/icon_hub.png"
    WorkshopZoneId.MOBS -> "branding/icons/icon_mobs.png"
    WorkshopZoneId.PORTALS -> "branding/icons/icon_portals.png"
    WorkshopZoneId.MAPS -> "branding/icons/icon_map.png"
    WorkshopZoneId.BLOCKS -> "branding/icons/icon_blocks.png"
    WorkshopZoneId.ITEMS -> "branding/icons/icon_items.png"
    WorkshopZoneId.RECIPES -> "branding/icons/icon_items.png"
    WorkshopZoneId.SOUNDS -> "branding/icons/icon_export.png"
    WorkshopZoneId.ENTITIES -> "branding/icons/icon_items.png"
    WorkshopZoneId.CHARACTER_STUDIO -> "branding/icons/icon_mobs.png"
    WorkshopZoneId.GAME_BUILDER -> "branding/icons/icon_map.png"
    WorkshopZoneId.EXPORT -> "branding/icons/icon_export.png"
}

/** Résultat d'un ajout de monstres : liste complète + compteurs réels. */
internal data class MobMerge(val mobs: List<MobEntity>, val added: Int, val repaired: Int)

/**
 * Ajoute [incoming] à [all] en ne comparant les identifiants que dans le projet du monstre ajouté.
 * Répare aussi un monstre déjà présent dans le projet qui est hostile mais inerte (ni poursuite ni attaque,
 * ancien bug des presets AGW) quand le preset correspondant est, lui, actif. Rien d'autre n'est modifié.
 */
internal fun mergeMobs(all: List<MobEntity>, incoming: List<MobEntity>): MobMerge {
    var result = all
    var added = 0
    var repaired = 0
    for (m in incoming) {
        val existing = result.firstOrNull { it.projectId == m.projectId && it.identifiant == m.identifiant }
        if (existing == null) {
            result = result + listOf(m)
            added++
        } else if (existing.hostile && !existing.poursuite && !existing.attaque && (m.poursuite || m.attaque)) {
            result = result.map {
                if (it.id == existing.id) it.copy(poursuite = m.poursuite, attaque = m.attaque) else it
            }
            repaired++
        }
    }
    return MobMerge(result, added, repaired)
}

internal fun mobMergeMessage(r: MobMerge): String =
    if (r.added == 0 && r.repaired == 0) {
        "Presets monstres déjà présents dans ce projet"
    } else {
        "Presets monstres : ${r.added} ajouté(s)" + if (r.repaired > 0) ", ${r.repaired} réparé(s)" else ""
    }

/** Ajoute les éléments de [incoming] absents du projet (même projet + même clé), et renvoie combien ont été ajoutés. */
internal fun <T> addMissing(
    all: List<T>,
    incoming: List<T>,
    projectOf: (T) -> String,
    keyOf: (T) -> String
): Pair<List<T>, Int> {
    var result = all
    var added = 0
    for (n in incoming) {
        if (result.none { projectOf(it) == projectOf(n) && keyOf(it) == keyOf(n) }) {
            result = result + listOf(n)
            added++
        }
    }
    return result to added
}


/** Résumé léger pour le badge Hub (pas le moteur complet SBhValidationEngine). */
internal data class HubValidationSummary(
    val errorCount: Int,
    val warningCount: Int,
    val messages: List<String> = emptyList()
) {
    val hasErrors: Boolean get() = errorCount > 0
    val hasWarnings: Boolean get() = warningCount > 0
    val isClean: Boolean get() = errorCount == 0 && warningCount == 0
}

/**
 * Contrôles croisés rapides pour l'indicateur Hub.
 * Les règles reprennent l'esprit de P3 sans dépendre du Communication Core.
 */
internal fun computeHubValidation(
    portals: List<PortalBlueprint>,
    maps: List<MapBlueprint>,
    mobs: List<MobEntity>,
    items: List<SbhItem>,
    blocks: List<SbhBlock>,
    recipes: List<RecipeBlueprint>,
    entities: List<SceneEntity>,
    sounds: List<SbhSound> = emptyList()
): HubValidationSummary {
    val errors = mutableListOf<String>()
    val warnings = mutableListOf<String>()
    val mapIds = maps.map { it.id }.toSet()
    val mobIds = mobs.map { it.id }.toSet()
    val itemIds = items.map { it.id }.toSet()
    val blockIds = blocks.map { it.id }.toSet()
    val knownIds = (items.map { it.identifier } + blocks.map { it.identifier }).toSet()

    portals.forEach { p ->
        if (p.linkedMapId != null && p.linkedMapId !in mapIds) {
            errors += "Portail « ${p.name} » → map introuvable"
        }
    }
    maps.forEach { m ->
        m.linkedMobIds.filter { it !in mobIds }.forEach {
            errors += "Map « ${m.name} » → mob manquant"
        }
        m.linkedItemIds.filter { it !in itemIds }.forEach {
            errors += "Map « ${m.name} » → item manquant"
        }
        m.linkedBlockIds.filter { it !in blockIds }.forEach {
            errors += "Map « ${m.name} » → bloc manquant"
        }
    }
    recipes.forEach { r ->
        if (r.resultId.isBlank()) errors += "Recette « ${r.name} » sans résultat"
        else if (r.resultId !in knownIds && !r.resultId.startsWith("minecraft:")) {
            warnings += "Recette « ${r.name} » → résultat hors projet (${r.resultId})"
        }
        if (r.type.contains("shaped") && r.pattern.all { it.isBlank() }) {
            errors += "Recette « ${r.name} » : grille shaped vide"
        }
        if (r.type.contains("shapeless") && r.ingredients.isEmpty()) {
            errors += "Recette « ${r.name} » : ingrédients absents"
        }
    }
    entities.forEach { e ->
        if (e.linkedMapId != null && e.linkedMapId !in mapIds) {
            errors += "Entité « ${e.name} » → map introuvable"
        }
        if (e.glbUri.isNullOrBlank() && e.glbName.isNullOrBlank()) {
            warnings += "Entité « ${e.name} » sans fichier .glb"
        }
    }
    sounds.filter { it.includeInPack && !it.extension.equals("ogg", ignoreCase = true) }.forEach { s ->
        warnings += "Son « ${s.name} » non-Ogg dans le pack"
    }

    return HubValidationSummary(
        errorCount = errors.size,
        warningCount = warnings.size,
        messages = (errors + warnings).take(8)
    )
}
