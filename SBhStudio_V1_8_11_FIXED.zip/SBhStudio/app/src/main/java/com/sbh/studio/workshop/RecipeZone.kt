package com.sbh.studio.workshop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.SbhItem
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle

@Composable
internal fun RecipeZone(
    projectId: String,
    recipes: List<RecipeBlueprint>,
    items: List<SbhItem>,
    onSave: (RecipeBlueprint) -> Unit,
    onDelete: (RecipeBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var name by rememberSaveable { mutableStateOf("Nouvelle recette") }
    var identifier by rememberSaveable { mutableStateOf("agw:recipe_custom") }
    var type by rememberSaveable { mutableStateOf("minecraft:recipe_shaped") }
    var resultId by rememberSaveable { mutableStateOf("agw:item_custom") }
    var resultCount by rememberSaveable { mutableStateOf("1") }
    // 9 cases pour shaped
    var c0 by rememberSaveable { mutableStateOf("") }
    var c1 by rememberSaveable { mutableStateOf("") }
    var c2 by rememberSaveable { mutableStateOf("") }
    var c3 by rememberSaveable { mutableStateOf("") }
    var c4 by rememberSaveable { mutableStateOf("") }
    var c5 by rememberSaveable { mutableStateOf("") }
    var c6 by rememberSaveable { mutableStateOf("") }
    var c7 by rememberSaveable { mutableStateOf("") }
    var c8 by rememberSaveable { mutableStateOf("") }
    var ingredientsText by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }

    fun patternList() = listOf(c0, c1, c2, c3, c4, c5, c6, c7, c8)

    fun reset() {
        editingId = null
        name = "Nouvelle recette"; identifier = "agw:recipe_custom"
        type = "minecraft:recipe_shaped"; resultId = "agw:item_custom"; resultCount = "1"
        c0 = ""; c1 = ""; c2 = ""; c3 = ""; c4 = ""; c5 = ""; c6 = ""; c7 = ""; c8 = ""
        ingredientsText = ""; notes = ""
    }

    fun load(r: RecipeBlueprint) {
        editingId = r.id; name = r.name; identifier = r.identifier; type = r.type
        resultId = r.resultId; resultCount = r.resultCount.toString(); notes = r.notes
        val p = r.pattern + List(9) { "" }
        c0 = p[0]; c1 = p[1]; c2 = p[2]; c3 = p[3]; c4 = p[4]; c5 = p[5]; c6 = p[6]; c7 = p[7]; c8 = p[8]
        ingredientsText = r.ingredients.joinToString(", ")
    }

    fun submit() {
        val r = RecipeBlueprint(
            id = editingId ?: java.util.UUID.randomUUID().toString(),
            projectId = projectId,
            name = name.trim().ifBlank { "Recette" },
            identifier = identifier.trim().ifBlank { "agw:recipe_custom" },
            type = type,
            resultId = resultId.trim().ifBlank { "agw:item_custom" },
            resultCount = resultCount.toIntOrNull()?.coerceIn(1, 64) ?: 1,
            pattern = patternList(),
            ingredients = ingredientsText.split(",", ";", "\n").map { it.trim() }.filter { it.isNotEmpty() },
            notes = notes
        )
        onSave(r)
        reset()
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Recettes de craft", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Crée des recettes shaped, shapeless ou four. La grille 3×3 est utilisée pour le type shaped.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)

        OutlinedTextField(name, { name = it }, label = { Text("Nom") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(identifier, { identifier = it }, label = { Text("Identifiant") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "minecraft:recipe_shaped" to "Shaped",
                "minecraft:recipe_shapeless" to "Shapeless",
                "minecraft:recipe_furnace" to "Four"
            ).forEach { (id, label) ->
                FilterChip(selected = type == id, onClick = { type = id }, label = { Text(label, fontSize = 11.sp) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(resultId, { resultId = it }, label = { Text("Résultat") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(resultCount, { resultCount = it }, label = { Text("Qté") }, modifier = Modifier.width(80.dp), singleLine = true)
        }

        if (type == "minecraft:recipe_shaped") {
            Text("Grille 3×3 (identifiant de bloc/item ou vide)", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
            // Preview visuelle de la grille
            RecipeGridPreview(patternList(), resultId, resultCount.toIntOrNull() ?: 1)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(c0, { c0 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c1, { c1 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c2, { c2 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(c3, { c3 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c4, { c4 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c5, { c5 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(c6, { c6 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c7, { c7 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
                OutlinedTextField(c8, { c8 = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("·", fontSize = 10.sp) })
            }
        } else {
            OutlinedTextField(
                ingredientsText,
                { ingredientsText = it },
                label = { Text("Ingrédients (séparés par ,)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
        }

        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldPrimaryButton(if (editingId != null) "Mettre à jour" else "Ajouter", onClick = { submit() }, modifier = Modifier.weight(1f))
            if (editingId != null) {
                GoldOutlineButton("Annuler", onClick = { reset() }, modifier = Modifier.weight(1f))
            }
        }

        SectionTitle("Recettes du projet (${recipes.size})")
        if (recipes.isEmpty()) {
            Text("Aucune recette. Créez-en une ci-dessus ou appliquez un template depuis le Hub.", color = AgwColors.Sand)
        } else {
            recipes.forEach { r ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                            Text("${r.identifier} → ${r.resultCount}× ${r.resultId}", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                            Text(r.type.removePrefix("minecraft:recipe_"), color = AgwColors.DesertOchre, style = MaterialTheme.typography.labelSmall)
                        }
                        TextButton(onClick = { load(r) }) { Text("Éditer", color = AgwColors.GoldSoft) }
                        TextButton(onClick = { onDelete(r) }) { Text("Suppr.", color = Color(0xFFB94E48)) }
                    }
                }
            }
        }

        if (items.isNotEmpty()) {
            Text("Astuce : items du projet disponibles comme résultat → ${items.take(5).joinToString { it.identifier }}", color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RecipeGridPreview(pattern: List<String>, resultId: String, resultCount: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Grille 3x3
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (row in 0 until 3) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (col in 0 until 3) {
                        val idx = row * 3 + col
                        val cell = pattern.getOrElse(idx) { "" }
                        Box(
                            Modifier
                                .size(28.dp)
                                .background(if (cell.isBlank()) Color(0xFF1A1F28) else Color(0xFF2A3544), RoundedCornerShape(4.dp))
                                .border(1.dp, AgwColors.GoldSoft.copy(alpha = 0.4f), RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (cell.isNotBlank()) {
                                Text(cell.takeLast(3), color = AgwColors.PaleMarble, fontSize = 7.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        Text("→", color = AgwColors.SacredGold, fontSize = 20.sp)
        Box(
            Modifier
                .size(40.dp)
                .background(Color(0xFF2A3544), RoundedCornerShape(6.dp))
                .border(1.dp, AgwColors.SacredGold, RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(resultId.takeLast(4), color = AgwColors.PaleMarble, fontSize = 8.sp, maxLines = 1)
                if (resultCount > 1) Text("×$resultCount", color = AgwColors.SacredGold, fontSize = 9.sp)
            }
        }
    }
}
