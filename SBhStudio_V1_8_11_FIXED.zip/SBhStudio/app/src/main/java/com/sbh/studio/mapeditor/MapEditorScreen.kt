package com.sbh.studio.mapeditor

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.data.RuntimeDiagnosticStore
import com.sbh.studio.workshop.SceneEntity
import com.sbh.studio.workshop.SceneEntityType
import com.sbh.studio.workshop.WorkshopRepository
import com.sbh.studio.texture.TextureRepository
import org.json.JSONArray
import org.json.JSONObject
import com.sbh.studio.data.RuntimeErrorRecord

/**
 * Éditeur de maps 3D intégré (Three.js via WebView).
 * Charge assets/mapstudio.html (Three.js embarqué localement, sans CDN)
 * et expose un bridge Android pour exporter la map vers SBh Studio.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MapEditorScreen(
    onBack: () -> Unit,
    onMapExported: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var loadStage by remember { mutableStateOf(0) }
    var pageReady by remember { mutableStateOf(false) }
    var studioReady by remember { mutableStateOf(false) }
    var retryCount by remember { mutableStateOf(0) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val runtimeDiagnostics = remember { RuntimeDiagnosticStore(context) }
    // Référence partagée vers la WebView, remplie après sa création (ligne ~227) ;
    // permet au bridge (défini avant la WebView) d'y injecter du JS depuis ready().
    val webViewHolder = remember { arrayOfNulls<WebView>(1) }
    var fileChooserCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val fileChooserLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        fileChooserCallback?.onReceiveValue(uri?.let { arrayOf(it) } ?: emptyArray())
        fileChooserCallback = null
    }

    val bridge = remember {
        object {
            @JavascriptInterface
            fun close() {
                mainHandler.post { onBack() }
            }

            @JavascriptInterface
            fun exportMap(json: String) {
                mainHandler.post {
                    onMapExported(json)
                    Toast.makeText(context, "Map importée dans SBh Studio ✓", Toast.LENGTH_SHORT).show()
                }
            }

            @JavascriptInterface
            fun ready() {
                try {
                    java.io.File(context.filesDir, "map_studio_last_error.txt").delete()
                    java.io.File(context.filesDir, "map_studio_last_ready.txt").writeText(System.currentTimeMillis().toString())
                } catch (_: Exception) {}
                mainHandler.post {
                    studioReady = true
                    loadStage = 8
                    loading = false
                    // Un personnage (ou objet) envoyé depuis un autre écran (ex. Character Studio)
                    // attend d'être injecté : on le pousse directement dans le viewport 3D.
                    PendingMapImport.take()?.let { pending ->
                        val wv = webViewHolder[0]
                        if (wv == null) {
                            Toast.makeText(context, "Import différé : vue non prête", Toast.LENGTH_SHORT).show()
                        } else {
                            try {
                                val bytes = java.io.File(pending.filePath).readBytes()
                                val base64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                                val js = "window.sbhImportGlbFromNative && window.sbhImportGlbFromNative(" +
                                    org.json.JSONObject.quote(base64) + ", " +
                                    org.json.JSONObject.quote(pending.displayName) + ");"
                                wv.evaluateJavascript(js, null)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Échec de l'import : ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            }

            @JavascriptInterface
            fun error(name: String, message: String, filename: String, line: Int, column: Int, function: String, stack: String) {
                val recent = runtimeDiagnostics.recentEvents()
                val record = RuntimeErrorRecord(
                    module = "Map Studio",
                    action = "Runtime JavaScript",
                    state = "WebView",
                    name = name.ifBlank { "Error" },
                    message = message,
                    filename = filename.ifBlank { null },
                    line = line.takeIf { it > 0 },
                    column = column.takeIf { it > 0 },
                    function = function.ifBlank { null },
                    stack = stack.ifBlank { null },
                    lastEvent = recent.lastOrNull(),
                    recentActions = recent,
                    runtimeState = mapOf("module" to "Map Studio", "state" to "WebView", "page" to "mapstudio.html"),
                    raw = listOf(name, message, filename, line, column, function, stack).joinToString(" | "),
                    interpretation = when (name) {
                        "TypeError" -> "Une opération utilise une valeur d'un type inattendu ou une affectation interdite."
                        "ReferenceError" -> "Le code utilise un identifiant qui n'est pas défini dans ce contexte."
                        "SyntaxError" -> "Le moteur JavaScript n'a pas pu analyser le code concerné."
                        else -> "Erreur JavaScript capturée pendant l'exécution du module."
                    }
                )
                runtimeDiagnostics.save(record)
                runtimeDiagnostics.appendEvent("EXCEPTION ${record.name}: ${record.message}")
                try { java.io.File(context.filesDir, "map_studio_last_error.txt").writeText(record.developerReport()) } catch (_: Exception) {}
                mainHandler.post {
                    loadError = "Erreur JavaScript Map Studio : ${record.message} [${record.errorId}]"
                    loading = false
                    studioReady = false
                }
            }

            @JavascriptInterface
            fun toast(msg: String) {
                mainHandler.post {
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }

            /** Remonte les objets 3D de la scène vers l'Atelier (transforms + noms). */
            @JavascriptInterface
            fun syncEntities(json: String) {
                mainHandler.post {
                    try {
                        val root = JSONObject(json)
                        val arr = root.optJSONArray("entities") ?: return@post
                        val ws = WorkshopRepository(context)
                        val existing = ws.loadEntities().toMutableList()
                        // projectId: garder ceux d'autres projets, remplacer/ajouter pour le projet courant si possible
                        // Sans projectId explicite côté JS, on merge par id globalement.
                        var added = 0
                        var updated = 0
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val id = o.optString("id")
                            if (id.isBlank()) continue
                            val name = o.optString("name", id)
                            val pos = o.optJSONArray("pos")
                            val posX = pos?.optDouble(0, 0.0)?.toFloat() ?: 0f
                            val posY = pos?.optDouble(1, 0.0)?.toFloat() ?: 0f
                            val posZ = pos?.optDouble(2, 0.0)?.toFloat() ?: 0f
                            val rotY = o.optDouble("rotY", 0.0).toFloat()
                            val scale = o.optDouble("scale", 1.0).toFloat().coerceIn(0.05f, 50f)
                            val glbName = o.optString("glbName").ifBlank { null }
                            val idx = existing.indexOfFirst { it.id == id }
                            if (idx >= 0) {
                                val prev = existing[idx]
                                existing[idx] = prev.copy(
                                    name = name,
                                    posX = posX, posY = posY, posZ = posZ,
                                    rotY = rotY, scale = scale,
                                    glbName = glbName ?: prev.glbName
                                )
                                updated++
                            } else {
                                existing.add(
                                    SceneEntity(
                                        id = id,
                                        projectId = "global",
                                        name = name,
                                        type = SceneEntityType.OBJECT,
                                        glbName = glbName,
                                        posX = posX, posY = posY, posZ = posZ,
                                        rotY = rotY, scale = scale
                                    )
                                )
                                added++
                            }
                        }
                        ws.saveEntities(existing)
                        if (added + updated > 0) {
                            Toast.makeText(
                                context,
                                "Entités Atelier: $added ajoutée(s), $updated maj",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "Sync entités: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    val assetLoader = remember {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
    }

    val webView = remember {
        WebView(context).apply {
            setBackgroundColor(Color.parseColor("#1A1612"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mediaPlaybackRequiresUserGesture = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                // Le HTML possède déjà un viewport mobile explicite.
                // Laisser WebView appliquer son propre zoom global agrandissait/rétrécissait
                // la page et perturbait les dimensions du canvas Three.js.
                useWideViewPort = false
                loadWithOverviewMode = false
                // Les assets sont servis par WebViewAssetLoader sur une origine HTTPS locale.
                // Aucune autorisation file:// inter-origines n'est nécessaire.
                //
                // ⚠️ Ne PAS forcer setLayerType(LAYER_TYPE_HARDWARE, ...) ici : l'app est déjà
                // accélérée matériellement par défaut (aucun android:hardwareAccelerated="false"
                // dans le manifest), et forcer explicitement ce mode sur la WebView est une cause
                // connue d'écran noir/vide sur certains GPU/pilotes (notamment appareils d'entrée
                // de gamme) alors que ça fonctionne normalement en test. On laisse Android choisir.
            }
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    consoleMessage?.let {
                        runtimeDiagnostics.appendEvent("CONSOLE ${it.messageLevel()}: ${it.message()} @ ${it.sourceId()}:${it.lineNumber()}")
                    }
                    return true
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = filePathCallback
                    return try {
                        fileChooserLauncher.launch(arrayOf(
                            "application/json",
                            "application/octet-stream",
                            "*/*"
                        ))
                        true
                    } catch (_: Exception) {
                        fileChooserCallback?.onReceiveValue(null)
                        fileChooserCallback = null
                        false
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val url = request?.url ?: return null
                    return assetLoader.shouldInterceptRequest(url)
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val uri = request?.url ?: return true
                    return uri.scheme != "https" || uri.host != "appassets.androidplatform.net"
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageReady = true
                    loadStage = 5
                    runtimeDiagnostics.appendEvent("Module loaded: Map Studio")
                    // Injecter les régions fondation si disponibles
                    val regionsFile = java.io.File(context.filesDir, "map_studio_regions.json")
                    if (regionsFile.exists()) {
                        try {
                            val json = regionsFile.readText()
                            val encoded = Base64.encodeToString(json.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                            view?.evaluateJavascript(
                                """
                                (function(){
                                  try {
                                    const raw = atob('$encoded');
                                    const bytes = Uint8Array.from(raw, c => c.charCodeAt(0));
                                    const text = new TextDecoder('utf-8').decode(bytes);
                                    window.__SBH_REGIONS__ = JSON.parse(text);
                                    if (window.SBhBridge && window.SBhBridge.toast) {
                                      window.SBhBridge.toast('Régions AGW chargées');
                                    }
                                  } catch(e) { console.warn('regions inject', e); }
                                })();
                                """.trimIndent(),
                                null
                            )
                        } catch (_: Exception) { /* ignore */ }
                    }
                    // Injecter le graphe Atelier (maps, portails, textures) pour Map Studio
                    try {
                        val ws = WorkshopRepository(context)
                        val tex = TextureRepository(context)
                        val maps = ws.loadMaps()
                        val portals = ws.loadPortals()
                        val entities = ws.loadEntities()
                        val textures = tex.loadAll()
                        val root = JSONObject()
                        val mapsArr = JSONArray()
                        maps.forEach { m ->
                            mapsArr.put(JSONObject().apply {
                                put("id", m.id)
                                put("name", m.name)
                                put("sizeX", m.sizeX)
                                put("sizeZ", m.sizeZ)
                                put("height", m.height)
                                put("terrain", m.terrain)
                                put("worldX", m.worldX)
                                put("worldZ", m.worldZ)
                                put("hasVillage", m.hasVillage)
                                put("hasDungeon", m.hasDungeon)
                                put("hasOasis", m.hasOasis)
                                put("linkedMobIds", JSONArray(m.linkedMobIds))
                                put("linkedItemIds", JSONArray(m.linkedItemIds))
                                put("linkedBlockIds", JSONArray(m.linkedBlockIds))
                                put("worldFilterTextureId", m.worldFilterTextureId ?: JSONObject.NULL)
                            })
                        }
                        val portalsArr = JSONArray()
                        portals.forEach { p ->
                            portalsArr.put(JSONObject().apply {
                                put("id", p.id)
                                put("name", p.name)
                                put("linkedMapId", p.linkedMapId ?: JSONObject.NULL)
                                put("mapX", p.mapX); put("mapY", p.mapY); put("mapZ", p.mapZ)
                                put("destX", p.destX); put("destY", p.destY); put("destZ", p.destZ)
                            })
                        }
                        val texArr = JSONArray()
                        textures.forEach { t ->
                            texArr.put(JSONObject().apply {
                                put("id", t.id)
                                put("name", t.name)
                                put("format", t.format)
                                put("width", t.width)
                                put("height", t.height)
                            })
                        }
                        val entitiesArr = JSONArray()
                        entities.forEach { e ->
                            entitiesArr.put(JSONObject().apply {
                                put("id", e.id)
                                put("name", e.name)
                                put("type", e.type.name)
                                put("glbName", e.glbName ?: JSONObject.NULL)
                                put("linkedMapId", e.linkedMapId ?: JSONObject.NULL)
                                put("posX", e.posX.toDouble())
                                put("posY", e.posY.toDouble())
                                put("posZ", e.posZ.toDouble())
                                put("rotY", e.rotY.toDouble())
                                put("scale", e.scale.toDouble())
                            })
                        }
                        root.put("maps", mapsArr)
                        root.put("portals", portalsArr)
                        root.put("textures", texArr)
                        root.put("entities", entitiesArr)
                        val encoded = Base64.encodeToString(root.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                        view?.evaluateJavascript(
                            """
                            (function(){
                              try {
                                const raw = atob('$encoded');
                                const bytes = Uint8Array.from(raw, c => c.charCodeAt(0));
                                const text = new TextDecoder('utf-8').decode(bytes);
                                window.__SBH_ATELIER__ = JSON.parse(text);
                                if (window.onSbhAtelier) window.onSbhAtelier(window.__SBH_ATELIER__);
                                if (window.SBhBridge && window.SBhBridge.toast) {
                                  window.SBhBridge.toast('Atelier relié: ' + (window.__SBH_ATELIER__.maps||[]).length + ' maps');
                                }
                              } catch(e) { console.warn('atelier inject', e); }
                            })();
                            """.trimIndent(),
                            null
                        )
                        runtimeDiagnostics.appendEvent("Atelier linked: ${maps.size} maps, ${portals.size} portals, ${textures.size} textures, ${entities.size} entities")
                    } catch (_: Exception) { /* ignore */ }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    // Ne signaler que l'erreur de la page principale
                    if (request?.isForMainFrame == true) {
                        runtimeDiagnostics.appendEvent("LOAD_ERROR: ${error?.description ?: "Erreur de chargement Map Studio"}")
                        loadError = error?.description?.toString() ?: "Erreur de chargement Map Studio"
                        loading = false
                        studioReady = false
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        loadStage = 1
        delay(180)
        loadStage = 2
        delay(180)
        loadStage = 3
        delay(220)
        loadStage = 4
        // Les étapes 5→8 sont déclenchées par le chargement réel de la page
        // et par SBhBridge.ready() appelé par Map Studio après son initialisation.
        delay(900)
        if (!studioReady && loadError == null) {
            loadStage = if (pageReady) 6 else loadStage
        }
    }

    val timeoutRunnable = remember { Runnable {
        if (loading && !studioReady && loadError == null) {
            loadError = "Map Studio n'a pas terminé son initialisation après 20 secondes."
            loading = false
        }
    } }

    DisposableEffect(Unit) {
        loadStage = 4
        runtimeDiagnostics.appendEvent("Module opened")
        webViewHolder[0] = webView
        webView.addJavascriptInterface(bridge, "SBhBridge")
        mainHandler.postDelayed(timeoutRunnable, 20_000L)
        webView.loadUrl("https://appassets.androidplatform.net/assets/mapstudio.html")
        onDispose {
            mainHandler.removeCallbacks(timeoutRunnable)
            webViewHolder[0] = null
            try {
                webView.removeJavascriptInterface("SBhBridge")
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            } catch (_: Exception) { /* ignore */ }
        }
    }

    LaunchedEffect(retryCount) {
        if (retryCount <= 0) return@LaunchedEffect
        loading = true
        loadError = null
        pageReady = false
        studioReady = false
        loadStage = 1
        mainHandler.removeCallbacks(timeoutRunnable)
        mainHandler.postDelayed(timeoutRunnable, 20_000L)
        webView.loadUrl("https://appassets.androidplatform.net/assets/mapstudio.html")
    }

    BackHandler { onBack() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AgwColors.DeepNight)
    ) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )

        if (loading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AgwColors.DeepNight),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.layout.Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "SBH / MAP STUDIO",
                        color = AgwColors.SacredGold,
                        style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                    Text(
                        "ÉDITEUR DE MONDE",
                        color = AgwColors.Sand,
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    LinearProgressIndicator(
                        progress = { ((loadStage.coerceIn(0, 8)) / 8f) },
                        color = AgwColors.SacredGold,
                        trackColor = AgwColors.NightStone,
                        modifier = Modifier
                            .padding(top = 18.dp)
                            .fillMaxWidth()
                            .height(3.dp)
                    )
                    androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))
                    CircularProgressIndicator(
                        color = AgwColors.SacredGold
                    )
                    Text(
                        when (loadStage.coerceIn(0, 8)) {
                            0 -> "Préparation de Map Studio"
                            1 -> "Initialisation de Map Studio"
                            2 -> "Préparation du projet"
                            3 -> "Chargement du World Core"
                            4 -> "Chargement de l'éditeur 3D"
                            5 -> "Chargement des régions et ressources"
                            6 -> "Préparation des textures et blocs"
                            7 -> "Préparation de la caméra"
                            else -> "Monde prêt · entrée dans Map Studio"
                        },
                        color = AgwColors.PaleMarble,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        }

        if (loadError != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AgwColors.DeepNight.copy(alpha = 0.92f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.layout.Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Map Studio n'a pas pu se charger",
                        color = AgwColors.SacredGold
                    )
                    Text(
                        loadError ?: "",
                        color = AgwColors.Sand,
                        modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                    )
                    androidx.compose.foundation.layout.Row(
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(onClick = { retryCount++ }) {
                            Text("Réessayer", color = AgwColors.SacredGold)
                        }
                        TextButton(onClick = onBack) {
                            Text("← Retour", color = AgwColors.GoldSoft)
                        }
                    }
                }
            }
        }
    }
}
