package com.sbh.studio.generator

import android.content.Context
import com.sbh.studio.communication.ExportStatus
import com.sbh.studio.communication.LifecycleStep
import com.sbh.studio.communication.SBhCommunicationCore
import com.sbh.studio.communication.SBhProtocol
import com.sbh.studio.communication.SBhProtocolPayload
import com.sbh.studio.communication.SBhReport
import com.sbh.studio.communication.SBhValidationEngine
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.data.SbhProject
import com.sbh.studio.data.SoundRepository
import com.sbh.studio.data.SbhSound
import com.sbh.studio.workshop.MapBlueprint
import com.sbh.studio.workshop.PortalBlueprint
import com.sbh.studio.workshop.RecipeBlueprint
import com.sbh.studio.workshop.SceneEntity
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/**
 * Moteur de fabrication avancé SBh Studio.
 * Enrichit PackGenerator : validation stricte via SBhValidationEngine,
 * portails, plans de map, fichiers lang, structure BP/RP plus complète.
 *
 * Flux :
 *   exportAdvanced → SBhValidationEngine → SBhCommunicationCore → SBhReport
 */
class AdvancedPackEngine(private val context: Context) {
    private val base = PackGenerator(context)
    private val json = Json { prettyPrint = true }
    private val core = SBhCommunicationCore(context)
    private val validator = SBhValidationEngine(context, core)

    data class BuildReport(
        val ok: Boolean,
        val errors: List<String>,
        val warnings: List<String>,
        val file: File? = null,
        /** Rapport structuré SBh (toujours présent après validation). */
        val sbhReport: SBhReport? = null
    )

    /**
     * Validation complète via le nouveau SBh Validation Engine.
     * Conserve la signature BuildReport pour compatibilité avec l'UI existante.
     */
    fun validateAll(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint> = emptyList(),
        maps: List<MapBlueprint> = emptyList(),
        recipes: List<RecipeBlueprint> = emptyList(),
        entities: List<SceneEntity> = emptyList(),
        sounds: List<SbhSound> = emptyList(),
        studioVersion: String = ""
    ): BuildReport {
        val result = validator.validate(
            project, mobs, items, blocks, portals, maps,
            recipes, entities, sounds, studioVersion
        )
        val errors = result.entries
            .filter { it.level == com.sbh.studio.communication.ReportLevel.ERROR ||
                      it.level == com.sbh.studio.communication.ReportLevel.CRITICAL }
            .map { formatEntry(it) }
        val warnings = result.entries
            .filter { it.level == com.sbh.studio.communication.ReportLevel.WARNING }
            .map { formatEntry(it) }
        return BuildReport(
            ok = !result.blocking,
            errors = errors,
            warnings = warnings,
            sbhReport = result.report
        )
    }

    private fun formatEntry(e: com.sbh.studio.communication.ReportEntry): String {
        val code = e.code?.code?.let { "[$it] " } ?: ""
        val file = e.file?.let { " ($it)" } ?: ""
        return "$code${e.title}$file${if (e.detail.isNotBlank()) " — ${e.detail}" else ""}"
    }

    /** Export .mcaddon enrichi (base + stubs portails/maps + texts). */
    fun exportAdvanced(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        portals: List<PortalBlueprint> = emptyList(),
        maps: List<MapBlueprint> = emptyList(),
        recipes: List<RecipeBlueprint> = emptyList(),
        entities: List<SceneEntity> = emptyList(),
        sounds: List<SbhSound> = emptyList(),
        studioVersion: String = ""
    ): BuildReport {
        // 1. Validation structurée → SBhReport + ExportRecord
        val validation = validateAll(
            project, mobs, items, blocks, portals, maps,
            recipes, entities, sounds, studioVersion
        )
        if (!validation.ok) return validation

        var sbhReport = validation.sbhReport
            ?: return BuildReport(false, listOf("Rapport de validation manquant"), emptyList())

        // 2. Génération + export réel
        return try {
            sbhReport = core.updateStatus(sbhReport, ExportStatus.EXPORTING)
            sbhReport = core.addEntry(
                sbhReport,
                core.info(
                    LifecycleStep.EXPORT,
                    "Génération du pack",
                    "ExportId=${sbhReport.exportId.value} — inclusion protocole SBH ${SBhProtocol.VERSION}"
                )
            )

            val extras = linkedMapOf<String, String>()

            // Protocole SBH : même payload que le SBhReport (identifiants identiques).
            // Écrit réellement dans le ZIP via PackGenerator.extraFiles :
            //   BP/sbh/protocol.json  →  sbh/protocol.json dans le Behavior Pack
            //   RP/sbh/protocol.json  →  sbh/protocol.json dans le Resource Pack
            // Le dossier sbh/ est ignoré par Minecraft Bedrock.
            val protocolPayload = SBhProtocolPayload.fromReport(sbhReport)
            val protocolJson = Json { prettyPrint = true }.encodeToString(protocolPayload)
            // Chemins littéraux exigés par le pipeline de validation + constantes SBhProtocol.
            extras["BP/sbh/protocol.json"] = protocolJson
            extras["RP/sbh/protocol.json"] = protocolJson
            check(extras.containsKey(SBhProtocol.BP_EXTRA_PATH)) {
                "Protocole SBH manquant (BP/sbh/protocol.json)"
            }
            check(extras.containsKey(SBhProtocol.RP_EXTRA_PATH)) {
                "Protocole SBH manquant (RP/sbh/protocol.json)"
            }

            // Portails : gérés nativement par PackGenerator (BP block + RP texture + light_emission).
            // On n'ajoute que la doc atelier pour éviter les doublons de chemin zip.
            portals.forEach { portal ->
                val id = portal.identifier.substringAfter(":", portal.identifier)
                extras["BP/docs/portal_${id}.txt"] =
                    "Portal ${portal.name} ${portal.width}x${portal.height} frame=${portal.frameBlock} " +
                    "dest=${portal.destinationHint} (${portal.destX}, ${portal.destY}, ${portal.destZ}) @ ${portal.destDimension}" +
                    if (portal.linkedMapId != null) " map=${portal.linkedMapId} pos=(${portal.mapX},${portal.mapY},${portal.mapZ})" else ""
            }
            maps.forEach { m ->
                val sid = safe(m.name).lowercase()
                extras["BP/docs/map_${sid}.json"] = mapDocJson(m)
            }
            extras["RP/texts/languages.json"] = """["en_US","fr_FR"]"""
            extras["RP/texts/fr_FR.lang"] = buildLang(project, mobs, items, blocks, "fr")
            extras["RP/texts/en_US.lang"] = buildLang(project, mobs, items, blocks, "en")

            // —— Sons / نشيد : inclusion dans le Resource Pack ——
            val soundRepo = SoundRepository(context)
            val projectSounds = soundRepo.loadForExport(project.id)
            val extraBinary = linkedMapOf<String, ByteArray>()
            if (projectSounds.isNotEmpty()) {
                // sound_definitions.json
                extras["RP/sounds/sound_definitions.json"] =
                    soundRepo.buildSoundDefinitionsJson(projectSounds)
                // Fichiers audio (ogg/mp3…) sous sounds/sbh/
                projectSounds.forEach { s ->
                    val bytes = soundRepo.bytesFor(s)
                    if (bytes != null && bytes.isNotEmpty()) {
                        // Bedrock attend souvent .ogg ; on conserve l'extension d'origine
                        val ext = s.extension.ifBlank { "ogg" }
                        val packPath = "RP/${s.packSoundPath()}.$ext"
                        extraBinary[packPath] = bytes
                    }
                }
                // Doc atelier
                extras["RP/docs/sbh_sounds.txt"] = buildString {
                    appendLine("SBh Studio — Sons / نشيد inclus dans ce pack")
                    appendLine("Nombre : ${projectSounds.size}")
                    projectSounds.forEach { s ->
                        appendLine("- ${s.name} → ${s.definitionKey()} (${s.packSoundPath()}.${s.extension})")
                    }
                    appendLine()
                    appendLine("Utilisation in-game : /playsound <event> @a")
                    appendLine("Événements music.* / record.* remplacent les sons vanilla si le pack est activé.")
                }
                sbhReport = core.addEntry(
                    sbhReport,
                    core.info(
                        LifecycleStep.EXPORT,
                        "Sons inclus",
                        "${projectSounds.size} fichier(s) audio dans le Resource Pack (sound_definitions.json)"
                    )
                )
                val nonOgg = projectSounds.filter { !it.extension.equals("ogg", ignoreCase = true) }
                if (nonOgg.isNotEmpty()) {
                    sbhReport = core.addEntry(
                        sbhReport,
                        core.warning(
                            step = LifecycleStep.EXPORT,
                            title = "Sons non-Ogg",
                            detail = "${nonOgg.size} fichier(s) ne sont pas en Ogg Vorbis (ex. ${nonOgg.first().name}). Minecraft Bedrock préfère fortement le .ogg."
                        )
                    )
                }
            }

            val result = base.exportDetailed(
                project, mobs, items, blocks, portals, extras, extraBinary
            )

            // 3. Archive créée — résultat observable
            sbhReport = core.setArchiveInfo(
                sbhReport,
                path = result.file.absolutePath,
                sizeBytes = result.file.length(),
                filesGenerated = null
            )
            sbhReport = core.addEntry(
                sbhReport,
                core.info(
                    LifecycleStep.EXPORT,
                    "Archive créée",
                    "Fichier : ${result.file.name} (${result.file.length()} octets). " +
                        "Protocole SBH embarqué : ${SBhProtocol.PACK_PATH}"
                )
            )
            if (result.warnings.isNotEmpty()) {
                val extraEntries = result.warnings.map { w ->
                    core.warning(
                        step = LifecycleStep.EXPORT,
                        title = "Avertissement générateur",
                        detail = w
                    )
                }
                sbhReport = core.addEntries(sbhReport, extraEntries)
            }

            // 4. Prêt à transmettre — l'Intent sera lancé par l'UI (MainActivity).
            // On ne passe PAS encore en TRANSMITTING ici : la transmission
            // n'a lieu que lorsque SBhTransmitter.transmitMcaddon est appelé.
            // Statut intermédiaire : READY_TO_SEND (pack prêt, pas encore envoyé).
            sbhReport = core.updateStatus(sbhReport, ExportStatus.READY_TO_SEND)
            sbhReport = core.addEntry(
                sbhReport,
                core.info(
                    LifecycleStep.TRANSMIT,
                    "Pack prêt à transmettre",
                    "En attente du lancement Intent ACTION_VIEW. " +
                        "L'import Minecraft restera non confirmable (IMPORT_UNKNOWN)."
                )
            )

            BuildReport(
                ok = true,
                errors = emptyList(),
                warnings = (validation.warnings + result.warnings).distinct(),
                file = result.file,
                sbhReport = sbhReport
            )
        } catch (e: Exception) {
            sbhReport = core.addEntry(
                sbhReport,
                core.critical(
                    step = LifecycleStep.EXPORT,
                    title = "Échec d'export",
                    detail = e.message ?: "Export failed",
                    cause = e.javaClass.simpleName,
                    code = com.sbh.studio.communication.SBhErrorCode.EXPORT_FAILED
                )
            )
            sbhReport = core.updateStatus(sbhReport, ExportStatus.FAILED)
            BuildReport(
                false,
                listOf(e.message ?: "Export failed"),
                validation.warnings,
                null,
                sbhReport
            )
        }
    }

    private fun portalBlockJson(p: PortalBlueprint): String {
        val (ns, id) = split(p.identifier)
        return buildJsonObject {
            put("format_version", "1.21.0")
            putJsonObject("minecraft:block") {
                putJsonObject("description") { put("identifier", "$ns:$id") }
                putJsonObject("components") {
                    put("minecraft:destroy_time", 2.0)
                    put("minecraft:light_emission", 8)
                }
            }
        }.toString()
    }

    private fun mapDocJson(m: MapBlueprint): String = buildJsonObject {
        put("name", m.name)
        put("size_x", m.sizeX)
        put("size_z", m.sizeZ)
        put("id", m.id)
        put("theme", m.theme)
        put("dimension", m.dimension)
        put("theme", m.theme)
        put("village", m.hasVillage)
        put("dungeon", m.hasDungeon)
        put("oasis", m.hasOasis)
        put("notes", m.notes)
        put("hint", "Plan logique — à construire in-game ou via structure BP.")
    }.toString()

    private fun buildLang(
        project: SbhProject,
        mobs: List<MobEntity>,
        items: List<SbhItem>,
        blocks: List<SbhBlock>,
        lang: String
    ): String = buildString {
        appendLine("pack.name=${project.name}")
        appendLine("pack.description=SBh Studio pack")
        mobs.forEach { appendLine("entity.${it.identifiant}.name=${it.nom}") }
        items.forEach { appendLine("item.${it.identifier}=${it.name}") }
        blocks.forEach { appendLine("tile.${it.identifier}.name=${it.name}") }
        if (lang == "fr") appendLine("agw.studio=Généré par SBh Studio")
        else appendLine("agw.studio=Generated by SBh Studio")
    }

    private fun split(id: String): Pair<String, String> {
        val p = id.split(":", limit = 2)
        return if (p.size == 2) p[0] to p[1] else "agw" to id
    }

    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
    private fun writeText(zip: ZipOutputStream, path: String, text: String) {
        zip.putNextEntry(ZipEntry(path))
        zip.write(text.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    /**
     * Presets monstre AGW pour faciliter la création.
     * Ils sont hostiles ET actifs (poursuite + attaque). Avant, seul `hostile` était vrai : l'export
     * n'écrivait ni attaque, ni mêlée, ni ciblage du joueur, et les créatures ne faisaient rien.
     */
    fun presetMobs(projectId: String): List<MobEntity> = listOf(
        MobEntity(projectId = projectId, nom = "Scorpion des Dunes", identifiant = "agw:dune_scorpion", vie = 24, vitesse = 0.3, degats = 5, hostile = true, poursuite = true, attaque = true),
        MobEntity(projectId = projectId, nom = "Spectre des Ruines", identifiant = "agw:ruin_specter", vie = 30, vitesse = 0.22, degats = 4, hostile = true, poursuite = true, attaque = true),
        MobEntity(projectId = projectId, nom = "Djinn Nocturne", identifiant = "agw:night_djinn", vie = 40, vitesse = 0.28, degats = 7, hostile = true, poursuite = true, attaque = true),
        MobEntity(projectId = projectId, nom = "Sultan-Djinn", identifiant = "agw:djinn_sultan", vie = 200, vitesse = 0.2, degats = 12, hostile = true, poursuite = true, attaque = true, profilIA = "boss")
    )
}
