package com.sbh.studio.workshop

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sbh.studio.data.MobEntity
import com.sbh.studio.data.SbhBlock
import com.sbh.studio.data.SbhItem
import com.sbh.studio.texture.TextureProject
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.GlassCard
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle

@Composable
internal fun MapZone(
    projectId: String,
    maps: List<MapBlueprint>,
    portals: List<PortalBlueprint>,
    mobs: List<MobEntity> = emptyList(),
    items: List<SbhItem> = emptyList(),
    blocks: List<SbhBlock> = emptyList(),
    textures: List<TextureProject> = emptyList(),
    onSave: (MapBlueprint) -> Unit,
    onLinkPortal: (PortalBlueprint, String?) -> Unit,
    onDelete: (MapBlueprint) -> Unit
) {
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var name by rememberSaveable { mutableStateOf("Nouvelle map") }
    var sizeX by rememberSaveable { mutableStateOf("64") }
    var sizeZ by rememberSaveable { mutableStateOf("64") }
    var height by rememberSaveable { mutableStateOf("64") }
    var terrain by rememberSaveable { mutableStateOf("desert") }
    var dimension by rememberSaveable { mutableStateOf("minecraft:overworld") }
    var seed by rememberSaveable { mutableStateOf("0") }
    var worldX by rememberSaveable { mutableStateOf("0") }
    var worldZ by rememberSaveable { mutableStateOf("0") }
    var village by rememberSaveable { mutableStateOf(true) }
    var dungeon by rememberSaveable { mutableStateOf(true) }
    var oasis by rememberSaveable { mutableStateOf(false) }
    var mountains by rememberSaveable { mutableStateOf(false) }
    var roads by rememberSaveable { mutableStateOf(false) }
    var notes by rememberSaveable { mutableStateOf("") }
    var showErrors by rememberSaveable { mutableStateOf(false) }
    var linkedMobIds by remember { mutableStateOf(listOf<String>()) }
    var linkedItemIds by remember { mutableStateOf(listOf<String>()) }
    var linkedBlockIds by remember { mutableStateOf(listOf<String>()) }
    var worldFilterTextureId by rememberSaveable { mutableStateOf<String?>(null) }

    val parsedX = sizeX.toIntOrNull()
    val parsedZ = sizeZ.toIntOrNull()
    val parsedH = height.toIntOrNull()
    val valid = name.isNotBlank() && parsedX != null && parsedX in 8..512 && parsedZ != null && parsedZ in 8..512 && parsedH != null && parsedH in 16..384
    val current = maps.firstOrNull { it.id == editingId }

    fun reset() {
        editingId = null
        name = "Nouvelle map"; sizeX = "64"; sizeZ = "64"; height = "64"
        terrain = "desert"; dimension = "minecraft:overworld"; seed = "0"; worldX = "0"; worldZ = "0"
        village = true; dungeon = true; oasis = false; mountains = false; roads = false; notes = ""; showErrors = false
        linkedMobIds = emptyList(); linkedItemIds = emptyList(); linkedBlockIds = emptyList(); worldFilterTextureId = null
    }

    fun load(m: MapBlueprint) {
        editingId = m.id; name = m.name; sizeX = m.sizeX.toString(); sizeZ = m.sizeZ.toString(); height = m.height.toString()
        terrain = m.terrain; dimension = m.dimension; seed = m.seed.toString(); worldX = m.worldX.toString(); worldZ = m.worldZ.toString()
        village = m.hasVillage; dungeon = m.hasDungeon; oasis = m.hasOasis; mountains = m.hasMountains; roads = m.hasRoads; notes = m.notes; showErrors = false
        linkedMobIds = m.linkedMobIds; linkedItemIds = m.linkedItemIds; linkedBlockIds = m.linkedBlockIds
        worldFilterTextureId = m.worldFilterTextureId
    }

    fun submit() {
        if (!valid) { showErrors = true; return }
        val existing = current
        onSave(MapBlueprint(
            id = existing?.id ?: java.util.UUID.randomUUID().toString(),
            projectId = projectId,
            name = name.trim(),
            sizeX = parsedX ?: 64,
            sizeZ = parsedZ ?: 64,
            height = parsedH ?: 64,
            theme = "desert_gothic",
            terrain = terrain,
            seed = seed.toLongOrNull() ?: 0L,
            worldX = worldX.toIntOrNull() ?: 0,
            worldZ = worldZ.toIntOrNull() ?: 0,
            hasVillage = village,
            hasDungeon = dungeon,
            hasOasis = oasis,
            hasMountains = mountains,
            hasRoads = roads,
            dimension = dimension.trim().ifBlank { "minecraft:overworld" },
            linkedMobIds = linkedMobIds,
            linkedItemIds = linkedItemIds,
            linkedBlockIds = linkedBlockIds,
            worldFilterTextureId = worldFilterTextureId,
            notes = notes.trim()
        ))
        reset()
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("🗺️ Cartes du monde", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold, fontSize = 20.sp)
        Text("Cette map est reliée à l'Atelier (mobs, items, blocs, portails, textures). Map Studio peut l'utiliser comme base 3D.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)

        Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (editingId == null) "Nouvelle carte" else "Modifier la carte", fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(sizeX, { sizeX = it }, label = { Text("Largeur X") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(sizeZ, { sizeZ = it }, label = { Text("Longueur Z") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(height, { height = it }, label = { Text("Hauteur") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(worldX, { worldX = it }, label = { Text("Monde X") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(worldZ, { worldZ = it }, label = { Text("Monde Z") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(seed, { seed = it }, label = { Text("Seed") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(terrain, { terrain = it }, label = { Text("Terrain / biome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(dimension, { dimension = it }, label = { Text("Dimension") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(village, { village = it }); Text("Village", color = AgwColors.PaleMarble)
                    Checkbox(dungeon, { dungeon = it }); Text("Donjon", color = AgwColors.PaleMarble)
                    Checkbox(oasis, { oasis = it }); Text("Oasis", color = AgwColors.PaleMarble)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(mountains, { mountains = it }); Text("Montagnes", color = AgwColors.PaleMarble)
                    Checkbox(roads, { roads = it }); Text("Routes", color = AgwColors.PaleMarble)
                }
                Text("Liaisons atelier", fontWeight = FontWeight.SemiBold, color = AgwColors.SacredGold)
                LinkChipRow(
                    title = "Mobs sur cette map",
                    all = mobs,
                    selectedIds = linkedMobIds,
                    idOf = { it.id },
                    labelOf = { it.nom },
                    onToggle = { id ->
                        linkedMobIds = if (id in linkedMobIds) linkedMobIds - id else linkedMobIds + id
                    }
                )
                LinkChipRow(
                    title = "Items (loot / commerce)",
                    all = items,
                    selectedIds = linkedItemIds,
                    idOf = { it.id },
                    labelOf = { it.name },
                    onToggle = { id ->
                        linkedItemIds = if (id in linkedItemIds) linkedItemIds - id else linkedItemIds + id
                    }
                )
                LinkChipRow(
                    title = "Blocs de construction",
                    all = blocks,
                    selectedIds = linkedBlockIds,
                    idOf = { it.id },
                    labelOf = { it.name },
                    onToggle = { id ->
                        linkedBlockIds = if (id in linkedBlockIds) linkedBlockIds - id else linkedBlockIds + id
                    }
                )
                StudioTexturePicker(
                    textures = textures,
                    selectedUri = worldFilterTextureId?.let { "sbhtex://$it" },
                    onSelect = { uri ->
                        worldFilterTextureId = uri?.removePrefix("sbhtex://")
                    },
                    preferredFormats = listOf("FILTER_MAP", "BLOCK_32", "BLOCK_16")
                )
                Text("Filtre monde (texture d'ambiance)", color = AgwColors.Sand, fontSize = 11.sp)

                OutlinedTextField(notes, { notes = it }, label = { Text("Notes / description") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                if (showErrors && !valid) Text("⚠ Vérifie le nom et les dimensions : X/Z 8–512, hauteur 16–384.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { submit() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)) {
                        Text(if (editingId == null) "Créer la map" else "Enregistrer")
                    }
                    if (editingId != null) OutlinedButton(onClick = { reset() }) { Text("Annuler") }
                }
            }
        }

        maps.forEach { m ->
            val linked = portals.filter { it.linkedMapId == m.id }
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(m.name, fontWeight = FontWeight.SemiBold, color = AgwColors.PaleMarble)
                            Text("ID: ${m.id}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                            Text("${m.sizeX}×${m.sizeZ}×${m.height} · ${m.terrain} · ${m.dimension}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                            Text("Position monde : ${m.worldX}, ${m.worldZ} · Seed : ${m.seed}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                        }
                        Row {
                            TextButton({ load(m) }) { Text("✎") }
                            TextButton({ onDelete(m); if (editingId == m.id) reset() }) { Text("X") }
                        }
                    }

                    MapPreviewCard(m)

                    Text("🔗 Portails liés : ${linked.size}", color = AgwColors.DesertOchre, style = MaterialTheme.typography.bodySmall)
                    if (portals.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            portals.forEach { p ->
                                val selected = p.linkedMapId == m.id
                                OutlinedButton(
                                    onClick = { onLinkPortal(p, if (selected) null else m.id) },
                                    colors = if (selected) ButtonDefaults.outlinedButtonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight) else ButtonDefaults.outlinedButtonColors(contentColor = AgwColors.PaleMarble)
                                ) { Text(if (selected) "✓ ${p.name}" else "+ ${p.name}") }
                            }
                        }
                    } else {
                        Text("Crée d’abord un portail pour le rattacher à cette map.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        if (maps.isEmpty()) Text("Aucune map. Crée la première carte ci-dessus.", color = AgwColors.Sand)
    }
}

@Composable
private fun MapPreviewCard(map: MapBlueprint) {
    Card(colors = CardDefaults.cardColors(containerColor = AgwColors.DeepNight), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(8.dp)) {
            Text("Aperçu logique · ${map.terrain}", color = AgwColors.PaleMarble, style = MaterialTheme.typography.labelMedium)
            Canvas(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF15110D))) {
                val w = size.width
                val h = size.height
                val cols = maxOf(8, minOf(32, map.sizeX / 4))
                val rows = maxOf(8, minOf(24, map.sizeZ / 4))
                val cw = w / cols
                val rh = h / rows
                for (z in 0 until rows) {
                    for (x in 0 until cols) {
                        val nx = x.toFloat() / cols
                        val nz = z.toFloat() / rows
                        val oasis = map.hasOasis && ((nx - 0.35f) * (nx - 0.35f) + (nz - 0.55f) * (nz - 0.55f) < 0.025f)
                        val mountain = map.hasMountains && (nz < 0.25f && nx > 0.45f)
                        val c = when {
                            oasis -> Color(0xFF3D6B45)
                            mountain -> Color(0xFF5A5550)
                            map.terrain.contains("snow", true) -> Color(0xFFD9D3C7)
                            map.terrain.contains("forest", true) -> Color(0xFF40553B)
                            map.terrain.contains("plains", true) -> Color(0xFF6D7144)
                            else -> Color(0xFF8C6B43)
                        }
                        drawRect(c, Offset(x * cw, z * rh), androidx.compose.ui.geometry.Size(cw + 1f, rh + 1f))
                    }
                }
                if (map.hasRoads) {
                    drawLine(Color(0xFFD8B56A), Offset(0f, h * 0.68f), Offset(w, h * 0.68f), strokeWidth = 4f)
                    drawLine(Color(0xFFD8B56A), Offset(w * 0.58f, 0f), Offset(w * 0.58f, h), strokeWidth = 4f)
                }
                if (map.hasVillage) {
                    drawCircle(Color(0xFFE2C15A), radius = 8f, center = Offset(w * 0.58f, h * 0.68f))
                }
                if (map.hasDungeon) {
                    drawCircle(Color(0xFFB34B4B), radius = 7f, center = Offset(w * 0.72f, h * 0.32f))
                }
            }
        }
    }
}
