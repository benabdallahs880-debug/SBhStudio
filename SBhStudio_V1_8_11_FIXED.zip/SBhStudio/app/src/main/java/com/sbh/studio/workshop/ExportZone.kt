package com.sbh.studio.workshop

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AgwDecor
import com.sbh.studio.ui.GoldOutlineButton
import com.sbh.studio.ui.GoldPrimaryButton

@Composable
internal fun ExportZone(
    reportText: String,
    hasProject: Boolean,
    counts: String,
    onValidate: () -> Unit,
    onExport: () -> Unit,
    onImportAgw: () -> Unit
) {
    val hasErrors = reportText.contains("❌")
    val hasWarnings = reportText.contains("⚠")
    val isOk = reportText.contains("✅") && !hasErrors

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Validation & export complet", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
        Text("Projet : ${if (hasProject) "ouvert" else "aucun"} · $counts", color = AgwColors.Sand)
        if (!hasProject) {
            Text("Astuce : Accueil → ouvrez un projet → Atelier.", color = AgwColors.DesertOchre)
        }

        Text(
            "La validation croisée vérifie les liens maps↔portails↔mobs/items/blocs, recettes, entités 3D et sons avant l'export.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        GoldOutlineButton("Importer AGW puis exporter", onImportAgw, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldOutlineButton("Valider", onValidate, modifier = Modifier.weight(1f))
            GoldPrimaryButton("Exporter", onExport, modifier = Modifier.weight(1f))
        }

        if (reportText.isNotBlank()) {
            val borderColor = when {
                hasErrors -> AgwColors.Error
                hasWarnings -> AgwColors.DesertOchre
                isOk -> AgwColors.SacredGold
                else -> AgwColors.GoldSoft
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = AgwColors.NightGlass),
                shape = AgwDecor.CardShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, borderColor, AgwDecor.CardShape)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        when {
                            hasErrors -> "Rapport — erreurs bloquantes"
                            hasWarnings -> "Rapport — avertissements"
                            isOk -> "Rapport — OK"
                            else -> "Rapport"
                        },
                        fontWeight = FontWeight.SemiBold,
                        color = borderColor
                    )
                    Text(
                        reportText,
                        color = AgwColors.PaleMarble,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
