package com.sbh.studio.workshop

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sbh.studio.data.SbhSound
import com.sbh.studio.data.SoundEvents
import com.sbh.studio.data.SoundRepository
import com.sbh.studio.ui.AgwColors
import com.sbh.studio.ui.AgwDecor
import com.sbh.studio.ui.GoldPrimaryButton
import com.sbh.studio.ui.SectionTitle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SoundZone(
    projectId: String,
    projectName: String?,
    sounds: List<SbhSound>,
    hasProject: Boolean,
    soundRepo: SoundRepository,
    onRefresh: () -> Unit,
    onMessage: (String) -> Unit
) {
    var eventTarget by remember { mutableStateOf<SbhSound?>(null) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        if (!hasProject) {
            onMessage("Ouvrez un projet avant d'importer un son")
            return@rememberLauncherForActivityResult
        }
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "nasheed"
        val result = soundRepo.importFromUri(uri, name, projectId = projectId)
        onRefresh()
        if (result.sound != null) {
            val tag = if (result.sound.extension == "ogg") "Ogg OK" else result.sound.extension.uppercase()
            onMessage("Importé : ${result.sound.name} ($tag) — ${result.message}")
        } else {
            onMessage(result.message.ifBlank { "Échec de l'import" })
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionTitle("Sons / نشيد · ${projectName ?: "projet"}")
        Text(
            "Importez des nasheeds ou musiques pour ce projet. Cochez Pack pour les inclure dans l'export Minecraft.",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.bodySmall
        )

        GoldPrimaryButton(
            text = "+ Importer un son",
            onClick = {
                if (!hasProject) onMessage("Ouvrez un projet")
                else importLauncher.launch(
                    arrayOf("audio/*", "audio/ogg", "audio/mpeg", "audio/mp4", "audio/wav", "application/ogg")
                )
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = hasProject
        )

        Text(
            "${sounds.size} son(s) · ${sounds.count { it.includeInPack }} dans le pack",
            color = AgwColors.SacredGold,
            fontWeight = FontWeight.SemiBold
        )

        if (sounds.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AgwColors.Panel),
                shape = AgwDecor.CardShape
            ) {
                Column(
                    Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Aucun son dans ce projet", color = AgwColors.PaleMarble, fontWeight = FontWeight.Medium)
                    Text(
                        "Formats : ogg (recommandé), mp3, m4a, wav.",
                        color = AgwColors.Sand,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else {
            sounds.forEach { sound ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AgwColors.Panel),
                    shape = AgwDecor.CardShape
                ) {
                    Column(
                        Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(sound.name, color = AgwColors.PaleMarble, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${sound.extension.uppercase()} · ${sound.definitionKey()}" +
                                if (sound.notes.isNotBlank()) " · ${sound.notes}" else "",
                            color = AgwColors.Sand,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = sound.includeInPack,
                                onClick = {
                                    soundRepo.update(sound.copy(includeInPack = !sound.includeInPack))
                                    onRefresh()
                                },
                                label = {
                                    Text(
                                        if (sound.includeInPack) "Pack OK" else "Pack",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AgwColors.GoldMuted,
                                    selectedLabelColor = AgwColors.GoldSoft,
                                    containerColor = AgwColors.NightStone,
                                    labelColor = AgwColors.Sand
                                )
                            )
                            TextButton(onClick = { eventTarget = sound }) {
                                Text("Événement", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelSmall)
                            }
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = {
                                soundRepo.delete(sound.id)
                                onRefresh()
                                onMessage("Supprimé : ${sound.name}")
                            }) {
                                Text("Supprimer", color = AgwColors.Error, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        SectionTitle("Événements Minecraft utiles")
        Text(
            "music.game · music.menu · music.game.creative · record.cat · ambient.cave · ou sbh.music.*",
            color = AgwColors.Sand,
            style = MaterialTheme.typography.labelSmall
        )
    }

    val target = eventTarget
    if (target != null) {
        var selected by remember(target.id) {
            mutableStateOf(
                SoundEvents.PRESETS.find { it.id == target.soundEvent }?.id
                    ?: if (target.soundEvent.startsWith("sbh.")) "custom" else target.soundEvent
            )
        }
        AlertDialog(
            onDismissRequest = { eventTarget = null },
            containerColor = AgwColors.Panel,
            title = {
                Text("Événement pour ${target.name}", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SoundEvents.PRESETS.forEach { preset ->
                        val active = selected == preset.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = preset.id }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = active,
                                onClick = { selected = preset.id },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = AgwColors.SacredGold,
                                    unselectedColor = AgwColors.Sand
                                )
                            )
                            Column {
                                Text(preset.label, color = AgwColors.PaleMarble)
                                Text(preset.description, color = AgwColors.Sand, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val finalEvent = if (selected == "custom") {
                        "sbh.music.${SbhSound.sanitize(target.fileName)}"
                    } else selected
                    val cat = when {
                        selected.startsWith("music") || selected.startsWith("record") || selected == "custom" -> "music"
                        selected.startsWith("ambient") -> "ambient"
                        else -> "music"
                    }
                    soundRepo.update(target.copy(soundEvent = finalEvent, category = cat))
                    onRefresh()
                    eventTarget = null
                    onMessage("Événement : $finalEvent")
                }) { Text("Valider", color = AgwColors.SacredGold) }
            },
            dismissButton = {
                TextButton(onClick = { eventTarget = null }) {
                    Text("Annuler", color = AgwColors.Sand)
                }
            }
        )
    }
}
