package com.sbh.studio.workshop

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File

private val gbJson = Json { prettyPrint = true; ignoreUnknownKeys = true }

/**
 * Persistance des blueprints Game Builder + lecture des templates assets.
 */
class GameBuilderRepository(private val context: Context) {
    private fun file() = File(context.filesDir, "sbh_game_projects.json")

    fun loadAll(): List<GameProjectBlueprint> = try {
        val f = file()
        if (!f.exists()) emptyList()
        else gbJson.decodeFromString(f.readText())
    } catch (_: Exception) {
        emptyList()
    }

    fun saveAll(list: List<GameProjectBlueprint>) {
        val f = file()
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, "${f.name}.tmp")
        tmp.writeText(gbJson.encodeToString(list))
        if (!tmp.renameTo(f)) {
            f.delete()
            tmp.renameTo(f)
        }
    }

    fun loadSchemaText(): String = try {
        context.assets.open("game_builder/game_project.schema.json").bufferedReader().use { it.readText() }
    } catch (_: Exception) {
        "{}"
    }

    fun loadTemplates(): List<GameBuilderTemplate> {
        val out = mutableListOf<GameBuilderTemplate>()
        try {
            val names = context.assets.list("game_builder/templates") ?: emptyArray()
            for (name in names.sorted()) {
                if (!name.endsWith(".json")) continue
                val text = context.assets.open("game_builder/templates/$name").bufferedReader().use { it.readText() }
                val obj = runCatching { gbJson.parseToJsonElement(text).jsonObject }.getOrNull()
                val isWorld = obj?.containsKey("engine") == true || obj?.containsKey("world") == true
                val perf = obj?.get("performance")?.jsonPrimitive?.content
                    ?: obj?.get("profile")?.jsonPrimitive?.content
                val label = name.removeSuffix(".json").replace('_', ' ')
                out += GameBuilderTemplate(
                    id = name,
                    name = label.replaceFirstChar { it.uppercase() },
                    description = if (isWorld) {
                        "Template monde / projet jeu"
                    } else {
                        "Profil mobile · ${perf ?: "?"}"
                    },
                    isWorldTemplate = isWorld,
                    performanceHint = perf
                )
            }
        } catch (_: Exception) { /* assets absents en test unitaire */ }
        return out
    }

    fun loadTemplateJson(assetName: String): String? = try {
        context.assets.open("game_builder/templates/$assetName").bufferedReader().use { it.readText() }
    } catch (_: Exception) {
        null
    }

    /** Construit un blueprint à partir d'un template monde (demo_world.json). */
    fun blueprintFromWorldTemplate(
        projectId: String,
        assetName: String,
        displayName: String? = null
    ): GameProjectBlueprint? {
        val text = loadTemplateJson(assetName) ?: return null
        val obj = runCatching { gbJson.parseToJsonElement(text).jsonObject }.getOrNull() ?: return null
        val world = obj["world"]?.jsonObject
        val size = world?.get("size")?.jsonObject
        val gameplay = obj["gameplay"]?.jsonObject
        fun str(o: JsonObject?, key: String, default: String = "") =
            o?.get(key)?.jsonPrimitive?.content ?: default
        fun int(o: JsonObject?, key: String, default: Int) =
            o?.get(key)?.jsonPrimitive?.content?.toIntOrNull() ?: default

        return GameProjectBlueprint(
            projectId = projectId,
            name = displayName ?: str(obj, "name", "Nouveau jeu"),
            engine = str(obj, "engine", "godot"),
            target = str(obj, "target", "android_mobile"),
            performance = str(obj, "performance", "balanced"),
            worldScene = str(world, "scene", "worlds/main.tscn"),
            worldSizeX = int(size, "x", 1024),
            worldSizeY = int(size, "y", 256),
            worldSizeZ = int(size, "z", 1024),
            playerPrefab = str(gameplay, "player", "player/default"),
            factions = gameplay?.get("factions")?.toString()
                ?.trim('[', ']')
                ?.split(",")
                ?.map { it.trim().trim('"') }
                ?.filter { it.isNotEmpty() }
                ?: listOf("player", "neutral", "enemy"),
            missions = emptyList(),
            vehicles = emptyList(),
            profileJson = "",
            notes = "Créé depuis template $assetName"
        )
    }

    fun profileJsonFor(performance: String): String {
        val file = when (performance.lowercase()) {
            "light" -> "mobile_light.json"
            "performance" -> "mobile_performance.json"
            else -> "mobile_balanced.json"
        }
        return loadTemplateJson(file).orEmpty()
    }
}
