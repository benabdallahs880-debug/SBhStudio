package com.sbh.studio.mapeditor

/**
 * Pont en mémoire (process unique) entre un autre écran — typiquement Character Studio —
 * et Map Studio : dépose le chemin d'un fichier .glb déjà généré, à injecter directement
 * dans le viewport 3D dès l'ouverture suivante de l'Éditeur 3D, sans repasser par le
 * sélecteur de fichiers système (qui ne voit pas le stockage privé de l'app).
 */
object PendingMapImport {
    data class Payload(val filePath: String, val displayName: String)

    @Volatile
    private var pending: Payload? = null

    fun offer(filePath: String, displayName: String) {
        pending = Payload(filePath, displayName)
    }

    /** Consomme la demande en attente (une seule fois). */
    fun take(): Payload? {
        val p = pending
        pending = null
        return p
    }
}
