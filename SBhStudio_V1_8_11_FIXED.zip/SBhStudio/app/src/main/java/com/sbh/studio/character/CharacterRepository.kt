package com.sbh.studio.character
import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
private val characterJson = Json { prettyPrint = true; ignoreUnknownKeys = true }
class CharacterRepository(private val context: Context) {
    private fun file() = File(context.filesDir, "sbh_character_projects.json")
    fun loadAll(): List<CharacterProject> = try { val f=file(); if(!f.exists()) emptyList() else characterJson.decodeFromString(f.readText()) } catch(_:Exception){ emptyList() }
    fun saveAll(value: List<CharacterProject>) { val f=file(); f.parentFile?.mkdirs(); val tmp=File(f.parentFile,"${f.name}.tmp"); tmp.writeText(characterJson.encodeToString(value)); if(!tmp.renameTo(f)){f.delete();tmp.renameTo(f)} }
}
