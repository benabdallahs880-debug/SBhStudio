# SBh Studio V1.8.9 — Character Studio Étape 7

## Connecteur Image→3D HTTPS générique

- Ajout d'un transport distant générique sans fournisseur imposé.
- Endpoint HTTPS configurable dans Character Studio.
- Soumission d'un job via `POST /jobs`.
- Suivi via `GET /jobs/{id}`.
- Progression et messages du job remontés dans l'interface.
- Téléchargement du GLB final via `resultUrl`.
- Validation minimale du GLB téléchargé.
- Stockage dans `filesDir/character_models`.
- Injection automatique dans `CharacterProject.modelUri` et dans le viewport.
- Aucun secret/API key embarqué dans le projet.
- Aucun appel distant n'est effectué tant qu'un endpoint HTTPS n'est pas configuré.

## Contrat attendu

`POST /jobs` reçoit le JSON de `CharacterGenerationRequest` et doit retourner au minimum :

```json
{"jobId":"..."}
```

`GET /jobs/{id}` doit retourner par exemple :

```json
{
  "jobId":"...",
  "status":"SUCCEEDED",
  "progress":100,
  "message":"Model ready",
  "resultUrl":"https://.../character.glb",
  "resultName":"character.glb"
}
```

## Validation

- Validateur statique SBh : 0 erreur, 0 avertissement.
- Compilation Gradle complète non déclarée comme réussie tant que l'environnement de build n'a pas accès aux dépendances Gradle/Maven.
