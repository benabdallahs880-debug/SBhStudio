# SBh Studio V1.8.10 — Character Studio Étape 8

## Fournisseur réel Image → 3D : Meshy

- Ajout du fournisseur `Meshy Image→3D`.
- Utilise l'API officielle Meshy Image-to-3D ou Multi-Image-to-3D.
- Une image utilise `/openapi/v1/image-to-3d`.
- Deux à quatre références utilisent `/openapi/v1/multi-image-to-3d`.
- Sortie demandée : GLB uniquement.
- Suivi du job jusqu'à `SUCCEEDED`/`FAILED`.
- Téléchargement du GLB dans l'espace privé de l'application.
- Injection du résultat dans Character Studio.
- La clé API n'est pas embarquée dans le code : elle est saisie par l'utilisateur et chiffrée avec Android Keystore.
- Aucun appel Meshy n'est effectué tant que l'utilisateur n'a pas lancé explicitement la génération.

## Validation

Le validateur statique doit rester à 0 erreur / 0 avertissement. La compilation Gradle dépend de l'accès aux dépôts Maven/Gradle du runner.
