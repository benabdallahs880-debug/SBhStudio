# SBh Studio V1.8.5 — Character Studio Étape 3

## Étape 3 : Image → analyse → préparation 3D
- Analyse locale réelle des images de référence : format, dimensions, ratio, qualité et cadrage.
- Détection de points de vigilance et recommandations pour préparer une reconstruction 3D.
- Nouveau contrat `CharacterGenerator` pour séparer les moteurs local, cloud et IA.
- Le moteur IA distant est explicitement non configuré : aucune fausse génération et aucun envoi réseau.
- Conservation du viewport 3D et du pipeline GLB/GLTF de V1.8.4.

## Validation
Le validateur statique SBh doit être exécuté sur le projet. La compilation Gradle dépend toujours de l'accès au dépôt Gradle/Maven de l'environnement.
