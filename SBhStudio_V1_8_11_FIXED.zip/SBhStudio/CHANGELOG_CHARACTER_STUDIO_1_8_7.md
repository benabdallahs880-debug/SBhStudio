# SBh Studio V1.8.7 — Character Studio Étape 5

## Pipeline de génération
- Ajout d'un modèle de job de génération avec états QUEUED/RUNNING/SUCCEEDED/FAILED.
- Ajout d'un moteur local prototype.
- Le moteur valide le dossier multi-vues avant génération.
- Il produit un GLB game-ready de base à partir du mannequin embarqué.
- Le fichier est copié dans le stockage privé de l'application et validé avant utilisation.
- Le modèle généré est automatiquement injecté dans le Character Studio et le viewport 3D.
- Le moteur IA distant reste explicitement non configuré.

## Limite volontaire
Cette étape ne prétend pas réaliser une reconstruction Image→3D photoréaliste hors ligne. Elle établit le pipeline réel de jobs et de sortie GLB afin que le futur moteur Image→3D puisse remplacer le générateur local sans refaire l'interface ni le cycle de vie du personnage.
