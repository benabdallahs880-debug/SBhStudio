# SBh Studio -- Session Atelier 2.0

Base: V1.8.2 MAPFIX
P1 Workshop split | P2 Entities 3D | P3 Cross validation | P4 Game Builder | Hub badge | Silver glass UI

Rebuild: python3 tools/validate_sbh.py && ./gradlew assembleDebug
