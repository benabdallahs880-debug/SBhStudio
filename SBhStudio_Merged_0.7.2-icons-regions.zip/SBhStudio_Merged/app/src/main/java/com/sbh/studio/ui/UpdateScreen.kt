package com.sbh.studio.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sbh.studio.BuildConfig
import com.sbh.studio.data.DownloadState
import com.sbh.studio.data.UpdateCheckResult
import com.sbh.studio.data.UpdateInfo
import com.sbh.studio.data.UpdateManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdateScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val updateManager = remember { UpdateManager(context) }
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var checkResult by remember { mutableStateOf<UpdateCheckResult?>(null) }
    var downloadState by remember { mutableStateOf<DownloadState>(DownloadState.Idle) }

    val assetInfo = remember { updateManager.localVersionFromAssets() }
    val currentCode = assetInfo?.versionCode ?: BuildConfig.VERSION_CODE
    val currentName = assetInfo?.versionName ?: BuildConfig.VERSION_NAME

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mises à jour", color = AgwColors.SacredGold, fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onBack) { Text("←") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AgwColors.NightStone)
            )
        },
        containerColor = AgwColors.DeepNight
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Version installée", color = AgwColors.DesertOchre, style = MaterialTheme.typography.labelMedium)
                    Text("$currentName  ·  code $currentCode", fontWeight = FontWeight.Bold, color = AgwColors.SacredGold)
                    Text(
                        "Source : version.json (même fichier que la release GitHub)",
                        style = MaterialTheme.typography.bodySmall,
                        color = AgwColors.Sand
                    )
                }
            }

            Button(
                onClick = {
                    checking = true
                    checkResult = null
                    downloadState = DownloadState.Idle
                    scope.launch {
                        checkResult = updateManager.checkForUpdate(currentCode)
                        checking = false
                    }
                },
                enabled = !checking && downloadState !is DownloadState.Downloading,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
            ) {
                Text(if (checking) "Vérification en cours…" else "Vérifier les mises à jour")
            }

            when (val result = checkResult) {
                is UpdateCheckResult.UpToDate -> {
                    Text("Tu as déjà la dernière version.", color = AgwColors.GoldSoft)
                }
                is UpdateCheckResult.Error -> {
                    Text("Impossible de vérifier", fontWeight = FontWeight.Bold, color = AgwColors.DriedBlood)
                    Text(result.message, color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Vérifie : réseau, repo public, release avec APK + body = version.json",
                        color = AgwColors.DesertOchre,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                is UpdateCheckResult.UpdateAvailable -> UpdateAvailableCard(
                    info = result.info,
                    localCode = currentCode,
                    downloadState = downloadState,
                    onDownload = {
                        downloadState = DownloadState.Downloading
                        scope.launch {
                            try {
                                val id = updateManager.startDownload(result.info.apkUrl)
                                downloadState = updateManager.awaitDownload(id)
                            } catch (e: Exception) {
                                downloadState = DownloadState.Failed(e.message ?: "Erreur téléchargement")
                            }
                        }
                    },
                    onInstall = { file -> updateManager.installApk(file) }
                )
                null -> {
                    Text("Appuie sur Vérifier pour interroger GitHub Releases.", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(Modifier.weight(1f))
            Text(
                "Le versionCode de version.json doit être identique dans l'APK (assets + build.gradle) et dans le body de la release GitHub.",
                style = MaterialTheme.typography.bodySmall,
                color = AgwColors.Sand
            )
        }
    }
}

@Composable
private fun UpdateAvailableCard(
    info: UpdateInfo,
    localCode: Int,
    downloadState: DownloadState,
    onDownload: () -> Unit,
    onInstall: (java.io.File) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AgwColors.NightStone)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Nouvelle version disponible", color = AgwColors.GoldSoft, style = MaterialTheme.typography.labelMedium)
            Text("${info.versionName}  ·  code ${info.versionCode}", style = MaterialTheme.typography.titleMedium, color = AgwColors.SacredGold)
            Text("Installé : code $localCode → Distant : code ${info.versionCode}", color = AgwColors.Sand, style = MaterialTheme.typography.bodySmall)
            if (info.notes.isNotBlank()) {
                Text(info.notes, style = MaterialTheme.typography.bodyMedium, color = AgwColors.PaleMarble)
            }

            when (val s = downloadState) {
                is DownloadState.Idle -> Button(
                    onClick = onDownload,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
                ) { Text("Télécharger l'APK") }
                is DownloadState.Downloading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp), color = AgwColors.SacredGold)
                    Spacer(Modifier.width(10.dp))
                    Text("Téléchargement…", color = AgwColors.Sand)
                }
                is DownloadState.ReadyToInstall -> Button(
                    onClick = { onInstall(s.apkFile) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AgwColors.SacredGold, contentColor = AgwColors.DeepNight)
                ) { Text("Installer maintenant") }
                is DownloadState.Failed -> Text("Échec : ${s.message}", color = AgwColors.DriedBlood)
            }
        }
    }
}
