package com.sbh.studio.mapeditor

import android.annotation.SuppressLint
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Éditeur de maps 3D intégré (Three.js via WebView).
 * Charge assets/mapstudio.html et expose un bridge Android
 * pour exporter la map vers SBh Studio (JSON → structure / atelier).
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MapEditorScreen(
    onBack: () -> Unit,
    onMapExported: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val webView = remember {
        WebView(context).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean = false
            }
            setBackgroundColor(android.graphics.Color.parseColor("#1A1612"))
        }
    }

    val bridge = remember {
        object {
            @JavascriptInterface
            fun close() {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    onBack()
                }
            }

            @JavascriptInterface
            fun exportMap(json: String) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    onMapExported(json)
                    Toast.makeText(context, "Map importée dans SBh Studio ✓", Toast.LENGTH_SHORT).show()
                }
            }

            @JavascriptInterface
            fun toast(msg: String) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    DisposableEffect(Unit) {
        webView.addJavascriptInterface(bridge, "SBhBridge")
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun onPageFinished(view: android.webkit.WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Injecter les régions fondation si disponibles
                val regionsFile = java.io.File(context.filesDir, "map_studio_regions.json")
                if (regionsFile.exists()) {
                    val json = regionsFile.readText().replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
                    view?.evaluateJavascript(
                        """
                        (function(){
                          try {
                            window.__SBH_REGIONS__ = JSON.parse('$json');
                            if (typeof toast === 'function') toast('Régions AGW chargées (' + (window.__SBH_REGIONS__.regions||[]).length + ')');
                          } catch(e) { console.warn('regions inject', e); }
                        })();
                        """.trimIndent(),
                        null
                    )
                }
            }
        }
        webView.loadUrl("file:///android_asset/mapstudio.html")
        onDispose {
            webView.removeJavascriptInterface("SBhBridge")
            webView.stopLoading()
            webView.destroy()
        }
    }

    BackHandler { onBack() }

    AndroidView(
        factory = { webView },
        modifier = Modifier.fillMaxSize()
    )
}
