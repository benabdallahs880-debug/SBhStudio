package com.sbh.studio.data

import com.sbh.studio.animation.AnimSoul
import com.sbh.studio.animation.AnimationPresets
import com.sbh.studio.data.Identifiers

/**
 * Moteur monstre — logique centrale atelier ↔ export.
 *
 * - validate : erreurs / avertissements
 * - deriveDefaults : collision, détection selon forme (suggestions, pas forcées)
 * - suggestSoul : âme d'animation recommandée
 * - prepareForExport : copie normalisée pour PackGenerator (bornes, familles)
 *
 * N'impose rien à l'utilisateur : l'UI appelle applySuggestions uniquement sur clic.
 */
object MobEngine {

    data class Issue(
        val level: Level,
        val message: String
    ) {
        enum class Level { ERROR, WARN, INFO }
    }

    data class Report(
        val issues: List<Issue>,
        val ok: Boolean get() = issues.none { it.level == Issue.Level.ERROR }
    )

    data class FormeDefaults(
        val collisionLargeur: Double,
        val collisionHauteur: Double,
        val detectionDistance: Double,
        val vitesse: Double,
        val geometryId: String
    )

    data class ExportHints(
        val familyTags: List<String>,
        val suggestedSoul: AnimSoul,
        val geometryId: String,
        val isHostileFamily: Boolean
    )

    fun formeDefaults(formeBase: String): FormeDefaults {
        val shape = MobShapeCatalog.shapes.firstOrNull { it.id == formeBase }
        val geo = shape?.geometryId ?: MobShapeCatalog.geometryFor(formeBase)
        return when (formeBase.lowercase()) {
            "zombie", "skeleton", "humanoid" -> FormeDefaults(0.6, 1.8, 24.0, 0.25, geo)
            "creeper" -> FormeDefaults(0.6, 1.7, 20.0, 0.2, geo)
            "spider" -> FormeDefaults(1.4, 0.9, 16.0, 0.3, geo)
            "wolf" -> FormeDefaults(0.6, 0.85, 28.0, 0.3, geo)
            "cow", "pig", "sheep" -> FormeDefaults(0.9, 1.4, 12.0, 0.2, geo)
            "chicken" -> FormeDefaults(0.4, 0.7, 10.0, 0.25, geo)
            "horse" -> FormeDefaults(1.4, 1.6, 16.0, 0.35, geo)
            else -> FormeDefaults(0.6, 1.8, 24.0, 0.25, geo)
        }
    }

    fun suggestSoul(formeBase: String): AnimSoul =
        AnimationPresets.soulForForme(formeBase)

    fun validate(m: MobEntity, existingIdentifiers: Set<String> = emptySet()): Report {
        val issues = mutableListOf<Issue>()
        val idErr = Identifiers.explain(m.identifiant)
        if (idErr != null) {
            issues += Issue(Issue.Level.ERROR, "Identifiant : $idErr (${m.identifiant})")
        }
        if (m.nom.isBlank()) {
            issues += Issue(Issue.Level.ERROR, "Nom vide")
        }
        if (m.identifiant in existingIdentifiers) {
            issues += Issue(Issue.Level.WARN, "Identifiant déjà utilisé dans le projet : ${m.identifiant}")
        }
        if (m.vie !in 1..1000) {
            issues += Issue(Issue.Level.WARN, "PV hors plage utile (1–1000) : ${m.vie}")
        }
        if (m.vitesse !in 0.01..2.0) {
            issues += Issue(Issue.Level.WARN, "Vitesse hors plage (0.01–2) : ${m.vitesse}")
        }
        if (m.collisionLargeur !in 0.1..4.0 || m.collisionHauteur !in 0.1..8.0) {
            issues += Issue(Issue.Level.WARN, "Boîte de collision hors limites")
        }
        val known = MobShapeCatalog.shapes.any { it.id == m.formeBase }
        if (!known) {
            issues += Issue(Issue.Level.WARN, "Forme « ${m.formeBase} » inconnue — export humanoid par défaut")
        }
        if (m.hostile && !m.attaque && !m.poursuite) {
            issues += Issue(Issue.Level.INFO, "Hostile sans poursuite/attaque : comportement passif en export")
        }
        if (m.textureUri.isNullOrBlank()) {
            issues += Issue(Issue.Level.INFO, "Pas de texture : placeholder à l'export")
        }
        val def = formeDefaults(m.formeBase)
        val boxFar = kotlin.math.abs(m.collisionLargeur - def.collisionLargeur) > 0.35 ||
            kotlin.math.abs(m.collisionHauteur - def.collisionHauteur) > 0.5
        if (boxFar) {
            issues += Issue(
                Issue.Level.INFO,
                "Collision différente du standard « ${m.formeBase} » " +
                    "(${def.collisionLargeur}×${def.collisionHauteur}) — OK si voulu"
            )
        }
        return Report(issues)
    }

    /**
     * Suggestions non destructives : forme → collision / détection / vitesse de base.
     * Ne touche pas nom, id, texture, pouvoirs.
     */
    fun applyFormeSuggestions(m: MobEntity): MobEntity {
        val d = formeDefaults(m.formeBase)
        return m.copy(
            collisionLargeur = d.collisionLargeur,
            collisionHauteur = d.collisionHauteur,
            detectionDistance = d.detectionDistance,
            vitesse = d.vitesse
        )
    }

    /**
     * Si hostile sans flags combat, active poursuite + attaque (suggestion combat).
     */
    fun applyCombatSuggestions(m: MobEntity): MobEntity {
        if (!m.hostile) return m
        return m.copy(
            poursuite = true,
            attaque = true,
            reactionDegats = true
        )
    }

    fun applyAllSuggestions(m: MobEntity): MobEntity =
        applyCombatSuggestions(applyFormeSuggestions(m))

    fun exportHints(m: MobEntity): ExportHints {
        val families = mutableListOf<String>()
        if (m.hostile) {
            families += "monster"
            families += "sbh_hostile"
        } else {
            families += "sbh_creature"
        }
        families += "mob"
        if (m.faction.isNotBlank() && m.faction != "neutre") {
            families += "sbh_faction_${m.faction.lowercase().replace(Regex("[^a-z0-9_]"), "_")}"
        }
        when (m.formeBase.lowercase()) {
            "zombie" -> families += "zombie"
            "skeleton" -> families += "skeleton"
            "spider" -> families += "spider"
            "creeper" -> families += "creeper"
            "wolf" -> families += "wolf"
        }
        return ExportHints(
            familyTags = families.distinct(),
            suggestedSoul = suggestSoul(m.formeBase),
            geometryId = formeDefaults(m.formeBase).geometryId,
            isHostileFamily = m.hostile
        )
    }

    /**
     * Normalisation douce avant JSON Bedrock (bornes uniquement).
     */
    fun prepareForExport(m: MobEntity): MobEntity = m.copy(
        vie = m.vie.coerceIn(1, 1000),
        vitesse = m.vitesse.coerceIn(0.01, 2.0),
        degats = m.degats.coerceIn(0, 100),
        detectionDistance = m.detectionDistance.coerceIn(1.0, 128.0),
        collisionLargeur = m.collisionLargeur.coerceIn(0.1, 4.0),
        collisionHauteur = m.collisionHauteur.coerceIn(0.1, 8.0),
        formeBase = if (MobShapeCatalog.shapes.any { it.id == m.formeBase }) m.formeBase else "humanoid"
    )

    fun statusSummary(m: MobEntity, hasLinkedAnim: Boolean): String {
        val report = validate(m)
        val soul = suggestSoul(m.formeBase)
        val parts = mutableListOf<String>()
        parts += if (report.ok) "Moteur : OK" else "Moteur : ${report.issues.count { it.level == Issue.Level.ERROR }} erreur(s)"
        parts += "Forme ${m.formeBase}"
        parts += "Âme suggérée « ${soul.label} »"
        parts += if (hasLinkedAnim) "Anim liée ✓" else "Anim non liée"
        val warns = report.issues.count { it.level == Issue.Level.WARN }
        if (warns > 0) parts += "$warns avertissement(s)"
        return parts.joinToString(" · ")
    }
}
