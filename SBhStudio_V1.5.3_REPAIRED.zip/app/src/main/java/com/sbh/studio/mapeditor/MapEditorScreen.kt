package com.sbh.studio.mapeditor

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.sbh.studio.ui.AgwColors

/**
 * Éditeur de maps 3D intégré (Three.js via WebView).
 * Charge assets/mapstudio.html (Three.js embarqué localement, sans CDN)
 * et expose un bridge Android pour exporter la map vers SBh Studio.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MapEditorScreen(
    onBack: () -> Unit,
    onMapExported: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var loadStage by remember { mutableStateOf(0) }
    var pageReady by remember { mutableStateOf(false) }
    var studioReady by remember { mutableStateOf(false) }
    var retryCount by remember { mutableStateOf(0) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    var fileChooserCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val fileChooserLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        fileChooserCallback?.onReceiveValue(uri?.let { arrayOf(it) } ?: emptyArray())
        fileChooserCallback = null
    }

    val bridge = remember {
        object {
            @JavascriptInterface
            fun close() {
                mainHandler.post { onBack() }
            }

            @JavascriptInterface
            fun exportMap(json: String) {
                mainHandler.post {
                    onMapExported(json)
                    Toast.makeText(context, "Map importée dans SBh Studio ✓", Toast.LENGTH_SHORT).show()
                }
            }

            @JavascriptInterface
            fun ready() {
                try {
                    java.io.File(context.filesDir, "map_studio_last_error.txt").delete()
                    java.io.File(context.filesDir, "map_studio_last_ready.txt").writeText(System.currentTimeMillis().toString())
                } catch (_: Exception) {}
                mainHandler.post {
                    studioReady = true
                    loadStage = 8
                    loading = false
                }
            }

            @JavascriptInterface
            fun error(msg: String) {
                try { java.io.File(context.filesDir, "map_studio_last_error.txt").writeText(msg) } catch (_: Exception) {}
                mainHandler.post {
                    loadError = "Erreur JavaScript Map Studio : $msg"
                    loading = false
                    studioReady = false
                }
            }

            @JavascriptInterface
            fun toast(msg: String) {
                mainHandler.post {
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val assetLoader = remember {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
    }

    val webView = remember {
        WebView(context).apply {
            setBackgroundColor(Color.parseColor("#1A1612"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mediaPlaybackRequiresUserGesture = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                // Le HTML possède déjà un viewport mobile explicite.
                // Laisser WebView appliquer son propre zoom global agrandissait/rétrécissait
                // la page et perturbait les dimensions du canvas Three.js.
                useWideViewPort = false
                loadWithOverviewMode = false
                // Les assets sont servis par WebViewAssetLoader sur une origine HTTPS locale.
                // Aucune autorisation file:// inter-origines n'est nécessaire.
                // Améliore les perfs WebGL
                setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    // Log utile en debug ; évite de spammer l'utilisateur
                    return true
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = filePathCallback
                    return try {
                        fileChooserLauncher.launch(arrayOf(
                            "application/json",
                            "application/octet-stream",
                            "*/*"
                        ))
                        true
                    } catch (_: Exception) {
                        fileChooserCallback?.onReceiveValue(null)
                        fileChooserCallback = null
                        false
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val url = request?.url ?: return null
                    return assetLoader.shouldInterceptRequest(url)
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val uri = request?.url ?: return true
                    return uri.scheme != "https" || uri.host != "appassets.androidplatform.net"
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageReady = true
                    loadStage = 5
                    // Injecter les régions fondation si disponibles
                    val regionsFile = java.io.File(context.filesDir, "map_studio_regions.json")
                    if (regionsFile.exists()) {
                        try {
                            val json = regionsFile.readText()
                            val encoded = Base64.encodeToString(json.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                            view?.evaluateJavascript(
                                """
                                (function(){
                                  try {
                                    const raw = atob('$encoded');
                                    const bytes = Uint8Array.from(raw, c => c.charCodeAt(0));
                                    const text = new TextDecoder('utf-8').decode(bytes);
                                    window.__SBH_REGIONS__ = JSON.parse(text);
                                    if (window.SBhBridge && window.SBhBridge.toast) {
                                      window.SBhBridge.toast('Régions AGW chargées');
                                    }
                                  } catch(e) { console.warn('regions inject', e); }
                                })();
                                """.trimIndent(),
                                null
                            )
                        } catch (_: Exception) { /* ignore */ }
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    // Ne signaler que l'erreur de la page principale
                    if (request?.isForMainFrame == true) {
                        loadError = error?.description?.toString() ?: "Erreur de chargement Map Studio"
                        loading = false
                        studioReady = false
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        loadStage = 1
        delay(180)
        loadStage = 2
        delay(180)
        loadStage = 3
        delay(220)
        loadStage = 4
        // Les étapes 5→8 sont déclenchées par le chargement réel de la page
        // et par SBhBridge.ready() appelé par Map Studio après son initialisation.
        delay(900)
        if (!studioReady && loadError == null) {
            loadStage = if (pageReady) 6 else loadStage
        }
    }

    val timeoutRunnable = remember { Runnable {
        if (loading && !studioReady && loadError == null) {
            loadError = "Map Studio n'a pas terminé son initialisation après 20 secondes."
            loading = false
        }
    } }

    DisposableEffect(Unit) {
        loadStage = 4
        webView.addJavascriptInterface(bridge, "SBhBridge")
        mainHandler.postDelayed(timeoutRunnable, 20_000L)
        webView.loadUrl("https://appassets.androidplatform.net/assets/mapstudio.html")
        onDispose {
            mainHandler.removeCallbacks(timeoutRunnable)
            try {
                webView.removeJavascriptInterface("SBhBridge")
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            } catch (_: Exception) { /* ignore */ }
        }
    }

    LaunchedEffect(retryCount) {
        if (retryCount <= 0) return@LaunchedEffect
        loading = true
        loadError = null
        pageReady = false
        studioReady = false
        loadStage = 1
        mainHandler.removeCallbacks(timeoutRunnable)
        mainHandler.postDelayed(timeoutRunnable, 20_000L)
        webView.loadUrl("https://appassets.androidplatform.net/assets/mapstudio.html")
    }

    BackHandler { onBack() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AgwColors.DeepNight)
    ) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )

        if (loading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AgwColors.DeepNight),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.layout.Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "SBH / MAP STUDIO",
                        color = AgwColors.SacredGold,
                        style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                    Text(
                        "ÉDITEUR DE MONDE",
                        color = AgwColors.Sand,
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    LinearProgressIndicator(
                        progress = { ((loadStage.coerceIn(0, 8)) / 8f) },
                        color = AgwColors.SacredGold,
                        trackColor = AgwColors.NightStone,
                        modifier = Modifier
                            .padding(top = 18.dp)
                            .fillMaxWidth()
                            .height(3.dp)
                    )
                    androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))
                    CircularProgressIndicator(
                        color = AgwColors.SacredGold
                    )
                    Text(
                        when (loadStage.coerceIn(0, 8)) {
                            0 -> "Préparation de Map Studio"
                            1 -> "Initialisation de Map Studio"
                            2 -> "Préparation du projet"
                            3 -> "Chargement du World Core"
                            4 -> "Chargement de l'éditeur 3D"
                            5 -> "Chargement des régions et ressources"
                            6 -> "Préparation des textures et blocs"
                            7 -> "Préparation de la caméra"
                            else -> "Monde prêt · entrée dans Map Studio"
                        },
                        color = AgwColors.PaleMarble,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        }

        if (loadError != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AgwColors.DeepNight.copy(alpha = 0.92f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.layout.Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Map Studio n'a pas pu se charger",
                        color = AgwColors.SacredGold
                    )
                    Text(
                        loadError ?: "",
                        color = AgwColors.Sand,
                        modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                    )
                    androidx.compose.foundation.layout.Row(
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(onClick = { retryCount++ }) {
                            Text("Réessayer", color = AgwColors.SacredGold)
                        }
                        TextButton(onClick = onBack) {
                            Text("← Retour", color = AgwColors.GoldSoft)
                        }
                    }
                }
            }
        }
    }
}
