package com.sbh.studio.ui

/**
 * Trilangue FR / EN / AR pour SBh Studio.
 * Noms arabes intégrés (عالم الزهراء، إلخ).
 */
enum class AppLang { FR, EN, AR }

object S {
    fun t(lang: AppLang, key: String): String = table[key]?.get(lang) ?: key

    private val table: Map<String, Map<AppLang, String>> = mapOf(
        "app_name" to mapOf(
            AppLang.FR to "SBh Studio",
            AppLang.EN to "SBh Studio",
            AppLang.AR to "استوديو صباح"
        ),
        "app_subtitle" to mapOf(
            AppLang.FR to "Atelier arabo-gothique · Al-Zahra",
            AppLang.EN to "Arabian Gothic Workshop · Al-Zahra",
            AppLang.AR to "ورشة عربية قوطية · الزهراء"
        ),
        "world_name" to mapOf(
            AppLang.FR to "Al-Zahra",
            AppLang.EN to "Al-Zahra",
            AppLang.AR to "الزهراء"
        ),
        "owl_motto" to mapOf(
            AppLang.FR to "La Chouette veille sur les dunes",
            AppLang.EN to "The Owl watches over the dunes",
            AppLang.AR to "البومة تسهر على الكثبان"
        ),
        "home" to mapOf(AppLang.FR to "Accueil", AppLang.EN to "Home", AppLang.AR to "الرئيسية"),
        "projects" to mapOf(AppLang.FR to "Projets", AppLang.EN to "Projects", AppLang.AR to "المشاريع"),
        "new_project" to mapOf(AppLang.FR to "Nouveau projet", AppLang.EN to "New project", AppLang.AR to "مشروع جديد"),
        "world_agw" to mapOf(AppLang.FR to "Monde AGW", AppLang.EN to "AGW World", AppLang.AR to "عالم الزهراء"),
        "lore" to mapOf(AppLang.FR to "Lore & Histoire", AppLang.EN to "Lore & Story", AppLang.AR to "القصة والتاريخ"),
        "heroes" to mapOf(AppLang.FR to "Héros & PNJ", AppLang.EN to "Heroes & NPCs", AppLang.AR to "الأبطال والشخصيات"),
        "bestiary" to mapOf(AppLang.FR to "Bestiaire", AppLang.EN to "Bestiary", AppLang.AR to "الوحوش"),
        "factions" to mapOf(AppLang.FR to "Factions", AppLang.EN to "Factions", AppLang.AR to "الفصائل"),
        "phases" to mapOf(AppLang.FR to "Phases", AppLang.EN to "Phases", AppLang.AR to "المراحل"),
        "mine_edit" to mapOf(AppLang.FR to "Mine Edit", AppLang.EN to "Mine Edit", AppLang.AR to "تحرير المنجم"),
        "updates" to mapOf(AppLang.FR to "Mises à jour", AppLang.EN to "Updates", AppLang.AR to "التحديثات"),
        "settings" to mapOf(AppLang.FR to "Paramètres", AppLang.EN to "Settings", AppLang.AR to "الإعدادات"),
        "language" to mapOf(AppLang.FR to "Langue", AppLang.EN to "Language", AppLang.AR to "اللغة"),
        "export" to mapOf(AppLang.FR to "Exporter .mcaddon", AppLang.EN to "Export .mcaddon", AppLang.AR to "تصدير الحزمة"),
        "mobs" to mapOf(AppLang.FR to "Créatures", AppLang.EN to "Mobs", AppLang.AR to "المخلوقات"),
        "items" to mapOf(AppLang.FR to "Objets", AppLang.EN to "Items", AppLang.AR to "العناصر"),
        "blocks" to mapOf(AppLang.FR to "Blocs", AppLang.EN to "Blocks", AppLang.AR to "الكتل"),
        "back" to mapOf(AppLang.FR to "Retour", AppLang.EN to "Back", AppLang.AR to "رجوع"),
        "save" to mapOf(AppLang.FR to "Enregistrer", AppLang.EN to "Save", AppLang.AR to "حفظ"),
        "open" to mapOf(AppLang.FR to "Ouvrir", AppLang.EN to "Open", AppLang.AR to "فتح"),
        "ready" to mapOf(
            AppLang.FR to "Studio prêt. La Chouette veille.",
            AppLang.EN to "Studio ready. The Owl watches.",
            AppLang.AR to "الاستوديو جاهز. البومة تسهر."
        ),
        "tagline" to mapOf(
            AppLang.FR to "Un monde où la pierre sombre rencontre les coupoles dorées.",
            AppLang.EN to "Where dark stone meets golden domes.",
            AppLang.AR to "عالم تلتقي فيه الحجارة الداكنة بالقباب الذهبية."
        ),
        "quick_actions" to mapOf(AppLang.FR to "Actions rapides", AppLang.EN to "Quick actions", AppLang.AR to "إجراءات سريعة"),
        "explore_world" to mapOf(AppLang.FR to "Explorer le monde", AppLang.EN to "Explore the world", AppLang.AR to "استكشف العالم"),
        "create_pack" to mapOf(AppLang.FR to "Créer un pack", AppLang.EN to "Create a pack", AppLang.AR to "إنشاء حزمة"),
        "night_court" to mapOf(
            AppLang.FR to "Cour de Nuit",
            AppLang.EN to "Night Court",
            AppLang.AR to "ديوان الليل"
        ),
        "watchers" to mapOf(
            AppLang.FR to "Les Veilleurs d'Al-Zahra",
            AppLang.EN to "Watchers of Al-Zahra",
            AppLang.AR to "حرّاس الزهراء"
        ),
        "scimitar" to mapOf(AppLang.FR to "Cimeterre", AppLang.EN to "Scimitar", AppLang.AR to "سيف منحني"),
        "lantern" to mapOf(AppLang.FR to "Lanterne", AppLang.EN to "Lantern", AppLang.AR to "فانوس"),
        "sultan_djinn" to mapOf(AppLang.FR to "Sultan-Djinn", AppLang.EN to "Djinn Sultan", AppLang.AR to "سلطان الجن"),
        "dune_scorpion" to mapOf(AppLang.FR to "Scorpion des Dunes", AppLang.EN to "Dune Scorpion", AppLang.AR to "عقرب الكثبان"),
        "ruin_specter" to mapOf(AppLang.FR to "Spectre des Ruines", AppLang.EN to "Ruin Specter", AppLang.AR to "شبح الآثار"),
        "night_djinn" to mapOf(AppLang.FR to "Djinn Nocturne", AppLang.EN to "Night Djinn", AppLang.AR to "جني الليل"),
        "yusuf" to mapOf(AppLang.FR to "Yusuf", AppLang.EN to "Yusuf", AppLang.AR to "يوسف"),
        "nadia" to mapOf(AppLang.FR to "Nadia", AppLang.EN to "Nadia", AppLang.AR to "نادية"),
        "rashid" to mapOf(AppLang.FR to "Rashid", AppLang.EN to "Rashid", AppLang.AR to "رشيد"),
        "phase_done" to mapOf(AppLang.FR to "Terminé", AppLang.EN to "Done", AppLang.AR to "مكتمل"),
        "phase_planned" to mapOf(AppLang.FR to "Prévu", AppLang.EN to "Planned", AppLang.AR to "مخطط"),
        "no_projects" to mapOf(
            AppLang.FR to "Aucun projet — créez le premier.",
            AppLang.EN to "No projects — create the first one.",
            AppLang.AR to "لا مشاريع — أنشئ الأول."
        )
    )
}
